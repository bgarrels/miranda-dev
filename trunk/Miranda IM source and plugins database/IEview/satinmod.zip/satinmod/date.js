/*
	This script removes "Today" string
	from relative timestamp in IEView template.
	Other timestamps are displayed normally.
	Version: 1.1
	Author: Wasacz
*/

var re = /today|dzisiaj|heute/i; // replace "today" as in your langpack (case insensitive)

function d(date) {
	if (!re.test(date)) {
		document.write(date +' ');
	}
}
