Author: Kiwi0Fruit

A port of iChadium (http://www.adiumxtras.com/index.php?a=xtras&xtra_id=1546) by Ravi Joshi (ravijo)
I also used iChat for MirandaIM by PowerProductions (http://powerproductions.deviantart.com/art/iChat-for-MirandaIM-19370238)