Title: Facebook IEView Template for Miranda IM
By: hummer
Contact: homer2k@gmx.net
Date: 06.03.2012

--------------------------------------------------
Attachment options can be customized in js/functions.php:

zoomOut: 0.6,       // multiplier image zoom out
zoomIn: 1.8,        // multiplier image zoom in
zoomOutVid: 0.9,    // multiplier video zoom out
zoomInVid: 1.1,     // multiplier video zoom in
imgExts: ['.bmp', '.gif', '.jpg', '.png', '.xbm', 'jpeg'],  // image extensions
checkYoutube: true, // check for youtube videos - true/false
checkImages: true,  // check for images - true/false
prevImgSize: 120,   // image preview width, px
videoWidth: 398,    // video width, px
videoHeight: 224    // video height, px

OR for specified message in facebook.ivt, eg:

$('.message:last').findAttachment({
    checkImages: false,
    videoWidth: 600,
    videoHeight: 400
});

--------------------------------------------------
Version info:
0.2 (06.03.2012)
- Added missing noavatar.jpg
- Added youtube and image preview (attachment)
- Added flash avatar support
- Changed filetransfer icon
- Fixed history message bug

0.1 (03.03.2012)
- First release
