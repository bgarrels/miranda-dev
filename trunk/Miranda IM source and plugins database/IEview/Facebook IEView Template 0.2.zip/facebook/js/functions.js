// search for attachments (images, youtube..)
(function($) {
    
    // Default options
    var O = {
        zoomOut: 0.6,       // multiplier image zoom out
        zoomIn: 1.8,        // multiplier image zoom in
        zoomOutVid: 0.9,    // multiplier video zoom out
        zoomInVid: 1.1,     // multiplier video zoom in
        imgExts: ['.bmp', '.gif', '.jpg', '.png', '.xbm', 'jpeg'],  // image extensions
        checkYoutube: true, // check for youtube videos - true/false
        checkImages: true,  // check for images - true/false
        prevImgSize: 120,   // image preview width, px
        videoWidth: 398,    // video width, px
        videoHeight: 224    // video height, px
    };
    
    // Methods
    var methods = {
        init: function() {
            return this.each(function() {
                var $attachment = $('<div></div>').addClass('attachment');
                
                $('a', this).each(function() {
                    var $url = $(this).attr('href');
                    
                    // Check for Youtube Videos
                    if($url.indexOf('youtube.com/watch') != -1 && O.checkYoutube) {
                        var ytid  = $.jYoutube($url, 'id');
                        if(ytid.length == 11) {
                            var ytimg = $.jYoutube($url, 'small');
                            var ctrl  = '<div class="yt-thumb">';
                                ctrl += '  <img src="' + ytimg + '" class="tglVid" alt="' + ytimg + '">';
                                ctrl += '  <a class="play-btn"></a>';
                                ctrl += '</div>';
                                ctrl += '<a class="close btn-close sicon"></a>';
                            var cont = '<embed width="' + O.videoWidth + '" height="' + O.videoHeight + '" flashvars="' + O.videoWidth + '&amp;' + O.videoHeight + '" wmode="opaque" allowfullscreen="true" scale="scale" quality="high" bgcolor="#FFFFFF" src="https://www.youtube.com/v/' + ytid + '?version=3&amp;autohide=1" type="application/x-shockwave-flash">';

                            var html = methods.buildViewer(ctrl, cont, 'video');                
                            $attachment.append(html);
                            
                        }
                    }
                    
                    // Check for images
                    var $urlExt = $url.substr($url.length - 4, 4).toLowerCase();
                    if(O.checkImages) {
                        $.each(O.imgExts, function(i, extension) {
                            if(extension == $urlExt) {
                    
                                var ctrl = '<a title="view image" class="tgl sicon fb-img"></a>';
                                var cont = '<img width="' + O.prevImgSize + '" src="' + $url + '" alt="' + $url + '">';
                                var html = methods.buildViewer(ctrl, cont, 'image');
                                $attachment.append(html);
                                
                            }
                        });
                    }
                });
                
                // If found, append attachment to message, else remove attachment-container.
                if(!$attachment.is(':empty')) {
                    $(this).after($attachment);
                } else {
                    $attachment.remove();
                }
            });
        },
        buildViewer:    function(control, content, cat) {    
            var zoomInClass = (cat == 'video') ? 'zoomInVid' : 'zoomIn';
            var zoomOutClass = (cat == 'video') ? 'zoomOutVid' : 'zoomOut';

            var html  = '<div class="img-viewer">';
                html += control;
                html += '  <span class="img-controls">';
                html += '    <a title="zoom in" class="sicon ' + zoomInClass + '"></a>';
                html += '    <a title="zoom out" class="sicon ' + zoomOutClass + '"></a>';
                if(cat == 'image') {
                    html += ' <a title="rotate 90deg" data-angle="90" class="rotate sicon rRight"></a>';
                    html += ' <a title="rotate 0deg" data-angle="0" class="rotate sicon rCenter"></a>';
                    html += ' <a title="rotate 270deg" data-angle="270" class="rotate sicon rLeft"></a>';
                }
                html += '  </span>';
                html += '  <div class="image-prev">';
                html += content;
                html += '  </div>';
                html += '</div>';
                
            return html;
        },
        videoZoom: function(inout) {
            return this.each(function() {
                var $vid = $(this).closest('.img-viewer').find('embed');
                var multiplier = (inout == 'out') ? O.zoomOutVid : O.zoomInVid;

                $vid.width($vid.width() * multiplier);
                $vid.height($vid.height() * multiplier);
            });
        },
        zoom: function(inout) {
            return this.each(function() {
                var $img = $(this).closest('.img-viewer').find('.image-prev img, .image-prev embed');   
                var multiplier = (inout == 'out') ? O.zoomOut : O.zoomIn;

                $img
                .animate({
                    width: $img.width() * multiplier,
                    height: $img.height() * multiplier
                });
            });
        }
    };
    
    $.fn.findAttachment = function(options, method) {
    
        $.extend(O, options);
        
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 2));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error('Method ' +  method + ' does not exist');
        } 
    }; 

})(jQuery);

// Status
(function($) {

    $.fn.writeStatus = function(options) {
    
        var getClassName = function() {
            return (options.text.indexOf('offline') !== -1) ? ' offline' : '';
        };
        
        var options = $.extend({
            name: '',
            text: '',
            history: '',
            tpl: {
                outer: '<div class="msg-outer status icon ' + getClassName() + ' ' + options.history + '"></div>',
                inner: '<span class="nick">' + options.name + '</span> <span class="info-txt">' + options.text + '</span>'
            }
        }, options);
        
        var $html = $(options.tpl.outer);
        $html.html(options.tpl.inner);
        $html.appendTo('body').fadeIn();
    }
    
})(jQuery);

// Support for flash-avatar
(function($) {
    $.fn.showAvatar = function(avatarUrl) {
        return this.each(function() {
            var html;
            if(avatarUrl.substr(avatarUrl.length - 4, 4).toLowerCase() == '.swf') {
                html = '<embed type="application/x-shockwave-flash" width="48" height="48" src="' + avatarUrl + '">';
            } else {
                html = '<img src="' + avatarUrl + '" alt="Avatar">';
            }
            $(this).html(html);
        });
    };
})(jQuery);

// bind event-handler
$('body')
.on('click', '.zoomIn', function() {
    $(this).findAttachment({}, 'zoom', 'in');
})
.on('click', '.zoomOut', function() {
    $(this).findAttachment({}, 'zoom', 'out');
})
.on('click', '.zoomInVid', function() {
    $(this).findAttachment({}, 'videoZoom', 'in');
})
.on('click', '.zoomOutVid', function() {
    $(this).findAttachment({}, 'videoZoom', 'out');
})
.on('click', '.rotate', function() {
    var angle = $(this).attr('data-angle');
    $(this).closest('.img-viewer').find('.image-prev img').rotate(angle);
})
.on('click', '.closeVid', function() {
    $(this).closest('.img-viewer').find('.image-prev').fadeOut(function() {
        $(this).prev('.img-controls').fadeOut();
    });
})
.on('click', '.close', function() {
    var $container = $(this).closest('.img-viewer');
    $(this).fadeOut();
    $container.find('.img-controls, .image-prev').fadeOut(function() {
        $container.find('.yt-thumb').fadeIn();
    });
})
.on('click', '.play-btn', function() {
    var $container = $(this).closest('.img-viewer');
    $(this).closest('.yt-thumb').fadeOut(function() {
        $container.find('.img-controls, .image-prev').fadeIn();
        $(this).closest('.img-viewer').find('.close').fadeIn();
    });
})
.on('click', '.tgl', function() {
    if($(this).attr('title') == 'view image') {
        $(this).attr('title', 'close image').addClass('btn-close');
    } else {
        $(this).attr('title', 'view image').removeClass('btn-close');
    }
    var $container = $(this).closest('.img-viewer').find('.image-prev');
    $container.fadeToggle(function() {
        $(this).prev('.img-controls').fadeToggle();
    });
});