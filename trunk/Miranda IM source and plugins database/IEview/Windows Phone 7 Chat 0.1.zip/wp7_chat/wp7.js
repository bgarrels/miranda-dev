function scrollsmooth()
{
window.scrollBy(0,-35);
setTimeout("scrolldown()",5)
}
var counter=0;
function scrolldown()
{
window.scrollBy(0,2);
counter++;
if(counter!=36)
{
setTimeout("scrolldown()",1);
}
if(counter==36)
{
counter=0;
}
}


