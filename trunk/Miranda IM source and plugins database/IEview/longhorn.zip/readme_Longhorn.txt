/--------------------------------------------------------------
|
| Longhorn (Graphics/Design by Hidea, Coded by Russellc)
|
|	Hidea: http://hidea.deviantart.com
|	       Email: daemon.mailer@gmail.com
|	       MSN: daemon.mailer@gmail.com (email before adding)
|	       AIM: mrhidea
|
|       Russellc: http://chunk.3rror.com
|		  Email: thechunk@gmail.com
|		  MSN: i_use@email.com
|		  AIM: thechunkster2k3
|
|
|	The Segoe UI font is required to use this
|	It can be found at http://chunk.3rror.com/files/segoeui.zip
|
|       NOTE: WHEN UPDATING, replace all files with ones included in archive
|
|
\--------------------------------------------------------------
 |
 |  How do I install this? (assuming you have IEView set up properly)
 |    1) Extract the files using 7zip, Winrar, or XP's built in ZIP support
 |       (anything that can extract .ZIPs properly will do) to any folder
 |        > It is -recommended- to extract in the Miranda folder.
 |    2) Go to the IEView options and go to the Templates tab.
 |    3) Browse (...) for the folder Longhorn\ that you should have remembered
 |       and double click the longhorn.ivt file (in Longhorn\ folder).
 |    4) Hit Apply and start chatting!
 |
 |  Variations:
 |    - longhorn.ivt - Regular style
 |    - longhorn_glass.ivt - A variation with an "Aero"-esque style
 |			     rather than the solid colour background
 |    - longhorn_thin.ivt - It's thin.
 |
 |    - Others are self-explanatory based on the above descriptions.
 |
 |  Stuff you'll want to know:
 |    -  Backgrounds:
 |        > To change backgrounds:
 |            1) Open longhorn.ivt/longhorn_glass.ivt in Notepad
 |            2) Choose a background from the Longhorn\images\ folder
 |            3) Put the name of the background (ex. background_leaf.png) into
 |               the line that looks like this (first few lines in the .ivt file):
 |                   body { background:url(images/background.png) 
 |            4) Replace background.png with the name of the background
 |               that you found (ex. replace background.png WITH background_leaf.png).
 |
 |    -  Why isn't my avatar showing up?
 |        > You need to save your avatar under the Longhorn\ folder
 |          that is extracted from the .ZIP archive as myavatar.jpg. There
 |          is already a file named myavatar.jpg; it is the default avatar
 |          to be in place of your actual avatar.
 |
 |    -  Why isn't my buddy's avatar showing up?
 |        > You need the latest version of IEView (1.0.2.1) and
 |          TabSRMM 0.9.9.92 (http://tabsrmm.sf.net)
 |
 |    -  So, I hear of PNG Transparency. What's so good about it?
 |        > Choose any background you wish and plant it into the code
 |          and you'll have a beautifully blended background with the 
 |          conversation =)
 |        > Changing of backgrounds is explained above.
 |
 |    -  Does message grouping work?
 |        > Yup! Just enable it in Miranda IM Options -> IEView plugin -> Templates tab
 |    
 |    -  Thanks to:
 |        > cpm for the Javascript code provided when doing Satin (used in
 |          Longhorn also)
 |
 | 
 |  Changelog:
 |   April 5, 2005 (v1.1)
 |   -  New "Black" glass-only style
 |   -  myavatar.jpg changed to same as noavatar.jpg until one changes it
 |   -  "Thin" styles created for..everything
 |   -  I hate making readmes
 |
 |   April 3, 2005 (v1.0)
 |   -  First release
 |
 |
 \-------------------------------------------------------------