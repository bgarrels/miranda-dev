Title: Facebook IEView Template for Miranda IM
By: hummer
Contact: homer2k@gmx.net
Date: 03.03.2012

--------------------------------------------------

Version info:

0.1 (03.03.2012)
- First release
