function writeStatus(name, text, history)
{
    var className = (text.indexOf('offline') !== -1) ? ' offline' : '';
    var $html  = $('<div class="msg-outer status icon' + className + ' ' + history + '"></div>');
    $html.html('<span class="nick">' + name + '</span> <span class="info-txt">' + text + '</span>');
    $html.appendTo('body').fadeIn();
}
