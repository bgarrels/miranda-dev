Trillian message history and contacts importer
----------------------------------------------
Imports message histories and contacts from Trillian instant messenger.
Features:
- Support for ICQ, MSN, AIM, Yahoo! and IRC protocols
- Succesfully tested on various systems and Trillian log formats
- New protocols can easily be added, just send me part of a log file
- Lots of options for importing and yet:
- Easy to use
- UTF8 support (and detection)

I included the source code so if you improve the Plugin please let me know:
dhofer(at)freesurf(dot)ch

Installation
------------
Copy the "importTrillian.dll" into your miranda\plugins directory. You can then import
the history using the main menu entry.

Importing history
-----------------
Select the menu entry "Import Trillian history/contacts..." in the main Menu. Then chose
which protocols should be imported and click "Start". This will only import the history
of existing contacts.
It's highly recommended to deactivate any notification plugin/setting before importing
the history!

Importing contacts
------------------
Same as importing history but you have to select the "Add new contacts from history"
option. If you imported the history of your existing contacts before you should
deselect the "Import history of existing contacts" to avoid duplicate entires.
This will ignore contacts with empty chat logs.

ATTENTION
---------
This plugin works for my Trillian logs but it might import bogus data with your logs.
It also doesn't check for dublicate messages so you'll have to let it complete the import.
I'm not responsible for any damage caused by this plugin, use it at your own risk!
(I recommend backing up the Miranda database before using it.)
The import can take a long time (~1h for me).

If you encounter a crash or a false import please send me the part of the Trillian .log
file that isn't imported correctly and I'll try to fix it.

Changelog
---------

0.2.0
-----
- Fixed some UTF8 importing issues
- Added user options for log file format
- Added the option to delete events prior to a specified date
- Fixed a timestamp detection bug
- Improved duplicate event handling

0.1.8
-----
- Fixed folder selection issue

0.1.7
-----
- Added fast mode

0.1.6
-----
- Added option to skip duplicate events
- Improved Trillian v3.1 support
- Fixed crash bug
- Fixed name length

0.1.4
-----
- Added experimental Trillian v3.1 support
- Fixed wrong message ordering
- Fixed whitespace before sent messages
- Fixed first log file not being imported
- Fixed crash bug on some rare occasions

0.1.2
-----
- Added translation support
- Speed improvement
- Recoded some functions
- Added GPL headers & licence

0.1.0
-----
- Added support for Yahoo! message history importing
- Added support for IRC message history importing
- Added contact importing
- Added new options
- Fixed a memory leak

0.0.4
------
- Added support for AIM message history importing
- Added importing of status report messages
- Fixed import bug for messages with [h:m:s] time format

0.0.2
------
- Added support for MSN message history importing
- Improved dialogs

0.0.1b
------
- Recompiled using proper flags

0.0.1
-----
- Initial public release