//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDC_BACK                        3
#define IDD_TRILLIAN                    105
#define IDD_DIALOG1                     106
#define IDD_STARTUP                     106
#define IDI_IMPORT                      177
#define IDC_MIRABILIS                   1000
#define IDC_DONTLOADPLUGIN              1001
#define IDC_MIRANDA                     1001
#define IDC_USEFINDADD                  1004
#define IDC_OTHER                       1005
#define IDC_LIST                        1006
#define IDC_FILENAME                    1007
#define IDC_PROGRESS                    1008
#define IDC_FILEP                       1008
#define IDC_STATUS                      1009
#define IDC_MIRABILISRUNNING            1010
#define IDC_OVERP                       1010
#define IDC_RADIO_ALL                   1016
#define IDC_RADIO_CONTACTS              1017
#define IDC_STATIC_ALL                  1019
#define IDC_STATIC_CONTACTS             1020
#define IDC_ICQUIN                      1025
#define IDC_LOGDIR                      1027
#define IDC_BROWSE                      1028
#define IDC_IMPICQ                      1029
#define IDC_IMPMSN                      1030
#define IDC_IMPAIM                      1031
#define IDC_IMPIRC                      1032
#define IDC_IMPMSG                      1033
#define IDC_IMPSTAT                     1034
#define IDC_IMPADD                      1035
#define IDC_IMPEX                       1036
#define IDC_IMPYAHOO                    1037
#define IDC_IMPIRC2                     1038
#define IDC_IMPCHA                      1038
#define IDC_INFO1                       1039
#define IDC_INFO2                       1040
#define IDC_INFO3                       1041
#define IDC_INFO4                       1042
#define IDC_INFO5                       1043
#define IDC_SKIPDUP                     1043
#define IDC_INFO6                       1044
#define IDC_IMPSTAT2                    1044
#define IDC_SPEEDMODE                   1044
#define IDC_REPDUP                      1045
#define IDC_DELBEFDATE                  1046
#define IDC_DELBEF                      1047
#define IDC_UTF8ALWAYS                  1048
#define IDC_UTF8h                       1049
#define IDC_UTF8AUTO                    1049
#define IDC_UTF8                        1050
#define IDC_STATIC                      -1
#define IDC_INFO7                       -1
#define IDC_DELBEFINFO                  -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
