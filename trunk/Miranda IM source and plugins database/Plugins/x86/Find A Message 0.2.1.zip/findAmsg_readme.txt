Find A Message
-------------
Find A Message gives you the option to search through your entire history looking for certain words/phrases

NOTE:
-----
- sorting only works properly for the contacts nickname and protocol
- double-clicking on a search result will load that contacts history. you manually need to find the msg in the history dialog.
- search by time is not implemented yet because i couldnt get it to work and have other stuff to do...


Hidden Settings:
----------------
If you want to change the order of the columns in the reaults window you need to edit the database directly.
open up DatabaseEditor (or Database Viewer) and goto the "Current USer" folder, expand that and goto the "findAmsg" folder. then just edit the values for the 5 settings there from 0 to 4 in the order you want them to appear.


Changelog
----------
0.2.1
- finally got around to getting the search by date stuff working..


0.2
- the main window is now resizable (thanx Frz)
- not using StrStrI anymore to do non-case sensitive searches (thanx Matrix)
- added multithreading so miranda doesnt free while searching (thanx noname, Matrix and egodust)
- added advanced search options
-- only show inbound msgs
-- only show outbound msgs
-- show both
-- show max of X results
-- search with case sensitivity
-- only search certain contacts
- added export results to txt file
- added copy message to clipboard (and fixed a stupid bug that was only found trying to add this)

0.1
- initial public release

Translation
-----------
here are all the translatable strings for Find A Message
make sure you leave the %d in any strings that has it. 
new translation strings...

[Search Canceled]
[Progress: %d/%d Contacts Searched. %d/%d Messages Searched]
[Finished... %d Contacts Searched. %d Messages Found]
[Protocol]
[Contact]
[Time/Date]
[Message]
[I/O]
------------------------------

(c) 2004-5 Jonathan Gordon (jdgordy@gmail.com)

contact me on ICQ, MSN, Email or Telepathy... just make sure you tell me who you are or youll get blocked :)
ICQ: 98791178
MSN: jonnog@hotmail.com

