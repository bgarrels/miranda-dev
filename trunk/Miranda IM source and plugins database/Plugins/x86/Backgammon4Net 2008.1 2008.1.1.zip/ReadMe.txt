Backgammon4Net
(c) No rights reserved
E-Mail: packpaul@mail.ru
URL:    http://backgammon.chess4net.ru
======================================

ABOUT

Backgammon4Net is a client for playing backgammon and its viariations. It can be used as standalone application (Socket version) or as plug-in for such instant messengers as Miranda, QIP Infium, Trillian Pro and &RQ (R&Q).

INSTALLATION

Socket version:
  Extract archive to a desired folder on your computer.

Miranda plug-in:
  Extract archive to the Miranda Plugins directory and re/start Miranda.

QIP Infium (Beta 9000 with a support for SDK 1.3.0) plugin:
  Extract archive to QIP Infium Plugins directory and re/start QIP Infium.

Trillian Pro plug-in:
  Extract archive to the Trillian plugins directory; go to Trillian->Trillian Preferences... choose Plugins and check Backgammon4Net_trillian.dll box.

&RQ (R&Q) plug-in:
  Extract archive to the installation directory of &RQ

HOW TO USE IT

Socket version:
  1) Start Backgammon4Net.exe
  2) Choose from menu 'Connection->Connect...'
  3) Type in your name into 'Your Nick' edit-box.
    a) Choose Server; provide your partner with IP (type 'ipconfig' in Start->Run... or command line to find it out); enter Port# (agree upon it with your partner).
    b) Choose Client; Enter IP or domain Name that your partner has told you; Enter Port# (for each instance of Backgammon4Net it should be unique).
  4) Click OK and wait until the connection is completed.

Miranda:
  1) Right-click the contact you want to play backgammon with and select 'Backgammon4Net' from contact pop-up menu.
  2) Wait until connection is completed.

QIP Infium:
  1) Open a chat window for the contact you want to play backgammon with.
  2) Press 'Backgammon4Net' chat button (below the contact's avatar in chat window).
  3) Wait until connection is completed.

Trillian Pro:
  1) Right-click the contact you want to play backgammon with and select 'Backgammon4Net' from pop-up menu or open message window for that contact and type "/BACKGAMMON4NET" without double quotes.
  2) Wait until connection is completed.
  NB: Backgammon4Net is using instant messages to transmit moves and other information. In Trillian Pro there is no way to suppress messages like in Miranda, so you may want to switch off the sounds for incomming messages while playing.

&RQ:
  1) Open a chat window for the contact you want to play backgammon with.
  2) Press 'Backgammon4Net' chat button (below the upper frame where the incomming and outgoing messages are shown).
  3) Wait until connection is completed.

HOW TO HELP

Backgammon4Net is constantly improving and it is up to you what features will be included in the next release. Please send all your wishes and/or complaints to packpaul@mail.ru or write them on forum of the main site. You can also try to translate Backgammon4Net's interface and help (see Backgammon4Net.lng and Help\ENG.zip therefore)

Backgammon4Net is a software and, like it is peculiar to software, it will never be bug free. Please report all bugs you may find to forum or packpaul@mail.ru but change log before reporting.

ENJOY!

Pavel Perminov, author of Backgammon4Net

=========================================

Change log
-----------

Backgammon4Net 2008.1.1 (Miranda)
[2008-04-22] API interface support for Miranda 0.7.17 and higher. Czech interface translation added

Backgammon4Net 2008.1 (&RQ)
[2008-02-14] 9.7.4 (and up) and 9.7.3 are supported. A superficial testing showed some inconsistancies in dialog handling (looking forward to be fixed although)

Backgammon4Net 2008.1 (Socket, Miranda, &RQ)
- Everything is new and open to a construct critique and improvements
- Interface/help languages: English and Russian
- 5 backgammon variants are implemented