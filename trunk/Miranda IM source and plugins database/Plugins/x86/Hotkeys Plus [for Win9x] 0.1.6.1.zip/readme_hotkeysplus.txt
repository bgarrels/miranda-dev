======== 		HotKeys	Plus

Plugin name:		Hotkeys+
File name:			HotkeysPlus.dll
Current version:	0.1.6.0
Copyright: 			� 2006-2009, [w]Lite

About:
==========

I think that it's not very good, if each Miranda plugin will set keyboard hook by itself, especially if plugin has need only for one or two hotkeys. So HotkeysPlus can perform this job by the best way ;)
It has special control for detecting pressed keys, so user can select virtually every key and associate it with desired Miranda function.

---------------------------------------------------------
Note: if you start Miranda after all other application, that are hooking keyboard, Miranda will override all hotkey in system, if they are equal for its set keys, excepts "Ctrl+Alt+Del". So you can "take off" some hotkeys, that other application owns :)
---------------------------------------------------------

Expert and simple modes of Miranda Options are supported.

Versions for different systems:
==========

Plugin is developed for new Windows NT core based systems (Windows 2000, Windows XP).
Since the February 2007 existed and supported parallel plugin version, adapted for Win9x systems.
I do not refuse to make plugin working on those legacy OSes, but I don't test it, as it takes place regarding Windows XP.

	Notification for Win9x users:
	Drop down lists (Control aka "ComboBox") can be shown partly because in Windows 98 maximal size of drop field must be set strictly.
	So, use arrow keys - up and down - to see a list of all items.


Web:
==========

Miranda forum page: 				http://forums.miranda-im.org/showthread.php?p=78163

Download page (Win2k/XP - Unicode):	http://addons.miranda-im.org/details.php?action=viewfile&id=2932

Download page (Win9x - ANSI):		http://addons.miranda-im.org/details.php?action=viewfile&id=3577

Also perhaps you can find testing builds on my private site: http://lite.site.io/


Small FAQ
==========

Q: What functions can I bind with hotkeys?

A: All what exists in Miranda as separate service (without parameters/arguments!)
So, for example, all functions that are in Main Miranda menu.
A part of available services you can select from the menu list at the Options page of HotkeysPlus. Contact-dependent functions are available by right click on contact in Contact list: "Add hotkey" item.
Note, in the choise lists are only functions that I see and use. I don't use and even don't know (don't have) all plugins. So, if you think that the function you added and use will useful for other people, so post it in HK+ forum thread and I add it to the current menus.
Naturally, hotkeys works with Miranda common and protocols' statuses.

Q: The popup appears with text that there were no open windows, although the conversation windows were closed. How to fix it?
A: In Options go to 
"Message Sessions-> General->Message windows options: Other options"
and check here the checkbox "Enable event API (support for third-party plugins)"

Q: How to get more names of miranda services?

A: The simplest way - to look at "Options": "Customize"->"MenuOrder". In the grayed edit field "Service" you see now the required service name.
To extract service name from the field I can recommend  "InqSoft Window Scanner 1.7": http://s0m.narod.ru/iws_inst.zip

Also the great tool for this objective - plugin "Services list" by Eblis:

	http://addons.miranda-im.org/details.php?action=viewfile&id=3085
		
It lists a lot of Miranda services and has an option to add selected service's name into "HotkeysPlus".

NOTE: many services require specific arguments. So, if you are trying to bind with hotkey and run the service (that is to be started with arguments), it gets trash data as arguments. In most cases it causes Miranda crash. So, you understand, such tricks are for advanced Miranda users only. If you don't know what do a service, use simple plugin interface that you see with unchecked checkbox "Show expert options", or use only the hotkeys added in "HotkeysPlus" by third-party plugins in automatic mode and selected in special menus of HotkeysPlus.

####################################################

If you know and use some services that are lacking in HK+ list, post them on forum page, and I add them to HK+ menu list.

************************************************************************************
If you want to perform anything else by hotkeys, ask plugin developers to create service wrapper function for desired action.
*************************************************************************************
---------------------------------------------------------		
	Hidden ICQ XStatus option:
	
	You can also invoke input dialog for XStatus changing. 
	In such case you should use service line:
	[Proto]/menuXStatus[XStatus number]
	where [Proto] means protocol's name, 
	"XStatus number" - code of XStatus (0-32)
---------------------------------------------------------
==========

"Variables" plug-in support
==========
HK+ can parse "Variables" in status messages and in inserted text.
For example, such line in "Insert text" function pastes in active SRMM window "Hello" with first name (if exists) or with nick of your buddy.

	Hello, ?if2(!cinfo(%subject%,first),!cinfo(%subject%,nick))!

For more information, see the documentation of the corresponding plug-in.

Internal plug-in's variable
==========
- for pasting text and web-browsing
(This variable doesn't depend on the plug-in "Variables".)
Input the data at "Edit" page of the plug-in (the biggest textbox).
By default it is %var% - you should set the line that will be sent into your default browser.
For instance, if in text field of "Open site" function will be this line:

	http://www.google.com/search?q=%var%&num=30&ie=utf-8&oe=utf-8

- then you invoke search by means Google search engine with word that will be selected in current active Miranda conversation window (30 links per page, code table - utf-8 - default for current versions of browsers).

Default variable %var% can be changed by user. A lot of Internet servers (search sites, shops, file servers and so on) support this way of access to their data.


Developers:
==========
See "m_hotkeysplus.h" for built-in support.
Please, publish names of services, that can be used by hotkeys. Remember about good mnemonic parameters and short form of services' names ;)

Installation:
==========
Just install it ;)! (Copy to the subfolder "Plugins" of your Miranda root folder.) 


Misc:
==========
Pre-release version (with version stamp 0.0.0.9) was called "HotKey Engine" and provided hotkey support for "Hdd Info" plugin only. 
Several builds were available in Internet for testing purposes, without publishing of release version (E.g. 0.1.3.0, 0.1.4.0).
I recommend to use the latest release build only:
http://addons.miranda-im.org/details.php?action=viewfile&id=2932

====================
The plugin is compiled and tested on system:
	Microsoft Windows XP Service Pack 2 (English)
with:
	- Miranda IM 0.4.0.1 ANSI	 (release) - ANSI version of HK+
	- Miranda IM 0.5	 Unicode (release)
	- Miranda IM 0.6.1	 Unicode (release)
	- Miranda IM 0.7	 Unicode (release)
	- Miranda IM 0.8 	 Unicode (testing)
	
Minimal recommended version of Miranda is 0.7 Unicode!
Previous versions provide only basic functionality and not be considered as target environment for development of the plugin.
Plugin's testing always carries out on _current stable_ build of Miranda.

Base image address: 0x33000000

============================================================
ChangeLog:
============================================================
====
0.1.6.0
============
+ full support of Unicode
+ support for new Miranda API (GUID)
+ functions: Contact List frames handling
+ functions: Enable/disable sounds
+ functions: Show/hide offline contacts
* buttons were removed from "Options" -> "List", use menus or keys instead
====
0.1.5.0
============
+ ability to set system-wide and Miranda scope hotkeys
* optimization of hotkey procedure (improved perfomance)
+ keystrokes sounding
+ ICQ's XStatus change support
+ Common (CList) status change support
+ "Variables" plug-in support
+ "Updater" plug-in support
+ basic support for "Open Last closed conversation window" function
+ function to open web-site with selected text of conversation window as option
+ functions: to activate Contact List, to paste text into conversation window, to open Miranda menus (main and common status)
+ list of predefined functions
* menu rewrited by GenMenu functions
+ preventing of adding items equal to already existed
+ sorting items by pressing on column header
+ columns width adjusting
+ custom column "Group"
+ tabbed interface of "Options"
+ plug-in's "Options" page was moved to "Customize" branch
+ set base image address - 0x33000000
* other interface improvements

0.1.4.0
============
~ was available as testing version only, no official release.

0.1.3.0
============
~ was available as testing version only, no official release.

0.1.2.0
============
+ possibility to associate multiple functions with single hotkey
+ support for status change functions

0.1.1.0
============
+ support for hotkeys with three modifier keys (like "Ctrl+Alt+Shift+Z")

0.1.0.0
============
* first release

0.0.0.9
============
* pre-release version (as "HotKey Engine") was in set with  "Hdd Info" plugin and supported only this one's functions.
