#define MS_HOTKEYSPLUS_ADDKEY		"HotkeysPlus/Add"

/*
This service registers hotkey for 
WPARAM - service to perform (char*)
LPARAM - decription of the service (char*)
Returned values:
0 - success,
1 - hotkey for this function is already existing,
2 - the service, that you try to register the hotkey for, not exists

Don't call this service in every Miranda startup, use next one instead.
*/

#define MS_HOTKEYSPLUS_EXISTKEY "HotkeysPlus/Exist"
/*
This service checks whether hotkey  for service (WPARAM (char*)) exists
LPARAM - not used
Returned values:
0 - failed,
1 - the hotkey for this function exists,
2 - the service not exists
*/

