mNetSend plugin for Miranda IM
==========================================================================

This plugin provides WinPopUp protocol for Miranda IM. It can be used
in local networks based on Windows in place of the messenger service. It also has some features, that the messenger service didn't have:

- It can monitor statuses of contacts (look for available for message delivery)
- It can find the real message sender
- It supports more than only online/offline statuses
- It can use custom names for sending messages



What's new in this version
==========================================================================

The old core had too many bugs, so in this version 95% of the core is rewrited. It is more stable now. No kidding!

Added some new features�the main of them is Safe Mail-Slots. Safe mail-slots don't use Windows API for creating mail-slots, because it can't tell you who the heck you got the message really from. Instead it uses RAW sockets to capture Mail-Slots packets and find real senders by their IP address.

Additional notes
==========================================================================

You need to use a NetBIOS name in order to send messages. NetBIOS name can include any character or number and must not be longer than 15 symbols.
This name must be unique on your network. No one can use the same name as yours, so if you have trouble with name registration, look if somebody already uses it.
In windows 2k or XP you can do it by typing in the command line window
"nbtstat -a NETBIOSNAME"
where NETBIOSNAME is the name you wanna use.

If it�s found, you better use some other name. (Bummer)

In some cases old mNetSend statuses aren�t compatible with new ones. "Me sorry" =)

You need to be in Administrator mode to use safe mail-slots. This mode is needed to be able to create RAW sockets. Administrator can turn on RAW sockets for non-admin mode by changing the registry key "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Afd\Parameters\DisableRawSecurity"
But it�s strongly NOT RECOMENDED. RAW sockets may be used by other programs for hacker attacks.
Also some firewalls can block RAW sockets. So you�d need to give RAW Socket access for Miranda in order to use Safe Mail-Slots

No more support for �*� in �Find/Add contact� dialog. Use multiple contacts selection to send the same message to more than one.

To send messages to domain or all users you can yse "Quick Send Message" (Use mailslots for sending) �� add quick contact with name *

Installation Instructions
==========================================================================

Extract the zip file into the Miranda plugin directory. At first run plugin will ask you for a NetBIOS name.


Thanks
==========================================================================
Grate thanks to Elk for texts and debug
and all people who use it