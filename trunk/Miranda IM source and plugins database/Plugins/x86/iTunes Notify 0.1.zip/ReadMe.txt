iTunes Notify
 - ReadMe

1. About  ..............................................................
2. What you need .......................................................
3. Install .............................................................
4. License .............................................................

===
1. About

"iTunes Notify" is a plugin for the Instant Messaging-Software "Miranda
IM"  (you can get it at www.miranda-im.org - it's the best software for
IM i know). It shows you the current track at iTunes, anytime the track
changes.

===
2. What you need

Of course you need iTunes.   And secondly you need   the Miranda-Plugin
"PopupPlus"               (you           can          get it         at
http://www.miranda-im.org/download/details.php?action=viewfile&id=1170)

===
3. Install

Just put the DLL-File in your Plugin-Folder at your Miranda-Directory.
(Normally at C:\Program Files\Miranda IM\Plugins\). All done.

===
4. License

See License.txt or License.de.txt

===
Copyright (c) 2004-2005 by Christopher Harms, CSD-Software
