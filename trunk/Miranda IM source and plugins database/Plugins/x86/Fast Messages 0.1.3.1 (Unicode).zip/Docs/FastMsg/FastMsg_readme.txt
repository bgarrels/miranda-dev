Fast Messages plugin for Miranda IM
by Timofey Bashkov a.k.a. TIMCAT

Description
========

A plugin that adds fast messages built-in message dialog support. 

Features:
- Capability to group messages
- IcoLib support
- Translation support

Installation
========

1) Close Miranda.
2) Extract the zip file in the Miranda home directory.
3) Start Miranda.
4) For tabSRMM: Activate the event API (support for third party plugins)

How to use
========

- Go to Options/Events/Fast Messages to configure Groups list and Messages list.
- When open message dialog, a Fast Messages button appears on your message window.
- Click on Fast Messages button, select message in list, insert message text in message area

Bugs
====
No guarantees, but probably there are some bugs. If you find something, and would 
like to see this fixed then post on the Miranda forum or e-mail as detailed as possible report 
on the bug (version numbers, OS, how to reproduce it) and I will get back on that.

ChangeLog
======== 

0.1.3.1
--------
* Fixed bug when Miranda crashed on changing icons (for IcoLib)

0.1.3.0
--------
+ Added UUID for 0.8.x.x compatibility
  ->MIID_FASTMSG {D737535F-DE92-4e9c-82EB-4478412FEE31}
+ Added Updater support

0.1.2.1
--------
* Fixed bug with button size for Scriver
* Fixed bug:
   ->when didn't change icons (flashing) on receive message
   ->when didn't show typing notifications
   ->when spontaneous sending the message
* Updated translation file
* Updated screenshot
+ Added option to choose button position for Scriver

0.1.2.0
--------
* Updated screenshot
+ Added Groupchat support (for tabSRMM, Scriver)
+ Added options:
   ->if the SHIFT key is down, that message is only inserted ignoring option "Send messages automatically"

0.1.1.0 (internal)
--------
* Changed button position for Scriver
+ Added IcoLib support

0.1.0.2 (internal)
--------
* Renumbered history version
   0.1.0.1(0.0.0.6)
   0.0.1.1(0.0.0.4)
   0.1.0.0(0.0.0.5)
   0.0.1.0(0.0.0.3)
* Updated Fast Messages main icon (thx Faith Healer)
* Updated translation file
* Fixed bug with button position:
for SRMM:
   ->on Maximized and Minimized message window (when used SmileyAdd plugin)
for Scriver:
   ->when hide toolbar
+ Added options:
   ->to show Fast Messages options by click the right mouse button on Fast Messages button

0.1.0.1(0.0.0.6)
--------
* Fixed bug when inserting sometimes wrong message

0.1.0.0(0.0.0.5)
--------
* Fixed bug with button position:
for SRMM,Scriver:
   ->when Miranda crashed on added contact
for tabSRMM:
   ->when hide toolbar,
   ->when change sizes a message window(on hide some font buttons)
* Updated translation file
* Updated screenshot
+ Added capability to group messages
+ Added options:
   ->to show Fast Messages options by click button when no messages in list,
   ->PopUp menu on message list to move messages

0.0.1.1(0.0.0.4)
--------
* Fixed bug with button position for tabSRMM
+ Added flat button capability for tabSRMM

0.0.1.0(0.0.0.3)
--------
+ Added tabSRMM support

0.0.0.2
--------
* Fixed bug when messages not send automatically
* Fixed bug with Fast Messages button position
* Fixed bug with Fast Messages menu coordinates
+ Added translation capability
+ Added documentation

0.0.0.1
--------
First release.