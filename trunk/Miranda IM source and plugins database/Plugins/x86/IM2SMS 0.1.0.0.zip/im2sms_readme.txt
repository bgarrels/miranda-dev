          IM2SMS - v0.1.0.0
-----------------------------------------------
           -=Miranda Plug-In=-
Copyright (C) 2006-2007 Tornado (Saar)
-----------------------------------------------

Desc:
====
This plug-in will forward IM messages (From any protocol including: ICQ, MSN, Jabber etc.) using ICQ to your mobile phone as an SMS.
The idea is based off icq-sms that doesn't really seems to work with Hebrew.. hmm :/


* Translators: Check out im2sms_translation.txt for the complete list of strings you will need to translate IM2SMS


Installation:
============
To install the plug-in you will need to copy IM2SMS.dll to your Miranda's plug-in directory (<MIRANDA DIR>\plugins).


Uninstallation:
==============
Shutdown Miranda, then delete IM2SMS.dll from <MIRANDA DIR>\plugins.


How to use:
==========
Well, first you should go to the options page (Options->Plugins->IM2SMS) to set your cellphone number to be used (Remember to use your international prefix..).
There are 2 ways to start using IM2SMS:
	- Go to the main menu, then choose: Activate IM2SMS. Any message received will be forwarded to your mobile phone.
	- In the options dialog, you can choose a status at which messages will be forwarded automatically.
	  i.e. When you go Away, messages will automatically be forwarded.
This plugin was written with simplicity in mind, but I'm open to suggestions if you have any :)


Final Notes (Or: Stuff you should know):
=======================================
- Be sure you have the ICQ protocol installed.. SMS' are sent through the ICQ network.
- Your messages are limited to 70 characters. That's on purpose. :)


Credits (Thanks... and stuff):
=============================
Big thanks goes out to:
- Omri B~M - Who actually asked me to write this thing.. :)
- RA-Man - for his help and that nifty icon..


ChangeLog:
=========

v0.1.0.0
--------
  - Initial release.


-------
Tornado ( tornado@goblineye.com ) & RA-Man ( raman@goblineye.com )