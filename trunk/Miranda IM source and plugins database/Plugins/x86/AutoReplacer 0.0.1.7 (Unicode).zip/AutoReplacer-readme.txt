AutoReplacer plugin
by Angelo Luiz Tartari

===========
NO WARRANTY
===========

This plugin is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. Should the program prove defective, you assume the cost of all necessary servicing, repair or correction.

===========
DESCRIPTION
===========

This plugin adds AutoCorrection and AutoText (AutoComplete) features to message window. It supports SRMM, tabSRMM, Scriver, nConvers and IRC plugin.

AutoCorrection is a feature that automatically detects and corrects misspellings of words, typos and incorrect capitalization. 

AutoComplete is a feature that lets you enter text into your message window simply by typing a few identifying characters. AutoText is the storage area for those text entries that AutoComplete uses for its automation process.

It supports SRMM, tabSRMM, Scriver, nConvers and IRC plugin.

==============
HOW TO INSTALL
==============

1) Close Miranda IM.
2) Find Miranda main directory (search for miranda32.exe).
3) Put AutoReplacer.dll into plugins directory.
4) Start Miranda IM.
5) Go to Options/Events/AutoCorrection and AutoText to configure some stuff.

See also: http://help.miranda-im.org/Installing_a_plugin

================
HOW TO UNINSTALL
================

Remove AutoReplacer.dll from plugin's folder.

================
HOW TO CONFIGURE
================

- Go to Options/Events/AutoCorrection and AutoText to configure some stuff.

==========
HOW TO USE
==========

AutoText : Any time you begin to type any of the phrases in AutoText list, AutoReplacer will suggest the entire phrase as soon as it knows for sure what you're trying to type. When the tooltip appears with the phrase, press ENTER or TAB to accept the AutoComplete.

=======
SUPPORT
=======

You understand that you use the AutoReplacer plugin at your own risk and that any assistance or support for your use of the AutoReplacer plugin is provided to you only as a convenience.

===================
ALPHA/BETA VERSIONS
===================

Alpha and beta versions are for testing purposes.
They are NOT recommended for daily usage.

You will find them at http://www.volumna.com.br/pessoal/angelo/

=========
MORE INFO
=========

Autocomplete:
http://en.wikipedia.org/wiki/Autocomplete

Autoreplace or AutoCorrect:
http://en.wikipedia.org/wiki/Autoreplace

======
AUTHOR
======

Name: Angelo Luiz Tartari

Email : corsario-br@users.sourceforge.net

You can send me messages in portuguese, english or italian.
Please read the faq file.