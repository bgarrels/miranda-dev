/*

'File Association Manager'-Plugin for
Miranda IM: the free IM client for Microsoft* Windows*

Copyright (C) 2005-2008 H. Herkenrath

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (AssocMgr-License.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef M_ASSOCMGR_H__
#define M_ASSOCMGR_H__

#if defined (_MSC_VER) && (_MSC_VER >= 1020)
 #pragma once
#endif

#if defined(_MSC_VER)
 #pragma warning(push)          /* save warning settings */
 #pragma warning(disable:4201)  /* nonstandard extension used : nameless struct/union */
#endif

/*
 File Association Manager v0.1.1.4
*/

#if !defined(ASSOCMGR_VER)
 #define ASSOCMGR_VER   0x0100
#endif

/* interface id */
#if !defined(MIID_ASSOCMGR)
 #define MIID_ASSOCMGR  {0xa05b56c0,0xcf7b,0x4389,{0xa1,0xe9,0xf1,0x3d,0xb9,0x36,0xe,0xf1}}
#endif
#if !defined(MIID_AUTORUN)
 #define MIID_AUTORUN  {0xeb0465e2,0xceee,0x11db,{0x83,0xef,0xc1,0xbf,0x55,0xd8,0x95,0x93}}
#endif

/******************************************************************/
/************************* ASSOC HANDLER **************************/
/******************************************************************/

/* The user-defined handler service specified in pszService for MS_ASSOCMGR_ADDNEWFILETYPE
and MS_ASSOCMGR_ADDNEWURLTYPE has the same specification for both situations.
 wParam=(WPARAM)(ASSOCHANDLERPARAM*)params (v0.1.1.1+, NULL earlier)
 lParam=(LPARAM)(char/WCHAR*)pszOpenCmd (depending on FTDF_UNICODE/UTDF_UNICODE set when registered)
 Note: You are allowed to modify this string in-place!
 Do not allocate a local copy to parse this string.
Return 0 on success, one of ASSOCERR_* otherwise.
*/
#if ASSOCMGR_VER>=0x0111
 typedef struct {
	int cbSize;
	const char *pszType;  // either pszFileExt or pszScheme
	LPARAM lParam;        // user-defined
 } ASSOCHANDLERPARAM;
#endif

/* error result codes */
#define ASSOCERR_SUCCESS         0 // file or URI/URL was processed successfully.
#define ASSOCERR_INVALIDFORMAT   1 // either invalid file contents or
                                   // invalid/unknown URI/URL specification. (only error prior to v0.1.1.1)
#if ASSOCMGR_VER>=0x0111
#define ASSOCERR_NOTSUPPORTED    2 // the file contents or URI specification is valid,
                                   // but can't be used as it is not supported
                                   // or not compatible
#define ASSOCERR_NOTENOUGHMEMORY 3 // memory limitations reached during string processing.
#define ASSOCERR_CANTPROCESS     4 // broader system call error occured while trying
                                   // to open the file or parse the URI/URL.
                                   // IMPORTANT!: GetLastError() will be called
                                   // afterwards to get details. always be sure something
                                   // has been set using SetLastError() when you return this.
#endif

/* suggested internal proto service constant for protocol devs */
#define PS_OPENASSOC  "/OpenAssoc"

/* callback procedure */
#if ASSOCMGR_VER>=0x0111
 typedef int (CALLBACK *ASSOCHANDLERPROC)(ASSOCHANDLERPARAM *param,char *pszOpenCmd);
 typedef int (CALLBACK *ASSOCHANDLERPROCW)(ASSOCHANDLERPARAM *param,WCHAR *pszOpenCmd);
 #if defined(_UNICODE)
  #define ASSOCHANDLERPROCT ASSOCHANDLERPROCW
 #else
  #define ASSOCHANDLERPROCT ASSOCHANDLERPROC
 #endif
#endif

/* utility which should be moved as service into m_netlib.h (MS_NETLIB_URLENCODE already exists) */
static __inline char *Netlib_UrlDecode(char *str)
{
	char *psz=str;
	for(;*psz;++psz)
		switch(*psz) {
			case '+':
				*psz=' ';
				break;
			case '%':
				if(!psz[1] || !psz[2]) break;
				MoveMemory(psz,&psz[1],2);
				psz[2]=0;
				*psz=(char)strtol(psz,NULL,16);
				MoveMemory(&psz[1],&psz[3],lstrlenA(&psz[3])+1);
				break;
		}
	return str;
}

/******************************************************************/
/************************* FILE TYPES *****************************/
/******************************************************************/

/* Add a new file type   v0.1.0.0+
Add a new file type to be registered with Windows.
You probably want to call this when the event
ME_SYSTEM_MODULESLOADED is fired.
 wParam=0
 lParam=(LPARAM)(FILETYPEDESC*)ftd
Returns 0 on success, nonzero otherwise.
*/
#define MS_ASSOCMGR_ADDNEWFILETYPE  "AssocMgr/AddNewFileType"

#define FILETYPEDESC_OLD_SIZE   36
typedef struct {
	int cbSize;                      // set to sizeof(FILETYPEDESC), in bytes
	union {
	   const char *pszDescription;   // description for options dialog and in registry.
	   const TCHAR *ptszDescription; // please use singular wording form here, automatically Translate()'d.
	   const WCHAR *pwszDescription;
	};
	HINSTANCE hInstance;             // instance of the calling module and where the icon
	                                 // resource is located.
	                                 // IMPORTANT!: always be sure you set this to your OWN hInstance even if
	                                 // you use the generic default icon

	UINT nIconResID;                 // resource id of an icon to use for the file type.
	                                 // this icon should contain icons of all sizes and color depths
	                                 // needed by Windows.
	                                 // set this to 0 to use the generic 'miranda file' icon
	                                 // provided by assocmgr.
	                                 // Note: This member is not a HICON for a reason.
	                                 // HICONs can't be used in in registry as Windows
	                                 // requires a resource identifier.
	union {
	   const char *pszService;       // service to call when a file is opened
	   #if ASSOCMGR_VER>=0x0111      // this service will be called with it's lParam set to
	    ASSOCHANDLERPROC pfnProc;    // the file name being opened including path.
	    ASSOCHANDLERPROCT ptfnProc;  // it can be assumed that the provided file name 
	    ASSOCHANDLERPROCW pwfnProc;  // is always the long path name.
	   #endif                        // return zero on success, one of ASSOCERR_* on error.
	};

	DWORD flags;                     // see FTDF_* flags below

	union {
	   const char *pszFileExt;       // file extension, e.g. ".ext"
	   const char *pszType;          // first character must be a dot, assumed to be all lower case.
	};                               // may only consist of ASCII characters.

	const char *pszMimeType;         // MIME type of the file, e.g. "application/x-icq"
	                                 // may only consist of ASCII characters.
	union {
	   const char *pszVerbDesc;      // description for the open verb e.g. "&Install".
	   const TCHAR *ptszVerbDesc;    // set this to NULL to use the default description "&Open".
	   const WCHAR *pwszVerbDesc;    // include an ampersand (&) character for a mnemonic key.
	};                               // automatically Translate()'d.

	#if ASSOCMGR_VER>=0x0111
	DWORD reserved;                  // reserved, ignored

	LPARAM lParam;                   // user-defined   v0.1.1.1+
	#endif
} FILETYPEDESC;

/* default icon resource 
 * (ensure you set hInstance to your own instance anyway) */
#if !defined(IDI_MIRANDAFILE) && !defined(RC_INVOKED)
#define IDI_MIRANDAFILE  0
#endif

#define FTDF_UNICODE          0x0001  // pszDescription and pszVerbDesc in struct are Unicode.
                                      // the specified pszService/pfnProc is called with Unicode parameters.

#define FTDF_DEFAULTDISABLED  0x0002  // type is not registered by default, it needs to be
                                      // enabled explicitly on the options page.
#if ASSOCMGR_VER>=0x0111
#define FTDF_KEEPUNTRANSLATED 0x0004  // do not automatically Translate() the pszDescription and   v0.1.1.1+
                                      // pszVerbDesc members

#define FTDF_PROC             0x0008  // use pfnProc instead of pszService member  v0.1.1.1+

#define FTDF_MULTITHREADED    0x0010  // the specified pszService/pfnProc is thread safe.  v0.1.1.1+
#endif                                // if not set it is always called in context of main thread
                                      // ensure your service is really thread-safe when you specify this.
                                      // do not make huge efforts in making the service thread-safe, just
                                      // specify this flag if your service is thread-safe anyway.
#if ASSOCMGR_VER>=0x0112
#define FTDF_NONEWCONFIRM     0x0020  // normally, when a type is registered for the first time, a dialog is   v0.1.1.2+
#endif                                // shown where one can confirm that the type should be registered with Windows.
                                      // if this flag is specified the type is registered silently.
                                      // useful in cases where user confirmation is not necessary,
                                      // e.g. file types private to Miranda such as installer packages or skin files
#if ASSOCMGR_VER>=0x0111
#define FTDF_BROWSERAUTOOPEN  0x0100  // tells the browser to download and open the file directly
#else                                 // without prompt (currently IE and Opera6+) - be careful!
#define FTDF_BROWSERAUTOOPEN  0x0004  // use only in conjunction with pszMimeType set.
#endif                                // this tells Windows that open can be safely invoked for
                                      // downloaded files.
                                      // Note that this flag may create a security risk with your plugin,
                                      // because downloaded files could contain malicious content.
                                      // you need to protect against such an exploit by protecting against
                                      // buffer overflows of malicious content etc.
#if ASSOCMGR_VER>=0x0111
#define FTDF_ISTEXT           0x0200  // tells Windows that this file can be opened
#else                                 // as a text file using e.g Notepad.
#define FTDF_ISTEXT           0x0008  // only has an effect on Windows XP and higher.
#endif

#if ASSOCMGR_VER>=0x0111
#define FTDF_ISSHORTCUT       0x0400  // file type behaves as shortcut, this means a   v0.1.1.0+
#elif ASSOCMGR_VER>=0x0110            // small overlay arrow is applied and the extension is never shown
#define FTDF_ISSHORTCUT       0x0010  // useful for example for .uin files of ICQ
#endif

#if defined(_UNICODE)
 #define FTDF_TCHAR     FTDF_UNICODE  // strings in struct are WCHAR*, specified service accepts WCHAR*
#else
 #define FTDF_TCHAR     0             // strings in struct are char*, specified service accepts char*
#endif

#if ASSOCMGR_VER>=0x0111
 #define FTDF_MASK             0x071F
#elif ASSOCMGR_VER>=0x0110
 #define FTDF_MASK             0x001F
#else
 #define FTDF_MASK             0x000F
#endif

/* Remove a file type   v0.1.0.0+
Remove a file type registered previously using
MS_ASSOCMGR_ADDNEWFILETYPE.
Currently you probably never want to call this.
This removes all settings in database and in registry
associated with the file type.
 wParam=0
 lParam=(LPARAM)(const char*)pszFileExt
Returns 0 on success, nonzero otherwise.
*/
#define MS_ASSOCMGR_REMOVEFILETYPE  "AssocMgr/RemoveFileType"

/* Open a given file   v0.1.1.1+
The file type of the specified file needs to be registered using
MS_ASSOCMGR_ADDNEWFILETYPE.
Useful for example if you would like to open a file 
using Miranda regardless of Windows settings. 
 wParam=(DWORD)flags (allowed are FTDF_UNICODE or FTDF_TCHAR)
 lParam=(LPARAM)(const char*)pszFilePath
Returns 0 on success, nonzero otherwise.
*/
#if ASSOCMGR_VER>=0x0111
#define MS_ASSOCMGR_INVOKEFILEHANDLER  "AssocMgr/InvokeFileHandler"
#endif

/******************************************************************/
/************************* URL/URI TYPES **************************/
/******************************************************************/

/* Add a new URL/URI protocol type   v0.1.0.0+
Add a new URL/URI type to be registered with Windows.
You probably want to call this when the event
ME_SYSTEM_MODULESLOADED is fired.
You can use this service to register any type of URI (URL or URN). 
 wParam=0
 lParam=(LPARAM)(URLTYPEDESC*)utd
Returns 0 on success, nonzero otherwise.
*/
#define MS_ASSOCMGR_ADDNEWURLTYPE  "AssocMgr/AddNewUrlType"

#define URLTYPEDESC_OLD_SIZE   28
typedef struct {
	int cbSize;                      // set to sizeof(URLTYPEDESC), in bytes
	union {
	   const char *pszDescription;   // description for options dialog and in registry.
	   const TCHAR *ptszDescription; // please use singular form here, automatically Translate()'d.
	   const WCHAR *pwszDescription;
	};
	HINSTANCE hInstance;             // instance of the calling module and where the icon
	                                 // resource is located.
	                                 // IMPORTANT: always be sure you set this to your OWN hInstance even if
	                                 // you use the generic default icon

	UINT nIconResID;                 // resource id of an icon to use for the url type.
	                                 // only a small one (16x16) is needed by Windows,
	                                 // e.g. proto icon as used in Miranda.
	                                 // set this to 0 to use the default miranda icon.
	                                 // Note: This member is not a HICON for a reason.
	                                 // HICONs can't be used in registry as Windows
	                                 // requires a resource identifier.
	union {
	   const char *pszService;       // service to call when a URL/URI is opened (can't be NULL)
	   #if ASSOCMGR_VER>=0x0111      // this service will be called with it's lParam set to
	    ASSOCHANDLERPROC pfnProc;    // the URL/URI being opened including the scheme.
	    ASSOCHANDLERPROCT ptfnProc;  // return zero on success, one of ASSOCERR_* on error.
	    ASSOCHANDLERPROCW pwfnProc;
	   #endif
	};

	DWORD flags;                     // see UTDF_* flags below

	union {
	   const char *pszScheme;        // protocol prefix, e.g. "http:"
	   const char *pszType;          // last character must be a colon, assumed to be all lower case.
	};                               // may only consist of ASCII characters.

	#if ASSOCMGR_VER>=0x0111
	LPARAM lParam;                   // user-defined   v0.1.1.1+
	#endif
} URLTYPEDESC;

/* default icon resource 
 * (ensure you set hInstance to your own instance anyway) */
#if !defined(IDI_MIRANDA) && !defined(RC_INVOKED)
#define IDI_MIRANDA  0
#endif

#define UTDF_UNICODE          0x0001  // pszDescription in struct is Unicode.
                                      // the specified pszService/pfnProc is called with Unicode parameters.

#define UTDF_DEFAULTDISABLED  0x0002  // type is not registered by default, it needs to be
                                      // enabled explicitly on the options page.
#if ASSOCMGR_VER>=0x0111
#define UTDF_KEEPUNTRANSLATED 0x0004  // do not automatically Translate() the pszDescription member   v0.1.1.1+

#define UTDF_PROC             0x0008  // use pfnProc instead of pszService   v0.1.1.1+

#define UTDF_MULTITHREADED    0x0010  // the specified pszService/pfnProc is thread safe.  v0.1.1.1+
#endif                                // if not set it is always called in context of main thread
                                      // ensure your service is really thread-safe when you specify this.
                                      // do not make huge efforts in making the service thread-safe, just
                                      // specify this flag if your service is thread-safe anyway.
#if ASSOCMGR_VER>=0x0112
#define UTDF_NONEWCONFIRM     0x0020  // normally, when a type is registered for the first time, a dialog is   v0.1.1.2+
#endif                                // shown where one can confirm that the type should be registered with Windows.
                                      // if this flag is specified the type is registered silently.
                                      // useful in cases where user confirmation is not necessary.
                                      // e.g. protocols private to Miranda such as installer package links

#if defined(_UNICODE)
 #define UTDF_TCHAR     UTDF_UNICODE  // strings in struct are WCHAR*, service accepts WCHAR*
#else
 #define UTDF_TCHAR     0             // strings in struct are char*, service accepts char*
#endif

#if ASSOCMGR_VER>=0x0111
 #define UTDF_MASK            0x001F
#else
 #define UTDF_MASK            0x0003
#endif

/* Remove an URL/URI protocol type   v0.1.0.0+
Remove an URL/URI registered previously using
MS_ASSOCMGR_ADDNEWURLTYPE.
Currently you probably never want to call this.
This removes all settings in database and in registry
associated with the URL/URI type.
 wParam=0
 lParam=(LPARAM)(const char*)pszScheme
Returns 0 on success, nonzero otherwise.
*/
#define MS_ASSOCMGR_REMOVEURLTYPE  "AssocMgr/RemoveUrlType"

/* Open a given URL/URI   v0.1.1.1+
The scheme of the specified URL/URI needs to be registered using
MS_ASSOCMGR_ADDNEWURLTYPE.
Useful for example if you would like to open an URL/URI 
using Miranda regardless of Windows settings. 
 wParam=(DWORD)flags (allowed are UTDF_UNICODE or UTDF_TCHAR)
 lParam=(LPARAM)(const char*)pszUrl
Returns 0 on success, nonzero otherwise.
*/
#if ASSOCMGR_VER>=0x0111
#define MS_ASSOCMGR_INVOKEURLHANDLER  "AssocMgr/InvokeUrlHandler"
#endif

/* URI term is more modern and broader */
#define URITYPEDESC_OLD_SIZE URLTYPEDESC_OLD_SIZE
#define URITYPEDESC URLTYPEDESC
#define MS_ASSOCMGR_ADDNEWURITYPE MS_ASSOCMGR_ADDNEWURLTYPE
#define MS_ASSOCMGR_REMOVEURITYPE MS_ASSOCMGR_REMOVEURLTYPE
#define MS_ASSOCMGR_INVOKEURIHANDLER MS_ASSOCMGR_INVOKEURLHANDLER

/* deprecated in favor of direct service calls, they do not help much */
#if ASSOCMGR_VER<=0x0111 && !defined(ASSOCMGR_NOHELPERFUNCTIONS)
__inline static int AssocMgr_AddNewFileTypeT(const char *ext,const char *mime,const TCHAR *desc,const TCHAR *verb,HINSTANCE inst,UINT icon,const char *service,DWORD flags)
{
	FILETYPEDESC ftd;
	ftd.cbSize=sizeof(FILETYPEDESC);
	ftd.pszFileExt=ext;
	ftd.pszMimeType=mime;
	ftd.pwszDescription=desc;
	ftd.pwszVerbDesc=verb;
	ftd.hInstance=inst;
	ftd.nIconResID=icon;
	ftd.pszService=service;
	ftd.flags=flags|FTDF_TCHAR;
	return CallService(MS_ASSOCMGR_ADDNEWFILETYPE,0,(LPARAM)&ftd);
}
static int __inline AssocMgr_AddNewUrlType(const char *scheme,const char *desc,HINSTANCE inst,UINT icon,const char *service,DWORD flags)
{
	URLTYPEDESC utd;
	utd.cbSize=sizeof(URLTYPEDESC);
	utd.pszScheme=scheme;
	utd.pszDescription=desc;
	utd.hInstance=inst;
	utd.nIconResID=icon;
	utd.pszService=service;
	utd.flags=flags&~UTDF_UNICODE;
	return CallService(MS_ASSOCMGR_ADDNEWURLTYPE,0,(LPARAM)&utd);
}
#endif

#if defined(_MSC_VER)
 #pragma warning(pop)  /* restore warning settings */
#endif

#if !defined(ASSOCMGR_NOSETTINGS)
 #define SETTING_ONLYWHILERUNNING_DEFAULT  0
#endif

#endif // M_ASSOCMGR_H