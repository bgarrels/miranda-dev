	
	SMSBox jest wtyczk� do komunikatora Miranda IM, 
	kt�ra umo�liwia wysy�anie SMS�w do Polskich operator�w sieci kom�rkowych.
	
	Dodatkow� cech� wtyczki jest mo�liwo�� wysy�ania powiadomienia SMSem 
	gdy jaki� kontakt z listy napisze do nas wiadomo��.


Licencja: Freeware (do u�ytku domowego)
Copyright (C) 2007-2010 �ukasz G�siorek
Wszystkie Prawa Zastrze�one


Dost�pne cechy wtyczki:

- Obs�uga bramek:
	Plus Standardowa
	Plus Bramka SMS (dawniej MiastoPlusa)
	Plus WWW/SMS (https://ssl.plusgsm.pl/smsgate/)
	Era Omnix Sponsorowana	
	Orange Standardowa
	Orange Multi Box

- Wysy�anie powiadomienia gdy kto� napisa� do nas wiadomo�� na dowolny protok�
- Sprawdzanie dost�pnego limitu SMS�w w bramkach kt�re taki posiadaj�
- Mo�liwo�� zapisywania kontakt�w do pliku XML
- Zapisywanie wys�anych sms�w do archiwum (plik XML)


:: F A Q ::

Q:	Jak otworzy� okno SMSBox ?
R:	Okno SMSBox mo�na otworzy� z menu g��wnego Mirandy lub poprzez globalnego HotKey'a, 
	domy�le jest to Ctrl+Alt+S. Globalny HotKey dost�pny jest tylko w wersjach 0.8+ Mirandy.


Q:	Jak przypisa� ka�dej bramce login i has�o ?
A:	Aby przypisa� bramce login i has�o nale�y przej�� do opcji, wybra� odpowiedni� bramk� z rozwijanego menu,
	wpisa� login i has�o, klikn�� przycisk 'Zastosuj' lub 'OK'. 
	Dla ka�dej bramki kt�rej chcesz ustawi� login/has�o musisz powt�rzy� te trzy kroki.	

Q:	Jak powinien by� wpisany login dla bramki Era Omnix Sponsorowana ?
R:	Login do bramki Ery musi by� wpisany w formacie: 48123456789 tak jak na stronie Ery


Q:	Co dodaje zaznaczenie opcji 'Pytaj czy zapisa� nieznany numer' ?
R:	Gdy ta opcja jest zaznaczona, to przed zamkni�ciem okna SMSBox, 	
	sprawdzany jest wpisany numer telefonu (tylko gdy jest wpisany numer 9 cyfrowy), 
	i je�li ten numer nie zostanie znaleziony w pliku, wyskoczy okno z pytaniem
	czy chcesz go zapisa� przed zamkni�ciem okna SMSBox.


Q:	Jak sprawdzi� ilo�� dost�pnych SMS�w ?
A:	Nale�y wype�ni� w opcjach has�o i login dla bramki, w oknie g��wnym SMSBox wybra� bramk� z menu rozwijanego, 
	i klikn�� przycisk 'Limit', po udanym odczytaniu limitu, pojawi si� on na przycisku.


Q:	Jak doda� / usun�� / edytowa� kontakt w oknie kontakt�w ?
A:	Dodawa�, usuwa� lub edytowa� kontakty mo�na klikaj�c na przyciski w oknie kontakt�w, 
	lub za pomoc� klawiszy akcelerator�w Alt+D, Alt-E, Alt+U lub klikaj�c na kontakt
	prawym przyciskiem myszy i wybranie odpowiedniej pozycji z menu.
	
	
Q:	Przycisk 'Wy�lij SMS' jest nieaktywny, dlaczego ?
A:	Przycisk b�dzie aktywny dopiero wtedy, gdy pole wiadomo�� i podpis b�d� wype�nione i w polu 'Telefon' 
	b�dzie wpisany poprany numer telefonu, czyli je�li b�d� to liczby musi by� ich 9, 
	a je�li b�dzie to nazwa kontaktu, to ta nazwa musi by� znaleziona w pliku kontakt�w,
	w przeciwnym wypadku przycisk nie b�dzie uaktywniony.
	
	
Q:	Jak ustawia� �cie�ki do plik�w ?
A:	Je�li pliki (kontakt�w lub archiwum) nie istniej�, nale�y klikn�� na przycisk 'Utw�rz',
    i utworzy� plik w wybranej lokalizacji. Je�li pliki ju� istniej�, nale�y klikn��
    na przycisk '...' i wybra� lokalizacj� danego pliku.

	
Q:	Czy rozszerzenia plik�w s� wa�ne ? trzeba je wpisywa� ?
A:	Tak s� WA�NE. �cie�ki do pliku kontaktow i pliku archiwum musz� by� zapisane z rozszerzeniem .xml,
	je�li tak nie b�dzie to pojawi si� b��d.


_______________________________________


Changelog;

v0.1.0.8 18/06/2010
- w kontrolce do wpisywania numeru telefonu mo�na u�ywa� klawiszy skr�t�w: CTRL+C (copy), CTRL+V (paste), CTRL+X (cut), CTRL+A (select all)
- tylko wersja z szyfrownaie dost�pna

v0.1.0.7
- naprawione wysy�anie sms�w do sieci plus gsm
- wersja ta zosta�a wydana dzi�ki wsparciu finansowemu od Bartosz Rojek (Dzi�ki!)

v0.1.0.6 beta!
- naprawione wysy�anie SMS-�w do sieci Plus GSM
- poprawiono zmiane ikony powiadomienia na pasku narzedzi (clist_modern.dll)

v0.1.0.5 beta! 03/06/2009
- poprawione odczytywanie numeru telefonu kontaktu (pozycja 'SMS' w menu kontekstowym powinna teraz by� dost�pna)
- opcje wtyczki przeniesione do grupy "Network" (Sieci)

v0.1.0.4 beta!
- poprawki w interfejsie u�ytkownika w opcjach
- poprawki bramki Orange MultiBox
- naprawiony b��d przy sprawdzaniu limitu w przypadku braku wtyczki PopUp Plus

v0.1.0.3 beta! 19/01/2009
- poprawki dla bramki orange standardowa (sms.orange.pl)

v0.1.0.2 beta! 24/09/2008
- przycisk 'Wy�lij SMS' nie jest ju� blokowany
- dla bramki Orange MultiBox podpis nie jest wymagany
- poprawka przy zamykaniu okna po wys�aniu sms-a
- mo�liwo�� wy��czania powiadomienia sms przy uruchamianiu mirandy 
(nale�y doda� wpis "NotifyDisableStartup" typu BYTE z warto�ci� 1 do bazy danych do modu�u SMSBox)

v0.1.0.1 beta! 26/08/2008
+ mo�liwo�� importowania kontakt�w z numerami telefon�w z listy do pliku kontakt�w
- poprawka w usuwaniu polskich znak�w z wiadomo�ci sms
- naprawione wykrywanie bramki
- naprawiony b��d z zamykaniem okna tokena i dodawania / edycji kontaktu
- poprawka dla opcji 'Wstaw podpis na poczatku wiadomosci'

v0.1.0.0 beta! 13/08/2008
+ podpowiadanie nazw kontakt�w w polu wpisywania numeru telefonu (co� jak Google Suggest)
+ komunikat potwierdzaj�cy czy wys�a� smsa (opcja)
+ przyciski w opcjach do tworzenia \ zaznaczania plik�w kontakt�w i archiwum
+ mo�liwo�� ustawienia pliku d�wi�kowego do powiadomienia o wys�anym smsie
- przepisana du�a cz�� wtyczki

v0.0.2.0 RC 3
+ mo�liwo�� ustawienia powiadomienia d�wi�kiem dla wys�anej wiadomo�ci 
+ informacje o wersji pliku
+ dodany prefiks 784 dla Ery
- naprawione wykrywanie plik�w
- naprawione wykrywanie bramki
- zamykanie popup'a prawym przyciskiem myszy
- natychmiastowa aktualizacja listy telefon�w w polu 'Telefon' przy jakiejkolwiek modyfikacji pliku kontakt�w (tj. dodanie / edycja / usuwanie kontaktu)
- naprawiony b��d powoduj�cy crash mirandy w sytuacji kiedy powiadomienie sms jest wysy�ane a opcje nie s� popranie wype�nione

v0.0.2.0 RC 2
+ dodany prefiks '669' do sieci Plus
- zmiana nazwy bramki z 'Plus Miasto Plusa' na 'Plus Bramka SMS'
- poprawione wykrywanie plik�w
- naprawiona bramka Plus WWW/SMS
 
v0.0.2.0 RC 1
+ opcja: zapami�tanie ostatnio wpisanego numeru tel. 
+ opcja: wstawianie podpisu na ko�cu / pocz�tku wiadomo�ci, domy�lnie jest na pocz�tku (MiastoPlusa / Era )
+ nowa zmienna '%s' zwraca opis stanu kontaktu kt�ry napisa� wiadomo��
+ zapisanie sms�w do archiwum
+ dodane przyciski do Toolbara (Modern Contact List)
- wtyczka w wi�kszo�ci zosta�a przepisana od nowa
- przycisk 'LogIn' usuni�ty
- miranda nie jest ju� blokowana przy wysy�aniu smsa
- w pole wiadomo�� na zak�adce 'Powiadomienia SMS' mo�na wpisywa� sw�j tekst, wraz z zmiennymi
- dodane nowe prefiksy plusa: 721, 722, 723, 725, 726, 781, 782, 783, 785
- globalny hotkey przeniesiony do nowego modu�u w Mirandzie od wersji 0.8 i tylko od tej wersji dzia�a; pozosta�e hotkeye usuni�te, dzia�aj� tylko klawisze akcelerator�w tj. alt+[podkre�lony klawisz]
- du�o innych zmian i poprawek

v0.0.1.9 beta
+ ikona w oknie rozmowy dla w�/wy� powiadomienia dla kontaktu (dzia�a tylko w Scriver)
- zmienione ikony i dodane do iconlib (mo�na sobie zmienia�, z wyj�tkiem ikony w oknie rozmowy)
- uaktywnienie pola z podpisem dla orange multibox (podpis domy�lnie dodawany na ko�cu wiadomo�ci, wi�cej w README)
- podpis dla EraOmnix pobierany z ustawie�, dodawany na ko�cu wiadomo�ci ( wi�cej w README )
- zmieniony adres serwera dla wtyczki Updater
- zmienione pole do wpisywania numeru telefonu (na ComboBox), mo�na od teraz wpisywa� tak�e nazw� kontaktu do kt�rego wysy�amy smsa, numer telefonu pojawi si� na etykiecie wiadomo�ci np: "Wiadomo�� pod numer: 123456789"
- pole do wpisywania telefonu domy�lnie zawiera wszystkie kontakty kt�re s� zapisane w pliku (oczywi�cie, mo�na w ten spos�b wybiera� kontakty. do kt�rych ma by� wys�any sms)
- hotkey: ALT+ENTER w oknie kontakt�w, wybiera zaznaczony kontakt, zamyka okno kontakt�w, wstawia numer telefonu w odpowiednie pole
- troch� innych zmian w kodzie

v0.0.1.8 beta!
+ opcja - ustawianie / usuwanie powiadomienia wszystkim kontaktom naraz
- poprawione dodawanie nieznanego kontaktu
- ma�e zmiany w orange standardowa (inf. o dostarczeniu smsa)
- drugi plik z funkcjami "Runtime Library" w kompilowanymi w wtyczk�

v0.0.1.7 beta! 
+ przyciski (dodaj / edytuj / usu� ) w oknie kontakt�w 
+ mo�liwo�� wysy�ania MMS�w ( tylko dla sieci Era )
+ globalny hotkey ctrl+shift+s do otwierania okna SMSBox
+ hotkey'e w oknie kontakt�w; ctrl+a = dodawanie kontaktu, ctrl+e = edycja kontaktu, delete = usuwanie kontaktu
- fixed: odczytywanie ilo�ci dost�pnych sms�w dla Orange MultiBox
- fixed: przypisywanie i odczytywanie bramki ustawionej dla kontaktu
- fixed: pobieranie podpis�w dla kontakt�w z przypisan� inn� bramk� ni� domy�lna
- fixed: usuwanie polskich znak�w
- fixed: sortowanie naprawione
- fixed: pobieranie numeru kontaktu
- inne zmiany, poprawki


v0.0.1.6 beta!
+ dodana obs�uga wtyczki popup
      popup wy�wietlany jest:
		- z potwierdzeniem kiedy sms zosta� wys�any + pozosta�� ilo�ci� dost�pnych sms�w
		- przy sprawdzaniu limitu sms�w
		- z informacja je�li wyst�pi� b��d przy wysy�aniu sms'a z powiadomieniem
+ wsparcie dla wtyczki updater
+ przycisk w oknie g��wnym SMSBox do sprawdzania ilo�ci dost�pnych punkt�w / sms�w (w opcjach po klikni�ciu przycisku "LogIn" w komunikacie ju� nie pojawia si� info o ilo�ci dost�pnych sms�w)
+ mo�liwo�� przypisania bramki dla kontakt�w zapisywanych do pliku
+ szyfrowanie hase�
- fixed: mo�na ju� klika� 2x na kontakt mPhantomUser
- fixed: podpis nie jest wymagany aby wysy�a� smsy z bramki Orange MultiBox
- fixed: menu kontaktu "Wy�lij SMS..." jest widoczne tylko wtedy, gdy kontakt ma przypisany numer telefonu
- fixed: nick do wysy�ania powiadomienia jest pobierany z listy kontakt�w - taki jaki jest widoczny na li�cie
- fixed: tylko jedna kopia okna SMSBox mo�e by� teraz otwarta
- inne poprawki


v0.0.1.5 beta!
+ dodana bramka Orange MultiBox
+ dodana bramka Plus WWW/SMS (p�atna) https://ssl.plusgsm.pl/smsgate/
+ przycisk w opcjach do sprawdzenie poprawno�ci wpisanych danych (login i has�o ) poprzez zalogowanie do wybranej bramki
+ przycisk do prze�adowania tokena (dla Orange Standardowa)
- fixed: focus w polu wpisywania tokena
- fixed: wy�wietlanie pozycji w menu kontaktu
- fixed: zapis opcji do bazy danych
- du�o zmian w kodzie


v0.0.1.4 beta!
+ wsparcie dla mPhantomUser
+ dodana bramka Orange
+ (opcja) je�li podany numer telefonu nie zostanie znaleziony w pliku, pyta si� czy zapisa�
+ dodano mo�liwo�� edycji zapisanych kontakt�w
+ dodano mo�liwo�� sortowania kontakt�w (poprze klikniecie na kolumnie "nazwa" lub "telefon")
+ dodana opcja pozwalaj�ca wys�a� raport na sms / www (tylko dla MiastaPlus'a!!)
- pozycja w menu kontaktu "W��cz powiadomienie na SMS" jest dost�pna tylko wtedy, gdy globalne powiadomienie (w menu g��wnym) jest w��czone
- fixed: crash mirandy przy otwieraniu okna kontakt�w gdy plik .xml nie istnieje
- fixed: auto-rozpoznawanie numeru


v0.0.1.3 beta!
+ wywo�anie okna SMSBox z menu kontaktu i pobranie numeru tel. kontaktu z bazy
+ zak�adki w opcjach
- przepisany kod odpowiedzialny za wysy�anie smsa
- poprawiony b��d z �cie�k� do pliku z kontaktami
- inne poprawki


v0.0.1.2 beta!
+ mo�liwo�� ustawienia powiadomienia dla pojedynczego kontaktu
+ ustawienie maksymalnej ilo�ci znak�w do wys�ania
- poprawione kilka b��d�w 


v0.0.1.1 beta! | 01.05.2007
+ bramka EraOmnix Sponsorowana
- teraz sms z powiadomieniem, dzia�a tylko jak kto� napisze (nie trzeba ju� wy��cza� tej opcji jak chcemy odpowiedzie�)
- poprawione zliczanie znak�w / sms�w dla danej bramki 


v0.0.1.0 beta! | 30.04.2007
- First Release


_______________________________________

Podzi�kowania za wsparcie finansowe dla:
- Bartosz Rojek

_______________________________________

W programie wykorzystano:

Ikony autorstwa Mark James
http://www.famfamfam.com/lab/icons/silk/


Bibliotek� TinyXml:
http://sourceforge.net/projects/tinyxml
