History Log plugin
---------------------

CAUTION: THIS IS ALPHA QUALITY SOFTWARE. USE AT YOUR OWN RISK.

This is a plugin that logs to a text file all messages exchanged with contact or in a group chat. The text file is encoded in UTF-8.

The messages filename pattern accepts the following vars: (also, it support variables plugin)
  %contact%
  %contact_id%
  %protocol%
  %group%
  %year%
  %month%
  %month_name%
  %day%

The group chat filename pattern accepts the following vars: (also, it support variables plugin)
  %session%
  %protocol%
  %year%
  %month%
  %month_name%
  %day%

It also register itself with meSpeak and allows reading of messages (chat, url, fileand group chat events).

This plugin requires at least Miranda 0.7 and needs History Events to work.

To report bugs/make suggestions, go to the forum thread: http://forums.miranda-im.org/showthread.php?t=18488


TODO
-----
- In group chat, disconnects and renames are not logged

