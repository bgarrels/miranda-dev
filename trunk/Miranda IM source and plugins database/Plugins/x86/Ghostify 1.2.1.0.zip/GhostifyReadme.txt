-------------------------------

  Ghostify Plugin v 1.2.1.0
  by Karl Einholz

-------------------------------


This plugin makes the Miranda IM contact list unclickable while it is inactive,
allowing you to klick through the contact list on whatever is below. 



REQUIREMENTS

- Windows 2000 or better
- Miranda IM



INSTALATION

1) Open the Miranda main directory
2) Put Ghostify.dll into the plugins directory. (You may need to stop Miranda
   if you have an old Ghostify plugin running)
3) (Re)Start Miranda IM.



HOW TO USE

******************************************************************************
NOTE: This plugin will not work unless you have the contact list transparency
      ENABLED. (You can set whatever opacity you like.)
******************************************************************************

When Ghostify is active, you will be able to klick through the contact list.

If you want to klick on the contact list, you can activate it by clicking on 
the tray icon or hover your mouse over the contact list for a while.

Check out the Ghostify options in the options dialogs' contact list tree. 



HINTS

- Enable the "Allways on top" option in the Contact List / Window options page

- Set a (fairly) different inactive and active contact list opacity. The lower
  the inactive opacity is, the better you will see what you klick.

- The show/hide hotkey (on the hotkeys page) unghostifies the contact list

- Use the Test Field to tweak the settings to your liking



KNOWN PROBLEMS

- Mouse Hover unghostifies Window even if it is beneath another window



WHAT'S NEW

1.2.1.0

- Bugfix: Changing the window title while using a unicode build doesn't 
  clear unicode chars to '?'



FEATURES PLANED

- multiple window support through the API
- release of the source code under the GNU GPL



AUTHOR

Karl Einholz
TODO: write some lines about how 1337 I am

Email: 
 ghostify@fozi.de

Plugin homepage: 
 http://www.miranda-im.org/download/details.php?action=viewfile&id=1557



HISTORY

1.2.1.0 (December 19 2005)

- Bugfix: Changing the window title while using a unicode build doesn't 
  clear unicode chars to '?'

1.2.0.0  (August 30 2005)

- Doesn't ghostify docked contact list
- Miranda 0.4 compatible sound support
- A new alpha Ghostify API

1.1.1.0  (April 8 2005)

- Bugfix: Access Violation crash at exit

1.1.0.0. (January 18 2005)

- supports sound

1.0.0.0  (January 12 2005)

- whole new hover detection algorithm, allowing to track mouse movement and
  mouse clicks and to unghostify only if the mouse holds still for a while
- ghostify can be delayed
- right mouse button can be passed to Miranda
- new options dialog with a test field
- bug fix: minimized start up bug solved
- other: Options are not expert only any more
- a lot of new strings to translate

0.2.1.0 (November 5 2004)

- Miranda now loads the plugin in version 3.4.3

0.2.0.0 (November 1 2004)

- Options dialog workflow changed (Options will only be applied on pressing 
  "Apply"
- Ghostify goes off/cannot be turned on if the contact list transparency is off
- Workaround for the tray icon hiding bug
- Performance bug solved
- Compatibility workaround for the Snapping Windows plugin

0.1.0.0 (October 25 2004)

- first public release



COPYRIGHT AND LICENCE

Copyright (C) 2005 Karl Einholz


This program is free software; You may redistribute it as long 
as you don't modify any part of the package, including the 
binaries, this readme file and any other files provided. The 
package should at least contain the plugin file and this readme.

Any commercial redistribution, with or without fees, is prohibited
unless I explicitly allow you to do that.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

