/* 
  Ghostify API 
  (c) Karl Einholz

  Notes:

  - This is the first Ghostify API Version. Use it with caution.
  

  History:
  1.2.0.0 first Ghostify with an API

  */



/* Ghostify/GetVersion service

Returns the Ghostify plugin version.

	wParam = (WPARAM) format

with format beeing one of:
    GHVER_VERSION:	Returns a DOWRD containing the major version and the subversion
    GHVER_PATCH:	Returns a DWORD containing the patch version and the build version.

Returns CALLSERVICE_NOTFOUND if the plugin is not installed, or a DWORD containing two
version numbers in the high and the low WORD.

Use this service with GHVER_VERSION to detect the API level. Each change in the API 
changes at least the subversion.
*/
#define MS_GHOSTIFY_GETVERSION	"Ghostify/GetVersion"
#define GHVER_VERSION 0
#define GHVER_PATCH 1



/* Ghostify/GhostifyWindow service

Ghostifies a Window, unless:
- ghostify is disabled
- the window is already ghostified
- the window is locked
- the window is not visible

NOTE: Currently only the main contact list window is supported.

	wParam = (WPARAM)(HANDLE) hReserved = NULL
*/
#define MS_GHOSTIFY_GHOSTIFYWND  "Ghostify/GhostifyWindow"



/* Ghostify/UnGhostifyWindow service

Unghostifies a Window, if it is ghostified. 

NOTE: Currently only the main contact list window is supported.

	wParam = (WPARAM)(HANDLE) hReserved = NULL
*/
#define MS_GHOSTIFY_UNGHOSTIFYWND "Ghostify/UnGhostifyWindow"



/* Ghostify/LockWindow service

Increments the locks count of a Window. While the lock count of a window is not zero,
the Window cannot ba ghostified.

If the Lock count was zero and the window is currently ghostified, UnghostifyWindow is called.

Use this service if you open another Window and you want to make sure that the contact list stays unghostified.

  wParam = (WPARAM)(HANDLE) hReserved = NULL

Returns the new lock count
*/
#define MS_GHOSTIFY_LOCKWND "Ghostify/LockWindow"



/* Ghostify/UnlockWindow service

Decrements the locks count of a Window. While the lock count of a window is not zero,
the Window cannot be ghostified.

If the lock count becomes zero and the window ist not active and the mouse pointer is not hovering
over the window, the window is ghostified.

  wParam = (WPARAM)(HANDLE) hReserved = NULL

Returns the new lock count
*/
#define MS_GHOSTIFY_UNLOCKWND "Ghostify/UnlockWindow"



/* things that MAY come:  AddWindow, Window Groups, enumarate Windows */
