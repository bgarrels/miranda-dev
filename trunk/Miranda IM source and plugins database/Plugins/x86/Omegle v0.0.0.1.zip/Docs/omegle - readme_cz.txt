---------------------------
| Omegle Protocol 0.0.0.1 |
|        (10.4.2010)      |
---------------------------

Autor: Robyer
  E-mail: robyer@seznam.cz
  Jabber: robyer@jabbim.cz
  ICQ: 372317536
  Web: http://robyer.info
 
SVN: http://code.google.com/p/robyer/

!!!! Vy�adov�na Miranda 0.9.14 nebo nov�j��! Mirandu 0.10.0#1 NEPOU��VAT !!!!

--------------------------------
            TODO
--------------------------------
 - V�e

--------------------------------
       Historie verz�
--------------------------------
0.0.0.1 - 10.4.2011
 + Prvn� ve�ejn� verze