---------------------------
| Omegle Protocol 0.0.0.1 |
|        (10.4.2010)      |
---------------------------

Autor: Robyer
  E-mail: robyer@seznam.cz
  Jabber: robyer@jabbim.cz
  ICQ: 372317536
  Web: http://robyer.info
 
SVN: http://code.google.com/p/robyer/

!!!! Required Miranda 0.9.14 or newer! Miranda 0.10.0#1 DONT USE !!!!

--------------------------------
						TODO
--------------------------------
 - Everything

--------------------------------
       Version history
--------------------------------
0.0.0.1 - 10.4.2011
 * First public version