Whiteboard plugin
  by Chervov Dmitry aka Deathdemon

This plugin allows you with your friend to draw something together. It sends all the changes from both sides almost in real-time. Just click "Whiteboard" in the contact menu and start drawing, your friend will see it.

Whiteboard must be installed on both sides, and also DataAsMessage plugin is required. Please note, Whiteboard and DataAsMessage are in beta development stage yet.


Changelog
=========

v0.1.0.2 (build 350; Oct 6, 2007)
--------
 - made the plugin work on Win9x somehow (though brush movements are not so accurate as on Win ME/2000/XP/2003 systems due to techical limitations of Win9x)
 - added possibility to save/load contents of a whiteboard window (currently it loads only locally, i.e. both you and your friend should load a file with the same contents to continue drawing)
 - added unicode support
 - added Miranda 0.8 support

v0.1.0.1 (build 318; May 9, 2006)
--------
 - First public release
