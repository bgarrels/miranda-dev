BClist plugin
--------------------

This is a contact list for blind folks. It uses a list control to show all contacts, so screen readers can "read" the clist to the user.

Based on classic contact list.

This plugin needs Miranda 0.8.0.9

To report bugs/make suggestions, go to the forum thread: http://forums.miranda-im.org/showthread.php?t=11778