PHOTON Readme
==========================================================================================================
Photon discussion @ http://forums.miranda-im.org/showthread.php?t=14411
Bugs, ideas, suggestions @ deml.tomas@seznam.cz

Homepage @ http://virtuosity.aspweb.cz/Miranda/Plugins/Photon