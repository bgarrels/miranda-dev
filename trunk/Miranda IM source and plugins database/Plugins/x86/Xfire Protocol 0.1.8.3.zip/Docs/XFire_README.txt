More informations and help:

English Miranda forum:
http://forums.miranda-im.org/showthread.php?17607-Xfire-Protocol-Discussion

German Miranda forum:
http://forum.miranda-im.de/index.php?topic=7055.0

Latest version:
http://addons.miranda-im.org/details.php?action=viewfile&id=3701