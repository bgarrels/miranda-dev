/* 
 * @author: Longedok, http://juick.com/Longedok
 *
 * @modified by: xa0c, http://xa0c.net
 *
 */


 var inputMsgId = 'jText';
 var showAvatars = true;
 var userAvatars = new Array();

 // �������� �� ������! ������������!
 function jInit()
 {
   var haveTree = typeof fixedMenu != 'undefined'; 
     
   var changed = false;

   if (haveTree && !treeContent)
      treeContent = new Array();
      
   var el = document.getElementById(inputMsgId);
   while(el)
   {
      var node = jMake(haveTree, el);
      if (node)
      {
         changed = true;
         var found = false;
         var nodeInfo = node.nodeKey.split('_');
         var nodekey = nodeInfo[0];
         
         for(var i=0, iCount=treeContent.length; i<iCount; i++)
         {
           if (treeContent[i].nodeKey == nodekey)
           {
             if (treeContent[i].nodes.length == 0)
             {
               var postNode = new Object();
               postNode.nodeAuthor = treeContent[i].nodeAuthor;
               postNode.nodeKey = treeContent[i].nodeKey;   
               postNode.random = treeContent[i].random;            
               treeContent[i].nodes.push(postNode);
             }
             found = true;
             treeContent[i].nodes.push(node);
             break;
           }
         }
         
         if (!found)
         {
            var rootNode = new Object();
            rootNode.expanded = false;
            rootNode.nodeKey = nodekey;
            rootNode.nodeTitle = '#' + nodekey;
            rootNode.nodeAuthor = !node.commentID ? node.nodeAuthor : '';
            rootNode.description = !node.commentID ? node.description : '';  
            rootNode.random = node.random;
            rootNode.nodes = new Array();
            if (node.commentID)
            {
              rootNode.nodes.push(node);
            }
            treeContent.push(rootNode);         
         }

      }
   	el = document.getElementById(inputMsgId);
   }
   
   if (haveTree)
   {
      if (!fixedMenu.ready)
      {
        fixedMenu.init();
      }
      
      if (changed)
      {
        treeContent.sort(ASCSort);
        reloadMenu();
      }
   }
   
   if (showAvatars)
   {
      var result = new Array()
      for(var i=0, iCount=userAvatars.length; i<iCount; i++)
      {
        result.push(userAvatars[i].Author);
      }
   }
   return result.join('#');
 }

 /*
 * @name juickonize
 * 
 * @description ��������� �����-���� � ���� � id = inputMsgId 
 *
 */

function jMake(haveTree, el)
{
    if (el == null || el == undefined)
      return false;
      
    // regexp ��� ������� ���������. 
    // ������ ������:
    // ��� ������ #123456/1 � $1 - ����� #123456/1, � $2 - #123456, $3 - 123456
    var msgNumRegEx = /\B((#(\d+[^/<]))(\/\d+)?)\b/gm;

    //������� � ������� �� ����
    //var lastMsgNumRegEx = /([^>]+@[a-zA-Z0-9-.@_|]+[: \*a-zA-Z0-9_]+).+\B((#(\d+))((\/){1}(\d+))?)([ \t]+\<\a[^<]*?<\/a>[ \t]*)$/im;

    //������� � ������ � ������ �����
    //var lastMsgNumRegEx = /(@[a-zA-Z0-9-.@_]+[^<]+).+\B((#(\d+))((\/){1}(\d+))?)([ \t]+\<\a[^<]*?<\/a>[ \t]*)$/im;
    var lastMsgNumRegEx = /(\B([^>]*)(@[a-zA-Z0-9-.@_]+):([^<]*).+\B((#(\d+))(\/\d+)?)([ \t]+\<\a[^<]*?<\/a>[ \t]*))$/im;
    
    //������� "������ ���"
    //var lastMsgNumRegEx = /(@[a-zA-Z0-9-.@_]+):.+\B((#(\d+))((\/){1}(\d+))?)([ \t]+\<\a[^<]*?<\/a>[ \t]*)$/im;
    var nickRegEx = /\B(@[a-zA-Z0-9-.@_]+)\b/gm;

    var result = false;
    var rand = Math.floor(Math.random() * 9001) + 1000;
    var avaRand = Math.floor(Math.random() * 90001) + 10000;
    if (haveTree)
    {
      result = el.innerHTML;
      var newID = '';

      if ((numArray = lastMsgNumRegEx.exec(result)) != null)
      {
        result = new Object;
        
        if (numArray[8])
        {
           result.commentID = numArray[8].replace('/', '');
           newID = numArray[7] + "_" + result.commentID;
        }
        else
        {
          newID = numArray[7];
          result.commentID = false;
        }
        result.description = numArray[4];
        result.nodeKey = newID;
        result.nodeAuthor = numArray[3];
        result.random = rand;
        
        if (showAvatars)
        {
           var avaObj = new Object();
           avaObj.ID = 'juick_user_avatar_' + avaRand;
           avaObj.Author = numArray[3];
           var found = false;        
            for(var i=0, iCount=userAvatars.length; i<iCount; i++)
            {
              if (userAvatars[i].Author == avaObj.Author)
              {
                avaObj.ID = userAvatars[i].ID;
                found = true;
              }
            }        
           if (!found)
              userAvatars.push(avaObj);
           el.innerHTML = el.innerHTML.replace(lastMsgNumRegEx, '<div id="' + avaObj.ID + '" style="display:inline;"></div>$1');
        }
      }
      else
      {
        result = false;
      }
    }
    else if (showAvatars)
    {
      if ((numArray = lastMsgNumRegEx.exec(result)) != null)
      {
           var avaObj = new Object();
           avaObj.ID = 'juick_user_avatar_' + avaRand;
           avaObj.Author = numArray[3];
           var found = false;        
            for(var i=0, iCount=userAvatars.length; i<iCount; i++)
            {
              if (userAvatars[i].Author == avaObj.Author)
              {
                avaObj.ID = userAvatars[i].ID;
                found = true;
              }
            }        
           if (!found)
              userAvatars.push(avaObj);
           el.innerHTML = el.innerHTML.replace(lastMsgNumRegEx, '<div id="' + avaObj.ID + '" style="display:inline;"></div>$1');
      }
    }
    // ����������� ���� ��������
    jWrap(el, nickRegEx, '<div>', 'class="juickNick" action="$1+" autosend="true"');

    
    var msgNumControl   = '<div class="juick">';
    msgNumControl       += '<div class="juickMsgButton" action="$1 ">$1</div>';
    // #123456+    
    msgNumControl       += '<div class="juickMiddleButton" action="$2+" autosend="true">+</div>';
    // S #123456
    msgNumControl       += '<div class="juickMiddleButton" action="S $2">S</div>';
    // U #123456
    msgNumControl       += '<div class="juickLastButton" action="U $2">U</div>';
    // D #123456
    //msgNumControl += ' <div class="juickButton" action="D $1">D</div>';
    // ! #123456
    //msgNumControl += ' <div class="juickButton" action="! $2">!</div>';
    msgNumControl += '</div>';
    
    jAdd(el, msgNumRegEx, msgNumControl);
    el.id = '_trash'+newID+'_'+rand;
    return result; 
}

/* 
 * @name wrap
 *
 * @description ����������� ����� � ����� � id = id, 
 * ����������� � �������� pattern ����� tag � ����������� params.
 *
 * @var pattern RegExObj 
 * @var tag string
 * @var params string
 *
 * @return void
 */
function jWrap(el, pattern, tag, params)
{
    if (params == undefined)
        params = '';
    tag = tag.substr(0, tag.length - 1) + ' ' + params + '>';
    var end = "</" + tag.substr(1, tag.length);
    el.innerHTML = el.innerHTML.replace(pattern, tag + "$1" + end);
};

/*
 * @name add
 *
 * @description ��������� text, � ���� � id = id, ����� 
 * ����� ������ ���������� � �������� pattern, 
 * ����� ��� div:hover ��� IE
 * 
 * @var pattern RegExObj
 * @var text string
 */
function jAdd(el, pattern, text)
{
   el.innerHTML = el.innerHTML.replace(pattern, text);

   if(el.hasChildNodes && el.childNodes.length >0)	
   {
	  var hEls = el.childNodes;
	  for(var i = 0; i < hEls.length; i++)	
	  {
         if (hEls[i].className == "juick")
         {
            var juick = hEls[i];
            if(juick.hasChildNodes && juick.childNodes.length >0)	
            {
         	  var jEls = juick.childNodes;
         	  for(var j = 0; j < jEls.length; j++)	
         	  {
                  if (jEls[j].className && (jEls[j].className == "juickMsgButton" || jEls[j].className == "juickMiddleButton" || jEls[j].className == "juickLastButton"))
                  {
                    jEls[j].onmouseover = function() { this.className+="_hover"; }
                    jEls[j].onmouseout = function() { this.className=this.className.replace("_hover", ""); }
                  }
               }  
            }           
         }
         else if (hEls[i].className == "juickNick")
         {
           // hEls[i].onclick = function() { scrollTo(el.id); } // ����������� ������ � ����
           hEls[i].onclick = function() { scrollTo('510353_81'); } // ����������� ������ � ����
           hEls[i].onmouseover = function() { this.className+="_hover"; }
           hEls[i].onmouseout = function() { this.className=this.className.replace("_hover", ""); }         
         }
      }  
   } 
   
}

function jInsertAvatar(author, avatarPath)
{
   for(var i=0, iCount=userAvatars.length; i<iCount; i++)
   {
     if (userAvatars[i].Author == author)
     {
       jFillAvatarDiv(userAvatars[i].ID, avatarPath);
       return false;
     }
   }
}

function jFillAvatarDiv(avatarDivID, avatarPath)
{
   var el = document.getElementById(avatarDivID);
   while(el)
   {
     el.innerHTML = '<img src="' + avatarPath + '" width=32 height=32 align=left hspace=1 vspace=1 border=0>';
     el.id = el.id + '_done';
     el = document.getElementById(avatarDivID);
   }  
}