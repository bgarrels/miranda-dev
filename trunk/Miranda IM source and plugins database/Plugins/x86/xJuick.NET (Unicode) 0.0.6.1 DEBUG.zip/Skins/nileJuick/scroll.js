/* 
 * FadeScroll by xa0c, http://xa0c.net
 *
 */

 var fadeTime = 200.0;
 var fadeSteps = 30;
 var fadeRTo = 187;
 var fadeGTo = 217;
 var fadeBTo = 254;
 
 var treeContent = new Array();
 
 var treeOpenBtn = '<div id="treeOpen" class="jThreadsBtnOpen" onclick="javascript:changeTreeStyle();"></div>';
 var treeOpened = '<div id="treeClose" class="jThreadsBtnClose" onclick="javascript:changeTreeStyle();"></div>';
  
function getRGB(elementColor)
{
  //alert (elementColor);

  var reFullHex = /(\w{2})(\w{2})(\w{2})$/;
  var reRGB = /rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/;
  var result = new Array();
  
  if (reRGB.test(elementColor))
  {
     var bits = reRGB.exec(elementColor);
     result.push(parseInt(bits[1]));
     result.push(parseInt(bits[2]));
     result.push(parseInt(bits[3]));
     return result; 
  }
  else if (reFullHex.test(elementColor))
  {
     var bits = reFullHex.exec(elementColor);
     result.push(parseInt(bits[1], 16));
     result.push(parseInt(bits[2], 16));
     result.push(parseInt(bits[3], 16));
     return result;      
  }

  return [255,255,255];
}

// �������� �� ������! ������������! 
function scrollTo(id)
{
   id = '_trash'+id;
   var scrollElement = document.getElementById(id);
   if (!scrollElement)
     return false;
     
   window.scroll(0, scrollElement.offsetTop);
   
   var coloredString;
   var coloredElement = scrollElement;
   
   do
   {
     try
     {
        coloredString = getStyle(coloredElement, "background-color");
        if (coloredString && coloredString != 'transparent')
          break;
     }
     catch(ex) {}
     
     coloredElement = coloredElement.parentNode;  
       
   } while (coloredElement)

   changeTreeStyle();
   var colors = getRGB(coloredString);
   fade(id, colors[0], colors[1], colors[2], 'in');
   return true;
}

function getStyle(oElm, strCssRule){
	var strValue = "";
	if(document.defaultView && document.defaultView.getComputedStyle){
		strValue = document.defaultView.getComputedStyle(oElm, "").getPropertyValue(strCssRule);
	}
	else if(oElm.currentStyle){
		strCssRule = strCssRule.replace(/\-(\w)/g, function (strMatch, p1){
			return p1.toUpperCase();
		});
		strValue = oElm.currentStyle[strCssRule];
	}
	return strValue;
}
     
function setColor(fromR, fromG, fromB, id, step, direction) 
{
  var level = step/fadeSteps;
  var element = document.getElementById(id);
  
   if (direction == 'in')
   {
     element.style.backgroundColor="rgb("+Math.floor(fromR*((fadeSteps-step)/fadeSteps) + fadeRTo*level)+","+Math.floor(fromG*((fadeSteps-step)/fadeSteps) + fadeGTo*level)+","+Math.floor(fromB*((fadeSteps-step)/fadeSteps) + fadeBTo*level)+")";
     if (step == fadeSteps)
     {
       fade(id, fromR, fromG, fromB, 'out');
     }
   }
   else
   {
     element.style.backgroundColor="rgb("+Math.floor(fadeRTo*((fadeSteps-step)/fadeSteps) + fromR*level)+","+Math.floor(fadeGTo*((fadeSteps-step)/fadeSteps) + fromG*level)+","+Math.floor(fadeBTo*((fadeSteps-step)/fadeSteps) + fromB*level)+")";   
   }  
}

function fade(id, fromR, fromG, fromB, direction)
{
  var element = document.getElementById(id);
  for (var step = 0; step <= fadeSteps; step++) 
  {
    setTimeout("setColor('" + fromR + "','" + fromG + "','" + fromB + "','" + id + "'," + step + ",'" + direction + "')", (step / fadeSteps) * fadeTime);
  }      
}

function changeTreeStyle()
{
  fixedMenu.moveMenu();
  if(fixedMenu.menu.className == fixedMenuId)
  {
    fixedMenu.menu.className = fixedMenuId + 'Opened';

    if (!fixedMenu.resizedW)
    {
      fixedMenu.menu.style.width = 350;
      fixedMenu.menu.style.height = document.body.clientHeight * 0.75;
    }
    else
    {
      fixedMenu.menu.style.width = fixedMenu.resizedW;
      fixedMenu.menu.style.height = fixedMenu.resizedH;      
    }
    
    reloadMenu();
  }
  else
  {
    fixedMenu.menu.style.width = 5;
    fixedMenu.menu.style.height = 5;  
    fixedMenu.menu.innerHTML = treeOpenBtn; 
    fixedMenu.menu.className = fixedMenuId;
  }
  fixedMenu.moveMenu();
}

function reloadMenu()
{
  if(fixedMenu.menu.className == fixedMenuId + 'Opened')
  {
    fixedMenu.menu.innerHTML = makeTree();
        
    var tree = document.getElementById('treeContent');
    tree.style.height = fixedMenu.menu.style.height;
    tree.style.width = fixedMenu.menu.style.width;
  }
}

function ASCSort (i, ii) 
{
 if (i.nodeKey > ii.nodeKey)
     return 1;
 else if (i.nodeKey < ii.nodeKey)
     return -1;
 else
     return 0;
}

function treeShow(nodeID)
{
  var obj = document.getElementById('sub' + nodeID)

  if (!obj)
    return false;
    
  if (obj.style.display == 'block')
  {
    obj.style.display = 'none';
    setExpandState(nodeID, false);
  }
  else
  {
    obj.style.display = 'block';
    setExpandState(nodeID, true);
  }
}

function setExpandState(nodeID, state)
{
  for(var i=0, iCount=treeContent.length; i<iCount; i++)
  {
    if (treeContent[i].nodeKey == nodeID)
    {
      treeContent[i].expanded = state;
      return false;
    }
  }
}

function makeTree()
{
  var result = treeOpened;
  result += '<div id="treeContent" class="treeContent">'
  for(var i=0, iCount=treeContent.length; i<iCount; i++)
  {
    var haveChilds = treeContent[i].nodes.length != 0;
    result += '<span class="menu" onclick="' + (haveChilds ? ('treeShow(\'' + treeContent[i].nodeKey) : ('scrollTo(\'' + treeContent[i].nodeKey + '_' + treeContent[i].random) ) + '\')">' + 
               (haveChilds ? '+ ' : '&nbsp;&nbsp;')  + treeContent[i].nodeTitle + '&nbsp;<span class="juickNick">' + treeContent[i].nodeAuthor +  '</span>' + (treeContent[i].description ? '[' + treeContent[i].description + ']' : '')  + '</span>'
    if (haveChilds)
    {
      result += '<span class="sub" id="sub' + treeContent[i].nodeKey + '" style="display: ' + (treeContent[i].expanded ? 'block' : 'none')  +  '">';
      for(var j=0, jCount=treeContent[i].nodes.length; j<jCount; j++)
      {
        result += '<span class="juickAnchor" onclick="scrollTo(\'' + treeContent[i].nodes[j].nodeKey + '_' + treeContent[i].nodes[j].random + '\')">&nbsp;&nbsp;' + (treeContent[i].nodes[j].commentID ? '#' + treeContent[i].nodes[j].commentID : '&nbsp;') + '&nbsp;<span class="juickNick">' + treeContent[i].nodes[j].nodeAuthor + '</span></span>';
      }
      result += '</span>';
    }
  } 
  result += '</div>';
  return result;
}

/*
 * Script by: www.jtricks.com
 * modified by xa0c, http://xa0c.net
 */
var fixedMenuId = 'jThreads';
var fixedMenu = {};

fixedMenu.computeShifts = function()
{
    fixedMenu.shiftX = fixedMenu.hasInner
        ? pageXOffset
        : fixedMenu.hasElement
          ? document.documentElement.scrollLeft
          : document.body.scrollLeft;
    if (fixedMenu.targetLeft > 0)
        fixedMenu.shiftX += fixedMenu.targetLeft;
    else
    {
        fixedMenu.shiftX += 
            (fixedMenu.hasElement
              ? document.documentElement.clientWidth
              : fixedMenu.hasInner
                ? window.innerWidth - 35
                : document.body.clientWidth)
            - fixedMenu.targetRight
            - fixedMenu.menu.offsetWidth;
    }

    fixedMenu.shiftY = fixedMenu.hasInner
        ? pageYOffset
        : fixedMenu.hasElement
          ? document.documentElement.scrollTop
          : document.body.scrollTop;
    if (fixedMenu.targetTop > 0)
        fixedMenu.shiftY += fixedMenu.targetTop;
    else
    {
        fixedMenu.shiftY += 
            (fixedMenu.hasElement
            ? document.documentElement.clientHeight
            : fixedMenu.hasInner
              ? window.innerHeight - 35
              : document.body.clientHeight)
            - fixedMenu.targetBottom
            - fixedMenu.menu.offsetHeight;
    }
};

fixedMenu.moveMenu = function(forced)
{
    fixedMenu.computeShifts();

    if (forced || (fixedMenu.currentX != fixedMenu.shiftX || fixedMenu.currentY != fixedMenu.shiftY))
    {
        fixedMenu.currentX = fixedMenu.shiftX;
        fixedMenu.currentY = fixedMenu.shiftY;

        if (document.layers)
        {
            fixedMenu.menu.left = fixedMenu.currentX;
            fixedMenu.menu.top = fixedMenu.currentY;
        }
        else
        {
            fixedMenu.menu.style.left = fixedMenu.currentX + 'px';
            fixedMenu.menu.style.top = fixedMenu.currentY + 'px';
        }
    }

    fixedMenu.menu.style.right = '';
    fixedMenu.menu.style.bottom = '';
};

fixedMenu.floatMenu = function()
{
    fixedMenu.moveMenu;
    setTimeout('fixedMenu.floatMenu', 10);
};

// addEvent designed by Aaron Moore
fixedMenu.addEvent = function(element, listener, handler)
{
    if(typeof element[listener] != 'function' || 
       typeof element[listener + '_num'] == 'undefined')
    {
        element[listener + '_num'] = 0;
        if (typeof element[listener] == 'function')
        {
            element[listener + 0] = element[listener];
            element[listener + '_num']++;
        }
        element[listener] = function(e)
        {
            var r = true;
            e = (e) ? e : window.event;
            for(var i = 0; i < element[listener + '_num']; i++)
                if(element[listener + i](e) === false)
                    r = false;
            return r;
        }
    }

    //if handler is not already stored, assign it
    for(var i = 0; i < element[listener + '_num']; i++)
        if(element[listener + i] == handler)
            return;
    element[listener + element[listener + '_num']] = handler;
    element[listener + '_num']++;
};

fixedMenu.supportsFixed = function()
{
    var testDiv = document.createElement("div");
    testDiv.id = "testingPositionFixed";
    testDiv.style.position = "fixed";
    testDiv.style.top = "0px";
    testDiv.style.right = "0px";
    document.body.appendChild(testDiv);
    var offset = 1;
    if (typeof testDiv.offsetTop == "number"
        && testDiv.offsetTop != null 
        && testDiv.offsetTop != "undefined")
    {
        offset = parseInt(testDiv.offsetTop);
    }
    if (offset == 0)
    {
        return true;
    }

    return false;
};

fixedMenu.moveTo = function (moveToRight)
{
   if (moveToright)
   {
      if (fixedMenu.menu.style.position=='fixed')
      {
         fixedMenu.menu.style.left='';
         fixedMenu.menu.style.top='5px';
         fixedMenu.menu.style.right='5px';
         fixedMenu.menu.style.bottom='';
      }
      else
      {
         fixedMenu.targetLeft='';
         fixedMenu.targetTop=5;
         fixedMenu.targetRight=5;
         fixedMenu.targetBottom='';
      }
   }
   else
   {
      if (fixedMenu.menu.style.position=='fixed')
      {
         fixedMenu.menu.style.left='5px';
         fixedMenu.menu.style.top='5px';
         fixedMenu.menu.style.right='';
         fixedMenu.menu.style.bottom='';
      }
      else
      {
         fixedMenu.targetLeft=5;
         fixedMenu.targetTop=5;
         fixedMenu.targetRight='';
         fixedMenu.targetBottom='';
      }
   }
}

// Resizing
fixedMenu.resizeObject = function() 
{
	this.el    = null; //pointer to the object
	this.dir   = "";      //type of current resize (n, s, e, w, ne, nw, se, sw)
	this.grabx = null;     //Some useful values
	this.graby = null;
	this.width = null;
	this.height = null;
	this.left   = null;
	this.top    = null;
}

fixedMenu.getDirection = function(el) 
{
	var xPos, yPos, offset, dir;
	dir = "";

	xPos = window.event.offsetX;
	yPos = window.event.offsetY;

	offset = 8; //The distance from the edge in pixels

	if (yPos<offset) 
	  dir += "n";
	else if (yPos > el.offsetHeight-offset) 
	  dir += "s";
	  
	if (xPos<offset) 
	  dir += "w";
	else if (xPos > el.offsetWidth-offset) 
	  dir += "e";

	return dir;
}

fixedMenu.doDown = function() 
{
   /*
	//var el = fixedMenu.getReal(event.srcElement, "className", "resizeMe");
	var el = event.srcElement;

	if (el.id == fixedMenuId && el.className == fixedMenuId + "Opened") {
		fixedMenu.theObject = null;
		return;
	}	
	*/	

	var el = fixedMenu.getReal(event.srcElement, "id", fixedMenuId);

	if (el == null) {
		theobject = null;
		return;
	}

	dir = fixedMenu.getDirection(el);
	if (dir == "") return;

	fixedMenu.theObject = new fixedMenu.resizeObject();
		
	fixedMenu.theObject.el = el;
	fixedMenu.theObject.dir = dir;

	fixedMenu.theObject.grabx = window.event.clientX;
	fixedMenu.theObject.graby = window.event.clientY;
	fixedMenu.theObject.width = el.offsetWidth;
	fixedMenu.theObject.height = el.offsetHeight;
	fixedMenu.theObject.left = el.offsetLeft;
	fixedMenu.theObject.top = el.offsetTop;

	window.event.returnValue = false;
	window.event.cancelBubble = true;
}

fixedMenu.doUp = function() 
{
	if (fixedMenu.theObject != null) {
		fixedMenu.theObject = null;
	}
	
	fixedMenu.moveMenu(true);
}

fixedMenu.doMove = function() 
{
	var el, xPos, yPos, str, xMin, yMin;
	xMin = 8; //The smallest width possible
	yMin = 8; //             height

   el = event.srcElement;

	if (el.id == fixedMenuId && (el.className == fixedMenuId + "Opened")) 
	{
		str = fixedMenu.getDirection(el);
	//Fix the cursor	
		if (str == "") 
		  str = "default";
		else 
		  str += "-resize";
		el.style.cursor = str;
	}
	else if (el.id == 'treeContent')
	{
	   /*
   	if (document.getElementById('treeContent'))
   	{
      	document.getElementById('treeContent').innerHTML = new Date().getMilliseconds() + ':' + el.className + ',' + el.id;
   	}	
   	*/
	   el.style.cursor = 'default';
	   //return;	   
	}
	

	
//Dragging starts here
	if(fixedMenu.theObject != null) {
	   var w = fixedMenu.theObject.el.style.width;
	   var h = fixedMenu.theObject.el.style.height;
		if (dir.indexOf("e") != -1)
			fixedMenu.theObject.el.style.width = w = Math.max(xMin, fixedMenu.theObject.width + window.event.clientX - fixedMenu.theObject.grabx);
	
		if (dir.indexOf("s") != -1)
			fixedMenu.theObject.el.style.height = h = Math.max(yMin, fixedMenu.theObject.height + window.event.clientY - fixedMenu.theObject.graby);

		if (dir.indexOf("w") != -1) {
			fixedMenu.theObject.el.style.left = Math.min(fixedMenu.theObject.left + window.event.clientX - fixedMenu.theObject.grabx, fixedMenu.theObject.left + fixedMenu.theObject.width - xMin);
			fixedMenu.theObject.el.style.width = w = Math.max(xMin, fixedMenu.theObject.width - window.event.clientX + fixedMenu.theObject.grabx);
		}
		if (dir.indexOf("n") != -1) {
			fixedMenu.theObject.el.style.top = Math.min(fixedMenu.theObject.top + window.event.clientY - fixedMenu.theObject.graby, fixedMenu.theObject.top + fixedMenu.theObject.height - yMin);
			fixedMenu.theObject.el.style.height = h = Math.max(yMin, fixedMenu.theObject.height - window.event.clientY + fixedMenu.theObject.graby);
		}
		
		if (dir != '')
      {
        var tree = document.getElementById('treeContent');
        if (tree)
        {
          fixedMenu.resizedW = tree.style.width = w;
          fixedMenu.resizedH = tree.style.height = h;

        }
        else
        {
          fixedMenu.theObject = null;
        }
      }
      
		window.event.returnValue = false;
		window.event.cancelBubble = true;
	} 
}

fixedMenu.getReal = function(el, type, value) 
{
	temp = el;
	while ((temp != null) && (temp.tagName != "BODY")) {
		if (eval("temp." + type) == value) {
			el = temp;
			return el;
		}
		temp = temp.parentElement;
	}
	return el;
}

// End of Resizing

fixedMenu.init = function()
{
    // Menu buttons creation
      var jThreadsX = document.createElement('div');
      jThreadsX.setAttribute('id',fixedMenuId);
      jThreadsX.style.top = '5px';
      jThreadsX.style.right = '5px';
      jThreadsX.className = fixedMenuId;

      jThreadsX.innerHTML = treeOpenBtn;

      document.body.appendChild(jThreadsX);
    // End of menu buttons creation

    // Fields initialization
      fixedMenu.theObject = null;
      document.onmousedown = fixedMenu.doDown;
      document.onmouseup   = fixedMenu.doUp;
      document.onmousemove = fixedMenu.doMove;
      
      fixedMenu.ready = true;
      fixedMenu.hasInner = typeof(window.innerWidth) == 'number';
      fixedMenu.hasElement = document.documentElement != null && document.documentElement.clientWidth;

      fixedMenu.menu = document.getElementById
                       ? document.getElementById(fixedMenuId)
                       : document.all
                         ? document.all[fixedMenuId]
                         : document.layers[fixedMenuId];
    // End of fields initialization
    
    if (fixedMenu.supportsFixed())
        fixedMenu.menu.style.position = "fixed";
    else
    {
        var ob = 
            document.layers 
            ? fixedMenu.menu
            : fixedMenu.menu.style;

        fixedMenu.targetLeft = parseInt(ob.left);
        fixedMenu.targetTop = parseInt(ob.top);
        fixedMenu.targetRight = parseInt(ob.right);
        fixedMenu.targetBottom = parseInt(ob.bottom);

        if (document.layers)
        {
            menu.left = 0;
            menu.top = 0;
        }
        fixedMenu.addEvent(window, 'onscroll', fixedMenu.moveMenu);
        fixedMenu.floatmenu;
    }
};
