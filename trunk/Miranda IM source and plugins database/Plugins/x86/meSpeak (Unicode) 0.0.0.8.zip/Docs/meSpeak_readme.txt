meSpeak plugin
--------------

CAUTION: THIS IS A BETA STAGE PLUGIN. IT CAN DO VERY BAD THINGS. USE AT YOUR OWN RISK.


This is a service plugin that read text aloud. It is based on eSpeak engine (http://espeak.sourceforge.net/).

It provides the following functionality:
- System voice
- Per contact voice
- Options to disable by global status
- Packed with voices for a lot of languages
- "fake" support for plugins that support Variables

This is a service plugin, so it does not read any text by itself. Other plugins need to request it!

It also has an iconpack of flags with it. It is built using famfamfam's icons. If you want other set of flags or to download then separated, they can be found here:
- famfamfam's icons as .ico: http://pescuma.mirandaim.ru/miranda/flags-famfamfam.zip (note that there are a lot of files inside this zip with wrong names. It happens because I don't know which languages they represent - and if they represent a language or not. So, if you think some file name must change, please tell me)
- famfamfam's icons as .dll: http://pescuma.mirandaim.ru/miranda/flags-dll-famfamfam.zip
- Angeli-Ka's icons as .ico: http://pescuma.mirandaim.ru/miranda/flags-angelika.zip
- Angeli-Ka's icons as .ico with language names: http://pescuma.mirandaim.ru/miranda/flags-angelika-name.zip
- Angeli-Ka's icons as .dll: http://pescuma.mirandaim.ru/miranda/flags-dll-angelika.zip

Additional dictionary data is available for languages: 
Russian, Cantonese at http://espeak.sourceforge.net/data/index.html

Many thanks to the eSpeak team for their engine and to the famfamfam.com site for the icons.

To report bugs/make suggestions, go to the forum thread: http://forums.miranda-im.org/showthread.php?t=16188