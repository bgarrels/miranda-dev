Gmail Multiple Notifier for Miranda IM (v0.4.0.14)
=================================
Check your Gmail inboxes locally!

Features:

Extreme small file size and system consumption
Support Multiple Gmail accounts
Support Gmail For Your Domain
Auto Login by using any browser or custom program
Notification on contact list, system tray, sound and PopUp plugin
Brief preview of the new threads
Intelligently notify users 


Setting:

Go to Miranda "Options" panel. Find the "Gmail notifier" item then input your Gmail account name and password.

If you use proxy to access internet, config your proxy settings in "Internet Options" in the control panel. If the proxy server need authorization, use following string pattern as your IE proxy setting username:password@999.999.999.999:8080 for auto login.

If you get a message "active content blocked" when you login, try to go to internet options put a check in Allow Active content to run in My Computer.

Tricks:

Push "Shift" key then double click the blinking icon, you can cancel the current notification.
Directly rename the contact when you use a long account name and feel inconvenient.
"...disable Auto Login" option has three states: "uncheck" does autologin with cookie enabled (you can use other google services without login), "gray check" does autologin without cookie and "check" does not autologin.

Many thanks to:
Angeli-Ka for some great icons!
Borkra for help updating the program for Unicode and some Browser issues.

Copyright (c) 2007-2011 Sun Zhuo, EgotisticalElf, borkra

Mixwind@gmail.com, bryan.a.aldrich@gmail.com


