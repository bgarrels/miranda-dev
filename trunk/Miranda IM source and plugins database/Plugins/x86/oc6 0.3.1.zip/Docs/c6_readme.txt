[Italiano]
==========

Cos'�
-----
OC6 � un plug-in per Miranda IM che permette di accedere alla rete italiana  C6
della Community di Virgilio.

Licenza
-------
General public Licence (GPL) (http://www.gnu.org/copyleft/gpl.html)

Installazione
-------------
E' sufficiente copiare oc6.dll nella cartella di Miranda/Plugin.
Per la traduzione italiana usare il file c6_translation.txt

Uso
---
In Opzioni/Rete/C6 riempire i campi di Nick: vecchio, ante chiave unica,  oppure
 nuovo (in questo case � proprio la chiave) e di password;
Se si possiede pi� di un nick collegato alla chiave unica al login verr� mostra-
ta una finestra di scelta, semprech� non sia barrata "Last Nick" in Opzioni, nel
qual caso si connette automaticamente all'ultimo nick usato.
Altre opzioni sono Nessuna Segreteria: cos� nello stato di netfriend/occupato  i
messaggi ricevuti vengono messi nella lista contatti; e possibilit� di disabili-
tare gli avatar.

Dalla versione 0.1.0.4 � possibile rinominare il file per avere pi� identit�.
Opportunit� rimossa dalle versioni > 0.2.0.0
--------------------------------------------

Gli stati possibili sono:
Online = Disponibile
NA = NetFriend 
Busy = Occupato
Away = Assente

Ci sono tre possibilit� di ricerca dei contatti online:
1) per nick, ovvero basta mettere le prime due lettere e varr� mostrata una  li-
   sta di quelli che iniziano per esse;
2) per e-mail, in tal caso il contatto pu� essere anche off-line;
3) avanzata, con diversi filtri possibili.

Nel menu principale:
Aggiungi Contatto: se si conosce, si immette nella lista contatti, senza  passa-
re dalla ricerca; Salva e carica Contatti: poich� i contatti diversamente da ICQ
non risiedono sul server quindi � utile salvarseli. Segretaria e Ricerca sul Web
(link al sito di virgilio).

Multichat
1) � necessario attivare il plugin chat.dll;
2) si accede alle stanze dal menu C6/Multichat;
3) nella finestra oltre  alla  lista c'� la  possibilit� di mostrare il  profilo
 della stanza selezionata (premendo il tasto "Profile"),  a meno che non sia at-
 tivo "Autoprofile"; 
4) � possibile aggiornare la lista premendo il tasto "Refresh";
5) per entrare in una stanza fare doppio click sul suo nome, oppure su "Join";
6) i menu presenti nella finestra di chat sono i seguenti: 
  sull'area  dei log,  "Invite User" per invitare un  amico in una stanza (viene 
 spedito un messaggio),  "Leave Room" per uscire dalla stanza,  "Exit from Room"
 esci senza rientrare nella lista delle stanze;
  mentre nell'area dei partecipanti "Add To List"  per aggiungere nella  propria 
 ContactList, "User Details" per mostrare i dettagli dell'utente e "Web Details" 
 per mostrare quelli presenti sul sito di Virgilio;
7) per uscire *NON* cliccare sul tasto in alto  (chiudi finestra) poich�  si ri-
 marrebbe comunque nella stanza (la finestra viene solo nascosta)  ma come detto 
 premere nel menu di log  "Leave Room" oppure in alternativa  scrivere come mes-
 saggio /exit e confermarlo naturalmente;
8) una volta usciti dalla stanza riapparir� la lista delle stanze;

Problemi conosciuti
--------------
- Qualche volta nel cancellare un contatto temporaneo da una clist_modern oppure
da una clist_meta_mw fa terminare Miranda.
- Il comando <ding> non funziona su nConvers++.
- Se hai il solo protocollo di C6 attivo, lo status selezionato � sballato.
- funziona con il plugin sendss solo se non cancelli il file

--------------------------------------------------------------------------------

[English]
=========

About
-----
With OC6 protocol plug-in for Miranda IM, you can connected to the C6  Italian
Community of Virgilio.

Licence
-------
General public Licence (GPL) (http://www.gnu.org/copyleft/gpl.html)

Install
-------
Copy oc6.dll into Miranda/Plugin directory.

Use
---
In Options/Network/C6 you fill up the following fields:
Nickname =  old nick, before "unique key", or new nick (just the unique key);
Password = obvious.

If you have more a nick connected to the unique key, at the login you can choice
a nick, unless "Last Nick" in Options/Network/C6 is not checked, in the which
case you are connected automatically to the last one nick used.

Possible status are:
Online = Available
NA = Only Friend in Contact List
Busy
Away

Plugin needed for *Groupchat* is chat.dll.

Known Issues
------------
- Sometimes if you remove a temporary contact from a clist_modern or a clist_meta_mw
 then Miranda crash.
- <ding> command doesn't work on nConvers++.
- If you have one active protocol (C6) then the checked status icons is wrong.

-----------------------------
http://r3vindt.altervista.org
(2009-07-29) MG Lena
-----------------------------
