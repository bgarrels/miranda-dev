                Miranda IPSearch
                ~~~~~~~~~~~~~~~~


What is it:
```````````
This is Miranda Plugin for searching users
in your CONTACT LIST by specified IP.
Now you can use it for copying both External
and Internal IPs into clipboard.


How to install and use:
```````````````````````
1. Put 'ipsearch.dll' in 'Plugins' directory
2. Start Miranda
3. Main menu -> IP Search

If External or Internal IPs of contact are available
then it will be shown in contact menu. You can copy it
to clipboard by clicking the corresponding menu item.


How to use mask:
````````````````
Searching routine ignores bit of IP if you
set this bit in mask.

C/C++ condition:
(IP & ~mask == userIP & ~mask)


--
bosm
newctech@yahoo.com