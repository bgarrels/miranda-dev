/*
	ReadMe
*/

/* What is bGSM? */
 bGSM(basic Game Servers Monitor) - is simple plugin for MirandaIM, that can
inform you, when someone starts games in your LAN.

/* What games it support? */
Currently, bGSM support 5 games:
- Half Life (EXPERIMENTAL)
- Half Life 2 (EXPERIMENTAL)
- Quake3
- StarCraft: BroodWar
- WarCraft III: The Frozen Throne v1.07-1.20e

/* INSTALL */
Copy bGSM.dll to Miranda's plugins directory.

/* Contact info */
WEB:	http://addons.miranda-im.org/details.php?action=viewfile&id=3254
		http://clanctl.narod.ru
E-MAIL: bGSM_offmail@mail.ru

/* Legal info */
bGSM Plugin for Miranda IM
Copyright (C) 2006 Yuri Konotopov a.k.a. nE0sIghT

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or ( at your option ) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
