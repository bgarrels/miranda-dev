==Wikify Plugin 1.0.1.2 Readme==

===GENERAL===
Description: Implements Wikipedia features and partially adapts outgoing messages to the wiki standards.
Features:
- unlimited, customizable wiki links
- templates
- indents :/::/:::/ etc.
- dashes (-- to � or �)
- tabulator character \t (non-wiki, but still useful)
- convertion of "" quotation marks to ��/�� or ��/��
- escape tag
Author: Oliver Prime
Contact: info@oliverprime.com
Website: http://www.oliverprime.com
Copyright: (c) 2006

===INSTALLATION===
Move wikify.dll to the folder \plugins in your miranda directory (usually C:\Program Files\Miranda IM\Plugins)

===USAGE===
To convert an occurrence of a word into a link to the homonymous Wikipedia article or any other custom URL, enclose it in double/3-fold/ .. /n-fold square brackets. For example, type "[[whatever]]" and it is converted to "http://en.wikipedia.org/wiki/whatever" automatically after you submit your message. In the options (Plugins/Wikify/Links) you can set the URLs of Wikipedia or other sites which will be used for the links. For example [[[whatever]]] will use the second URL specified in the options, [[[[whatever]]]] the third, and so on. To link to another language version of Wikipedia, replace "en" in the URL. You can override the language temporarily like "[[de:article]]". Wikipedia resolves this by itself when you open the link.

{{...}} converts as set in options/templates.
: at the beginning of a new line converts to 3 spaces.
-- converts to � or � as chosen in the options.
\t converts to a tabulator character.
"example" converts to either �example�, �example�, �example� or �example� as chosen in the options.

These commands are not converted within one message when preceded with <!>. Each can be deactivated in the options. The plugin only modifies outgoing messages.

===VERSION HISTORY===
http://addons.miranda-im.org/details.php?action=viewlog&id=2611

===LICENSE===
This program is freeware. You can copy, use or distribute it as long as you don't charge for it, include it in a product which is distributed for profit, and provided that you do not make any changes in the software or readme file.

This software is provided "as-is" and without any express or implied warranties, including, without limitation, the implied warranties of merchantability and fitness for a particular purpose. In no event will the author be held liable for any damages arising from the use of this software.