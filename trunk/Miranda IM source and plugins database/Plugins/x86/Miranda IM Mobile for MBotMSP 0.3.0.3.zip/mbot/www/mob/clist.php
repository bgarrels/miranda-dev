<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');
?><?php

include("inc/arriba.inc.php");

if(isset($_GET["cid"])) {
	$cid = $_GET["cid"];
	if($cid == 0)
		$cid = mb_CFindFirst();
} else
	$cid = mb_CFindFirst();

/*
 ************ TEMPORAL ***************
 
					RECONNECT
					NICK
					
*/
//show all contacts or just 'not offline' contacts
if(isset($_GET["reconnect"]))
	mb_PSetMyStatus($_GET["reconnect"], ID_STATUS_NA);
if(isset($_GET["nick"]))
	mb_CSettingSet(0, 'MSP_autoSetNickAndMessage', 'Nickname', $_GET["nick"]);
/* fin TEMPORAL */

//show all contacts or just 'not offline' contacts
if(isset($_GET["all"])) {
	$all = $_GET["all"];
	if($all != 1)
		$all = 0;
} else
	$all = 0;

//first contact to show. number of the array key index.
if(isset($_GET["first"]))
	$firstContact = $_GET["first"];
else
	$firstContact = 1;

$icon = 'fotos/status/default/'.ID_STATUS_ONLINE.'.png';

if(!$all)
	$showAllOrOnline = "Show All";
else
	$showAllOrOnline = "Show Online";

printHTML('<table width="100%" border="0" style="border-bottom: 1px solid #000000;"><tr>');
printHTML('<td><div align="left">');
printHTML('<a href="clist.php?all='.$all.'">'.translateString('Reload').'</a> | ');
printHTML('<a href="clist.php?all='. (($all == 1) ? 0 : 1) .'">'.translateString($showAllOrOnline).'</a> | ');
//printHTML('<a href="clist.php?reconnect=MSN">'.translateString('Reconnect').'</a>');
printHTML('<a href="status.php">'.translateString('Status').'</a> | ');
printHTML('<a href="login.php?log=out">'.translateString('Log Out').'</a>');
printHTML('</div></td>');
printHTML('<td><div align="right" style="font-weight:bold;">Miranda IM <img src="'.$icon.'" /></div></td>');
printHTML('</tr></table><br />');

function compareNicks($x, $y) {

	//tiene unread messages
	if(mb_EventFindFirstUnread($x['cid']))
		return -1;	
	else if(mb_EventFindFirstUnread($y['cid']))
		return 1;
	//abecedario
	else if (icString(strtolower($x['nick'])) == icString(strtolower($y['nick'])))
		return 0;
	else if(icString(strtolower($x['nick'])) < icString(strtolower($y['nick'])))
		return -1;
	else
		return 1;
		
}

$contacts = array();

$totalContacts = 0;
do { 
	
	$known = mb_CIsOnList($cid);
	$nick = mb_CGetDisplayName($cid);
	
	if($all || (!$all && mb_CGetStatus($cid) != ID_STATUS_OFFLINE && mb_CGetStatus($cid) != 0)) {
	
		$contacts[$totalContacts]['cid'] = $cid;
		$contacts[$totalContacts]['known'] = $known;
		$contacts[$totalContacts]['nick'] = $nick;
		
		++$totalContacts;
	
	}
	
} while($cid = mb_CFindNext($cid));

usort($contacts, 'compareNicks');

if($firstContact > $totalContacts)
	$firstContact = 1;

$inicio = $firstContact - 1;
$fin = ($firstContact - 1) + CONTACTS_PER_PAGE;

/* IMPRIMIR LISTA */
for($contactsPrinted = $inicio; $contactsPrinted < $fin && $contactsPrinted < $totalContacts; ++$contactsPrinted) {

	$proto = mb_CGetProto($contacts[$contactsPrinted]['cid']);
	
	$status = mb_CGetStatus($contacts[$contactsPrinted]['cid']);

	if(is_null($status) || $status === '') //workaround for UNKNOWN CONTACTS or contacts returning '' as status ID
		$status = 'unknown';
	else if($status == 0) //this is a workaround for contacts returning 0 as the status id... don't know why :-\
		$status = ID_STATUS_OFFLINE;

	if(mb_EventFindFirstUnread($contacts[$contactsPrinted]['cid']))
		$icon = 'fotos/other/message.png';
	else if(file_exists('fotos\\status\\'.$proto.'\\'.$status.'.png'))
		$icon = 'fotos/status/'.$proto.'/'.$status.'.png';
	else {
		if(file_exists('fotos\\status\\default\\'.$status.'.png'))
			$icon = 'fotos/status/default/'.$status.'.png';
		else
			$icon = 'fotos/status/default/unknown.png';
	}

	printHTML('<img src="'.$icon.'" /> ');

	if($contacts[$contactsPrinted]['known'])
		$nick = fixForHTML(ssm_encoding($contacts[$contactsPrinted]['nick']));
	else
		$nick = '<i>'.fixForHTML(ssm_encoding($contacts[$contactsPrinted]['nick'])).'</i>';

	printHTML('<a href="contact.php?cid='.$contacts[$contactsPrinted]['cid'].'">'.$nick.'</a><br />');

}
/* FIN IMPRIMIR LISTA */

$pages = ceil($totalContacts / CONTACTS_PER_PAGE);

if($pages > 1) {

	printHTML('<div align="right">');
	
	printHTML(translateString('Go to page').':');
	
	for($i = 1; $i <= $pages; ++$i)
		printHTML(' <a href="clist.php?all='.$all.'&first='.(($i-1)*CONTACTS_PER_PAGE + 1).'">'.$i.'</a>');
		
	printHTML('</div>');

}

include("inc/abajo.inc.php");

?>