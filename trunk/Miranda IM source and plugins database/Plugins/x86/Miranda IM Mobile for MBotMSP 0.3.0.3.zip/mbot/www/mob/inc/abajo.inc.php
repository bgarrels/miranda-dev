<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

?>

<br />
<div align="center" style="font-size:10px; border-top: 1px solid #000000;"><a href="http://www.felipebrahm.com"><?php printHTML(translateString('Miranda IM Mobile for MBot/MSP by Felipe Brahm (aka souFrag)')); ?></a></div>

</body>
</html>