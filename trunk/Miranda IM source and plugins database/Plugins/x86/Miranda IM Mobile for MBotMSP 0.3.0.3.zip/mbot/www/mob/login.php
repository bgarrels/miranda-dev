<?php

/*******************************************************************************
 *
 * souFrag Site Manager
 * (CC)2006-2007 Felipe Brahm
 *
 * http://www.felipebrahm.com
 *
 *******************************************************************************
 */

require('inc/comun.inc.php');
?><?php

if(isset($_GET['log']) && $_GET['log'] == 'out') {

	unset($_SESSION[SESSION_NAME]);

	redirectToLocal('index.php');
	exit;

}

if(isset($_POST['user']) && isset($_POST['pass'])) {

	if(CAPTCHA_ENABLED) {
	
		require('inc/captcha/verificarCaptcha.inc.php');
	
		if($blnCaptcha != true)
			redirectToLocal('index.php');
	
	}

	if($_POST['user'] == USER && $_POST['pass'] == PASSWORD) {
	
		$_SESSION[SESSION_NAME] = USER;
		redirectToLocal('clist.php');
		exit;
	
	}

}

redirectToLocal('index.php');

?>