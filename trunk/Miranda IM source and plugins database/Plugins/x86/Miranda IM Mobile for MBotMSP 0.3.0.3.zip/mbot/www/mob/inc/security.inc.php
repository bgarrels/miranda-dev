<?php

@session_start();

if(LOGIN_ENABLED && (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME] == null)) {
	redirectToLocal('index.php');
	exit;
}

?>