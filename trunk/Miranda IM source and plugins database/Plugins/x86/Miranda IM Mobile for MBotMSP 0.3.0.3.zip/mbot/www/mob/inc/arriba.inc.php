<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espaol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<? if(strstr($_SERVER['PHP_SELF'], 'reply.php') || strstr($_SERVER['PHP_SELF'], 'status.php')) { //windows-1251?>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET_REPLY; ?>" />
	<!--meta http-equiv="Content-Type" content="text/html; charset=windows-1251" /-->
	<!--meta http-equiv="Content-Type" content="text/html; charset=utf-8" /-->
<?php } else {?>
	<!--meta http-equiv="Content-Type" content="text/html; charset=windows-1251" /-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php } ?>
<meta name="author" CONTENT="Felipe Brahm (aka souFrag) - http://www.felipebrahm.com">
<title>Miranda IM Mobile for MBot/MSP</title>
<style>
<!--
body, td, th { font-family: Arial, Helvetica, Verdana, sans-serif; font-size: 14px; color:#000000; background:#FFFFFF }
input, select { font-family: Arial, Helvetica, Verdana, sans-serif; font-size: 13px; border: 1px solid #000000; background:#FFFFFF; color:#000000; font-weight:bold; padding-left: 1px; padding-right: 1px; }
-->
</style>
<?php
if(strpos($_SERVER['PHP_SELF'], "index.php") !== FALSE && AUTOREFRESH_CONTACTLIST >= 0)
	printHTML('<meta http-equiv="refresh" content="'.AUTOREFRESH_CONTACTLIST.'">');
else if(strpos($_SERVER['PHP_SELF'], "contact.php") !== FALSE && !isset($_GET["search"]) && AUTOREFRESH_MESSAGES >= 0)
	printHTML('<meta http-equiv="refresh" content="'.AUTOREFRESH_MESSAGES.'">');
?>
</head>

<body>