<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');
?><?php

include("inc/phpthumb.bmp.php"); //http://phpthumb.sf.net

function getFileExtension($file) {

	//comienza en -2 ya que no puede haber un punto al final (�ltima posici�n == -1).. y si lo hay no tiene sentido
	for($i = strlen($file) - 2; $i >= 0; --$i) {
		if($file[$i] == '.')
			return(strtolower(substr($file, $i+1)));
	}

	return false;

}

/*
I took most of this code from a post at PHP manual comments...
Thanks "jongliertreff.de" :-)
*/

if(isset($_GET["cid"]))
	$cid = $_GET["cid"];
else
	exit();

if(isset($_GET["s"]))
	$max_size = $_GET["s"];
else
	$max_size = AVATAR_MAX_SIZE;
	
if(isset($_GET["q"]))
	$quality = $_GET["q"];
else
	$quality = AVATAR_QUALIY;

$image_file = mb_CSettingGet($cid, "ContactPhoto", "File"); //set source file

if($image_file === FALSE)
	$image_file = NO_AVATAR_FILE;

$extension = getFileExtension($image_file);

if(!in_array($extension, $allowedAvatarExtensions))
	$image_file = NO_AVATAR_FILE; //unsupported avatar file format

$size = getimagesize($image_file); //get original size

if($size[0] > $size[1])
	$divisor = $size[0] / $max_size;
else
	$divisor = $size[1] / $max_size;

if($max_size <= 0)
	$divisor = 1;

$new_width = $size[0] / $divisor;
$new_height = $size[1] / $divisor;

//sizes should be integers
$new_width = round($new_width);
$new_height = round($new_height);

//load original image
switch($extension) {

	case 'jpg':
	
		$image_big = imagecreatefromjpeg($image_file);
		break;

	case 'gif':

		$image_big = imagecreatefromgif($image_file);
		break;

	case 'bmp':

		$bmp2gd_instance = new phpthumb_bmp();
		$bmp2gd = $bmp2gd_instance->phpthumb_bmpfile2gd($image_file);
		$image_big = $bmp2gd;
		break;

	case 'png':

		$image_big = imagecreatefrompng($image_file);
		break;

	default:
	
		//it shouldn't get to this point as I've already checked for a valid extension before
		break;

}
	
$image_small = imagecreatetruecolor($new_width, $new_height); //create new image

//imageresampled whill result in a much higher quality than imageresized
if($max_size >= 0)
	imagecopyresampled($image_small, $image_big, 0, 0, 0, 0, $new_width, $new_height, $size[0], $size[1]);
else { //tama�o original
	imagecopy($image_small, $image_big, 0, 0, 0, 0, $size[0], $size[1]);
	imagejpeg($image_small, 'c:\caca.jpg', $quality);
//	echo 'caca'; exit;
}

imagedestroy($image_big); //the original data are no longer used

header("Content-type: image/jpeg");
header('Content-Disposition: filename='.$cid.'-'.$max_size.'.jpg');

//finally send image to browser and destroy no longer needed data.
imagejpeg($image_small, null, $quality);
imagedestroy($image_small);

exit();

?>