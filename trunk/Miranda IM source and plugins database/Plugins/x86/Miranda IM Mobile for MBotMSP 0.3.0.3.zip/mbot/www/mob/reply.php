<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');
?><?php

include("inc/arriba.inc.php");

$cid = $_GET["cid"];

if(file_exists('fotos\\status\\'.mb_CGetProto($cid).'\\'.mb_CGetStatus($cid).'.png'))
	$icon = 'fotos/status/'.mb_CGetProto($cid).'/'.mb_CGetStatus($cid).'.png';
else
	$icon = 'fotos/status/default/'.mb_CGetStatus($cid).'.png';

$realNick = mb_CGetInfo($cid, 3);
$nick = mb_CGetDisplayName($cid);

printHTML('<table width="100%" border="0" style="border-bottom: 1px solid #000000;"><tr>');
printHTML('<td><div align="left"><a href="contact.php?cid='.$cid.'">'.translateString('Back').'</a></div></td>');
printHTML('<td><div align="right"><b>'. fixForHTML($nick) .'</b> <img src="'.$icon.'" /></div></td>');
printHTML('</tr></table>');

if(!is_null($realNick) && strcmp($realNick, $nick) != 0)
	printHTML('<div align="right" style="font-size:12px;">'.fixForHTML($realNick).'</div>');
else
	printHTML('<br />');
	
$statusMessage = mb_CSettingGet($cid, 'CList', 'StatusMsg');

if($statusMessage !== FALSE && !is_null($statusMessage))
	printHTML('<div align="right" style="font-size:12px;font-style:italic;">'.fixForHTML($statusMessage).'</div>');

printHTML('<br />');

printHTML('<div align="center">');

printHTML('<form name="send" method="post" action="contact.php?cid='.$cid.'" />');

printHTML('<input type="hidden" name="action" value="sendMessage" />');

printHTML('<input type="hidden" name="cid" value="'.$cid.'" />');

printHTML('<textarea name="body" cols="60" rows="5"></textarea>');

printHTML('<br /><br />');

printHTML('<input name="send" value="'.translateString('Send').'" type="submit" />');

printHTML('</div>');

include("inc/abajo.inc.php");

?>