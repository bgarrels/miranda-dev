<!-- CAPTCHA by (CC)2006-2007 Felipe Brahm http://www.felipebrahm.com -->

<script language="javaScript">
function reloadCaptcha(campoCaptcha) {
	document.getElementById(campoCaptcha).src='<?php echo (isset($captchaImageDirectory) ? $captchaImageDirectory : 'inc/captcha'); ?>/getCaptcha.img.php?campoCaptcha='+campoCaptcha+'&'+Date();
}
</script>

<img src="<?php echo (isset($captchaImageDirectory) ? $captchaImageDirectory : 'inc/captcha'); ?>/getCaptcha.img.php?campoCaptcha=<?php echo $campoCaptcha ?>" alt="<?php echo translateString('Contact the system administrator if you can\'t see this image'); ?>." id="<?php echo $campoCaptcha ?>" /><br />
<a href="javascript:reloadCaptcha('<?php echo $campoCaptcha ?>');" style="font-size: 9px"><?php echo translateString('Get a new image'); ?>.</a>
<br />
<input type="hidden" name="campoCaptcha" value="<?php echo $campoCaptcha ?>" />
<input type="text" name="<?php echo $campoCaptcha ?>" size="6" maxlength="6" autocomplete="off" />

<!-- END CAPTCHA by (CC)2006-2007 Felipe Brahm http://www.felipebrahm.com -->