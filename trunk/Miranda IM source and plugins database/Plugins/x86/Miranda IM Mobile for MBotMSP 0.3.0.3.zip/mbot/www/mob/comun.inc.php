<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

include("config.inc.php");

@session_start();

$allowedAvatarExtensions = array('jpg', 'png', 'gif', 'bmp');

define('SESSION_NAME', 'mobile_user');

function printHTML($string) {

		echo $string . "\n";

}

function fixForHTML($str) {

	//i tried using htmlentities() but it messed up unicode strings..
	//maybe here I could just replace "<" and ">"..
	//return $str;
	
	return htmlentities($str, ENT_QUOTES, 'UTF-8');

}


function translateString($str) {

	return ssm_encoding(mb_SysTranslate($str));

}

//define("SENT", "0x02");
//define("READ", "0x04");
define("SENT", 2);
define("READ", 4);
define("READ_UNICODE_UNREAD", 16);
define("SENT_UNICODE", 18);
define("READ_UNICODE", 20);

$statusArray = array(
	ID_STATUS_OFFLINE => translateString("Offline"),
	ID_STATUS_ONLINE => translateString("Online"),
	ID_STATUS_AWAY => translateString("Away"),
	ID_STATUS_DND => translateString("Do Not Disturb"),
	ID_STATUS_NA => translateString("N/A"),
	ID_STATUS_OCCUPIED => translateString("Occupied"),
	ID_STATUS_FREECHAT => translateString("Free For Chat"),
	ID_STATUS_INVISIBLE => translateString("Invisible"),
	ID_STATUS_ONTHEPHONE => translateString("On The Phone"),
	ID_STATUS_OUTTOLUNCH => translateString("Out To Lunch"),
	ID_STATUS_IDLE => translateString("Idle")
);

//convert international characters to "simple" ones
//this is used so that "a" is read as "�" when comparing strings
function icString($string) {

	$a = array("�","�","�","�","�","�");
	$e = array("�","�","�","�");
	$i = array("�","�","�","�");
	$o = array("�","�","�","�","�");
	$u = array("�","�","�","�");
	$n = array("�");

	$string = str_replace($a, 'a', $string);
	$string = str_replace($e, 'e', $string);
	$string = str_replace($i, 'i', $string);
	$string = str_replace($o, 'o', $string);
	$string = str_replace($u, 'u', $string);
	$string = str_replace($n, 'n', $string);
		
	return $string;

}

//encode in UTF8
function ssm_encoding($string) {

	return mb_convert_encoding($string, "UTF-8");

}

function redirectToLocal($file) {

	if(headers_sent()) {
	
		printHTML('ERROR: Could not redirect because headers were already sent.');
		exit;
	
	}

	$host  = $_SERVER['HTTP_HOST'];
	$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = $file;
	if($uri == '.') $uri = '';
	header("Location: http://$host$uri/".INSTALLATION_DIRECTORY."/$extra");
	exit;

}

function requestPost($campo, $applyThisFunction = array()) {

	if(!isset($_POST[$campo]))

		$x = null;

	else {
	
		$x = trim($_POST[$campo]);
		
		if((is_string($x) && strlen($x) == 0) || $x == '')
			$x = null;
			
	}
	
	if(!is_array($applyThisFunction))
		$applyThisFunction = array($applyThisFunction);

	foreach($applyThisFunction as $function)
		$x = $function($x);

	return $x;

}

function requestGet($campo, $applyThisFunction = array()) {

	if(!isset($_GET[$campo]))

		$x = null;

	else {
	
		$x = trim($_GET[$campo]);

		if((is_string($x) && strlen($x) == 0) || $x == '')
			$x = null;
			
	}
	
	if(!is_array($applyThisFunction))
		$applyThisFunction = array($applyThisFunction);

	foreach($applyThisFunction as $function)
		$x = $function($x);

	return $x;

}
?>