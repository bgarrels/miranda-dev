<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

include("inc/comun.inc.php");
?><?php

if(!LOGIN_ENABLED || (isset($_SESSION[SESSION_NAME]) && $_SESSION[SESSION_NAME] == USER)) {
	redirectToLocal('clist.php');
	exit;
}

include("inc/arriba.inc.php");

?>

	<br />

	<div style="font-weight:bold; text-align:center">
		Miranda IM Mobile for MBot/MSP
	</div>
	
	<br />

	<form name="login" action="login.php" method="post">

	<table width="390" border="0" cellspacing="0" cellpadding="0" align="center">

		<tr>
			<td style="font-weight:bold"><?php echo translateString('User'); ?>:</td>
			<td><input type="text" name="user" maxlength="20" size="30" /></td>
		</tr>

		<tr>
			<td style="font-weight:bold"><?php echo translateString('Password'); ?>:</td>
			<td><input type="password" name="pass" maxlength="255" size="30" /></td>
		</tr>

		<?php if(CAPTCHA_ENABLED) { ?>

			<tr>
				<td colspan="2" style="text-align:center">
					&nbsp;<br />
					<span style="font-weight:bold; font-size: 10px"><?php echo translateString('Write the following characters'); ?>:</span> <br />
	
					<?php
					$campoCaptcha = "loginCaptcha";
					require("inc/captcha/captchaForm.inc.php");
					?>
				
				</td>
			</tr>
			
		<?php } ?>

		<tr>
			<td colspan="2" style="text-align:center">
				&nbsp;<br />
				<input type="submit" value="<?php echo translateString('Login'); ?>" />
			</td>
		</tr>
	</table>

	</form>

<?php include("inc/abajo.inc.php"); ?>