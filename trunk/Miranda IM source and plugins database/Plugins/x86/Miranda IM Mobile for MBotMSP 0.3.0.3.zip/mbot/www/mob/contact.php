<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');
?><?php

/*
function messageSendCallback($cid, $result, $param) { 

  if($result == 1) 
  { 
    //here we will store the msg if sent 
    if($body = mt_getvar('/mobile/msg/'.$param)){ 
      mb_EventAdd(mb_CGetProto($cid), $cid, $body, EVENTTYPE_MESSAGE, 0x18, time()); 
    } 
    mb_PUMsg('Message delivered!'); 
  } 
  else 
  { 
    mb_PUMsg('Message not delivered!'); 
  }
  
  mt_delvar('/mobile/msg/'.$param);

}

function messageSend($cid, $body) { 

	$var_id = time(0); 

	if(mb_MsgSend($cid, $body, 0, 'messageSendCallback', $var_id)) 
	 	mt_setvar('/mobile/msg/'.$var_id, $body);
	else
		mb_PuMsg('Failed instantly!');

}
*/

function html_entity_decode_utf8($string)
{
    static $trans_tbl;
   
    // replace numeric entities
    $string = preg_replace('~&#x([0-9a-f]+);~ei', 'code2utf(hexdec("\\1"))', $string);
    $string = preg_replace('~&#([0-9]+);~e', 'code2utf(\\1)', $string);

    // replace literal entities
    if (!isset($trans_tbl))
    {
        $trans_tbl = array();
       
        foreach (get_html_translation_table(HTML_ENTITIES) as $val=>$key)
            $trans_tbl[$key] = utf8_encode($val);
    }
   
    return strtr($string, $trans_tbl);
}

// Returns the utf string corresponding to the unicode value (from php.net, courtesy - romans@void.lv)
function code2utf($num)
{
    if ($num < 128) return chr($num);
    if ($num < 2048) return chr(($num >> 6) + 192) . chr(($num & 63) + 128);
    if ($num < 65536) return chr(($num >> 12) + 224) . chr((($num >> 6) & 63) + 128) . chr(($num & 63) + 128);
    if ($num < 2097152) return chr(($num >> 18) + 240) . chr((($num >> 12) & 63) + 128) . chr((($num >> 6) & 63) + 128) . chr(($num & 63) + 128);
    return '';
}

function messageSend($cid, $body) { 
/*
	echo '<pre>'.$body.'</pre>';
	//$body = html_entity_decode_utf8($body);
	echo '<pre>'.$body.'</pre>';
*/
	if(mb_MsgSend($cid, $body, 1)) {

		//$body = mb_convert_encoding($body, "UTF-8");
		//mb_EventAdd(mb_CGetProto($cid), $cid, $body, EVENTTYPE_MESSAGE, 18, time()); 

	} else
		mb_PuMsg('Message send failed instantly!');

}

if($_SERVER['REQUEST_METHOD'] == "POST") {

	$action = $_POST["action"];
	$cid = $_POST["cid"];
	$body = $_POST["body"];
	
	if($action == "sendMessage")
		//mb_MsgSend($cid, $body, 1);
		messageSend($cid, $body);

}

include("inc/arriba.inc.php");

$cid = $_GET["cid"];

if(isset($_GET["hid"])) {
	$hid = $_GET["hid"];
	if($hid == 0)
		$hid = mb_EventFindLast($cid);
} else
	$hid = mb_EventFindLast($cid);

if(isset($_GET["search"])) {
	$search = $_GET["search"];
	$searchSuccess = false; //turn true if there are >=1 results.
}

if(file_exists('fotos\\status\\'.mb_CGetProto($cid).'\\'.mb_CGetStatus($cid).'.png'))
	$icon = 'fotos/status/'.mb_CGetProto($cid).'/'.mb_CGetStatus($cid).'.png';
else {
	if(file_exists('fotos\\status\\default\\'.mb_CGetStatus($cid).'.png'))
		$icon = 'fotos/status/default/'.mb_CGetStatus($cid).'.png';
	else
		$icon = 'fotos/status/default/unknown.png';
}

$realNick = mb_CGetInfo($cid, 3);
$nick = mb_CGetDisplayName($cid);

printHTML('<table width="100%" border="0" style="border-bottom: 1px solid #000000;">');
printHTML('<tr>');
printHTML('<td><div align="left"><a href="clist.php">'.translateString('CList').'</a> | <a href="contact.php?cid='.$cid.'">'.translateString('Reload').'</a> | <a href="reply.php?cid='.$cid.'">'.translateString('Reply').'</a> | <a href="searchHistory.php?cid='.$cid.'">'.translateString('Search').'</a></div></td>');
printHTML('<td><div align="right"><b>'. fixForHTML(ssm_encoding($nick)) .'</b> <img src="'.$icon.'" /></div></td>');
printHTML('</tr>');
printHTML('</table>');

printHTML('<table width="100%" border="0" style="border-bottom: 1px solid #000000;"><tr>');

printHTML('<td valign="middle" width="100%">');

if(!is_null($realNick) && strcmp($realNick, $nick) != 0)
	printHTML('<div align="right" style="font-size:12px;">'. fixForHTML(ssm_encoding($realNick)) .'</div>');
else
	printHTML('&nbsp;');

$statusMessage = mb_CSettingGet($cid, 'CList', 'StatusMsg');

if($statusMessage !== FALSE && !is_null($statusMessage))
	printHTML('<div align="right" style="font-size:12px;font-style:italic;">'. fixForHTML(ssm_encoding($statusMessage)) .'</div>');
	
printHTML('</td>');

if(AVATARS_ENABLED) {

	printHTML('<td>&nbsp;</td>'); //para que haya un peque�o espacio entre medio

	printHTML('<td><a href="getAvatar.img.php?cid='.$cid.'&q=75&s=-1"><img src="getAvatar.img.php?cid='.$cid.'" style="border: #000000 solid thin;" /></a></td>');
	
}
	
printHTML('</tr></table><br />');

$messages = 0;

if($hid) {

	do {
	
		$msg = mb_EventGetData($hid, 0);
		list($module, $type, $timestamp, $flags, $body) = $msg;

/*
		echo('<pre>');
		print_r($msg);
		echo('</pre>');
*/

		/*if(isset($msg[5]))
			$body = $msg[5];*/

		//IF IS SEARCHING HISTORY...
		if(isset($search)) {
			if(stripos($body, $search) === FALSE)
				continue;
			else
				$searchSuccess = true;
		}

		$date = date(DATE_FORMAT, $timestamp);
		
		if(MARK_MESSAGES_AS_READ && $type == EVENTTYPE_MESSAGE && ($flags != SENT && $flags != SENT_UNICODE))
			mb_EventMarkRead($hid, $cid);

		if($type == EVENTTYPE_FILE) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('Outgoing File Transfer').'</span>';
			else
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('Incoming File Transfer').'</span>';
		
		} else if($type == EVENTTYPE_URL) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('Outgoing URL').'</span>';
			else
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('Incoming URL').'</span>';
				
		} else if($type == EVENTTYPE_CONTACTS) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('Outgoing Contacts').'</span>';
			else
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('Incoming Contacts').'</span>';
		
		} else if($type == EVENTTYPE_ADDED) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('You\'ve added this user to your contact list').'</span>';
			else
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('You\'ve been added to the user contacts list').'</span>';
		
		} else if($type == EVENTTYPE_AUTHREQUEST) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('Outgoing Authorization Request').'</span>';
			else
				$body = '<span style="color:#990000; font-weight:bold; font-style:italic">'.translateString('Incoming Authorization Request').'</span>';
				
		} else { //EVENTTYPE_MESSAGE or anything new :-)

			if($flags != SENT_UNICODE && $flags != READ_UNICODE && $flags != READ_UNICODE_UNREAD)
				$body = ssm_encoding($body);

			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span style="color:#990000; font-weight:bold;">'.nl2br(fixForHTML($body)).'</span>';
			else
				$body = '<span style="color:#000000; font-weight:bold;">'.nl2br(fixForHTML($body)).'</span>';
		
		}
		
		printHTML('<span style="font-size:10px;font-style:italic;">' . fixForHTML($date) . '</span>');
		if(isset($search))
			printHTML('<span style="font-size:10px;font-wight:bold;"><a href="contact.php?cid='.$cid.'&hid='.$hid.'">[+]</a></span>');
		printHTML('<br />' . $body . '<br />');
		
		++$messages;
		
	} while(($hid = mb_EventFindPrev($hid)) && $messages < MESSAGES_PER_PAGE);

	if($hid)
		printHTML('<div align="right"><a href="contact.php?cid='.$cid.'&hid='.$hid . ((isset($search)) ? '&search='.$search : '') .'">&gt;&gt; '.translateString('more').'</a></div>');
	else if(isset($search) && !$searchSuccess)
		printHTML('<span style="font-weight:bold;">'.translateString('No such items').'.</span><br />');
	else
		printHTML('<div align="right"><a href="contact.php?cid='.$cid . ((isset($search)) ? '&search='.$search : '') .'">&gt;&gt; '.translateString('go to first message').'</a></div>');

} else

	printHTML('<br /><span style="font-weight:bold;">'.translateString('No messages available for this contact').'.</span><br />');
	
include("inc/abajo.inc.php");

?>