<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

//When replying a message, use this charset.
//To reply in spanish (�, �, �, �, �, �, etc.) use 'iso-8859-1'.
//I haven't been able to make it work for Russian characters... If you find some workaround, please contact me through the Miranda IM forums or at my webpage: http://www.felipebrahm.com
define('CHARSET_REPLY', 'iso-8859-1');

//Autorefresh/reload contact list (in SECONDS). Set to -1 to disable.
define('AUTOREFRESH_CONTACTLIST', -1);

//Autorefresh/reload message window (in SECONDS). Set to -1 to disable.
define('AUTOREFRESH_MESSAGES', -1);

//Number of contacts to show per page.
define('CONTACTS_PER_PAGE', 100);

//Number of messages to show per page.
define('MESSAGES_PER_PAGE', 10);

//How to show date when reading messages.
/*
Examples:
'F j Y, g:i:s A' -> September 25 2006, 8:03:49 PM
'y-m-d, g:i:s a' -> 06-09-25, 8:03:49 pm

More information at: http://www.php.net/date
*/
define('DATE_FORMAT', 'y-m-d, g:i:s a');

//Mark messages as read when reading messages from this script.
//You can set this to true or false.
define('MARK_MESSAGES_AS_READ', true);

/* BEGIN LOGIN CONFIGURATION */
define('LOGIN_ENABLED', true);

define('USER', 'user');
define('PASSWORD', 'pass');

define('CAPTCHA_ENABLED', false);
/* END LOGIN CONFIGURATION */

//do not end with slash
define('INSTALLATION_DIRECTORY', 'mob');

/* BEGIN AVATARS CONFIGURATION */

/*

In order to enable avatars, you must first install GD extension.
Follow this steps:

- Copy php_gd2.dll to /mbot/extensions/
  php_gd2.dll should be included in this zip. If not, then please download Miranda Mobile again
  from the Miranda IM File Listing.

- Open /mbot/config/mbot.xml and add/change this line:

  -----------------------------------------------------------
	<add_php>

		...

		<!-- extensions go here !-->

		...

		<extension>php_gd2.dll</extension> <!-- THIS LINE! -->

		...		

	</add_php>
  -----------------------------------------------------------

- Now change AVATARS_ENABLED to true, restart miranda and you are ready to see avatars :-) 

*/
define('AVATARS_ENABLED', false);

//Maximum height/width of avatar.
define('AVATAR_MAX_SIZE', 90);

define('AVATAR_QUALIY', 50);

define('NO_AVATAR_FILE', 'fotos/other/noavatar.jpg');

/* END AVATARS CONFIGURATION */

?>