<?php
/*
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Español: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');
?><?php

/* begin APPLY CHANGES */

if(isset($_POST['setStatus'])) {

	$protocols = mb_SysEnumProtocols();
	
	foreach($protocols as $protocol) {

		$currentStatus = mb_PGetMyStatus($protocol);
		$newStatus = requestPost('status_'.$protocol);

		if($newStatus != null && $newStatus != $currentStatus)
			mb_PSetMyStatus($protocol, $newStatus);

		$newNick = requestPost('nick_'.$protocol);

		if($newNick != null)
			mb_SysCallProtoService($protocol, "/SetNickname", 0, $newNick);

		$newStatusMessage = requestPost('statusMessage_'.$protocol);

		if($newStatusMessage != null)
			mb_PSetMyAwayMsg($protocol, $newStatusMessage);
	
	}
	
	redirectToLocal('clist.php');
	exit;

}

/* end APPLY CHANGES */

include("inc/arriba.inc.php");

$icon = 'fotos/status/default/'.ID_STATUS_ONLINE.'.png';

printHTML('<table width="100%" border="0" style="border-bottom: 1px solid #000000;"><tr>');
printHTML('<td><div align="left">');
printHTML('<a href="clist.php">'.translateString('Back').'</a>');
printHTML('</div></td>');
printHTML('<td><div align="right" style="font-weight:bold;">Miranda IM <img src="'.$icon.'" /></div></td>');
printHTML('</tr></table><br />');

$protocols = mb_SysEnumProtocols();

printHTML('<form name="status" action="status.php" method="post">');

foreach($protocols as $protocol) {

	if($protocol == 'Weather')
		continue;

	printHTML('

				<div style="font-weight:bold">'.$protocol.'</div>

				<table border="0" cellspacing="0" cellpadding="3">
				
					<tr>
					
						<td>
							Status:
						</td>
			
						<td>
						
							<select name="status_'.$protocol.'">
				');
				
	$myStatus = mb_PGetMyStatus($protocol);

	reset($statusArray);
	while (list($statusValue, $statusName) = each($statusArray)) {

		$selected = '';
		if($statusValue == $myStatus)
			$selected = ' selected="selected"';

		printHTML('<option value="'.$statusValue.'"'.$selected.'>'.$statusName.'</option>');

	}

	printHTML('
							</select>
							
						</td>
						
					</tr>
					
					<tr>
						<td>
							Nick:
						</td>
						<td>
							<input type="text" name="nick_'.$protocol.'" />
						</td>
					</tr>
				
					<tr>
						<td>
							Status Message:
						</td>
						<td>
							<input type="text" name="statusMessage_'.$protocol.'" />
						</td>
					</tr>

				</table>
						
				<br />

				');

}

printHTML('
			<div style="text-align:center">
				<input type="submit" name="setStatus" value="'. translateString('Apply Changes') .'" />
			</div>
			');

printHTML('</form>');

include("inc/abajo.inc.php");

?>