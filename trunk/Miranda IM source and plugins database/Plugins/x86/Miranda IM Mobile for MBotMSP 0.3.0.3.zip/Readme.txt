* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*
*  Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*  Released 25.09.2006
*  ICQ#50566818
*  My Personal Webpage: http://www.felipebrahm.com
*  My Company's Webpage: http://www.soufrag.cl
*  Miranda IM: http://www.miranda-im.org
*  Miranda IM en Espa�ol: http://www.mi-miranda.org
*
*  CONTACT ME AND CHECK FOR UPDATES AT felipebrahm.com OR miranda-im.org
*
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

DESCRIPTION

	Read and reply your Miranda IM messages online from your PDA, PSP (Play Station Portable)
	or mobile phone using an internet connection and a web browser.

	Miranda IM must be running on your computer in order for you to use this script from
	another device.

	You may also use this to remotely read and reply to your messages from another computer
	using any web browser.

INSTALLATION

	First, you must have Miranda IM and MBot/MSP (Miranda Scripting Plugin) installed.
	You may find more information about MBot/MSP here:
	http://addons.miranda-im.org/details.php?action=viewfile&id=1584
	
	Then just unzip this script in the Miranda IM folder.
	
	You'll be able to test it entering this in your browser: http://localhost:8081/mob/
	If you want to access from another computer, you must use: http://YOUR_IP:8081/mob/
	
	I recommend you to register for a free account at no-ip.org or dyndns.com.
	After doing this, you'll be able to access Miranda through
	http://YOUR_NICKNAME.no-ip.org:8081/mob/ without having to know your IP.
	
	Remember you must enable MBot/MSP's Webserver at:
	Miranda IM Options > Plugins > MBot > Enable WWW Server.
	
	You must install php_mbstring.dll extension. Also, if you want to display avatars you'll need php_gd2.dll.
	Both files should be included with this ZIP. If not, then you should download the PHP package from php.net
	(IMPORTANT: you MUST use the same version as your php5ts.dll)
	
		Follow this steps:
		
		- Copy php_mbstring.dll and php_gd2.dll to /mbot/extensions/
		
		- Open /mbot/config/mbot.xml and add/change these lines:
		
		  -----------------------------------------------------------
			<add_php>
		
				...
		
				<!-- extensions go here !-->
		
				...
		
				<extension>php_mbstring.dll</extension> <!-- THIS LINE! -->
				<extension>php_gd2.dll</extension> <!-- THIS LINE! -->
		
				...		
		
			</add_php>
		  -----------------------------------------------------------
		
		- Now if you want to display avatars, open /inc/config.inc.php and change AVATARS_ENABLED to true.

CONFIGURATION

	You may change some settings of this script at:
	/Miranda IM/mbot/www/mob/inc/config.inc.php
	
	You may set a PASSWORD using MBot/MSP's webserver built-in password protection.
	Open the file Miranda IM/mbot/config/mbot.xml
	and then add/change the following code between <httpd> tags:
	----------------------------------------------------------------------
	<httpd>
	
		...
	
		<dirs>
			<dir path="/mob" auth_req="1" user="YOUR_USERNAME" pass="YOUR_PASSWORD" ip_mask="*"/>
		</dirs>
		
		...
		
	</httpd>
	----------------------------------------------------------------------

QUESTIONS?

	If you have any questions you can post a message at:
	http://forums.miranda-im.org/showthread.php?t=11013
	
	You may contact me at felipebrahm.com.
