#define __FILEVERSION_STRING        2,0,4,14
#define __VERSION_STRING            "2.0.4.14"
#define __VERSION_DWORD             PLUGIN_MAKE_VERSION(2, 0, 4, 14)

