/*
Copyright (C) 2006-2007 Scott Ellis
Copyright (C) 2007-2010 Jan Holub

This is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this file; see the file license.txt.  If
not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  
*/

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the POPUPS2_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// POPUPS2_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef TIPPER_EXPORTS
#define TIPPER_API __declspec(dllexport)
#else
#define TIPPER_API __declspec(dllimport)
#endif

#ifndef _UNICODE
// {63FD0B98-43AD-4c13-BD6E-2B550B9B20EF}
#define	MIID_TIPPER { 0x63fd0b98, 0x43ad, 0x4c13, { 0xbd, 0x6e, 0x2b, 0x55, 0xb0, 0x9b, 0x20, 0xef } }
#else
// {8392DF1D-9090-4f8e-9DF6-2FE058EDD800}
#define MIID_TIPPER	{ 0x8392df1d, 0x9090, 0x4f8e, { 0x9d, 0xf6, 0x2f, 0xe0, 0x58, 0xed, 0xd8, 0x00 } }
#endif

/////////////////////
///// This service is NOT implemented by tipper - it is to be implemented by plugins that extend the basic away message services
///// so that tipper has a common interface to use
////////////////////

//-------------------------------
//wParam = (char *)protocol name
//lParam = 0
//returns (char *) current status message for a protocol or NULL if there is none
//remember to mir_free the return value
#define MS_SA_GETPROTOSTATUSMSG  "SimpleAway/GetProtoStatusMessage"