/*
Copyright (C) 2006-2007 Scott Ellis
Copyright (C) 2007-2010 Jan Holub

This is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this file; see the file license.txt.  If
not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  
*/

#pragma once

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#ifndef WINVER				// Allow use of features specific to Windows XP or later.
#define WINVER 0x0501		// Change this to the appropriate value to target other versions of Windows.
#endif

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

#ifndef _WIN32_WINDOWS		// Allow use of features specific to Windows 98 or later.
#define _WIN32_WINDOWS 0x0410 // Change this to the appropriate value to target Windows Me or later.
#endif

#ifndef _WIN32_IE			// Allow use of features specific to IE 6.0 or later.
#define _WIN32_IE 0x0600	// Change this to the appropriate value to target other versions of IE.
#endif

#define MIRANDA_VER		0x0800

#include <m_stdhdr.h>

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>
#include <process.h>
#include <commctrl.h>
#include <stddef.h>
#include <time.h>
#include <winsock.h>
#include <windowsx.h>

#include <win2k.h>
#include <newpluginapi.h>
#include <statusmodes.h>
#include <m_database.h>
#include <m_langpack.h>
#include <m_options.h>
#include <m_system.h>
#include <m_idle.h>
#include <m_skin.h>
#include <m_clui.h>
#include <m_clist.h>
#include <m_clc.h>
#include <m_cluiframes.h>
#include <m_awaymsg.h>
#include <m_utils.h>
#include <m_protocols.h>
#include <m_protosvc.h>
#include <m_protomod.h>
#include <m_contacts.h>
#include <m_icolib.h>
#include <m_fontservice.h>
#include <m_avatars.h>
#include <m_icq.h>
#include <m_imgsrvc.h>

#include "resource.h"
#include "docs\m_tipper.h"
#include "sdk\m_ersatz.h"
#include "sdk\m_fingerprint.h"
#include "sdk\m_flags.h"
#include "sdk\m_folders.h"
#include "sdk\m_newawaysys.h"
#include "sdk\m_metacontacts.h"
#include "sdk\m_variables.h"
#include "sdk\m_updater.h"
#include "sdk\m_smileyadd.h"
#include "sdk\m_simpleaway.h"

#define MODULE					"Tipper"
#define MODULE_ITEMS			"Tipper_Items"

#define DEFAULT_SKIN_FOLDER		"skins\\Tipper"

extern HMODULE hInst;
extern PLUGINLINK *pluginLink;
extern HANDLE mainThread;

extern HFONT hFontTitle, hFontLabels, hFontValues, hFontTrayTitle;
extern COLORREF	colTitle, colLabels, colBg, colValues;

extern int iCodePage;
extern char szMetaModuleName[256];

extern MM_INTERFACE mmi;
extern LIST_INTERFACE li;
extern FI_INTERFACE *fii;

extern int ReloadFont(WPARAM wParam, LPARAM lParam);