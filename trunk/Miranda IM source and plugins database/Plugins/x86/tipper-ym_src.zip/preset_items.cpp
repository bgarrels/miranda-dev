/*
Copyright (C) 2006-2007 Scott Ellis
Copyright (C) 2007-2010 Jan Holub

This is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this file; see the file license.txt.  If
not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  
*/

#include "common.h"
#include "preset_items.h"

PresetItem presetItems[PRESET_ITEM_COUNT] = 
{
	LPGENT("Birthday"), LPGENT("Birthday:"), _T("%birthday_date% (%birthday_age%) @ Next: %birthday_next%"), 11, 12, 13,
	LPGENT("Client"), LPGENT("Client:"), _T("%raw:/MirVer%"), -1, -1, -1,
	LPGENT("Email"), LPGENT("Email:"), _T("%raw:/e-mail%"), -1, -1, -1,
	LPGENT("Gender"), LPGENT("Gender:"), _T("%gender%"), 0, -1, -1,
	LPGENT("Homepage"), LPGENT("Homepage:"), _T("%raw:/Homepage%"), -1, -1, -1,
	LPGENT("Identifier"), LPGENT("%sys:uidname|UID^!MetaContacts%:"), _T("%sys:uid%"), -1, -1, -1,
	LPGENT("Idle"), LPGENT("Idle:"), _T("%idle% (%idle_diff% ago)"), 4, 5, -1,
	LPGENT("IP"), LPGENT("IP:"), _T("%ip%"), 2, -1, -1,
	LPGENT("IP internal"), LPGENT("IP internal:"), _T("%ip_internal%"), 3, -1, -1,
	LPGENT("Last message"), LPGENT("Last message: (%sys:last_msg_reltime% ago)"), _T("%sys:last_msg%"), -1, -1, -1,
	LPGENT("Listening to"), LPGENT("Listening to:"), _T("%raw:/ListeningTo%"), -1, -1, -1,
	LPGENT("Name"), LPGENT("Name:"), _T("%raw:/FirstName|% %raw:/LastName%"), -1, -1, -1,
	LPGENT("Number of received messages"), LPGENT("Number of msg [IN]:"), _T("%sys:msg_count_in%"), -1, -1, -1,
	LPGENT("Number of sended messages"), LPGENT("Number of msg [OUT]:"), _T("%sys:msg_count_out%"), -1, -1, -1,
	LPGENT("Status"), LPGENT("Status:"), _T("%Status%"), 1, -1, -1,
	LPGENT("Status message"), LPGENT("Status message:"), _T("%sys:status_msg%"), -1, -1, -1,
	LPGENT("XStatus title"), LPGENT("XStatus title:"), _T("%xsname%"), 6, -1, -1,
	LPGENT("XStatus text"), LPGENT("XStatus text:"), _T("%raw:/XStatusMsg%"), -1, -1, -1,
	LPGENT("[jabber.dll] Activity title"), LPGENT("Activity title:"), _T("%raw:AdvStatus/?dbsetting(%subject%,Protocol,p)/activity/title%"), -1, -1, -1,
	LPGENT("[jabber.dll] Activity text"), LPGENT("Activity text:"), _T("%raw:AdvStatus/?dbsetting(%subject%,Protocol,p)/activity/text%"), -1, -1, -1,
	LPGENT("[seenplugin.dll] Last seen time"), LPGENT("Last seen time:"), _T("%lastseen_date% @ %lastseen_time%"), 7, 8, -1,
	LPGENT("[seenplugin.dll] Last seen status"), LPGENT("Last seen status:"), _T("%lastseen_status% (%lastseen_ago% ago)"), 9, 10, -1,
	LPGENT("[weather.dll] Condition"), LPGENT("Condition:"), _T("%raw:Current/Condition%"), -1, -1, -1,
	LPGENT("[weather.dll] Humidity"), LPGENT("Humidity:"), _T("%raw:Current/Humidity%"), -1, -1, -1,
	LPGENT("[weather.dll] Max/Min temperature"), LPGENT("Max/Min:"), _T("%raw:Current/High%/%raw:Current/Low%"), -1, -1, -1,
	LPGENT("[weather.dll] Moon"), LPGENT("Moon:"), _T("%raw:Current/Moon%"), -1, -1, -1,
	LPGENT("[weather.dll] Pressure"), LPGENT("Pressure:"), _T("%raw:Current/Pressure% (%raw:Current/Pressure Tendency%)"), -1, -1, -1,
	LPGENT("[weather.dll] Sunrise"), LPGENT("Sunrise:"), _T("%raw:Current/Sunrise%"), -1, -1, -1,
	LPGENT("[weather.dll] Sunset"), LPGENT("Sunset:"), _T("%raw:Current/Sunset%"), -1, -1, -1,
	LPGENT("[weather.dll] Temperature"), LPGENT("Temperature:"), _T("%raw:Current/Temperature%"), -1, -1, -1,
	LPGENT("[weather.dll] Update time"), LPGENT("Update time:"), _T("%raw:Current/Update%"), -1, -1, -1,
	LPGENT("[weather.dll] UV Index"), LPGENT("UV Index:"), _T("%raw:Current/UV% - %raw:Current/UVI%"), -1, -1, -1,
	LPGENT("[weather.dll] Visibility"), LPGENT("Visibility:"), _T("%raw:Current/Visibility%"), -1, -1, -1,
	LPGENT("[weather.dll] Wind"), LPGENT("Wind:"), _T("%raw:Current/Wind Direction% (%raw:Current/Wind Direction DEG%)/%raw:Current/Wind Speed%"), -1, -1, -1
};

PresetSubst presetSubsts[PRESET_SUBST_COUNT] = 
{
	_T("gender"), DVT_PROTODB, NULL, "Gender", 5,
	_T("Status"), DVT_PROTODB, NULL, "Status", 1,
	_T("ip"), DVT_PROTODB, NULL, "IP", 7,
	_T("ip_internal"), DVT_PROTODB, NULL, "RealIP", 7,
	_T("idle"), DVT_PROTODB, NULL, "IdleTS", 2,
	_T("idle_diff"), DVT_PROTODB, NULL, "IdleTS", 3,
	_T("xsname"), DVT_PROTODB, NULL, "XStatusName", 17,
	_T("lastseen_date"), DVT_DB, "SeenModule", NULL, 8,
	_T("lastseen_time"), DVT_DB, "SeenModule", NULL, 10,
	_T("lastseen_status"), DVT_DB, "SeenModule", "OldStatus", 1,
	_T("lastseen_ago"), DVT_DB, "SeenModule", "seenTS", 3,
	_T("birthday_date"), DVT_PROTODB, NULL, "Birth", 8,
	_T("birthday_age"), DVT_PROTODB, NULL, "Birth", 9,
	_T("birthday_next"), DVT_PROTODB, NULL, "Birth", 12
};