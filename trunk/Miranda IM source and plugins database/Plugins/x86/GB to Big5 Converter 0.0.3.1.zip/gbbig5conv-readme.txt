GB to Big5 Converter  v0.0.3.1
==============================

This plugin converts incoming and outgoing messages between Chinese GB and BIG5
encoding.  Each contact can have a different conversion setting.  This plugin
can also convert nickname display and database settings. However, the conversion
of nickname will erase your custom nickname.

This plugin will not work when unicode messaging dialog is used in conjunction
with unicode-aware protocol such as MSN.

This is useful for using QQ in a Traditional Chinese machine by setting:
	Outgoing:	Big5 (trad/simp) -> GB (simp)
	Incoming:	GB (trad/simp) -> Big5 (trad)
This can also be used for using ICQ on a non-unicode conversation window:
	Outgoing:	from Trad to Simp machine: Big5 (trad/simp) -> GB (simp)
			from Simp to Trad machine: GB (trad/simp) -> Big5 (trad)
	Incoming:	No Conversion
This plugin can also convert Big5 coded simplified characters into its traditional
form, useful when the machine does not have Unicode-At-On installed and cannot
view these character correctly.  Conversion of outgoing messages is not recommended.

Note: Not tested for any other protocols.


Installation
============
Use Miranda installer, or extract the dll and both dat files into Miranda plugin
folder.


Translation
===========
[Chinese Encoding]
[Conversion Settings]
[Incoming Messages]
[Outging Messages]
[Contact List]
[No Conversion]
[GB (simp/trad)\nto\nBig5 (trad)]
[Big5 (simp/trad)\nto\nGB (simp)]
[Big5 (simp/trad)\nto\nBig5 (trad)]

[Cannot find translation mapping file!  Please put conv_%s.dat in the plugin directory.]
[Chinese Big5/GB Conversion]
[Convert Database Settings]


History
=======
Version 0.0.3.1		2005/05/16
 - Service function added for the conversion

Version 0.0.3.0		2005/03/02
 - Support conversion of big5 simplified characters into its traditional form
 - Auto-detection and notification if the dat file is not found
 - Bug fix on crashes when opening the setting dialog
 - Fixes numerious translation errors in the dat file

Version 0.0.2.0		2005/01/16
 - Support conversion of database settings
 - Support conversion of nicknames on contact list

Version 0.0.1.1		2004/11/20
 - Changes in the mapping files (add about 5000 new words and fix some old ones)
 - Slightly change the restriction of the words to be translated.

Version 0.0.1.0		2004/11/15
 - Expands and update both big5 and gb mapping
   (now support Simp characters in big5; Trad characters in gb)
 - Add conversion setting window, able to choose conversion method
 - Reduce mapping file size

Version 0.0.0.1
 - Initial release, design for QQ (out: Big5 -> GB, in: GB -> Big5)
