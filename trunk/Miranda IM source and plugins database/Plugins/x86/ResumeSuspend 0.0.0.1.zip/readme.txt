"Simple Floater" for Miranda IM
----------------------------------------------

 This plugin displays your status and received event in a small window for easy
and quick access, like ICQ Status Floating. Already exists "Status Floater"
plugin, but this plugin competition with ATOK(Japanese IME). This plugin is for
ATOK user.

 If you want "Floating Contact", please use "Status Floater" or "Floating#SL".



LeftButton DoubleClick:
if you have received events(message/file/url), open event.
otherwise Show/hide ContactList window.

RightButton Click:
Open Status Menu.



History
--------------
v0.0.0.4 - Fixed: Move option from the main menu to the miranda's option.
           Added: some options
           (Borderline ON/OFF,Icon blink ON/OFF,Text Font/Color,
            Select action when single/doule/right click)
v0.0.0.3 - Fixed: Error dialog when sometimes clicking on floater.
v0.0.0.2 - Added: option dialog
           (Show/Hide status text,Width,Background Color,Alpha)
v0.0.0.1 - First Release.



 I am not good at speaking & writing English, and very sorry about my poor
English.

Copyright (C) 2002 Yukiha
