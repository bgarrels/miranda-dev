		-================================-
		 FDD Notify plugin for Miranda-IM
		-================================-


Copyright (C) 2005	TioDuke (tioduke@yahoo.ca)


Description
-----------
This plugin for Miranda-IM notifies user of specified events (as incoming messages, incoming files, incoming URLs or other events). This plugin is based on keyboardnotify by Martin �berg/Std/TioDuke (me).

It has many options allowing:
  a) To select on which events to react
  b) Under which conditions (eg: fullscreen mode, ScreenSaver running, workstation locked)
  c) To act only if the protocol receiving the event is under specified status
  d) For message events you can choose to be notified if the message window is open or not
  e) A notification feature allowing to be notified of pending events (unopened events) after specified period of time
  f) To select method for stopping the blinking (after x secs, if Miranda is re-attended, if Windows is re-attended, if all notified events are opened or when the notify conditions end)
  g) To select initial delay and speed and a preview button

It was designed to be flexible and performing different tasks.
It also provides a service to allow third party plugins use its notifier capabilities.


Installation
------------
First you have to copy fddnotify.dll into plugins folder. Now, if you are running on a non-NT system (as Windows 98/ME) you are done. If not you will need a driver to use the plugin (if the driver is not installed when running Miranda with this plugin you will receive a message box at startup warning you about it and the plugin will simply do nothing -neither bad nor good-, not even show its option page). To continue with installation you will need two files I have packed inside the zip: porttalk.sys, the driver, and PTInstaller, a console application that will install the driver for you and make it available on system startup (by writing a few settings in Windows' Registry). The plugin won't try to install it: you need the installer (or any other mean) to do that. Take into consideration that you will need administrator rights to install the driver. Now, both the Win98 or the WinNT user will have to restart Miranda and configure the Options the way yhey want. That's it, that's all.


Options
-------
Options page Options->Plugins->Floppy Flash. Tabbed: Protocols, Rules (when) and Flashing (how).

Here there are some explanations on features on the Options' Page.

Protocols tab:
Protocols to check: check/uncheck the protocols you want this plugin to work with.

Rules tab:
Events to react on:
   - Incoming messages: check this if you want to be notified on incoming message events
   - Incoming files: check this if you want to be notified on incoming file events
   - Incoming URLs: check this if you want to be notified on incoming URL events
   - Everything else: check this if you want to be notified on incoming events that are not messages, files or URLs (like authorization requests or you-were-added events).
Message event only:
   - Blink if message window is open: check it if you want to be notified of incoming messages even if that contact's message window is open, if you uncheck it you will only be notified of incoming messages if the window is closed
   - ... and not in foreground: check this option if you want to be notified if the message window is open and that window is not focused
   - Only if last is xx seconds old: if you check this option the plugin will not notify you of new messages until xx seconds have passed after the last message for that contact was sent/received
Notify when:
   - Full screen mode: check this if you want to be notified when you are on full screen mode (screen saver excluded form the full screen classification, although it is a special type of full screen application)
   - Screen saver is running: check this if you want to be notified while screen saver is running
   - Workstation is locked (2000/XP): check this if you want to be notified when your workstation is locked (only for Windows NT systems)
   - All other situations: check this if you want to be notified when neither you are in full screen mode, nor the screen saver is running and nor the workstation is locked.
   Note on 'notify when': to be notified on ANY condition (always) you will have to check them all.
Notify if status is:
   - Online, Away, NA, etc: check each status for which you want notification to be turn on. Checking all means on all statuses.
   Note on 'notify if status is ...': The plugin will check these options against the event's protocol status, this means that if you choose to be notified only when you are online and at a certain moment you are online in one protocol but away in another, then you will be notified on events for the first one only.
Flash until:
   - nn seconds: if this option is selected leds will flash for the amount of seconds you have specified
   - Miranda/Windows is re-attended: if this option is selected flashing will stop when either the mouse or a key is pressed on any of Miranda/Windows's windows
   - Events are opened: if this option is selected flashing will stop when there will be no more pending events (for the selected protocols, of course)
   - End of 'notify when' conditions: if this option is selected the flashing will stop when all situations checked under 'notify when' (and also the status conditions) ceased to be true.
   Note on 'End of notify when conditions': this means that if you select ALL the 'notify when' situations and all the statuses (e.g. always) flashing will not stop (you may still stop it manually by pressing the Pause key).
   This option is particluarly usuful if you want to be notified only when you are in full screen mode (for example) and you want the flashing to stop when you change to non full screen mode. The same applies to all the other situations.
Pending Events:
   - Remind me every xx minutes: this option will make the plugin check for unopen events every xx minutes and start notifying if any is found and the 'notify when' and the status conditions are met. If you don't want this option, just specify 0 minutes and it will be disabled.
   This option is usuful if you, for example, select to be notified on workstation locked and then to stop the flashing using 'end of notify conditions'. If you do not open the event that generated the flashing (e.g. leaving the event pending) then when you lock your computer back the flashing will begin again.
   Note that if on your messaging plugin you have enabled the option to pop up the message window, then the reminder won't alert you of messages (as they will be promptly opened) but it will still work for files/URLs/others.

Flashing tab:
Wait before starting flashing:
   - nn seconds: specify the amount of time for the plugin to wait before starting flashing (0 means do not wait).
Speed: You may select between 5 different speeds that go from really slow to really fast.
Preview button: This button will allow you to test your flashing settings. Since v.0.0.1.0 it is an on/off button (thank you tweety for the definition), which means that it will flash when it is on and stop when it is off.


Warning
-------
Playing with the floppy motor (to turn the led on the plugin turns on and off the motor, led is connected to that function in floppy's architecture) is not a funny thing, so be aware that if you abuse hardware damage could arrive. That's why I recommend you to use a low speed, set maximum time option to stop blinking and use a high delay time (so that, the floppy will blink only on necessary situations).
Having said that, the only remaining thing to tell is: enjoy!


Thanks
------
- Pete for the numerous patches he sent, actively helping to improve the code and functionality
- UnregistereD for great help in solving problem with Windows activity detection
- Slacktarn, Sir_qwerty and Tweety for giving great help with ideas (most of the new features included in this plugin were suggested by them) and testing
- The authors of AAA, PopUp+, KeyScrollNotify, original KeyboardNotify, Neweventnotify, IEView, NGEventNotify for part of their code used in this plugin.
- Miranda IM developers for this amazing program
- all other people from Miranda community

History
-------
0.0.2.3:
    [!] Added support for Miranda 0.8.x.x.
0.0.2.2:
    [!] Fixed problem while trying to detect if message window is in foreground
    [*] Improved ListView control handling
    [*] Changed the default values (for the sake of new users)
    [*] More code optimization.
0.0.2.1:
    [+] Support for Update plugin.
0.0.2.0:
    [+] New 'notify when' option: while defined programs are running (just like gamerstatus)
    [+] Extended the API to add two new services to disable and re-enable keyboards notifications (for use by bosskey plugin)
    [!] Minor source fixes.
0.0.1.2:
    [!] Fixed some compatibility issues with nconvers++ (thank you donatas for your help).
0.0.1.1:
    [!] Fixed problem with Windows' activity detection under Win9X when using other plugins that do the same.
    [!] Fixed crash caused by incoming authorisation requests when metacontacts was enabled.
0.0.1.0:
    [+] Applied pete's patches (thank you very much for your great work)
        - Use of GetLastInputInfo when possible for detecting Windows' activity
        - Made Windows' mouse hooks also aware of mouse clicking
        - Made Miranda re-attended option react on windows restoring and ignoring mouse hovering an unfocused window
        - New option for message events to avoid blinking if message window is focused
        - Made the plugin handle metacontact's special issues
    [!] Use of the new message API for windows detection when possible
    [+] New message event option to check last message timestamp (requested by D46MD)
    [+] Possibility of choosing more than one flash until option at the same time
    [+] Possibility of selecting/unselecting protocols (requested by tweety, usuful to avoid flashing on some protocols as rss)
    [!] Changed behaviour of Preview button to make it independent of the rules' options.
    [!] Fixed Metacontacts recognition in checking and counting of pending events (thank you NirG for finding the problem)
    [!] Fixed problems with multiple instances of the plugin running (thank you tweety for reporting and testing).
    [+] New plugin API (thank you CriS for your ideas and great help)
    [!] Added Offline status to status check list (thank you Slaktarn for finding it).
    [!] Fixed problem with first message in Metacontacts recognition while checking for pending events (thank you again NirG)
0.0.0.3:
    [!] scriver's message window detection (thanks D46MD for your great help)
    [!] corrected 'flash until' checking accordingly to pete's patch (thank you)
0.0.0.2:
    [!] fixed nconvers++'s message window detection and checked window detection for srmm, scriver, sramm and srmm_mod
    [!] checking of 'notify when' and statuses added for API events
0.0.0.1:
    First version (using keyboardnotify 1.5.1.0 as a model)


License
-------
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=====================================================================
