The HMTrack.dll is a Miranda plugin. It's made to fit with Miranda 0.6 and upwards.
How far that will be, I have no idea. That depends on the MSN.dll plugin for Miranda.
At the moment, it supports MSN.dll v.0.6.0.1

The basic idea in the HMTrack plugin is to patch the msn plugin in memory, to add
functionality. However, patching is never safe, so the HMTrack plugin might make
Miranda unstable. Bear this in mind.

What HMTrack does:
- patches the msn modules loaded by Miranda
- creates a number of contacts equal to the number of msn modules loaded (note: it's
  actually equal to the number of msn modules found, that seem to be connected with a
  hotmail account)
- sets the name of the contacts according to the number of unread mail in the hotmail
  inbox

What HMTrack doesn't yet do, but might some day do (so don't ask for it, I already know):
- Support IcoLib
- Store titles and senders of mail received, for use with mtooltip

Features:
- decide what counts as unread mail
- set the contact name using variables (%E% for emailaddress, %N% for count of unread mail)
- have contact go offline, when there's no unread mail
- doubleclick contact to go hotmail inbox

Installing the plugin:
- just place the HMTrack.dll in your miranda/plugins dir.

NOTE: THIS IS A WORK IN PROGRESS. HENCE, IT MAY BE UNSTABLE, AND THINGS MAY BE
ONLY HALF IMPLEMENTED. KEEP THIS IN MIND WHEN TESTING IT.

Changes from 0.0.1.7 to 0.0.1.8:
- fixed a bug that could crash a clean profile
- updated HMTrack to work with Miranda 0.7 build #1

Questions and bug reports can be mailed to:
fake51@yahoo.com

NOTE: hmtrack.dll will create a file called hmtrack-log.txt whenever it has a problem. In
this file it will store the date and time, as well as a description of what went wrong. In
addition to this, it might also (depending upon the error) save the contents of an array it
creates. In this array are stored names of msn modules and their corresponding email-addresses.
Now, the log-file is of interest to me in the process of finding errors, but I really don't
have any interest in the email-addresses. Hence, if you experience a problem and wouldn't mind
sending me the log file, you can just open the hmtrack-log.txt first, wipe the first part of
the email-address (or all of it, if you're really paranoid - I just need to know that the right
email-address was actually saved by the program, so please tell me), and then send the log file
to me.
 If you want to really help me find bugs, please also send some system specifications, otherwise
looking for bugs is pretty much needle in a haystack. And Miranda is quite a haystack, mind you.
 Thanks.

Here are some of the errors and things you can do to try to solve them:
Version of Miranda less than 0.4
- Upgrade
One instance of HMTrack is already running
- Find the double and delete it. Running two instances won't do anything
Failed to allocate memory for array
- Make sure that there's enough free mem to run Miranda. HMTrack should use very little mem, so
  generally this problem shouldn't come too often
Failed to create array of loaded msn protocols
- Make sure you've got msn.dll v.0.4.3.0 minimum
Failed to patch protocols
- Make sure you've got msn.dll v.0.4.3.0 minimum

Other troubleshooting:
- In case you've had a previous version of HMTrack installed, you might want to delete some of the previous
  settings. If you can find out how to handle DBEditor, that is. Otherwise, just try and see if it works like
  (you think) it should.
- Specifically, under settings, find the group called HMTRACK and delete it.
- Apart from that, if you don't like the icons of HMTrack, you can change yourself, if you feel like it. It
  involves digging in the database, though, so you should think twice. How to:
  - Locate the group Icons under settings. Then locate the entries HMTRACK40071, HMTRACK40072, and HMTRACK40073.
  - Set the values to that of some other icons you like (hint: HMTRACK40071 is offline, HMTRACK40072 is online).

For copyright info, look at the accompanying license-hmtrack.txt