UpTime 0.1.1.0

This plug-in adds an option called "Windows Uptime" to the Miranda
main menu. Upon clicking on it, you will get a message box showing
the number of days, hours, minutes and seconds that have elapsed
since your Windows was started.

Since there is an OS-specified limit to the time counter, however,
it will reset after about 49.5 days of uptime. I _do_ hope that
your OS is stable (and up-to-date) enough for this "limit" to be
an actual problem for you ;).

Changelog:
0.1.1.0: Got rid of the "copy to clipboard" function... at last.
0.1.0.2: Another quick bugfix.
0.1.0.1: Fixed the "negative time" bug that occured after ~24.5 days.
0.1.0.0: First release.

Notes:
This plug-in was initially an experimental one so I could learn
about Miranda's API and start coding for it. To be honest, I
wrote it in a hurry and never thought people would take it that
seriously... Since I've realized it *could* be useful, I am
considering it a serious (however an unbelievably easy) coding
project.

A.i.b.
galgamet@hotmail.com
UIN: 6541926