MSN Account Setup
by souFrag / Felipe Brahm
ICQ#50566818
http://www.soufrag.cl

PLEASE CONTACT ME FIRST IF YOU WANT TO USE PART OF MY CODE IN YOUR OWN WORK :-)

Description:

Shows a dialog to enter your e-mail/password on first run or if there's no e-mail/password stored.

It also gives you the possibility not to store e-mail/password (they are deleted on exit if you select the option "Not remember e-mail/password").

PLEASE NOTE:
You'll see no dialog on start if there's already an e-mail and password stored on your profile. If you want to see the dialog, then go to MSN options and delete your e-mail or password.

Thx to:
Nightwish and Std for answering my questions on the forums :-)