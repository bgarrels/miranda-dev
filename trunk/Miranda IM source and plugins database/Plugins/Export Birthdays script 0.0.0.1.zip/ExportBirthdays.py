import database
import contacts
import os.path

#This script exports birthday information for your contacts to an external file.
#the file format is compatible with the format used by WhenWasIt plugin.

#To run simply write the following in MirPy's console window, without the '#' comment character at the beginning:
#import ExportBirthdays #ExportBirthdays is the name of this file
#ExportBirthdays.ExportBirthdays() #this will export birthday information for all your contacts to the default output file. 

def IsDOBValid(year, month, day):
	"""Checks to see if a birthday is valid.
	"""
	return ((year != 0) and (month != 0) and (day != 0))

def GetContactBirthday(hContact):
	"""Tries to read birthday information asociated with the hContact
	The information can be present in different modules so it reads
	all known location until it finds a valid birthday. 
	"""
	year = database.GetContactSettingWord(hContact, "UserInfo", "DOBy", 0)
	month = database.GetContactSettingByte(hContact, "UserInfo", "DOBm", 0)
	day = database.GetContactSettingByte(hContact, "UserInfo", "DOBd", 0)

	if (not IsDOBValid(year, month, day)):
		year = database.GetContactSettingWord(hContact, "mBirthday", "BirthYear", 0)
		month = database.GetContactSettingByte(hContact, "mBirthday", "BirthMonth", 0)
		day = database.GetContactSettingByte(hContact, "mBirthday", "BirthDay", 0)
		
	if (not IsDOBValid(year, month, day)):
		protocol = database.GetContactSettingString(hContact, "Protocol", "p", "None")
		year = database.GetContactSettingWord(hContact, protocol, "BirthYear", 0)
		month = database.GetContactSettingByte(hContact, protocol, "BirthMonth", 0)
		day = database.GetContactSettingByte(hContact, protocol, "BirthDay", 0)
		
	if (not IsDOBValid(year, month, day)):
		year = database.GetContactSettingWord(hContact, "BirthDay", "BirthYear", 0)
		month = database.GetContactSettingByte(hContact, "BirthDay", "BirthMonth", 0)
		day = database.GetContactSettingByte(hContact, "BirthDay", "BirthDay", 0)
		
	return (year, month, day)

def BuildExportLine(uID, protocol, year, month, day):
	"""Builds a birthday export line compatible with the format used by WhenWasIt plugin.
	"""
	return "%s@%s : %02d/%02d/%04d" % (uID, protocol, day, month, year)


def ExportBirthday(hContact, fout):
	"""Exports the birthday information for the given contact to the given file.
	The birthday information will only be exported if the contact and the date are valid.
	"""
	(year, month, day) = GetContactBirthday(hContact)
	if (IsDOBValid(year, month, day)): #does the contact have a valid birthday ?
		contact = contacts.GetContact(hContact) #get contact information
		if ((contact.uniqueID == 0) or (contact.protocol == 0)): #does the contact have a valid unique name and protocol
			print "Unknown contact", contact.nick, hContact
		else:
			print "Exporting %s (%s)" % (contact.uniqueID, contact.nick) #valid contact unique name and protocol found, exporting birthday info
			export = BuildExportLine(contact.uniqueID, contact.protocol, year, month, day)
			fout.write(export)
			fout.write("\n")

def ExportBirthdays(fileName = "birthdays.bdays"):
	"""Exports birthday information for all valid contacts to the given file.
	If no file name is supplied the the script will use 'birthdays.bdays' by default.
	The external file must have the extension '.bdays' otherwise an exception will be raised - safety reasons.
	""" 
	(fn, extension) = os.path.splitext(fileName)
	if (extension != '.bdays'):
		raise ValueError("Exported file name must have .bdays extension, '" + fileName + "' was supplied instead.")
		return
		
	print "Exporting birthday information for all contacts to file", fileName
	fout = open(fileName, "wt")
	fout.write("#Birthday list exported by ExportBirthdays MirPy script.\n")
	fout.write("#This file format is compatible with the format used by WhenWasIt plugin.\n")
	hContact = database.ContactFindFirst()
	while (hContact != 0):
		ExportBirthday(hContact, fout)
		hContact = database.ContactFindNext(hContact)
	fout.close()
	print "Finished exporting birthday information for all contacts"