#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_OPTIONS                             101
#define IDC_BASSVERSION                         1000
#define IDC_VOLUMELABEL                         1001
#define IDC_CURRPATHLABEL                       1002
#define IDC_OUTDEVICELABEL                      1004
#define IDC_OUTDEVICE                           1005
#define IDC_QUIETTIME                           1008
#define IDC_CURRPATH                            1009
#define IDC_MAXCHANNELLABEL                     1010
#define IDC_MAXCHANNEL                          1011
#define IDC_VOLUME                              1012
#define IDC_GETBASS                             1013
#define IDC_TIME1                               1014
#define IDC_TIME2                               1015
#define IDC_CHECKBOX1                           1100
#define IDC_CHECKBOX2                           1101
#define IDC_CHECKBOX3                           1102
#define IDC_CHECKBOX4                           1103
#define IDC_CHECKBOX5                           1104
#define IDC_CHECKBOX6                           1105
#define IDC_CHECKBOX7                           1106
#define IDC_CHECKBOX8                           1107
#define IDC_CHECKBOX9                           1108
#define IDC_CHECKBOX10                          1109
#define IDC_PREVIEW                             1110

#define IDI_BASSSoundOnOffUp					200
#define IDI_BASSSoundOnOffDown					201
