#include "main.h"
#include <MemoryFind.h>
#include <MemoryCompare.h>
#include <BuffToLowerCase.h>




BOOL DB_GetStaticString(HANDLE hContact,LPSTR lpszModule,LPSTR lpszValueName,LPSTR lpszRet,SIZE_T dwRetBuffSize,SIZE_T *pdwRetBuffSize)
{
	BOOL bRet=FALSE;
	SIZE_T dwReadedStringLen;
	DBVARIANT dbv;
	DBCONTACTGETSETTING sVal;

	sVal.pValue=&dbv;
	sVal.szModule=lpszModule;
	sVal.szSetting=lpszValueName;
	if (CallService(MS_DB_CONTACT_GETSETTING,(WPARAM)hContact,(LPARAM)&sVal)==0)
	{
		switch(dbv.type){
		case DBVT_WCHAR:
			dwReadedStringLen=lstrlenW(dbv.pwszVal);
			if (dwRetBuffSize>=dwReadedStringLen)
			{
				bRet=(WideCharToMultiByte(CODE_PAGE,0,dbv.pwszVal,dwReadedStringLen,lpszRet,dwRetBuffSize,NULL,NULL)!=0);
			}
			if (pdwRetBuffSize) (*pdwRetBuffSize)=dwReadedStringLen;
			break;
		case DBVT_UTF8:
			dwReadedStringLen=MultiByteToWideChar(CP_UTF8,0,dbv.pszVal,-1,NULL,0);
			if (dwRetBuffSize>=dwReadedStringLen)
			{
				LPWSTR lpszString=(LPWSTR)MEMALLOC((dwReadedStringLen*sizeof(WCHAR)));
				if (lpszString)
				{
					if (MultiByteToWideChar(CP_UTF8,0,dbv.pszVal,dwReadedStringLen,lpszString,dwReadedStringLen))
					{
						bRet=(WideCharToMultiByte(CODE_PAGE,0,lpszString,dwReadedStringLen,lpszRet,dwRetBuffSize,NULL,NULL)!=0);
					}
					MEMFREE(lpszString);
				}
			}
			if (pdwRetBuffSize) (*pdwRetBuffSize)=dwReadedStringLen;
			break;
		case DBVT_ASCIIZ:
			dwReadedStringLen=lstrlenA(dbv.pszVal);
			if (dwRetBuffSize>=dwReadedStringLen)
			{
				CopyMemory(lpszRet,dbv.pszVal,dwReadedStringLen+1);//include null terminated
				bRet=TRUE;
			}
			if (pdwRetBuffSize) (*pdwRetBuffSize)=dwReadedStringLen;
			break;
		default:
			DebugBreak();
			break;
		}
		DBFreeVariant(&dbv);
	}else{
		if (lpszRet)		(*lpszRet)=0;
		if (pdwRetBuffSize)	(*pdwRetBuffSize)=0;
		bRet=FALSE;
	}
return(bRet);
}


BOOL DB_SetStringEx(HANDLE hContact,LPSTR lpszModule,LPSTR lpszValueName,LPSTR lpszValue,SIZE_T dwValueSize)
{
	BOOL bRet=TRUE;
	if (dwValueSize)
	{
		LPSTR lpszValueLocal=(LPSTR)MEMALLOC(dwValueSize);
		
		if (lpszValueLocal)
		{
			CopyMemory(lpszValueLocal,lpszValue,dwValueSize);
			DBWriteContactSettingString(hContact,lpszModule,lpszValueName,lpszValueLocal);
			MEMFREE(lpszValueLocal);
		}
	}else{
		DBDeleteContactSetting(hContact,lpszModule,lpszValueName);
	}
return(bRet);
}


LPSTR GetModuleName(HANDLE hContact)
{
	LPSTR lpszRet;

	if (hContact)
	{
		lpszRet=(LPSTR)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)hContact,0);
		if (lpszRet==NULL) lpszRet=PROTOCOL_NAME;
	}else{
		lpszRet=PROTOCOL_NAME;
	}
return(lpszRet);
}


void CListShowMenuItem(HANDLE hMenuItem,BOOL bShow)
{
	CLISTMENUITEM mi={0};

	mi.cbSize=sizeof(mi);
	mi.flags=CMIM_FLAGS;
	if (bShow==FALSE) mi.flags|=CMIF_HIDDEN;

	CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hMenuItem,(LPARAM)&mi);
}


//This function gets a Cellular string szPhone and clean it from symbools.
SIZE_T CopyNumber(LPCVOID lpcOutBuff,LPCVOID lpcBuff,SIZE_T dwLen)
{
	BYTE btChar;
	LPBYTE lpbOutBuff=(LPBYTE)lpcOutBuff,lpbInBuff=(LPBYTE)lpcBuff;

	for(SIZE_T i=0;i<dwLen;i++)
	{
		btChar=(*lpbInBuff++);
		if (btChar>='0' && btChar<='9') (*lpbOutBuff++)=btChar;
	}
	(*lpbOutBuff)=0;

return((lpbOutBuff-(LPBYTE)lpcOutBuff));
}


BOOL IsPhone(LPSTR lpszString,SIZE_T dwStringSize)
{
	BOOL bRet;

	if (dwStringSize>1)
	{// country code
		BYTE btChar;

		bRet=TRUE;
		for(SIZE_T i=0;i<dwStringSize;i++)
		{
			btChar=(*lpszString++);
			if (btChar<'0' || btChar>'9')
			if (btChar!='+' && btChar!='S' && btChar!='M' && btChar!=' ' && btChar!='(' && btChar!=')')
			{
				bRet=FALSE;
				break;
			}
		}
	}else{
		bRet=FALSE;
	}
return(bRet);
}


DWORD GetContactPhonesCountParam(HANDLE hContact,LPSTR lpszModule,LPSTR lpszValueName)
{
	DWORD dwRet=0;
	char szBuff[MAX_PATH],szPhone[MAX_PHONE_LEN];
	SIZE_T i,dwPhoneSize;

	if (DB_GetStaticString(hContact,lpszModule,lpszValueName,szPhone,sizeof(szPhone),&dwPhoneSize))
	{
		if (IsPhone(szPhone,dwPhoneSize)) dwRet++;
	}

	for (i=0;TRUE;i++)
	{
		mir_snprintf(szBuff,sizeof(szBuff),"%s%ld",lpszValueName,i);
		if (DB_GetStaticString(hContact,lpszModule,szBuff,szPhone,sizeof(szPhone),&dwPhoneSize))
		{
			if (IsPhone(szPhone,dwPhoneSize)) dwRet++;
		}else{
			if (i>PHONES_MIN_COUNT) break;
		}
	}
return(dwRet);
}


DWORD GetContactPhonesCount(HANDLE hContact)
{
	DWORD dwRet=0;
	LPSTR lpszProto;

	lpszProto=(LPSTR)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)hContact,0);
	if (lpszProto)
	{
		dwRet+=GetContactPhonesCountParam(hContact,lpszProto,"Phone");
		dwRet+=GetContactPhonesCountParam(hContact,lpszProto,"Cellular");
		dwRet+=GetContactPhonesCountParam(hContact,lpszProto,"Fax");
	}
	dwRet+=GetContactPhonesCountParam(hContact,"UserInfo","MyPhone");
	dwRet+=GetContactPhonesCountParam(hContact,"UserInfo","Phone");
	dwRet+=GetContactPhonesCountParam(hContact,"UserInfo","Cellular");
	dwRet+=GetContactPhonesCountParam(hContact,"UserInfo","Fax");

return(dwRet);
}


BOOL IsContactPhoneParam(HANDLE hContact,LPSTR lpszModule,LPSTR lpszValueName,LPSTR lpszPhone,SIZE_T dwPhoneSize)
{
	BOOL bRet=FALSE;
	char szBuff[MAX_PATH],szPhoneLocal[MAX_PHONE_LEN];
	SIZE_T i,dwPhoneSizeLocal;

	if (DB_GetStaticString(hContact,lpszModule,lpszValueName,szPhoneLocal,sizeof(szPhoneLocal),&dwPhoneSizeLocal))
	if (IsPhone(szPhoneLocal,dwPhoneSizeLocal))
	{
		dwPhoneSizeLocal=CopyNumber(szPhoneLocal,szPhoneLocal,dwPhoneSizeLocal);
		if (MemoryCompare(szPhoneLocal,dwPhoneSizeLocal,lpszPhone,dwPhoneSize)==CSTR_EQUAL)
		{
			bRet=TRUE;
		}
	}

	for (i=0;bRet==FALSE;i++)
	{
		mir_snprintf(szBuff,sizeof(szBuff),"%s%ld",lpszValueName,i);
		if (DB_GetStaticString(hContact,lpszModule,szBuff,szPhoneLocal,sizeof(szPhoneLocal),&dwPhoneSizeLocal))
		{
			if (IsPhone(szPhoneLocal,dwPhoneSizeLocal))
			{
				dwPhoneSizeLocal=CopyNumber(szPhoneLocal,szPhoneLocal,dwPhoneSizeLocal);
				if (MemoryCompare(szPhoneLocal,dwPhoneSizeLocal,lpszPhone,dwPhoneSize)==CSTR_EQUAL)
				{
					bRet=TRUE;
					break;
				}
			}
		}else{
			if (i>PHONES_MIN_COUNT) break;
		}
	}
return(bRet);
}


BOOL IsContactPhone(HANDLE hContact,LPSTR lpszPhone,SIZE_T dwPhoneSize)
{
	BOOL bRet=FALSE;
	char szPhoneLocal[MAX_PHONE_LEN];
	LPSTR lpszProto;
	SIZE_T dwPhoneSizeLocal;

	dwPhoneSizeLocal=CopyNumber(szPhoneLocal,lpszPhone,dwPhoneSize);
	lpszProto=(LPSTR)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)hContact,0);
	if (lpszProto)
	{
		if (bRet==FALSE) bRet=IsContactPhoneParam(hContact,lpszProto,"Phone",szPhoneLocal,dwPhoneSizeLocal);
		if (bRet==FALSE) bRet=IsContactPhoneParam(hContact,lpszProto,"Cellular",szPhoneLocal,dwPhoneSizeLocal);
		if (bRet==FALSE) bRet=IsContactPhoneParam(hContact,lpszProto,"Fax",szPhoneLocal,dwPhoneSizeLocal);
	}
	if (bRet==FALSE) bRet=IsContactPhoneParam(hContact,"UserInfo","MyPhone",szPhoneLocal,dwPhoneSizeLocal);
	if (bRet==FALSE) bRet=IsContactPhoneParam(hContact,"UserInfo","Phone",szPhoneLocal,dwPhoneSizeLocal);
	if (bRet==FALSE) bRet=IsContactPhoneParam(hContact,"UserInfo","Cellular",szPhoneLocal,dwPhoneSizeLocal);
	if (bRet==FALSE) bRet=IsContactPhoneParam(hContact,"UserInfo","Fax",szPhoneLocal,dwPhoneSizeLocal);

return(bRet);
}


//This function get a string cellular number and return the HANDLE of the contact that has this
//number in the miranda phonebook (and marked as an SMS able) at the User Details.
//If no one has this number function returns NULL.
HANDLE HContactFromPhone(LPSTR lpszPhone,SIZE_T dwPhoneSize)
{
	HANDLE hContact=NULL;

	if (lpszPhone && dwPhoneSize)
	{
		//check not already on list
		for(hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);hContact!=NULL;hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0))
		{
			if (IsContactPhone(hContact,lpszPhone,dwPhoneSize)) break;
		}
	}
return(hContact);
}


BOOL GetDataFromMessage(LPSTR lpszMessage,SIZE_T dwMessageSize,DWORD *pdwEventType,LPSTR lpszPhone,SIZE_T dwPhoneSize,SIZE_T *pdwPhoneSizeRet,UINT *piIcon)
{
	BOOL bRet=FALSE;

	DWORD dwEventTypeRet=0;
	SIZE_T dwPhoneSizeRet=0;
	UINT iIconRet=0;

	if (lpszMessage && dwMessageSize)
	{
		LPSTR lpsz;

		if (MemoryCompare(lpszMessage,10,"SMS From: ",10)==CSTR_EQUAL)
		{
			lpsz=(LPSTR)MemoryFind(10,lpszMessage,dwMessageSize,"\r\n",2);
			if (lpsz)
			{
				if (lpszPhone && dwPhoneSize) dwPhoneSizeRet=CopyNumber(lpszPhone,(lpszMessage+10),min((SIZE_T)(lpsz-(lpszMessage+10)),dwPhoneSize));
			}
			iIconRet=IDI_SMS;
			dwEventTypeRet=ICQEVENTTYPE_SMS;
			bRet=TRUE;
		}else
		if (MemoryCompare(lpszMessage,23,"SMS Confirmation From: ",23)==CSTR_EQUAL)
		{
			lpsz=(LPSTR)MemoryFind(23,lpszMessage,dwMessageSize,"\r\n",2);
			if (lpsz)
			{
				if (lpszPhone && dwPhoneSize) dwPhoneSizeRet=CopyNumber(lpszPhone,(lpszMessage+23),min((SIZE_T)(lpsz-(lpszMessage+23)),dwPhoneSize));

				lpsz+=2;
				if (MemoryCompare(lpsz,24,"SMS was sent succesfully",24)==CSTR_EQUAL)
				{
					iIconRet=IDI_SMSSENT;
				}else{
					iIconRet=IDI_SMSNOTSENT;
				}
			}
			dwEventTypeRet=ICQEVENTTYPE_SMSCONFIRMATION;
			bRet=TRUE;
		}
	}

	if (pdwPhoneSizeRet)	(*pdwPhoneSizeRet)=dwPhoneSizeRet;
	if (pdwEventType)		(*pdwEventType)=dwEventTypeRet;
	if (piIcon)				(*piIcon)=iIconRet;

return(bRet);
}


BOOL GetXMLFieldEx(LPSTR lpszXML,SIZE_T dwXMLSize,LPSTR *plpszData,SIZE_T *pdwDataSize,const char *tag1,...)
{
	BOOL bRet=FALSE;
	int thisLevel=0;
	LPSTR lpszFindTag=(LPSTR)tag1,lpszTagStart,lpszTagEnd=lpszXML,lpszDataStart=NULL;
	va_list va;

	va_start(va,tag1);
	while(TRUE)
	{
		lpszTagStart=(LPSTR)MemoryFindByte((lpszTagEnd-lpszXML),lpszXML,dwXMLSize,'<');
		if (lpszTagStart)
		{
			lpszTagEnd=(LPSTR)MemoryFindByte((lpszTagStart-lpszXML),lpszXML,dwXMLSize,'>');
			if (lpszTagEnd)
			{
				lpszTagStart++;
				lpszTagEnd--;
				if ((*((BYTE*)lpszTagStart))=='/')
				{
					if (--thisLevel<0)
					{
						if (lpszDataStart)
						{
							if (plpszData) (*plpszData)=lpszDataStart;
							if (pdwDataSize) (*pdwDataSize)=((lpszTagStart-1)-lpszDataStart);
							bRet=TRUE;
						}
						break;
					}
				}else{
					if (++thisLevel==1)
					if (CompareStringA(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),NORM_IGNORECASE,lpszFindTag,-1,lpszTagStart,((lpszTagEnd+1)-lpszTagStart))==CSTR_EQUAL)
					{
						lpszFindTag=va_arg(va,LPSTR);
						if (lpszFindTag==NULL) lpszDataStart=(lpszTagEnd+2);
						thisLevel=0;
					}
				}
			}else{
				break;
			}
		}else{
			break;
		}
	}
	va_end(va);
return(bRet);
}


BOOL GetXMLFieldExBuff(LPSTR lpszXML,SIZE_T dwXMLSize,LPSTR lpszBuff,SIZE_T dwBuffSize,SIZE_T *pdwBuffSizeRet,const char *tag1,...)
{
	BOOL bRet=FALSE;
	int thisLevel=0;
	LPSTR lpszFindTag=(LPSTR)tag1,lpszTagStart,lpszTagEnd=lpszXML,lpszDataStart=NULL;
	va_list va;


	va_start(va,tag1);
	while(TRUE)
	{
		lpszTagStart=(LPSTR)MemoryFindByte((lpszTagEnd-lpszXML),lpszXML,dwXMLSize,'<');
		if (lpszTagStart)
		{
			lpszTagEnd=(LPSTR)MemoryFindByte((lpszTagStart-lpszXML),lpszXML,dwXMLSize,'>');
			if (lpszTagEnd)
			{
				lpszTagStart++;
				lpszTagEnd--;
				if ((*((BYTE*)lpszTagStart))=='/')
				{
					if (--thisLevel<0)
					{
						if (lpszDataStart)
						{
							SIZE_T dwBuffSizeRet=min((dwBuffSize-2),(SIZE_T)((lpszTagStart-1)-lpszDataStart));
							if (lpszBuff && dwBuffSize) CopyMemory(lpszBuff,lpszDataStart,dwBuffSizeRet);(*((WORD*)(lpszBuff+dwBuffSizeRet)))=0;
							if (pdwBuffSizeRet) (*pdwBuffSizeRet)=dwBuffSizeRet;
							bRet=TRUE;
						}
						break;
					}
				}else{
					if (++thisLevel==1)
					if (CompareStringA(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),NORM_IGNORECASE,lpszFindTag,-1,lpszTagStart,((lpszTagEnd+1)-lpszTagStart))==CSTR_EQUAL)
					{
						lpszFindTag=va_arg(va,LPSTR);
						if (lpszFindTag==NULL) lpszDataStart=(lpszTagEnd+2);
						thisLevel=0;
					}
				}
			}else{
				break;
			}
		}else{
			break;
		}
	}
	va_end(va);


	if (bRet==FALSE)
	{
		if (lpszBuff)		(*((WORD*)lpszBuff))=0;
		if (pdwBuffSizeRet)	(*pdwBuffSizeRet)=0;
	}

return(bRet);
}
//
char* EncodeXML(const char* cXml)
{
	int i;
	char *cEncodedXML;
	cEncodedXML=(char*)MEMALLOC(1);
	*cEncodedXML='\0';
	for(i=0;i<lstrlen(cXml);i++)
	{
		char cTmp[2];
		cTmp[0]=*(cXml+i);
		cTmp[1]='\0';
		if (MemoryCompare(cXml+i,1,"\'",1)==CSTR_EQUAL)
		{
			cEncodedXML=(char*)MEMREALLOC(cEncodedXML,sizeof(char*) * (6 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&apos;");
		}
		else if (MemoryCompare(cXml+i,1,"\"",1)==CSTR_EQUAL)
		{
			cEncodedXML=(char*)MEMREALLOC(cEncodedXML,sizeof(char*) * (6 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&quot;");
		}
		else if (MemoryCompare(cXml+i,1,"&",1)==CSTR_EQUAL)
		{
			cEncodedXML=(char*)MEMREALLOC(cEncodedXML,sizeof(char*) * (5 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&amp;");
		}
		else if (MemoryCompare(cXml+i,1,"<",1)==CSTR_EQUAL)
		{
			cEncodedXML=(char*)MEMREALLOC(cEncodedXML,sizeof(char*) * (4 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&lt;");
		}
		else if (MemoryCompare(cXml+i,1,">",1)==CSTR_EQUAL)
		{
			cEncodedXML=(char*)MEMREALLOC(cEncodedXML,sizeof(char*) * (4 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&gt;");
		}
		else
		{
			cEncodedXML=(char*)MEMREALLOC(cEncodedXML,sizeof(char*) * (1 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,cTmp);
		}
	}
	cEncodedXML=(char*)MEMREALLOC(cEncodedXML,sizeof(char*) * (1 + lstrlen(cEncodedXML)));
	lstrcat(cEncodedXML,"\0");
return(cEncodedXML);
}

//
char* DecodeXML(const char* cXml)
{
	int i;
	char *cDecodedXML;
	cDecodedXML=(char*)MEMALLOC(1);
	*cDecodedXML='\0';
	for(i=0;i<lstrlen(cXml);i++)
	{
		char cTmp[2];
		cTmp[0]=*(cXml+i);
		cTmp[1]='\0';
		if (MemoryCompare(cXml+i,6,"&apos;",6)==CSTR_EQUAL)
		{
			cDecodedXML=(char*)MEMREALLOC(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,"\'");
			i=i+5;
		}
		else if (MemoryCompare(cXml+i,6,"&quot;",6)==CSTR_EQUAL)
		{
			cDecodedXML=(char*)MEMREALLOC(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,"\"");
			i=i+5;
		}
		else if (MemoryCompare(cXml+i,5,"&amp;",5)==CSTR_EQUAL)
		{
			cDecodedXML=(char*)MEMREALLOC(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,"&");
			i=i+4;
		}
		else if (MemoryCompare(cXml+i,4,"&lt;",4)==CSTR_EQUAL)
		{
			cDecodedXML=(char*)MEMREALLOC(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,"<");
			i=i+3;
		}
		else if (MemoryCompare(cXml+i,4,"&gt;",4)==CSTR_EQUAL)
		{
			cDecodedXML=(char*)MEMREALLOC(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,">");
			i=i+3;
		}
		else
		{
			cDecodedXML=(char*)MEMREALLOC(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,cTmp);
		}
	}
	cDecodedXML=(char*)MEMREALLOC(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
	lstrcat(cDecodedXML,"\0");
return(cDecodedXML);
}



//(Taken from Miranda-IM source code:)
#if defined( _UNICODE )
static BYTE MsgDlgGetFontDefaultCharset(const TCHAR* szFont)
{
  return DEFAULT_CHARSET;
}
#else
// get font charset according to current CP
static BYTE MsgDlgGetCPDefaultCharset()
{
	switch (GetACP()) {
		case 1250:
			return EASTEUROPE_CHARSET;
		case 1251:
			return RUSSIAN_CHARSET;
		case 1252:
			return ANSI_CHARSET;
		case 1253:
			return GREEK_CHARSET;
		case 1254:
			return TURKISH_CHARSET;
		case 1255:
			return HEBREW_CHARSET;
		case 1256:
			return ARABIC_CHARSET;
		case 1257:
			return BALTIC_CHARSET;
		case 1361:
			return JOHAB_CHARSET;
		case 874:
			return THAI_CHARSET;
		case 932:
			return SHIFTJIS_CHARSET;
		case 936:
			return GB2312_CHARSET;
		case 949:
			return HANGEUL_CHARSET;
		case 950:
			return CHINESEBIG5_CHARSET;
		default:
			return DEFAULT_CHARSET;
	}
}

static int CALLBACK EnumFontFamExProc(const LOGFONT *lpelfe, const TEXTMETRIC *lpntme, DWORD FontType, LPARAM lParam)
{
	*(int*)lParam = 1;
	return 0;
}

// get font charset according to current CP, if available for specified font
static BYTE MsgDlgGetFontDefaultCharset(const TCHAR* szFont)
{
	HDC hdc;
	LOGFONT lf = {0};
	int found = 0;

	lstrcpy(lf.lfFaceName, szFont);
	lf.lfCharSet = MsgDlgGetCPDefaultCharset();

	// check if the font supports specified charset
	hdc = GetDC(0);
	EnumFontFamiliesEx(hdc, &lf, &EnumFontFamExProc, (LPARAM)&found, 0);
	ReleaseDC(0, hdc);

	if (found)
		return lf.lfCharSet;
	else // no, give default
		return DEFAULT_CHARSET;
}
#endif


void LoadMsgDlgFont(int i,LOGFONT *lf,COLORREF *colour)
{
	int style;
	char str[MAX_PATH];
	DBVARIANT dbv;

	if (colour)
	{
		wsprintfA(str,"Font%dCol",i);
		(*colour)=DBGetContactSettingDword(NULL,SRMMMOD,str,fontOptionsList[0].defColour);
	}

	if (lf)
	{
		if (DBGetContactSetting(NULL,SRMMMOD,str,&dbv))
		{
			lstrcpy(lf->lfFaceName,fontOptionsList[0].szDefFace);
		}else{
			lstrcpyn(lf->lfFaceName,dbv.pszVal,sizeof(lf->lfFaceName));
			DBFreeVariant(&dbv);
		}

		wsprintfA(str,"Font%dSize",i);
		lf->lfHeight=(char)DBGetContactSettingByte(NULL,SRMMMOD,str,fontOptionsList[0].defSize);
		lf->lfWidth=0;
		lf->lfEscapement=0;
		lf->lfOrientation=0;
		wsprintfA(str,"Font%dSty",i);
		style=DBGetContactSettingByte(NULL,SRMMMOD,str,fontOptionsList[0].defStyle);
		lf->lfWeight=style&FONTF_BOLD?FW_BOLD:FW_NORMAL;
		lf->lfItalic=style&FONTF_ITALIC?1:0;
		lf->lfUnderline=0;
		lf->lfStrikeOut=0;
		wsprintfA(str,"Font%dSet",i);
		lf->lfCharSet=DBGetContactSettingByte(NULL,SRMMMOD,str,MsgDlgGetFontDefaultCharset(lf->lfFaceName));
		lf->lfOutPrecision=OUT_DEFAULT_PRECIS;
		lf->lfClipPrecision=CLIP_DEFAULT_PRECIS;
		lf->lfQuality=DEFAULT_QUALITY;
		lf->lfPitchAndFamily=DEFAULT_PITCH|FF_DONTCARE;
		wsprintfA(str,"Font%d",i);
	}
}


