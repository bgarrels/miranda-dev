/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/

#include "utf8.h"
#include <windows.h>
#include <time.h>
#include <stdarg.h>
#include "main.h"
#include "send.h"
#include "newpluginapi.h"
#include "m_database.h"
#include "m_protosvc.h"
#include "m_icq.h"

void SetSendSMSWindowDbei(HWND hwndDlg, DBEVENTINFO dbei);

//This function gets HWND of the window, the number, and the message.
void StartSmsSend(HWND hwndDlg,const char *number,const char *text)
{
	
    char *tmpText;
	char *tmpEncodedXML=NULL;
	HANDLE hProcess;
	tmpText=(char *)malloc(256);
	tmpEncodedXML=EncodeXML(text);
	utf8_encode(tmpEncodedXML,&tmpText);
	hProcess=(HANDLE)CallService("ICQ/SendSMS",(WPARAM)number,(LPARAM)tmpText);
	SetSendSMSWindowHProcess(hwndDlg, hProcess);
	{
		DBEVENTINFO dbei={0};
		HANDLE hContactTmp;
		hContactTmp=CellularToHandle(number);
		dbei.cbSize = sizeof(dbei);
		dbei.szModule = "ICQ";
		dbei.timestamp = time(NULL);
		dbei.flags = DBEF_SENT;
		dbei.eventType = ICQEVENTTYPE_SMS;
		dbei.cbBlob = lstrlen(text)+lstrlen(number)+lstrlen("SMS To: ")+5;
		dbei.pBlob=(PBYTE)malloc(dbei.cbBlob);
		lstrcpy((char*)dbei.pBlob,"SMS To: ");
		lstrcat((char*)dbei.pBlob,"+");
		lstrcat((char*)dbei.pBlob,strCellular(number));
		lstrcat((char*)dbei.pBlob,"\n");
		lstrcat((char*)dbei.pBlob,text);
		SetSendSMSWindowDbei(hwndDlg,dbei);
	}
	free(tmpText);
}

void InitSmsSend(void)
{

}

void UninitSmsSend(void)
{
	RemoveAllSendSMSWindow();
}


