/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes
Copyright (C) 2007  Rozhuk Ivan

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/
#include "main.h"



HANDLE hHookOPT;

int GetStringOption(int id,char *pStr,int cbStr)
{
	char *pszSetting,*pszDefault;
	DBVARIANT dbv;
	
	switch(id) {
		case OPTION_USESIGNATURE:
			pszSetting="UseSignature";
			{
				char str[2];
				int len=1;
				str[0]='1';
				str[1]='\0';
				pszDefault=str;
			}
			break;
		case OPTION_SIGNATURE:
			pszSetting="Signature";
			{
				char str[256];
				int len;
				len=mir_snprintf(str,sizeof(str),Translate("From %s:\r\n\r\n"),DB_GetContactName(NULL));
				pszDefault=str;
			}
			break;
		case OPTION_SIGNATUREPOS:
			pszSetting="SignaturePos";
			{
				char str[2];
				int len;
				len=1;
				str[0]='0';
				str[1]='\0';
				pszDefault=str;
			}
			break;
		case OPTION_SHOWACK:
			pszSetting="ShowACK";
			{
				char str[2];
				int len;
				len=1;
				str[0]='0';
				str[1]='\0';
				pszDefault=str;
			}
			break;
		default:
			return 1;
	}
	if (DBGetContactSetting(NULL,PROTOCOL_NAME,pszSetting,&dbv))
		lstrcpyn(pStr,pszDefault,cbStr);
	else {
		lstrcpyn(pStr,dbv.pszVal,cbStr);
		DBFreeVariant(&dbv);
	}
	return 0;
}

static BOOL CALLBACK DlgProcEditorOptions(HWND hWndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg){
	case WM_INITDIALOG:
		TranslateDialogDefault(hWndDlg);
		{	
			char cSign[1024];
			char cBegin[2];
			char cShowACK[2];
			char cUseSign[2];


			GetStringOption(OPTION_SIGNATURE,cSign,sizeof(cSign));
			SetDlgItemText(hWndDlg,IDC_SIGNATURE,cSign);
			GetStringOption(OPTION_SIGNATUREPOS,cBegin,sizeof(cBegin));
			if (cBegin[0] == '0')
			{
				CheckDlgButton(hWndDlg,IDC_BEGIN,0);
				CheckDlgButton(hWndDlg,IDC_END,1);
			}
			else
			{
				CheckDlgButton(hWndDlg,IDC_BEGIN,1);
				CheckDlgButton(hWndDlg,IDC_END,0);
			}
			GetStringOption(OPTION_SHOWACK,cShowACK,sizeof(cShowACK));
			if (cShowACK[0] == '0')
			{
				CheckDlgButton(hWndDlg,IDC_SHOWACK,0);
				CheckDlgButton(hWndDlg,IDC_NOSHOWACK,1);
			}
			else
			{
				CheckDlgButton(hWndDlg,IDC_NOSHOWACK,0);
				CheckDlgButton(hWndDlg,IDC_SHOWACK,1);
			}
			GetStringOption(OPTION_USESIGNATURE,cUseSign,sizeof(cUseSign));
			if (cUseSign[0] == '0')
			{
				CheckDlgButton(hWndDlg,IDC_USESIGNATURE,0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_BEGIN),0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_END),0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SIGNATURE),0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SIGNGROUP),0);
			}
			else
			{
				CheckDlgButton(hWndDlg,IDC_USESIGNATURE,1);
				EnableWindow(GetDlgItem(hWndDlg,IDC_BEGIN),1);
				EnableWindow(GetDlgItem(hWndDlg,IDC_END),1);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SIGNATURE),1);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SIGNGROUP),1);
			}

		}
		return TRUE;
	case WM_COMMAND:
		SendMessage(GetParent(hWndDlg),PSM_CHANGED,0,0);
		switch(LOWORD(wParam)){
		case IDC_USESIGNATURE:
			if (!IsDlgButtonChecked(hWndDlg,IDC_USESIGNATURE))
			{
				CheckDlgButton(hWndDlg,IDC_USESIGNATURE,0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_BEGIN),0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_END),0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SIGNATURE),0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SIGNGROUP),0);
			}else{
				CheckDlgButton(hWndDlg,IDC_USESIGNATURE,1);
				EnableWindow(GetDlgItem(hWndDlg,IDC_BEGIN),1);
				EnableWindow(GetDlgItem(hWndDlg,IDC_END),1);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SIGNATURE),1);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SIGNGROUP),1);
			}
			break;
		}
		break;
	case WM_NOTIFY:
		switch(((LPNMHDR)lParam)->idFrom){
		case 0:
			switch (((LPNMHDR)lParam)->code){
			case PSN_APPLY:
				{
					char cSign[1024];
					GetDlgItemText(hWndDlg,IDC_SIGNATURE,cSign,sizeof(cSign));
					DBWriteContactSettingString(NULL,PROTOCOL_NAME,"Signature",cSign);
					if (!IsDlgButtonChecked(hWndDlg,IDC_BEGIN))
						DBWriteContactSettingString(NULL,PROTOCOL_NAME,"SignaturePos","0");
					else
						DBWriteContactSettingString(NULL,PROTOCOL_NAME,"SignaturePos","1");
					if (!IsDlgButtonChecked(hWndDlg,IDC_SHOWACK))
						DBWriteContactSettingString(NULL,PROTOCOL_NAME,"ShowACK","0");
					else
						DBWriteContactSettingString(NULL,PROTOCOL_NAME,"ShowACK","1");
					if (!IsDlgButtonChecked(hWndDlg,IDC_USESIGNATURE))
						DBWriteContactSettingString(NULL,PROTOCOL_NAME,"UseSignature","0");
					else
						DBWriteContactSettingString(NULL,PROTOCOL_NAME,"UseSignature","1");
				}
				return(TRUE);
			}
			break;
		}
		break;
	}
return(FALSE);
}

static int OptInitialise(WPARAM wParam,LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp={0};

	odp.cbSize=sizeof(odp);
	odp.position=910000000;
	odp.hInstance=GetPluginhInst();
	odp.pszGroup=Translate("Events");
	odp.flags=ODPF_BOLDGROUPS|ODPF_EXPERTONLY;
	odp.pszTemplate=MAKEINTRESOURCE(IDD_OPT_SMSPLUGIN);
	odp.pszTitle=Translate("SMS Plugin");
	odp.pfnDlgProc=DlgProcEditorOptions;
	CallService(MS_OPT_ADDPAGE,wParam,(LPARAM)&odp);
return(0);
}

void InitOptions(void)
{
	hHookOPT=HookEvent(ME_OPT_INITIALISE,OptInitialise);
}
void UninitOptions(void)
{
	UnhookEvent(hHookOPT);
}