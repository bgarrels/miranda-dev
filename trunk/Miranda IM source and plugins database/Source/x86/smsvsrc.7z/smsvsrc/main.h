#ifndef _MAIN_H
#define _MAIN_H




#define _USE_32BIT_TIME_T
#define _CRT_SECURE_NO_WARNINGS

//#define UNICODE
//#define _UNICODE

#ifdef NDEBUG
	#pragma optimize("gsy",on)
	#pragma comment(linker,"/subsystem:Windows,5")
	#pragma comment(linker,"/version:5")

	#pragma comment(linker,"/nodefaultlib")
	//#pragma comment(linker,"/GS")
	//#pragma comment(linker,"/merge:.rdata=.text /merge:.data=.text")
	//#pragma comment(linker,"/verbose")
	//#pragma comment(linker,"/noentry")
	#pragma comment(linker,"/ENTRY:DllMain")

#endif //_DEBUG*/

	//#pragma comment(linker,"/nodefaultlib")
	//#pragma comment(linker,"/noentry")
	//#pragma comment(linker,"/ENTRY:DllMain")

#define CRTDLL

#define MIRANDA_VER 0x0800


#include "resource.h"
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <time.h>
#ifdef NDEBUG
	#include <..\minicrt\minicrt.h>
#else
	#include <..\minicrt\timefuncs.h>
#endif //_DEBUG*/

#include <ListMT.h>
#include <DebugFunctions.h>
#include <MemoryCompare.h>
#include <MemoryFind.h>
#include <MemoryFindByte.h>
#include "newpluginapi.h"
#include "m_database.h"
#include "m_clist.h"
#include "m_langpack.h"
#include "m_history.h"
#include "m_protomod.h"
#include "m_autoreplacer.h"
#include "resource.h"
#include "m_skin.h"
#include "m_protosvc.h"
#include "m_icq.h"
#include "m_protosvc.h"
#include "m_system.h"
#include "m_utils.h"
#include "m_options.h"

#include "send.h"
#include "senddlg.h"
#include "recvdlg.h"



//#if !defined(_memcpy)
//#define CopyMemory RtlCopyMemory
//#endif

//#include ".\mincrt\wsnprintf.h"
//#define mir_snprintf wsnprintf

// {CF97FD5D-B911-47a8-AF03-D21968B5B894}
#define  SMS_GUID  { 0xcf97fd5d, 0xb911, 0x47a8, { 0xaf, 0x3, 0xd2, 0x19, 0x68, 0xb5, 0xb8, 0x94 } }

#define MIN_SMS_DBEVENT_LEN					4
#define MAX_PHONE_LEN						MAX_PATH
#define MAX_FILEPATH						32768
#define CODE_PAGE							1251
#define PHONES_MIN_COUNT					4 //internal	// ����������� ��������� ����������� ����������� ��� ���������� email ������ �� ���� �����
#define PROTOCOL_NAME						"SMSPlugin"

#define OPTION_SIGNATURE  1
#define OPTION_SIGNATUREPOS  2
#define OPTION_SHOWACK  3
#define OPTION_USESIGNATURE 4

//
#define ICQEVENTTYPE_SMSCONFIRMATION 3001


//Fonts defenitions
//#define SRMMMOD 	"SRMM"
#define SRMMMOD 	"TabSRMM_Fonts"

#define FONTF_BOLD   1
#define FONTF_ITALIC 2
struct FontOptionsList
{
	COLORREF defColour;
	TCHAR*   szDefFace;
	BYTE     defStyle;
	char     defSize;
}
static fontOptionsList[] = {
	{ RGB(106, 106, 106), _T("Arial"),    0, -12},
};


#define MSGFONTID_MYMSG		  0
#define MSGFONTID_YOURMSG	  2
#define MSGFONTID_MESSAGEAREA 16




#define SRMSGSET_BKGCOLOUR         "BkgColour"
#define SRMSGSET_INPBKGCOLOUR		"inputbg"
#define SRMSGDEFSET_BKGCOLOUR      GetSysColor(COLOR_WINDOW)
#define FONTF_BOLD   1
#define FONTF_ITALIC 2


#define MEMALLOC(Size)			HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,(Size+sizeof(SIZE_T)))
#define MEMREALLOC(Mem,Size)	HeapReAlloc(GetProcessHeap(),(HEAP_ZERO_MEMORY),(LPVOID)Mem,(Size+sizeof(SIZE_T)))
#define MEMFREE(Mem)			if (Mem) {HeapFree(GetProcessHeap(),0,(LPVOID)Mem);Mem=NULL;}


#define DB_GetContactName(Contact) (LPSTR)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)Contact,0)
#define DB_SMS_DeleteValue(Contact,valueName) DBDeleteContactSetting(Contact,PROTOCOL_NAME,valueName)
#define DB_SMS_GetDword(Contact,valueName,parDefltValue) DBGetContactSettingDword(Contact,PROTOCOL_NAME,valueName,parDefltValue)
#define DB_SMS_SetDword(Contact,valueName,parValue) DBWriteContactSettingDword(Contact,PROTOCOL_NAME,valueName,parValue)
#define DB_SMS_GetWord(Contact,valueName,parDefltValue) DBGetContactSettingWord(Contact,PROTOCOL_NAME,valueName,parDefltValue)
#define DB_SMS_SetWord(Contact,valueName,parValue) DBWriteContactSettingWord(Contact,PROTOCOL_NAME,valueName,parValue)
#define DB_SMS_GetByte(Contact,valueName,parDefltValue) DBGetContactSettingByte(Contact,PROTOCOL_NAME,valueName,parDefltValue)
#define DB_SMS_SetByte(Contact,valueName,parValue) DBWriteContactSettingByte(Contact,PROTOCOL_NAME,valueName,parValue)
BOOL	DB_GetStaticString(HANDLE hContact,LPSTR lpszModule,LPSTR lpszValueName,LPSTR lpszRet,SIZE_T dwRetBuffSize,SIZE_T *pdwRetBuffSize);
#define DB_SMS_GetStaticString(Contact,ValueName,Ret,RetBuffSize,pRetBuffSize) DB_GetStaticString(Contact,PROTOCOL_NAME,ValueName,Ret,RetBuffSize,pRetBuffSize)
BOOL	DB_SetStringEx(HANDLE hContact,LPSTR lpszModule,LPSTR lpszValueName,LPSTR lpszValue,SIZE_T dwValueSize);
#define DB_SetString(Contact,Module,valueName,parValue) DB_SetStringEx(Contact,Module,valueName,parValue,lstrlenA(parValue))
#define DB_SMS_SetString(Contact,valueName,parValue) DB_SetString(Contact,PROTOCOL_NAME,valueName,parValue)
#define DB_SMS_SetStringEx(Contact,valueName,parValue,parValueSize) DB_SetStringEx(Contact,PROTOCOL_NAME,valueName,parValue,parValueSize)

LPSTR			GetModuleName					(HANDLE hContact);

void			CListShowMenuItem				(HANDLE hMenuItem,BOOL bShow);
void			CListSetMenuItemIcon			(HANDLE hMenuItem,HICON hIcon);
//Decleration of function that returns received string with only numbers
SIZE_T			CopyNumber						(LPCVOID lpcOutBuff,LPCVOID lpcBuff,SIZE_T dwLen);
BOOL			IsPhone							(LPSTR lpszString,SIZE_T dwStringSize);
DWORD			GetContactPhonesCount			(HANDLE hContact);
BOOL			IsContactPhone					(HANDLE hContact,LPSTR lpszPhone,SIZE_T dwPhoneSize);
//Decleration of function that returns HANDLE of contact by his cellular number
HANDLE			HContactFromPhone				(LPSTR lpszPhone,SIZE_T dwPhoneSize);
BOOL			GetDataFromMessage				(LPSTR lpszMessage,SIZE_T dwMessageSize,DWORD *pdwEventType,LPSTR lpszPhone,SIZE_T dwPhoneSize,SIZE_T *pdwPhoneSizeRet,UINT *piIcon);
//Decleration of function that gets a XML string and return the asked tag.
BOOL			GetXMLFieldEx					(LPSTR lpszXML,SIZE_T dwXMLSize,LPSTR *plpszData,SIZE_T *pdwDataSize,const char *tag1,...);
BOOL			GetXMLFieldExBuff				(LPSTR lpszXML,SIZE_T dwXMLSize,LPSTR lpszBuff,SIZE_T dwBuffSize,SIZE_T *pdwBuffSizeRet,const char *tag1,...);
//
char* DecodeXML(const char* cXml);
char* EncodeXML(const char* cXml);



//Decleration of Initialation\Uninitialation functions
void InitSmsSend();
void UninitSmsSend();
void InitSmsRecv();
void UninitSmsRecv();
void InitOptions();
void UninitOptions();


int handleNewMessage(WPARAM wParam,LPARAM lParam);
void RestoreUnreadMessageAlerts();

//Decleration of Menu SMS send click function
static int SMSMenuCommand(WPARAM wParam,LPARAM lParam);
static int SendSMSMenuCommand(WPARAM wParam,LPARAM lParam);


void StartSmsSend(HWND hWndDlg,LPSTR lpszModule,LPSTR lpszPhone,SIZE_T dwPhoneSize,LPSTR lpszMessage,SIZE_T dwMessageSize);



//Decleration of function that returns plugin instance
HINSTANCE GetPluginhInst();

//Decleration of functions that used when user hit miranda for new message/confirmation
static int ReadAckSMS(WPARAM wParam,LPARAM lParam);
static int ReadMsgSMS(WPARAM wParam,LPARAM lParam);

//Fonts Stuff
void LoadMsgDlgFont(int i,LOGFONT *lf,COLORREF *colour);

//
int GetStringOption(int id,char *pStr,int cbStr);

//


#endif