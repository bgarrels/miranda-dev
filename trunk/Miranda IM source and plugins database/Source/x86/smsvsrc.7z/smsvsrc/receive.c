/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/

#include "main.h"
#include "utf8.h"
#include "resource.h"
#include <windows.h>
#include <time.h>
#include <stdio.h>
#include "newpluginapi.h"
#include "m_clist.h"
#include "m_skin.h"
#include "m_database.h"
#include "m_langpack.h"
#include "m_protosvc.h"
#include "m_icq.h"
#include "m_protomod.h"

HANDLE hHookDbAdd;
HANDLE hHookAck;
BOOL CALLBACK RecvSmsDlgProc(HWND hwndDlg,UINT message,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK SMSTimedOutDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

//This function handles the ACK received from that hooked.
static int handleAckSMS(WPARAM wParam,LPARAM lParam)
{
	ACKDATA *ack=(ACKDATA*)lParam;
	char *cResult;
	if(ack->type!=ICQACKTYPE_SMS) return 0;
	if(lstrcmp(ack->szModule,"ICQ")) return 0;
//This common used for debugging:
//	if(ack->result==ACKRESULT_SENTREQUEST)
//		MessageBox(NULL,"ACKRESULT_SENTREQUEST","DEBUG - SMS ACK",MB_OK);
//	if(ack->result==ACKRESULT_FAILED) 
//	{
//		MessageBox(NULL,_strdup((char*)ack->lParam),"DEBUG - SMS ACK",MB_OK);
//		return 0;
//	}
//	MessageBox(NULL,_strdup((char*)ack->lParam),"DEBUG - SMS ACK",MB_OK);
//END OF DEBUG
	cResult=(char*)malloc(512);
	if(GetXMLField(_strdup((char*)ack->lParam),"sms_message","text",NULL) != NULL)	
	{
		char *cUTF8Decoded=NULL;
		char *cXMLDecoded=(char*)malloc(512);
		utf8_decode(GetXMLField(_strdup((char*)ack->lParam),"sms_message","text",NULL),&cUTF8Decoded);
		cXMLDecoded=DecodeXML(cUTF8Decoded);
		cResult=cXMLDecoded;//ReplaceNwithRN(cXMLDecoded);
		{
			HANDLE hContactTmp;
			hContactTmp=CellularToHandle(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL));
			{
				DBEVENTINFO dbei={0};
				dbei.cbSize = sizeof(dbei);
				dbei.szModule = "ICQ";
				dbei.timestamp = time(NULL);
				dbei.flags = 0;
				dbei.eventType = ICQEVENTTYPE_SMS;
				dbei.cbBlob = lstrlen(cResult)+lstrlen(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL))+lstrlen("SMS From: ")+6;
				dbei.pBlob=(PBYTE)malloc(dbei.cbBlob);
				lstrcpy((char*)dbei.pBlob,"SMS From: ");
				lstrcat((char*)dbei.pBlob,"+");
				lstrcat((char*)dbei.pBlob,GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL));
				lstrcat((char*)dbei.pBlob,"\r\n");
				lstrcat((char*)dbei.pBlob,cResult);
				CallService(MS_DB_EVENT_ADD, (WPARAM)hContactTmp, (LPARAM)&dbei);
				if(hContactTmp == NULL)
				{	
					HWND hwndRecvSms;
					char newtitle[256];
					char *cNumber;
					cNumber = (char *)malloc(lstrlen(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL))+2);
					lstrcpy(cNumber,"+");
					lstrcat(cNumber,GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL));
					lstrcat(cNumber,"\0");
					SkinPlaySound("RecvSMSMsg");
					hwndRecvSms=AddRecvSMSWindow();
					lstrcpy(newtitle,Translate("Unknown"));
					lstrcat(newtitle," - ");
					lstrcat(newtitle,Translate("Received SMS"));
					SetWindowText(hwndRecvSms,newtitle);
					SetRecvSMSWindowHContact(hwndRecvSms,NULL);
					SetDlgItemText(hwndRecvSms,IDC_NAME,Translate("Unknown"));
					SetDlgItemText(hwndRecvSms,IDC_NUMBER,cNumber);
					SetDlgItemText(hwndRecvSms,IDC_MESSAGE,(char*)dbei.pBlob);
					CallService(MS_DB_EVENT_MARKREAD,(WPARAM)hContactTmp, (LPARAM)&dbei);
					return 0;
				}
			}
			return 0;
		}
		
	}
	else if(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","delivered",NULL) != NULL)	
	{
		cResult=(char *)malloc(lstrlen(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","delivered",NULL))+1);
		lstrcpy(cResult,GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","delivered",NULL));
		{
			HANDLE hContactTmp;
			hContactTmp=CellularToHandle(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL));
			{
				DBEVENTINFO dbei={0};
				dbei.cbSize = sizeof(dbei);
				dbei.szModule = "ICQ";
				dbei.timestamp = time(NULL);
				dbei.flags = 0;
				dbei.eventType = ICQEVENTTYPE_SMSCONFIRMATION;
				if(!lstrcmp(cResult,"Yes"))
				{
					dbei.cbBlob = lstrlen("SMS was sent succesfully")+lstrlen("SMS Confirmation From: ")+lstrlen(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))+5;
					dbei.pBlob=(PBYTE)malloc(dbei.cbBlob);
					lstrcpy((char*)dbei.pBlob,"SMS Confirmation From: ");
					lstrcat((char*)dbei.pBlob,"+");
					lstrcat((char*)dbei.pBlob,GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL));
					lstrcat((char*)dbei.pBlob,"\r\n");
					lstrcat((char*)dbei.pBlob,"SMS was sent succesfully");
				}
				else
				{
					dbei.cbBlob = lstrlen("SMS was not sent succesfully")+lstrlen("SMS Confirmation From: ")+lstrlen(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))+5;
					dbei.pBlob=(PBYTE)malloc(dbei.cbBlob);
					lstrcpy((char*)dbei.pBlob,"SMS Confirmation From: ");
					lstrcat((char*)dbei.pBlob,"+");
					lstrcat((char*)dbei.pBlob,GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL));
					lstrcat((char*)dbei.pBlob,"\r\n");
					lstrcat((char*)dbei.pBlob,"SMS was not sent succesfully");
				}			
				if((HANDLE)hContactTmp == NULL)
				{
					HWND hwndRecvSms;
					char *cNumber;
					char newtitle[256];
					cNumber=malloc(lstrlen(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))+2);
					lstrcpy(cNumber,"+");
					lstrcat(cNumber,GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL));
					lstrcat(cNumber,'\0');
					hwndRecvSms=AddRecvSMSWindow();
					if(!lstrcmp(cResult,"Yes"))
						SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT)));
					else
						SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT)));
					lstrcpy(newtitle,Translate("Unknown"));
					lstrcat(newtitle," - ");
					lstrcat(newtitle,Translate("Received SMS Confirmation"));
					SetWindowText(hwndRecvSms,newtitle);
					SetRecvSMSWindowHContact(hwndRecvSms,NULL);
					SetDlgItemText(hwndRecvSms,IDC_NAME,"Unknown");
					SetDlgItemText(hwndRecvSms,IDC_NUMBER,cNumber);
					SetDlgItemText(hwndRecvSms,IDC_MESSAGE,(char*)dbei.pBlob);
					return 0;
				}
				CallService(MS_DB_EVENT_ADD, (WPARAM)hContactTmp, (LPARAM)&dbei);
				free(cResult);
				return 0;
			}
		}
	}
	else if((ack->result==ACKRESULT_FAILED) || ((GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL) != NULL) && (!lstrcmp(GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL),"No"))))
	{
		HWND hwndDlg;
		hwndDlg=GetHwndByHProcess(ack->hProcess);
		if(hwndDlg != NULL)
		{	
			HWND hwndTimeOut;
			char cMessage[512];
			char caption[200];
			char number[161];
			GetDlgItemText(hwndDlg,IDC_MULTIPLE,caption,sizeof(caption));
			if(lstrcmp(caption,Translate("Multiple >>")))
			{
				TVITEM tvi;
				tvi.mask=TVIF_TEXT;
				tvi.hItem=GetSendSMSWindowHItemSend(hwndDlg);
				tvi.pszText=number;
				tvi.cchTextMax=sizeof(number);
				TreeView_GetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvi);
			}
			else
				GetDlgItemText(hwndDlg,IDC_ADDRESS,number,sizeof(number));
			wsprintf(cMessage,Translate("SMS message didn't send by ICQ to %s because :\r\n"),number);
			if(ack->result==ACKRESULT_FAILED)
				lstrcat(cMessage,_strdup((char*)ack->lParam));
			else
				lstrcat(cMessage,GetXMLField(_strdup((char*)ack->lParam),"sms_response","error","params","param",NULL));
			KillTimer(hwndDlg,wParam);
			ShowWindow(hwndDlg,SW_SHOWNORMAL);
			EnableWindow(hwndDlg,FALSE);
			hwndTimeOut=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSTIMEDOUT),hwndDlg,SMSTimedOutDlgProc);
			SetDlgItemText(hwndTimeOut,IDC_STATUS,cMessage);
		}
	}
	else if((GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL) != NULL) && (!lstrcmp(GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL),"Yes")))
	{
		HWND hwndDlg;
		hwndDlg=GetHwndByHProcess(ack->hProcess);
		if(hwndDlg != NULL)
		{
			HWND hwndAccepted;
			KillTimer(hwndDlg,wParam);
			AddSendSMSWindowDB(hwndDlg);
			if(!GetSendSMSWindowMultiple(hwndDlg))
			{
				char cShowACK[2];
				GetStringOption(3,cShowACK,sizeof(cShowACK));
				if(cShowACK[0] == '1')
				{	
					hwndAccepted=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSACCEPT),hwndDlg,SMSAcceptedDlgProc);
					SetDlgItemText(hwndAccepted,IDC_SOURCE,GetXMLField(_strdup((char*)ack->lParam),"sms_response","source",NULL));
					SetDlgItemText(hwndAccepted,IDC_MESSAGEID,GetXMLField(_strdup((char*)ack->lParam),"sms_response","message_id",NULL));
					SetDlgItemText(hwndAccepted,IDC_NETWORK,GetXMLField(_strdup((char*)ack->lParam),"sms_response","network",NULL));
					return 0;
				}
				RemoveSendSMSWindow(hwndDlg);
			}
			else
			{
				if(GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg))==NULL)
				{
					RemoveSendSMSWindow(hwndDlg);
					return 0;
				}
				SetSendSMSWindowAsSent(hwndDlg);
				SetSendSMSWindowHItemSend(hwndDlg,GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg)));
				SendSMSWindowNext(hwndDlg);
			}
		}
	}
	else if((GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL) != NULL) && (!lstrcmp(GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL),"SMTP")))
	{
		HWND hwndDlg;
		hwndDlg=GetHwndByHProcess(ack->hProcess);
		if(hwndDlg != NULL)
		{
			HWND hwndAccepted;
			KillTimer(hwndDlg,wParam);
			AddSendSMSWindowDB(hwndDlg);
			if(!GetSendSMSWindowMultiple(hwndDlg))
			{
				char cShowACK[2];
				GetStringOption(3,cShowACK,sizeof(cShowACK));
				if(cShowACK[0] == '1')
				{	
					hwndAccepted=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSACCEPT),hwndDlg,SMSAcceptedDlgProc);
					SetDlgItemText(hwndAccepted,IDC_ST_SOURCE,"From:");
					SetDlgItemText(hwndAccepted,IDC_ST_MESSAGEID,"To:");
					SetDlgItemText(hwndAccepted,IDC_SOURCE,GetXMLField(_strdup((char*)ack->lParam),"sms_response","from",NULL));
					SetDlgItemText(hwndAccepted,IDC_MESSAGEID,GetXMLField(_strdup((char*)ack->lParam),"sms_response","to",NULL));
					SetDlgItemText(hwndAccepted,IDC_NETWORK,"ICQ");
					return 0;
				}
				RemoveSendSMSWindow(hwndDlg);
			}
			else
			{
				if(GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg))==NULL)
				{
					RemoveSendSMSWindow(hwndDlg);
					return 0;
				}
				SetSendSMSWindowAsSent(hwndDlg);
				SetSendSMSWindowHItemSend(hwndDlg,GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg)));
				SendSMSWindowNext(hwndDlg);
			}
		}
	}
	else
	{
		HWND hwndDlg;
		hwndDlg=GetHwndByHProcess(ack->hProcess);
		if(hwndDlg != NULL)
		{
			
			KillTimer(hwndDlg,wParam);
			AddSendSMSWindowDB(hwndDlg);		
			if(!GetSendSMSWindowMultiple(hwndDlg))
				RemoveSendSMSWindow(hwndDlg);
			else
			{
				if(GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg))==NULL)
				{
					RemoveSendSMSWindow(hwndDlg);
					return 0;
				}
				SetSendSMSWindowAsSent(hwndDlg);
				SetSendSMSWindowHItemSend(hwndDlg,GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg)));
				SendSMSWindowNext(hwndDlg);
			}
		}
	}
	return 0;
}

//Handles new SMS messages added to the database
int handleNewMessage(WPARAM wparam,LPARAM lparam)
{
	CLISTEVENT cle;
	char *contactName;
	char toolTip[256];
	HANDLE hContact = (HANDLE)wparam;
	DBEVENTINFO dbei={0};
	dbei.cbSize=sizeof(dbei);
	dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)lparam,0);
	dbei.pBlob=(PBYTE)malloc(dbei.cbBlob);
	CallService(MS_DB_EVENT_GET,lparam,(LPARAM)&dbei);
	if((dbei.eventType != ICQEVENTTYPE_SMS) && (dbei.eventType!=ICQEVENTTYPE_SMSCONFIRMATION)) return 0;
	if(dbei.flags == DBEF_SENT) return 0;
	{
		char *cTmp;
		cTmp=malloc(lstrlen(dbei.pBlob)+1);
		lstrcpy(cTmp,dbei.pBlob);
		*(cTmp + 7) = '\0';
		if(!lstrcmp("SMS To:",cTmp)) return 0;
		free(cTmp);
	}
	if((HANDLE)wparam == NULL)	return 0;
	{
		char *cTmp;
		cTmp=malloc(lstrlen(dbei.pBlob)+1);
		lstrcpy(cTmp,dbei.pBlob);
		*(cTmp + 22) = '\0';
		if(!lstrcmp("SMS Confirmation From:",cTmp)) 
		{
			int i;
			char *cStatus;
			cStatus=(char*)malloc(lstrlen(dbei.pBlob)+1);
			lstrcpy(cStatus,dbei.pBlob);
			for(i=0;i<(signed)lstrlen(dbei.pBlob);i++)
				if(*(cStatus+i) == '\n')
					break;
			cStatus=cStatus + i + 1;
			SkinPlaySound("RecvSMSConfirmation");
			if(DBGetContactSettingByte(NULL,"SRMsg","AutoPopup",0)) 
			{
				HWND hwndRecvSms;
				int i;
				char cTmpNum[256];
				char newtitle[256];
				hwndRecvSms=AddRecvSMSWindow();
				if((HANDLE)wparam != NULL)
					lstrcpy(newtitle,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)(HANDLE)wparam,0));
				else
					lstrcpy(newtitle,Translate("Unknown"));
				lstrcat(newtitle," - ");
				lstrcat(newtitle,Translate("Received SMS Confirmation"));
				SetWindowText(hwndRecvSms,newtitle);
				SetRecvSMSWindowHContact(hwndRecvSms,(HANDLE)wparam);
				SetDlgItemText(hwndRecvSms,IDC_NAME,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wparam,0));
				for(i=23;*((char*)dbei.pBlob + i)!='\r';i++)
					cTmpNum[i-23]=*((char*)dbei.pBlob + i);
				cTmpNum[i-23]='\0';
				if(!lstrcmp("SMS was sent succesfully",((char*)dbei.pBlob + i + 2)))
					SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT)));
				else
					SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT)));
				SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
				SetDlgItemText(hwndRecvSms,IDC_MESSAGE,(char*)dbei.pBlob);		
				CallService(MS_DB_EVENT_DELETE,wparam,(LPARAM)&dbei);					
				return 0;
			}
			ZeroMemory(&cle,sizeof(cle));
			cle.cbSize=sizeof(cle);
			cle.hContact=(HANDLE)wparam;
			cle.hDbEvent=(HANDLE)lparam;
			if(!lstrcmp(cStatus,"SMS was not sent succesfully"))
				cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT));
			else
				cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT));
			cle.pszService="SRSMS/ReadSmsAck";
			contactName=(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wparam,0);
			wsnprintf(toolTip,sizeof(toolTip),Translate("SMS Confirmation from %s"),contactName);
			cle.pszTooltip=toolTip;
			CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
			return 0;
		}
		free(cTmp);
	}
	SkinPlaySound("RecvSMSMsg");
	if(DBGetContactSettingByte(NULL,"SRMsg","AutoPopup",0)) 
	{
		HWND hwndRecvSms;
		int i;
		char cTmpNum[256];
		char newtitle[256];
		hwndRecvSms=AddRecvSMSWindow();
		if((HANDLE)wparam != NULL)
			lstrcpy(newtitle,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)(HANDLE)wparam,0));
		else
			lstrcpy(newtitle,Translate("Unknown"));
		lstrcat(newtitle," - ");
		lstrcat(newtitle,Translate("Received SMS"));
		SetWindowText(hwndRecvSms,newtitle);
		SetRecvSMSWindowHContact(hwndRecvSms,(HANDLE)wparam);
		SetDlgItemText(hwndRecvSms,IDC_NAME,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wparam,0));
		for(i=10;*((char*)dbei.pBlob + i)!='\r';i++)
			cTmpNum[i-10]=*((char*)dbei.pBlob + i);
		cTmpNum[i-10]='\0';
		SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
		SetDlgItemText(hwndRecvSms,IDC_MESSAGE,(char*)dbei.pBlob);
		CallService(MS_DB_EVENT_MARKREAD,wparam,(LPARAM)&dbei);
		return 0;
	}
	ZeroMemory(&cle,sizeof(cle));
	cle.cbSize=sizeof(cle);
	cle.hContact=(HANDLE)wparam;
	cle.hDbEvent=(HANDLE)lparam;
	cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));
	cle.pszService="SRSMS/ReadSms";
	contactName=(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wparam,0);
	wsnprintf(toolTip,sizeof(toolTip),Translate("SMS Message from %s"),contactName);
	cle.pszTooltip=toolTip;
	CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
	return 0;
}

void InitSmsRecv(void)
{
	hHookAck=HookEvent(ME_PROTO_ACK,handleAckSMS);
	hHookDbAdd=HookEvent(ME_DB_EVENT_ADDED,handleNewMessage);
	SkinAddNewSound("RecvSMSMsg",Translate("Incoming SMS Message"),"message.wav");
	SkinAddNewSound("RecvSMSConfirmation",Translate("Incoming SMS Confirmation"),"message.wav");
}

void UninitSmsRecv(void)
{
	UnhookEvent(hHookAck);
	UnhookEvent(hHookDbAdd);
	RemoveAllRecvSMSWindow();
}


char *ReplaceNwithRN(const char *cStr)
{
	int i,j;
	char *cStrTmp=(char*)malloc(512);
	*cStrTmp='\0';
	i=0;
	j=0;
	while(*(cStr + i) != '\0')
	{
		if(*(cStr + i) == '\n')
		{
			lstrcat(cStrTmp,"\r\n");
			i++;
			j++;
			j++;
		}
		else if(*(cStr + i) == '\r')
		{
			lstrcat(cStrTmp,"\r\n");
			i++;
			j++;
			j++;
		}
		*(cStrTmp + j) = *(cStr + i);
		i++;
		j++;
	}
	lstrcat(cStrTmp,"\0");
	return cStrTmp;
}