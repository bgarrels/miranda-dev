/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes
Copyright (C) 2007-8  Rozhuk Ivan

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/

#include "main.h"





extern "C" __declspec(naked) void __cdecl _chkstk()
{
	#define _PAGESIZE_ 4096

			__asm
			{
			push    ecx

	; Calculate new TOS.

			lea     ecx, [esp] + 8 - 4      ; TOS before entering function + size for ret value
			sub     ecx, eax                ; new TOS

	; Handle allocation size that results in wraparound.
	; Wraparound will result in StackOverflow exception.

			sbb     eax, eax                ; 0 if CF==0, ~0 if CF==1
			not     eax                     ; ~0 if TOS did not wrapped around, 0 otherwise
			and     ecx, eax                ; set to 0 if wraparound

			mov     eax, esp                ; current TOS
			and     eax, not ( _PAGESIZE_ - 1) ; Round down to current page boundary

	cs10:
			cmp     ecx, eax                ; Is new TOS
			jb      short cs20              ; in probed page?
			mov     eax, ecx                ; yes.
			pop     ecx
			xchg    esp, eax                ; update esp
			mov     eax, dword ptr [eax]    ; get return address
			mov     dword ptr [esp], eax    ; and put it at new TOS
			ret

	; Find next lower page and probe
	cs20:
			sub     eax, _PAGESIZE_         ; decrease by PAGESIZE
			test    dword ptr [eax],eax     ; probe page.
			jmp     short cs10

			}
}//


extern "C" void __declspec(naked) __cdecl _aulldiv()
{// http://tamiaode.3322.org/svn/ntldr/trunk/source/ntldr/ia32/x86stub.cpp
	__asm
	{
		push	ebx
		push	esi

		mov	eax,[esp + 24]
		or	eax,eax
		jnz	short L1

		mov	ecx,[esp + 20]
		mov	eax,[esp + 16]
		xor	edx,edx
		div	ecx
		mov	ebx,eax
		mov	eax,[esp + 12]
		div	ecx
		mov	edx,ebx
		jmp	short L2

	L1:
		mov	ecx,eax
		mov	ebx,[esp + 20]
		mov	edx,[esp + 14]
		mov	eax,[esp + 12]

	L3:
		shr	ecx,1
		rcr	ebx,1
		shr	edx,1
		rcr	eax,1
		or	ecx,ecx
		jnz	short L3
		div	ebx
		mov	esi,eax

		mul	dword ptr [esp + 24]
		mov	ecx,eax
		mov	eax,[esp + 20]
		mul	esi
		add	edx,ecx
		jc	short L4

		cmp	edx,[esp + 16]
		ja	short L4
		jb	short L5
		cmp	eax,[esp + 12]
		jbe	short L5
	L4:
		dec	esi
	L5:
		xor	edx,edx
		mov	eax,esi

	L2:

		pop	esi
		pop	ebx

		ret	16
	}
}//





HANDLE hHookRebuildCMenu,hContactMenuItem;
HINSTANCE hInst;
MM_INTERFACE mmi;
PLUGINLINK *pluginLink;

PLUGININFOEX pluginInfoEx={
	sizeof(PLUGININFOEX),
	"SMS",
	PLUGIN_MAKE_VERSION(0,2,5,1),
	"Send SMS text messages to mobile phones through the IM networks",
	"Richard Hughes, Improved by Ariel Shulman, rewritten by Rozhuk Ivan",
	"Rozhuk_I@mail.ru",
	"� 2001-2 Richard Hughes, 2003 Ariel Shulman, 2007-2009 Rozhuk Ivan (Rozhuk_I@mail.ru)",
	"http://miranda-icq.sourceforge.net/",
	0,		//not transient
	0,		//doesn't replace anything built-in
	// {70AC2AC9-85C6-4624-9B05-24733FEBB052}
	SMS_GUID
};


static const MUUID interfaces[]={SMS_GUID,MIID_LAST};



int SmsRebuildContactMenu(WPARAM wParam,LPARAM lParam);




BOOL WINAPI DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
    switch(dwReason){
	case DLL_PROCESS_ATTACH:
		//ZeroMemory(&mSmsSettings,sizeof(mSmsSettings));
		//mSmsSettings.hInstance=hInstance;
		//mSmsSettings.hHeap=GetProcessHeap();
		hInst=hInstance;
		DisableThreadLibraryCalls((HMODULE)hInstance);
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
    }
return(TRUE);
}

__declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	if (mirandaVersion<PLUGIN_MAKE_VERSION(0,2,0,0)) 
	{
		MessageBox(NULL,TEXT("Pleace, update your Miranda IM, SMS will not load with this version."),NULL,(MB_OK|MB_ICONERROR));
		return(NULL);
	}
return(&pluginInfoEx);
}

__declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
return((PLUGININFO*)MirandaPluginInfoEx(mirandaVersion));
}


__declspec(dllexport) const MUUID* MirandaPluginInterfaces()
{
return(interfaces);
}



int __declspec(dllexport) Load(PLUGINLINK *link)
{
	CLISTMENUITEM mi={0};

	pluginLink=link;
	mir_getMMI(&mmi);

	CreateServiceFunction("SRSMS/ReadSms",ReadMsgSMS);
	CreateServiceFunction("SRSMS/ReadSmsAck",ReadAckSMS);
	CreateServiceFunction("SMS/SendSMS",SendSMSMenuCommand);
	CreateServiceFunction("SendSMS/MenuCommand",SMSMenuCommand);

	mi.cbSize=sizeof(mi);
	mi.position=300050000;
	mi.flags=0;
	mi.hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_SMS));
	mi.pszName=Translate("Send &SMS...");
	mi.pszService="SMS/SendSMS";
	CallService(MS_CLIST_ADDMAINMENUITEM,0,(LPARAM)&mi);

	mi.position=-2000070000;
	mi.flags=0;
	mi.hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_SMS));
	mi.pszName=Translate("&SMS Message");
	mi.pszService="SendSMS/MenuCommand";
	hContactMenuItem=(HANDLE)CallService(MS_CLIST_ADDCONTACTMENUITEM,0,(LPARAM)&mi);

	hHookRebuildCMenu=HookEvent(ME_CLIST_PREBUILDCONTACTMENU,SmsRebuildContactMenu);

	InitSmsSend();
	InitSmsRecv();
	InitOptions();
	RestoreUnreadMessageAlerts();

return(0);
}

int __declspec(dllexport) Unload(void)
{
	if (hHookRebuildCMenu) UnhookEvent(hHookRebuildCMenu);
	UninitSmsSend();
	UninitSmsRecv();
	UninitOptions();
return(0);
}

//This function return plugin HINSTANCE.
HINSTANCE GetPluginhInst()
{
return(hInst);
}

int SmsRebuildContactMenu(WPARAM wParam,LPARAM lParam)
{
	CListShowMenuItem(hContactMenuItem,(BOOL)GetContactPhonesCount((HANDLE)wParam));
return(0);
}


//This function called when user clicked on the "SMS Send" in the Main Menu.
static int SendSMSMenuCommand(WPARAM wParam,LPARAM lParam)
{
	HWND hwndSendSms;

	hwndSendSms=SendSMSWindowAdd(NULL);
	EnableWindow(GetDlgItem(hwndSendSms,IDC_NAME),TRUE);
	EnableWindow(GetDlgItem(hwndSendSms,IDC_SAVENUMBER),FALSE);

	for(HANDLE hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);hContact!=NULL;hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0))
	{
		if (GetContactPhonesCount(hContact))
		{
			SendDlgItemMessage(hwndSendSms,IDC_NAME,CB_ADDSTRING,0,(LPARAM)DB_GetContactName(hContact));
			SendSMSWindowSMSContactAdd(hwndSendSms,hContact);
		}
	}
return(0);
}

//This function called when user clicked on the "SMS Message" on one of the users.
static int SMSMenuCommand(WPARAM wParam,LPARAM lParam)
{
	HWND hwndSendSms;

	hwndSendSms=SendSMSWindowIsOtherInstanceHContact((HANDLE)wParam);
	if (hwndSendSms)
	{
		SetFocus(hwndSendSms);
	}else{
		hwndSendSms=SendSMSWindowAdd((HANDLE)wParam);
	}
return(0);
}

//This function used to popup a read SMS window after the user clicked on the received SMS message.
static int ReadMsgSMS(WPARAM wParam,LPARAM lParam)
{
	int iRet=1;
	DBEVENTINFO dbei={0};

	dbei.cbSize=sizeof(dbei);
	if ((dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)((CLISTEVENT*)lParam)->hDbEvent,0))!=-1)
	{
		dbei.pBlob=(PBYTE)MEMALLOC(dbei.cbBlob);
		if (dbei.pBlob)
		{
			if (CallService(MS_DB_EVENT_GET,(WPARAM)((CLISTEVENT*)lParam)->hDbEvent,(LPARAM)&dbei)==0)
			if (dbei.eventType==ICQEVENTTYPE_SMS || dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION)
			if (dbei.cbBlob>MIN_SMS_DBEVENT_LEN)
			{
				if (RecvSMSWindowAdd(((CLISTEVENT*)lParam)->hContact,ICQEVENTTYPE_SMS,NULL,0,(LPSTR)dbei.pBlob,dbei.cbBlob,IDI_SMS))
				{
					CallService(MS_DB_EVENT_MARKREAD,(WPARAM)((CLISTEVENT*)lParam)->hContact,(LPARAM)((CLISTEVENT*)lParam)->hDbEvent);
					iRet=0;
				}
			}
			MEMFREE(dbei.pBlob);
		}
	}
return(iRet);
}

//This function used to popup a read SMS window after the user clicked on the received SMS confirmation.
static int ReadAckSMS(WPARAM wParam,LPARAM lParam)
{
	int iRet=1;
	DBEVENTINFO dbei={0};

	dbei.cbSize=sizeof(dbei);
	if ((dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)((CLISTEVENT*)lParam)->hDbEvent,0))!=-1)
	{
		dbei.pBlob=(PBYTE)MEMALLOC(dbei.cbBlob);
		if (dbei.pBlob)
		{
			if (CallService(MS_DB_EVENT_GET,(WPARAM)((CLISTEVENT*)lParam)->hDbEvent,(LPARAM)&dbei)==0)
			if (dbei.eventType==ICQEVENTTYPE_SMS || dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION)
			if (dbei.cbBlob>MIN_SMS_DBEVENT_LEN)
			{
				if (RecvSMSWindowAdd(((CLISTEVENT*)lParam)->hContact,ICQEVENTTYPE_SMSCONFIRMATION,NULL,0,(LPSTR)dbei.pBlob,dbei.cbBlob,0))
				{
					CallService(MS_DB_EVENT_DELETE,(WPARAM)((CLISTEVENT*)lParam)->hContact,(LPARAM)((CLISTEVENT*)lParam)->hDbEvent);
					iRet=0;
				}
			}
			MEMFREE(dbei.pBlob);
		}
	}
return(iRet);
}

void RestoreUnreadMessageAlerts(void)
{
	DBEVENTINFO dbei={0};
	HANDLE hDbEvent,hContact;

	dbei.cbSize=sizeof(dbei);
	for(hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);hContact!=NULL;hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0))
	for(hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDFIRSTUNREAD,(WPARAM)hContact,0);hDbEvent!=NULL;hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDNEXT,(WPARAM)hDbEvent,0))
	{
		dbei.cbBlob=0;
		if (CallService(MS_DB_EVENT_GET,(WPARAM)hDbEvent,(LPARAM)&dbei)==0)
		if ((dbei.flags&(DBEF_SENT|DBEF_READ))==0 && ((dbei.eventType==ICQEVENTTYPE_SMS) || (dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION)))
		if (dbei.cbBlob>MIN_SMS_DBEVENT_LEN)
		{
			handleNewMessage((WPARAM)hContact,(LPARAM)hDbEvent);
		}
	}

	hContact=NULL;
	for(hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDFIRSTUNREAD,(WPARAM)hContact,0);hDbEvent!=NULL;hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDNEXT,(WPARAM)hDbEvent,0))
	{
		dbei.cbBlob=0;
		if (CallService(MS_DB_EVENT_GET,(WPARAM)hDbEvent,(LPARAM)&dbei)==0)
		if ((dbei.flags&(DBEF_SENT|DBEF_READ))==0 && ((dbei.eventType==ICQEVENTTYPE_SMS) || (dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION)))
		if (dbei.cbBlob>MIN_SMS_DBEVENT_LEN)
		{
			handleNewMessage((WPARAM)hContact,(LPARAM)hDbEvent);
		}
	}
}