/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes
Copyright (C) 2007  Rozhuk Ivan

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/

#include "main.h"



//This function gets HWND of the window, the number, and the message.
void StartSmsSend(HWND hWndDlg,LPSTR lpszModule,LPSTR lpszPhone,SIZE_T dwPhoneSize,LPSTR lpszMessage,SIZE_T dwMessageSize)
{
	SIZE_T dwBuffSize=(dwPhoneSize+dwMessageSize+MAX_PATH);
	DBEVENTINFO *pdbei;

	pdbei=(DBEVENTINFO*)MEMALLOC((sizeof(DBEVENTINFO)+dwBuffSize));
	if (pdbei)
	{
		char szPhone[MAX_PHONE_LEN],szServiceName[MAX_PATH];;
 		LPSTR lpszBuff,lpszMessageConverted;
		LPWSTR lpwszBuff;
		SIZE_T dwBuffLen;
		HANDLE hProcess;

		lpszBuff=(LPSTR)(pdbei+1);
		dwPhoneSize=CopyNumber(szPhone,lpszPhone,dwPhoneSize);
		pdbei->timestamp=time(NULL);
		pdbei->flags=DBEF_SENT;
		pdbei->eventType=ICQEVENTTYPE_SMS;
		pdbei->cbBlob=(mir_snprintf(lpszBuff,dwBuffSize,"SMS To: +%s\r\n%s",szPhone,lpszMessage)+4);
		pdbei->pBlob=(PBYTE)lpszBuff;
		SendSMSWindowDbeiSet(hWndDlg,pdbei);


		//char *tmpText=lpszMessage;
		//char *tmpEncodedXML=NULL;
		//tmpText=(char *)MEMALLOC(256);
		//tmpEncodedXML=EncodeXML(lpszMessage);
		//utf8_encode(tmpEncodedXML,&tmpText);


		lpwszBuff=(LPWSTR)MEMALLOC(((dwMessageSize+MAX_PATH)*sizeof(WCHAR)));
		if (lpwszBuff)
		{
			dwBuffLen=MultiByteToWideChar(GetConsoleCP(),MB_PRECOMPOSED,lpszMessage,dwMessageSize,lpwszBuff,(dwMessageSize+MAX_PATH));
			if (dwBuffLen)
			{
				lpszMessageConverted=(LPSTR)MEMALLOC((dwMessageSize+MAX_PATH));
				if (lpszMessageConverted)
				{
					dwMessageSize=WideCharToMultiByte(CP_UTF8,0,lpwszBuff,dwBuffLen,lpszMessageConverted,(dwMessageSize+MAX_PATH),NULL,NULL);

					mir_snprintf(szServiceName,sizeof(szServiceName),"%s%s",lpszModule,MS_ICQ_SENDSMS);
					hProcess=(HANDLE)CallService(szServiceName,(WPARAM)szPhone,(LPARAM)lpszMessageConverted);
					SendSMSWindowHProcessSet(hWndDlg,hProcess);
					MEMFREE(lpszMessageConverted);
				}
			}
			MEMFREE(lpwszBuff);
		}
	}
}

void InitSmsSend()
{
	SendSMSWindowInitialize();
}

void UninitSmsSend()
{
	SendSMSWindowDestroy();
}


