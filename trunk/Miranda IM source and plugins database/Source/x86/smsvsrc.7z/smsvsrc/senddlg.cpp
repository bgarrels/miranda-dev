/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes
Copyright (C) 2007-2009  Rozhuk Ivan

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/

#include "main.h"
#include "senddlg.h"



//Defnition needed to the SMS window list
typedef struct
{
	LIST_MT_ITEM	lmtListMTItem;
	HWND			hWnd;
	HBRUSH			hBkgBrush;
	HANDLE			hProcess;
	HANDLE			hContact;
	HANDLE			hMyContact;
	HTREEITEM		hItemSend;
	BOOL			bMultiple;
	SIZE_T			dwContactsListCount;
	HANDLE			*phContactsList;
	DBEVENTINFO		*pdbei;
} SEND_SMS_WINDOW_DATA;





void			AddContactPhonesToCombo		(HWND hWnd,HANDLE hContact);
void			SendSMSWindowFillTreeView	(HWND hWnd);
SIZE_T			GetSMSMessageLenMax			(HWND hWndDlg);

#define GET_WINDOW_DATA(hWndDlg)	((SEND_SMS_WINDOW_DATA*)GetWindowLongPtr(hWndDlg,GWL_USERDATA))

static WNDPROC OldEditWndProc;
static LIST_MT	lmtSendSMSWindowsListMT;
//END of defenitions



DWORD SendSMSWindowInitialize()
{
	DWORD dwRetErrorCode;

	dwRetErrorCode=ListMTInitialize(&lmtSendSMSWindowsListMT,0);
return(dwRetErrorCode);
}

void SendSMSWindowDestroy()
{
	SEND_SMS_WINDOW_DATA *psswdWindowData;

	ListMTLock(&lmtSendSMSWindowsListMT);
	while(ListMTItemGetFirst(&lmtSendSMSWindowsListMT,NULL,(LPVOID*)&psswdWindowData)==NO_ERROR)
	{// ����
		SendSMSWindowRemove(psswdWindowData->hWnd);
	}
	ListMTUnLock(&lmtSendSMSWindowsListMT);
	ListMTDestroy(&lmtSendSMSWindowsListMT);
}


static LRESULT CALLBACK MessageSubclassProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message){
	case WM_CHAR:
		if (wParam=='\n' && GetKeyState(VK_CONTROL)&0x8000)
		{
			PostMessage(GetParent(hwnd),WM_COMMAND,IDOK,0);
			return(0);
		}
		break;
	}
return(CallWindowProc(OldEditWndProc,hwnd,message,wParam,lParam));
}


BOOL CALLBACK SendSmsDlgProc(HWND hWndDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	switch(message){
	case WM_INITDIALOG:
		TranslateDialogDefault(hWndDlg); //Translate intially - bid
		AddWinHandle(GetDlgItem(hWndDlg,IDC_MESSAGE));
		
		psswdWindowData=(SEND_SMS_WINDOW_DATA*)lParam;
		SetWindowLongPtr(hWndDlg,GWL_USERDATA,(LONG_PTR)lParam);
		OldEditWndProc=(WNDPROC)SetWindowLongPtr(GetDlgItem(hWndDlg,IDC_MESSAGE),GWL_WNDPROC,(LONG_PTR)MessageSubclassProc);
		
		SendMessage(hWndDlg,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS)));
		SendDlgItemMessage(hWndDlg,IDC_HISTORY,BM_SETIMAGE,IMAGE_ICON,(LPARAM)LoadImage(GetPluginhInst(),MAKEINTRESOURCE(IDI_HISTORY),IMAGE_ICON,GetSystemMetrics(SM_CXSMICON),GetSystemMetrics(SM_CYSMICON),0));
		{
			HICON hIcon;
			HIMAGELIST hIml=ImageList_Create(16,16,ILC_COLOR32|ILC_MASK,0,30);
			TreeView_SetImageList(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),hIml,TVSIL_NORMAL);	
			hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_NOTICK));		ImageList_AddIcon(hIml,hIcon);
			hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_TICK));			ImageList_AddIcon(hIml,hIcon);
			hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_HALFTICK));		ImageList_AddIcon(hIml,hIcon);
			hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));			ImageList_AddIcon(hIml,hIcon);
			hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT));	ImageList_AddIcon(hIml,hIcon);
			hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT));		ImageList_AddIcon(hIml,hIcon);
		}
		{	
			HFONT hFont;
			LOGFONT lf;
			hFont=(HFONT)SendDlgItemMessage(hWndDlg,IDC_MESSAGE,WM_GETFONT,0,0);
			if (hFont && hFont!=(HFONT)SendDlgItemMessage(hWndDlg,IDOK,WM_GETFONT,0,0)) DeleteObject(hFont);
			LoadMsgDlgFont(MSGFONTID_MESSAGEAREA,&lf,NULL);
			hFont=CreateFontIndirect(&lf);
			SendDlgItemMessage(hWndDlg,IDC_MESSAGE,WM_SETFONT,(WPARAM)hFont,MAKELPARAM(TRUE,0));

			COLORREF colour=DBGetContactSettingDword(NULL,SRMMMOD,SRMSGSET_INPBKGCOLOUR,SRMSGDEFSET_BKGCOLOUR);
			psswdWindowData->hBkgBrush=CreateSolidBrush(colour);
		}
		{
			TOOLINFO ti;
			HWND hwndToolTips;
			hwndToolTips=CreateWindowEx(WS_EX_TOPMOST,TOOLTIPS_CLASS,"",WS_POPUP,0,0,0,0,NULL,NULL,GetModuleHandle(NULL),NULL);
			ZeroMemory(&ti,sizeof(ti));
			ti.cbSize=sizeof(ti);
			ti.uFlags=TTF_IDISHWND|TTF_SUBCLASS;
			ti.uId=(UINT)GetDlgItem(hWndDlg,IDC_HISTORY);
			ti.lpszText=Translate("View User's History");
			SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
			ti.uId=(UINT)GetDlgItem(hWndDlg,IDC_ADDNUMBER);
			ti.lpszText=Translate("Add Number To The Multiple List");
			SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
			ti.uId=(UINT)GetDlgItem(hWndDlg,IDC_SAVENUMBER);
			ti.lpszText=Translate("Save Number To The User's Details Phonebook");
			SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
			ti.uId=(UINT)GetDlgItem(hWndDlg,IDC_MULTIPLE);
			ti.lpszText=Translate("Show/Hide Multiple List");
			SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
			ti.uId=(UINT)GetDlgItem(hWndDlg,IDC_COUNT);
			ti.lpszText=Translate("Shows How Much Chars You've Typed");
			SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
		}
		{
			RECT rcWin,rcList;
			GetWindowRect(hWndDlg,&rcWin);
			GetWindowRect(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),&rcList);
			SetWindowPos(hWndDlg,0,rcWin.left,rcWin.top,rcWin.right-rcWin.left - (rcList.right-rcList.left) - 10,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
		}

		{
			int protoCount,i;
			char szServiceName[MAX_PATH];
			PROTOCOLDESCRIPTOR **protos;

			// Make sure we have some networks to search on.
			CallService(MS_PROTO_ENUMPROTOCOLS,(WPARAM)&protoCount,(LPARAM)&protos);
			for(i=0;i<protoCount;i++)
			{
				if ((*(protos+i))->type==PROTOTYPE_PROTOCOL)
				{
					mir_snprintf(szServiceName,sizeof(szServiceName),"%s%s",(*(protos+i))->szName,MS_ICQ_SENDSMS);
					if (ServiceExists(szServiceName))
					{
						//mir_snprintf(szServiceName,sizeof(szServiceName),"%s%s",(*(protos+i))->szName,PS_GETNAME);
						//CallService(szServiceName,sizeof(szServiceName),(LPARAM)szServiceName);
						//SendDlgItemMessage(hWndDlg,IDC_PROTOCOLS,CB_ADDSTRING,0,(LPARAM)szServiceName);
						SendDlgItemMessage(hWndDlg,IDC_PROTOCOLS,CB_ADDSTRING,0,(LPARAM)(*(protos+i))->szName);
					}
				}
			}
		}

		{	
			char cSign[1024];
			char cBegin[2];
			char cUseSign[2];
			char str[20];
			int count;
			//cBegin[0] = '0';
			//cBegin[1] = '\0';
			GetStringOption(OPTION_SIGNATURE,cSign,sizeof(cSign));
			GetStringOption(OPTION_USESIGNATURE,cUseSign,sizeof(cUseSign));
			if ((*cSign!='\0') && (cUseSign[0]!='0'))
			{
				GetStringOption(OPTION_SIGNATUREPOS,cBegin,sizeof(cBegin));
				count=lstrlen(cSign);
				SetDlgItemText(hWndDlg,IDC_MESSAGE,cSign);
				wsprintf(str,"%d/%d",count,GetSMSMessageLenMax(hWndDlg));
				SetDlgItemText(hWndDlg,IDC_COUNT,str);
				
				if (!(cBegin[0] == '0')) SendDlgItemMessage(hWndDlg,IDC_MESSAGE,EM_SETSEL,lstrlen(cSign),lstrlen(cSign));
				EnableWindow(GetDlgItem(hWndDlg,IDOK),count);
			}else{
				SetDlgItemText(hWndDlg,IDC_COUNT,"0/160");
			}
		}

		SendDlgItemMessage(hWndDlg,IDC_PROTOCOLS,CB_SETCURSEL,(WPARAM)DB_SMS_GetDword(NULL,"LastProto",0),0);
		if (Utils_RestoreWindowPosition(hWndDlg,(DBGetContactSettingByte(NULL,"SRMsg","SavePerContact",0)? psswdWindowData->hMyContact:NULL),PROTOCOL_NAME,"send"))
		{// def pos
			SetWindowPos(hWndDlg,0,200,200,400,350,SWP_NOZORDER);
		}
		InvalidateRect(GetDlgItem(hWndDlg,IDC_MESSAGE),NULL,FALSE);
		return(TRUE);
	case WM_GETMINMAXINFO:
		if (psswdWindowData->bMultiple)
		{
			((LPMINMAXINFO)lParam)->ptMinTrackSize.x=461; 
			((LPMINMAXINFO)lParam)->ptMinTrackSize.y=230;
		}else{
			((LPMINMAXINFO)lParam)->ptMinTrackSize.x=300; 
			((LPMINMAXINFO)lParam)->ptMinTrackSize.y=230;
		}
		break;
	case WM_SIZE:
		{
			int cx,cy;
			RECT rcWin;
			GetWindowRect(hWndDlg,&rcWin);
			if (psswdWindowData->bMultiple)
			{
				cx=rcWin.right-rcWin.left-181;
				cy=rcWin.bottom-rcWin.top;
			}else{
				cx=rcWin.right-rcWin.left;
				cy=rcWin.bottom-rcWin.top;
			}
			SetWindowPos(GetDlgItem(hWndDlg,IDC_MESSAGE),0,0,0,cx - 14,cy - 132,SWP_NOZORDER|SWP_NOMOVE);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_NAME),0,0,0,(cx*35)/100,20,SWP_NOZORDER|SWP_NOMOVE);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_PROTOCOLS),0,0,0,(cx*35)/100,20,SWP_NOZORDER|SWP_NOMOVE);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_ADDRESS),0,cx - (cx*35)/100 - 11,5,(cx*35)/100,20,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_ST_ADDRESS),0,cx - (cx*35)/100 - 68,5,50,20,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_MULTIPLE),0,cx - ((cx*35)/100 + 35)/2 - 11,30,((cx*35)/100 + 35)/2,20,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_SAVENUMBER),0,cx - (cx*35)/100 - 58,30,((cx*35)/100 + 35)/2,20,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_HISTORY),0,0,0,20,20,SWP_NOZORDER|SWP_NOMOVE);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_COUNT),0,cx - 61,52,50,15,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_ST_CHARS),0,cx - 106,52,40,15,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_ADDNUMBER),0,cx,5,170,20,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),0,cx,25,170,cy - 90,SWP_NOZORDER);
			//SetWindowPos(GetDlgItem(hWndDlg,IDC_REMOVENUMBER),0,cx,cy - 110 + 25,170,20,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDOK),0,cx/2 - 87,cy - 60,80,25,SWP_NOZORDER);
			SetWindowPos(GetDlgItem(hWndDlg,IDCANCEL),0,cx/2 + 7,cy - 60,80,25,SWP_NOZORDER);
			RedrawWindow(hWndDlg,NULL,NULL,RDW_FRAME|RDW_INVALIDATE);
		}
		break;
	case WM_TIMER:
		if (wParam==TIMERID_MSGSEND)
		{
			HWND hwndTimeOut;
			char szMessage[1028],szPhone[MAX_PHONE_LEN];

			if (psswdWindowData->bMultiple)
			{
				TVITEM tvi;
				tvi.mask=TVIF_TEXT;
				tvi.hItem=SendSMSWindowHItemSendGet(hWndDlg);
				tvi.pszText=szPhone;
				tvi.cchTextMax=sizeof(szPhone);
				TreeView_GetItem(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),&tvi);
			}else{
				GetDlgItemText(hWndDlg,IDC_ADDRESS,szPhone,sizeof(szPhone));
			}
			wsprintf(szMessage,Translate("The SMS message send to %s timed out."),szPhone);				
			KillTimer(hWndDlg,wParam);
			ShowWindow(hWndDlg,SW_SHOWNORMAL);
			EnableWindow(hWndDlg,FALSE);
			hwndTimeOut=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSTIMEDOUT),hWndDlg,SMSTimedOutDlgProc);
			SetDlgItemText(hwndTimeOut,IDC_STATUS,szMessage);
		}
		break;
	case WM_CTLCOLOREDIT:
		if ((HWND)lParam==GetDlgItem(hWndDlg,IDC_MESSAGE))
		{	
			COLORREF colour;

			LoadMsgDlgFont(MSGFONTID_MESSAGEAREA,NULL,&colour);
			SetTextColor((HDC)wParam,colour);
			SetBkColor((HDC)wParam,DBGetContactSettingDword(NULL,SRMMMOD,SRMSGSET_INPBKGCOLOUR,SRMSGDEFSET_BKGCOLOUR));
			return((BOOL)psswdWindowData->hBkgBrush);
		}
		break;
	case DM_TIMEOUTDECIDED:
		EnableWindow(hWndDlg,TRUE);
		switch(wParam){
		case TIMEDOUT_CANCEL:
			if (psswdWindowData->bMultiple)
			{
				if (SendSMSWindowNextHItemGet(hWndDlg,psswdWindowData->hItemSend))
				{
					psswdWindowData->hItemSend=SendSMSWindowNextHItemGet(hWndDlg,psswdWindowData->hItemSend);
					SendSMSWindowNext(hWndDlg);
				}else{
					SendSMSWindowRemove(hWndDlg);
				}
			}else{	
				EnableWindow(GetDlgItem(hWndDlg,IDOK),TRUE);
				SendDlgItemMessage(hWndDlg,IDC_MESSAGE,EM_SETREADONLY,FALSE,0);
				EnableWindow(GetDlgItem(hWndDlg,IDC_PROTOCOLS),TRUE);
				EnableWindow(GetDlgItem(hWndDlg,IDC_ADDRESS),TRUE);
				EnableWindow(GetDlgItem(hWndDlg,IDC_SAVENUMBER),TRUE);
				EnableWindow(GetDlgItem(hWndDlg,IDC_MULTIPLE),TRUE);
				EnableWindow(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),TRUE);
				if (psswdWindowData->hMyContact==NULL) EnableWindow(GetDlgItem(hWndDlg,IDC_NAME),TRUE);
				SetFocus(GetDlgItem(hWndDlg,IDC_MESSAGE));
				psswdWindowData->hItemSend=NULL;
			}
			break;
		case TIMEDOUT_RETRY:
			{
				char szModule[MAX_PATH],szPhone[MAX_PHONE_LEN];
				LPSTR lpszMessage;
				SIZE_T dwPhoneSize,dwMessageSize;

				dwMessageSize=GetWindowTextLength(GetDlgItem(hWndDlg,IDC_MESSAGE));
				lpszMessage=(LPSTR)MEMALLOC((dwMessageSize+4));
				if (lpszMessage)
				{
					if (psswdWindowData->bMultiple)
					{
						TVITEM tvi;
						tvi.mask=TVIF_TEXT;
						tvi.hItem=psswdWindowData->hItemSend;
						tvi.pszText=szPhone;
						tvi.cchTextMax=sizeof(szPhone);
						TreeView_GetItem(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),&tvi);
						dwPhoneSize=lstrlen(szPhone);
					}else{
						dwPhoneSize=GetDlgItemText(hWndDlg,IDC_ADDRESS,szPhone,sizeof(szPhone));
					}
					dwMessageSize=GetDlgItemText(hWndDlg,IDC_MESSAGE,lpszMessage,(dwMessageSize+2));
					GetDlgItemText(hWndDlg,IDC_PROTOCOLS,szModule,sizeof(szModule));
					SendSMSWindowNumberSet(hWndDlg,szPhone,dwPhoneSize);
					StartSmsSend(hWndDlg,szModule,szPhone,dwPhoneSize,lpszMessage,dwMessageSize);
					MEMFREE(lpszMessage);
				}
			}
			SetTimer(hWndDlg,TIMERID_MSGSEND,TIMEOUT_MSGSEND,NULL);
			break;
		}
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam)){
		case IDC_MULTIPLE:
			SendSMSWindowMultipleSet(hWndDlg,!psswdWindowData->bMultiple);
			break;
		case IDC_ADDNUMBER:
			{	
				char szPhone[MAX_PHONE_LEN];
				if (IsPhone(szPhone,GetDlgItemText(hWndDlg,IDC_ADDRESS,szPhone,sizeof(szPhone))))
				{
					TVINSERTSTRUCT tvis={0};

					tvis.item.mask=(TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE);
					tvis.hInsertAfter=TVI_SORT;
					tvis.item.pszText=szPhone;
					TreeView_InsertItem(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),&tvis);
				}else{
					MessageBox(hWndDlg,Translate("The phone szPhone should start with a + and consist of numbers, spaces, brackets and hyphens only."),Translate("Invalid Phone Number"),MB_OK);
				}
			}
			break;
		case IDC_HISTORY:
			CallService(MS_HISTORY_SHOWCONTACTHISTORY,(WPARAM)psswdWindowData->hMyContact,0);
			break;
		case IDOK:
			if ((SIZE_T)GetWindowTextLength(GetDlgItem(hWndDlg,IDC_MESSAGE)) > GetSMSMessageLenMax(hWndDlg))
			{
				MessageBox(hWndDlg,Translate("Message is too long, press OK to continue."),Translate("Error - Message too long"),MB_OK);
			}else{
				if (psswdWindowData->bMultiple)
				{
					HTREEITEM hItem=SendSMSWindowNextHItemGet(hWndDlg,TreeView_GetRoot(GetDlgItem(hWndDlg,IDC_NUMBERSLIST)));
					if (hItem)
					{
						psswdWindowData->hItemSend=hItem;
						EnableWindow(GetDlgItem(hWndDlg,IDOK),FALSE);
						EnableWindow(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),FALSE);
						EnableWindow(GetDlgItem(hWndDlg,IDC_SAVENUMBER),FALSE);
						EnableWindow(GetDlgItem(hWndDlg,IDC_NAME),FALSE);
						EnableWindow(GetDlgItem(hWndDlg,IDC_MULTIPLE),FALSE);
						EnableWindow(GetDlgItem(hWndDlg,IDC_ADDNUMBER),FALSE);
						//EnableWindow(GetDlgItem(hWndDlg,IDC_REMOVENUMBER),FALSE);
						SendDlgItemMessage(hWndDlg,IDC_MESSAGE,EM_SETREADONLY,TRUE,0);
						EnableWindow(GetDlgItem(hWndDlg,IDC_PROTOCOLS),FALSE);
						EnableWindow(GetDlgItem(hWndDlg,IDC_ADDRESS),FALSE);
						SendSMSWindowNext(hWndDlg);
					}else{
						MessageBox(hWndDlg,Translate("There must be numbers in the list first."),Translate("No Numbers"),MB_OK);
					}
				}else{
					char szPhone[MAX_PHONE_LEN];
					SIZE_T dwPhoneSize;

					dwPhoneSize=GetDlgItemText(hWndDlg,IDC_ADDRESS,szPhone,sizeof(szPhone));
					if (IsPhone(szPhone,dwPhoneSize))
					{
						char szModule[MAX_PATH];
						LPSTR lpszMessage;
						SIZE_T dwMessageSize;

						dwMessageSize=GetWindowTextLength(GetDlgItem(hWndDlg,IDC_MESSAGE));
						lpszMessage=(LPSTR)MEMALLOC((dwMessageSize+4));
						if (lpszMessage)
						{
							dwMessageSize=GetDlgItemText(hWndDlg,IDC_MESSAGE,lpszMessage,(dwMessageSize+2));
							GetDlgItemText(hWndDlg,IDC_PROTOCOLS,szModule,sizeof(szModule));
							SendSMSWindowNumberSet(hWndDlg,szPhone,dwPhoneSize);
							EnableWindow(GetDlgItem(hWndDlg,IDOK),FALSE);
							EnableWindow(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),FALSE);
							EnableWindow(GetDlgItem(hWndDlg,IDC_SAVENUMBER),FALSE);
							EnableWindow(GetDlgItem(hWndDlg,IDC_NAME),FALSE);
							EnableWindow(GetDlgItem(hWndDlg,IDC_MULTIPLE),FALSE);
							EnableWindow(GetDlgItem(hWndDlg,IDC_PROTOCOLS),FALSE);
							EnableWindow(GetDlgItem(hWndDlg,IDC_ADDRESS),FALSE);
							SendDlgItemMessage(hWndDlg,IDC_MESSAGE,EM_SETREADONLY,TRUE,0);
							StartSmsSend(hWndDlg,szModule,szPhone,dwPhoneSize,lpszMessage,dwMessageSize);
							SetTimer(hWndDlg,TIMERID_MSGSEND,TIMEOUT_MSGSEND,NULL);
							MEMFREE(lpszMessage);
						}
					}else{
						MessageBox(hWndDlg,Translate("Valid phone numbers are of the form '+(country code)(phone szPhone)'. The contents of the phone szPhone portion is dependent on the national layout of phone numbers, but often omits the leading zero."),Translate("Invalid phone number"),MB_OK);
						SetFocus(GetDlgItem(hWndDlg,IDC_ADDRESS));
						SendDlgItemMessage(hWndDlg,IDC_ADDRESS,CB_SETEDITSEL,0,MAKELPARAM(0,-1));
					}
				}
			}
			break;
		case IDCANCEL:
			DeleteObject((HFONT)SendDlgItemMessage(hWndDlg,IDC_MESSAGE,WM_GETFONT,0,0));
			KillTimer(GetParent(hWndDlg),TIMERID_MSGSEND);
			SendSMSWindowRemove(hWndDlg);
			break;
		case IDC_MESSAGE:
			if (HIWORD(wParam)==EN_CHANGE)
			{
				char szBuff[MAX_PATH];
				SIZE_T dwMessageSize=GetWindowTextLength(GetDlgItem(hWndDlg,IDC_MESSAGE));
				EnableWindow(GetDlgItem(hWndDlg,IDOK),dwMessageSize);
				wsprintf(szBuff,"%d/%d",dwMessageSize,GetSMSMessageLenMax(hWndDlg));
				SetDlgItemText(hWndDlg,IDC_COUNT,szBuff);
			}
			break;
		case IDC_SAVENUMBER:
			{
				BOOL bCont=TRUE;
				char szBuff[MAX_PATH],szPhone[MAX_PHONE_LEN];
				SIZE_T dwPhoneSize;
				DBVARIANT dbv;

				dwPhoneSize=GetDlgItemText(hWndDlg,IDC_ADDRESS,szPhone,(sizeof(szPhone)-4));
				if (IsPhone(szPhone,dwPhoneSize))
				{
					if (IsContactPhone(psswdWindowData->hMyContact,szPhone,dwPhoneSize)==FALSE)
					{
						lstrcat(szPhone," SMS");
						for(DWORD i=0;bCont;i++)
						{
							wsprintf(szBuff,"MyPhone%d",i);
							if (DBGetContactSetting(psswdWindowData->hMyContact,"UserInfo",szBuff,&dbv)) bCont=FALSE;
							DBFreeVariant(&dbv);
						}
						DBWriteContactSettingString(psswdWindowData->hMyContact,"UserInfo",szBuff,szPhone);
					}
				}else{
					MessageBox(hWndDlg,Translate("The phone szPhone should start with a + and consist of numbers, spaces, brackets and hyphens only."),Translate("Invalid Phone Number"),MB_OK);
				}
			}
			break;
		case IDC_NAME:
			if (HIWORD(wParam)==CBN_SELCHANGE) 
			{
				SendDlgItemMessage(hWndDlg,IDC_ADDRESS,CB_RESETCONTENT,0,0);
				if (SendDlgItemMessage(hWndDlg,IDC_NAME,CB_GETCURSEL,0,0))
				{
					HANDLE hContact=SendSMSWindowSMSContactGet(hWndDlg,(SendDlgItemMessage(hWndDlg,IDC_NAME,CB_GETCURSEL,0,0)-1));
					if (hContact) AddContactPhonesToCombo(hWndDlg,hContact);
				}
			}
			break;
		}
		break;
	case WM_NOTIFY:
		switch(((NMHDR*)lParam)->idFrom){
		case IDC_NUMBERSLIST:
			switch(((NMHDR*)lParam)->code){
			case NM_CLICK:
				{	
					int iImage,iSame=1;
					HWND hWndTree=GetDlgItem(hWndDlg,IDC_NUMBERSLIST);
					TVITEM tvi={0};
					HTREEITEM hParent;
					TVHITTESTINFO hti={0};

					hti.pt.x=(short)LOWORD(GetMessagePos());
					hti.pt.y=(short)HIWORD(GetMessagePos());
					ScreenToClient(((LPNMHDR)lParam)->hwndFrom,&hti.pt);

					if (TreeView_HitTest(((LPNMHDR)lParam)->hwndFrom,&hti))
					if (hti.flags&TVHT_ONITEMICON) 
					{
						tvi.mask=(TVIF_IMAGE|TVIF_SELECTEDIMAGE);
						tvi.hItem=hti.hItem;
						TreeView_GetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
						iImage=tvi.iImage=tvi.iSelectedImage=!tvi.iImage;
						TreeView_SetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);

						if (TreeView_GetParent(hWndTree,hti.hItem))
						{
							hParent=TreeView_GetParent(hWndTree,hti.hItem);
							for(tvi.hItem=TreeView_GetChild(hWndTree,hParent);tvi.hItem;tvi.hItem=TreeView_GetNextSibling(hWndTree,tvi.hItem))
							{
								TreeView_GetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
								if (tvi.iImage!=iImage)
								{
									iSame=0;
									break;
								}								
							}
							tvi.hItem=hParent;
							tvi.iImage=tvi.iSelectedImage=((iSame==1)? iImage:2);
							TreeView_SetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
						}else{
							for(tvi.hItem=TreeView_GetChild(hWndTree,hti.hItem);tvi.hItem;tvi.hItem=TreeView_GetNextSibling(hWndTree,tvi.hItem))
							{
								TreeView_GetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
								tvi.iImage=tvi.iSelectedImage=iImage;
								TreeView_SetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
							}
						}
					}
				}
				break;
			}
		}
		break;			
	case WM_CLOSE:
		DeleteObject((HFONT)SendDlgItemMessage(hWndDlg,IDC_MESSAGE,WM_GETFONT,0,0));
		DeleteObject(psswdWindowData->hBkgBrush);
		RemWinHandle(GetDlgItem(hWndDlg,IDC_MESSAGE));
		KillTimer(GetParent(hWndDlg),TIMERID_MSGSEND);
		SendSMSWindowRemove(hWndDlg);
		break;
	}
return(FALSE);
}

BOOL CALLBACK SMSTimedOutDlgProc(HWND hWndDlg,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg){
	case WM_INITDIALOG:
		{
			RECT rc,rcParent;
			TranslateDialogDefault(hWndDlg); 
			GetWindowRect(hWndDlg,&rc);
			GetWindowRect(GetParent(hWndDlg),&rcParent);
			SetWindowPos(hWndDlg,0,(rcParent.left+rcParent.right-(rc.right-rc.left))/2,(rcParent.top+rcParent.bottom-(rc.bottom-rc.top))/2,0,0,SWP_NOZORDER|SWP_NOSIZE);
			KillTimer(GetParent(hWndDlg),TIMERID_MSGSEND);
		}
		return(TRUE);
	case WM_COMMAND:
		switch(LOWORD(wParam)){
		case IDOK:
			SendMessage(GetParent(hWndDlg),DM_TIMEOUTDECIDED,TIMEDOUT_RETRY,0);
			DestroyWindow(hWndDlg);
			break;
		case IDCANCEL:
			SendMessage(GetParent(hWndDlg),DM_TIMEOUTDECIDED,TIMEDOUT_CANCEL,0);
			DestroyWindow(hWndDlg);
			break;
		}
		break;
	}
return(FALSE);
} 

BOOL CALLBACK SMSAcceptedDlgProc(HWND hWndDlg,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg){
	case WM_INITDIALOG:
		{
			RECT rc,rcParent;
			TranslateDialogDefault(hWndDlg); 
			GetWindowRect(hWndDlg,&rc);
			GetWindowRect(GetParent(hWndDlg),&rcParent);
			SetWindowPos(hWndDlg,0,(rcParent.left+rcParent.right-(rc.right-rc.left))/2,(rcParent.top+rcParent.bottom-(rc.bottom-rc.top))/2,0,0,SWP_NOZORDER|SWP_NOSIZE);
		}
		return(TRUE);
	case WM_COMMAND:
		switch(LOWORD(wParam)){
		case IDOK:
			SendSMSWindowRemove(GetParent(hWndDlg));
			DestroyWindow(hWndDlg);
			break;
		}
		break;
	}
return(FALSE);
}

//SMS Send window list functions

//This function create a new SMS send window, and insert it to the list.
//The function gets void and return the window HWND
HWND SendSMSWindowAdd(HANDLE hContact)
{
	HWND hRet=NULL;
	SEND_SMS_WINDOW_DATA *psswdWindowData;

	psswdWindowData=(SEND_SMS_WINDOW_DATA*)MEMALLOC(sizeof(SEND_SMS_WINDOW_DATA));
	if (psswdWindowData)
	{
		psswdWindowData->hMyContact=hContact;
		psswdWindowData->hWnd=CreateDialogParam(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMS),NULL,SendSmsDlgProc,(LPARAM)psswdWindowData);
		if (psswdWindowData->hWnd)
		{
			char szTitle[MAX_PATH];
			LPSTR lpszContactDisplayName;

			ListMTLock(&lmtSendSMSWindowsListMT);
			ListMTItemAdd(&lmtSendSMSWindowsListMT,&psswdWindowData->lmtListMTItem,psswdWindowData);
			ListMTUnLock(&lmtSendSMSWindowsListMT);

			lpszContactDisplayName=DB_GetContactName(hContact);
			mir_snprintf(szTitle,sizeof(szTitle),"%s - %s",lpszContactDisplayName,Translate("Send SMS"));
			SetWindowText(psswdWindowData->hWnd,szTitle);
			SendDlgItemMessage(psswdWindowData->hWnd,IDC_NAME,CB_ADDSTRING,0,(LPARAM)lpszContactDisplayName);
			SendDlgItemMessage(psswdWindowData->hWnd,IDC_NAME,CB_SETCURSEL,0,0);
			AddContactPhonesToCombo(psswdWindowData->hWnd,hContact);
			SetFocus(GetDlgItem(psswdWindowData->hWnd,IDC_MESSAGE));
			hRet=psswdWindowData->hWnd;
		}else{
			MEMFREE(psswdWindowData);
		}
	}
return(hRet);
}

//This function close the SMS send window that given, and remove it from the list.
//The function gets the HWND of the window that should be removed and return void
void SendSMSWindowRemove(HWND hWndDlg)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData)
	{
		DB_SMS_SetDword(NULL,"LastProto",SendDlgItemMessage(hWndDlg,IDC_PROTOCOLS,CB_GETCURSEL,0,0));
		SendSMSWindowMultipleSet(hWndDlg,FALSE);
		Utils_SaveWindowPosition(hWndDlg,(DBGetContactSettingByte(NULL,"SRMsg","SavePerContact",0)? psswdWindowData->hMyContact:NULL),PROTOCOL_NAME,"send");
	
		ListMTLock(&lmtSendSMSWindowsListMT);
		ListMTItemDelete(&lmtSendSMSWindowsListMT,&psswdWindowData->lmtListMTItem);
		ListMTUnLock(&lmtSendSMSWindowsListMT);
		SendSMSWindowSMSContactsRemove(hWndDlg);
		MEMFREE(psswdWindowData->pdbei);
		MEMFREE(psswdWindowData);
	}
	DestroyWindow(hWndDlg);
}

//This function return the contact HANDLE for the given to the SMS send window.
//The function gets the HWND of the window and return the HANDLE of the contact.
HANDLE SendSMSWindowHContactGet(HWND hWndDlg)
{
	HANDLE hRet=NULL;
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData) hRet=psswdWindowData->hMyContact;
return(hRet);
}

//This function set the contact info of the person we send him the in the given to the SMS send window.
//The function gets the HWND of the window and the HANDLE of the contact and return void
void SendSMSWindowHContactSet(HWND hWndDlg,HANDLE hContact)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);
	if (psswdWindowData) psswdWindowData->hMyContact=hContact;
}

//This function return the HWND of a SMS send window that have the same process as given.
//The function gets the HANDLE of a process and return the HWND of the SMS send window that has
//the same process
HWND SendSMSWindowHwndByHProcessGet(HANDLE hProcess)
{
	HWND hRet=NULL;
	SEND_SMS_WINDOW_DATA *psswdWindowData;
	LIST_MT_ITERATOR lmtiIterator;

	ListMTLock(&lmtSendSMSWindowsListMT);
	ListMTIteratorMoveFirst(&lmtSendSMSWindowsListMT,&lmtiIterator);
	do
	{// ����
		if (ListMTIteratorGet(&lmtiIterator,NULL,(LPVOID*)&psswdWindowData)==NO_ERROR)
		if (psswdWindowData->hProcess==hProcess)
		{
			hRet=psswdWindowData->hWnd;
			break;
		}
	}while(ListMTIteratorMoveNext(&lmtiIterator));
	ListMTUnLock(&lmtSendSMSWindowsListMT);
return(hRet);		
}

//This function set the process info of the send procedure we sent with the given SMS send window.
//The function gets the HWND of the window and the HANDLE of the process and return void
void SendSMSWindowHProcessSet(HWND hWndDlg,HANDLE hProcess)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);
	if (psswdWindowData) psswdWindowData->hProcess=hProcess;
}

//
BOOL SendSMSWindowMultipleGet(HWND hWndDlg)
{
	BOOL bRet=FALSE;
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData) bRet=psswdWindowData->bMultiple;
return(bRet);
}

//
void SendSMSWindowMultipleSet(HWND hWndDlg,BOOL bMultiple)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData)
	if (psswdWindowData->bMultiple!=bMultiple)
	{
		RECT rcWin,rcList;
		WINDOWPLACEMENT wp;

		psswdWindowData->bMultiple=bMultiple;
		wp.length=sizeof(WINDOWPLACEMENT);
		GetWindowRect(hWndDlg,&rcWin);
		GetWindowRect(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),&rcList);
		GetWindowPlacement(hWndDlg,&wp);

		if (bMultiple)
		{
			SendSMSWindowFillTreeView(hWndDlg);

			EnableWindow(GetDlgItem(hWndDlg,IDC_SAVENUMBER),FALSE);
			SetDlgItemText(hWndDlg,IDC_MULTIPLE,Translate("<< Single"));
			if (wp.showCmd==SW_MAXIMIZE) SetWindowPos(hWndDlg,0,0,0,rcWin.right - rcWin.left - (rcList.right - rcList.left + 11) ,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
			SetWindowPos(hWndDlg,0,rcWin.left,rcWin.top,rcWin.right - rcWin.left + (rcList.right-rcList.left) + 11,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
		}else{
			if (psswdWindowData->hMyContact) AddContactPhonesToCombo(hWndDlg,psswdWindowData->hMyContact);

			EnableWindow(GetDlgItem(hWndDlg,IDC_SAVENUMBER),TRUE);
			SetDlgItemText(hWndDlg,IDC_MULTIPLE,Translate("Multiple >>"));
			SetWindowPos(hWndDlg,0,rcWin.left,rcWin.top,rcWin.right-rcWin.left - (rcList.right-rcList.left) - 11,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
			if (wp.showCmd==SW_MAXIMIZE) SetWindowPos(hWndDlg,0,0,0,rcWin.right - rcWin.left + (rcList.right - rcList.left + 11) ,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
		}
	}
}

//
void SendSMSWindowNumberSet(HWND hWndDlg,LPSTR lpszPhone,SIZE_T dwPhoneSize)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData)
	if (psswdWindowData->bMultiple)
	{
		psswdWindowData->hContact=psswdWindowData->hMyContact;
	}else{
		psswdWindowData->hContact=HContactFromPhone(lpszPhone,dwPhoneSize);
	}
}

//
void SendSMSWindowAsSentSet(HWND hWndDlg)
{
//	LVITEM lvi;
//	char szPhone[MAX_PHONE_LEN];
//	lvi.mask=LVIF_TEXT|LVIF_IMAGE;
//	lvi.iItem=GetSendSMSWindowSMSSend(hWndDlg) - 1;
//	lvi.iSubItem=0;
//	ListView_GetItemText(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),GetSendSMSWindowSMSSend(hWndDlg) - 1,0,szPhone,sizeof(szPhone));
//	lvi.pszText=szPhone;
//	lvi.iImage=2;
//	ListView_SetItem(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),&lvi);
//	ListView_RedrawItems(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),0,ListView_GetItemCount(GetDlgItem(hWndDlg,IDC_NUMBERSLIST)) - 1);							
}

//This function set the databsae info of the sent message we sent with the SMS send window.
//The function gets the HWND of the window and the DBEI of the database information of the message
//and return void
void SendSMSWindowDbeiSet(HWND hWndDlg,DBEVENTINFO *pdbei)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);
	if (psswdWindowData) psswdWindowData->pdbei=pdbei;
}

//This function get a HWND of SMS send window and add its database information into Miranda-IM database
//The function gets the HWND of the window and return void
//and return void
void SendSMSWindowDBAdd(HWND hWndDlg)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);
	
	if (psswdWindowData)
	{
		psswdWindowData->pdbei->cbSize=sizeof(DBEVENTINFO);
		psswdWindowData->pdbei->szModule=GetModuleName(psswdWindowData->hContact);

		CallService(MS_DB_EVENT_ADD,(WPARAM)psswdWindowData->hContact,(LPARAM)psswdWindowData->pdbei);
		MEMFREE(psswdWindowData->pdbei);
	}
}

//
void SendSMSWindowHItemSendSet(HWND hWndDlg,HTREEITEM hItemSend)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);
	if (psswdWindowData) psswdWindowData->hItemSend=hItemSend;
}

//
HTREEITEM SendSMSWindowHItemSendGet(HWND hWndDlg)
{
	HTREEITEM hRet=NULL;
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData) hRet=psswdWindowData->hItemSend;
return(hRet);
}

//
HTREEITEM SendSMSWindowNextHItemGet(HWND hWndDlg,HTREEITEM hItem)
{
	int isFound=0;
	HWND hWndTree=GetDlgItem(hWndDlg,IDC_NUMBERSLIST);
	TVITEM tvi;
	HTREEITEM hItemNext,hItemChild;

	if (hItem==TreeView_GetRoot(hWndTree)) isFound=1;

	for(hItemNext=TreeView_GetRoot(hWndTree);hItemNext;hItemNext=TreeView_GetNextSibling(hWndTree,hItemNext))
	{
		if ((hItem==hItemNext) && (hItem!=TreeView_GetRoot(hWndTree)))
		{
			isFound=1;
			continue;
		}

		tvi.mask=(TVIF_IMAGE|TVIF_SELECTEDIMAGE);
		tvi.hItem=hItemNext;
		tvi.iImage=0;
		tvi.iSelectedImage=0;
		TreeView_GetItem(hWndTree,&tvi);

		if (tvi.iImage || tvi.iSelectedImage)
		if (TreeView_GetChild(hWndTree,hItemNext))
		{
			for (hItemChild=TreeView_GetChild(hWndTree,hItemNext);hItemChild;hItemChild=TreeView_GetNextSibling(hWndTree,hItemChild))
			{
				if (hItem==hItemChild)
				{
					isFound=1;
					continue;
				}

				tvi.mask=(TVIF_IMAGE|TVIF_SELECTEDIMAGE);
				tvi.hItem=hItemChild;
				tvi.iImage=0;
				tvi.iSelectedImage=0;
				TreeView_GetItem(hWndTree,&tvi);

				if (tvi.iImage || tvi.iSelectedImage)
				if (isFound)
				{
					return(hItemChild);				
				}else{
					continue;
				}
			}
		}else{
			if (isFound)
			{
				return(hItemNext);				
			}else{
				continue;
			}
		}
	}
return(NULL);
}

//This function get the HANDLE of an user. if there is already a SMS send window for this contact
//it return its HWND else the function return NULL.
//The function gets the HANDLE of a contact and return HWND
HWND SendSMSWindowIsOtherInstanceHContact(HANDLE hContact)
{
	HWND hRet=NULL;
	SEND_SMS_WINDOW_DATA *psswdWindowData;
	LIST_MT_ITERATOR lmtiIterator;

	ListMTLock(&lmtSendSMSWindowsListMT);
	ListMTIteratorMoveFirst(&lmtSendSMSWindowsListMT,&lmtiIterator);
	do
	{// ����
		if (ListMTIteratorGet(&lmtiIterator,NULL,(LPVOID*)&psswdWindowData)==NO_ERROR)
		if (psswdWindowData->hMyContact==hContact)
		{
			hRet=psswdWindowData->hWnd;
			break;
		}
	}while(ListMTIteratorMoveNext(&lmtiIterator));
	ListMTUnLock(&lmtSendSMSWindowsListMT);
return(hRet);
}


//
void SendSMSWindowNext(HWND hWndDlg)
{
	char szModule[MAX_PATH],szPhone[MAX_PHONE_LEN];
	LPSTR lpszMessage;
	SIZE_T dwPhoneSize,dwMessageSize;
	TVITEM tvi={0};

	dwMessageSize=GetWindowTextLength(GetDlgItem(hWndDlg,IDC_MESSAGE));
	lpszMessage=(LPSTR)MEMALLOC((dwMessageSize+4));
	if (lpszMessage)
	{
		dwMessageSize=GetDlgItemText(hWndDlg,IDC_MESSAGE,lpszMessage,(dwMessageSize+2));
		GetDlgItemText(hWndDlg,IDC_PROTOCOLS,szModule,sizeof(szModule));

	//	if (SendSMSWindowNextHItemGet(hWndDlg,SendSMSWindowHItemSendGet(hWndDlg))==NULL) SendSMSWindowMultipleSet(hWndDlg,FALSE);	
		tvi.mask=TVIF_TEXT;
		tvi.hItem=SendSMSWindowHItemSendGet(hWndDlg);
		tvi.pszText=szPhone;
		tvi.cchTextMax=sizeof(szPhone);
		TreeView_GetItem(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),&tvi);
		TreeView_SelectItem(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),tvi.hItem);
		dwPhoneSize=lstrlen(szPhone);
		SendSMSWindowNumberSet(hWndDlg,szPhone,dwPhoneSize);
		StartSmsSend(hWndDlg,szModule,szPhone,dwPhoneSize,lpszMessage,dwMessageSize);
		SetTimer(hWndDlg,TIMERID_MSGSEND,TIMEOUT_MSGSEND,NULL);
		MEMFREE(lpszMessage);
	}
}


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//This function gets a HANDLE of a contact and add it to a list.
void SendSMSWindowSMSContactAdd(HWND hWndDlg,HANDLE hContact)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData)
	{
		psswdWindowData->dwContactsListCount++;
		if (psswdWindowData->phContactsList)
		{
			psswdWindowData->phContactsList=(HANDLE*)MEMREALLOC(psswdWindowData->phContactsList,(sizeof(HANDLE)*psswdWindowData->dwContactsListCount));
		}else{
			psswdWindowData->phContactsList=(HANDLE*)MEMALLOC((sizeof(HANDLE)*psswdWindowData->dwContactsListCount));
		}
		*(psswdWindowData->phContactsList+psswdWindowData->dwContactsListCount-1)=hContact;
	}
}

//This function gets the number of the given contact in the combo list and return its contact.
HANDLE SendSMSWindowSMSContactGet(HWND hWndDlg,SIZE_T iNum)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData)
	{
		return(*((psswdWindowData->phContactsList)+iNum));
	}
return(NULL);
}

void SendSMSWindowSMSContactsRemove(HWND hWndDlg)
{
	SEND_SMS_WINDOW_DATA *psswdWindowData=GET_WINDOW_DATA(hWndDlg);

	if (psswdWindowData)
	{
		MEMFREE(psswdWindowData->phContactsList);
		psswdWindowData->dwContactsListCount=0;
	}
}
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////




void AddContactPhonesToComboToListParam(HANDLE hContact,LPSTR lpszModule,LPSTR lpszValueName,HWND hWndList)
{
	char szBuff[MAX_PATH],szPhone[MAX_PHONE_LEN],szPhoneRaw[MAX_PHONE_LEN];
	SIZE_T i,dwPhoneSize;

	if (DB_GetStaticString(hContact,lpszModule,lpszValueName,szPhoneRaw,sizeof(szPhoneRaw),&dwPhoneSize))
	{
		szPhone[0]='+';
		dwPhoneSize=CopyNumber((szPhone+1),szPhoneRaw,dwPhoneSize);
		if (IsPhone(szPhone,dwPhoneSize))
		{
			if (SendMessage(hWndList,CB_FINDSTRING,-1,(LPARAM)szPhone)==CB_ERR) SendMessage(hWndList,CB_ADDSTRING,0,(LPARAM)szPhone);
		}
	}

	for (i=0;TRUE;i++)
	{
		mir_snprintf(szBuff,sizeof(szBuff),"%s%ld",lpszValueName,i);
		if (DB_GetStaticString(hContact,lpszModule,szBuff,szPhoneRaw,sizeof(szPhoneRaw),&dwPhoneSize))
		{
			szPhone[0]='+';
			dwPhoneSize=CopyNumber((szPhone+1),szPhoneRaw,dwPhoneSize);
			if (IsPhone(szPhone,dwPhoneSize))
			{
				if (SendMessage(hWndList,CB_FINDSTRING,-1,(LPARAM)szPhone)==CB_ERR) SendMessage(hWndList,CB_ADDSTRING,0,(LPARAM)szPhone);
			}
		}else{
			if (i>PHONES_MIN_COUNT) break;
		}
	}
}


void AddContactPhonesToCombo(HWND hWnd,HANDLE hContact)
{
	HWND hWndList;
	LPSTR lpszProto;

	hWndList=GetDlgItem(hWnd,IDC_ADDRESS);
	SendDlgItemMessage(hWnd,IDC_ADDRESS,CB_RESETCONTENT,0,0);

	lpszProto=(LPSTR)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)hContact,0);
	if (lpszProto)
	{
		AddContactPhonesToComboToListParam(hContact,lpszProto,"Phone",hWndList);
		AddContactPhonesToComboToListParam(hContact,lpszProto,"Cellular",hWndList);
		AddContactPhonesToComboToListParam(hContact,lpszProto,"Fax",hWndList);
	}
	AddContactPhonesToComboToListParam(hContact,"UserInfo","MyPhone",hWndList);
	AddContactPhonesToComboToListParam(hContact,"UserInfo","Phone",hWndList);
	AddContactPhonesToComboToListParam(hContact,"UserInfo","Cellular",hWndList);
	AddContactPhonesToComboToListParam(hContact,"UserInfo","Fax",hWndList);

	SendDlgItemMessage(hWnd,IDC_ADDRESS,CB_SETCURSEL,0,0);
}



void AddContactPhonesToTreeViewParam(HANDLE hContact,LPSTR lpszModule,LPSTR lpszValueName,HWND hWndList,HTREEITEM *phParent)
{
	char szBuff[MAX_PATH],szPhone[MAX_PHONE_LEN],szPhoneRaw[MAX_PHONE_LEN];
	SIZE_T i,dwPhoneSize;
	TVINSERTSTRUCT tvis={0};

	if (phParent) tvis.hParent=(*phParent);
	tvis.item.mask=(TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE);
	tvis.hInsertAfter=TVI_SORT;
	tvis.item.iImage=tvis.item.iSelectedImage=0;

	if (DB_GetStaticString(hContact,lpszModule,lpszValueName,szPhoneRaw,sizeof(szPhoneRaw),&dwPhoneSize))
	{
		szPhone[0]='+';
		dwPhoneSize=CopyNumber((szPhone+1),szPhoneRaw,dwPhoneSize);
		if (IsPhone(szPhone,dwPhoneSize))
		{
			if (tvis.hParent==NULL)
			{
				tvis.item.pszText=DB_GetContactName(hContact);
				tvis.hParent=TreeView_InsertItem(hWndList,&tvis);
			}
			tvis.item.pszText=szPhone;
			TreeView_InsertItem(hWndList,&tvis);											
		}
	}

	for (i=0;TRUE;i++)
	{
		mir_snprintf(szBuff,sizeof(szBuff),"%s%ld",lpszValueName,i);
		if (DB_GetStaticString(hContact,lpszModule,szBuff,szPhoneRaw,sizeof(szPhoneRaw),&dwPhoneSize))
		{
			szPhone[0]='+';
			dwPhoneSize=CopyNumber((szPhone+1),szPhoneRaw,dwPhoneSize);
			if (IsPhone(szPhone,dwPhoneSize))
			{
				if (tvis.hParent==NULL)
				{
					tvis.item.pszText=DB_GetContactName(hContact);
					tvis.hParent=TreeView_InsertItem(hWndList,&tvis);
				}
				tvis.item.pszText=szPhone;
				TreeView_InsertItem(hWndList,&tvis);											
			}
		}else{
			if (i>PHONES_MIN_COUNT) break;
		}
	}
	if (phParent) (*phParent)=tvis.hParent;
}


void SendSMSWindowFillTreeView(HWND hWnd)
{
	HWND hWndTreeView;
	LPSTR lpszProto;
	HTREEITEM hParent;

	hWndTreeView=GetDlgItem(hWnd,IDC_NUMBERSLIST);
	TreeView_DeleteAllItems(hWndTreeView);

	for(HANDLE hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);hContact!=NULL;hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0))
	{
		hParent=NULL;
		lpszProto=(LPSTR)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)hContact,0);
		if (lpszProto)
		{
			AddContactPhonesToTreeViewParam(hContact,lpszProto,"Phone",hWndTreeView,&hParent);
			AddContactPhonesToTreeViewParam(hContact,lpszProto,"Cellular",hWndTreeView,&hParent);
			AddContactPhonesToTreeViewParam(hContact,lpszProto,"Fax",hWndTreeView,&hParent);
		}
		AddContactPhonesToTreeViewParam(hContact,"UserInfo","MyPhone",hWndTreeView,&hParent);
		AddContactPhonesToTreeViewParam(hContact,"UserInfo","Phone",hWndTreeView,&hParent);
		AddContactPhonesToTreeViewParam(hContact,"UserInfo","Cellular",hWndTreeView,&hParent);
		AddContactPhonesToTreeViewParam(hContact,"UserInfo","Fax",hWndTreeView,&hParent);
	}	
}


SIZE_T GetSMSMessageLenMax(HWND hWndDlg)
{
	LPSTR lpszMessage;
	SIZE_T dwMessageSize,dwLenght=160;

	dwMessageSize=GetWindowTextLength(GetDlgItem(hWndDlg,IDC_MESSAGE));
	lpszMessage=(LPSTR)MEMALLOC((dwMessageSize+4));
	if (lpszMessage)
	{
		GetDlgItemText(hWndDlg,IDC_MESSAGE,lpszMessage,(dwMessageSize+2));
		for(SIZE_T i=0;i<dwMessageSize;i++)
		{
			if ((*((BYTE*)(lpszMessage+i)))>127)
			{
				dwLenght=70;
				break;
			}
		}
		MEMFREE(lpszMessage);
	}
return(dwLenght);
}