/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/

#include "main.h"
#include "utf8.h"
#include "resource.h"
#include <windows.h>
#include <time.h>
#include <stdio.h>
#include "newpluginapi.h"
#include "m_clist.h"
#include "m_skin.h"
#include "m_database.h"
#include "m_langpack.h"
#include "m_protosvc.h"
#include "m_icq.h"
#include "m_protomod.h"
#include "m_protosvc.h"



BOOL CALLBACK RecvSmsDlgProc(HWND hwndDlg,UINT message,WPARAM wParam,LPARAM lParam);

HINSTANCE hInst;
PLUGINLINK *pluginLink;

PLUGININFO pluginInfo={
	sizeof(PLUGININFO),
	"SMS",
	PLUGIN_MAKE_VERSION(0,2,4,8),
	"Send SMS text messages to mobile phones through the ICQ network\n+Improvments by NuKe007",
	"Richard Hughes (Improved by Ariel Shulman)",
	"cyreve@users.sourceforge.net (nuke007@nuke007.tk)",
	"� 2001-2 Richard Hughes (2003 Ariel Shulman)",
	"http://miranda-icq.sourceforge.net/",
	0,		//not transient
	0		//doesn't replace anything built-in
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst=hinstDLL;
	return TRUE;
}

__declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	if(mirandaVersion<PLUGIN_MAKE_VERSION(0,2,0,0))
		return NULL;
	return &pluginInfo;
}

int __declspec(dllexport) Load(PLUGINLINK *link)
{
	CLISTMENUITEM mi;
	pluginLink=link;
	CreateServiceFunction("SMS/SendSMS",SendSMSMenuCommand);
	CreateServiceFunction("SRSMS/ReadSms",ReadMsgSMS);
	CreateServiceFunction("SRSMS/ReadSmsAck",ReadAckSMS);
	ZeroMemory(&mi,sizeof(mi));
	mi.cbSize=sizeof(mi);
	mi.position=300050000;
	mi.flags=0;
	mi.hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_SMS));
	mi.pszName=Translate("Send &SMS...");
	mi.pszService="SMS/SendSMS";
	CallService(MS_CLIST_ADDMAINMENUITEM,0,(LPARAM)&mi);
	InitSmsSend();
	InitSmsRecv();
	InitOptions();
	RestoreUnreadMessageAlerts();
	{
		CLISTMENUITEM mi;

		pluginLink=link;
		CreateServiceFunction("SendSMS/MenuCommand",SMSMenuCommand);
		ZeroMemory(&mi,sizeof(mi));
		mi.cbSize=sizeof(mi);
		mi.position=-2000070000;
		mi.flags=0;
		mi.hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_SMS));
		mi.pszName=Translate("&SMS Message");
		mi.pszService="SendSMS/MenuCommand";
		CallService(MS_CLIST_ADDCONTACTMENUITEM,0,(LPARAM)&mi);

	}
	return 0;
}

int __declspec(dllexport) Unload(void)
{
	UninitSmsSend();
	UninitSmsRecv();
	UninitOptions();
	return 0;
}

//This function return plugin HINSTANCE.
HINSTANCE GetPluginhInst()
{
	return hInst;
}

//This function called when user clicked on the "SMS Send" in the Main Menu.
static int SendSMSMenuCommand(WPARAM wParam,LPARAM lParam)
{
	char newtitle[256];
	HWND hwndSendSms;
	HANDLE hContact=NULL;
	if (!CallService(MS_PROTO_ISPROTOCOLLOADED, 0, (LPARAM)"ICQ"))
	{
		MessageBox(NULL,Translate("Can't load SMS Plugin, ICQ protocol must be loaded."),Translate("SMS Plugin Error"),MB_OK|MB_ICONERROR);
		return 0;
	}
	hwndSendSms=AddSendSMSWindow(NULL);
	EnableWindow(GetDlgItem(hwndSendSms,IDC_NAME),1);
	EnableWindow(GetDlgItem(hwndSendSms,IDC_SAVENUMBER),0);
	SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_RESETCONTENT,0,0);
	SendDlgItemMessage(hwndSendSms,IDC_NAME,CB_ADDSTRING,0,(LPARAM)Translate("Unknown"));
	hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
	while (hContact!=NULL) 
	{
		{
			int i,iHasSms=0;
			char idstr[256];
			{	
				DBVARIANT dbv;
				char *szProto;
				szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
				if(!DBGetContactSetting(hContact,szProto,"Cellular",&dbv)) 
				{
					if(lstrlen(dbv.pszVal)>4 && !lstrcmp(dbv.pszVal+lstrlen(dbv.pszVal)-4," SMS")) 				
						iHasSms=1;
					DBFreeVariant(&dbv);
				}
				for(i=0;;i++) 
				{
					wsprintf(idstr,"MyPhone%d",i);
					if(DBGetContactSetting(hContact,"UserInfo",idstr,&dbv))
						break;
					wsprintf(idstr,Translate("Custom %d"),i+1);
					if(lstrlen(dbv.pszVal)>4 && !lstrcmp(dbv.pszVal+lstrlen(dbv.pszVal)-4," SMS")) 	
						iHasSms=1;
					DBFreeVariant(&dbv);
				}
			}
			if(iHasSms==1)
			{
				SendMessage(GetDlgItem(hwndSendSms, IDC_NAME), CB_ADDSTRING, 0, (LPARAM)(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0));
				AddSMSContact(hwndSendSms,hContact);
			}
		}	
		hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0);
	}
	SendDlgItemMessage(hwndSendSms, IDC_NAME, CB_SETCURSEL, 0, 0);
	lstrcpy(newtitle,Translate("Unknown"));
	lstrcat(newtitle," - ");
	lstrcat(newtitle,Translate("Send SMS"));
	SetWindowText(hwndSendSms,newtitle);
	SetFocus(GetDlgItem(hwndSendSms,IDC_MESSAGE));
	return 0;
}

//This function called when user clicked on the "SMS Message" on one of the users.
static int SMSMenuCommand(WPARAM wParam,LPARAM lParam)
{
	char newtitle[256];
	HWND hwndSendSms;
	if (!CallService(MS_PROTO_ISPROTOCOLLOADED, 0, (LPARAM)"ICQ"))
	{
		MessageBox(NULL,Translate("Can't load SMS Plugin, ICQ protocol must be loaded."),Translate("SMS Plugin Error"),MB_OK|MB_ICONERROR);
		return 0;
	}
	hwndSendSms=IsOtherInstanceHContact((HANDLE)wParam);
	if(IsOtherInstanceHContact((HANDLE)wParam) != NULL)
	{
		SetFocus(hwndSendSms);
		return 0;
	}
	hwndSendSms=AddSendSMSWindow((HANDLE)wParam);
	{
		int i;
		char idstr[256];
		{	
			char *cTmp;
			HANDLE hContact=NULL;
			DBVARIANT dbv;
			char *szProto;
			hContact=(HANDLE)wParam;
			SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_RESETCONTENT,0,0);
			szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
			if(!DBGetContactSetting(hContact,szProto,"Cellular",&dbv)) 
			{
				if(lstrlen(dbv.pszVal)>4 && !lstrcmp(dbv.pszVal+lstrlen(dbv.pszVal)-4," SMS")) 
				{
					dbv.pszVal[lstrlen(dbv.pszVal)-4]='\0';
					cTmp=malloc(lstrlen(dbv.pszVal)+2);
					lstrcpy(cTmp,"+");
					lstrcat(cTmp,strCellular(dbv.pszVal));
					SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)cTmp);
					SetDlgItemText(hwndSendSms,IDC_ADDRESS,cTmp);
					free(cTmp);
				}
				DBFreeVariant(&dbv);
			}
			for(i=0;;i++) 
			{
				wsprintf(idstr,"MyPhone%d",i);
				if(DBGetContactSetting(hContact,"UserInfo",idstr,&dbv))
					break;
				wsprintf(idstr,Translate("Custom %d"),i+1);
				if(lstrlen(dbv.pszVal)>4 && !lstrcmp(dbv.pszVal+lstrlen(dbv.pszVal)-4," SMS")) 
				{
					dbv.pszVal[lstrlen(dbv.pszVal)-4]='\0';
					cTmp=malloc(lstrlen(dbv.pszVal)+2);
					lstrcpy(cTmp,"+");
					lstrcat(cTmp,strCellular(dbv.pszVal));
					SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)cTmp);
					SetDlgItemText(hwndSendSms,IDC_ADDRESS,cTmp);
					free(cTmp);
				}
				DBFreeVariant(&dbv);
			}
		}
	}
	SendMessage(GetDlgItem(hwndSendSms, IDC_NAME), CB_ADDSTRING, 0, (LPARAM)(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wParam,0));
	SendDlgItemMessage(hwndSendSms, IDC_NAME, CB_SETCURSEL, 0, 0);
	lstrcpy(newtitle,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wParam,0));
	lstrcat(newtitle," - ");
	lstrcat(newtitle,Translate("Send SMS"));
	SetWindowText(hwndSendSms,newtitle);
	SetFocus(GetDlgItem(hwndSendSms,IDC_MESSAGE));
	SetSendSMSWindowHContact(hwndSendSms,(HANDLE)wParam);
	return 0;
}

//This function used to popup a read SMS window after the user clicked on the received SMS message.
static int ReadMsgSMS(WPARAM wparam,LPARAM lparam)
{
	char newtitle[256];
	HWND hwndRecvSms;
	DBEVENTINFO dbei={0};
	int i;
	char cTmpNum[256];
	dbei.cbSize=sizeof(dbei);
	dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)((CLISTEVENT*)lparam)->hDbEvent,0);
	dbei.pBlob=(PBYTE)malloc(dbei.cbBlob);
	CallService(MS_DB_EVENT_GET,(WPARAM)((CLISTEVENT*)lparam)->hDbEvent,(LPARAM)&dbei);
	if((dbei.eventType != ICQEVENTTYPE_SMS) && (dbei.eventType!=ICQEVENTTYPE_SMSCONFIRMATION)) return 0;
	hwndRecvSms=AddRecvSMSWindow();//CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_RECVSMS),NULL,RecvSmsDlgProc);
	if(((CLISTEVENT*)lparam)->hContact != NULL)
		lstrcpy(newtitle,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)((CLISTEVENT*)lparam)->hContact,0));
	else
		lstrcpy(newtitle,Translate("Unknown"));
	lstrcat(newtitle," - ");
	lstrcat(newtitle,Translate("Received SMS"));
	SetWindowText(hwndRecvSms,newtitle);
	SetRecvSMSWindowHContact(hwndRecvSms,((CLISTEVENT*)lparam)->hContact);
	SetDlgItemText(hwndRecvSms,IDC_NAME,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)((CLISTEVENT*)lparam)->hContact,0));
	for(i=10;*((char*)dbei.pBlob + i)!='\r';i++)
		cTmpNum[i-10]=*((char*)dbei.pBlob + i);
	cTmpNum[i-10]='\0';
	SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
	SetDlgItemText(hwndRecvSms,IDC_MESSAGE,(char*)dbei.pBlob);
	CallService(MS_DB_EVENT_MARKREAD,(WPARAM)((CLISTEVENT*)lparam)->hContact,(LPARAM)((CLISTEVENT*)lparam)->hDbEvent);
	return 0;
	
}

//This function used to popup a read SMS window after the user clicked on the received SMS confirmation.
static int ReadAckSMS(WPARAM wparam,LPARAM lparam)
{
	char newtitle[256];
	HWND hwndRecvSms;
	DBEVENTINFO dbei={0};
	int i;
	char cTmpNum[256];
	dbei.cbSize=sizeof(dbei);
	dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)((CLISTEVENT*)lparam)->hDbEvent,0);
	dbei.pBlob=(PBYTE)malloc(dbei.cbBlob);
	CallService(MS_DB_EVENT_GET,(WPARAM)((CLISTEVENT*)lparam)->hDbEvent,(LPARAM)&dbei);
	if((dbei.eventType != ICQEVENTTYPE_SMS) && (dbei.eventType!=ICQEVENTTYPE_SMSCONFIRMATION)) return 0;
	hwndRecvSms=AddRecvSMSWindow();//CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_RECVSMS),NULL,RecvSmsDlgProc);
	if(((CLISTEVENT*)lparam)->hContact != NULL)
		lstrcpy(newtitle,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)((CLISTEVENT*)lparam)->hContact,0));
	else
		lstrcpy(newtitle,Translate("Unknown"));
	lstrcat(newtitle," - ");
	lstrcat(newtitle,Translate("Received SMS Confirmation"));
	SetWindowText(hwndRecvSms,newtitle);
	SetRecvSMSWindowHContact(hwndRecvSms,((CLISTEVENT*)lparam)->hContact);
	SetDlgItemText(hwndRecvSms,IDC_NAME,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)((CLISTEVENT*)lparam)->hContact,0));
	for(i=23;*((char*)dbei.pBlob + i)!='\r';i++)
		cTmpNum[i-23]=*((char*)dbei.pBlob + i);
	cTmpNum[i-23]='\0';
	if(!lstrcmp("SMS was sent succesfully",((char*)dbei.pBlob + i + 2)))
		SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT)));
	else
		SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT)));
	SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
	SetDlgItemText(hwndRecvSms,IDC_MESSAGE,(char*)dbei.pBlob);
	CallService(MS_DB_EVENT_DELETE,(WPARAM)((CLISTEVENT*)lparam)->hContact,(LPARAM)((CLISTEVENT*)lparam)->hDbEvent);
	return 0;
}

//This function gets a Cellular string number and clean it from symbools.
char *strCellular(const char* str)
{
	int i,j=0;
	char *cReturn;
	cReturn=(char *)malloc(50);
	for(i=0;i <= (signed)(lstrlen(str) - 1);i++)
	{
		if((*(str + i) >= 48) && (*(str + i) <= 57))
		{
			cReturn[j]=*(str + i);
			j++;
		}
	}
	cReturn[j]='\0';
	return cReturn;
}

//This function get a XML string and return the asked tag.
char *GetXMLField(const char *xml,const char *tag1,...)
{
	va_list va;
	int thisLevel,i,start=-1;
	const char *findTag;

	va_start(va,tag1);
	thisLevel=0;
	findTag=tag1;
	for(i=0;xml[i];i++) {
		if(xml[i]=='<') {
			char tag[64],*tagend=strchr(xml+i,'>');
			if(tagend==NULL) return NULL;
			lstrcpyn(tag,xml+i+1,min(sizeof(tag),tagend-xml-i));
			if(tag[0]=='/') {
				if(--thisLevel<0) {
					char *ret;
					if(start==-1) return NULL;
					ret=(char*)malloc(i-start+1);
					lstrcpyn(ret,xml+start,i-start+1);
					return ret;
				}
			}
			else {
				if(++thisLevel==1 && !lstrcmpi(tag,findTag)) {
					findTag=va_arg(va,const char*);
					if(findTag==NULL) start=tagend-xml+1;
					thisLevel=0;
				}
			}
			i=tagend-xml;
		}
	}
	va_end(va);
	return NULL;
}

//
char* EncodeXML(const char* cXml)
{
	int i;
	char *cEncodedXML;
	cEncodedXML=malloc(1);
	*cEncodedXML='\0';
	for(i=0;i<lstrlen(cXml);i++)
	{
		char cTmp[2];
		cTmp[0]=*(cXml+i);
		cTmp[1]='\0';
		if(!MYstrncmp(cXml+i,"\'",1))
		{
			cEncodedXML=(char*)realloc(cEncodedXML,sizeof(char*) * (6 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&apos;");
		}
		else if(!MYstrncmp(cXml+i,"\"",1))
		{
			cEncodedXML=(char*)realloc(cEncodedXML,sizeof(char*) * (6 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&quot;");
		}
		else if(!MYstrncmp(cXml+i,"&",1))
		{
			cEncodedXML=(char*)realloc(cEncodedXML,sizeof(char*) * (5 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&amp;");
		}
		else if(!MYstrncmp(cXml+i,"<",1))
		{
			cEncodedXML=(char*)realloc(cEncodedXML,sizeof(char*) * (4 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&lt;");
		}
		else if(!MYstrncmp(cXml+i,">",1))
		{
			cEncodedXML=(char*)realloc(cEncodedXML,sizeof(char*) * (4 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,"&gt;");
		}
		else
		{
			cEncodedXML=(char*)realloc(cEncodedXML,sizeof(char*) * (1 + lstrlen(cEncodedXML)));
			lstrcat(cEncodedXML,cTmp);
		}
	}
	cEncodedXML=(char*)realloc(cEncodedXML,sizeof(char*) * (1 + lstrlen(cEncodedXML)));
	lstrcat(cEncodedXML,"\0");
	return cEncodedXML;
}

//
char* DecodeXML(const char* cXml)
{
	int i;
	char *cDecodedXML;
	cDecodedXML=malloc(1);
	*cDecodedXML='\0';
	for(i=0;i<lstrlen(cXml);i++)
	{
		char cTmp[2];
		cTmp[0]=*(cXml+i);
		cTmp[1]='\0';
		if(!MYstrncmp(cXml+i,"&apos;",6))
		{
			cDecodedXML=(char*)realloc(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,"\'");
			i=i+5;
		}
		else if(!MYstrncmp(cXml+i,"&quot;",6))
		{
			cDecodedXML=(char*)realloc(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,"\"");
			i=i+5;
		}
		else if(!MYstrncmp(cXml+i,"&amp;",5))
		{
			cDecodedXML=(char*)realloc(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,"&");
			i=i+4;
		}
		else if(!MYstrncmp(cXml+i,"&lt;",4))
		{
			cDecodedXML=(char*)realloc(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,"<");
			i=i+3;
		}
		else if(!MYstrncmp(cXml+i,"&gt;",4))
		{
			cDecodedXML=(char*)realloc(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,">");
			i=i+3;
		}
		else
		{
			cDecodedXML=(char*)realloc(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
			lstrcat(cDecodedXML,cTmp);
		}
	}
	cDecodedXML=(char*)realloc(cDecodedXML,sizeof(char*) * (1 + lstrlen(cDecodedXML)));
	lstrcat(cDecodedXML,"\0");
	return cDecodedXML;
}

//This function get a string cellular number and return the HANDLE of the contact that has this
//number in the miranda phonebook (and marked as an SMS able) at the User Details.
//If no one has this number function returns NULL.
HANDLE CellularToHandle(const char *cNumber)
{
	HANDLE hContactTmp=NULL;
	int i;
	char idstr[256];
	{	
		HANDLE hContact=NULL;
		DBVARIANT dbv;
		hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
		while(hContact!=NULL) 
		{
			char *szProto;
			szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
			if(!DBGetContactSetting(hContact,szProto,"Cellular",&dbv)) 
			{
				if(lstrlen(dbv.pszVal)>4 && !lstrcmp(dbv.pszVal+lstrlen(dbv.pszVal)-4," SMS")) 
				{
					dbv.pszVal[lstrlen(dbv.pszVal)-4]='\0';
					if(!lstrcmp(strCellular(dbv.pszVal),strCellular(cNumber)))
					{
						hContactTmp = hContact;
						return hContactTmp;				
					}
				}
				DBFreeVariant(&dbv);
			}
			for(i=0;;i++) 
			{
				wsprintf(idstr,"MyPhone%d",i);
				if(DBGetContactSetting(hContact,"UserInfo",idstr,&dbv))
					break;
				wsprintf(idstr,Translate("Custom %d"),i+1);
				if(lstrlen(dbv.pszVal)>4 && !lstrcmp(dbv.pszVal+lstrlen(dbv.pszVal)-4," SMS")) 
				{
					dbv.pszVal[lstrlen(dbv.pszVal)-4]='\0';
					if(!lstrcmp(strCellular(dbv.pszVal),strCellular(cNumber)))
					{
						hContactTmp = hContact;
						return hContactTmp;
					}
				}
				DBFreeVariant(&dbv);
			}
			hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0);
		}
	}
	return (HANDLE)NULL;
}

void RestoreUnreadMessageAlerts(void)
{
	char toolTip[256];
	CLISTEVENT cle={0};
	DBEVENTINFO dbei={0};
	HANDLE hDbEvent,hContact;
	char *contactName;

	dbei.cbSize=sizeof(dbei);
	
	hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
	while(hContact) {
		hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDFIRSTUNREAD,(WPARAM)hContact,0);
		while(hDbEvent) {
			dbei.cbBlob=0;
			CallService(MS_DB_EVENT_GET,(WPARAM)hDbEvent,(LPARAM)&dbei);
			if(!(dbei.flags&(DBEF_SENT|DBEF_READ)) && ((dbei.eventType==ICQEVENTTYPE_SMS) || (dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION))) {
				handleNewMessage((WPARAM)hContact,(LPARAM)hDbEvent);
			}
			hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDNEXT,(WPARAM)hDbEvent,0);
		}
		hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0);
	}
	hContact=NULL;
	hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDFIRSTUNREAD,(WPARAM)hContact,0);
	while(hDbEvent) {
		dbei.cbBlob=0;
		CallService(MS_DB_EVENT_GET,(WPARAM)hDbEvent,(LPARAM)&dbei);
		if(!(dbei.flags&(DBEF_SENT|DBEF_READ)) && (dbei.eventType==ICQEVENTTYPE_SMS)) {
			if(DBGetContactSettingByte(NULL,"SRMsg","AutoPopup",0)) {
				HWND hwndRecvSms;
				int i;
				char cTmpNum[256];
				char newtitle[256];
				hwndRecvSms=AddRecvSMSWindow();
				lstrcpy(newtitle,Translate("Unknown"));
				lstrcat(newtitle," - ");
				lstrcat(newtitle,Translate("Received SMS"));
				SetWindowText(hwndRecvSms,newtitle);
				SetRecvSMSWindowHContact(hwndRecvSms,(HANDLE)hContact);
				SetDlgItemText(hwndRecvSms,IDC_NAME,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0));
				for(i=10;*((char*)dbei.pBlob + i)!='\r';i++)
					cTmpNum[i-10]=*((char*)dbei.pBlob + i);
				cTmpNum[i-10]='\0';
				SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
				SetDlgItemText(hwndRecvSms,IDC_MESSAGE,(char*)dbei.pBlob);
				CallService(MS_DB_EVENT_MARKREAD,(WPARAM)hContact,(LPARAM)&dbei);
			}
			else
			{
				ZeroMemory(&cle,sizeof(cle));
				cle.cbSize=sizeof(cle);
				cle.hContact=(HANDLE)hContact;
				cle.hDbEvent=(HANDLE)hDbEvent;
				cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));
				cle.pszService="SRSMS/ReadSms";
				contactName=(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0);
				wsnprintf(toolTip,sizeof(toolTip),Translate("SMS Message from %s"),contactName);
				cle.pszTooltip=toolTip;
				CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
			}
		}
		if(!(dbei.flags&(DBEF_SENT|DBEF_READ)) && (dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION)) {
			int i;
			char *cStatus;
			cStatus=(char*)malloc(lstrlen(dbei.pBlob)+1);
			lstrcpy(cStatus,dbei.pBlob);
			for(i=0;i<(signed)lstrlen(dbei.pBlob);i++)
				if(*(cStatus+i) == '\n')
					break;
			cStatus=cStatus + i + 1;
			SkinPlaySound("RecvSMSConfirmation");
			if(DBGetContactSettingByte(NULL,"SRMsg","AutoPopup",0)) 
			{
				HWND hwndRecvSms;
				int	i;
				char cTmpNum[256];
				char newtitle[256];
				hwndRecvSms=AddRecvSMSWindow();
				lstrcpy(newtitle,Translate("Unknown"));
				lstrcat(newtitle," - ");
				lstrcat(newtitle,Translate("Received SMS Confirmation"));
				SetWindowText(hwndRecvSms,newtitle);
				SetRecvSMSWindowHContact(hwndRecvSms,(HANDLE)hContact);
				SetDlgItemText(hwndRecvSms,IDC_NAME,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0));
				for(i=23;*((char*)dbei.pBlob + i)!='\r';i++)
					cTmpNum[i-23]=*((char*)dbei.pBlob + i);
				cTmpNum[i-23]='\0';
				if(!lstrcmp("SMS was sent succesfully",((char*)dbei.pBlob + i + 2)))
					SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT)));
				else
					SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT)));
				SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
				SetDlgItemText(hwndRecvSms,IDC_MESSAGE,(char*)dbei.pBlob);		
				CallService(MS_DB_EVENT_DELETE,(WPARAM)hContact,(LPARAM)&dbei);					
			}
			else
			{
				ZeroMemory(&cle,sizeof(cle));
				cle.cbSize=sizeof(cle);
				cle.hContact=(HANDLE)hContact;
				cle.hDbEvent=(HANDLE)hDbEvent;
				if(!lstrcmp(cStatus,"SMS was not sent succesfully"))
					cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT));
				else
					cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT));
				cle.pszService="SRSMS/ReadSmsAck";
				contactName=(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0);
				wsnprintf(toolTip,sizeof(toolTip),Translate("SMS Confirmation from %s"),contactName);
				cle.pszTooltip=toolTip;
				CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
			}
		}
		hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDNEXT,(WPARAM)hDbEvent,0);
	}
		
 
}