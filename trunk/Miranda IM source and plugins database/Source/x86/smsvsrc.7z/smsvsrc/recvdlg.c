/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/

#include "main.h"
#include <windows.h>
#include <stdio.h>
#include "resource.h"
#include "newpluginapi.h"
#include "m_database.h"
#include "m_clist.h"
#include "m_langpack.h"
#include "m_protomod.h"

//Defnition needed to the SMS window list
typedef struct {
	HWND hwndSMS;
	char *cMsg;
	HANDLE hContact;
} SMSWindowRecv;
static SMSWindowRecv *SMSWindowRecvList=NULL;
static int SMSWindowRecvNum;
//END of defenitions


static WNDPROC OldEditWndProc;

static LRESULT CALLBACK MessageSubclassProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message) {
		case WM_CHAR:
			if(wParam=='\n' && GetKeyState(VK_CONTROL)&0x8000) {
				PostMessage(GetParent(hwnd),WM_COMMAND,IDOK,0);
				return 0;
			}
			break;
	}
	return CallWindowProc(OldEditWndProc,hwnd,message,wParam,lParam);
}

BOOL CALLBACK RecvSmsDlgProc(HWND hwndDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message) {
		case WM_INITDIALOG:
			TranslateDialogDefault(hwndDlg); //Translate intially - bid
			SendMessage(hwndDlg,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS)));
			OldEditWndProc=(WNDPROC)SetWindowLong(GetDlgItem(hwndDlg,IDC_MESSAGE),GWL_WNDPROC,(LONG)MessageSubclassProc);
			InvalidateRect(GetDlgItem(hwndDlg,IDC_MESSAGE),NULL,FALSE);
			{	HFONT hFont;
				LOGFONT lf;
				hFont=(HFONT)SendDlgItemMessage(hwndDlg,IDC_MESSAGE,WM_GETFONT,0,0);
				if(hFont!=NULL && hFont!=(HFONT)SendDlgItemMessage(hwndDlg,IDOK,WM_GETFONT,0,0)) DeleteObject(hFont);
				LoadMsgDlgFont(MSGFONTID_YOURMSG,&lf,NULL);
				hFont=CreateFontIndirect(&lf);
				SendDlgItemMessage(hwndDlg,IDC_MESSAGE,WM_SETFONT,(WPARAM)hFont,MAKELPARAM(TRUE,0));
			}
			{
				int x,y,cx,cy;
				HANDLE hContact;
				hContact=NULL;
				x=DBGetContactSettingDword(hContact,"SMSPlugin","recvx",0);
				y=DBGetContactSettingDword(hContact,"SMSPlugin","recvy",0);
				cx=DBGetContactSettingDword(hContact,"SMSPlugin","recvwidth",0);
				cy=DBGetContactSettingDword(hContact,"SMSPlugin","recvheight",0);
				if((x==0) && (y==0) && (cx==0) && (cy==0))
					SetWindowPos(hwndDlg,0,200,200,400,350,SWP_NOZORDER);	
				else
					SetWindowPos(hwndDlg,0,x,y,cx,cy,SWP_NOZORDER);	
			}
			break;
		case WM_CTLCOLORSTATIC:
			{	
				COLORREF colour;
				HBRUSH hBkgBrush;
				if((HWND)lParam!=GetDlgItem(hwndDlg,IDC_MESSAGE)) break;
				LoadMsgDlgFont(MSGFONTID_YOURMSG,NULL,&colour);
				SetTextColor((HDC)wParam,colour);
				SetBkColor((HDC)wParam,DBGetContactSettingDword(NULL,"SRMsg","BkgColour",SRMSGDEFSET_BKGCOLOUR));
				hBkgBrush=CreateSolidBrush(DBGetContactSettingDword(NULL,"SRMsg","BkgColour",SRMSGDEFSET_BKGCOLOUR));
				return (BOOL)hBkgBrush;
			}
		case WM_GETMINMAXINFO:
			{
				((MINMAXINFO*)lParam)->ptMinTrackSize.x=300; 
				((MINMAXINFO*)lParam)->ptMinTrackSize.y=230;
			}
			break;
		case WM_SIZE:
			{
				RECT rcWin;
				int cx,cy;
				GetWindowRect(hwndDlg,&rcWin);
				cx = rcWin.right - rcWin.left;
				cy = rcWin.bottom - rcWin.top;
				SetWindowPos(GetDlgItem(hwndDlg,IDC_MESSAGE),0,0,0,cx - 14,cy - 112,SWP_NOZORDER|SWP_NOMOVE);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_NAME),0,0,0,(cx*35)/100,20,SWP_NOZORDER|SWP_NOMOVE);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_NUMBER),0,cx - (cx*35)/100 - 11,5,(cx*35)/100,20,SWP_NOZORDER);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_ST_NUMBER),0,cx - (cx*35)/100 - 58,5,40,20,SWP_NOZORDER);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_READNEXT),0,cx - 87, cy - 60,80,25,SWP_NOZORDER);
				SetWindowPos(GetDlgItem(hwndDlg,IDOK),0,cx/2 - 87,cy - 60,80,25,SWP_NOZORDER);
				SetWindowPos(GetDlgItem(hwndDlg,IDCANCEL),0,cx/2 + 7,cy - 60,80,25,SWP_NOZORDER);

				RedrawWindow(hwndDlg,NULL,NULL,RDW_FRAME|RDW_INVALIDATE);
			}
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam)) {
				case IDOK:
					{
						char name[256];
						char number[256];
						HANDLE hContact;
						HWND hwndSendSms;
						GetDlgItemText(hwndDlg,IDC_NAME,name,sizeof(name));
						GetDlgItemText(hwndDlg,IDC_NUMBER,number,sizeof(number));
						number[lstrlen(number)]='\0';
						hContact=CellularToHandle(strCellular(number));
						hwndSendSms=IsOtherInstanceHContact(hContact);
						if(hwndSendSms != NULL)
						{
							SetFocus(hwndSendSms);
						}
						else
						{
							char newtitle[256];

							hwndSendSms=AddSendSMSWindow(GetRecvSMSWindowHContact(hwndDlg));
							SetSendSMSWindowHContact(hwndSendSms,GetRecvSMSWindowHContact(hwndDlg));
							//SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_RESETCONTENT,0,0);
							SendDlgItemMessage(hwndSendSms,IDC_NAME,CB_ADDSTRING,0,(LPARAM)name);
							SendDlgItemMessage(hwndSendSms, IDC_NAME, CB_SETCURSEL, 0, 0);
							lstrcpy(newtitle,name);
							lstrcat(newtitle," - ");
							lstrcat(newtitle,Translate("Send SMS"));
							SetWindowText(hwndSendSms,newtitle);
							{
								int i;
								char idstr[256];
								{	
									char *cTmp;
									HANDLE hContact=NULL;
									DBVARIANT dbv;
									char *szProto;
									hContact=GetRecvSMSWindowHContact(hwndDlg);
									SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_RESETCONTENT,0,0);
									szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
									if(!DBGetContactSetting(hContact,szProto,"Cellular",&dbv)) 
									{
										if(lstrlen(dbv.pszVal)>4 && !lstrcmp(dbv.pszVal+lstrlen(dbv.pszVal)-4," SMS")) 
										{
											dbv.pszVal[lstrlen(dbv.pszVal)-4]='\0';
											cTmp=malloc(lstrlen(dbv.pszVal)+2);
											lstrcpy(cTmp,"+");
											lstrcat(cTmp,strCellular(dbv.pszVal));
											SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)cTmp);
											free(cTmp);
										}
									DBFreeVariant(&dbv);
									}
									for(i=0;;i++) 
									{
										wsprintf(idstr,"MyPhone%d",i);
										if(DBGetContactSetting(hContact,"UserInfo",idstr,&dbv))
											break;
										wsprintf(idstr,Translate("Custom %d"),i+1);
										if(lstrlen(dbv.pszVal)>4 && !lstrcmp(dbv.pszVal+lstrlen(dbv.pszVal)-4," SMS")) 
										{
											dbv.pszVal[lstrlen(dbv.pszVal)-4]='\0';
											cTmp=malloc(lstrlen(dbv.pszVal)+2);
											lstrcpy(cTmp,"+");
											lstrcat(cTmp,strCellular(dbv.pszVal));
											SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)cTmp);
											free(cTmp);
										}
										DBFreeVariant(&dbv);
									}
								}
							}
							//SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)number);
							SetDlgItemText(hwndSendSms,IDC_ADDRESS,number);
							SetFocus(GetDlgItem(hwndSendSms,IDC_MESSAGE));
							SetSendSMSWindowHContact(hwndSendSms,hContact);
							//{
							//	int x,y,cx,cy;
							//	HANDLE hContact;
							//	if(DBGetContactSettingByte(NULL,"SRMsg","SavePerContact",0))
							//		hContact=GetSendSMSWindowHContact(hwndSendSms);
							//	else hContact=NULL;
							//	x = DBGetContactSettingDword(hContact,"SMSPlugin","sendx",0);
							//	y = DBGetContactSettingDword(hContact,"SMSPlugin","sendy",0);
							//	cx = DBGetContactSettingDword(hContact,"SMSPlugin","sendwidth",0);
							//	cy = DBGetContactSettingDword(hContact,"SMSPlugin","sendheight",0);
							//	if((x==0) && (y==0) && (cx==0) && (cy==0))
							//		SetWindowPos(hwndSendSms,0,200,200,400,350,SWP_NOZORDER);	
							//	else
							//		SetWindowPos(hwndSendSms,0,x,y,cx,cy,SWP_NOZORDER);
							//}
						}
						
					}
				case IDCANCEL:
					RemoveRecvSMSWindow(hwndDlg);
					break;
			}
			break;
		case WM_CLOSE:
			RemoveRecvSMSWindow(hwndDlg);
			break;
	}
	return FALSE;
}

//SMS Receive window list functions

//This function create a new SMS receive window, and insert it to the list.
//The function gets void and return the window HWND
HWND AddRecvSMSWindow()
{
	SMSWindowRecv SMSWindowRecvTmp;
	SMSWindowRecvTmp.hwndSMS = CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_RECVSMS),NULL,RecvSmsDlgProc);
	SMSWindowRecvTmp.cMsg = NULL;
	SMSWindowRecvTmp.hContact = NULL;
	SMSWindowRecvNum++;
	SMSWindowRecvList=(SMSWindowRecv*)realloc(SMSWindowRecvList,sizeof(SMSWindowRecv) * SMSWindowRecvNum);
	*(SMSWindowRecvList + SMSWindowRecvNum - 1) = SMSWindowRecvTmp;
	return SMSWindowRecvTmp.hwndSMS;
}

//This function set the contact info of the person we send him the in the given to the SMS receive window.
//The function gets the HWND of the window and the HANDLE of the contact and return void
void SetRecvSMSWindowHContact(HWND hwndDlg, HANDLE hContact)
{
	int i;
	for(i=0;i < SMSWindowRecvNum;i++)
		if((SMSWindowRecvList + i)->hwndSMS == hwndDlg)
		{
			(SMSWindowRecvList + i)->hContact = hContact;
			return;
		}
}

HANDLE GetRecvSMSWindowHContact(HWND hwndDlg)
{
	int i;
	for(i=0;i < SMSWindowRecvNum;i++)
		if((SMSWindowRecvList + i)->hwndSMS == hwndDlg)
		{
			return (SMSWindowRecvList + i)->hContact;
		}
	return NULL;
}

//This function close the SMS receive window that given, and remove it from the list.
//The function gets the HWND of the window that should be removed and return void
void RemoveRecvSMSWindow(HWND hwndRemove)
{
	int i,iDel;
	SMSWindowRecv SMSWindowRecvTmp;
	for(i=0;i < SMSWindowRecvNum;i++)
		if((SMSWindowRecvList + i)->hwndSMS == hwndRemove)
			break;
	iDel=i;
	{
		WINDOWPLACEMENT wp={0};
		HANDLE hContact;
		if(DBGetContactSettingByte(NULL,"SRMsg","SavePerContact",0))
			hContact=GetSendSMSWindowHContact(hwndRemove);
		else hContact=NULL;
		wp.length=sizeof(wp);
		GetWindowPlacement(hwndRemove,&wp);
		DBWriteContactSettingDword(hContact,"SMSPlugin","recvx",wp.rcNormalPosition.left);
		DBWriteContactSettingDword(hContact,"SMSPlugin","recvy",wp.rcNormalPosition.top);
		DBWriteContactSettingDword(hContact,"SMSPlugin","recvwidth",wp.rcNormalPosition.right-wp.rcNormalPosition.left);
		DBWriteContactSettingDword(hContact,"SMSPlugin","recvheight",wp.rcNormalPosition.bottom-wp.rcNormalPosition.top);
	}	
	DestroyWindow((SMSWindowRecvList + iDel)->hwndSMS);
	SMSWindowRecvNum--;
	SMSWindowRecvTmp = *(SMSWindowRecvList + SMSWindowRecvNum);
	if(SMSWindowRecvNum != 0)
		SMSWindowRecvList=(SMSWindowRecv*)realloc(SMSWindowRecvList,sizeof(SMSWindowRecv)*SMSWindowRecvNum);
	else
		SMSWindowRecvList=NULL;
	if(iDel < SMSWindowRecvNum)
		*(SMSWindowRecvList + iDel) = SMSWindowRecvTmp;
}

//This function destroy all SMS receive windows
void RemoveAllRecvSMSWindow()
{
	int i;
	for(i=0;i < SMSWindowRecvNum;i++)
		DestroyWindow((SMSWindowRecvList + i)->hwndSMS);
	SMSWindowRecvNum=0;
	SMSWindowRecvList=NULL;
}

//
void AddRecvSMSWindowNewMessage(HWND hwndDlg, char *cMessage)
{
//	int i;
//	for(i=0;i < SMSWindowRecvNum;i++)
//		if((SMSWindowRecvList + i)->hwndSMS == hwndDlg)
//		{
//			(SMSWindowRecvList + i)->cMessagesNum++;
//		}
}

//
void ReadNextMessage(HWND hwndDlg)
{
	
}

//
void RemoveAllNextMessages(HWND hwndDlg)
{
	
}