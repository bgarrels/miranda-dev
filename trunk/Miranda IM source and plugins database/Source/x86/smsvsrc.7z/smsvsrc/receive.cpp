/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes
Copyright (C) 2007  Rozhuk Ivan

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at www.nuke007.tk
Enjoy the code and use it smartly!
*/

#include "main.h"


HANDLE hHookDbAdd;
HANDLE hHookAck;

//This function handles the ACK received from that hooked.
static int handleAckSMS(WPARAM wParam,LPARAM lParam)
{
	if (lParam)
	if (((ACKDATA*)lParam)->type==ICQACKTYPE_SMS)
	{
		char szPhone[MAX_PHONE_LEN];
		LPSTR lpszXML=(LPSTR)((ACKDATA*)lParam)->lParam,lpszData,lpszPhone;
		SIZE_T dwXMLSize=lstrlen(lpszXML),dwDataSize,dwPhoneSize;
		ACKDATA *ack=((ACKDATA*)lParam);

		if (GetXMLFieldEx(lpszXML,dwXMLSize,&lpszData,&dwDataSize,"sms_message","text",NULL))
		{
			/*char *cUTF8Decoded=NULL;
			char *cXMLDecoded=(char*)malloc(512);
			utf8_decode(GetXMLField(_strdup((char*)ack->lParam),"sms_message","text",NULL),&cUTF8Decoded);
			cXMLDecoded=DecodeXML(cUTF8Decoded);
			cResult=cXMLDecoded;*/

			LPWSTR lpwszBuff;
			SIZE_T dwBuffLen;

			lpwszBuff=(LPWSTR)MEMALLOC(((dwDataSize+MAX_PHONE_LEN+MAX_PATH)*sizeof(WCHAR)));
			if (lpwszBuff)
			{
				dwBuffLen=MultiByteToWideChar(CP_UTF8,0,lpszData,dwDataSize,lpwszBuff,(dwDataSize+MAX_PATH));
				if (dwBuffLen)
				{
					lpszData=(LPSTR)MEMALLOC((dwDataSize+MAX_PATH));
					if (lpszData)
					{
						dwDataSize=WideCharToMultiByte(GetConsoleCP(),WC_COMPOSITECHECK,lpwszBuff,dwBuffLen,lpszData,(dwDataSize+MAX_PATH),NULL,NULL);
						if (GetXMLFieldEx(lpszXML,dwXMLSize,&lpszPhone,&dwPhoneSize,"sms_message","sender",NULL))
						{
							HANDLE hContact;
							DBEVENTINFO dbei={0};

							dwPhoneSize=CopyNumber(szPhone,lpszPhone,dwPhoneSize);
							hContact=HContactFromPhone(szPhone,dwPhoneSize);

							dbei.cbSize=sizeof(dbei);
							dbei.szModule=GetModuleName(hContact);
							dbei.timestamp=time(NULL);
							dbei.eventType=ICQEVENTTYPE_SMS;
							dbei.cbBlob=(mir_snprintf((LPSTR)lpwszBuff,((dwDataSize+MAX_PHONE_LEN+MAX_PATH)*sizeof(WCHAR)),"SMS From: +%s\r\n%s",szPhone,lpszData)+sizeof(DWORD));
							dbei.pBlob=(PBYTE)lpwszBuff;
							(*((DWORD*)(dbei.pBlob+(dbei.cbBlob-sizeof(DWORD)))))=0;
							CallService(MS_DB_EVENT_ADD,(WPARAM)hContact,(LPARAM)&dbei);
							if (hContact==NULL)
							{	
								if (RecvSMSWindowAdd(NULL,ICQEVENTTYPE_SMS,szPhone,dwPhoneSize,(LPSTR)dbei.pBlob,dbei.cbBlob,IDI_SMS))
								{
									CallService(MS_DB_EVENT_MARKREAD,(WPARAM)hContact,(LPARAM)&dbei);
									SkinPlaySound("RecvSMSMsg");
								}
							}
						}
						MEMFREE(lpszData);
					}
				}
				MEMFREE(lpwszBuff);
			}
		}else
		if (GetXMLFieldEx(lpszXML,dwXMLSize,&lpszData,&dwDataSize,"sms_delivery_receipt","delivered",NULL))
		{
			if (GetXMLFieldEx(lpszXML,dwXMLSize,&lpszPhone,&dwPhoneSize,"sms_delivery_receipt","destination",NULL))
			{
				UINT iIcon;
				HANDLE hContact;
				DBEVENTINFO dbei={0};

				dwPhoneSize=CopyNumber(szPhone,lpszPhone,dwPhoneSize);
				hContact=HContactFromPhone(szPhone,dwPhoneSize);

				dbei.cbSize=sizeof(dbei);
				dbei.szModule=GetModuleName(hContact);
				dbei.timestamp=time(NULL);
				dbei.eventType=ICQEVENTTYPE_SMSCONFIRMATION;
				if (CompareStringA(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),NORM_IGNORECASE,lpszData,dwDataSize,"yes",3)==CSTR_EQUAL)
				{
					iIcon=IDI_SMSSENT;
					dbei.cbBlob=(MAX_PHONE_LEN+MAX_PATH);
					dbei.pBlob=(PBYTE)MEMALLOC(dbei.cbBlob);
					if (dbei.pBlob) dbei.cbBlob=(mir_snprintf((LPSTR)dbei.pBlob,dbei.cbBlob,"SMS From: +%s\r\nSMS was sent succesfully",szPhone)+4);
				}else{
					iIcon=IDI_SMSNOTSENT;
					if (GetXMLFieldEx(lpszXML,dwXMLSize,&lpszData,&dwDataSize,"sms_delivery_receipt","error","params","param",NULL)==FALSE)
					{
						lpszData="";
						dwDataSize=0;
					}
					dbei.cbBlob=(MAX_PHONE_LEN+MAX_PATH+dwDataSize);
					dbei.pBlob=(PBYTE)MEMALLOC(dbei.cbBlob);
					if (dbei.pBlob)
					{
						dbei.cbBlob=mir_snprintf((LPSTR)dbei.pBlob,dbei.cbBlob,"SMS From: +%s\r\nSMS was not sent succesfully: ",szPhone);
						CopyMemory((dbei.pBlob+dbei.cbBlob),lpszData,dwDataSize);
						dbei.cbBlob+=(dwDataSize+sizeof(DWORD));
						(*((DWORD*)(dbei.pBlob+(dbei.cbBlob-sizeof(DWORD)))))=0;
					}
				}

				if (dbei.pBlob)
				{
					if (hContact)
					{
						CallService(MS_DB_EVENT_ADD,(WPARAM)hContact,(LPARAM)&dbei);
					}else{
						RecvSMSWindowAdd(NULL,ICQEVENTTYPE_SMSCONFIRMATION,szPhone,dwPhoneSize,(LPSTR)dbei.pBlob,dbei.cbBlob,iIcon);
					}
					MEMFREE(dbei.pBlob);
				}
			}
		}else
		if ((ack->result==ACKRESULT_FAILED) || GetXMLFieldEx(lpszXML,dwXMLSize,&lpszData,&dwDataSize,"sms_response","deliverable",NULL))
		{
			HWND hWndDlg=SendSMSWindowHwndByHProcessGet(ack->hProcess);
			if (hWndDlg)
			{
				char szNetwork[MAX_PATH];

				KillTimer(hWndDlg,wParam);
				GetXMLFieldExBuff(lpszXML,dwXMLSize,szNetwork,sizeof(szNetwork),NULL,"sms_response","network",NULL);

				if (ack->result==ACKRESULT_FAILED || CompareStringA(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),NORM_IGNORECASE,lpszData,dwDataSize,"no",2)==CSTR_EQUAL)
				{	
					HWND hwndTimeOut;
					char szErrorMessage[1028],szBuff[1024];
					LPSTR lpszErrorDescription;

					if (SendSMSWindowMultipleGet(hWndDlg))
					{
						TVITEM tvi;
						tvi.mask=TVIF_TEXT;
						tvi.hItem=SendSMSWindowHItemSendGet(hWndDlg);
						tvi.pszText=szPhone;
						tvi.cchTextMax=sizeof(szPhone);
						TreeView_GetItem(GetDlgItem(hWndDlg,IDC_NUMBERSLIST),&tvi);
					}else{
						GetDlgItemText(hWndDlg,IDC_ADDRESS,szPhone,sizeof(szPhone));
					}
					if (ack->result==ACKRESULT_FAILED)
					{
						lpszErrorDescription=lpszXML;
					}else{
						lpszErrorDescription=szBuff;
						GetXMLFieldExBuff(lpszXML,dwXMLSize,szBuff,sizeof(szBuff),NULL,"sms_response","error","params","param",NULL);
					}
					wsprintf(szErrorMessage,Translate("SMS message didn't send by %s to %s because: %s"),szNetwork,szPhone,lpszErrorDescription);
					ShowWindow(hWndDlg,SW_SHOWNORMAL);
					EnableWindow(hWndDlg,FALSE);
					hwndTimeOut=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSTIMEDOUT),hWndDlg,SMSTimedOutDlgProc);
					SetDlgItemText(hwndTimeOut,IDC_STATUS,szErrorMessage);
				}else{
					SendSMSWindowDBAdd(hWndDlg);
					if (SendSMSWindowMultipleGet(hWndDlg))
					{
						if (SendSMSWindowNextHItemGet(hWndDlg,SendSMSWindowHItemSendGet(hWndDlg)))
						{
							SendSMSWindowAsSentSet(hWndDlg);
							SendSMSWindowHItemSendSet(hWndDlg,SendSMSWindowNextHItemGet(hWndDlg,SendSMSWindowHItemSendGet(hWndDlg)));
							SendSMSWindowNext(hWndDlg);
						}else{
							SendSMSWindowRemove(hWndDlg);
						}
					}else{
						if (CompareStringA(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),NORM_IGNORECASE,lpszData,dwDataSize,"yes",3)==CSTR_EQUAL || CompareStringA(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),NORM_IGNORECASE,lpszData,dwDataSize,"smtp",4)==CSTR_EQUAL)
						{
							char cShowACK[2],szSource[MAX_PATH],szMessageID[MAX_PATH];
							GetStringOption(3,cShowACK,sizeof(cShowACK));
							if (cShowACK[0]=='1')
							{	
								HWND hwndAccepted=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSACCEPT),hWndDlg,SMSAcceptedDlgProc);
								if (CompareStringA(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),NORM_IGNORECASE,lpszData,dwDataSize,"yes",3)==CSTR_EQUAL)
								{
									GetXMLFieldExBuff(lpszXML,dwXMLSize,szSource,sizeof(szSource),NULL,"sms_response","source",NULL);
									GetXMLFieldExBuff(lpszXML,dwXMLSize,szMessageID,sizeof(szMessageID),NULL,"sms_response","message_id",NULL);
								}else{
									SetDlgItemText(hwndAccepted,IDC_ST_SOURCE,Translate("From:"));
									SetDlgItemText(hwndAccepted,IDC_ST_MESSAGEID,Translate("To:"));
									GetXMLFieldExBuff(lpszXML,dwXMLSize,szSource,sizeof(szSource),NULL,"sms_response","from",NULL);
									GetXMLFieldExBuff(lpszXML,dwXMLSize,szMessageID,sizeof(szMessageID),NULL,"sms_response","to",NULL);
								}
								SetDlgItemText(hwndAccepted,IDC_NETWORK,szNetwork);
								SetDlgItemText(hwndAccepted,IDC_SOURCE,szSource);
								SetDlgItemText(hwndAccepted,IDC_MESSAGEID,szMessageID);
							}else{
								SendSMSWindowRemove(hWndDlg);
							}
						}else{
							SendSMSWindowRemove(hWndDlg);
						}
					}
				}
			}
		}
	}
return(0);
}

//Handles new SMS messages added to the database
int handleNewMessage(WPARAM wParam,LPARAM lParam)
{
	char szToolTip[MAX_PATH];
	HANDLE hContact=(HANDLE)wParam,hDbEvent=(HANDLE)lParam;
	CLISTEVENT cle={0};
	DBEVENTINFO dbei={0};

	dbei.cbSize=sizeof(dbei);
	if ((dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,lParam,0))!=-1)
	{
		dbei.pBlob=(PBYTE)MEMALLOC(dbei.cbBlob);
		if (dbei.pBlob)
		{
			if (CallService(MS_DB_EVENT_GET,lParam,(LPARAM)&dbei)==0)
			if ((dbei.flags&DBEF_SENT)==0)
			if (dbei.eventType==ICQEVENTTYPE_SMS)
			{
				if (dbei.cbBlob>MIN_SMS_DBEVENT_LEN)
				{
					SkinPlaySound("RecvSMSMsg");
					if (DBGetContactSettingByte(NULL,"SRMsg","AutoPopup",0))
					{
						if (RecvSMSWindowAdd(hContact,ICQEVENTTYPE_SMS,NULL,0,(LPSTR)dbei.pBlob,dbei.cbBlob,IDI_SMS))
						{
							CallService(MS_DB_EVENT_MARKREAD,(WPARAM)hContact,(LPARAM)&dbei);
						}
					}else{
						cle.cbSize=sizeof(cle);
						cle.hContact=hContact;
						cle.hDbEvent=hDbEvent;
						cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));
						cle.pszService="SRSMS/ReadSms";
						mir_snprintf(szToolTip,sizeof(szToolTip),Translate("SMS Message from %s"),DB_GetContactName(hContact));
						cle.pszTooltip=szToolTip;
						CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
					}
				}
			}else
			if (dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION)
			{
				SkinPlaySound("RecvSMSConfirmation");
				if (DBGetContactSettingByte(NULL,"SRMsg","AutoPopup",0)) 
				{
					if (RecvSMSWindowAdd(hContact,ICQEVENTTYPE_SMSCONFIRMATION,NULL,0,(LPSTR)dbei.pBlob,dbei.cbBlob,0))
					{
						CallService(MS_DB_EVENT_DELETE,(WPARAM)hContact,(LPARAM)&dbei);
					}
				}else{
					UINT iIcon;

					if (GetDataFromMessage((LPSTR)dbei.pBlob,dbei.cbBlob,NULL,NULL,0,NULL,&iIcon))
					{
						cle.cbSize=sizeof(cle);
						cle.hContact=hContact;
						cle.hDbEvent=hDbEvent;
						cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(iIcon));
						cle.pszService="SRSMS/ReadSmsAck";
						mir_snprintf(szToolTip,sizeof(szToolTip),Translate("SMS Confirmation from %s"),DB_GetContactName(hContact));
						cle.pszTooltip=szToolTip;
						CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
					}
				}
			}
			MEMFREE(dbei.pBlob);
		}
	}
return(0);
}

void InitSmsRecv(void)
{
	hHookAck=HookEvent(ME_PROTO_ACK,handleAckSMS);
	hHookDbAdd=HookEvent(ME_DB_EVENT_ADDED,handleNewMessage);
	RecvSMSWindowInitialize();
	SkinAddNewSound("RecvSMSMsg",Translate("Incoming SMS Message"),"message.wav");
	SkinAddNewSound("RecvSMSConfirmation",Translate("Incoming SMS Confirmation"),"message.wav");
}

void UninitSmsRecv(void)
{
	UnhookEvent(hHookAck);
	UnhookEvent(hHookDbAdd);
	RecvSMSWindowDestroy();
}


