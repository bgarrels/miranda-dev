#ifndef _SMS_MAIN
#define _SMS_MAIN

#define MS_SENDSMS "SMSPlug/SendSMS"

#endif