#ifndef _SMS_SEND
#define _SMS_SEND

#define TIMEDOUT_CANCEL	    0
#define TIMEDOUT_RETRY	    1

#define TIMERID_MSGSEND      0
#define TIMEOUT_MSGSEND      60000

#define OPTION_SIGNATURE  1
#define OPTION_SIGNATUREPOS  2

#define DM_TIMEOUTDECIDED    (WM_USER+18)

#endif