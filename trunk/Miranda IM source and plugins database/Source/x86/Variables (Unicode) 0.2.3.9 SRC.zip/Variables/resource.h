//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Variables.rc
//
#define IDD_OPTS_DIALOG                 101
#define IDD_TRG_STRINGCHANGE            102
#define IDD_INPUT_DIALOG                103
#define IDD_CLIST_DIALOG                104
#define IDD_EXTRATEXT_DIALOG            105
#define IDD_HELPDIALOG                  106
#define IDD_HELP_DIALOG                 106
#define IDD_TOKENS_DIALOG               107
#define IDD_HELPINFO_DIALOG             108
#define IDD_ACT_PARSESTRING             109
#define IDD_CND_PARSESTRING             110
#define IDI_V                           113
#define IDC_FORMATTEXT                  1000
#define IDC_PARSE                       1001
#define IDC_AUTOPARSE                   1002
#define IDC_RESULT                      1003
#define IDC_PARSEATSTARTUP              1005
#define IDC_STRIPCRLF                   1006
#define IDC_SHOWHELP                    1008
#define IDC_TOKENLIST                   1013
#define IDC_TESTSTRING                  1014
#define IDC_OK                          1016
#define IDC_CANCEL                      1017
#define IDC_SUBJECT                     1018
#define IDC_CLIST                       1019
#define IDC_APPLY                       1020
#define IDC_EXTRATEXT                   1021
#define IDC_NULL                        1023
#define IDC_CONTACT                     1024
#define IDC_RICHEDIT1                   1025
#define IDC_HELPDESC                    1026
#define IDC_SPLITTER                    1028
#define IDC_TABS                        1030
#define IDC_ABOUT                       1035
#define IDC_ABOUTFRAME                  1036
#define IDC_SETTINGFRAME                1037
#define IDC_PARSESTRING                 1038
#define IDC_STRIPWS                     1039
#define IDC_STRIPALL                    1041
#define IDC_PARSEASYNC                  1047
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
