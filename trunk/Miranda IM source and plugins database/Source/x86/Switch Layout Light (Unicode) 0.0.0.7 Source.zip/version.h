/*
Copyright (C) 2010, 2011 tico-tico
*/

#define PLUGVERSION 0,0,0,7
#define MPLUGVERSION PLUGIN_MAKE_VERSION(0,0,0,7)
#define SPLUGVERSION "0.0.0.7"
