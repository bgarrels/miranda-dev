/*
Copyright (C) 2010, 2011 tico-tico
*/

#ifndef __SWITCHLAYOUTLIGHT_H__
#define __SWITCHLAYOUTLIGHT_H__

#include <windows.h>
#include <commctrl.h>
#include <richedit.h>
#include "version.h"
#include "newpluginapi.h"
#include "m_options.h"
#include "m_langpack.h"
#include "m_database.h"
#include "m_hotkeys.h"
#include "win2k.h"
#include "m_popup.h"
#include "m_smileyadd.h"

#define LAST	1
#define REV		2

void SwitchLayout(int);

// {005DB215-EC34-4a4c-BADB-187CD0F01012}
#define MIID_SWLL { 0x5db215, 0xec34, 0x4a4c, { 0xba, 0xdb, 0x18, 0x7c, 0xd0, 0xf0, 0x10, 0x12 } }

#endif
