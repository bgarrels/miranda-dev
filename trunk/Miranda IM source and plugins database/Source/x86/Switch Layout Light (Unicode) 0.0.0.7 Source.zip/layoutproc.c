/*
Copyright (C) 2007 Dmitry Titkov (C) 2010, 2011 tico-tico
*/

#include "switchlayoutlight.h"

SMADD_BATCHPARSE2 smgp;
SMADD_BATCHPARSERES *smileyPrs = NULL;

BOOL isItSmiley(unsigned int position)
{
	unsigned int j;

	if (smileyPrs == NULL) return FALSE;

	for (j = 0; j < smgp.numSmileys; j++)
	{
		if (position >= smileyPrs[j].startChar && position < (smileyPrs[j].startChar + smileyPrs[j].size))
			return TRUE;
	}
	
	return FALSE;
}

static DWORD CALLBACK StreamOutCallback(DWORD_PTR dwCookie, LPBYTE pbBuff, LONG cb, LONG * pcb)
{
	static int sendBufferSize;
	char ** ppText = (char **) dwCookie;

	if (*ppText == NULL) sendBufferSize = 0;

	*ppText = (char *)realloc(*ppText, sendBufferSize + cb + 2);
	memcpy (*ppText + sendBufferSize, pbBuff, cb);
	sendBufferSize += cb;
	*((TCHAR *)(*ppText + sendBufferSize)) = '\0';
	*pcb = cb;
    return 0;
}

TCHAR* Message_GetFromStream(HWND hwndRtf, DWORD dwPassedFlags)
{
	EDITSTREAM stream = {0};
	TCHAR *pszText = NULL;

	if (hwndRtf == 0) return NULL;

	stream.pfnCallback = StreamOutCallback;
	stream.dwCookie = (DWORD_PTR) & pszText;
	SendMessage(hwndRtf, EM_STREAMOUT, (WPARAM)dwPassedFlags, (LPARAM) & stream);

	return pszText;
}

void SwitchLayout( int last_rev )
{
	HWND hwnd = GetForegroundWindow();

	if(hwnd != NULL)
	{
		DWORD dwProcessID;
		DWORD dwThreadID = GetWindowThreadProcessId(hwnd, &dwProcessID);
		HWND hwnd2 = GetFocus();

		if(hwnd2 != NULL)
		{
			TCHAR szClassName[16];

			GetClassName(hwnd2, szClassName, SIZEOF(szClassName));

			if(lstrcmp(szClassName, _T("TExtHistoryGrid")) == 0 && ServiceExists(MS_POPUP_SHOWMESSAGE))	// make popup here
			{
				TCHAR buf[2048]; int i, slen; SHORT vks; TCHAR tchr; BYTE keys[256] = {0};
				
				SendMessage(hwnd2, WM_GETTEXT, SIZEOF(buf), (LPARAM)buf);		// gimme, gimme, gimme...
				
				slen = lstrlen(buf);
				if (slen != 0)
				{	
					HKL hkl;
					ActivateKeyboardLayout((HKL)HKL_NEXT, KLF_ACTIVATE); // go to next layout before....
					hkl = GetKeyboardLayout(dwThreadID);
					ActivateKeyboardLayout((HKL)HKL_PREV, KLF_ACTIVATE); // return to prev layout

					if (ServiceExists(MS_SMILEYADD_BATCHPARSE))
					{
						ZeroMemory(&smgp, sizeof(smgp));
						smgp.cbSize = sizeof(smgp);
						smgp.str = buf;
						smgp.flag = SAFL_UNICODE;
						smileyPrs = (SMADD_BATCHPARSERES *)CallService(MS_SMILEYADD_BATCHPARSE, 0, (LPARAM)&smgp);
					}

					for(i = 0; i < slen; i++)
					{
						vks = VkKeyScanEx(buf[i], hkl);

						keys[VK_SHIFT]   = (HIBYTE(vks) & 1) ? 0xFF : 0x00; // shift
						keys[VK_CONTROL] = (HIBYTE(vks) & 2) ? 0xFF : 0x00; // ctrl
						keys[VK_MENU]    = (HIBYTE(vks) & 4) ? 0xFF : 0x00;	// alt
						
						if (!isItSmiley(i))
						{
							if(ToUnicodeEx(LOBYTE(vks), 0, keys, &tchr, 1, 0, GetKeyboardLayout(dwThreadID)) == 1)
								buf[i] = tchr;
						}
					}

					if (smileyPrs != NULL)		CallService(MS_SMILEYADD_BATCHFREE, 0, (LPARAM)smileyPrs);
					
					PUShowMessageT(buf, SM_NOTIFY);
					
					if ((last_rev & LAST) && OpenClipboard(hwnd2))	// copy to clipboard
					{
						HGLOBAL hData = GlobalAlloc(GMEM_MOVEABLE, sizeof(TCHAR)*(slen+1));
						lstrcpy((TCHAR*)GlobalLock(hData), buf);
						GlobalUnlock(hData);
						EmptyClipboard();
						SetClipboardData(CF_UNICODETEXT, hData);
						CloseClipboard();
					}
				}
			}
			
			else
			if(lstrcmp(szClassName, _T("RichEdit20W")) == 0)
			{
				DWORD dwStart, dwEnd;
				int i, slen, start = 0; TCHAR *sel;
				BOOL somethingIsSelected = TRUE;
				SHORT vks; TCHAR tchr; BYTE keys[256] = {0};
				HKL hkl = GetKeyboardLayout(dwThreadID);

				SendMessage(hwnd2, EM_GETSEL, (WPARAM)&dwStart, (LPARAM)&dwEnd);
				
				if (dwStart == dwEnd)	somethingIsSelected = FALSE;
				
				if (somethingIsSelected)	sel = Message_GetFromStream(hwnd2, SF_TEXT|SF_UNICODE|SFF_SELECTION );
				else						sel = Message_GetFromStream(hwnd2, SF_TEXT|SF_UNICODE );
				
				ActivateKeyboardLayout((HKL)((last_rev & REV)?HKL_PREV:HKL_NEXT), KLF_ACTIVATE);
				
				slen = lstrlen(sel);	// lstrlen(NULL) == 0
				
				if (slen != 0)
				{
					if (ServiceExists(MS_SMILEYADD_BATCHPARSE))
					{
						ZeroMemory(&smgp, sizeof(smgp));
						smgp.cbSize = sizeof(smgp);
						smgp.str = sel;
						smgp.flag = SAFL_UNICODE;
						smileyPrs = (SMADD_BATCHPARSERES *)CallService(MS_SMILEYADD_BATCHPARSE, 0, (LPARAM)&smgp);
					}

					if ((last_rev & LAST) && !somethingIsSelected)
					{
						start = slen-1;
						while(start != 0)	{if (!(_istspace(sel[start]) || isItSmiley(start))) break; start--;}
						while(start != 0)	{if (_istspace(sel[start]) || isItSmiley(start)) break; start--;}
					}

					for(i = start; i < slen; i++)
					{
						vks = VkKeyScanEx(sel[i], hkl);

						keys[VK_SHIFT]   = (HIBYTE(vks) & 1) ? 0xFF : 0x00; // shift
						keys[VK_CONTROL] = (HIBYTE(vks) & 2) ? 0xFF : 0x00; // ctrl
						keys[VK_MENU]    = (HIBYTE(vks) & 4) ? 0xFF : 0x00;	// alt
						
						if (!isItSmiley(i))
						{
							if(ToUnicodeEx(LOBYTE(vks), 0, keys, &tchr, 1, 0, GetKeyboardLayout(dwThreadID)) == 1)
								sel[i] = tchr;
						}
					}

					if (smileyPrs != NULL)		CallService(MS_SMILEYADD_BATCHFREE, 0, (LPARAM)smileyPrs);

					if (somethingIsSelected)	SendMessage(hwnd2, EM_REPLACESEL, FALSE, (LPARAM)sel);
					else						SendMessage(hwnd2, WM_SETTEXT, 0, (LPARAM)sel);

					SendMessage(hwnd2, EM_SETSEL, dwStart, dwEnd);
				}
				free(sel);
			}
		}
	}
}
