/*
Copyright (C) 2007 Dmitry Titkov (C) 2010, 2011 tico-tico
*/

#include "switchlayoutlight.h"

PLUGINLINK *pluginLink;
HINSTANCE hInst;

PLUGININFOEX pluginInfo = {
	sizeof(PLUGININFOEX),
	"Switch Layout Light Unicode",
	MPLUGVERSION,
	"Allows to switch a layout of the entered text in the message window if the text is written in a wrong layout. Unicode version with SmileyAdd support.",
	"Tim, tico-tico",
	"",
	"� 2007 Dmitry Titkov � 2010, 2011 tico-tico",
	"",
	UNICODE_AWARE,
	0,
	MIID_SWLL
};

static HANDLE hHook;
static HANDLE hService;

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst=hinstDLL;
	return TRUE;
}

__declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	return &pluginInfo;
}

static const MUUID interfaces[] = {MIID_SWLL, MIID_LAST};
__declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

//-------------------------------------------------------------------------------------------------------
#define MS_SWLL_SWITCHLAYOUT "SwitchLayoutLight/SwitchLayout"
INT_PTR ServiceSwitch(WPARAM wParam, LPARAM lParam)
{
	SwitchLayout(lParam);
	return 0;
}
int OnModulesLoaded(WPARAM wParam, LPARAM lParam) 
{
	HOTKEYDESC hkd = {0};
	hkd.cbSize = sizeof(hkd);

	hService = CreateServiceFunction(MS_SWLL_SWITCHLAYOUT, ServiceSwitch);

	hkd.pszName = "SwitchLayoutLight/ConvertAllOrSelected";
	hkd.pszDescription = "Convert All / Selected";
	hkd.pszSection = "Switch Layout Light";
	hkd.pszService = MS_SWLL_SWITCHLAYOUT;
	hkd.DefHotKey = HOTKEYCODE(HOTKEYF_CONTROL, 'R') | HKF_MIRANDA_LOCAL;
	hkd.lParam = !LAST | !REV;
	CallService(MS_HOTKEY_REGISTER, 0, (LPARAM)&hkd);
	
	hkd.pszName = "SwitchLayoutLight/ConvertAllOrSelectedR";
	hkd.pszDescription = "Convert All / Selected (rev)";
	hkd.DefHotKey = HKF_MIRANDA_LOCAL;
	hkd.lParam = !LAST | REV;
	CallService(MS_HOTKEY_REGISTER, 0, (LPARAM)&hkd);
	
	hkd.pszName = "SwitchLayoutLight/ConvertLastOrSelected";
	hkd.pszDescription = "Convert Last / Selected";
	hkd.lParam = LAST | !REV;
	CallService(MS_HOTKEY_REGISTER, 0, (LPARAM)&hkd);
	
	hkd.pszName = "SwitchLayoutLight/ConvertLastOrSelectedR";
	hkd.pszDescription = "Convert Last / Selected (rev)";
	hkd.lParam = LAST | REV;
	CallService(MS_HOTKEY_REGISTER, 0, (LPARAM)&hkd);
	
	return 0;
}

//-------------------------------------------------------------------------------------------------------

__declspec(dllexport) int Load(PLUGINLINK *link)
{
	pluginLink = link;

	hHook = HookEvent(ME_SYSTEM_MODULESLOADED, OnModulesLoaded);

	return 0;
}

__declspec(dllexport) int Unload(void)
{
	DestroyServiceFunction(hService);
	UnhookEvent(hHook);

	return 0;
}
