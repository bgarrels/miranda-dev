//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDD_SENDSMS                     102
#define IDR_CONTEXT                     104
#define IDD_RECVSMS                     109
#define IDI_SMSNOTSENT                  110
#define IDI_SMSSENT                     111
#define IDD_SMSTIMEDOUT                 112
#define IDD_SENDSMSTIMEDOUT             113
#define IDI_HALFTICK                    119
#define IDD_SENDSMSACCEPT               120
#define IDD_OPT_SMSPLUGIN               234
#define IDC_ADDRESS                     1000
#define IDC_EDIT                        1001
#define IDC_ADDRESS2                    1001
#define IDC_ACCOUNTS                    1001
#define IDC_MESSAGE                     1002
#define IDC_STATUS                      1003
#define IDC_NUMBER                      1004
#define IDC_NAME                        1005
#define IDC_ADD                         1006
#define IDC_DELETE                      1008
#define IDC_SIGNATURE                   1008
#define IDC_LIST                        1009
#define IDC_COUNT                       1010
#define IDC_TEXT                        1011
#define IDC_MSGTYPE                     1012
#define IDC_MSGTIME                     1013
#define IDC_BEGIN                       1017
#define IDC_END                         1018
#define IDC_SAVENUMBER                  1020
#define IDC_MULTIPLE                    1025
#define IDC_ADDNUMBER                   1029
#define IDC_ST_CHARS                    1033
#define IDC_ST_ENTERMESSAGE             1034
#define IDC_ST_TO                       1035
#define IDC_ST_ADDRESS                  1036
#define IDC_ST_NUMBER                   1037
#define IDC_NUMBERSLIST                 1038
#define IDC_MESSAGEID                   1039
#define IDC_SOURCE                      1040
#define IDC_NETWORK                     1041
#define IDC_SHOWACK                     1044
#define IDC_NOSHOWACK                   1045
#define IDC_AUTOPOP                     1045
#define IDC_READNEXT                    1046
#define IDC_SAVEWINPOS                  1046
#define IDC_USESIGNATURE                1047
#define IDC_SIGNGROUP                   1048
#define IDC_ST_MESSAGEID                1049
#define IDC_ST_NETWORK                  1050
#define IDC_ST_SOURCE                   1051
#define IDC_HISTORY                     1080
#define IDM_VIEWMSG                     40001
#define IDM_VIEWACK                     40002
#define IDM_VIEWRCPT                    40003
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        121
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
