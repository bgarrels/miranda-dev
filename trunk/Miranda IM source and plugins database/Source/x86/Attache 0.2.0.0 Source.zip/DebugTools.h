#pragma once

//#define UPLOAD_URL		"http://zeus.pricewatch.com.au/~koobs/upload.php"
//#define UPLOAD_URL			"http://bugs.miranda-im.org/minidump_upload.php"
#define UPLOAD_URL			"http://attache.miranda-im.org/upload.php"

void InitializeDebug();
void UninitializeDebug();

// used for test upload in options
bool HttpUpload(TCHAR *filename, TCHAR *module_filename, TCHAR *module_filename2, TCHAR *module_version, TCHAR *module_version2, PVOID address, PVOID address2);