//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by minidump.rc
//
#define IDD_OPTIONS                     101
#define IDD_DIALOG1                     102
#define IDD_CP                          102
#define IDC_CHK_CONFUPLOAD              1001
#define IDC_CHK_DELUPLOADED             1002
#define IDC_BUTTON1                     1003
#define IDC_BTN_TEST                    1003
#define IDC_ED_ID                       1004
#define IDC_LNK_BUGS                    1006
#define IDC_LNK_DUMP                    1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
