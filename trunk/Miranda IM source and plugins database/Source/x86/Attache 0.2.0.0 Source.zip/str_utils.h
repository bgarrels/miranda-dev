#ifndef _STR_UTILS_INC
#define _STR_UTILS_INC

void set_codepage();

wchar_t *a2w(const char *as);
char *w2a(const wchar_t *ws);

char *w2u(const wchar_t *ws);
wchar_t *u2w(const char *ws);

TCHAR *u2t(const char *utfs);
char *t2u(const TCHAR *ts);

char *t2a(const TCHAR *ts);
TCHAR *a2t(const char *as);

char *u2a(const char *utfs);
char *a2u(const char *as);


#endif

