#ifndef _COMMON_INC
#define _COMMON_INC

#include <windows.h>
//#include <winsock2.h>
#include <wininet.h>
#include <malloc.h>

#include <newpluginapi.h>
#include <m_database.h>
#include <m_system.h>
#include <stdio.h>
#include <m_utils.h>
#include <m_updater.h>
#include <m_langpack.h>
#include <m_netlib.h>
#include <m_options.h>
#include <m_folders.h>

extern HINSTANCE hInst;
extern PLUGINLINK *pluginLink;

extern HANDLE hNetlibUser;

extern MM_INTERFACE mmi;
extern TCHAR stzDumpPath[MAX_PATH];

extern DWORD mirandaVersion;

#define DEFAULT_DUMP_PATH	"\\Attache\\dumps"

#endif
