#include <windows.h>
#include <commctrl.h>
#include <tchar.h>
#include <strsafe.h>
#include "miranda/newpluginapi.h"
#include "miranda/m_clist.h"
#include "miranda/m_protosvc.h"
#include "miranda/m_system.h"
#include "miranda/m_options.h"
#include "miranda/m_langpack.h"
#include "miranda/m_database.h"
#include "miranda/m_popup.h"
#include "resource.h"
#include "linkedlist.h"

HINSTANCE hInst;
PLUGINLINK *pluginLink;
HANDLE heap;
HANDLE statusModeChangeEvent;
HANDLE okToExitHookEvent;
HANDLE optInitializeEvent;
HANDLE manualChangeEvent;
HANDLE logFile = INVALID_HANDLE_VALUE;
CRITICAL_SECTION lock;
BOOL loaded = FALSE;

struct ListNode *threadStarted;
struct ListNode *manuallyChanged;
struct ListNode *loginFromOtherLocation;
struct ListNode *lastStatus;
struct ListNode *icons;


PLUGININFO pluginInfo={
    sizeof(PLUGININFO),
    "Real Reconnect Plugin",
    PLUGIN_MAKE_VERSION(0,0,1,0),
    "Makes real reconnecting for all protocols",
    "Ilya V. Gershman",
    "ilya@tvsystem.ru",
    "� 2005 Ilya V. Gershman",
    "http://intrice.com",
    0,
    0
};

#define MODULE                "RealReconnect"
#define SHOW_POPUP_SETTING    "ShowPopup"
#define POPUP_TIMEOUT_SETTING "PopupTimeout"
#define USE_LOG_SETTING       "UseLog"
#define DELAY_SECONDS_SETTING "DelaySeconds"
#define LOG_NAME_SETTING      "LogName"
#define NEED_RECONNECT        "NeedReconnect"

void writeNum(WORD num, int digits) {
  char d[16];
  DWORD read;
  int i;

  for (i = digits - 1; i >= 0; --i) {
    d[i] = num % 10 + '0';
    num /= 10;
  }
  for (i = 0; i < digits; ++i) {
    WriteFile(logFile, d + i, 1, &read, 0);
  }
}

void writeString(const char *str) {
  DWORD read;

  WriteFile(logFile, str, lstrlen(str), &read, 0);
}

void writeTime() {
  SYSTEMTIME time;

  GetLocalTime(&time);
  writeNum(time.wYear, 4);
  writeString("/");
  writeNum(time.wMonth, 2);
  writeString("/");
  writeNum(time.wDay, 2);
  writeString(" ");
  writeNum(time.wHour, 2);
  writeString(":");
  writeNum(time.wMinute, 2);
  writeString(":");
  writeNum(time.wSecond, 2);
  writeString(".");
  writeNum(time.wMilliseconds, 3);
  writeString(" ");
}

BOOL isShowPopup()
{
  return (BOOL) DBGetContactSettingByte(NULL, MODULE, SHOW_POPUP_SETTING, FALSE);
}

int getPopupTimeout()
{
  return (int)DBGetContactSettingDword(NULL, MODULE, POPUP_TIMEOUT_SETTING, 0);
}

BOOL isUseLog()
{
  return (BOOL) DBGetContactSettingByte(NULL, MODULE, USE_LOG_SETTING, FALSE);
}

WORD getDelaySeconds()
{
  return DBGetContactSettingWord(NULL, MODULE, DELAY_SECONDS_SETTING, 30);
}

void getLogName(char *str)
{
  DBVARIANT dbv;

  if (DBGetContactSetting(NULL, MODULE, LOG_NAME_SETTING, &dbv)) {
    lstrcpy(str, "c:\\var\\log\\realreconnect.log");
  } else {
    lstrcpy(str, dbv.pszVal);
    DBFreeVariant(&dbv);
  }
}

BOOL needReconnectFor(const char *proto) {
  char settingName[64];
  lstrcpy(settingName, NEED_RECONNECT);
  lstrcat(settingName, proto);
  return (BOOL) DBGetContactSettingByte(NULL, MODULE, settingName, TRUE);
}

void setShowPopup(BOOL flag)
{
  DBWriteContactSettingByte(NULL, MODULE, SHOW_POPUP_SETTING, (BYTE)flag);
}

void setPopupTimout(int seconds)
{
  if (seconds < -1) {
    seconds = -1;
  }
  DBWriteContactSettingDword(NULL, MODULE, POPUP_TIMEOUT_SETTING, (DWORD)seconds);
}

void setUseLog(BOOL flag)
{
  DBWriteContactSettingByte(NULL, MODULE, USE_LOG_SETTING, (BYTE)flag);
}

void setDelaySeconds(WORD seconds)
{
  if (seconds < 10) {
    seconds = 10;
  }
  DBWriteContactSettingWord(NULL, MODULE, DELAY_SECONDS_SETTING, seconds);
}

void setLogName(char *logName)
{
  DBWriteContactSettingString(NULL, MODULE, LOG_NAME_SETTING, logName);
}

void setNeedReconnectFor(const char *proto, BOOL flag) {
  char settingName[64];
  lstrcpy(settingName, NEED_RECONNECT);
  lstrcat(settingName, proto);
  DBWriteContactSettingByte(NULL, MODULE, settingName, (BYTE)flag);
}

void writeStatus(int status)
{
  switch (status) {
    case ID_STATUS_CONNECTING:
      writeString("Connecting");
      break;
    case ID_STATUS_OFFLINE:
      writeString("Offline");
      break;
    case ID_STATUS_ONLINE:
      writeString("Online");
      break;
    case ID_STATUS_AWAY:
      writeString("Away");
      break;
    case ID_STATUS_DND:
      writeString("DND");
      break;
    case ID_STATUS_NA:
      writeString("N/A");
      break;
    case ID_STATUS_OCCUPIED:
      writeString("Occupied");
      break;
    case ID_STATUS_FREECHAT:
      writeString("Free For Char");
      break;
    case ID_STATUS_INVISIBLE:
      writeString("Invisible");
      break;
    case ID_STATUS_ONTHEPHONE:
      writeString("On the Phone");
      break;
    case ID_STATUS_OUTTOLUNCH:
      writeString("Out to Lunch");
      break;
    default:
      writeString("Unknown status");
      break;
  }
}

void logProtoMessage2(const char *sign, const char *proto, const char *msg, int status) {
  if (logFile == INVALID_HANDLE_VALUE || !isUseLog()) {
    return;
  }

  writeTime();
  writeString(sign);
  if (proto) {
    writeString(proto);
    writeString(" - ");
  }
  writeString(msg);
  if (status != -256) {
    writeStatus(status);
  }
  writeString("\r\n");
  FlushFileBuffers(logFile);
}

void logMessage2(const char *sign, const char *msg, int status) {
  logProtoMessage2(sign, 0, msg, status);
}

void logProtoMessage(const char *sign, const char *proto, const char *msg) {
  logProtoMessage2(sign, proto, msg, -256);
}

void logMessage(const char *sign, const char *msg) {
  logProtoMessage2(sign, 0, msg, -256);
}

static void ShowPopup(const char *proto, BOOL online) {
  POPUPDATAEX data;

  if (!isShowPopup()) {
    return;
  }

  ZeroMemory(&data, sizeof(data));
  data.lchIcon = (HICON)getValue(icons, proto, 0);
  lstrcpy(data.lpzContactName, Translate("Real Reconnect"));
  lstrcpy(data.lpzText, proto);
  lstrcat(data.lpzText, ": ");
  lstrcat(data.lpzText, Translate(online ? "Finished" : "Started"));
  lstrcat(data.lpzText, " ");
  lstrcat(data.lpzText, Translate("reconnecting"));
  data.iSeconds = getPopupTimeout();
  PUAddPopUpEx(&data);
}

DWORD WINAPI CheckStatus (const char *proto) {
  int status, i;
  BOOL all_ok = FALSE;
  BOOL exit = FALSE;

  Sleep(1000);
  EnterCriticalSection(&lock);
  exit = getValue(manuallyChanged, proto, FALSE);
  setValue(manuallyChanged, proto, FALSE);
  if (exit) {
    setValue(lastStatus, proto, ID_STATUS_OFFLINE);
    setValue(threadStarted, proto, FALSE);
  }
  LeaveCriticalSection(&lock);

  if (exit) {
    logProtoMessage("* ", proto, "Skipping manually changing");
    return 0;
  }

  EnterCriticalSection(&lock);
  exit = getValue(loginFromOtherLocation, proto, FALSE);
  setValue(loginFromOtherLocation, proto, FALSE);
  if (exit) {
    setValue(lastStatus, proto, ID_STATUS_OFFLINE);
    setValue(threadStarted, proto, FALSE);
  }
  LeaveCriticalSection(&lock);

  if (exit) {
    logProtoMessage("* ", proto, "Skipping due to login from other location");
    return 0;
  }

  logProtoMessage("+ ", proto, "Started reconnection thread");
  ShowPopup(proto, FALSE);

  while (!all_ok && loaded) {
    status = CallProtoService (proto, PS_GETSTATUS, 0, 0);
    all_ok = TRUE;
    if (status == ID_STATUS_OFFLINE) {
      logProtoMessage("+ ", proto, "Checking status: Offline");
      EnterCriticalSection(&lock);
      status = getValue(lastStatus, proto, ID_STATUS_ONLINE);
      LeaveCriticalSection(&lock);
      if (status != ID_STATUS_OFFLINE) {
        logProtoMessage2("! ", proto, "Changing status to: ", status);
        CallProtoService(proto, PS_SETSTATUS, (WPARAM)status, 0);
        all_ok = FALSE;
      }
    } else if (status == ID_STATUS_CONNECTING) {
      logProtoMessage("+ ", proto, "Checking status: Connecting");
      CallProtoService(proto, PS_SETSTATUS, (WPARAM)ID_STATUS_OFFLINE, 0);
      all_ok = FALSE;
    }

    if (!all_ok) {
      WORD delay = getDelaySeconds();
      for (i = 0; i < delay * 10 && loaded; ++i) {
        Sleep(100);
      }
    }
  }

  logProtoMessage("+ ", proto, "Finishing reconnection thread");
  ShowPopup(proto, TRUE);

  EnterCriticalSection(&lock);
  setValue(threadStarted, proto, FALSE);
  LeaveCriticalSection(&lock);

  return 0;
}

static int OkToExitHook (WPARAM wParam, LPARAM lParam) {
  logMessage("* ", "OkToExitHook");
  loaded = FALSE;
  return 0;
}

static int StatusModeChange (WPARAM wParam, LPARAM lParam)
{
  ACKDATA *ack =(ACKDATA*) lParam;
  int status;
  DWORD thread;
  int all_ok = TRUE;

  if (loaded && ack->type == ACKTYPE_LOGIN &&
      ack->result == ACKRESULT_FAILED && ack->lParam == LOGINERR_OTHERLOCATION) {
    EnterCriticalSection(&lock);
    setValue(loginFromOtherLocation, ack->szModule, TRUE);
    LeaveCriticalSection(&lock);
    return 0;
  }

  if (ack->type == ACKTYPE_STATUS && loaded) {
    if (!needReconnectFor(ack->szModule)) {
      return 0;
    }
    status = CallProtoService (ack->szModule, PS_GETSTATUS, 0, 0);
    if (status == ID_STATUS_OFFLINE) {
      logProtoMessage("! ", ack->szModule, "Status Changed to: Offline");
      all_ok = FALSE;
    } else if (status != ID_STATUS_CONNECTING) {
      logProtoMessage2("* ", ack->szModule, "Status Changed to: ", status);
      EnterCriticalSection(&lock);
      setValue(lastStatus, ack->szModule, status);
      LeaveCriticalSection(&lock);
    }

    EnterCriticalSection(&lock);
    if (!all_ok && !getValue(threadStarted, ack->szModule, FALSE)) {
      setValue(threadStarted, ack->szModule, TRUE);
      logProtoMessage("+ ", ack->szModule, "Starting reconnection thread");
      CreateThread(0, 0, CheckStatus, (LPVOID)ack->szModule, 0, &thread);
    }
    LeaveCriticalSection(&lock);
  }

  return 0;
}

static BOOL CALLBACK DlgProcOpts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch (msg)
  {
    case WM_INITDIALOG:
    {
      char str[MAX_PATH];
      RECT rect;
      LV_COLUMN lvc;
      PROTOCOLDESCRIPTOR **protos;
      int count, i, newItem;
      LV_ITEM lvi;
      HWND protoList;

      TranslateDialogDefault(hwndDlg);
      CheckDlgButton(hwndDlg, IDC_SHOW_POPUP, isShowPopup() ? BST_CHECKED : BST_UNCHECKED);
      EnableWindow(GetDlgItem(hwndDlg, IDC_POPUP_TIMEOUT), IsDlgButtonChecked(hwndDlg, IDC_SHOW_POPUP));
      SetDlgItemInt(hwndDlg, IDC_POPUP_TIMEOUT, getPopupTimeout(), TRUE);

      CheckDlgButton(hwndDlg, IDC_USE_LOG, isUseLog() ? BST_CHECKED : BST_UNCHECKED);
      SetDlgItemInt(hwndDlg, IDC_DELAY_MILLIS, getDelaySeconds(), FALSE);
      EnableWindow(GetDlgItem(hwndDlg, IDC_LOG_NAME), IsDlgButtonChecked(hwndDlg, IDC_USE_LOG));
      getLogName(str);
      SetDlgItemText(hwndDlg, IDC_LOG_NAME, str);

      protoList = GetDlgItem(hwndDlg, IDC_PROTO_LIST);
      GetClientRect(protoList, &rect);
      ListView_SetExtendedListViewStyle(protoList, LVS_EX_CHECKBOXES);

      lvc.mask = LVCF_WIDTH | LVCF_TEXT;
      lvc.cx = rect.right;
      lvc.pszText = Translate("Protocol");
      ListView_InsertColumn(protoList, 0, &lvc);

      CallService(MS_PROTO_ENUMPROTOCOLS, (WPARAM)&count, (LPARAM)&protos);
      lvi.mask = LVIF_TEXT;
      lvi.iSubItem = 0;
      for (i = 0; i < count; ++i) {
        if (protos[i]->type != PROTOTYPE_PROTOCOL) {
          continue;
        }

        lvi.pszText = protos[i]->szName;
        newItem = ListView_InsertItem(protoList, &lvi);
        ListView_SetCheckState(protoList, newItem, needReconnectFor(protos[i]->szName));
      }
      return TRUE;
    }

    case WM_COMMAND:
      switch(LOWORD(wParam)) {
        case IDC_USE_LOG:
          EnableWindow(GetDlgItem(hwndDlg,IDC_LOG_NAME),IsDlgButtonChecked(hwndDlg,IDC_USE_LOG));
          break;
        case IDC_SHOW_POPUP:
          EnableWindow(GetDlgItem(hwndDlg,IDC_POPUP_TIMEOUT),IsDlgButtonChecked(hwndDlg,IDC_SHOW_POPUP));
          break;
        case IDC_LOG_NAME:
          if (HIWORD(wParam) != EN_CHANGE) return 0;
          if ((HWND)lParam != GetFocus()) return 0;
          break;
      }
      SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);
      break;

    case WM_NOTIFY:
      switch (((LPNMHDR)lParam)->code)
      {
        case PSN_APPLY:
        {
          char str[MAX_PATH];
          HWND protoList;
          int count, i;

          GetDlgItemText(hwndDlg, IDC_LOG_NAME, str, sizeof(str));
          if (logFile != INVALID_HANDLE_VALUE) {
            CloseHandle(logFile);
            logFile = INVALID_HANDLE_VALUE;
          }
          if (IsDlgButtonChecked(hwndDlg, IDC_USE_LOG)) {
            logFile = CreateFile(str,
              FILE_APPEND_DATA, FILE_SHARE_READ, 0,
              OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
            SetFilePointer(logFile, 0, 0, FILE_END);
          }
          setLogName(str);
          setShowPopup(IsDlgButtonChecked(hwndDlg, IDC_SHOW_POPUP));
          setPopupTimout(GetDlgItemInt(hwndDlg, IDC_POPUP_TIMEOUT, NULL, TRUE));
          setUseLog(IsDlgButtonChecked(hwndDlg, IDC_USE_LOG));
          setDelaySeconds((WORD)GetDlgItemInt(hwndDlg, IDC_DELAY_MILLIS, NULL, FALSE));

          protoList = GetDlgItem(hwndDlg, IDC_PROTO_LIST);
          count = ListView_GetItemCount(protoList);
          for (i = 0; i < count; ++i) {
            ListView_GetItemText(protoList, i, 0, str, sizeof(str));
            setNeedReconnectFor(str, ListView_GetCheckState(protoList, i));
          }
          return TRUE;
        }
      }
      break;
  }
  return FALSE;
}

static int OptInitialise(WPARAM wParam, LPARAM lParam)
{
  OPTIONSDIALOGPAGE odp;

  ZeroMemory(&odp,sizeof(odp));
  odp.cbSize = sizeof(odp);
  odp.position = 1000000000;
  odp.hInstance = GetModuleHandle("realreconnect.dll");
  odp.pszTemplate = MAKEINTRESOURCE(IDD_OP_DLG);
  odp.pszTitle = Translate("Real Reconnect");
  odp.pszGroup = Translate("Plugins");
  odp.pfnDlgProc = (DLGPROC)DlgProcOpts;
  odp.flags = ODPF_BOLDGROUPS;
  CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);
  return 0;
}

static int AllStatusChanged()
{
  PROTOCOLDESCRIPTOR **protos;
  int count, i;

  CallService(MS_PROTO_ENUMPROTOCOLS, (WPARAM)&count, (LPARAM)&protos);

  EnterCriticalSection(&lock);
  for (i = 0; i < count; ++i) {
    if (protos[i]->type != PROTOTYPE_PROTOCOL) {
      continue;
    }

    if (needReconnectFor(protos[i]->szName)) {
      setValue(manuallyChanged, protos[i]->szName, TRUE);
    }
  }
  LeaveCriticalSection(&lock);

  return 0;
}

static int ManualStatusChange(WPARAM wParam, LPARAM lParam)
{
  const char *proto = (const char *)lParam;
  if (!proto && wParam == ID_STATUS_OFFLINE) {
    return AllStatusChanged();
  }

  if (!needReconnectFor(proto)) {
    return 0;
  }

  if (wParam == ID_STATUS_OFFLINE) {
    EnterCriticalSection(&lock);
    setValue(manuallyChanged, proto, TRUE);
    LeaveCriticalSection(&lock);
  }
  return 0;
}

static void loadIcons() {
  PROTOCOLDESCRIPTOR **protos;
  int count, i;

  CallService(MS_PROTO_ENUMPROTOCOLS, (WPARAM)&count, (LPARAM)&protos);

  for (i = 0; i < count; ++i) {
    if (protos[i]->type != PROTOTYPE_PROTOCOL) {
      continue;
    }

    setValue(
      icons,
      protos[i]->szName,
      CallProtoService(protos[i]->szName, PS_LOADICON, PLI_PROTOCOL|PLIF_SMALL, 0)
    );
  }
}

static void unloadIcons() {
  int length, i;

  length = getLength(icons);
  for (i = 0; i < length; ++i) {
    DestroyIcon((HICON) getValueByNum(icons, i));
  }
}

__declspec(dllexport) PLUGININFO* MirandaPluginInfo (DWORD mirandaVersion)
{
  return &pluginInfo;
}

/*DWORD WINAPI KeepStatus (void *dummy) {
  PROTOCOLDESCRIPTOR **protos;
  int count, i;

  while (1) {
    WORD delay = getDelaySeconds();
    for (i = 0; i < delay * 10 && loaded; ++i) {
      Sleep(100);
    }
    if (!loaded) {
      break;
    }

    CallService(MS_PROTO_ENUMPROTOCOLS, (WPARAM)&count, (LPARAM)&protos);

    for (i = 0; i < count; ++i) {
      if (protos[i]->type != PROTOTYPE_PROTOCOL) {
        continue;
      }

      if (needReconnectFor(protos[i]->szName)) {
        int status;

        EnterCriticalSection(&lock);
        status = getValue(lastStatus, protos[i]->szName, ID_STATUS_ONLINE);
        LeaveCriticalSection(&lock);

        CallProtoService(protos[i]->szName, PS_SETSTATUS, (WPARAM)status, 0);
        logProtoMessage2("* ", protos[i]->szName, "keeping status: ", status);
      }
    }
  }

  return 0;
}
*/
int __declspec(dllexport) Load (PLUGINLINK *link)
{
  pluginLink=link;

  heap = GetProcessHeap();
  threadStarted = initList();
  manuallyChanged = initList();
  loginFromOtherLocation = initList();
  lastStatus = initList();
  icons = initList();

  loadIcons();

  if (logFile == INVALID_HANDLE_VALUE) {
    char str[MAX_PATH];
    getLogName(str);

    if (isUseLog()) {
      logFile = CreateFile(str,
        FILE_APPEND_DATA, FILE_SHARE_READ, 0,
        OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
      SetFilePointer(logFile, 0, 0, FILE_END);
    }
  }

  InitializeCriticalSection (&lock);
  loaded = TRUE;
  statusModeChangeEvent = HookEvent(ME_PROTO_ACK, StatusModeChange);
  okToExitHookEvent = HookEvent(ME_SYSTEM_OKTOEXIT, OkToExitHook);
  optInitializeEvent = HookEvent(ME_OPT_INITIALISE, OptInitialise);
  manualChangeEvent = HookEvent(ME_CLIST_STATUSMODECHANGE, ManualStatusChange);
  logMessage("+ ", "Load");

//  CreateThread(0, 0, KeepStatus, 0, 0, &thread);

  return 0;
}

int __declspec(dllexport) Unload (void)
{
  logMessage("+ ", "Unload");
  loaded = FALSE;
  UnhookEvent(statusModeChangeEvent);
  UnhookEvent(okToExitHookEvent);
  UnhookEvent(optInitializeEvent);
  UnhookEvent(manualChangeEvent);
  DeleteCriticalSection(&lock);

  CloseHandle(logFile);
  logFile = INVALID_HANDLE_VALUE;

  unloadIcons();

  destroyList(threadStarted);
  destroyList(manuallyChanged);
  destroyList(loginFromOtherLocation);
  destroyList(lastStatus);
  destroyList(icons);

  return 0;
}


BOOL WINAPI DllMain(HANDLE hDllHandle, DWORD dwReason, LPVOID lpreserved)
{
  return TRUE ;
}

