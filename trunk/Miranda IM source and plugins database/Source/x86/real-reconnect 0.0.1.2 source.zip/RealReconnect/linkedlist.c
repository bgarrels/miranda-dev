#include "linkedlist.h"

struct ListNode *initList() {
  struct ListNode *root =
    HeapAlloc(heap, HEAP_ZERO_MEMORY, sizeof (struct ListNode));
  root->prev = root;
  root->next = root;
  return root;
}

void destroyList(struct ListNode *root) {
  struct ListNode *node = root->next;
  while (node != root) {
    node = node->next;
    HeapFree(heap, 0, node->prev);
  }
  HeapFree(heap, 0, root);
}

/*struct ListNode *insertAfter(struct ListNode *root, const char *name, DWORD value) {
  struct ListNode *node =
    HeapAlloc(heap, HEAP_ZERO_MEMORY, sizeof (struct ListNode));
  node->prev = root;
  node->next = root->next;
  root->next->prev = node;
  root->next = node;
  node->data.name = name;
  node->data.value = value;
  return node;
}*/

struct ListNode *insertBefore(struct ListNode *root, const char *name, DWORD value) {
  struct ListNode *node =
    HeapAlloc(heap, HEAP_ZERO_MEMORY, sizeof (struct ListNode));
  node->prev = root->prev;
  node->next = root;
  root->prev->next = node;
  root->prev = node;
  node->data.name = name;
  node->data.value = value;
  return node;
}

struct ListNode *findByName(struct ListNode *root, const char *name) {
  struct ListNode *node;
  for (node = root->next; node != root; node = node->next) {
    if (lstrcmp(node->data.name, name) == 0) {
      return node;
    }
  }
  return 0;
}

struct ListNode *setValue(struct ListNode *root, const char *name, DWORD value) {
  struct ListNode *node;
  node = findByName(root, name);
  if (node) {
    node->data.value = value;
  } else {
    node = insertBefore(root, name, value);
  }
  return node;
}

DWORD getValue(struct ListNode *root, const char *name, DWORD defaultValue) {
  struct ListNode *node;
  node = findByName(root, name);
  return node ? node->data.value : defaultValue;
}

int getLength(struct ListNode *root) {
  struct ListNode *node = root->next;
  int length = 0;
  while (node != root) {
    node = node->next;
    ++length;
  }
  return length;
}

DWORD getValueByNum(struct ListNode *root, int index) {
  struct ListNode *node = root->next;
  int length = -1;
  while (length != index) {
    node = node->next;
    ++length;
  }
  return node->data.value;
}
