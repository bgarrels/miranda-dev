//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by realreconnect.rc
//
#define IDD_OP_DLG                      101
#define IDC_LOG_NAME                    1001
#define IDC_USE_LOG                     1003
#define IDC_DELAY_MILLIS                1004
#define IDC_PROTO_LIST                  1005
#define IDC_SHOW_POPUP                  1007
#define IDC_POPUP_TIMEOUT               1008

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
