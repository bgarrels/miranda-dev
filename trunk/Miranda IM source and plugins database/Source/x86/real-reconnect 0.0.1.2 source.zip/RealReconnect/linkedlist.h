#ifndef __LINKEDLIST_H__
#define __LINKEDLIST_H__

#include <windows.h>

extern HANDLE heap;

struct ListData {
  const char *name;
  DWORD value;
};

struct ListNode {
  struct ListNode *prev;
  struct ListNode *next;
  struct ListData data;
};

struct ListNode *initList();
void destroyList(struct ListNode *root);
struct ListNode *insertAfter(struct ListNode *root, const char *name, DWORD value);
struct ListNode *insertBefore(struct ListNode *root, const char *name, DWORD value);
struct ListNode *findByName(struct ListNode *root, const char *name);
struct ListNode *setValue(struct ListNode *root, const char *name, DWORD value);
DWORD getValue(struct ListNode *root, const char *name, DWORD defaultValue);
int getLength(struct ListNode *root);
DWORD getValueByNum(struct ListNode *root, int index);

#endif
