//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDI_MIRANDA                     101
#define IDI_MIRANDAFILE                 102
#define IDD_OPT_ASSOCLIST               103
#define IDC_HEADERTEXT                  1001
#define IDC_ASSOCLIST                   1002
#define IDC_AUTOSTART                   1003
#define IDC_ONLYWHILERUNNING            1004
#define IDC_NOASSOC                     1005
#define IDC_MISCLABEL                   1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           2001
#endif
#endif
