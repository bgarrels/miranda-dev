/*

'File Association Manager'-Plugin for Miranda IM

Copyright (C) 2005-2007 H. Herkenrath

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (AssocMgr-License.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "common.h"
#include "version.h"

HINSTANCE hInst;
PLUGINLINK *pluginLink;
struct MM_INTERFACE mmi;
struct UTF8_INTERFACE utfi;
static HANDLE hHookModulesLoaded;

PLUGININFO pluginInfo={
	sizeof(PLUGININFO),
#if defined(_UNICODE)
	"File Association Manager (Unicode)",
#else
	"File Association Manager",
#endif
	PLUGIN_VERSION,
#if defined(_DEBUG)
	"Development build not intended for release. ("__DATE__")", /* autotranslated */
#else
	"Handles file type associations and URLs like aim, ymsgr, xmpp, wpmsg, gg, tlen.", /* autotranslated */
#endif
	"H. Herkenrath",
	PLUGIN_EMAIL,  /* @ will be set later */
	"� 2005-2007 H. Herkenrath",
	PLUGIN_WEBSITE,
	UNICODE_AWARE,
	0  /* does not replace anything built-in */
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,void *pReserved)
{
	UNREFERENCED_PARAMETER(pReserved);
	if(fdwReason==DLL_PROCESS_ATTACH) {
		/* Do not call this from a DLL that is linked to the static C run-time library (CRT).
		 * The static CRT requires DLL_THREAD_ATTACH and DLL_THREAD_DETATCH notifications
		 * to function properly. */
		DisableThreadLibraryCalls(hInst=hinstDLL);
	}
	return TRUE;
}

static void InstallFile(const TCHAR *pszFileName,const TCHAR *pszDestSubDir)
{
	TCHAR szFileFrom[MAX_PATH+1],szFileTo[MAX_PATH+1],*p;
	HANDLE hFile;

	if(!GetModuleFileName(hInst,szFileFrom,SIZEOF(szFileFrom)-lstrlen(pszFileName)))
		return;
	p=_tcsrchr(szFileFrom,_T('\\'));
	if(p!=NULL) *(++p)=0;
	lstrcat(szFileFrom,pszFileName); /* buffer safe */

	hFile=CreateFile(szFileFrom,0,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
	if(hFile==INVALID_HANDLE_VALUE) return;
	CloseHandle(hFile);

	if(!GetModuleFileName(NULL,szFileTo,SIZEOF(szFileTo)-lstrlen(pszDestSubDir)-lstrlen(pszFileName)))
		return;
	p=_tcsrchr(szFileTo,_T('\\'));
	if(p!=NULL) *(++p)=0;
	lstrcat(szFileTo,pszDestSubDir); /* buffer safe */
	CreateDirectory(szFileTo,NULL);
	lstrcat(szFileTo,pszFileName);  /* buffer safe */

	if(!MoveFile(szFileFrom,szFileTo) && GetLastError()==ERROR_ALREADY_EXISTS) {
		DeleteFile(szFileTo);
		MoveFile(szFileFrom,szFileTo);
	}
}

static int AssocMgrModulesLoaded(WPARAM wParam,LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	/* db editor */
	if(ServiceExists("DBEditorpp/RegisterSingleModule"))
		CallService("DBEditorpp/RegisterSingleModule",(WPARAM)"AssocMgr",0);
	InitTest();
	return 0;
}

#ifdef __cplusplus
extern "C" {
#endif 

__declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	if(mirandaVersion<PLUGIN_MAKE_VERSION(0,1,0,1)) return NULL;
	/* email obfuscated, made .rdata writable */
	pluginInfo.authorEmail[PLUGIN_EMAIL_ATT_POS-1]='@';
	return &pluginInfo;
}

__declspec(dllexport) int Load(PLUGINLINK *link)
{
	pluginLink=link;

	/* existance of MS_SYSTEM_GETVERSION and MS_LANGPACK_TRANSLATESTRING
	 * is checked in MirandaPluginInfo().
	 * Not placed in MirandaPluginInfo() to avoid MessageBoxes on plugin options. 
	 * Using ANSI as LANG_UNICODE might not be supported. */
	if(CallService(MS_SYSTEM_GETVERSION,0,0)<NEEDED_MIRANDA_VERSION) {
		char szText[256];
		mir_snprintf(szText,sizeof(szText),Translate("The File Association Manager Plugin can not be loaded. It requires Miranda IM %hs or later."),NEEDED_MIRANDA_VERSION_STR);
		MessageBoxA(NULL,szText,Translate("File Association Manager Plugin"),MB_OK|MB_ICONERROR|MB_SETFOREGROUND|MB_TOPMOST|MB_TASKMODAL);
		return 1;
	}
	if(!ServiceExists(MS_DB_CONTACT_GETSETTING_STR)) return 1; /* dbx3x v0.5.1.0 */
	if(mir_getMMI(&mmi)) return 1;
	if(mir_getUTFI(&utfi)) return 1;
	InitAssocList();
	InitDde();

	/* installation */
	InstallFile(_T("AssocMgr-Readme.txt"),_T("Docs\\"));
	InstallFile(_T("AssocMgr-License.txt"),_T("Docs\\"));
	InstallFile(_T("AssocMgr-SDK.zip"),_T("Docs\\"));
	hHookModulesLoaded=HookEvent(ME_SYSTEM_MODULESLOADED,AssocMgrModulesLoaded);
	return 0;
}

__declspec(dllexport) int Unload(void)
{
	UninitTest();
	UninitDde();
	UninitAssocList();
	UnhookEvent(hHookModulesLoaded);
	return 0;
}

#ifdef __cplusplus
}
#endif
