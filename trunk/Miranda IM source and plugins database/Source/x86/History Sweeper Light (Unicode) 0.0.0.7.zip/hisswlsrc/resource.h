#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_OPT_HISTORYSWEEPER                  101
#define IDI_ACTG                                102
#define IDI_ACT1                                103
#define IDI_ACT2                                104
#define IDI_ACTDEL                              105
#define IDC_LIST                                106
#define IDC_SSOLDER                             107
#define IDC_UNSAFEMODE                          108
#define IDC_SWEEPONCLOSE                        109
#define IDC_SSKEEP                              110
#define IDC_HISTMW                              111
#define IDC_ACT1                                112
#define IDC_ACT2                                113

