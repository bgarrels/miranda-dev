/*
 * A plugin for Miranda IM which displays web page text in a window Copyright 
 * (C) 2005 Vincent Joyce.
 * 
 * Miranda IM: the free icq client for MS Windows  Copyright (C) 2000-2
 * Richard Hughes, Roland Rabien & Tristan Van de Vreede
 * 
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free 
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc., 59 
 * Temple Place - Suite 330, Boston, MA  02111-1307, USA. 
 */

static int      searchId = -1;
static char     sID[32];

/************************/
static int      DBSettingChanged(WPARAM wParam, LPARAM lParam)
{

   DBCONTACTWRITESETTING *cws = (DBCONTACTWRITESETTING *) lParam;

   // We can't upload changes to NULL contact
   if ((HANDLE) wParam == NULL)
      return 0;

   if (!strcmp(cws->szModule, "CList"))
   {
      HANDLE          hContact;
      DBVARIANT       dbv;
      char           *szProto;
      FILE           *pcachefile;
      char            cachepath[MAX_PATH];
      //wchar_t unicachepath[MAX_PATH];    
      char            cachedirectorypath[MAX_PATH];
      //wchar_t unicachedirectorypath[MAX_PATH];    
      char            newcachepath[MAX_PATH + 50];
      char            renamedcachepath[MAX_PATH + 50];
      char           *cacheend;
      char            OLDcontactname[100];
      char            NEWcontactname[100];

      hContact = (HANDLE) wParam;
      szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
      if (szProto == NULL || strcmp(szProto, DLLNAME))
         return 0;

      // A contact is renamed
      if (!strcmp(cws->szSetting, "MyHandle"))
      {
         hContact = (HANDLE) wParam;
         szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
         if (szProto == NULL || strcmp(szProto, DLLNAME))
            return 0;
///////
         if (!DBGetContactSetting(hContact, DLLNAME, PRESERVE_NAME_KEY, &dbv))
         {
            char            nick[100];

            ZeroMemory(&OLDcontactname, sizeof(OLDcontactname));
            ZeroMemory(&NEWcontactname, sizeof(NEWcontactname));

            DBFreeVariant(&dbv);

            ZeroMemory(&nick, sizeof(nick));

            DBGetContactSetting(hContact, "CList", "MyHandle", &dbv);
            _snprintf(nick, sizeof(nick), "%s", dbv.pszVal);
            DBFreeVariant(&dbv);

            DBGetContactSetting((HANDLE) wParam, DLLNAME, PRESERVE_NAME_KEY, &dbv);
            _snprintf(OLDcontactname, sizeof(OLDcontactname), "%s", dbv.pszVal);
            DBFreeVariant(&dbv);

            if (((strchr(nick, '(')) == 0))
            {
               DBWriteContactSettingString(hContact, DLLNAME, PRESERVE_NAME_KEY, nick);
               DBWriteContactSettingString(hContact, DLLNAME, "Nick", nick);
            }
            DBGetContactSetting((HANDLE) wParam, DLLNAME, PRESERVE_NAME_KEY, &dbv);
            _snprintf(NEWcontactname, sizeof(NEWcontactname), "%s", dbv.pszVal);
            DBFreeVariant(&dbv);

//

            // TEST GET NAME FOR CACHE
           	//#if defined( _UNICODE )
            //MultiByteToWideChar(CP_ACP, 0, cachepath, (lstrlenA(cachepath)), unicachepath, (lstrlenA(cachepath)));  
            //GetModuleFileNameW(hInst, unicachepath, sizeof(unicachepath));
            //#else
            GetModuleFileName(hInst, cachepath, sizeof(cachepath));
           	//#endif
            cacheend = strrchr(cachepath, '\\');
            cacheend++;
            *cacheend = '\0';

            _snprintf(cachedirectorypath, sizeof(cachedirectorypath), "%s%s%s", cachepath, DLLNAME, "cache\\");
           //	#if defined( _UNICODE )
           	// MultiByteToWideChar(CP_ACP, 0, cachedirectorypath, (lstrlenA(cachedirectorypath)), unicachedirectorypath, (lstrlenA(cachepath)));  
            //CreateDirectoryW(unicachedirectorypath, NULL);
           // #else
            CreateDirectory(cachedirectorypath, NULL);
            //#endif
            
            
            _snprintf(newcachepath, sizeof(newcachepath), "%s%s%s%s%s", cachepath, DLLNAME, "cache\\", OLDcontactname, ".txt");
            _snprintf(renamedcachepath, sizeof(newcachepath), "%s%s%s%s%s", cachepath, DLLNAME, "cache\\", NEWcontactname, ".txt");
            
           
             
            // file exists?
            if ((_access(newcachepath, 0)) != -1)
            {
               if ((pcachefile = fopen(newcachepath, "r")) != NULL)
               {
                  fclose(pcachefile);
                  if (lstrcmp(newcachepath, renamedcachepath))
                     MoveFile(newcachepath, renamedcachepath);
               }
            }
//

         }
////////     
      }
   }
   return 0;
}
/************************/

/************************/
int             SiteDeleted(WPARAM wParam, LPARAM lParam)
{
   FILE           *pcachefile;
   char            cachepath[MAX_PATH];
   char            cachedirectorypath[MAX_PATH];
   char            newcachepath[MAX_PATH + 50];
   char           *cacheend;
   char            contactname[100];
   DBVARIANT       dbv;

   ZeroMemory(&contactname, sizeof(contactname));
   ZeroMemory(&dbv, sizeof(dbv));

   if (lstrcmp((char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, wParam, 0), DLLNAME))
      return 0;

   DBGetContactSetting((HANDLE) wParam, DLLNAME, PRESERVE_NAME_KEY, &dbv);
   _snprintf(contactname, sizeof(contactname), "%s", dbv.pszVal);
   DBFreeVariant(&dbv);

   // TEST GET NAME FOR CACHE
   GetModuleFileName(hInst, cachepath, sizeof(cachepath));
   cacheend = strrchr(cachepath, '\\');
   cacheend++;
   *cacheend = '\0';

   _snprintf(cachedirectorypath, sizeof(cachedirectorypath), "%s%s%s", cachepath, DLLNAME, "cache\\");
   CreateDirectory(cachedirectorypath, NULL);
   _snprintf(newcachepath, sizeof(newcachepath), "%s%s%s%s%s", cachepath, DLLNAME, "cache\\", contactname, ".txt");
   // file exists?
   if ((_access(newcachepath, 0)) != -1)
   {
      if ((pcachefile = fopen(newcachepath, "r")) != NULL)
      {
         fclose(pcachefile);
         DeleteFile(newcachepath);
      }
   }
   return 0;
}
/************************/

/************************/
static int      OpenCacheDir(WPARAM wParam, LPARAM lParam)
{

 
 
      char            cachepath[MAX_PATH];
      char            cachedirectorypath[MAX_PATH];
      char           *cacheend;
  

            //GET NAME FOR CACHE
            GetModuleFileName(hInst, cachepath, sizeof(cachepath));
            cacheend = strrchr(cachepath, '\\');
            cacheend++;
            *cacheend = '\0';

            _snprintf(cachedirectorypath, sizeof(cachedirectorypath), "%s%s%s%s", cachepath, DLLNAME, "cache\\", cacheend);
          
            ShellExecute(NULL, "open", cachedirectorypath, NULL, NULL, SW_SHOWNORMAL);

   return 0;
}
/************************/
/************************/
static int      PingWebsiteMenuCommand(WPARAM wParam, LPARAM lParam)
{
   DBVARIANT       dbv;
   char            url[300];
   static char    *Newnick;
   static char    *Oldnick;
   char           *Nend;
   char            Cnick[255];
  

   ZeroMemory(&Cnick, sizeof(Cnick));
   ZeroMemory(&url, sizeof(url));
   
   DBGetContactSetting((HANDLE) wParam, DLLNAME, "URL", &dbv);
    wsprintf(url, "%s", dbv.pszVal);
	DBFreeVariant(&dbv);
	
	   strncpy(Cnick, url, sizeof(Cnick));
   Oldnick = strdup(Cnick);

    /**/
      if ((strstr(Cnick, "://")) != 0)
   {
      Oldnick = strstr(Cnick, "://");
      Oldnick = Oldnick + 3;
   } else if ((strstr(Cnick, "://")) == 0)
   {
      strcpy(Oldnick, Cnick);
   }
   
      Newnick = strdup(Oldnick);
      if (strchr(Newnick, '/'))
      {
         Nend = strchr(Newnick, '/');
         *Nend = '\0';
      }
   
    //MessageBox(NULL, Newnick, DLLNAME, MB_OK);   
          
  ShellExecute(NULL, "open", "psite.bat", Newnick, NULL, SW_HIDE);
  

   return 0;
}
/************************/


/************************/
static int      StpPrcssMenuCommand(WPARAM wParam, LPARAM lParam)
{
   DBVARIANT       dbv;

  DBWriteContactSettingByte((HANDLE) wParam, DLLNAME, STOP_KEY, 1);  

   return 0;
}
/************************/



//=======================================================
// GetCaps
// =======================================================

int             GetCaps(WPARAM wParam, LPARAM lParam)
{
   int             ret = 0;

   if (wParam == PFLAGNUM_1)
      ret = PF1_BASICSEARCH | PF1_ADDSEARCHRES | PF1_VISLIST;

   if (wParam == PFLAGNUM_2)
   {
      if (!(DBGetContactSettingByte(NULL, DLLNAME, HIDE_STATUS_ICON_KEY, 0)))
         return PF2_ONLINE | PF2_SHORTAWAY | PF2_LONGAWAY | PF2_LIGHTDND | PF2_HEAVYDND; // add 
                                                                                         // the
      // possible
      // statuses here

   }
   if (wParam == PFLAG_UNIQUEIDTEXT)
      ret = (int) Translate("Site URL");

   if (wParam == PFLAGNUM_3)
      ret = 0;
      
      
      if (wParam == PFLAGNUM_5)
			ret = PF2_INVISIBLE|PF2_SHORTAWAY|PF2_LONGAWAY|PF2_LIGHTDND|PF2_HEAVYDND|PF2_FREECHAT|
				PF2_OUTTOLUNCH|PF2_ONTHEPHONE;
				
   if (wParam == PFLAG_UNIQUEIDSETTING)
      ret = (int) "PreserveName";

   return ret;
}

//=======================================================
// =======================================================
// GetName
// =======================================================
int             GetName(WPARAM wParam, LPARAM lParam)
{
   lstrcpyn((char *) lParam, DLLNAME, wParam);
   return 0;
}
//=======================================================
// SetStatus
// =======================================================
int             SetStatus(WPARAM wParam, LPARAM lParam)
{
   int             oldStatus;
   DBVARIANT       dbv;

   oldStatus = bpStatus;
   char           *szProto;
   HANDLE          hContact = (HANDLE) CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);

   if (wParam == ID_STATUS_ONLINE)
   {
      wParam = ID_STATUS_ONLINE;
   } else if (wParam == ID_STATUS_OFFLINE)
   {
      wParam = ID_STATUS_OFFLINE;
   } else
   {
      wParam = ID_STATUS_ONLINE;
   }
   // broadcast the message
   bpStatus = wParam;

   ProtoBroadcastAck(DLLNAME, NULL, ACKTYPE_STATUS, ACKRESULT_SUCCESS, (HANDLE) oldStatus, wParam);

    /**/
   // Make sure no contact has offline status for any reason on first time
   // run     
      if (DBGetContactSetting(NULL, DLLNAME, "FirstTime", &dbv))
   {
      while (hContact)
      {
         szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
         if (szProto != NULL && !lstrcmp(DLLNAME, szProto))
         {
            DBWriteContactSettingWord(hContact, DLLNAME, "Status", ID_STATUS_ONLINE);
         }
         hContact = (HANDLE) CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM) hContact, 0);
      }
      if (DBGetContactSetting(NULL, DLLNAME, "FirstTime", &dbv))
         DBWriteContactSettingByte(NULL, DLLNAME, "FirstTime", 1);
   }
   DBFreeVariant(&dbv);
    /**/

      if (bpStatus == ID_STATUS_OFFLINE)
      DBWriteContactSettingByte(NULL, DLLNAME, OFFLINE_STATUS, 1);
   else
      DBWriteContactSettingByte(NULL, DLLNAME, OFFLINE_STATUS, 0);

   return 0;
}
//=======================================================
// GetStatus
// =======================================================

int             GetStatus(WPARAM wParam, LPARAM lParam)
{

   if (bpStatus == ID_STATUS_ONLINE)
      return ID_STATUS_ONLINE;
   else if (bpStatus == ID_STATUS_AWAY)
      return ID_STATUS_AWAY;
   else if (bpStatus == ID_STATUS_NA)
      return ID_STATUS_NA;
   else if (bpStatus == ID_STATUS_OCCUPIED)
      return ID_STATUS_OCCUPIED;
   else if (bpStatus == ID_STATUS_DND)
      return ID_STATUS_DND;
   else
      return ID_STATUS_OFFLINE;

}

//=======================================================
// BPLoadIcon
// =======================================================

int             BPLoadIcon(WPARAM wParam, LPARAM lParam)
{
   UINT            id;

   switch (wParam & 0xFFFF)
   {
   case PLI_PROTOCOL:
      id = IDI_SITE;
      break;
   default:
      return (int) (HICON) NULL;
   }
   return (int) LoadImage(hInst, MAKEINTRESOURCE(id), IMAGE_ICON, GetSystemMetrics(wParam & PLIF_SMALL ? SM_CXSMICON : SM_CXICON), GetSystemMetrics(wParam & PLIF_SMALL ? SM_CYSMICON : SM_CYICON), 0);
}

/*******************/
static void __cdecl BasicSearchTimerProc(void *pszNick)
{
   PROTOSEARCHRESULT psr;

   ZeroMemory(&psr, sizeof(psr));
   psr.cbSize = sizeof(psr);
   psr.nick = (char *) pszNick;
   // 

   // broadcast the search result
   ProtoBroadcastAck(DLLNAME, NULL, ACKTYPE_SEARCH, ACKRESULT_DATA, (HANDLE) 1, (LPARAM) & psr);
   ProtoBroadcastAck(DLLNAME, NULL, ACKTYPE_SEARCH, ACKRESULT_SUCCESS, (HANDLE) 1, 0);

   // exit the search
   searchId = -1;
}

/*******************/

/*******************/
int             BasicSearch(WPARAM wParam, LPARAM lParam)
{
   static char     buf[300];

   if (lParam)
      lstrcpyn(buf, (const char *) lParam, 256);
   // 

   if (searchId != -1)
      return 0; // only one search at a time

   lstrcpyn(sID, (char *) lParam, sizeof(sID));
   searchId = 1;
   // create a thread for the ID search
   forkthread(BasicSearchTimerProc, 0, &buf);

   return searchId;
}
/*******************/

/*******************/
int             AddToList(WPARAM wParam, LPARAM lParam)
{
   PROTOSEARCHRESULT *psr = (PROTOSEARCHRESULT *) lParam;
   DBVARIANT       dbv;
   static char    *Newnick;
   static char    *Oldnick;
   char           *Nend;
   char            Cnick[255];
   int             sameurl = 0;

   ZeroMemory(&Cnick, sizeof(Cnick));

   // search for existing contact
   HANDLE          hContact = (HANDLE) CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
   char           *szProto;

   while (hContact != NULL)
   {
      szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
      // check if it is a webview contact
      if (szProto != NULL && !lstrcmp(DLLNAME, szProto))
      {
         // check ID to see if the contact already exist in the database

         if (!DBGetContactSetting(hContact, DLLNAME, "URL", &dbv))
         {
            if (!lstrcmpi(psr->nick, dbv.pszVal))
            {
               // remove the flag for not on list and hidden, thus make the
               // contact visible
               // and add them on the list
               sameurl++;
               if (DBGetContactSettingByte(hContact, "CList", "NotOnList", 1))
               {
                  DBDeleteContactSetting(hContact, "CList", "NotOnList");
                  DBDeleteContactSetting(hContact, "CList", "Hidden");
               }
               DBFreeVariant(&dbv);
            }
         }
         DBFreeVariant(&dbv);

      }
      hContact = (HANDLE) CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM) hContact, 0);
   }

   // if contact with the same ID was not found, add it
   if (psr->cbSize != sizeof(PROTOSEARCHRESULT))
      return (int) (HANDLE) NULL;
   hContact = (HANDLE) CallService(MS_DB_CONTACT_ADD, 0, 0);
   CallService(MS_PROTO_ADDTOCONTACT, (WPARAM) hContact, (LPARAM) DLLNAME);

/////////write to db
   DBWriteContactSettingByte(hContact, DLLNAME, ON_TOP_KEY, 0);
   DBWriteContactSettingByte(hContact, DLLNAME, DBLE_WIN_KEY, 1);
   DBWriteContactSettingString(hContact, DLLNAME, END_STRING_KEY, "");
   DBWriteContactSettingByte(hContact, DLLNAME, RWSPACE_KEY, 1);

//Convert url into a name for contact
   strncpy(Cnick, psr->nick, sizeof(Cnick));
   Oldnick = strdup(Cnick);

    /**/
      if ((strstr(Cnick, "://")) != 0)
   {
      Oldnick = strstr(Cnick, "://");
      Oldnick = Oldnick + 3;
   } else if ((strstr(Cnick, "://")) == 0)
   {
      strcpy(Oldnick, Cnick);
   }
   if ((strstr(Oldnick, "www.")) != 0)
   {
      Newnick = strstr(Oldnick, "www.");
      Newnick = Newnick + 4;
      Nend = strchr(Newnick, '.');
      *Nend = '\0';
   } else if ((strstr(Oldnick, "WWW.")) != 0)
   {
      Newnick = strstr(Oldnick, "WWW.");
      Newnick = Newnick + 4;
      Nend = strchr(Newnick, '.');
      *Nend = '\0';
   } else
   {
      Newnick = strdup(Oldnick);
      if (strchr(Newnick, '.'))
      {
         Nend = strchr(Newnick, '.');
         *Nend = '\0';
      }
   }
   if (sameurl > 0) // contact has the same url as another contact, add rand
                    // num to name

   {
      int             ranNum;
      char            ranStr[7];

      srand((unsigned) time(NULL));

      ranNum = (int) 10000 *rand() / (RAND_MAX + 1.0);

      _snprintf(ranStr, sizeof(ranStr), "%d", ranNum);
      strcat(Newnick, ranStr);
   }
//end convert

   DBWriteContactSettingString(hContact, "CList", "MyHandle", Newnick);
   DBWriteContactSettingString(hContact, DLLNAME, PRESERVE_NAME_KEY, Newnick);
   DBWriteContactSettingString(hContact, DLLNAME, "Nick", Newnick);
   DBWriteContactSettingByte(hContact, DLLNAME, CLEAR_DISPLAY_KEY, 1);
   DBWriteContactSettingString(hContact, DLLNAME, START_STRING_KEY, "");
   DBWriteContactSettingString(hContact, DLLNAME, URL_KEY, psr->nick);
   DBWriteContactSettingString(hContact, DLLNAME, "Homepage", psr->nick);
   DBWriteContactSettingByte(hContact, DLLNAME, U_ALLSITE_KEY, 1);
   DBWriteContactSettingWord(hContact, DLLNAME, "Status", ID_STATUS_ONLINE);
////////////////////////

   // ignore status change
   DBWriteContactSettingDword(hContact, "Ignore", "Mask", 8);

   Sleep(2);

   DBFreeVariant(&dbv);
   return (int) hContact;
}
/*******************/

/*******************/
int             GetInfo(WPARAM wParam, LPARAM lParam)
{
   forkthread(AckFunc, 0, NULL);
   return 1;
}
/*******************/
/*******************/
void            AckFunc(void *dummy)
{
   HANDLE          hContact = (HANDLE) CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
   char           *szProto;

   while (hContact != NULL)
   {
      szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
      // 
      if (szProto != NULL && !lstrcmp(DLLNAME, szProto))
         ProtoBroadcastAck(DLLNAME, hContact, ACKTYPE_GETINFO, ACKRESULT_SUCCESS, (HANDLE) 1, 0);
      // 
      hContact = (HANDLE) CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM) hContact, 0);
   }

}
/*******************/
