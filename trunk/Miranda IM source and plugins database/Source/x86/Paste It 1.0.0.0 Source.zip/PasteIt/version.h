#define __FILEVERSION_STRING        1,0,0,0
#define __VERSION_STRING            "1.0.0.0"
#define __VERSION_DWORD             PLUGIN_MAKE_VERSION(1, 0, 0, 0)

