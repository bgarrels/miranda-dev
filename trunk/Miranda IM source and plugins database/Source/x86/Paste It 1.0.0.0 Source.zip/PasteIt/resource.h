
#define IDD_OPT_MAIN                    101
#define IDD_DLG_FROM_CLIPBOARD          102
#define IDD_DLG_FROM_FILE               103
#define IDD_OPT_PAGES                   104
#define IDD_DLG_CONFIGURE               105
#define IDD_DLG_PASTEBIN_LOGIN          106
#define IDC_WEBLIST                     1001
#define IDC_CONFDLG                     1002
#define IDC_AUTOSEND                    1003
#define IDC_CODEPAGE                    1004
#define IDC_AUTOUTF                     1005
#define IDC_CLIPBOARD_DATA              1006
#define IDC_BTN_OK                      1007
#define IDC_FILE_DATA                   1008
#define IDC_FILE_PATH                   1009
#define IDC_RECODE                      1010
#define IDC_WEBPAGE                     1011
#define IDC_DEFFORMAT                   1012
#define IDC_AUTOFORMAT                  1013
#define IDC_CONFIGURE                   1014
#define IDC_FORMATTING                  1015
#define IDC_RESTORE                     1016
#define IDC_DOWNLOAD                    1017
#define IDC_DELETE                      1018
#define IDC_UP                          1019
#define IDC_DOWN                        1020
#define IDC_FORMAT                      1021
#define IDC_FORMATTEXT                  1022
#define IDC_PUBLICPASTE                 1023
#define IDC_COMBO1                      1024
#define IDC_COMBO1_DESC                 1025
#define IDC_GUEST                       1026
#define IDC_PASTEBIN_KEY                1027
#define IDC_PASTEBIN_KEY_DESC           1028
#define IDC_PASTEBIN_LOGIN              1029
#define IDC_PASTEBIN_USER               1031
#define IDC_PASTEBIN_PASSWORD           1032
#define IDI_MENU                        20000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
