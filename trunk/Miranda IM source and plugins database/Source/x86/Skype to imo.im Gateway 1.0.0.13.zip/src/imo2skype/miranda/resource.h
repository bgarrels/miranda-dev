//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res.rc
//
#define IDD_OPTIONS                     101
#define IDC_BINDPORT                    1001
#define IDC_BINDIP                      1002
#define IDC_INTERACT                    1003
#define IDC_CURRTIMESTAMP               1004
#define IDC_LOG                         1005
#define IDC_LOGFILE                     1006
#define IDC_OPEN                        1007
#define IDC_USERNAME                    1008
#define IDC_PASSWORD                    1009
#define IDC_STATUS                      1010
#define IDC_RESTART                     1011
#define IDC_CONSOLE                     1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
