#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>
#else
#include <pthread.h>
#define SOCKET int
#define __cdecl
#endif
#include "imo2skypeapi.h"

#ifdef WIN32
#define mutex_t CRITICAL_SECTION
#else
#define mutex_t pthread_mutex_t
#endif

typedef struct
{
	char *pszAuthPass;
	int bVerbose;
	FILE *fpLog;
	int iFlags;

	unsigned long int lAddr;
	short sPort;
	int iMaxConn;

// FIXME: user+pass from cmdline, until there is a possibility for 
// a client to authenticate
	char *pszUser;
	char *pszPass;

	int (__cdecl *logerror)( FILE *stream, const char *format, ...);
	SOCKET listen_fd;
	volatile int iRunning;
	mutex_t loopmutex;
} IMO2SPROXY;


void Imo2sproxy_Init(IMO2SPROXY *hProxy);
int Imo2sproxy_Open(IMO2SPROXY *hProxy);
void Imo2sproxy_Loop(IMO2SPROXY *hProxy);
void Imo2sproxy_Exit(IMO2SPROXY *hProxy);
