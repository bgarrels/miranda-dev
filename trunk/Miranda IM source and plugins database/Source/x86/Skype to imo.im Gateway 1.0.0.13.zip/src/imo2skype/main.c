/* Module:  main.c
   Purpose: Main commandline dispatcher for imo.im Skypeproxy
   Author:  leecher
   Date:    07.11.2009
*/
#include <stdlib.h>
#include <stdio.h>
#include "imo2sproxy.h"
#ifdef WIN32
#define Daemonize FreeConsole()
#ifdef _DEBUG
#define LOG(_args_) printf _args_
#include "crash.c"
#endif
#else
#define Daemonize daemon(0, 0)
#endif

// -----------------------------------------------------------------------------
// EIP
// -----------------------------------------------------------------------------
int main(int argc, char **argv)
{
	int i, j=0, bDaemon = 0;
	IMO2SPROXY stCfg={0};

#ifdef _DEBUG
	Crash_Init();
#endif

	Imo2sproxy_Init (&stCfg);
	if (argc<3)
	{
		printf ("imo.im Skypeproxy V1.11 - (c) by leecher 2009-2010\n\n"
			"%s [-d] [-v [-l <Logfile>]] [-t] [-i][-h <Bind to IP>] [-p <Port>] <Username> <Password>\n\n"
			"-v\t- Verbose mode, log commands to console\n"
			"-l\t- Set logfile to redirect verbose log to.\n"
			"-d\t- Daemonize (detach from console)\n"
			"-i\t- Use interactive mode (starts imo.im flash app upon call)\n"
			"-t\t- Ignore server timestamp and use current time for messages\n"
			"-h\t- Bind to a specific IP, not to all interfaces (default)\n"
			"-p\t- Bind to another port (default: 1401)\n"
			"Default: Bind to any interface, Use Port %d\n", argv[0], stCfg.sPort);
		return EXIT_FAILURE;
	}

	for (i=1; i<argc; i++)
	{
		if (argv[i][0] == '-')
		{
			switch (argv[i][1])
			{
			case 'v':
				stCfg.bVerbose = 1;
				break;
			case 'l':
				if (argc<=i+1)
				{
					fprintf (stderr, "Please specify logfile for -l\n");
					return  EXIT_FAILURE;
				}
				if (!(stCfg.fpLog = fopen(argv[++i], "a")))
				{
					fprintf (stderr, "Cannot open logfile %s\n", argv[i]);
					return EXIT_FAILURE;
				}
				break;
			case 'd':
				bDaemon = 1;
				break;
			case 'h':
				if (argc<=i+1)
				{
					fprintf (stderr, "Please specify bind IP for -h\n");
					return  EXIT_FAILURE;
				}
				stCfg.lAddr = inet_addr(argv[++i]);
				break;
			case 'p':
				if (argc<=i+1)
				{
					fprintf (stderr, "Please specify port for -p\n");
					return EXIT_FAILURE;
				}
				stCfg.sPort = atoi(argv[++i]);
				break;
			case 't':
				stCfg.iFlags |= IMO2S_FLAG_CURRTIMESTAMP;
				break;
			case 'i':
				stCfg.iFlags |= IMO2S_FLAG_ALLOWINTERACT;
				break;
			default:
				printf ("Unknown parameter: %s\n", argv[i]);
				break;
			}
		}
		else
		{
			switch (j)
			{
			case 0: stCfg.pszUser = argv[i]; break;
			case 1: stCfg.pszPass = argv[i]; break;
			default: printf ("Unknown extra arg: %s\n", argv[i]); break;
			}
			j++;
		}
	}

	if (!stCfg.pszUser)
	{
		printf ("Please specify Username\n");
		return EXIT_FAILURE;
	}
	if (!stCfg.pszPass)
	{
		printf ("Please specify Password\n");
		return EXIT_FAILURE;
	}
	if (bDaemon && stCfg.bVerbose && stCfg.fpLog == stdout)
	{
		printf ("Parameters Verbose mode and daemonize cannot be used together, if you don't\n"
			"specify a logfile, not daemonizing.\n");
		bDaemon = 0;
	}
	if (bDaemon) Daemonize;

	if (Imo2sproxy_Open(&stCfg) == 0)
	{
		Imo2sproxy_Loop(&stCfg);
		Imo2sproxy_Exit(&stCfg);
	}

	return EXIT_SUCCESS;
}

