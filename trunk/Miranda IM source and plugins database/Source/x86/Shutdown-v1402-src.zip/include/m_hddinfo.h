#define MS_SYSINFO_HDDTEMP			"SysInfo/HddTemp"
		// checks current hdd temperature
#define MS_SYSINFO_CUSTPOP			"SysInfo/CustomPopup"
		//shows special custom popup
#define ME_SYSINFO_HDDOVERHEAT		"SysInfo/HddOverheat"
	// happens if one ot the drives has current temperature higher than set as normal
