/*
Weather Protocol plugin for Miranda IM
Copyright (C) 2002-2004 Calvin Che

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef M_WEATHER_H__
#define M_WEATHER_H__ 1

// weather conditions
#define SUNNY			ID_STATUS_ONLINE
#define NA				ID_STATUS_OFFLINE
#define PCLOUDY			ID_STATUS_AWAY
#define CLOUDY			ID_STATUS_NA
#define RAIN			ID_STATUS_OCCUPIED
#define RSHOWER			ID_STATUS_DND
#define SNOW			ID_STATUS_FREECHAT
#define LIGHT			ID_STATUS_INVISIBLE
#define THUNDER			ID_STATUS_INVISIBLE
#define SSHOWER			ID_STATUS_ONTHEPHONE
#define FOG				ID_STATUS_OUTTOLUNCH

// ===============  WEATHER SERVICES  ================

// Enable or disable weather protocol.
// WPARAM = FALSE to toggle, TRUE to use the LPARAM
// LPARAM = TRUE to enable, FALSE to disable
#define MS_WEATHER_ENABLED		"Weather/EnableDisable"

// Update all weather info
// WPARAM = LPARAM = NULL
#define MS_WEATHER_UPDATEALL	"Weather/UpdateAll"

// Update all weather info + erase the old ones
// WPARAM = LPARAM = NULL
#define MS_WEATHER_REFRESHALL	"Weather/RefreshAll"

// Open the find/add dialog with weather as the selected protocol
// WPARAM = LPARAM = NULL
#define MS_WEATHER_ADD			"Weather/Add"

// Reload all the ini files into memory
// WPARAM = LPARAM = NULL
#define MS_WEATHER_INI_RELOAD	"Weather/Reload"

// View a message box with all the weather info
// WPARAM = LPARAM = NULL
#define MS_WEATHER_INI_INFO		"Weather/INIInfo"

// Below are the service functions for weather contacts
// The plugin does NOT verify that they are used in weather contact,
// so bad call on these function may cause crashes.

// Update a single station
// WPARAM = (HANDLE)hContact
// LPARAM = NULL
#define MS_WEATHER_UPDATE		"Weather/Update"

// Update a single station + delete old settings
// WPARAM = (HANDLE)hContact
// LPARAM = NULL
#define MS_WEATHER_REFRESH		"Weather/Refresh"

// View the brief info of a contact
// WPARAM = (HANDLE)hContact
// LPARAM = NULL
#define MS_WEATHER_BRIEF		"Weather/Brief"

// Use default browser to open the complete forecast on web
// WPARAM = (HANDLE)hContact
// LPARAM = NULL
#define MS_WEATHER_COMPLETE		"Weather/CompleteForecast"

// Use default browser to open the weather map defined for the contact
// WPARAM = (HANDLE)hContact
// LPARAM = NULL
#define MS_WEATHER_MAP			"Weather/Map"

// Open the external log of the weather contact
// WPARAM = (HANDLE)hContact
// LPARAM = NULL
#define MS_WEATHER_LOG			"Weather/Log"

// Edit weather contact setting
// WPARAM = (HANDLE)hContact
// LPARAM = NULL
#define MS_WEATHER_EDIT			"Weather/Edit"

// ===============  WEATHER EVENTS  ================

/*
HANDLE hContact = (HANDLE)wParam;
BOOL Condition_Changed = (BOOL)lParam;

hContact is the handle of updated contact
If the weather condition is differ from the last update (either temperature/condition,
or the last update time, depend what the user choose in the options), then
Condition_Changed is true; otherwise is false.
*/
#define ME_WEATHER_UPDATED	"Miranda/Weather/Updated"

/*
Shows a warning message for Weather PopUp.
wParam = (char*) lpzMessage
lParam = Type
Type can either be SM_WARNING, SM_NOTIFY, or SM_WEATHERALERT

This event is used to avoid the error popup to occurs within a thread, so the "Use
multiply thread" fuction don't have to be enabled for weather popups to work.
*/
#define SM_WEATHERALERT		16
#define ME_WEATHER_ERROR	"Miranda/Weather/Error"


#endif //M_WEATHER_H__
