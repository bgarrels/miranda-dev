//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDI_ACTIVE                      101
#define IDI_INACTIVE                    102
#define IDI_HEADER                      103
#define IDD_SETTINGS                    104
#define IDD_SHUTDOWNNOW                 105
#define IDD_OPT_SHUTDOWN                106
#define IDC_ICON_HEADER                 1001
#define IDC_TEXT_HEADER                 1002
#define IDC_TEXT_HEADERDESC             1003
#define IDC_RECT_HEADER                 1004
#define IDC_RADIO_STTIME                1005
#define IDC_RADIO_STCOUNTDOWN           1006
#define IDC_CHECK_SPECIFICTIME          1007
#define IDC_TIME_TIMESTAMP              1008
#define IDC_DATE_TIMESTAMP              1009
#define IDC_EDIT_COUNTDOWN              1010
#define IDC_SPIN_COUNTDOWN              1011
#define IDC_COMBO_COUNTDOWNUNIT         1012
#define IDC_COMBO_SHUTDOWNTYPE          1013
#define IDC_TEXT_SHUTDOWNTYPE           1014
#define IDC_TEXT_SECONDS                1015
#define IDC_CHECK_FILETRANSFER          1016
#define IDC_CHECK_IDLE                  1017
#define IDC_URL_IDLE                    1018
#define IDC_CHECK_MESSAGE               1019
#define IDC_EDIT_MESSAGE                1020
#define IDC_CHECK_STATUS                1021
#define IDC_CHECK_CPUUSAGE              1022
#define IDC_TEXT_CURRENTCPU             1023
#define IDC_EDIT_CPUUSAGE               1024
#define IDC_SPIN_CPUUSAGE               1025
#define IDC_TEXT_PERCENT                1026
#define IDC_BUTTON_SHUTDOWNNOW          1027
#define IDC_TEXT_UNSAVEDWARNING         1028
#define IDC_CHECK_SHOWCONFIRMDLG        1029
#define IDC_TEXT_COUNTDOWNSTARTS        1030
#define IDC_EDIT_CONFIRMDLGCOUNTDOWN    1031
#define IDC_SPIN_CONFIRMDLGCOUNTDOWN    1032
#define IDC_CHECK_REMEMBERONRESTART     1033
#define IDC_CHECK_SMARTOFFLINECHECK     1034
#define IDC_CHECK_WEATHER               1035
#define IDC_CHECK_HDDOVERHEAT           1036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           2001
#endif
#endif
