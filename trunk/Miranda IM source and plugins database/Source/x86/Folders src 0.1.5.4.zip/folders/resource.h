//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by folders.rc
//
#define IDD_OPT_FOLDERS                 101
#define IDD_VARIABLES_HELP              102
#define IDC_FOLDERS_ITEMS_LIST          1002
#define IDC_FOLDERS_GROUPBOX            1003
#define IDC_EDIT_FOLDER_GROUPBOX        1004
#define IDC_FOLDER_EDIT                 1005
#define IDC_REFRESH_BUTTON              1008
#define IDC_PREVIEW_GROUPBOX            1009
#define IDC_PREVIEW_EDIT                1010
#define IDC_HELP_BUTTON                 1011
#define IDC_HELP_RICHEDIT               1012
#define IDC_FOLDERS_SECTIONS_LIST       1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
