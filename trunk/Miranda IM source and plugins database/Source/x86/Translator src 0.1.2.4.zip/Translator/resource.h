//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Translator.rc
//
#define IDD_DLG_OPT                     101
#define IDD_OPT_TRANSLATOR              101
#define IDD_TRANSLATIONS                102
#define IDD_EXPORT                      103
#define IDI_TRANSLATOR                  105
#define IDC_FLUSHAMOUNT                 1002
#define IDC_COMBO2                      1003
#define IDC_FILTER_MODE                 1003
#define IDC_FLUSH                       1004
#define IDC_STATISTICS                  1005
#define IDC_TRANSLATION_MODE            1006
#define IDC_LIST_TRANSLATIONS           1007
#define IDC_CANCEL                      1009
#define IDC_SAVE                        1010
#define IDC_ENGLISH                     1011
#define IDC_TRANSLATION                 1012
#define IDC_TRANSLATION_OLD             1012
#define IDC_EXPORT                      1014
#define IDC_TRANSLATIONS                1015
#define IDC_LABEL_ENGLISH               1016
#define IDC_LABEL_TRANSLATION           1017
#define IDC_AUTOSAVE                    1018
#define IDC_FLUSHONEXIT                 1020
#define IDC_LANGUAGE                    1021
#define IDC_LOCALE                      1022
#define IDC_AUTHORS                     1023
#define IDC_EMAILS                      1024
#define IDC_PLUGINSINCLUDED             1025
#define IDC_FLID                        1026
#define IDC_COMMENTS                    1029
#define IDC_OUTPUT                      1030
#define IDC_BUTTON3                     1031
#define IDC_BROWSE                      1031
#define IDC_RESET                       1032
#define IDC_OVERRIDE_CODEPAGE           1033
#define IDC_EDIT1                       1034
#define IDC_CODEPAGE                    1034
#define IDC_CUSTOM_CODEPAGE             1034
#define IDC_TRANSLATIONS_GROUPBOX       1035
#define IDC_NORMAL_GROUPBOX             1036
#define IDC_DYNAMIC_TRANSLATION         1037
#define IDC_IGNORE_DOUBLE_TRANSLATIOSN  1038
#define IDC_IGNORE_DOUBLE_TRANSLATIONS  1038
#define IDC_RICHEDIT21                  1039
#define IDC_LANGUAGEPACK_IGNOREUNTRANSLATED 1040
#define IDC_FILTER_EDIT                 1044
#define IDC_AUTOMATIC_FILTER            1045
#define IDC_FILTER_TIMEOUT              1046
#define IDC_BUTTON1                     1047
#define IDC_FILTER                      1047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
