//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by stopspam.rc
//
#define IDD_MESSAGES                    101
#define IDD_MAIN                        103
#define ID_DESCRIPTION                  1001
#define ID_QUESTION                     1002
#define ID_ANSWER                       1003
#define ID_CONGRATULATION               1004
#define ID_RESTOREDEFAULTS              1005
#define ID_ADD                          1005
#define ID_ANSWER2                      1007
#define ID_AUTHREPL                     1007
#define ID_ALLPROTO                     1008
#define IDD_PROTO                       1008
#define ID_MAXQUESTCOUNT                1008
#define ID_REMOVE                       1009
#define ID_SPECIALGROUPNAME             1009
#define IDD_ADVANCED                    1009
#define ID_USEDPROTO                    1010
#define ID_REMOVEALL                    1011
#define ID_ADDALL                       1012
#define ID_INFTALKPROT                  1013
#define ID_ADDPERMANENT                 1014
#define ID_ADDPERMANENT2                1015
#define ID_HANDLEAUTHREQ                1015
#define ID_DOS_INTEGRATION              1016
#define ID_SPECIALGROUP                 1017
#define IDC_BUTTON1                     1017
#define IDC_VARS                        1017
#define ID_HIDECONTACTS                 1018
#define IDC_CASE_INSENSITIVE            1018
#define ID_IGNORESPAMMERS               1019
#define IDC_CHECK2                      1019
#define IDC_INVIS_DISABLE               1019
#define ID_REMOVE_TMP                   1020
#define IDC_CUSTOM1                     1020
#define ID_REMOVE_TMP2                  1021
#define ID_EXCLUDE                      1021
#define ID_ADDPERMANENT3                1022
#define ID_DEL_NO_IN_LIST               1022
#define IDC_ADDTOSRVLST                 1022
#define ID_IGNOREURL                    1023
#define IDC_EDIT1                       1024
#define IDC_AUTOADDGROUP                1024
#define IDC_AUTOAUTH                    1025
#define IDC_REQAUTH                     1026
#define IDC_LOGSPAMTOFILE               1027
#define ID_REMOVE_TMP_ALL               1027
#define ID_LOGSPAMTOFILE                1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
