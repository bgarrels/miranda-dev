#include "headers.h"


MIRANDA_HOOK_EVENT(ME_DB_CONTACT_ADDED, w, l)
{
	return 0;
}


MIRANDA_HOOK_EVENT(ME_DB_EVENT_ADDED, wParam, lParam)
{
	HANDLE hContact = (HANDLE)wParam;
	HANDLE hDbEvent = (HANDLE)lParam;

	DBEVENTINFO dbei = {0};
	dbei.cbSize = sizeof(dbei);
	dbei.cbBlob = CallService(MS_DB_EVENT_GETBLOBSIZE, (WPARAM)hDbEvent, 0);
	if(-1 == dbei.cbBlob) 
		return 0;
	
	dbei.pBlob = new BYTE[dbei.cbBlob];
	CallService(MS_DB_EVENT_GET, lParam, (LPARAM)&dbei);

	// if event is in protocol that is not despammed
	if(!ProtoInList(dbei.szModule)) {
		delete dbei.pBlob;
		return 0;
	}

	// event is an auth request
	if(gbHandleAuthReq)
	{
		if(!(dbei.flags & DBEF_SENT) && !(dbei.flags & DBEF_READ) && dbei.eventType == EVENTTYPE_AUTHREQUEST)
		{
			HANDLE hcntct;
			hcntct=*((PHANDLE)(dbei.pBlob+sizeof(DWORD)));

			// if request is from unknown or not marked Answered contact
			int a = DBGetContactSettingByte(hcntct, "CList", "NotOnList", 0);
			int b = !DBGetContactSettingByte(hcntct, pluginName, "Answered", 0);
			
			if(a && b)// 
			{
				// ...send message

				if(gbHideContacts)
					DBWriteContactSettingByte(hcntct, "CList", "Hidden", 1);
				if(gbSpecialGroup)
					DBWriteContactSettingTString(hcntct, "CList", "Group", gbSpammersGroup.c_str());
				BYTE msg = 1;
				if(gbIgnoreURL){
					TCHAR* EventText = ReqGetText(&dbei); //else return NULL
					msg=!IsUrlContains(EventText);
					mir_free(EventText);
				};
				if(gbInvisDisable)
				{
					if(CallProtoService(dbei.szModule, PS_GETSTATUS, 0, 0) == ID_STATUS_INVISIBLE)
						msg = 0;
					else if(DBGetContactSettingWord(hContact,dbei.szModule,"ApparentMode",0) == ID_STATUS_OFFLINE)
						msg = 0; //is it useful ? 
				}
				if(msg)
				{
#ifdef _UNICODE
					char * buff=mir_utf8encodeW(variables_parse(gbAuthRepl, hcntct).c_str());
					CallContactService(hcntct, PSS_MESSAGE, PREF_UTF, (LPARAM) buff);
					mir_free(buff);
#else
					CallContactService(hcntct, PSS_MESSAGE, 0, (LPARAM) variables_parse(gbAuthRepl, hcntct).c_str());
#endif

				};
				delete dbei.pBlob;
				return 1;
			}
		}
	}
	delete dbei.pBlob;
	return 0;
}

MIRANDA_HOOK_EVENT(ME_DB_EVENT_FILTER_ADD, w, l)
{
	HANDLE hContact = (HANDLE)w;
	if(!l) //fix potential DEP crash
		return 0;
	DBEVENTINFO * dbei = (DBEVENTINFO*)l;
	
	// if event is in protocol that is not despammed
	if(!ProtoInList(dbei->szModule))
	{
		// ...let the event go its way
		return 0;
	}
	//do not check excluded contact

	if(DBGetContactSettingByte(hContact, pluginName, "Answered", 0))
		return 0;
	if(DBGetContactSettingByte(hContact, pluginName, "Excluded", 0))
	{
		if(!DBGetContactSettingByte(hContact, "CList", "NotOnList", 0))
			DBDeleteContactSetting(hContact, pluginName, "Excluded");
		return 0;
	}
	//we want block not only messages, i seen many types other eventtype flood
	if(dbei->flags & DBEF_READ)
		// ...let the event go its way
		return 0;
	//mark contact which we trying to contact for exclude from check
	if((dbei->flags & DBEF_SENT) && DBGetContactSettingByte(hContact, "CList", "NotOnList", 0)
		&& (!gbMaxQuestCount || DBGetContactSettingDword(hContact, pluginName, "QuestionCount", 0) < gbMaxQuestCount) && gbExclude)
	{
		DBWriteContactSettingByte(hContact, pluginName, "Excluded", 1);
		return 0;
	}
	// if message is from known or marked Answered contact
	if(!DBGetContactSettingByte(hContact, "CList", "NotOnList", 0))
		// ...let the event go its way
		return 0;
	// if message is corrupted or empty it cannot be an answer.
	if(!dbei->cbBlob || !dbei->pBlob)
		// reject processing of the event
		return 1;

	tstring message;
	
	if(dbei->flags & DBEF_UTF){
		WCHAR* msg_u;
		char* msg_a = mir_strdup(( char* )dbei->pBlob );
		mir_utf8decode( msg_a, &msg_u );
#ifdef _UNICODE
		message = msg_u;
#else
		message = mir_u2a(msg_u);
#endif
	}
	else{
#ifdef _UNICODE
		message = mir_a2u((char*)(dbei->pBlob));
#else
		message = (char*)(dbei->pBlob);
#endif
	}

	// if message contains right answer...
	
	BYTE msg = 1;
	if(gbInvisDisable)
	{
		if(CallProtoService(dbei->szModule, PS_GETSTATUS, 0, 0) == ID_STATUS_INVISIBLE)
			msg = 0;
		else if(DBGetContactSettingWord(hContact,dbei->szModule,"ApparentMode",0) == ID_STATUS_OFFLINE)
			msg = 0; //is it useful ?
	}

	if(gbCaseInsensitive?(!Stricmp(message.c_str(), (variables_parse(gbAnswer, hContact).c_str()))):( !_tcscmp(message.c_str(), (variables_parse(gbAnswer, hContact).c_str()))))
	{
		// unhide contact
		DBDeleteContactSetting(hContact, "CList", "Hidden");

		// mark contact as Answered
		DBWriteContactSettingByte(hContact, pluginName, "Answered", 1);

		//add contact permanently
		if(gbAddPermanent) //do not use this )
			DBDeleteContactSetting(hContact, "CList", "NotOnList");

		// send congratulation
		if(msg)
		{
			tstring prot=DBGetContactSettingStringPAN(NULL,dbei->szModule,"AM_BaseProto", _T(""));
			// for notICQ protocols or disable auto auth. reqwest
			if((Stricmp(_T("ICQ"),prot.c_str()))||(!gbAutoReqAuth))
			{
#ifdef _UNICODE
				char * buf=mir_utf8encodeW(variables_parse(gbCongratulation, hContact).c_str());
				CallContactService(hContact, PSS_MESSAGE, PREF_UTF, (LPARAM)buf);
				mir_free(buf);
#else
				CallContactService(hContact, PSS_MESSAGE, 0, (LPARAM)GetCongratulation().c_str());
#endif
			};
			// Note: For ANSI can be not work
			if(!Stricmp(_T("ICQ"),prot.c_str())){
				// grand auth.
				if(gbAutoAuth)
						CallProtoService(dbei->szModule, "/GrantAuth", w, 0);
					// add contact to server list and local group
				if(gbAutoAddToServerList)
				{
					DBWriteContactSettingTString(hContact, "CList", "Group", gbAutoAuthGroup.c_str());
					CallProtoService(dbei->szModule, "/AddServerContact", w, 0);
					DBDeleteContactSetting(hContact, "CList", "NotOnList");
				};
				// auto auth. reqwest with send congratulation
				if(gbAutoReqAuth)
					CallContactService(hContact,PSS_AUTHREQUESTW,0, (LPARAM)variables_parse(gbCongratulation, hContact).c_str());
			}
		}
		return 0;
	}
	// URL contains check
	msg=(msg&&gbIgnoreURL)?(!IsUrlContains((TCHAR *) message.c_str())):msg;
	// if message message does not contain infintite talk protection prefix
	// and question count for this contact is less then maximum
	if(msg)
	{
		if((!gbInfTalkProtection || tstring::npos==message.find(_T("StopSpam automatic message:\r\n")))
			&& (!gbMaxQuestCount || DBGetContactSettingDword(hContact, pluginName, "QuestionCount", 0) < gbMaxQuestCount))
		{
			// send question
			tstring q = _T("StopSpam automatic message:\r\n") + variables_parse(gbQuestion, hContact);

#ifdef _UNICODE
			char * buf=mir_utf8encodeW(q.c_str());
			CallContactService(hContact, PSS_MESSAGE, PREF_UTF, (LPARAM)buf);
			mir_free(buf);
#else
			CallContactService(hContact, PSS_MESSAGE, 0, (LPARAM)q.c_str());
#endif

			// increment question count
			DWORD questCount = DBGetContactSettingDword(hContact, pluginName, "QuestionCount", 0);
			DBWriteContactSettingDword(hContact, pluginName, "QuestionCount", questCount + 1);
		}
		else
		{
			if (gbDosServiceExist)
			{
				if(gbDosServiceIntegration)
				{
					int i;
					i = rand()%255*13;
					CallService(MS_DOS_SERVICE, (WPARAM)hContact, (LPARAM)i);
				}
			}
			if(gbIgnoreContacts)
			{
				DBWriteContactSettingDword(hContact, "Ignore", "Mask1", 0x0000007F);
			}
		}
	}
	if(gbHideContacts)
		DBWriteContactSettingByte(hContact, "CList", "Hidden", 1);
	if(gbSpecialGroup)
		DBWriteContactSettingTString(hContact, "CList", "Group", gbSpammersGroup.c_str());
	DBWriteContactSettingByte(hContact, "CList", "NotOnList", 1);

	// save first message from contact
	if (DBGetContactSettingDword(hContact, pluginName, "QuestionCount", 0)<2){
		dbei->flags |= DBEF_READ;
		CallService(MS_DB_EVENT_ADD, (WPARAM)hContact, (LPARAM)dbei);
	};
	// reject processing of the event
	LogSpamToFile(hContact, message);
	return 1;
}


MIRANDA_HOOK_EVENT(ME_DB_CONTACT_SETTINGCHANGED, w, l)
{
	HANDLE hContact = (HANDLE)w;
	DBCONTACTWRITESETTING * cws = (DBCONTACTWRITESETTING*)l;

	// if CList/NotOnList is being deleted then remove answeredSetting
	if(strcmp(cws->szModule, "CList"))
		return 0;
	if(strcmp(cws->szSetting, "NotOnList"))
		return 0;
	if(!cws->value.type)
	{
		DBDeleteContactSetting(hContact, pluginName, "Answered");
		DBDeleteContactSetting(hContact, pluginName, "QuestionCount");
	}

	return 0;
}



