tstring DBGetContactSettingStringPAN(HANDLE hContact, char const * szModule, char const * szSetting, tstring errorValue);
std::string DBGetContactSettingStringPAN_A(HANDLE hContact, char const * szModule, char const * szSetting, std::string errorValue);
tstring &GetDlgItemString(HWND hwnd, int id);
std::string &GetProtoList();
bool ProtoInList(std::string proto);
void RemoveExcludedUsers();
tstring variables_parse(tstring const &tstrFormat, HANDLE hContact);
const int Stricmp(const TCHAR *str, const TCHAR *substr);
//const int Stristr(const TCHAR *str, const TCHAR *substr);
TCHAR* ReqGetText(DBEVENTINFO* dbei);
BOOL IsUrlContains(TCHAR * Str);
void DeleteCListGroupsByName(TCHAR* szGroupName);
tstring GetContactUid(HANDLE hContact, std::string Protocol);
void LogSpamToFile(HANDLE hContact, tstring message);
struct hContact_entry
{
	HANDLE hContact;
	struct hContact_entry *next;
};

