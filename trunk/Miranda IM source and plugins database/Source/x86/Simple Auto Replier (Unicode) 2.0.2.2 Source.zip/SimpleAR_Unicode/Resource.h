//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDD_OPTION                      102
#define IDC_ENABLEREPLIER               1001
#define IDC_HEADING                     1002
#define IDC_STATUSMODE                  1004
#define IDC_MESSAGE                     1005
#define IDC_INTERVAL                    1006
#define IDC_DEFAULT                     1007
#define IDI_ON							103
#define IDI_OFF							104

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
