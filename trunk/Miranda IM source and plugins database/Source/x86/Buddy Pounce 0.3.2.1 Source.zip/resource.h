//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_DELETE                      5
#define IDC_DEFAULT                     6
#define IDD_POUNCE                      101
#define IDI_POUNCE                      104
#define IDD_CONFIRMSEND                 105
#define IDD_POUNCE_SIMPLE               108
#define IDD_STATUSMODES                 109
#define IDD_OPTIONS                     110
#define IDC_MESSAGE                     1000
#define CHK_OFFLINE                     1003
#define CHK_ONLINE                      1004
#define CHK_AWAY                        1005
#define CHK_NA                          1006
#define CHK_OCCUPIED                    1007
#define CHK_DND                         1008
#define CHK_FFC                         1009
#define CHK_PHONE                       1010
#define CHK_LUNCH                       1011
#define CHK_ANYSTATUS                   1012
#define CHK_ONLINE2                     1013
#define CHK_AWAY2                       1014
#define CHK_NA2                         1015
#define CHK_OCCUPIED2                   1016
#define CHK_DND2                        1017
#define CHK_FFC2                        1018
#define CHK_PHONE2                      1019
#define CHK_LUNCH2                      1020
#define CHK_REUSE                       1028
#define IDC_REUSETIMES                  1029
#define CHK_GIVEUP                      1030
#define IDC_GIVEUPDAYS                  1031
#define LBL_CONTACT                     1034
#define CHK_POUNCESETUP                 1036
#define CHK_CONFIRM                     1037
#define IDC_TIMEOUT                     1038
#define GRP_DEFAULT                     1040
#define GRP_MSG                         1041
#define GRP_SENDON                      1042
#define GRP_SENDIF                      1043
#define GRP_SETTINGS                    1044
#define IDC_STATICTIMES                 1045
#define IDC_STATICDAYS                  1046
#define IDC_STATICWAIT                  1047
#define IDC_STATICSECONDS               1048
#define IDC_SETTINGMSG                  1061
#define IDC_SETTINGNUMBER               1066
#define IDC_SPIN                        1067
#define IDC_SETTINGTEXT                 1068
#define IDC_BUTTON                      1069
#define IDC_SETTINGS                    1075
#define IDC_CONTACTS                    1076
#define IDC_ADVANCED                    1078
#define IDC_SIMPLE                      1080
#define IDC_CHECK1                      1081
#define IDC_CHECK2                      1082
#define IDC_CHECK3                      1083
#define IDC_CHECK4                      1084
#define IDC_CHECK5                      1085
#define IDC_CHECK6                      1086
#define IDC_CHECK7                      1087
#define IDC_CHECK8                      1088
#define IDC_CHECK9                      1089
#define IDC_CHECK10                     1090
#define IDC_SETTINGMSG2                 1095
#define IDC_USEADVANCED                 1096
#define IDC_SHOWDELIVERYMSGS            1097

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1098
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
