#define __FILEVERSION_STRING        0,2,3,16
#define __VERSION_STRING            "0.2.3.16"
#define __VERSION_DWORD             PLUGIN_MAKE_VERSION(0, 2, 3, 16)
