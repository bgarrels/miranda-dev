// cflash.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"

#define DBVARIANT MIM_DBVARIANT

#include "cflash.h"
#include <map>
#include <fcntl.h>
#import  "PROGID:ShockwaveFlash.ShockwaveFlash" no_namespace raw_interfaces_only
//#import "c:\windows\system32\macromed\flash\flash.ocx" no_namespace raw_interfaces_only
#include "m_flash.h"
#include "CriticalSection.h"

#include <statusmodes.h>
#include <m_clist.h>
#include "m_icq.h"
#include "m_tabsrmm.h"

#define MODULENAME "FlashAvatars"
#define BAD_FLASH_VERSION 0x80000

PLUGININFO pluginInfo = {
    sizeof(PLUGININFO), 
	"Flash avatars service (unicode)",
	PLUGIN_MAKE_VERSION(0, 0, 1, 11), 
	"Load and display flash avatars", 
	"Big Muscle", 
	"", 
	"Copyright 2000-2006 Miranda-IM project", 
	"http://www.miranda-im.org", 
	0, 
	0
};

typedef multimap<HANDLE, pair<FLASHAVATAR, IShockwaveFlash*>> FlashList;
typedef FlashList::iterator FlashIter;
typedef FlashList::const_iterator FlashConstIter;

HINSTANCE g_hInst = 0;

PLUGINLINK *pluginLink;
FlashList flashList;
static HANDLE hStatusHook, hEventHook, hOwnStatusHook;
CriticalSection cs;
bool warned = false;

#ifdef TZERS_SUPPORT
IShockwaveFlash* tZersFlash = 0;
HWND tZersWindow = 0;
BOOL isPlaying = FALSE;
BOOL exitThread = FALSE;
#endif

typedef HRESULT (WINAPI *LPAtlAxAttachControl)(IUnknown* pControl, HWND hWnd, IUnknown** ppUnkContainer);
LPAtlAxAttachControl AtlAxAttachControl3;

#define getProto() \
	char* proto = hFA->cProto;\
	if(!proto) {\
		proto = reinterpret_cast<char*>(CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)hFA->hContact,0));\
		if(!proto)\
			proto = "ICQ";\
	}

#define loadFlash() \
	if(flash == 0) {\
		MessageBox(0, _T("Flash.ocx not registered!"), _T(""), MB_OK);\
		return 0;\
	} else {\
		AtlAxAttachControl3(flash, hFA->hWindow, 0);\
		flash->LoadMovie(0, _bstr_t(cUrl).copy());\
		flash->Play();\
	}

#define getFace() \
	char* face;\
	switch (status) {\
		case ID_STATUS_OFFLINE:\
			face = AV_OFFLINE;\
			break;\
		case ID_STATUS_ONLINE:\
		case ID_STATUS_INVISIBLE:\
			face = AV_NORMAL;\
			break;\
		default:\
			face = AV_BUSY;\
			break;\
	}
	
static int destroyAvatar(WPARAM wParam, LPARAM)
{
	FLASHAVATAR* hFA = (FLASHAVATAR*)wParam;
	
	getProto();
		
	Lock l(cs);
	pair<FlashIter, FlashIter> range = flashList.equal_range(hFA->hContact);
	for(FlashIter i = range.first; i != range.second; i++) {
		if((strcmp(i->second.first.cProto, proto) == 0) && (i->second.first.id == hFA->id)) {
			i->second.second->Release();
			DestroyWindow(i->second.first.hWindow);
			delete[] i->second.first.cUrl;
			flashList.erase(i);
			break;
		}
	}
	return 0;
}

static int makeAvatar(WPARAM wParam, LPARAM)
{
	FLASHAVATAR* hFA = (FLASHAVATAR*)wParam;
	IShockwaveFlash* flash=0;
	char* url = NULL;

	PROTO_AVATAR_INFORMATION AI;
	AI.cbSize = sizeof(AI);
	AI.hContact = hFA->hContact;
	AI.format = PA_FORMAT_UNKNOWN;

	getProto();
	
	BOOL avatarOK = false;
	if(hFA->hContact) {
		avatarOK = (int)CallProtoService(proto, PS_GETAVATARINFO, 0, (LPARAM)&AI) == GAIR_SUCCESS;
	} else {
		avatarOK = (int)CallProtoService(proto, PS_ICQ_GETMYAVATAR, (WPARAM)AI.filename, (LPARAM)255) == 0;
		if(avatarOK) {
			char* ext = strrchr(AI.filename, '.');
			if(ext && (strcmp(ext, ".xml") == 0))
				AI.format = PA_FORMAT_XML;
		}
	}
	
	if(avatarOK) {
		switch(AI.format) {
			case PA_FORMAT_SWF:
				url = AI.filename;
				break;
			case PA_FORMAT_XML: {
				char pBuf[2048];
				int src = _open(AI.filename, _O_BINARY | _O_RDONLY);
				if(src != -1) {
					char* urlBuf;
					_read(src, pBuf, 2048);
					_close(src);
					
					urlBuf = strstr(pBuf, "<URL>");
					if(urlBuf)
 						url = strtok(urlBuf + 5, "<");
 					else
 						return 0;
 				} else {
 					return 0;
 				}
 				break;
 			}
 			default:
 				destroyAvatar(wParam, 0);
 				return 0;
		}
		{
			Lock l(cs);
			bool found = false;
			pair<FlashIter, FlashIter> range = flashList.equal_range(hFA->hContact);
			if(range.first != range.second) {
				for(FlashIter i = range.first; i != range.second; ++i) {
					if((strcmp(i->second.first.cProto, proto) == 0) && (i->second.first.id == hFA->id)) {
						found = true;
						hFA->hWindow = i->second.first.hWindow;
						ShowWindow(hFA->hWindow, SW_SHOW);
						flash = i->second.second;
						if(_stricmp(i->second.first.cUrl, url) != 0) {
							delete[] i->second.first.cUrl;
							hFA->cProto = proto;
							flashList.erase(i);
	
							char* cUrl = new char[lstrlenA(url) + 1];
							lstrcpyA(cUrl, url);

							loadFlash();

							hFA->cUrl = cUrl;
							flashList.insert(make_pair(hFA->hContact, make_pair(*hFA, flash)));
							break;
						}
					}
				}
			}
			
			if(!found) {	
				RECT rc;
				GetWindowRect(hFA->hParentWindow, &rc);
				hFA->hWindow = CreateWindowEx(WS_EX_TOPMOST, _T("AtlAxWin"), _T(""), WS_VISIBLE | WS_CHILD, 0, 0, rc.right - rc.left, rc.bottom - rc.top, hFA->hParentWindow, (HMENU) 0, g_hInst, NULL);
				char* cUrl = (char*) malloc(lstrlenA(url) + 1);
				lstrcpyA(cUrl, url);

				CoCreateInstance(__uuidof(ShockwaveFlash),0,CLSCTX_ALL, __uuidof(IShockwaveFlash), (void **)&flash); 
				loadFlash();

				if(!warned) {
					long version;
					flash->FlashVersion(&version);
					if(version == BAD_FLASH_VERSION)
						MessageBox(0, _T("You have installed Flash 8.\r\nThis version of Flash contains a bug which can causes random crashes.\r\nIt's recommended to upgrade or downgrade your Flash library"), _T("Bad Flash detected!"), MB_ICONWARNING | MB_OK);
					warned = true;
				}

				hFA->cUrl = cUrl;
				hFA->cProto = proto;
				flashList.insert(make_pair(hFA->hContact, make_pair(*hFA, flash)));
				InvalidateRect(hFA->hParentWindow, NULL, FALSE);
			}
		}
	
		if(flash != 0) {
			flash->Play();
					
			int status;
			if(hFA->hContact)
				status = DBGetContactSettingWord(hFA->hContact, proto, "Status", 0);
			else
				status = CallProtoService(proto,PS_GETSTATUS,0,0);
			getFace();
			flash->SetVariable(L"face.emotion", _bstr_t(face).copy());			
		}
	}	
	return 0;
}

static int resizeAvatar(WPARAM wParam, LPARAM lParam)
{
	FLASHAVATAR* hFA = (FLASHAVATAR*)wParam;
	RECT rc = *((LPRECT)lParam);
	
	getProto();
	
	Lock l(cs);
	pair<FlashConstIter, FlashConstIter> range = flashList.equal_range(hFA->hContact);
	for(FlashConstIter i = range.first; i != range.second; i++) {
		if((strcmp(i->second.first.cProto, proto) == 0) && (i->second.first.id == hFA->id)) {
			SetWindowPos(i->second.first.hWindow, HWND_TOP, 0, 0, rc.right - rc.left, rc.bottom - rc.top, SWP_SHOWWINDOW);
			break;
		}
	}
	return 0;
}

static int setPos(WPARAM wParam, LPARAM lParam)
{
	FLASHAVATAR* hFA = (FLASHAVATAR*)wParam;
	RECT rc = *((LPRECT)lParam);
	
	getProto();
	
	Lock l(cs);
	pair<FlashConstIter, FlashConstIter> range = flashList.equal_range(hFA->hContact);
	for(FlashConstIter i = range.first; i != range.second; i++) {
		if((strcmp(i->second.first.cProto, proto) == 0) && (i->second.first.id == hFA->id)) {
			SetWindowPos(i->second.first.hWindow, HWND_TOP, rc.left, rc.top, rc.right, rc.bottom, SWP_SHOWWINDOW);
			break;
		}
	}
	return 0;
}

static int getInfo(WPARAM wParam, LPARAM)
{
	FLASHAVATAR* hFA = (FLASHAVATAR*)wParam;
	
	getProto();
	
	Lock l(cs);
	pair<FlashConstIter, FlashConstIter> range = flashList.equal_range(hFA->hContact);
	for(FlashConstIter i = range.first; i != range.second; i++) {
		if((strcmp(i->second.first.cProto, proto) == 0) && (i->second.first.id == hFA->id)) {
			hFA->hWindow = i->second.first.hWindow;
			hFA->cUrl = i->second.first.cUrl;
			hFA->cProto = i->second.first.cProto;
			break;
		}
	}
	return 0;
}

static int setEmoFace(WPARAM wParam, LPARAM lParam)
{
	FLASHAVATAR* hFA = (FLASHAVATAR*)wParam;
	
	getProto();
	
	Lock l(cs);
	pair<FlashConstIter, FlashConstIter> range = flashList.equal_range(hFA->hContact);
	for(FlashConstIter i = range.first; i != range.second; i++) {
		if((strcmp(i->second.first.cProto, proto) == 0) && (i->second.first.id == hFA->id)) {
			IShockwaveFlash* flash = i->second.second;
			flash->SetVariable(L"face.emotion", (BSTR)lParam);
			break;
		}
	}
	return 0;
}

static int setBkColor(WPARAM wParam, LPARAM lParam)
{
	FLASHAVATAR* hFA = (FLASHAVATAR*)wParam;
	COLORREF clr = (COLORREF)lParam;

	getProto();
	
	Lock l(cs);
	pair<FlashConstIter, FlashConstIter> range = flashList.equal_range(hFA->hContact);
	for(FlashConstIter i = range.first; i != range.second; i++) {
		if((strcmp(i->second.first.cProto, proto) == 0) && (i->second.first.id == hFA->id)) {
			IShockwaveFlash* flash = i->second.second;
			
			char buf[16];
			sprintf(buf, "%02X%02X%02X", LOBYTE(LOWORD(clr)), HIBYTE(LOWORD(clr)), LOBYTE(HIWORD(clr)));
			flash->put_BGColor(_bstr_t(buf));	
			break;
		}
	}
	return 0;
}

static int statusChanged(WPARAM wParam, LPARAM lParam)
{
	WORD status = HIWORD(lParam);

	Lock l(cs);
	pair<FlashConstIter, FlashConstIter> range = flashList.equal_range((HANDLE)wParam);
	for(FlashConstIter i = range.first; i != range.second; i++) {
		IShockwaveFlash* flash = i->second.second;	
		getFace();
		flash->SetVariable(L"face.emotion", _bstr_t(face).copy());
		break;
	}
	return 0;
}

static int ownStatusChanged(WPARAM wParam, LPARAM lParam)
{
	WORD status = (WORD)wParam;
	char* proto = (char*)lParam;

	Lock l(cs);
	pair<FlashConstIter, FlashConstIter> range = flashList.equal_range((HANDLE)0);
	for(FlashConstIter i = range.first; i != range.second; i++) {
		if(!proto || (strcmp(i->second.first.cProto, proto) == 0)) {
			IShockwaveFlash* flash = i->second.second;	
			getFace();
			flash->SetVariable(L"face.emotion", _bstr_t(face).copy());
			break;
		}
	}
	return 0;
}

static int eventAdded(WPARAM wParam, LPARAM lParam)
{
	DBEVENTINFO dbei;
	ZeroMemory(&dbei, sizeof(dbei));
	dbei.cbSize = sizeof(dbei);
    dbei.cbBlob = CallService(MS_DB_EVENT_GETBLOBSIZE, (WPARAM)lParam , 0);
    if (dbei.cbBlob == 0xFFFFFFFF) {
        return 0;
	}
    dbei.pBlob = new BYTE[dbei.cbBlob];
    CallService(MS_DB_EVENT_GET, (WPARAM)lParam, (LPARAM) & dbei);
#ifdef TZERS_SUPPORT
	if (dbei.eventType == EVENTTYPE_TZERS && !(dbei.flags & DBEF_READ)) {
		isPlaying = TRUE;
		if(tZersWindow == 0) {
			MessageWindowInputData mwid = {0};
			mwid.cbSize = sizeof(MessageWindowInputData);
			mwid.hContact = (HANDLE)wParam;
			mwid.uFlags = MSG_WINDOW_UFLAG_MSG_BOTH;
			
			MessageWindowOutputData mwod = {0};
			mwod.cbSize = sizeof(MessageWindowOutputData);
			CallService(MS_MSG_GETWINDOWDATA, (WPARAM)&mwid, (LPARAM)&mwod);

			RECT rc = {0};

			GetWindowRect(mwod.hwndWindow, &rc);
			tZersWindow = CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST, _T("AtlAxWin"), _T(""), WS_POPUP | WS_VISIBLE, 
				rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, 0, (HMENU) 0, g_hInst, NULL);
			
			typedef bool (CALLBACK* LPFUNC)(HWND hwnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);
			LPFUNC _d_SetLayeredWindowAttributes = (LPFUNC)GetProcAddress(LoadLibrary(_T("user32")), "SetLayeredWindowAttributes");
			_d_SetLayeredWindowAttributes(tZersWindow, RGB(0, 0, 0), 0, LWA_COLORKEY);
			
			CoCreateInstance(__uuidof(ShockwaveFlash),0,CLSCTX_ALL, __uuidof(IShockwaveFlash), (void **)&tZersFlash);
		}

		if(tZersFlash == 0) {
			MessageBox(0, _T("Flash.ocx not registered!"), _T(""), MB_OK);
		} else {
			tZersFlash->put_WMode(L"transparent");
			AtlAxAttachControl3(tZersFlash, tZersWindow, 0);
			
			tZersFlash->LoadMovie(0, _bstr_t((char*)dbei.pBlob).copy());
			tZersFlash->put_AllowScriptAccess(L"always");
			tZersFlash->put_Loop(FALSE);
			tZersFlash->Play();
		}
	} else 
#endif		
	if (dbei.eventType == EVENTTYPE_MESSAGE && !(dbei.flags & DBEF_READ)) {
		Lock l(cs);
		pair<FlashConstIter, FlashConstIter> range = flashList.equal_range((dbei.flags & DBEF_SENT) ? 0 : (HANDLE)wParam);
		if(range.first != range.second) {
			//size_t aLen = strlen((char *)dbei.pBlob)+1;
			char* face = NULL;
	
			if(	(strstr((char*)dbei.pBlob, (char*)":-)") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":)") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)";)") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)";-)") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"*THUMBS UP*") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"O:-)") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":P") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":-P") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"*Drink*") != NULL)) { face = AV_SMILE; }
			else
			if(	(strstr((char*)dbei.pBlob, (char*)":-(") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":-$") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":-!") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":-X") != NULL)) { face = AV_SAD; }
			else
			if(	(strstr((char*)dbei.pBlob, (char*)"*JOKINGLY*") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":-D") != NULL)) { face = AV_LAUGH; }
			else
			if(	(strstr((char*)dbei.pBlob, (char*)":'(") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":'-(") != NULL)) { face = AV_CRY; }
			else
			if(	(strstr((char*)dbei.pBlob, (char*)">:o") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":-@") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"*STOP*") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"]:->") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"@=") != NULL)) { face = AV_MAD; }
			else
			if(	(strstr((char*)dbei.pBlob, (char*)":-*") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)":-[") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"*KISSED*") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"*KISSING*") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"@}->--") != NULL) ||
				(strstr((char*)dbei.pBlob, (char*)"*IN LOVE*") != NULL)) { face = AV_LOVE; }
			else {
				face = AV_NORMAL;
			}

			for(FlashConstIter i = range.first; i != range.second; i++) {
				char* cProto = i->second.first.cProto;
				if(strcmp(cProto, dbei.szModule) == 0) {	
					IShockwaveFlash* flash = i->second.second;	
					flash->SetVariable(L"face.emotion", _bstr_t(face).copy());
					break;
				}
			}
		}
	}

	delete[] dbei.pBlob;
	return 0;
}
#ifdef TZERS_SUPPORT
static int tZersSupport(WPARAM wParam, LPARAM lParam)
{
	return 0;
}

static DWORD WINAPI starter(void* p) {
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_IDLE);
	while(!exitThread) {
		Sleep(10000);
		if(tZersWindow != 0) {
			if(!isPlaying) {
				tZersFlash->Release();
				ShowWindow(tZersWindow, SW_HIDE);
				DestroyWindow(tZersWindow);
				tZersWindow = 0;
			}
			if(isPlaying) isPlaying = FALSE;
		}
	}
	return 0;
}
#endif
static int ModulesLoaded(WPARAM /*wParam*/, LPARAM /*lParam*/)
{
    void* init = GetProcAddress(LoadLibrary(_T("atl")), "AtlAxWinInit"); _asm call init;
	AtlAxAttachControl3 = (LPAtlAxAttachControl)GetProcAddress(LoadLibrary(_T("atl")),"AtlAxAttachControl"); 

	CreateServiceFunction(MS_FAVATAR_DESTROY, destroyAvatar);	
	CreateServiceFunction(MS_FAVATAR_MAKE, makeAvatar);
	CreateServiceFunction(MS_FAVATAR_RESIZE, resizeAvatar);
	CreateServiceFunction(MS_FAVATAR_SETPOS, setPos);
	CreateServiceFunction(MS_FAVATAR_GETINFO, getInfo);
	CreateServiceFunction(MS_FAVATAR_SETEMOFACE, setEmoFace);
	CreateServiceFunction(MS_FAVATAR_SETBKCOLOR, setBkColor);
#ifdef TZERS_SUPPORT	
	CreateServiceFunction(MS_TZERS_SUPPORT, tZersSupport);
	DWORD threadId;
	CreateThread(NULL, 0, &starter, 0, 0, &threadId);
#endif
	hEventHook = HookEvent(ME_DB_EVENT_ADDED, eventAdded);
	hStatusHook = HookEvent("Miranda/StatusChange/ContactStatusChanged", statusChanged);
	hOwnStatusHook = HookEvent(ME_CLIST_STATUSMODECHANGE, ownStatusChanged); 

	return 0;
}

static int ShutdownProc(WPARAM /*wParam*/, LPARAM /*lParam*/)
{
	// Shutdown cleanup	
#ifdef TZERS_SUPPORT
	exitThread = TRUE;
	tZersFlash->Release();
	DestroyWindow(tZersWindow);
#endif
	{
		Lock l(cs);
		for(FlashConstIter i = flashList.begin(); i != flashList.end(); i++) {
			i->second.second->Release();
			DestroyWindow(i->second.first.hWindow);
			delete[] i->second.first.cUrl;
		}
		flashList.clear();
	}
	
	UnhookEvent(hStatusHook);
	UnhookEvent(hEventHook);
	
	return 0;
}

static int LoadAvatarModule()
{
    HookEvent(ME_SYSTEM_MODULESLOADED, ModulesLoaded);
    return 0;
}

extern "C" __declspec(dllexport) PLUGININFO * MirandaPluginInfo(DWORD mirandaVersion)
{
    if (mirandaVersion < PLUGIN_MAKE_VERSION(0, 4, 0, 0))
        return NULL;
    return &pluginInfo;
}

static int systemModulesLoaded(WPARAM wParam, LPARAM lParam)
{
    ModulesLoaded(wParam, lParam);
    return 0;
}

extern "C" int __declspec(dllexport) Load(PLUGINLINK * link)
{
	//AFX_MANAGE_STATE(AfxGetStaticModuleState());
    pluginLink = link;
    return(LoadAvatarModule());
}

extern "C" int __declspec(dllexport) Unload(void)
{
	//AFX_MANAGE_STATE(AfxGetStaticModuleState());
    return ShutdownProc(0, 0);
}

