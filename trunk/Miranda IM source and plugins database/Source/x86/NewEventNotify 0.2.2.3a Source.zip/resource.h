//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDD_OPT                         101
#define IDI_ENABLED                     106
#define IDI_ICON2                       107
#define IDI_DISABLED                    107
#define IDC_PREVIEW                     1000
#define IDC_CHKNOTIFY_MESSAGE           1001
#define IDC_CHKNOTIFY_URL               1002
#define IDC_CHKNOTIFY_FILE              1003
#define IDC_CHKNOTIFY_OTHER             1004
#define IDC_CHKMENUITEM                 1005
#define IDC_CHKDISABLE                  1006
#define IDC_CHKACTL_DISMISS             1007
#define IDC_CHKACTL_OPEN                1008
#define IDC_CHKACTL_REMOVE              1009
#define IDC_CHKACTR_DISMISS             1010
#define IDC_CHKACTR_OPEN                1011
#define IDC_CHKACTR_REMOVE              1012
#define IDC_CHKWINDOWCHECK              1013
#define IDC_CHKREPLYWINDOW              1014
#define IDC_CHKPREVIEW                  1015
#define IDC_CHKINFINITE                 1016
#define IDC_CHKHIDESEND                 1016
#define IDC_CHKDEFAULTCOL_MESSAGE       1017
#define IDC_COLBACK_MESSAGE             1018
#define IDC_COLTEXT_MESSAGE             1019
#define IDC_CHKDEFAULTCOL_URL           1020
#define IDC_COLBACK_URL                 1021
#define IDC_COLTEXT_URL                 1022
#define IDC_CHKDEFAULTCOL_FILE          1023
#define IDC_COLBACK_FILE                1024
#define IDC_COLTEXT_FILE                1025
#define IDC_CHKDEFAULTCOL_OTHERS        1026
#define IDC_COLBACK_OTHERS              1027
#define IDC_COLTEXT_OTHERS              1028
#define IDC_MERGEPOPUP                  1029
#define IDC_CHKINFINITE_MESSAGE         1029
#define IDC_CHKMERGEPOPUP               1030
#define IDC_DELAY_MESSAGE               1031
#define IDC_DELAY_URL                   1032
#define IDC_DELAY_FILE                  1033
#define IDC_DELAY_OTHERS                1034
#define IDC_NUMBERMSG                   1035
#define IDC_CHKSHOWDATE                 1036
#define IDC_CHKSHOWTIME                 1037
#define IDC_CHKSHOWHEADERS              1038
#define IDC_RDNEW                       1039
#define IDC_RDOLD                       1040
#define IDC_LBNUMBERMSG                 1041
#define IDC_CHKINFINITE_URL             1042
#define IDC_CHKINFINITE_FILE            1043
#define IDC_CHKINFINITE_OTHERS          1044
#define IDC_CHKMERGEPOPUP2              1045
#define IDC_SUPRESSRSS                  1045
#define IDC_TESTFORREAD                 1046
#define IDC_READCHECK                   1046
#define IDC_CMDEDITHEADERS              1047
#define IDC_CHKACTTE_DISMISS            1049
#define IDC_CHKACTTE_OPEN               1050
#define IDC_CHKACTTE_REMOVE             1051
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
