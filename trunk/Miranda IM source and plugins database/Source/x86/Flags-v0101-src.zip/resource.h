//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDB_FLAGS                       101
#define IDR_IPTOCOUNTRY                 102
#define IDD_OPT_EXTRAIMG                103
#define IDC_CHECK_SHOWSTATUSFLAGICON    1001
#define IDC_CHECK_SHOWEXTRAIMGFLAGICON  1002
#define IDC_TEXT_EXTRAIMGFLAGCOLUMN     1003
#define IDC_COMBO_EXTRAIMGFLAGCOLUMN    1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           2001
#endif
#endif
