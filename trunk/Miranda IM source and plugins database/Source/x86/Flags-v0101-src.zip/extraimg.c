/*
Miranda IM Country Flags Plugin
Copyright (C) 2006-1007 H. Herkenrath

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (Flags-License.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "flags.h"

/* Services */
static HANDLE hServiceDetectContactOrigin;
/* Extra Image */
static HANDLE hHookExtraRebuild,hHookExtraApply;
/* Status Icon */
static HANDLE hHookMsgWndEvent,hHookIconsChanged;
/* Options */
static HANDLE hHookOptInit;
/* Misc */
extern HINSTANCE hInst;
static HANDLE hHookModulesLoaded,hHookSettingChanged;

/************************* Services *******************************/

static int ServiceDetectContactOriginCountry(WPARAM wParam,LPARAM lParam)
{
	DWORD val;
	char *pszProto;
	UNREFERENCED_PARAMETER(lParam);
	pszProto=(char*)CallService(MS_PROTO_GETCONTACTBASEPROTO,wParam,0);
	/* ip detect */
	val=DBGetContactSettingDword((HANDLE)wParam,pszProto,"RealIP",0);
	if(val) val=ServiceIpToCountry(val,0);
	/* fallback */
	if(val==0xFFFF) val=DBGetContactSettingWord((HANDLE)wParam,pszProto,"Country",0xFFFF);
	if(val==0xFFFF) val=DBGetContactSettingWord((HANDLE)wParam,pszProto,"CompanyCountry",0xFFFF);
	return val;
}

/************************* Extra Image ****************************/

static HANDLE hExtraImages[NUMBEROFFLAGS];
static BYTE idExtraColumn;

static int ExtraListRebuild(WPARAM wParam,LPARAM lParam)
{
	BYTE idMaxExtraCol;
	int i;
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	/* invalidate icons */
	for(i=0;i<NUMBEROFFLAGS;++i) hExtraImages[i]=INVALID_HANDLE_VALUE;
	/* choose column */
	idMaxExtraCol=(BYTE)CallService(MS_CLUI_GETCAPS,0,CLUIF2_EXTRACOLUMNCOUNT); /* 1-based count */
	if(idMaxExtraCol==0) idMaxExtraCol=EXTRA_ICON_ADV2; /* zero if not present */
	idExtraColumn=DBGetContactSettingRangedByte(NULL,"Flags","ExtraImgFlagColumn",SETTING_SHOWEXTRAIMGFLAGICON_DEFAULT,1,idMaxExtraCol);
	return 0;
}

static int ExtraImageApply(WPARAM wParam,LPARAM lParam)
{
	if(DBGetContactSettingByte(NULL,"Flags","ShowExtraImgFlagIcon",SETTING_SHOWEXTRAIMGFLAGICON_DEFAULT)) {
		IconExtraColumn iec;
		int countryNumber,index;
		UNREFERENCED_PARAMETER(lParam);
		/* get contact's country */
		countryNumber=ServiceDetectContactOriginCountry(wParam,0);
		index=CountryNumberToIndex(countryNumber);
		/* icon not yet loaded? */
		if(hExtraImages[index]==INVALID_HANDLE_VALUE) {
			HICON hIcon;
			hIcon=LoadFlagIcon(countryNumber);
			if(hIcon!=NULL) hExtraImages[index]=(HANDLE)CallService(MS_CLIST_EXTRA_ADD_ICON,(WPARAM)hIcon,0);
			CallService(MS_SKIN2_RELEASEICON,(WPARAM)hIcon,0); /* does NULL check */
		}
		/* choose column */
		iec.cbSize=sizeof(iec);
		iec.ColumnType=idExtraColumn;
		iec.hImage=hExtraImages[index];
		CallService(MS_CLIST_EXTRA_SET_ICON,wParam,(LPARAM)&iec);
	}
	return 0;
}

// always call in context of main thread
static void RemoveExtraImages(void)
{
	IconExtraColumn iec;
	int countryNumber,index;
	register HANDLE hContact;
	iec.cbSize=sizeof(iec);
	iec.ColumnType=idExtraColumn;
	iec.hImage=INVALID_HANDLE_VALUE;
	/* enum all contacts */
	hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
	while(hContact!=NULL) {
		/* get contact's country */
		countryNumber=ServiceDetectContactOriginCountry((WPARAM)hContact,0);
		index=CountryNumberToIndex(countryNumber);
		/* invalidate icon */
		CallService(MS_CLIST_EXTRA_SET_ICON,(WPARAM)hContact,(LPARAM)&iec);
		hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0);
	}
}

// always call in context of main thread
static void EnsureExtraImages(void)
{
	register HANDLE hContact;
	BYTE idMaxExtraCol,idExtraColumnNew;
	/* choose column */

	idMaxExtraCol=(BYTE)CallService(MS_CLUI_GETCAPS,0,CLUIF2_EXTRACOLUMNCOUNT); /* 1-based count */
	if(idMaxExtraCol==0) idMaxExtraCol=EXTRA_ICON_ADV2; /* zero if not present */
	idExtraColumnNew=DBGetContactSettingRangedByte(NULL,"Flags","ExtraImgFlagColumn",SETTING_SHOWEXTRAIMGFLAGICON_DEFAULT,1,idMaxExtraCol);
	/* clear previous column */
	if(idExtraColumnNew!=idExtraColumn) RemoveExtraImages();
	idExtraColumn=idExtraColumnNew;
	/* enum all contacts */
	hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
	while(hContact!=NULL) {
		ExtraImageApply((WPARAM)hContact,0);
		hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0);
	}
}

/************************* Status Icon ****************************/

// always call in context of main thread
static void FASTCALL SetStatusIcon(HANDLE hContact,int countryNumber)
{
	int i;
	HICON hIcon;
	StatusIconData sid;
	int nCountriesCount;
	struct CountryListEntry *countries;
	
	/* copy icon, status icon API will call DestroyIcon() on it */
	hIcon=LoadFlagIcon(countryNumber);
	sid.hIcon=(hIcon!=NULL)?CopyIcon(hIcon):NULL;
	CallService(MS_SKIN2_RELEASEICON,(WPARAM)hIcon,0); /* does NULL check */
	/* ensure status icon is registered */
	sid.cbSize=sizeof(sid);
	sid.szModule="Flags";
	sid.dwId=countryNumber;
	sid.hIconDisabled=NULL;
	sid.flags=0;
	sid.szTooltip=Translate((char*)CallService(MS_UTILS_GETCOUNTRYBYNUMBER,countryNumber,0));
	if(CallService(MS_MSG_MODIFYICON,0,(LPARAM)&sid)) /* not yet registered? */
		CallService(MS_MSG_ADDICON,0,(LPARAM)&sid);
	
	/* disable all other flags for this contact */
	sid.hIcon=NULL;
	sid.szTooltip=NULL;
	sid.flags=MBF_HIDDEN;
	if(!CallService(MS_UTILS_GETCOUNTRYLIST,(WPARAM)&nCountriesCount,(LPARAM)&countries))
		for(i=0;i<nCountriesCount;++i) {
			sid.dwId=countries[i].id;
			sid.flags=(countryNumber!=countries[i].id)?MBF_HIDDEN:0;
			/* displayed icon can only be modified globally, not per contact */
			CallService(MS_MSG_MODIFYICON,(WPARAM)hContact,(LPARAM)&sid);
		}
}

// always call in context of main thread
static void FASTCALL UnsetStatusIcon(HANDLE hContact,int countryNumber)
{
	StatusIconData sid;
	sid.cbSize=sizeof(sid);
	sid.szModule="Flags";
	sid.dwId=countryNumber;
	sid.hIconDisabled=sid.hIcon=NULL;
	sid.szTooltip=NULL;
	sid.flags=MBF_HIDDEN;
	CallService(MS_MSG_MODIFYICON,(WPARAM)hContact,(LPARAM)&sid); /* registered? */
	/* can't call MS_MSG_REMOVEICON here as the icon might be
	 * in use by other contacts simultanously, removing them all at exit */
}

static int MsgWndEvent(WPARAM wParam,LPARAM lParam)
{
	MessageWindowEventData *msgwe=(MessageWindowEventData*)lParam;
	UNREFERENCED_PARAMETER(wParam);
	switch(msgwe->uType) {
		case MSG_WINDOW_EVT_OPENING:
		case MSG_WINDOW_EVT_CLOSE:
		{	int countryNumber;
			if(msgwe->hContact==NULL || !ServiceExists(MS_MSG_ADDICON)) break; /* sanity check */
			countryNumber=ServiceDetectContactOriginCountry((WPARAM)msgwe->hContact,0);
			if(DBGetContactSettingByte(NULL,"Flags","ShowStatusFlagIcon",SETTING_SHOWSTATUSFLAGICON_DEFAULT)) {
				if(msgwe->uType==MSG_WINDOW_EVT_OPENING) SetStatusIcon(msgwe->hContact,countryNumber);
				else UnsetStatusIcon(msgwe->hContact,countryNumber);
			}
			/* ensure it is hidden, RemoveStatusIcons() only enums currently opened ones  */
			else UnsetStatusIcon(msgwe->hContact,countryNumber);
		}
	}
	return 0;
}

// always call in context of main thread
static void UpdateStatusIcons(BOOL fShow)
{
	MessageWindowInputData msgwi; /* input */
	MessageWindowData msgw; /* output */
	int countryNumber;
	if(!ServiceExists(MS_MSG_ADDICON)) return;
	msgwi.cbSize=sizeof(msgwi);
	msgw.cbSize=sizeof(msgw);
	msgwi.uFlags=MSG_WINDOW_UFLAG_MSG_BOTH;
	/* enum all opened message windows */
	msgwi.hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
	while(msgwi.hContact!=NULL) {
		/* is a message window opened for this contact? */
		if(!CallService(MS_MSG_GETWINDOWDATA,(WPARAM)&msgwi,(LPARAM)&msgw) && msgw.uState&MSG_WINDOW_STATE_EXISTS) {
			countryNumber=ServiceDetectContactOriginCountry((WPARAM)msgwi.hContact,0);
			if(fShow) SetStatusIcon(msgwi.hContact,countryNumber);
			else UnsetStatusIcon(msgwi.hContact,countryNumber);
		}
		msgwi.hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)msgw.hContact,0);
	}
}

static int StatusIconsChanged(WPARAM wParam,LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	UpdateStatusIcons(DBGetContactSettingByte(NULL,"Flags","ShowStatusFlagIcon",SETTING_SHOWSTATUSFLAGICON_DEFAULT));
	return 0;
}

/************************* Options ************************************/

#define M_ENABLE_SUBCTLS  (WM_APP+1)

static int CALLBACK ExtraImgOptDlgProc(HWND hwndDlg,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg) {
		case WM_INITDIALOG:
			TranslateDialogDefault(hwndDlg);
			/* init checkboxes */
			{	BOOL val;
				/* Status Icon */
				if(ServiceExists(MS_MSG_ADDICON)) val=DBGetContactSettingByte(NULL,"Flags","ShowStatusFlagIcon",SETTING_SHOWSTATUSFLAGICON_DEFAULT)!=0;
				else EnableWindow(GetDlgItem(hwndDlg,IDC_CHECK_SHOWSTATUSFLAGICON),val=FALSE);
				CheckDlgButton(hwndDlg,IDC_CHECK_SHOWSTATUSFLAGICON,val);
				/* Extra Image */
				if(ServiceExists(MS_CLIST_EXTRA_ADD_ICON)) val=DBGetContactSettingByte(NULL,"Flags","ShowExtraImgFlagIcon",SETTING_SHOWEXTRAIMGFLAGICON_DEFAULT)!=0;
				else EnableWindow(GetDlgItem(hwndDlg,IDC_CHECK_SHOWEXTRAIMGFLAGICON),val=FALSE);
				CheckDlgButton(hwndDlg,IDC_CHECK_SHOWEXTRAIMGFLAGICON,val);
			}
			/* init combobox */
			{	HWND hwndCombo;
				TCHAR *pszItem,*pszAdvFmt;
				BYTE idColumn,idSavedColumn;
				BYTE idMaxExtraCol,idAdvExtraColStart;
				int index,size;
				hwndCombo=GetDlgItem(hwndDlg,IDC_COMBO_EXTRAIMGFLAGCOLUMN);
				idSavedColumn=DBGetContactSettingByte(NULL,"Flags","ExtraImgFlagColumn",SETTING_EXTRAIMGFLAGCOLUMN_DEFAULT);
				idMaxExtraCol=(BYTE)CallService(MS_CLUI_GETCAPS,0,CLUIF2_EXTRACOLUMNCOUNT); /* 1-based count */
				idAdvExtraColStart=(BYTE)CallService(MS_CLUI_GETCAPS,0,CLUIF2_USEREXTRASTART); /* 1-based id */
				/* can't use mir_sntprintf() */
				pszAdvFmt=TranslateT("Advanced #%u");
				size=lstrlen(pszAdvFmt)+2;
				pszItem=(TCHAR*)mir_alloc(size*sizeof(TCHAR)); /* buffer safe */
				/* init */
				SendMessage(hwndCombo,CB_SETLOCALE,(LCID)CallService(MS_LANGPACK_GETLOCALE,0,0),0); /* for sort order */
				SendMessage(hwndCombo,CB_INITSTORAGE,idMaxExtraCol-idAdvExtraColStart+3,(idMaxExtraCol-idAdvExtraColStart+3)*size);
				if(pszItem!=NULL) {
					/* Advanced #1,#2 */
					const BYTE columnIds[]={EXTRA_ICON_ADV1,EXTRA_ICON_ADV2};
					for(idColumn=0;idColumn<SIZEOF(columnIds);++idColumn) {
						wsprintf(pszItem,pszAdvFmt,idColumn+1); /* buffer safe */
						index=SendMessage(hwndCombo,CB_ADDSTRING,0,(LPARAM)pszItem);
						if(index!=LB_ERR) {
							SendMessage(hwndCombo,CB_SETITEMDATA,index,columnIds[idColumn]);
							if(idColumn==0 || columnIds[idColumn]==idSavedColumn) SendMessage(hwndCombo,CB_SETCURSEL,index,0);
						}
					}
					/* Advanced #3+: clist_modern, clist_nicer */
					if(idMaxExtraCol!=idAdvExtraColStart) /* same flags if not present */
						for(idColumn=idAdvExtraColStart;idColumn<=idMaxExtraCol;++idColumn) {
							wsprintf(pszItem,pszAdvFmt,idColumn-idAdvExtraColStart+3); /* buffer safe */
							index=SendMessage(hwndCombo,CB_ADDSTRING,0,(LPARAM)pszItem);
							if(index!=LB_ERR) {
								SendMessage(hwndCombo,CB_SETITEMDATA,index,idColumn);
								if(idColumn==idSavedColumn) SendMessage(hwndCombo,CB_SETCURSEL,index,0);
							}
						}
					mir_free(pszItem);
				}
			}
			SendMessage(hwndDlg,M_ENABLE_SUBCTLS,0,0);
			return TRUE; /* default focus */
		case M_ENABLE_SUBCTLS:
		{	BOOL checked=IsDlgButtonChecked(hwndDlg,IDC_CHECK_SHOWEXTRAIMGFLAGICON)!=0;
			if(checked) checked=IsWindowEnabled(GetDlgItem(hwndDlg,IDC_CHECK_SHOWEXTRAIMGFLAGICON));
			EnableWindow(GetDlgItem(hwndDlg,IDC_TEXT_EXTRAIMGFLAGCOLUMN),checked);
			EnableWindow(GetDlgItem(hwndDlg,IDC_COMBO_EXTRAIMGFLAGCOLUMN),checked);
			return TRUE;
		}
 		case WM_COMMAND:
			if(LOWORD(wParam)==IDC_CHECK_SHOWEXTRAIMGFLAGICON)
				PostMessage(hwndDlg,M_ENABLE_SUBCTLS,0,0);
			PostMessage(GetParent(hwndDlg),PSM_CHANGED,0,0); /* enable apply */
			return FALSE;
		case WM_NOTIFY:
			switch(((NMHDR*)lParam)->code) {
				case PSN_APPLY:
					/* save checkboxes */
					if(IsWindowEnabled(GetDlgItem(hwndDlg,IDC_CHECK_SHOWSTATUSFLAGICON)))
						DBWriteContactSettingByte(NULL,"Flags","ShowStatusFlagIcon",(BYTE)(IsDlgButtonChecked(hwndDlg,IDC_CHECK_SHOWSTATUSFLAGICON)!=0));
					if(IsWindowEnabled(GetDlgItem(hwndDlg,IDC_CHECK_SHOWEXTRAIMGFLAGICON)))
						DBWriteContactSettingByte(NULL,"Flags","ShowExtraImgFlagIcon",(BYTE)(IsDlgButtonChecked(hwndDlg,IDC_CHECK_SHOWEXTRAIMGFLAGICON)!=0));
					/* save combobox */
					{	int index;
						index=SendDlgItemMessage(hwndDlg,IDC_COMBO_EXTRAIMGFLAGCOLUMN,CB_GETCURSEL,0,0);
						if(index!=LB_ERR) DBWriteContactSettingByte(NULL,"Flags","ExtraImgFlagColumn",(BYTE)SendDlgItemMessage(hwndDlg,IDC_COMBO_EXTRAIMGFLAGCOLUMN,CB_GETITEMDATA,index,0));
					}
					return TRUE;
			}
			break;
	}
	return FALSE;
}

static int ExtraImgOptInit(WPARAM wParam,LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp={0};
	UNREFERENCED_PARAMETER(lParam);
	odp.cbSize=sizeof(odp);
	odp.hInstance=hInst;
	odp.pszTemplate=MAKEINTRESOURCEA(IDD_OPT_EXTRAIMG);
	odp.position=900000002;
	odp.ptszGroup=_T("Contact List");  /* autotranslated */
	odp.ptszTitle=_T("Country Flags"); /* autotranslated */
	odp.ptszTab=_T("Country Flags");   /* autotranslated, can be made a tab */
	odp.flags=ODPF_BOLDGROUPS|ODPF_TCHAR;
	odp.pfnDlgProc=ExtraImgOptDlgProc;
	CallService(MS_OPT_ADDPAGE,wParam,(LPARAM)&odp);
	return 0;
}

/************************* Misc ***********************************/

static int ExtraImgSettingChanged(WPARAM wParam,LPARAM lParam)
{
	DBCONTACTWRITESETTING *cws=(DBCONTACTWRITESETTING*)lParam;
	if((HANDLE)wParam==NULL && !lstrcmpA(cws->szModule,"Flags")) {
		register BOOL val=FALSE;
		if(cws->value.type!=DBVT_DELETED) val=(cws->value.bVal!=0);
		if(!lstrcmpA(cws->szSetting,"ShowStatusFlagIcon")) {
			/* Status Icon */
			UpdateStatusIcons(val);
		}
		else if(!lstrcmpA(cws->szSetting,"ShowExtraImgFlagIcon") || !lstrcmpA(cws->szSetting,"ExtraImgFlagColumn")) {
			/* Extra Image */
			if(ServiceExists(MS_CLIST_EXTRA_SET_ICON)) {
				if(val) EnsureExtraImages();
				else RemoveExtraImages();
			}
		}
	}
	return 0;
}

static int ExtraImgModulesLoaded(WPARAM wParam,LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	/* Options */
	if(ServiceExists("DBEditorpp/RegisterSingleModule"))
		CallService("DBEditorpp/RegisterSingleModule",(WPARAM)"Flags",0);
	/* Extra Image */
	if(ServiceExists(MS_CLIST_EXTRA_SET_ICON)) {
		hHookExtraRebuild=HookEvent(ME_CLIST_EXTRA_LIST_REBUILD,ExtraListRebuild);
		hHookExtraApply=HookEvent(ME_CLIST_EXTRA_IMAGE_APPLY,ExtraImageApply);
	}
	/* Status Icon */
	hHookMsgWndEvent=HookEvent(ME_MSG_WINDOWEVENT,MsgWndEvent);
	return 0;
}

void InitExtraImg(void)
{
	/* Services */
	hServiceDetectContactOrigin=CreateServiceFunction(MS_FLAGS_DETECTCONTACTORIGINCOUNTRY,ServiceDetectContactOriginCountry);
	/* Misc */
	hHookModulesLoaded=HookEvent(ME_SYSTEM_MODULESLOADED,ExtraImgModulesLoaded);
	hHookSettingChanged=HookEvent(ME_DB_CONTACT_SETTINGCHANGED,ExtraImgSettingChanged);
	/* Extra Image */
	hHookExtraRebuild=hHookExtraApply=NULL;
	/* Status icon */
	hHookMsgWndEvent=NULL;
	hHookIconsChanged=HookEvent(ME_SKIN2_ICONSCHANGED,StatusIconsChanged);
	/* Options */
	hHookOptInit=HookEvent(ME_OPT_INITIALISE,ExtraImgOptInit);
}

void UninitExtraImg(void)
{
	/* Services */
	DestroyServiceFunction(hServiceDetectContactOrigin);
	/* Misc */
	UnhookEvent(hHookModulesLoaded);
	UnhookEvent(hHookSettingChanged);
	/* Extra Image */
	UnhookEvent(hHookSettingChanged);
	UnhookEvent(hHookExtraRebuild);
	UnhookEvent(hHookExtraApply);
	/* Status icon */
	UnhookEvent(hHookMsgWndEvent);
	UnhookEvent(hHookIconsChanged);
	/* Options */
	UnhookEvent(hHookOptInit);
}
