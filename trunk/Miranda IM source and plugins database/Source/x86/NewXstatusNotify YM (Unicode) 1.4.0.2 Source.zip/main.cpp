/*
	NewXstatusNotify YM - Plugin for Miranda IM
	Copyright (c) 2001-2004 Luca Santarelli
	Copyright (c) 2005-2007 Vasilich
	Copyright (c) 2007-2010 yaho

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "common.h"
#include "indsnd.h"
#include "options.h"
#include "popup.h"
#include "utils.h"
#include "version.h"
#include "xstatus.h"

HINSTANCE hInst;
PLUGINLINK *pluginLink;

MM_INTERFACE mmi = {0};
UTF8_INTERFACE utfi = {0};
LIST_INTERFACE li = {0};

SortedList *eventList;
SortedList *xstatusList;

HANDLE hEnableDisableMenu, hOptionsInitialize, hModulesLoaded, hUserInfoInitialise;
HANDLE hContactSettingChanged, hHookContactStatusChanged, hContactStatusChanged;
HANDLE hStatusModeChange, hProtoAck, hServiceMenu = NULL;
HANDLE hMessageWindowOpen;

char szMetaModuleName[256] = {0};
STATUS StatusList[STATUS_COUNT];
UINT_PTR uintXstatusTimerId = 0;
HWND SecretWnd;
CRITICAL_SECTION cs;

extern OPTIONS opt;

PLUGININFOEX pluginInfoEx = {
	sizeof(PLUGININFOEX),
#ifdef _WIN64
	"NewXstatusNotify YM x64",
#else
	"NewXstatusNotify YM",
#endif
	__VERSION_DWORD,
	"Notifies you when a contact changes his/her (X)status.",
	"Luca Santarelli, Vasilich, yaho",
	"yaho@miranda-easy.net",
	"� 2001-2004 Luca Santarelli, 2005-2007 Vasilich, 2007-2010 yaho",
	"http://miranda-easy.net/mods.php",
	UNICODE_AWARE,
	DEFMOD_RNDUSERONLINE,
	MIID_NXSN
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst = hinstDLL;
	DisableThreadLibraryCalls(hInst);
	return TRUE;
}

extern "C" __declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	if (mirandaVersion < PLUGIN_MAKE_VERSION(0, 9, 0, 0))
		return NULL;

	return &pluginInfoEx;
}

static const MUUID interfaces[] = {MIID_USERONLINE, MIID_LAST};
extern "C" __declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

BYTE GetGender(HANDLE hContact)
{
	char *szProto =(char *)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);
	if (szProto)
	{
		switch (DBGetContactSettingByte(hContact, szProto, "Gender", 0)) 
		{
			case 'M': case 'm':
				return GENDER_MALE;
			case 'F': case 'f':
				return GENDER_FEMALE;
			default:
				return GENDER_UNSPECIFIED;
		}
	}

	return GENDER_UNSPECIFIED;
}

XSTATUSCHANGE *findContact(HANDLE hContact)
{
	for (int i = 0; i < xstatusList->realCount; i++)
	{
		XSTATUSCHANGE *xsc = (XSTATUSCHANGE *)xstatusList->items[i];
		if (xsc->hContact == hContact)
		{
			li.List_Remove(xstatusList, i);
			return xsc;
		}
	}

	return NULL;
}

VOID CALLBACK XstatusTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime) 
{
	int res = KillTimer(NULL, uintXstatusTimerId);
	uintXstatusTimerId = 0;

	for (int i = 0; i < xstatusList->realCount; i++)
		ExtraStatusChanged((XSTATUSCHANGE *)xstatusList->items[i]);

	li.List_Destroy(xstatusList);
}

int CheckExtraStatus(DBCONTACTWRITESETTING *cws, HANDLE hContact)
{
	char *szProto = (char *)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

	if (ProtoServiceExists(szProto, JS_PARSE_XMPP_URI))
	{
		if (strstr(cws->szSetting, "/mood/") || strstr(cws->szSetting, "/activity/")) // Jabber mood or activity changed
		{
			int type = strstr(cws->szSetting, "/mood/") ? TYPE_JABBER_MOOD : TYPE_JABBER_ACTIVITY; 
			if (strstr(cws->szSetting, "title")) 
			{
				XSTATUSCHANGE *xsc;
				if (cws->value.type == DBVT_ASCIIZ && cws->value.pszVal[0] == 0)
					xsc = NewXstatusChange(hContact, szProto, type, NOTIFY_REMOVE, NULL, NULL);
				else
					xsc = NewXstatusChange(hContact, szProto, type, NOTIFY_NEW_XSTATUS, db2t(&cws->value), NULL);

				li.List_Insert(xstatusList, xsc, xstatusList->realCount);
				if (uintXstatusTimerId == 0)
					uintXstatusTimerId = SetTimer(NULL, 0x77, NOTIFY_INTERVAL_JABBER, XstatusTimerProc);
			}
			else if (strstr(cws->szSetting, "text"))
			{
				XSTATUSCHANGE *xsc = NULL;
				if (xsc = findContact(hContact)) 
				{
					if (xsc->action != NOTIFY_REMOVE)
						xsc->swzText = db2t(&cws->value);
				}
				else
				{
					xsc = NewXstatusChange(hContact, szProto, type, NOTIFY_NEW_MESSAGE, NULL, db2t(&cws->value));
				}

				if (xsc != NULL) 
					ExtraStatusChanged(xsc);
			}

			return 1;
		}
	}
	else if (strstr(cws->szSetting, "XStatus"))
	{
		if (strcmp(cws->szSetting, "XStatusName") == 0)
		{
			XSTATUSCHANGE *xsc;
			if (xsc = findContact(hContact)) 
				FreeXstatusChange(xsc);

			if (cws->value.type == DBVT_DELETED)
			{
				xsc = NewXstatusChange(hContact, szProto, TYPE_ICQ_XSTATUS, NOTIFY_REMOVE, NULL, NULL);
			}
			else
			{

				if (cws->value.pszVal[0] == 0)
				{
					TCHAR buff[64];
					int statusID = DBGetContactSettingByte(hContact, szProto, "XStatusId", -1);
					GetDefaultXstatusName(statusID, szProto, buff);
					xsc = NewXstatusChange(hContact, szProto, TYPE_ICQ_XSTATUS, NOTIFY_NEW_XSTATUS, mir_tstrdup(buff), NULL);
				}
				else
				{
					xsc = NewXstatusChange(hContact, szProto, TYPE_ICQ_XSTATUS, NOTIFY_NEW_XSTATUS, db2t(&cws->value), NULL);
				}

			}

			li.List_Insert(xstatusList, xsc, xstatusList->realCount);

			if (uintXstatusTimerId != 0)
			{
				KillTimer(NULL, uintXstatusTimerId);
				uintXstatusTimerId = 0;
			}
			uintXstatusTimerId = SetTimer(NULL, 0x77, NOTIFY_INTERVAL_ICQ, XstatusTimerProc);
		}
		else if (strstr(cws->szSetting, "XStatusMsg"))
		{
			if (cws->value.type != DBVT_DELETED)
			{
				XSTATUSCHANGE *xsc;
				if (xsc = findContact(hContact)) 
				{
					if (xsc->action != NOTIFY_REMOVE && cws->value.pszVal[0] != 0)
						xsc->swzText = db2t(&cws->value);

					li.List_Insert(xstatusList, xsc, xstatusList->realCount);
				}
				else
				{
					xsc = NewXstatusChange(hContact, szProto, TYPE_ICQ_XSTATUS, NOTIFY_NEW_MESSAGE, NULL, db2t(&cws->value));
					li.List_Insert(xstatusList, xsc, xstatusList->realCount);

					if (uintXstatusTimerId != 0)
					{
						KillTimer(NULL, uintXstatusTimerId);
						uintXstatusTimerId = 0;
					}
					uintXstatusTimerId = SetTimer(NULL, 0x77, NOTIFY_INTERVAL_ICQ, XstatusTimerProc);
				}

			}
		}

		return 1;
	}

	return 0;
}

int ContactSettingChanged(WPARAM wParam, LPARAM lParam)
{
	DBCONTACTWRITESETTING *cws = (DBCONTACTWRITESETTING *)lParam;
	HANDLE hContact = (HANDLE)wParam;
	WORD newStatus = 0, oldStatus = 0;
	DWORD dwStatuses = 0;

	if (hContact == NULL) 
		return 0;

	char *szProto = (char *)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);
	if (szProto == NULL) return 0;

	if (DBGetContactSettingWord(hContact, szProto, "Status", ID_STATUS_OFFLINE) != ID_STATUS_OFFLINE)
	{
		if (CheckExtraStatus(cws, hContact))
			return 0;
	}

	if (strcmp(cws->szSetting, "Status") == 0) 
	{
		newStatus = cws->value.wVal;
		if (newStatus < ID_STATUS_MIN || newStatus > ID_STATUS_MAX) 
			return 0;

		DBVARIANT dbv = {0};
		if (!DBGetContactSettingString(hContact, "Protocol", "p", &dbv))
		{
			BOOL temp = strcmp(cws->szModule, dbv.pszVal) != 0;
			DBFreeVariant(&dbv);
			if (temp) return 0;
		}

		oldStatus = DBGetContactSettingRangedWord(hContact, "UserOnline", "OldStatus", ID_STATUS_OFFLINE, ID_STATUS_MIN, ID_STATUS_MAX);
		if (oldStatus == newStatus) 
			return 0;

		//If we get here, the two stauses differ, so we can proceed.
		DBWriteContactSettingWord(hContact, "UserOnline", "OldStatus", newStatus);

		//If *Miranda* ignores the UserOnline event, exit!
		if (CallService(MS_IGNORE_ISIGNORED, (WPARAM)hContact, IGNOREEVENT_USERONLINE)) 
			return 0;

		//If we get here, we have to notify the Hooks.
		NotifyEventHooks(hHookContactStatusChanged, (WPARAM)wParam, (LPARAM)MAKELPARAM(oldStatus, newStatus));
	}

	return 0;
}

int StatusModeChanged(WPARAM wParam, LPARAM lParam)
{
	char *szProto = (char *)lParam;
	if (opt.AutoDisable && (!opt.OnlyGlobalChanges || szProto == NULL)) 
	{
		if (opt.DisablePopupGlobally && ServiceExists(MS_POPUP_QUERY)) 
		{
			char setting[12];
			wsprintfA(setting, "p%d", wParam);
			BYTE disablePopup = DBGetContactSettingByte(0, MODULE, setting, 0);
			if (disablePopup && !opt.isPopupDisabled) 
			{	
				DBWriteContactSettingByte(0, MODULE, "OldPopup", CallService(MS_POPUP_QUERY, PUQS_GETSTATUS, 0));
				CallService(MS_POPUP_QUERY, PUQS_DISABLEPOPUPS, 0);
				opt.isPopupDisabled = 1;
			} 
			else if (!disablePopup && opt.isPopupDisabled) 
			{
				BYTE popupState = (BYTE)CallService(MS_POPUP_QUERY, PUQS_GETSTATUS, 0);
				if (popupState == 0) 
				{
					if (DBGetContactSettingByte(0, MODULE, "OldPopup", 1) == 1)
						CallService(MS_POPUP_QUERY, PUQS_ENABLEPOPUPS, 0);
					else
						CallService(MS_POPUP_QUERY, PUQS_DISABLEPOPUPS, 0);
				}

				opt.isPopupDisabled = 0;
			} 
		}

		if (opt.DisableSoundGlobally) 
		{
			char setting[12];
			wsprintfA(setting, "s%d", wParam);
			BYTE disableSound = DBGetContactSettingByte(0, MODULE, setting, 0);
			if (disableSound && !opt.isSoundDisabled) 
			{				
				DBWriteContactSettingByte(0, MODULE, "OldSound", DBGetContactSettingByte(NULL, "Skin", "UseSound", 1));
				DBWriteContactSettingByte(0, "Skin", "UseSound", 0);	
				opt.isSoundDisabled = 1;
			} 
			else if (!disableSound&& opt.isSoundDisabled) 
			{
				if (DBGetContactSettingByte(0, "Skin", "UseSound", 1) == 0)
					DBWriteContactSettingByte(0, "Skin", "UseSound", DBGetContactSettingByte(0, MODULE, "OldSound", 1));

				opt.isSoundDisabled = 0;
			} 
		}
	}

	return 0;
}

int ContactStatusChanged(WPARAM wParam, LPARAM lParam)
{
	WORD oldStatus = LOWORD(lParam);
	WORD newStatus = HIWORD(lParam);
	HANDLE hContact = (HANDLE)wParam;
	char buff[8], szSubProto[64] = {0}; 

	char *szProto = (char *)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)wParam, 0);
	if (szProto == NULL || opt.TempDisable) 
		return 0;

	WORD myStatus = (WORD)CallProtoService(szProto, PS_GETSTATUS, (WPARAM)0, (LPARAM)0); 

	if (strcmp(szProto, szMetaModuleName) == 0) //this contact is Meta
	{
		HANDLE hSubContact = (HANDLE)CallService(MS_MC_GETMOSTONLINECONTACT, (WPARAM)hContact, 0); 
		strcpy(szSubProto, (char *)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hSubContact,0));
		
		if (newStatus == ID_STATUS_OFFLINE)			
		{
			// read last online proto for metaconatct if exists, 
			// to avoid notifying when meta went offline but default contact's proto still online
			DBVARIANT dbv; 
		    if (!DBGetContactSettingString(hContact, szProto, "LastOnline", &dbv))
			{
	            strcpy(szSubProto, dbv.pszVal);
				DBFreeVariant(&dbv);
			}				
		}
		else
			DBWriteContactSettingString(hContact, szProto, "LastOnline", szSubProto);

		if (!DBGetContactSettingByte(0, MODULE, szSubProto, 1))	
			return 0;     

		strcpy(szProto, szSubProto);
	}
	else
	{
		if (myStatus == ID_STATUS_OFFLINE || !DBGetContactSettingByte(0, MODULE, szProto, 1)) 
			return 0;
	}
	
	if (!opt.FromOffline || oldStatus != ID_STATUS_OFFLINE) // Either it wasn't a change from Offline or we didn't enable that.
	{ 
		wsprintfA(buff, "%d", newStatus); 
		if (DBGetContactSettingByte(0, MODULE, buff, 1) == 0) 
			return 0; // "Notify when a contact changes to one of..." is unchecked
	}
		
	if (!opt.HiddenContactsToo && (DBGetContactSettingByte(hContact, "CList", "Hidden", 0) == 1)) 
		return 0;

	// we don't want to be notified if new chatroom comes online
	if (DBGetContactSettingByte(hContact, szProto, "ChatRoom", 0) == 1)
		return 0;

	// check if that proto from which we received statuschange notification, isn't in autodisable list
	char statusIDs[12], statusIDp[12];
	if (opt.AutoDisable)
	{
		wsprintfA(statusIDs, "s%d", myStatus);
		wsprintfA(statusIDp, "p%d", myStatus);
		opt.EnableSounds = DBGetContactSettingByte(0, MODULE, statusIDs, 1) ? FALSE : TRUE;
		opt.EnablePopups = DBGetContactSettingByte(0, MODULE, statusIDp, 1) ? FALSE : TRUE;
	}

	if (opt.EnablePopups && DBGetContactSettingByte(hContact, MODULE, "EnablePopups", 1)) 
	{
		TCHAR swzStatusText[MAX_SECONDLINE] = {0};
		POPUPDATAT ppd = {0};
		ppd.lchContact = hContact;
		ppd.lchIcon = LoadSkinnedProtoIcon(szProto, newStatus);
		_tcscpy(ppd.lptzContactName, (TCHAR *)CallService(MS_CLIST_GETCONTACTDISPLAYNAME, (WPARAM)hContact, GCMDF_TCHAR));
		
		if (opt.ShowGroup) //add group name to popup title
		{
			DBVARIANT dbv = {0};
			if (!DBGetContactSettingTString(hContact, "CList", "Group", &dbv))
			{
				_tcscat(ppd.lptzContactName, _T(" ("));
				_tcscat(ppd.lptzContactName, dbv.ptszVal);
				_tcscat(ppd.lptzContactName, _T(")"));
				DBFreeVariant(&dbv);
			}
		}

		if (opt.ShowStatus)
		{
			if (opt.UseAlternativeText)
			{
				switch (GetGender(hContact)) 
				{
					case GENDER_MALE:
						_tcsncpy(swzStatusText, StatusList[Index(newStatus)].lpzMStatusText, MAX_STATUSTEXT); 
						break;
					case GENDER_FEMALE:
						_tcsncpy(swzStatusText, StatusList[Index(newStatus)].lpzFStatusText, MAX_STATUSTEXT); 
						break;
					case GENDER_UNSPECIFIED:
						_tcsncpy(swzStatusText, StatusList[Index(newStatus)].lpzUStatusText, MAX_STATUSTEXT); 
						break;
				}
			}
			else
			{
				_tcsncpy(swzStatusText, StatusList[Index(newStatus)].lpzStandardText, MAX_STATUSTEXT);
			}

			//Now we add the old status.
			if (opt.ShowPreviousStatus) 
			{
				TCHAR szAux[MAX_STATUSTEXT];
				wsprintf(szAux, TranslateTS(STRING_SHOWPREVIOUSSTATUS), StatusList[Index(oldStatus)].lpzStandardText);
				_tcscat(_tcscat(swzStatusText, _T(" ")), szAux);
			}

			if (opt.ReadAwayMsg && 
				myStatus != ID_STATUS_INVISIBLE && 
				StatusHasAwayMessage(szProto, newStatus))
			{
				DBWriteContactSettingTString(hContact, MODULE, "LastPopupText", swzStatusText);
			}

		}

		_tcscat(ppd.lptzText, swzStatusText);

		switch (opt.Colors)
		{
			case POPUP_COLOR_OWN:
				ppd.colorBack = StatusList[Index(newStatus)].colorBack;
				ppd.colorText = StatusList[Index(newStatus)].colorText;
				break;
			case POPUP_COLOR_WINDOWS:
				ppd.colorBack = GetSysColor(COLOR_BTNFACE);
				ppd.colorText = GetSysColor(COLOR_WINDOWTEXT);
				break;
			case POPUP_COLOR_POPUP:
				ppd.colorBack = ppd.colorText = 0;
				break;
		}

		ppd.PluginWindowProc = (WNDPROC)PopupDlgProc;

		PLUGINDATA *pdp = (PLUGINDATA *)mir_alloc(sizeof(PLUGINDATA));
		pdp->oldStatus = oldStatus;
		pdp->newStatus = newStatus;
		pdp->hAwayMsgHook = NULL;
		pdp->hAwayMsgProcess = NULL;

		//Now that the plugin data has been filled, we add it to the PopUpData.
		ppd.PluginData = pdp;
		ppd.iSeconds = opt.PopupTimeout; 
		PUAddPopUpT(&ppd);
	}

	if (opt.BlinkIcon)
	{
		CLISTEVENT cle = {0};
		TCHAR swzTooltip[256];

		cle.cbSize = sizeof(cle);
		cle.flags = CLEF_ONLYAFEW | CLEF_TCHAR;
		cle.hContact = hContact;
		cle.hDbEvent = hContact;
		if (opt.BlinkIcon_Status)
			cle.hIcon = LoadSkinnedProtoIcon(szProto, newStatus);
		else
			cle.hIcon = LoadSkinnedIcon(SKINICON_OTHER_USERONLINE);
		cle.pszService = "UserOnline/Description";
		wsprintf(swzTooltip, TranslateT("%s is now %s"), (TCHAR *)CallService(MS_CLIST_GETCONTACTDISPLAYNAME, (WPARAM)hContact, GCDNF_TCHAR), StatusList[Index(newStatus)].lpzStandardText);
		cle.ptszTooltip = swzTooltip;
		CallService(MS_CLIST_ADDEVENT, 0, (LPARAM)&cle);
	}

	if (opt.Log) 
	{
		TCHAR swzName[64], swzStatus[MAX_STATUSTEXT], swzOldStatus[MAX_STATUSTEXT];
		TCHAR swzDate[MAX_STATUSTEXT], swzTime[MAX_STATUSTEXT];
		TCHAR swzText[1024];

		_tcscpy(swzName, (TCHAR *)CallService(MS_CLIST_GETCONTACTDISPLAYNAME, (WPARAM)hContact, GCDNF_TCHAR));
		_tcsncpy(swzStatus, StatusList[Index(newStatus)].lpzStandardText, MAX_STATUSTEXT);
		_tcsncpy(swzOldStatus, StatusList[Index(oldStatus)].lpzStandardText, MAX_STATUSTEXT);
		GetTimeFormat(LOCALE_USER_DEFAULT, 0, NULL,_T("HH':'mm"), swzTime, SIZEOF(swzTime));
		GetDateFormat(LOCALE_USER_DEFAULT, 0, NULL,_T("dd/MM/yyyy"), swzDate, SIZEOF(swzDate));
		wsprintf(swzText, TranslateT("%s, %s. %s changed to: %s (was: %s).\r\n"), swzDate, swzTime, swzName, swzStatus, swzOldStatus);
		LogToFile(swzText);
	}
		

	if (opt.EnableSounds &&
		DBGetContactSettingByte(0, "Skin", "UseSound", TRUE) &&
		DBGetContactSettingByte(hContact, MODULE, "EnableSounds", 1))
	{
		if (opt.UseIndSnd)
		{
			TCHAR swzSound[MAX_PATH] = {0};
			DBVARIANT dbv = {0};
			if (!DBGetContactSettingTString(hContact, MODULE, "UserFromOffline", &dbv)) 
			{			
				if (oldStatus == ID_STATUS_OFFLINE)
					_tcscpy(swzSound, dbv.ptszVal);
				DBFreeVariant(&dbv);
			}
			else // check other individual sounds 
			{
				if (!DBGetContactSettingTString(hContact, MODULE, StatusList[Index(newStatus)].lpzSkinSoundName, &dbv))
					lstrcpy(swzSound, dbv.ptszVal);
				DBFreeVariant(&dbv);
			}

			if (swzSound[0] != 0)
			{
				//Now make path to IndSound absolute, as it isn't registered
				TCHAR swzSoundPath[MAX_PATH];
				CallService(MS_UTILS_PATHTOABSOLUTET, (WPARAM)swzSound, (LPARAM)swzSoundPath);
				PlaySound(swzSoundPath, NULL, SND_ASYNC | SND_FILENAME | SND_NOSTOP);
				return 0;
			}	
		}

		char szSoundFile[MAX_PATH] = { 0 };
		DBVARIANT dbv = {0};

		if (!DBGetContactSettingByte(0, "SkinSoundsOff", "UserFromOffline", 0) && 
		    !DBGetContactSettingString(0,"SkinSounds", "UserFromOffline", &dbv) &&
			oldStatus == ID_STATUS_OFFLINE)
		{					 
			strcpy(szSoundFile, "UserFromOffline");
			DBFreeVariant(&dbv);
		}
		else if (!DBGetContactSettingByte(0, "SkinSoundsOff", StatusList[Index(newStatus)].lpzSkinSoundName, 0) && 
			     !DBGetContactSetting(0, "SkinSounds", StatusList[Index(newStatus)].lpzSkinSoundName, &dbv))
		{
			strcpy(szSoundFile, StatusList[Index(newStatus)].lpzSkinSoundName);
			DBFreeVariant(&dbv);
		}

		if (szSoundFile[0] != 0)
			SkinPlaySound(szSoundFile);
	}

	return 0;
} 

void InitStatusList() 
{
	int index = 0;
	//Online
	index = Index(ID_STATUS_ONLINE);
	StatusList[index].ID = ID_STATUS_ONLINE;
	StatusList[index].icon = SKINICON_STATUS_ONLINE;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) is back online!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) is back online!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) is back online!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("Online"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserOnline", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Online"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "global.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40072bg", COLOR_BG_AVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40072tx", COLOR_TX_DEFAULT);

	//Offline
	index = Index(ID_STATUS_OFFLINE);
	StatusList[index].ID = ID_STATUS_OFFLINE;
	StatusList[index].icon = SKINICON_STATUS_OFFLINE;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) went offline! :("), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) went offline! :("), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) went offline! :("), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("Offline"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserOffline", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Offline"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "offline.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40071bg", COLOR_BG_NAVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40071tx", COLOR_TX_DEFAULT);

	//Invisible
	index = Index(ID_STATUS_INVISIBLE);
	StatusList[index].ID = ID_STATUS_INVISIBLE;
	StatusList[index].icon = SKINICON_STATUS_INVISIBLE;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) hides in shadows..."), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) hides in shadows..."), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) hides in shadows..."), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("Invisible"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserInvisible", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Invisible"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "invisible.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40078bg", COLOR_BG_AVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40078tx", COLOR_TX_DEFAULT);

	//Free for chat
	index = Index(ID_STATUS_FREECHAT);
	StatusList[index].ID = ID_STATUS_FREECHAT;
	StatusList[index].icon = SKINICON_STATUS_FREE4CHAT;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) feels talkative!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) feels talkative!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) feels talkative!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("Free for chat"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserFreeForChat", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Free For Chat"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "free4chat.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40077bg", COLOR_BG_AVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40077tx", COLOR_TX_DEFAULT);

	//Away
	index = Index(ID_STATUS_AWAY);
	StatusList[index].ID = ID_STATUS_AWAY;
	StatusList[index].icon = SKINICON_STATUS_AWAY;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) went Away"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) went Away"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) went Away"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("Away"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserAway", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Away"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "away.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40073bg", COLOR_BG_NAVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40073tx", COLOR_TX_DEFAULT);

	//NA
	index = Index(ID_STATUS_NA);
	StatusList[index].ID = ID_STATUS_NA;
	StatusList[index].icon = SKINICON_STATUS_NA;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) isn't there anymore!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) isn't there anymore!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) isn't there anymore!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("NA"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserNA", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Not Available"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "na.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40075bg", COLOR_BG_NAVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40075tx", COLOR_TX_DEFAULT);

	//Occupied
	index = Index(ID_STATUS_OCCUPIED);
	StatusList[index].ID = ID_STATUS_OCCUPIED;
	StatusList[index].icon = SKINICON_STATUS_OCCUPIED;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) has something else to do."), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) has something else to do."), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) has something else to do."), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("Occupied"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserOccupied", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Occupied"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "occupied.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40076bg", COLOR_BG_NAVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40076tx", COLOR_TX_DEFAULT);

	//DND
	index = Index(ID_STATUS_DND);
	StatusList[index].ID = ID_STATUS_DND;
	StatusList[index].icon = SKINICON_STATUS_DND;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) doesn't want to be disturbed!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) doesn't want to be disturbed!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) doesn't want to be disturbed!"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("DND"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserDND", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Do Not Disturb"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "dnd.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40074bg", COLOR_BG_NAVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40074tx", COLOR_TX_DEFAULT);

	//OutToLunch
	index = Index(ID_STATUS_OUTTOLUNCH);
	StatusList[index].ID = ID_STATUS_OUTTOLUNCH;
	StatusList[index].icon = SKINICON_STATUS_OUTTOLUNCH;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) is eating something"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) is eating something"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) is eating something"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("Out to lunch"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserOutToLunch", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: Out To Lunch"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "lunch.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40080bg", COLOR_BG_NAVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40080tx", COLOR_TX_DEFAULT);

	//OnThePhone
	index = Index(ID_STATUS_ONTHEPHONE);
	StatusList[index].ID = ID_STATUS_ONTHEPHONE;
	StatusList[index].icon = SKINICON_STATUS_ONTHEPHONE;
	lstrcpyn(StatusList[index].lpzMStatusText, TranslateT("(M) had to answer the phone"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzFStatusText, TranslateT("(F) had to answer the phone"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzUStatusText, TranslateT("(U) had to answer the phone"), MAX_STATUSTEXT);
	lstrcpyn(StatusList[index].lpzStandardText, TranslateT("On the phone"), MAX_STANDARDTEXT);
	lstrcpynA(StatusList[index].lpzSkinSoundName, "UserOnThePhone", MAX_SKINSOUNDNAME);
	lstrcpynA(StatusList[index].lpzSkinSoundDesc, Translate("User: On The Phone"), MAX_SKINSOUNDDESC);
	lstrcpynA(StatusList[index].lpzSkinSoundFile, "phone.wav", MAX_PATH);
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40079bg", COLOR_BG_NAVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40079tx", COLOR_TX_DEFAULT);

	//Extra status
	index = Index(ID_STATUS_EXTRASTATUS);
	StatusList[index].ID = ID_STATUS_EXTRASTATUS;
	StatusList[index].colorBack = DBGetContactSettingDword(NULL, MODULE, "40081bg", COLOR_BG_AVAILDEFAULT);
	StatusList[index].colorText = DBGetContactSettingDword(NULL, MODULE, "40081tx", COLOR_TX_DEFAULT);
}

void InitUpdaterSupport()
{
#ifndef _WIN64
	if (ServiceExists(MS_UPDATE_REGISTER)) 
	{
		Update update = {0};
		char szVersion[16];

		update.cbSize = sizeof(Update);
		update.szComponentName = pluginInfoEx.shortName;
		update.pbVersion = (BYTE *)CreateVersionString(pluginInfoEx.version, szVersion);
		update.cpbVersion = strlen((char *)update.pbVersion);
#ifdef _UNICODE
		update.szUpdateURL = "http://miranda-easy.net/addons/updater/nxsn-ym.zip";
#else
		update.szUpdateURL = "http://miranda-easy.net/addons/updater/nxsn-ym_ansi.zip";
#endif
		update.szVersionURL = "http://miranda-easy.net/addons/updater/nxsn_version.txt";
		update.pbVersionPrefix = (BYTE *)"NewXstatusNotify YM ";
		update.cpbVersionPrefix = strlen((char *)update.pbVersionPrefix);

		CallService(MS_UPDATE_REGISTER, 0, (WPARAM)&update);
	}
#endif
}

INT_PTR EnableDisableMenuCommand(WPARAM wParam, LPARAM lParam) 
{
	CLISTMENUITEM mi = {0};
	mi.cbSize = sizeof(mi);

	if (opt.TempDisable)
	{
		mi.ptszName = _T("Disable status &notification");
		mi.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_MAINMENU_ON));
	}
	else 
	{
		mi.ptszName = _T("Enable status &notification");
		mi.hIcon = LoadIcon(hInst,MAKEINTRESOURCE(IDI_MAINMENU_OFF));
	}

	mi.flags = CMIM_ICON | CMIM_NAME | CMIF_TCHAR;
	CallService(MS_CLIST_MODIFYMENUITEM, (WPARAM)hEnableDisableMenu, (LPARAM)&mi);

	opt.TempDisable = !opt.TempDisable;	
	DBWriteContactSettingByte(0, MODULE, "TempDisable", opt.TempDisable);
	return 0;
}

VOID CALLBACK ConnectionTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime) 
{
	char szProto[256];
	DWORD dwResult = 0;

	if (uMsg == WM_TIMER)
	{
		//We've received a timer message: enable the popups for a specified protocol.
		KillTimer(hwnd, idEvent);
		dwResult = (DWORD)GetAtomNameA((ATOM)idEvent, szProto, sizeof(szProto));
		if (dwResult) DBWriteContactSettingByte(0, MODULE, szProto, 1);
	}
}

int ProtoAck(WPARAM wParam,LPARAM lParam)
{
	ACKDATA *ack = (ACKDATA *)lParam;

	if (ack->type == ACKTYPE_STATUS)
	{
		WORD newStatus = (WORD)ack->lParam;
		WORD oldStatus = (WORD)ack->hProcess;
		char *szProto = (char *)ack->szModule;

		if (oldStatus == newStatus) 
			return 0;

		if (newStatus == ID_STATUS_OFFLINE) 
		{
			//The protocol switched to offline. Disable the popups for this protocol
			DBWriteContactSettingByte(NULL, MODULE, szProto, 0);
		}
		else if (oldStatus < ID_STATUS_ONLINE && newStatus >= ID_STATUS_ONLINE) 
		{
			//The protocol changed from a disconnected status to a connected status.
			//Enable the popups for this protocol.
			int idTimer = AddAtomA(szProto);
			if (idTimer) 
			{
				UINT ConnectTimer;
				char TimerProtoName[256];
				mir_snprintf(TimerProtoName, sizeof(TimerProtoName), "ConnectionTimeout%s", szProto);
				ConnectTimer = DBGetContactSettingDword(0, MODULE, TimerProtoName, DBGetContactSettingDword(0, MODULE, "ConnectionTimeout", 10000));
				SetTimer(SecretWnd, idTimer, ConnectTimer, ConnectionTimerProc);
			}
		}
	}

	return 0;
}

void InitMainMenuItem() 
{
	hServiceMenu = (HANDLE)CreateServiceFunction(MS_STATUSCHANGE_MENUCOMMAND, EnableDisableMenuCommand);

	CLISTMENUITEM mi = { 0 };
	mi.cbSize = sizeof(mi);
	mi.flags = CMIF_TCHAR;
	if (opt.TempDisable)
	{
		mi.ptszName = _T("Enable status &notification");
		mi.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_MAINMENU_OFF));
	}
	else 
	{
		mi.ptszName = _T("Disable status &notification");
		mi.hIcon = LoadIcon(hInst,MAKEINTRESOURCE(IDI_MAINMENU_ON));
	}

	if (ServiceExists(MS_POPUP_ADDPOPUP)) 
		mi.ptszPopupName = _T("PopUps");
	else
		mi.ptszPopupName = NULL;

	mi.pszService = MS_STATUSCHANGE_MENUCOMMAND;
	hEnableDisableMenu = (HANDLE)CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);
}

int ModulesLoaded(WPARAM wParam, LPARAM lParam) 
{
	InitUpdaterSupport();
	InitMainMenuItem();

	eventList = li.List_Create(0, 10);
	xstatusList = li.List_Create(0, 10);

	hUserInfoInitialise = HookEvent(ME_USERINFO_INITIALISE, UserInfoInitialise);
	hContactStatusChanged = HookEvent(ME_STATUSCHANGE_CONTACTSTATUSCHANGED, ContactStatusChanged);
	hMessageWindowOpen = HookEvent(ME_MSG_WINDOWEVENT, OnWindowEvent);

	SecretWnd = CreateWindowEx(WS_EX_TOOLWINDOW,_T("static"),_T("ConnectionTimerWindow"),0,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,HWND_DESKTOP,
		NULL,hInst,NULL);

	int count = 0;
	PROTOACCOUNT **accounts = NULL;
	CallService(MS_PROTO_ENUMACCOUNTS, (WPARAM)&count, (LPARAM)&accounts);
	for (int i = 0; i < count; i++) 
	{
		if (IsAccountEnabled(accounts[i])) 
			DBWriteContactSettingByte(NULL, MODULE, accounts[i]->szModuleName, 0);
	}

	if (ServiceExists(MS_MC_GETPROTOCOLNAME))
		strcpy(szMetaModuleName, (char *)CallService(MS_MC_GETPROTOCOLNAME, 0, 0));

	return 0;
}

extern "C" int __declspec(dllexport) Load(PLUGINLINK *link)
{
	pluginLink = link;
	mir_getMMI(&mmi);
	mir_getUTFI(&utfi);
	mir_getLI(&li);

	InitializeCriticalSection(&cs);

	//"Service" Hook, used when the DB settings change: we'll monitor the "status" setting.
	hContactSettingChanged = HookEvent(ME_DB_CONTACT_SETTINGCHANGED, ContactSettingChanged);
	//We create this Hook which will notify everyone when a contact changes his status.
	hHookContactStatusChanged = CreateHookableEvent(ME_STATUSCHANGE_CONTACTSTATUSCHANGED);
	hModulesLoaded = HookEvent(ME_SYSTEM_MODULESLOADED, ModulesLoaded);
	//We add the option page and the user info page (it's needed because options are loaded after plugins)
	hOptionsInitialize = HookEvent(ME_OPT_INITIALISE, OptionsInitialize);
	//Protocol status: we use this for "PopUps on Connection".
	hProtoAck = HookEvent(ME_PROTO_ACK, ProtoAck);
	//This is needed for "NoSound"-like routines.
	hStatusModeChange = HookEvent(ME_CLIST_STATUSMODECHANGE, StatusModeChanged);

	LoadOptions();

	InitStatusList();
	for (int i = ID_STATUS_MIN; i <= ID_STATUS_MAX; i++) 
		SkinAddNewSoundEx(StatusList[Index(i)].lpzSkinSoundName, "Status Notify", StatusList[Index(i)].lpzSkinSoundDesc);

	SkinAddNewSoundEx("UserFromOffline", "Status Notify", Translate("User: from offline (has priority!)"));
	SkinAddNewSoundEx(XSTATUS_SOUND_CHANGED, "Status Notify", "Extra status changed");
	SkinAddNewSoundEx(XSTATUS_SOUND_MSGCHANGED, "Status Notify", "Extra status message changed");
	SkinAddNewSoundEx(XSTATUS_SOUND_REMOVED, "Status Notify", "Extra status removed");

	CallService(MS_DB_SETSETTINGRESIDENT, (WPARAM)TRUE, (LPARAM)"MetaContacts/LastOnline");
	CallService(MS_DB_SETSETTINGRESIDENT, (WPARAM)TRUE, (LPARAM)"NewStatusNotify/LastPopupText");
	return 0;
}

extern "C" int __declspec(dllexport) Unload(void)
{
	li.List_Destroy(eventList);
	li.List_Destroy(xstatusList);
	mir_free(eventList);
	mir_free(xstatusList);

	DeleteCriticalSection(&cs);
	UnhookEvent(hContactSettingChanged);
	UnhookEvent(hOptionsInitialize);
	UnhookEvent(hModulesLoaded);
	UnhookEvent(hUserInfoInitialise);
	UnhookEvent(hStatusModeChange);
	UnhookEvent(hProtoAck);
	DestroyHookableEvent(hHookContactStatusChanged);
	DestroyServiceFunction(hServiceMenu);
	UnhookEvent(hMessageWindowOpen);
	return 0;
}