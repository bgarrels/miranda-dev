/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef MIRANDA_VER
#define MIRANDA_VER 0x0600
#endif

#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock.h>    // for netlib
#include <commctrl.h>
#include <commdlg.h>
#include <stdarg.h>     // for Netlib_Logf (m_netlib.h)
#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "resource.h"

#include "../../include/newpluginapi.h"
#include "../../include/m_system.h"
#include "../../include/m_database.h"
#include "../../include/m_netlib.h"
#include "../../include/m_protomod.h"
#include "../../include/m_protosvc.h"
#include "../../include/m_protocols.h"
#include "../../include/m_clist.h"
#include "../../include/m_options.h"
#include "../../include/m_skin.h"
#include "../../include/m_langpack.h"
#include "../../include/m_userinfo.h"
#include "../../include/m_message.h"
#include "../../include/m_awaymsg.h"
#include "../../include/m_ignore.h"
#include "../../include/m_popup.h"      // LogPopup
#include "../../include/m_addcontact.h" // AddContact ()
#include "../../include/m_clui.h"       // Ding
#include "../../include/m_clistint.h"   // Group Rename
#include "../../include/m_button.h"     // Invite GroupChat Window
#include "../../include/m_icolib.h"     // Invite IcoLib
#include "../../include/m_history.h"    // Invite Button

#ifdef FULL_C6
#include "../../include/m_avatars.h"   // avatar
#endif

#ifdef ROOM_C6

#include "../../include/m_chat.h"       // Rooms

#endif

#include "../../include/m_file.h"       // File

#include "m_updater.h"                  // for Updater

#include "m_eventareaex.h"              // for WELCOME+

#include "c6_svcs.h"
#include "c6_server.h"
#include "c6_auth.h"
#include "c6_user.h"
#include "c6_utilities.h"
#include "c6_userinfotab.h"
#include "c6_advsearch.h"
#include "c6_opt.h"
#include "c6_dialog.h"
#include "c6_xcap.h"
#include "c6_list.h"

#ifdef ROOM_C6

#include "c6_groupchat.h"

#endif

#include "c6_file.h"

#include "encoding.h"

