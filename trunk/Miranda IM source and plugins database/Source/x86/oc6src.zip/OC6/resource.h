// resource.h for oc6.rc

#define	IDC_STATIC	    	-1
#define	IDD_SEARCH	     	 1
#define	IDD_OPT_C6	     	 2
#define	IDD_ADVSEARCH	 	 3
#define IDD_DEBUGWND     	 4
#define IDD_ADDTOLIST    	 5
#define IDD_INFO_C6     	10
#define IDD_INFO_AVATAR 	11
#define IDD_SECRETARIAT 	12
#define	IDD_SETNICKNAME		13
#define IDD_SELECTUSER  	14
#define IDD_MULTICHAT   	15
#define IDD_ROOMLIST    	16
#define IDD_SEARCHROOM  	17
#define IDD_CREATEROOM  	18
#define IDD_PROGRAMME   	19
#define IDD_INVITEUSER  	20
#define IDD_INVITERECV          21
#define IDD_C6ACCOUNT           22
#define IDD_C6SETSTATMSG        23
#define IDD_OPT_FEATURES        24
#define IDD_OPT_C6_CONTACTS     25
#define IDD_C6READSTATMSG       26
#define IDD_C6SERVERLIST        27

#define	IDC_STC6GROUP	    1001
#define	IDC_HANDLE          1002
#define	IDC_C6ACCOUNTLINK   1003
#define	IDC_PASSWORD	    1004
#define	IDC_LOGINSERVER	    1005
#define	IDC_C6PORT          1006

#define IDC_LV_MISC         1010
#define IDC_LASTNICK        1011
#define IDC_NOSECRETARIAT   1012
#define IDC_IPVISIBLE       1013
#define IDC_WELCOME         1014
#define IDC_C6DEFAULTLOG    1016
#define IDC_C6LOG           1017
#define IDC_DEEPINFO        1018
#define IDC_MSGBBCODE       1019
#define IDC_HIDESECRETARIAT 1020
#define IDC_C6TYPINGNOTIFY  1021
#define IDC_IGNOREMSG       1022
#define IDC_INVISADVSEARCH  1023

#define IDC_C6USEXCAP       1031
#define IDC_SERVERCONTACTS  1032
#define IDC_MANAGESERVERLST 1033
#define IDC_FORCEAUTH       1034
#define IDC_NOPERMISSION    1035
#define IDC_WARNINGPER      1036
#define IDC_NOTIFPERM       1037
#define IDC_OFMSGONMAIL     1038
#define IDC_OFMSGONMSGR     1039
#define IDC_SAVEXCAP        1040
#define IDC_XCAPNOUPLOAD    1041
#define IDC_AVATARSUPPORT   1042
#define IDC_AVATARAUTOCLEAN 1043
#define IDC_AVATARCLEANING  1045

#define IDC_GBSUMMARY       1100
#define IDC_GBHOBBY         1101
#define IDC_GBSPORT         1102
#define IDC_GBOTHER         1103
#define IDC_GBEXTRA         1104
#define IDC_AGERANGE    	2001
#define IDC_GENDER      	2002
#define IDC_STATE       	2003
#define IDC_COUNTRY     	2004
#define IDC_WORK        	2005
#define IDC_HOBBY       	2006
#define IDC_HOBBY2      	2007
#define IDC_HOBBY3      	2008
#define IDC_SPORT       	2009
#define IDC_SPORT2      	2010
#define IDC_SPORT3      	2011
#define IDC_MUSIC       	2012
#define IDC_CINEMA      	2013
#define IDC_DISLIKE     	2014
#define IDC_IDCLIENT    	2015
#define IDC_WITHAVATAR  	2016
#define IDC_IDSTATUS        2017
#define IDC_SAVEPREFSEARCH 	2018
#define IDC_LOADPREFSEARCH 	2019
#define IDC_RESETADVSEARCH  2020

#define IDC_C6NICK      	2201
#define IDC_IP          	2202
#define IDC_PORT        	2203
#define IDC_MIRVER      	2204
#define IDC_C6STATUS    	2205
#define IDC_ONLINESINCE 	2206
#define IDC_LASTONLINE  	2207
#define IDC_C6FLAGS     	2208
#define IDC_CHANGEMYDETAILS 2209

#define IDC_DATA        	2100

#define IDC_NICKTOLIST   	2201
#define IDC_ENICKTOLIST  	2202

#define IDC_SELUSER      	2301

#define IDC_CUSTSTAT            2351

#define IDC_SECR_LISTVIEW 	2400
#define IDC_CLOSE         	2401
#define IDC_DELETE_MSG    	2402

#define IDC_AVATAR     	 	2450
#define IDC_GETAVATAR   	2451

#define IDC_ROOMLIST      	2500
#define IDC_REFRESHROOM   	2501
#define IDC_PROFILEROOM   	2502
#define IDC_NUMBERROOM    	2503
#define IDC_ROOMNAME      	2510
#define IDC_PROFILERESULT 	2511
#define IDC_ROOMOWNER     	2512
#define IDC_ROOMKIND      	2513
#define IDC_ROOMUSERS     	2514
#define IDC_NAMESEARCH    	2520
#define IDC_KINDPRIVATE   	2521
#define IDC_KINDC6        	2522
#define IDC_ENTERROOM     	2525
#define IDC_AUTOPROFILE   	2527
#define	IDC_RC_NICK	      	2530
#define	IDC_RC_ROOMNAME	  	2531
#define	IDC_RC_ARGUMENT	  	2532
#define	IDC_RC_PUBLIC	  	2533
#define	IDC_RC_PRIVATE	  	2534
#define IDC_RC_PASSWORD         2535
#define	IDC_RC_CREATE	  	2536
#define	IDC_PR_LIST	      	2540
#define	IDC_PR_REFRESH	  	2541
#define IDC_PR_STATUS     	2543
#define	IDC_PR_FILEDATE	  	2544
#define IDC_NEWROOM       	2550
#define IDC_AUTOUPDATE    	2558
#define IDC_MULTIVIEW     	2559
#define IDC_IV_LIST       	2600
#define IDC_IV_MESSAGE    	2601
#define IDC_IV_ROOM       	2602
#define IDC_IV_INVITE     	2603

#define IDC_PROTOCOL            2604
#define IDC_NAME                2605
#define IDC_DETAILS             2606
#define IDC_USERMENU            2607
#define IDC_HISTORY             2608
#define IDC_MESSAGE             2609

#define IDC_WL              2610
#define IDC_BL              2611
#define IDC_SL              2612
#define IDC_ADD             2613
#define IDC_DEL             2614
#define IDC_SERVERLIST      2615
#define IDC_INFOLIST        2616

#define IDC_UKEY            2700
#define IDC_PW              2701
#define IDC_REGISTER        2702

#define	IDI_C6	 	    3000
#define	IDI_LCL	 	    3001
#define	IDI_SCL	 	    3002
#define	IDI_SECR 	    3003
#define	IDI_WS	 	    3004
#define IDI_GC   	    3005
#define IDI_NEWGC       3006
#define IDI_WD   	    3007
#define IDI_DING  	    3008
#define IDI_STATMSG     3009

#define	IDI_CL_MIRANDA 		3011
#define	IDI_CL_OPENC6  		3012
#define	IDI_CL_CM4X    		3013
#define	IDI_CL_CM60    		3014
#define	IDI_CL_CM50    		3015
#define	IDI_CL_CM51    		3016
#define	IDI_CL_CM52    		3017
#define	IDI_CL_CMJAVA  		3018
#define	IDI_CL_CM70    		3019
#define	IDI_FT	                3050
