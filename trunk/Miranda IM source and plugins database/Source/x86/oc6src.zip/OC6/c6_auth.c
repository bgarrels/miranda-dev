/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * Original copyright : (C) 2003 by Giorgio A.
 *          email     : openc6@hotmail.com
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

#include "blowfish.h"

//--------------------------------------------------------------------
//                        BlowFishEncode
//                code extract from OpenC6 project
//             function blowFishEncode in protosupport.cpp
//--------------------------------------------------------------------

void BlowFishEncode(int len, BYTE *source, int len_key, BYTE* init)
{
  BLOWFISH_CTX ctx;
  unsigned long lvalue, rvalue;
  int i;

  Blowfish_Init(&ctx, init, len_key);

  for (i = 0; i < (len/8); i++)
    {
      lvalue = *source << 24 | *(source+1) << 16 | +*(source+2) << 8 | *(source+3);
      rvalue = *(source+4) << 24 | *(source+5) << 16 | +*(source+6) << 8 | *(source+7);

      Blowfish_Encrypt(&ctx,&lvalue,&rvalue);
	  packWORD(&source, lvalue >> 16);
	  packWORD(&source, lvalue & 0x0000ffff);
	  packWORD(&source, rvalue >> 16);
	  packWORD(&source, rvalue & 0x0000ffff);
    }
}

//--------------------------------------------------------------------
//                          BlowFishDecode
//                code extract from OpenC6 project
//            function blowFishDecode in protosupport.cpp
//--------------------------------------------------------------------

void BlowFishDecode(int len, BYTE *source, int len_key, BYTE* init)
{
  BLOWFISH_CTX ctx;
  unsigned long lvalue, rvalue;
  int i;

  Blowfish_Init(&ctx, init, len_key);

  for (i = 0; i < (len/8); i++)
    {
      lvalue = *source << 24 | *(source+1) << 16 | +*(source+2) << 8 | *(source+3);
      rvalue = *(source+4) << 24 | *(source+5) << 16 | +*(source+6) << 8 | *(source+7);

      Blowfish_Decrypt(&ctx,&lvalue,&rvalue);
	  packWORD(&source, lvalue >> 16);
	  packWORD(&source, lvalue & 0x0000ffff);
	  packWORD(&source, rvalue >> 16);
	  packWORD(&source, rvalue & 0x0000ffff);
    }
}

//--------------------------------------------------------------------
//                          generMD5Key
//                code extract from OpenC6 project
//          function encodeNewMd5Key in protosupport.cpp
//--------------------------------------------------------------------

void generMD5Key(unsigned char *md5_key, unsigned char const *server_key)
{

    const BYTE init_pattern[10] = {0x4a, 0x4e, 0x42, 0x55, 0x25, 0x5e, 0x26, 0x43, 0x29, 0x25};
    BYTE new_key[19];
	int l;

  	memcpy(new_key, server_key, 8);
	memcpy(new_key+8, init_pattern, 10);
  	new_key[18] = 0;

  	GenerKey(md5_key, new_key);

  	for(l = 0; l < 16; l++)
    	md5_key[l] = (md5_key[l] % 0x5E)+0x20;

}


