/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_DIALOG_H
#define __C6_DIALOG_H

#include <stdarg.h>

/* ---------------------- Functions ---------------------- */

int  addToListDlgInit(void);
int  logDlgInit(void);
void logDlgDone(void);
void c6LogMsg(const char *fmt,...);

int  secretariatDlgInit(BOOL bShow);
void secretariatDlgDone(void);
void insertInSecretariat(int iImage, LPSTR pszNick, LPSTR pszMsg, time_t *tt);

int  selectUserDlgInit(LPSTR lpBuffer);

void c6FirstRunCheck(void);

int  setStatusMessage(void);
int  getOnlineMessage(HANDLE hContact);

#ifdef ROOM_C6

int  roomListDlgInit(void);
void roomListDlgDone(void);
void roomListDlgBuf(int action, LPSTR lpBuffer);
void roomListDlgRefresh(void);
void c6SetProfileRoom(LPSTR pszNick, LPSTR pszRoomInfo, LPSTR pszRoomOwner, BYTE kind, WORD nUsers);
int  inviteUserDlgInit(LPSTR pszRoomName);
int  createRoomDlgInit(void);
int  setPasswordxRoom(LPSTR pszRoom);

int ShowInviteWindow(WPARAM wParam, LPARAM lParam);
int InviteEventAdded(WPARAM wParam, LPARAM lParam);

#endif

#endif /* __C6_DIALOG_H */
