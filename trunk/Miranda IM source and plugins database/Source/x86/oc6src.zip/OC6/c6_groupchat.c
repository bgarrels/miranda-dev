/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

#include <wininet.h> // HINTERNET

#define IDM_INVITE      10010
#define IDM_ROOMPROFILE 10011
#define IDM_LEAVE       10012
#define IDM_ADDTOLIST   10015
#define IDM_USERDETAILS 10020
#define IDM_WEBDETAILS  10021
#define IDM_USERIGNORE  10022
#define IDM_USERBAN     10023

// palinsesto ridotto :
#define URLPROGR "http://c6.community.virgilio.it/messenger/html/palinsesto2.html"

#define BUFSIZE 512

BOOL bGroupChat = FALSE;

extern HANDLE hGCMenuItem;
extern HANDLE hRCMenuItem;

typedef struct c6_gclist_s
{
	BOOL bQuit, bOwner;
	LPSTR pszID;
	LPSTR pszRoomName;
	struct c6_gclist_s *next;
} c6_gclist;

c6_gclist *gclist = NULL;

int get_gcnumber(void)
{
 	c6_gclist *h;
	int i = 0;

 	h = gclist;
 	while (h != NULL) {
		h = h->next;
		i++;
  	}
 	return i;

}

LPSTR push_gc(LPSTR pszID, BOOL bOwner)
{

	c6_gclist *h;

	int iRoom = get_gcnumber() + 1;
 	h = mir_alloc(sizeof(c6_gclist));

	h->pszID = mir_alloc(strlen("RoomChat") + strlen(C6PROTOCOLNAME) + 3);
 	wsprintf(h->pszID, "%sRoomChat%02d", C6PROTOCOLNAME, iRoom);

	h->pszRoomName = mir_alloc(strlen(pszID) + 1);
 	strcpy(h->pszRoomName, pszID);

	h->bQuit = FALSE;
	h->bOwner = bOwner;

	h->next = gclist;
 	gclist = h;

	return h->pszID;

}

LPSTR get_quit_gc(void)
{
 	c6_gclist *h;
	BOOL found = FALSE;

	h = gclist;
 	while (h != NULL && !found)
		if (h->bQuit){
			found = TRUE;
		}
		else h = h->next;

 	return (found)?(LPSTR)h->pszID:NULL;

}

LPSTR get_gc(LPSTR pszRoomName)
{
 	c6_gclist *h;
	BOOL found = FALSE;

 	h = gclist;

 	while (h != NULL && !found)
		if (!strcmp(pszRoomName, h->pszRoomName))
			found = TRUE;
		else h = h->next;

 	return (found)?(LPSTR)h->pszID:NULL;

}

LPSTR get_gc_namefromid(LPSTR pszID)
{
 	c6_gclist *h;
	BOOL found = FALSE;

 	h = gclist;

 	while (h != NULL && !found)
		if (!strcmp(pszID, h->pszID))
			found = TRUE;
		else h = h->next;

 	return (found)?(LPSTR)h->pszRoomName:"";

}

BOOL get_gc_ownerfromid(LPSTR pszID)
{
 	c6_gclist *h;
	BOOL found = FALSE;

 	h = gclist;

 	while (h != NULL && !found)
		if (!strcmp(pszID, h->pszID))
			found = TRUE;
		else h = h->next;

 	return (found)?h->bOwner:FALSE;

}

BOOL set_gc_quit(LPSTR pszRoomName)
{

 	c6_gclist *h;
	BOOL found = FALSE;

 	h = gclist;

 	while (h != NULL && !found)
		if (!strcmp(pszRoomName, h->pszRoomName))
			found = TRUE;
		else h = h->next;

 	if (found){
		h->bQuit = TRUE;
	}
	return found;

}

BOOL set_gc_active(LPSTR pszRoomName)
{

 	c6_gclist *h;
	BOOL found = FALSE;

 	h = gclist;

 	while (h != NULL && !found)
		if (!strcmp(pszRoomName, h->pszRoomName))
			found = TRUE;
		else h = h->next;

 	if (found){
		h->bQuit = FALSE;
	}
	return found;

}

void pop_gc(void)
{

	c6_gclist *h;

 	while (gclist!=NULL) {

		h = gclist;
		gclist = gclist->next;
		mir_free(h->pszID);
		mir_free(h->pszRoomName);
		mir_free(h);
	}

}

void pop_a_gc(LPSTR pszID)
{

	c6_gclist *k,*precedente;
	BOOL found = FALSE;

 	k = gclist;
 	precedente = NULL;
	while (k!=NULL && !found) {
		if (!strcmp(pszID, k->pszID))
			found = TRUE;
		else {
	   		precedente=k;
			k=k->next;
		}
	}

	if (found) {
 		if (precedente) {
   			precedente->next = k->next;
			mir_free(k->pszID);
			mir_free(k->pszRoomName);
   			mir_free(k);
  		}
 		else if (k) {
   			gclist = k->next;
			mir_free(k->pszID);
			mir_free(k->pszRoomName);
   			mir_free(k);
  		}
	}

}

//--------------------------------------------------------------------
//                             c6GcInit
//--------------------------------------------------------------------

int c6GcInit(LPSTR pszRoomName, BOOL bOwner)
{

	GCEVENT gce;
	memset(&gce, 0, sizeof(GCEVENT));

	LPSTR pszUID = push_gc(pszRoomName, bOwner);

	{

		GCSESSION gcw;// = {0};

		memset(&gcw, 0, sizeof(GCSESSION));
		gcw.cbSize = sizeof(GCSESSION);
		gcw.iType = GCW_CHATROOM;
		gcw.pszModule = C6PROTOCOLNAME;
		gcw.pszName = pszRoomName;
		gcw.pszID = pszUID;

		gcw.pszStatusbarText = NULL;
		CallService(MS_GC_NEWSESSION, 0, (LPARAM)&gcw);

	}

	GCDEST gcd;
	gcd.pszModule = C6PROTOCOLNAME;
	gcd.pszID = pszUID;
	gcd.iType = GC_EVENT_ADDGROUP;

	gce.cbSize = sizeof(GCEVENT);
	gce.pDest = &gcd;
	gce.pszStatus = Translate( "Users" );
	CallService(MS_GC_EVENT, 0, ( LPARAM )&gce );

	gce.pszStatus = Translate( "Guest" );
	CallService(MS_GC_EVENT, 0, ( LPARAM )&gce );

	gce.pszStatus = Translate( "Mod" );
	CallService(MS_GC_EVENT, 0, ( LPARAM )&gce );

	gce.pszStatus = Translate( "Leader" );
	CallService(MS_GC_EVENT, 0, ( LPARAM )&gce );

	gce.pszStatus = Translate( "Others" );
	CallService(MS_GC_EVENT, 0, ( LPARAM )&gce );

	// set Room Name
    memset(&gce, 0, sizeof(gce));
	gce.cbSize = sizeof(GCEVENT);
	gce.pDest = &gcd;
	gce.pszUID = pszUID;
	gce.pszText = pszRoomName;
	gcd.iType = GC_EVENT_SETSBTEXT;
	CallService(MS_GC_EVENT, 0, (LPARAM)&gce);

	gcd.iType = GC_EVENT_CONTROL;
	CallService(MS_GC_EVENT, SESSION_INITDONE, (LPARAM)&gce);
	CallService(MS_GC_EVENT, SESSION_ONLINE, (LPARAM)&gce);
	CallService(MS_GC_EVENT, WINDOW_VISIBLE, (LPARAM)&gce);

	set_gc_quit(pszRoomName);

	return 0;

}

//--------------------------------------------------------------------
//                                c6GcQuit
//--------------------------------------------------------------------

void c6GcQuit(void)
{

	GCEVENT gce;
	GCDEST gcd;

	LPSTR pszID = get_quit_gc();
	if (pszID==NULL) return ;

	gcd.pszModule = C6PROTOCOLNAME;
	gcd.pszID = pszID;
	gcd.iType = GC_EVENT_CONTROL;

	memset(&gce, 0, sizeof(GCEVENT));
	gce.cbSize = sizeof(GCEVENT);
	gce.pDest = &gcd;
	CallService(MS_GC_EVENT, SESSION_TERMINATE, (LPARAM)&gce);
	CallService(MS_GC_EVENT, WINDOW_CLEARLOG, (LPARAM)&gce);

	pop_a_gc(pszID);

}

//--------------------------------------------------------------------
//                            c6GcAllQuit
//--------------------------------------------------------------------

void c6GcAllQuit(void)
{

	GCEVENT gce;
	GCDEST gcd;

	gcd.pszModule = C6PROTOCOLNAME;
	gcd.pszID = NULL;
	gcd.iType = GC_EVENT_CONTROL;

	memset(&gce, 0, sizeof(GCEVENT));
	gce.cbSize = sizeof(GCEVENT);
	gce.pDest = &gcd;
	CallService(MS_GC_EVENT, SESSION_TERMINATE, (LPARAM)&gce);
	CallService(MS_GC_EVENT, WINDOW_CLEARLOG, (LPARAM)&gce);

	pop_gc();

}

//--------------------------------------------------------------------
//                      c6ChatProcessMessage
//--------------------------------------------------------------------

void c6ChatProcessMessage( BYTE opType, LPSTR pszRoomName, LPSTR pszNick, LPSTR pszMsg )
{

	GCDEST gcd;
	gcd.pszModule = C6PROTOCOLNAME;
	gcd.pszID = get_gc(pszRoomName);

	gcd.iType = GC_EVENT_MESSAGE;

	char szUser[40];
	GetUserNickName(szUser);

	time_t msgTime = time( NULL );

	GCEVENT gce = {0};
	gce.cbSize = sizeof(GCEVENT);
	gce.pDest = &gcd;
	gce.pszUID = pszNick;
	gce.pszNick = pszNick;
	gce.time = msgTime;
	gce.pszText = pszMsg;
	if (opType == OT_MODERATED)
		gce.pszUserInfo = Translate("Moderated");
	else if (opType == OT_SCREENED)
		gce.pszUserInfo = Translate("Screened");

	HANDLE hContact = HContactfNickNoAdd(pszNick);
	if (hContact && CallService(MS_IGNORE_ISIGNORED, (WPARAM)hContact, (LPARAM)IGNOREEVENT_MESSAGE)) {

		gce.pszText = Translate("%i[Ignored]%I");

	}

	gce.bIsMe = strcmp( szUser, pszNick ) == 0;
	CallService(MS_GC_EVENT, 0, (LPARAM)&gce);

}

//--------------------------------------------------------------------
//                     c6UpdateMemberStatus
//--------------------------------------------------------------------

enum ROOM_ENTER_MODE {
        ROOM_SUPER_USER = 1,
        ROOM_CHAT_LEADER = 2,
        ROOM_SCREENER = 4,
        ROOM_SPEAKER = 8,
        ROOM_STAFF = 16,
        ROOM_GUEST = 32,
        ROOM_USER_LIST = 64,
        ROOM_MODERATOR = 128
};

void c6UpdateMemberStatus(LPSTR pszNick, LPSTR pszRoomName, int action, int log, LONG role)
{

	GCDEST gcd;
	gcd.pszModule = C6PROTOCOLNAME;
	gcd.pszID = get_gc(pszRoomName);
	gcd.iType = GC_EVENT_PART;

	char szUser[40];
	GetUserNickName(szUser);

	GCEVENT gce = {0};
	gce.cbSize = sizeof(GCEVENT);
	gce.pszNick = pszNick;
	gce.pszUID = pszNick;
	gce.pDest = &gcd;
	gce.dwFlags = (BOOL)0;//log;
	gce.time = time(0);

	if (action)
    	gcd.iType = GC_EVENT_JOIN;

	if (role == 0) // users
		gce.pszStatus = Translate( "Users" );
	else if ((role&ROOM_CHAT_LEADER) == ROOM_CHAT_LEADER) // leader
		gce.pszStatus = Translate( "Leader" );
	else if ((role&ROOM_MODERATOR) == ROOM_MODERATOR) // mod
		gce.pszStatus = Translate( "Mod" );
	else if ((role&ROOM_GUEST) == ROOM_GUEST) // guest
		gce.pszStatus = Translate( "Guest" );
	else gce.pszStatus = Translate( "Others" );

	gce.bIsMe = strcmp( pszNick, szUser ) == 0;

	CallService( MS_GC_EVENT, 0, ( LPARAM )&gce );

}

void c6KickMember(LPSTR pszNick, LPSTR pszRoomName)
{

	GCDEST gcd;
	gcd.pszModule = C6PROTOCOLNAME;
	gcd.pszID = get_gc(pszRoomName);
   	gcd.iType = GC_EVENT_KICK;

	char szUser[40];
	GetUserNickName(szUser);

	GCEVENT gce = {0};
	gce.cbSize = sizeof(GCEVENT);
	gce.pszNick = pszNick;
	gce.pszUID = pszNick;
	gce.pszStatus = (LPSTR)szUser;
	gce.pDest = &gcd;
	gce.time = time(0);

	CallService( MS_GC_EVENT, 0, ( LPARAM )&gce );

}

void c6IgnoreMember(LPSTR pszNick, LPSTR pszRoomName, BOOL bMode)
{

	GCDEST gcd;
	gcd.pszModule = C6PROTOCOLNAME;
	gcd.pszID = get_gc(pszRoomName);
	gcd.iType = GC_EVENT_ACTION;

	GCEVENT gce = {0};
	gce.cbSize = sizeof(GCEVENT);
	gce.pszNick = pszNick;
	gce.pszUID = pszNick;
	gce.pDest = &gcd;
	gce.time = time(0);

	if (bMode)
		gce.pszText = Translate( "now is Ignored" );
	else gce.pszText = Translate( "is not Ignored" );
	gce.bIsMe = FALSE;

	CallService( MS_GC_EVENT, 0, ( LPARAM )&gce );

}

//--------------------------------------------------------------------
//                     getProgrammeFileName
//--------------------------------------------------------------------

void getProgrammeFileName(LPSTR *pszDest, int cbLen)
{

	WORD tPathLen;

	*pszDest = (LPSTR)mir_alloc(cbLen);
    CallService(MS_DB_GETPROFILEPATH, cbLen, (LPARAM)*pszDest);

    tPathLen = strlen(*pszDest);
    tPathLen += mir_snprintf(*pszDest + tPathLen, MAX_PATH-tPathLen, "\\%s\\", C6PROTOCOLNAME);
    CreateDirectory(*pszDest, NULL);
	strcat(*pszDest, "palinsesto2.html");

}

//--------------------------------------------------------------------
//                       getProgrammeFile
//--------------------------------------------------------------------

BOOL getProgrammeFile(LPSTR *pszDest)
{

	HINTERNET hIn, hURL;
 	DWORD dwNumberOfBytesRead;
 	FILE *f;
 	BOOL bret;
	char szFile[MAX_PATH];

	char Buffer[BUFSIZE];

	getProgrammeFileName(pszDest, 255);

 	bret = FALSE;

    c6LogMsg("Download programme...");
	hIn = InternetOpen("miranda32.exe",INTERNET_OPEN_TYPE_PRECONFIG,NULL,NULL,0);
	if (hIn) {

		strcpy(szFile, URLPROGR);

		hURL=InternetOpenUrl(hIn, szFile, NULL, 0, 0, 0);
		if (hURL) {

   	 		if ((f = fopen(*pszDest, "wb")) != NULL) {
   	        	do {

   	   				InternetReadFile(hURL,&Buffer,BUFSIZE,&dwNumberOfBytesRead);
   	   				fwrite(Buffer, dwNumberOfBytesRead, 1, f);

   	  			} while (dwNumberOfBytesRead != 0);
   	  			fclose(f);
	  			bret = TRUE;

	 		}
   	 		InternetCloseHandle(hURL);
		}
		InternetCloseHandle(hIn);
	}
 	return bret;

}

char* __stdcall rtrim( char *string )
{
   char* p = string + strlen( string ) - 1;

   while ( p >= string )
   {  if ( *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r' )
         break;

		*p-- = 0;
   }
   return string;
}

//--------------------------------------------------------------------
//                         sttLogListHook
//--------------------------------------------------------------------

static void sttLogListHook(GCHOOK* gch)
{

	switch( gch->dwData ) {
	case IDM_INVITE:
		{
			LPSTR pszRoomName = get_gc_namefromid(gch->pDest->pszID);

			inviteUserDlgInit(pszRoomName);
		}
		break;
	case IDM_LEAVE:
		{
			char szUser[40];
			GetUserNickName(szUser);

			LPSTR pszRoomName = get_gc_namefromid(gch->pDest->pszID);

			if (set_gc_quit(pszRoomName))

				c6reqEnterExitRoom(0, szUser, pszRoomName);

		}
		break;
	}

}

//--------------------------------------------------------------------
//                        sttNickListHook
//--------------------------------------------------------------------

static void sttNickListHook(GCHOOK* gch)
{

	switch( gch->dwData ) {
	case IDM_ADDTOLIST:
		{	ADDCONTACTSTRUCT acs;

			C6SEARCHRESULT sr = {0};

    		sr.hdr.cbSize = sizeof(sr);

			sr.hdr.nick = gch->pszUID;
			sr.hdr.firstName = NULL;
			sr.hdr.lastName = NULL;
			sr.hdr.email = NULL;
			sr.status = 0;

			acs.handle = NULL;
			acs.handleType = HANDLE_SEARCHRESULT;
			acs.szProto = C6PROTOCOLNAME;
			acs.psr = &sr;
			CallService(MS_ADDCONTACT_SHOW,(WPARAM)NULL,(LPARAM)&acs);
		}
		break;
	case IDM_USERDETAILS :
		{
			HANDLE hContact = HContactFromNick(PALF_TEMPORARY, gch->pszUID);
			if (hContact)
				CallService(MS_USERINFO_SHOWDIALOG, (WPARAM)hContact, 0);
		}
		break;
    case IDM_WEBDETAILS :
		{
			HANDLE hContact = HContactFromNick(PALF_TEMPORARY, gch->pszUID);
			if (hContact)
				DetailPlusMenu((WPARAM)hContact, 0);
		}
		break;
	case IDM_USERIGNORE :
		{
			char szUser[40];
			GetUserNickName(szUser);

			if (!strcmp(gch->pszUID, szUser))
				MessageBox(GetFocus(), Translate("Impossible operation"), gch->pszUID, MB_ICONSTOP);
			else {

				LPSTR pszRoomName = get_gc_namefromid(gch->pDest->pszID);
				BOOL bPrevIgnored = FALSE;

				HANDLE hContact = HContactfNickNoAdd(gch->pszUID);
				if (hContact && CallService(MS_IGNORE_ISIGNORED, (WPARAM)hContact, (LPARAM)IGNOREEVENT_MESSAGE)) {
					bPrevIgnored = TRUE;
					c6LogMsg("Rimosso l'ignore... per %s", gch->pszUID);
					CallService(MS_IGNORE_UNIGNORE, (WPARAM)hContact, IGNOREEVENT_MESSAGE);
				} else {
					bPrevIgnored = FALSE;
					addSrvIgnoreList(gch->pszUID, IGNOREEVENT_MESSAGE);
				}

				c6IgnoreMember(gch->pszUID, pszRoomName, !bPrevIgnored);

			}
		}
		break;
	case IDM_USERBAN :
		{
			char szUser[40];
			GetUserNickName(szUser);

			if (!strcmp(gch->pszUID, szUser) || !get_gc_ownerfromid(gch->pDest->pszID))
				MessageBox(GetFocus(), Translate("Impossible operation"), gch->pszUID, MB_ICONSTOP);
			else {
				LPSTR pszRoomName = get_gc_namefromid(gch->pDest->pszID);
				if (c6reqBanUserNewRoom(szUser, pszRoomName, gch->pszUID, 10)) // 10 minutes suspended
					c6KickMember(gch->pszUID, pszRoomName);
			}
		}
		break;
	}

}

//--------------------------------------------------------------------
//                         c6GcEventHook
//--------------------------------------------------------------------

int c6GcEventHook(WPARAM wParam, LPARAM lParam)
{

	GCHOOK* gch = (GCHOOK*)lParam;
	if ( gch == NULL )
		return 0;

	if ( lstrcmpi(gch->pDest->pszModule, C6PROTOCOLNAME))
		return 0;

	switch ( gch->pDest->iType ) {
	case GC_USER_MESSAGE:
		if (gch->pszText && lstrlen(gch->pszText) > 0) {

			rtrim(gch->pszText);

			char szUser[40];
			GetUserNickName(szUser);

			LPSTR pszRoomName = get_gc_namefromid(gch->pDest->pszID);

			if (strcmp(gch->pszText,"/exit")==0){

				if (set_gc_quit(pszRoomName))
					c6reqEnterExitRoom(0, szUser, pszRoomName);
			}

			else {

				if (c6SendMessage2Room(szUser, pszRoomName, gch->pszText))
					c6ChatProcessMessage(0, pszRoomName, szUser, gch->pszText);
			}

		}
		break;

	case GC_USER_PRIVMESS :
			if (MessageBox(0,gch->pszUID,"Send Private Message?",MB_YESNO)==IDYES) {

				HANDLE hContact = HContactFromNick(PALF_TEMPORARY, gch->pszUID);

				CallService(MS_MSG_SENDMESSAGE,(WPARAM)hContact,(LPARAM)(const char*)NULL);
			}
		break;

	case GC_SESSION_TERMINATE :
	    c6LogMsg("Terminate Chat Window");
		break;

	case GC_USER_CHANMGR:
		roomListDlgInit();

		if (amIOnline())
			roomListDlgRefresh();
		break;

	case GC_USER_LOGMENU:
		sttLogListHook(gch);
		break;

	case GC_USER_NICKLISTMENU:
		sttNickListHook(gch);
		break;

	case GC_USER_CLOSEWND:
	    c6LogMsg("Close Chat Window");
		break;

	}


	return 0;
}

//--------------------------------------------------------------------
//                         c6GcMenuHook
//--------------------------------------------------------------------

int c6GcMenuHook( WPARAM wParam, LPARAM lParam )
{
	GCMENUITEMS* gcmi= ( GCMENUITEMS* )lParam;
	if ( gcmi == NULL )
		return 0;

	if ( lstrcmpi( gcmi->pszModule, C6PROTOCOLNAME ))
		return 0;

	if ( gcmi->Type == MENU_ON_LOG ) {

		static struct gc_item sttLogListItems[3];

		sttLogListItems[0].pszDesc = Translate( "&Invite User..." );
		sttLogListItems[0].dwID = IDM_INVITE;
		sttLogListItems[0].uType = MENU_ITEM;
		sttLogListItems[0].bDisabled = FALSE;

		sttLogListItems[1].pszDesc = NULL;
		sttLogListItems[1].dwID = 0;
		sttLogListItems[1].uType = MENU_SEPARATOR;
		sttLogListItems[1].bDisabled = FALSE;

		sttLogListItems[2].pszDesc = Translate( "&Leave Room" );
		sttLogListItems[2].dwID = IDM_LEAVE;
		sttLogListItems[2].uType = MENU_ITEM;
		sttLogListItems[2].bDisabled = FALSE;

		gcmi->nItems = sizeof( sttLogListItems ) / sizeof( sttLogListItems[0] );
		gcmi->Item = sttLogListItems;

	}
	else if ( gcmi->Type == MENU_ON_NICKLIST ) {
		static struct gc_item sttListItems[7];

		sttListItems[0].pszDesc = Translate( "Add to list" );
		sttListItems[0].dwID = IDM_ADDTOLIST;
		sttListItems[0].uType = MENU_ITEM;
		sttListItems[0].bDisabled = FALSE;

		sttListItems[1].pszDesc = NULL;
		sttListItems[1].dwID = 0;
		sttListItems[1].uType = MENU_SEPARATOR;
		sttListItems[1].bDisabled = FALSE;

		sttListItems[2].pszDesc = Translate( "User Details" );
		sttListItems[2].dwID = IDM_USERDETAILS;
		sttListItems[2].uType = MENU_ITEM;
		sttListItems[2].bDisabled = FALSE;

		sttListItems[3].pszDesc = Translate( "View Profile" );
		sttListItems[3].dwID = IDM_WEBDETAILS;
		sttListItems[3].uType = MENU_ITEM;
		sttListItems[3].bDisabled = FALSE;

		sttListItems[4].pszDesc = NULL;
		sttListItems[4].dwID = 0;
		sttListItems[4].uType = MENU_SEPARATOR;
		sttListItems[4].bDisabled = FALSE;

		sttListItems[5].pszDesc = Translate( "Ignore" );
		sttListItems[5].dwID = IDM_USERIGNORE;
		sttListItems[5].uType = MENU_ITEM;
		sttListItems[5].bDisabled = FALSE;

		sttListItems[6].pszDesc = Translate( "Ban" );
		sttListItems[6].dwID = IDM_USERBAN;
		sttListItems[6].uType = MENU_ITEM;
		sttListItems[6].bDisabled = FALSE;

		gcmi->nItems = sizeof( sttListItems )/sizeof( sttListItems[0] );
		gcmi->Item = sttListItems;

	}

	return 0;
}

//--------------------------------------------------------------------
//                          c6GcWindowEvent
//--------------------------------------------------------------------

int c6GcWindowEvent(WPARAM wParam, LPARAM lParam)
{

	MessageWindowEventData* msgEvData = (MessageWindowEventData*)lParam;

	switch( msgEvData->uType ) {

		case MSG_WINDOW_EVT_CLOSING:
			{

   				char szbuf[255];
				DBVARIANT dbv;

				if (DBGetContactSettingByte(msgEvData->hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 1) {

			        if (!DBGetContactSetting(msgEvData->hContact, C6PROTOCOLNAME, "Nick", &dbv)) {
						sprintf(szbuf, "%s", dbv.pszVal);
						DBFreeVariant(&dbv);
			    		c6LogMsg(szbuf);

						char szUser[40];
						GetUserNickName(szUser);

						if (set_gc_quit(szbuf)){
							c6reqEnterExitRoom(0, szUser, szbuf);
						}
					}
				}

				break;
			}

	}
	return 0;
}

//--------------------------------------------------------------------
//                       roomcreateMenuChange
//--------------------------------------------------------------------

void roomcreateMenuChange(BOOL bShow)
{
	CLISTMENUITEM clmi;

	memset( &clmi, 0, sizeof( clmi ));
	clmi.cbSize = sizeof( clmi );

	clmi.flags = (bShow) ? 0 : CMIF_GRAYED;
	clmi.flags |= CMIM_FLAGS;
	CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hGCMenuItem,(LPARAM)&clmi);
	CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hRCMenuItem,(LPARAM)&clmi);

}

