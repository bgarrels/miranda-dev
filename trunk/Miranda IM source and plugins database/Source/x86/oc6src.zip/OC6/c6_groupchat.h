/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_GROUPCHAT_H
#define __C6_GROUPCHAT_H

#define C6_DB_EVENT_TYPE_CHATSTATES   2000
#define MS_CHAT_SHOWINVITE            "/ShowInvite"

enum ROOM_OPERATION_TYPE
{
	OT_MODERATED = 1,
	OT_SCREENED = 3
};

/* ---------------------- Functions ---------------------- */

void pop_gc(void);
BOOL set_gc_quit(LPSTR pszRoomName);
BOOL set_gc_active(LPSTR pszRoomName);

void c6GcAllQuit(void);

int  c6GcInit(LPSTR pszRoomName, BOOL bOwner);
void c6GcQuit(void);
void c6ChatProcessMessage(BYTE opType, LPSTR pszRoomName, LPSTR pszNick, LPSTR pszMsg);
void c6UpdateMemberStatus(LPSTR pszNick, LPSTR pszRoomName, int action, int log, LONG role);

BOOL getProgrammeFile(LPSTR *pszDest);

int  c6GcEventHook(WPARAM wParam,LPARAM lParam);
int  c6GcMenuHook(WPARAM wParam, LPARAM lParam);
int  c6GcWindowEvent(WPARAM wParam, LPARAM lParam);

void roomcreateMenuChange(BOOL bShow);

#endif /* __C6_GROUPCHAT_H */

