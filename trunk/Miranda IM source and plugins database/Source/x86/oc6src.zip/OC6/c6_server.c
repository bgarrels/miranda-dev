/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

typedef struct serverthread_start_info_s {
	NETLIBOPENCONNECTION nloc;
	int status;
	LPSTR pszNick;
	LPSTR pszPass;
} serverthread_start_info;

typedef struct pthread_s {
	HANDLE hThread;
	DWORD dwThreadId;
} pthread_t;

HANDLE hServerConn;

HANDLE hDirectBoundPort; // P2P
DWORD dwLocalInternalIP;

WORD wListenPort;

char reordered_key[8];
char server_key[8];
char md5_key[16];

int client_count = 1;

static pthread_t serverThreadId;

extern HANDLE hNetlibUser;
extern HANDLE hDirectNetlibUser; // P2P

extern int c6Status;

//--------------------------------------------------------------------
//                           getTimeMsg
//--------------------------------------------------------------------

char *getTimeMsg(void)
{

	SYSTEMTIME ST;
    static char szdate[12];

    GetLocalTime(&ST);
    _snprintf(szdate, 12, "%02d:%02d:%02d", ST.wHour, ST.wMinute, ST.wSecond);
    return (*(&szdate));

}

//--------------------------------------------------------------------
//                          unpack functions
//--------------------------------------------------------------------

BYTE unpackBYTE(BYTE **bpacket)
{

	BYTE c = *(*bpacket)++;
  	return c;

}

void unpackNBYTE(BYTE **bpacket, WORD n, BYTE *pbyte)
{

	memcpy(pbyte, *bpacket, n);
    (*bpacket) += n;

}

void unpackWORD(BYTE **bpacket, WORD *pw)
{

	*pw  = *(*bpacket)++ << 8;
	*pw |= *(*bpacket)++;

}

void unpackDWORD(BYTE **bpacket, LONG *pl)
{

	*pl  = *(*bpacket)++ << 24;
	*pl |= *(*bpacket)++ << 16;
	*pl |= *(*bpacket)++ << 8;
	*pl |= *(*bpacket)++;

}

void unpackZSTR(BYTE **bpacket, int len, LPSTR pstr)
{

	strncpy(pstr, *bpacket, len);
	pstr[len] = '\0';
	*bpacket += len;

}

//--------------------------------------------------------------------
//                           recvHeloPacket
//--------------------------------------------------------------------

static void recvHeloPacket(BYTE *bpacket, int size)
{

    BYTE *bp;
	BYTE unknown[2];
	BYTE klen;
	BYTE key[8];

    c6LogMsg("HELO");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	unknown[0] = unpackBYTE(&bp);
	unknown[1] = unpackBYTE(&bp);
	klen = unpackBYTE(&bp);


    if (klen != 8) {
        c6LogMsg("Invalid server key length (%d)", klen);
        return;
    }

	unpackNBYTE(&bp, klen, key);

    memcpy(server_key, key, 8);

    reorder_key_server(server_key, reordered_key);

}

//--------------------------------------------------------------------
//                          recvRedirectPacket
//--------------------------------------------------------------------

static HANDLE recvRedirectPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	ULONG ip;
	BYTE  unknown[2];
	WORD  port;
	NETLIBOPENCONNECTION nloc;

	struct in_addr sin_addr;

    c6LogMsg("REDIRECT");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return NULL;
    }

	unpackDWORD(&bp, (LONG*)&ip);
	ip = ntohl(ip);

	unknown[0] = unpackBYTE(&bp);
	unknown[1] = unpackBYTE(&bp);

	unpackWORD(&bp, &port);

	int sck = CallService(MS_NETLIB_GETSOCKET, (WPARAM)hServerConn, (LPARAM)0);
   	if (sck!=INVALID_SOCKET) shutdown(sck, 2); // close gracefully
    Netlib_CloseHandle(hServerConn);
    hServerConn = NULL;

    memcpy(&sin_addr, &ip, sizeof(LONG));

    nloc.cbSize = sizeof(NETLIBOPENCONNECTION);
    nloc.flags = 0;

	// Server port
	nloc.szHost = inet_ntoa(sin_addr);

//#ifndef FILE_C6
//    wListenPort =
//#endif
	nloc.wPort = port;

    c6LogMsg("Host= %s Port= %d", nloc.szHost, nloc.wPort);

    client_count = 1;

    return (HANDLE)CallService(MS_NETLIB_OPENCONNECTION, (WPARAM)hNetlibUser, (LPARAM)&nloc);

}

//--------------------------------------------------------------------
//                            c6EventWelcome
//--------------------------------------------------------------------

int c6EventWelcome(LPSTR msg)
{
	int i = 0;

	if (ServiceExists(MS_EAX_ADDMESSAGE)) {
		//c6LogMsg(msg);
		i = CallService(MS_EAX_ADDMESSAGE, (WPARAM)msg, 0);

	}
	else LogPopup(0, POPUPCOLOR_WHITE, msg);

	return i;
}

//--------------------------------------------------------------------
//                          recvWelcomePacket
//--------------------------------------------------------------------

static int recvWelcomePacket(BYTE *bpacket, int size, BOOL bPopup)
{

    BYTE *bp;
	WORD len;
	LPSTR pmsg;

    c6LogMsg("WELCOME%s",(bPopup)?"":"+");

	if(!bPopup && DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "ShowWelcome", 0) == 0)
		return 1;

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return 1;
    }

	unpackWORD(&bp, &len);

    pmsg = (LPSTR)mir_alloc(len + 1);
    if (pmsg == NULL) {
		c6LogMsg("Cannot get memory");
        return 1;
    }

	unpackZSTR(&bp, len, pmsg);

	if (bPopup) {
    	// Show the welcome message
    	c6LogMsg(pmsg);

   		LogPopup(0, POPUPCOLOR_WHITE, pmsg);
	}
	else {

		c6EventWelcome(pmsg);

	}

    mir_free(pmsg);
	return 0;

}

void HandleBBcode(LPSTR *pszMsg, BYTE *bpacket)
{

	BYTE *bp;
	BYTE iStyle, iRed, iGreen, iBlue, iSize;
	LPSTR pszNewMsg;

	bp = bpacket;
	iStyle = unpackBYTE(&bp);
	if (iStyle==0)
		iStyle = unpackBYTE(&bp);

	if (iStyle > 8) {

		if (((iStyle-8) & 1) == 1) { // bold
				pszNewMsg = (LPSTR)mir_alloc(strlen(*pszMsg) + 1 + 7);
				wsprintf(pszNewMsg, "[b]%s[/b]", *pszMsg);
				mir_free(*pszMsg);
				*pszMsg = pszNewMsg;
		}
		if (((iStyle-8) & 2) == 2) { // italic
				pszNewMsg = (LPSTR)mir_alloc(strlen(*pszMsg) + 1 + 7);
				wsprintf(pszNewMsg, "[i]%s[/i]", *pszMsg);
				mir_free(*pszMsg);
				*pszMsg = pszNewMsg;
		}
		if (((iStyle-8) & 4) == 4) { // underline
				pszNewMsg = (LPSTR)mir_alloc(strlen(*pszMsg) + 1 + 7);
				wsprintf(pszNewMsg, "[u]%s[/u]", *pszMsg);
				mir_free(*pszMsg);
				*pszMsg = pszNewMsg;
		}

	}

	iRed = unpackBYTE(&bp);
	iGreen = unpackBYTE(&bp);
	iBlue = unpackBYTE(&bp);
	if (iRed || iGreen || iBlue) { // it's not black
		pszNewMsg = (LPSTR)mir_alloc(strlen(*pszMsg) + 1 + 15 + 8);
		wsprintf(pszNewMsg, "[color=#%02X%02X%02X]%s[/color]", iRed, iGreen, iBlue, *pszMsg);
		mir_free(*pszMsg);
		*pszMsg = pszNewMsg;
	}
	bp++; // font name is not implemented in BBcode
	iSize = unpackBYTE(&bp);
	if (iSize != 10) { // 10 pixel is default size
		pszNewMsg = (LPSTR)mir_alloc(strlen(*pszMsg) + 1 + 7 + 2 + 7);
		wsprintf(pszNewMsg, "[size=%02d]%s[/size]", iSize, *pszMsg);
		mir_free(*pszMsg);
		*pszMsg = pszNewMsg;
	}

}

//--------------------------------------------------------------------
//                         recvSrvMessagePacket
//--------------------------------------------------------------------

static void recvSrvMessagePacket(BYTE *bpacket, int size)
{

    BYTE *bp;
	BYTE  s_len, r_len;
	WORD  m_len;
	BYTE  style, mtype;
	LPSTR pszSender, pszRecver, pszMsg;

	char szbuf[150];

    c6LogMsg("SRV_MESSAGE");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	// sender
	s_len = unpackBYTE(&bp);

    pszSender = (LPSTR)mir_alloc(s_len + 1);
    if (pszSender == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, s_len, pszSender);

	// receiver
	r_len = unpackBYTE(&bp);

    pszRecver = (LPSTR)mir_alloc(r_len + 1);
    if (pszRecver == NULL) {
		mir_free(pszSender);
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, r_len, pszRecver);

	unpackWORD(&bp, &m_len);

	style = unpackBYTE(&bp);
	mtype = unpackBYTE(&bp);

	m_len -= 2;
	if (style==14 && mtype==0) // type BBcode
		m_len -= 6; // 7 bytes

    pszMsg = (LPSTR)mir_alloc(m_len + 1);
    if (pszMsg == NULL) {
		mir_free(pszRecver);
		mir_free(pszSender);
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, m_len, pszMsg);

	switch (style) {

		case NEW_STYLE_MSG: // messaging = 14

			if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseBBCode", 0))
				if (mtype == 0) // type BBcode
					HandleBBcode(&pszMsg, bp);

			HandleGetMessage(pszSender, pszMsg, NULL);

		break;

		case INVITE_MSG: // invite messaging = 13

			HandleInviteMessage(pszSender, pszMsg);

		break;

		case SELF_MSG : // self message = 4

			switch (mtype) {

			case AUTH_BUDDY_OP : // buddy_op = 8
				{
					BYTE byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_Permission", 0);

					if (byValue == CONFIG_NOTIFICATION) {
	        			c6LogMsg("Buddy Added in CList");
						sprintf(szbuf, "%s %s", pszSender, Translate("has Added you to Contact List"));
			  			LogPopup(0, POPUPCOLOR_ORANGE, szbuf);
					}
					else if (byValue == CONFIG_AUTHORIZE) {
	        			c6LogMsg("Request Buddy for Insert in CList");
						if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", 0))
							handleRecvAuthRequest(pszSender);
						else {
							sprintf(szbuf, "%s %s", pszSender, Translate("requests Authorization in Server List"));
			  				LogPopup(0, POPUPCOLOR_ORANGE, szbuf);
						}
					}
				}
			break;

			case FILE_TRANSFER_AV : // filesharing = 16
				{
					sprintf(szbuf, "%s: %s", pszSender, pszMsg);
					c6LogMsg(szbuf);
					LogPopup(0, POPUPCOLOR_ORANGE, szbuf);
				}
			break;

			case TYPING_NOTIFY_OP : // typing = 0x1d (29)

				handleTypingNotification(pszSender, pszMsg); // occorre un client >= 6.2

			break;

			case FILE_TRANSFER_OP : // file request = 3
				if(DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", 0)==0)
					HandleFileRequest(pszSender, pszMsg);
				c6LogMsg(pszMsg);
			break;

            case REQUEST_FILE : // dipende dal client... = 21
				if(DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", 0))
					HandleFileRequest(pszSender, pszMsg);
				c6LogMsg("%s is trying to send a file", pszSender);
            break;

			default :
		    	// Display the message / groupchat invite
				if (HandleInviteMessage(pszSender, pszMsg)>1)
					HandleGetMessage(pszSender, pszMsg, NULL); // mtype==2 : black_list_op
			break;

			} // switch mtype

		break;

		default:
			HandleGetMessage(pszSender, pszMsg, NULL); // style==2 : ordinary_msg
		break;

	} // switch style

	mir_free(pszMsg);
	mir_free(pszRecver);
    mir_free(pszSender);

}

//--------------------------------------------------------------------
//                          recvSndUsersPacket
//--------------------------------------------------------------------

static void recvSndUsersPacket(BYTE *bpacket, int size)
{

    BYTE *bp, *bpx;
	WORD num_nick;
	LPSTR pszNick, pszStatMsg;
	WORD status;
	int i, j, len_nick;

    c6LogMsg("ADD_REQUEST_RECEIVED");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	unpackWORD(&bp, &num_nick);

	c6LogMsg("nick number = %d", num_nick);

	// jump to status field
   	for (i = 0; i < num_nick; i++) {
    	len_nick = *bp;
      	bp += 1 + len_nick;
   	}
	bpx = bp + 2;

    //  now read nick name
	bp = bpacket + 2;
   	for (i = 0; i < num_nick; i++) {

		len_nick = unpackBYTE(&bp);

    	pszNick = (LPSTR)mir_alloc(len_nick + 1);
    	if (pszNick == NULL) {
			c6LogMsg("Cannot get memory");
        	return;
    	}

		unpackZSTR(&bp, len_nick, pszNick);

      	bpx += 7;
		unpackWORD(&bpx, &status);
      	bpx += 3; // 0x00 0x02 0x05 0xLL
		j = unpackBYTE(&bpx);
    	pszStatMsg = (LPSTR)mir_alloc(j + 1);
    	if (pszStatMsg) {

			unpackZSTR(&bpx, j, pszStatMsg);

    	} else c6LogMsg("Cannot get memory");

      	c6LogMsg("NETFRIEND_ONLINE %s (0x%04X)", pszNick, status);

	  	SetNetFriendStatus(pszNick, status, 1, pszStatMsg);
		if (pszStatMsg)
			mir_free(pszStatMsg);

	  	mir_free(pszNick);
   	}

}

//--------------------------------------------------------------------
//                        recvSndSearchusrPacket
//--------------------------------------------------------------------

static void recvSndSearchusrPacket(BYTE *bpacket, int size)
{

    BYTE *bp;
	WORD n_nick;

    c6LogMsg("SEARCH_RESULT");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	unpackWORD(&bp, &n_nick);

	c6LogMsg("Found = %d", n_nick);

    struct snd_users_pkt_s {
      char list;
    } *ptr = (struct snd_users_pkt_s *) bp;

 	SearchLaunch(n_nick, (LPARAM)&ptr->list);

}

//--------------------------------------------------------------------
//                         recvStatusUserPacket
//--------------------------------------------------------------------

static void recvStatusUserPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	BYTE  len_nick;
	LPSTR pszNick;
	BYTE  status;

    c6LogMsg("STATUS_USER");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len_nick = unpackBYTE(&bp);

    pszNick = (LPSTR)mir_alloc(len_nick + 1);
    if (pszNick == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len_nick, pszNick);

	status = unpackBYTE(&bp);

    /* Show user status */
    if (status) {
		c6LogMsg("NETFRIEND ONLINE %s %u", pszNick, status);
	    status = C6_AVAILABLE;
	} else {
		c6LogMsg("NETFRIEND OFFLINE %s %u", pszNick, status);
		status = C6_OFFLINE;
	}

    SetNetFriendStatus(pszNick, status, 1, NULL);

    mir_free(pszNick);

}

//--------------------------------------------------------------------
//                          recvChgStatusPacket
//--------------------------------------------------------------------

static void recvChgStatusPacket(BYTE *bpacket, int size)
{

	const BYTE str3[]={ 0x00, 0x02, 0x05 };
    BYTE  *bp;
	BYTE  len;
	LPSTR pszNick, pszStatusMsg = NULL;
	WORD  status;

    c6LogMsg("CHANGE_STATUS");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len = unpackBYTE(&bp);

    pszNick = (LPSTR)mir_alloc(len + 1);
    if (pszNick == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszNick);

	bp += 8;
	unpackWORD(&bp, &status);

    c6LogMsg("NETFRIEND %s (0x%04X)", pszNick, status);

	if ((len+8+1+2 != size) && !memcmp(bp, str3, 3)) {
		// StatusMessage
		bp += 3;
		len = unpackBYTE(&bp);

	    pszStatusMsg = (LPSTR)mir_alloc(len + 1);
	    if (pszStatusMsg) {

			unpackZSTR(&bp, len, pszStatusMsg);

	    } else c6LogMsg("Cannot get memory");
	}

    SetNetFriendStatus(pszNick, status, 1, pszStatusMsg);

	if (pszStatusMsg)
		mir_free(pszStatusMsg);
    mir_free(pszNick);

}

#ifdef ROOM_C6

//--------------------------------------------------------------------
//                           recvRoomsPacket
//--------------------------------------------------------------------

static void recvRoomsPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	WORD  nRooms;

    c6LogMsg("ROOM_LIST");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	bp += 2;

	unpackWORD(&bp, &nRooms);

   	c6LogMsg("Rooms # %d", nRooms);

	roomListDlgBuf(0, bpacket+2);

}

//--------------------------------------------------------------------
//                           recvRoomsMultiPacket
//--------------------------------------------------------------------

static void recvRoomsMultiPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	WORD  nRooms;

    c6LogMsg("ROOM_MULTILIST");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	bp+=2;

	unpackWORD(&bp, &nRooms);

   	c6LogMsg("Rooms # %d", nRooms);

	roomListDlgBuf(1, bpacket+2);

}

//--------------------------------------------------------------------
//                         recvMsgFromRoomPacket
//--------------------------------------------------------------------

static void recvMsgFromRoomPacket(BYTE *bpacket, int size)
{

    BYTE  *bp, *bpd;
	BYTE  len, style, optype;
	LPSTR pszNick, pszRoom, pszMsg;
	WORD  len_msg;

    c6LogMsg("MSG_FROMROOM");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len = unpackBYTE(&bp);

    pszNick = (LPSTR)mir_alloc(len + 1);
    if (pszNick == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszNick);

	len = unpackBYTE(&bp);

    pszRoom = (LPSTR)mir_alloc(len + 1);
    if (pszRoom == NULL) {
		mir_free(pszNick);
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszRoom);

	len = unpackBYTE(&bp);
	bp += len;

	unpackBYTE(&bp);
	unpackWORD(&bp, &len_msg);
	len_msg-=2;

	style = unpackBYTE(&bp);
	optype = unpackBYTE(&bp);

    pszMsg = (LPSTR)mir_alloc(len_msg + 1);
    if (pszMsg == NULL) {
		mir_free(pszRoom);
		mir_free(pszNick);
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len_msg, pszMsg);

    if (optype == OT_MODERATED || optype == OT_SCREENED)
    {
		c6LogMsg("Chat Message: MODERATED (%s)", pszMsg);
		char *p = strtok(pszMsg, "~");
		if (p) {
			p = strtok(NULL, "~");
			if (p) {
				free(pszNick);
			    pszNick = (LPSTR)mir_alloc(strlen(p) + 1);
				strcpy(pszNick, p);
				char *q = p;
				while (p) {
					p = strtok(NULL, "~");
					if (p)
						q = p;
				}
				if (q) {
					free(pszMsg);
			    	pszMsg = (LPSTR)mir_alloc(strlen(p) + 1);
					strcpy(pszMsg, p);
				}
			}
		}
    }

	c6ChatProcessMessage(optype, pszRoom, pszNick, pszMsg);

	mir_free(pszMsg);
	mir_free(pszRoom);
	mir_free(pszNick);

}

//--------------------------------------------------------------------
//                        recvProfileRoomPacket
//--------------------------------------------------------------------

static void recvProfileRoomPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	BYTE  len, kind;
	WORD  nUsers;
	LPSTR pszNick, pszRoomInfo, pszRoomOwner;

    c6LogMsg("GET_ROOM_PROFILE");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len = unpackBYTE(&bp);

    pszNick = (LPSTR)mir_alloc(len + 1);
    if (pszNick == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszNick);

	kind = unpackBYTE(&bp);

	len = unpackBYTE(&bp);

    pszRoomInfo = (LPSTR)mir_alloc(len + 1);
    if (pszRoomInfo == NULL) {
		mir_free(pszNick);
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszRoomInfo);

	len = unpackBYTE(&bp);

    pszRoomOwner = (LPSTR)mir_alloc(len + 1);
    if (pszRoomOwner == NULL) {
		mir_free(pszRoomInfo);
		mir_free(pszNick);
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszRoomOwner);

	unpackWORD(&bp, &nUsers);

	// follow WORD=length of packet type ( groups of 2 bytes )

	c6SetProfileRoom(pszNick,pszRoomInfo,pszRoomOwner,kind,nUsers);

	mir_free(pszRoomOwner);
	mir_free(pszRoomInfo);
	mir_free(pszNick);

}

//--------------------------------------------------------------------
//                      recvEventFromRoomPacket
//--------------------------------------------------------------------

static void recvEventFromRoomPacket(BYTE *bpacket, int size, int cmd)
{

    BYTE  *bp;
	BYTE  len;
	LPSTR pszNick, pszRoomName;

	if (cmd==ENTER_ROOM)
    	c6LogMsg("ENTER_ROOM");
	else c6LogMsg("EXIT_FROMROOM");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len = unpackBYTE(&bp);

    pszNick = (LPSTR)mir_alloc(len + 1);
    if (pszNick == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }
	unpackZSTR(&bp, len, pszNick);

	len = unpackBYTE(&bp);

    pszRoomName = (LPSTR)mir_alloc(len + 1);
    if (pszRoomName == NULL) {
		mir_free(pszNick);
		c6LogMsg("Cannot get memory");
        return;
    }
	unpackZSTR(&bp, len, pszRoomName);

	char szUser[40]; // 20
	GetUserNickName(szUser);

	if (!strcmp(szUser,pszNick)) {
		LPSTR pszbuf = mir_alloc(strlen(Translate("You are banned from:")) + strlen(pszRoomName) + 2);
		sprintf(pszbuf, "%s\n%s", Translate("You are banned from:"), pszRoomName);
		LogPopup(0, POPUPCOLOR_ORANGE, pszbuf);
		mir_free(pszbuf);
		set_gc_quit(pszRoomName);
		c6GcQuit();

	}

	else c6UpdateMemberStatus(pszNick, pszRoomName, (cmd==ENTER_ROOM)?1:0, 0, 0);//1

	mir_free(pszRoomName);
	mir_free(pszNick);

}

//--------------------------------------------------------------------
//                       recvRoomNickListPacket
//--------------------------------------------------------------------

static void recvRoomNickListPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	BYTE  len, nPeople;
	LPSTR pszRoom, pszNick;
	WORD  i, kind;

    c6LogMsg("ROOM_NICKLIST");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len = unpackBYTE(&bp);

    pszRoom = (LPSTR)mir_alloc(len + 1);
    if (pszRoom == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszRoom);
	unpackWORD(&bp, &kind);

	nPeople = unpackBYTE(&bp);

    for (i=0; i < nPeople; i++) {

		len = unpackBYTE(&bp);

	    pszNick = (LPSTR)mir_alloc(len + 1);
    	if (pszNick == NULL) {
			mir_free(pszRoom);
			c6LogMsg("Cannot get memory");
        	return;
    	}

		unpackZSTR(&bp, len, pszNick);

		c6UpdateMemberStatus(pszNick, pszRoom, 1, 0, 0);

 		mir_free(pszNick);

    }

	set_gc_active(pszRoom);

    mir_free(pszRoom);

}

//--------------------------------------------------------------------
//                       recvRoomEnteredPacket
//--------------------------------------------------------------------

static void recvRoomEnteredPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	BYTE  len;
	LPSTR pszRoom, pszNick, pszRoomMsg;
	WORD  i, wlen, nPeople, kind, user;
	LONG role;

    c6LogMsg("ROOM_ENTERED");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len = unpackBYTE(&bp);

    pszRoom = (LPSTR)mir_alloc(len + 1);
    if (pszRoom == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszRoom);

	unpackWORD(&bp, &wlen);

    pszRoomMsg = (LPSTR)mir_alloc(wlen + 1);
    if (pszRoomMsg==NULL) {
		mir_free(pszRoom);
		c6LogMsg("Cannot get memory");
		return;
    }
	unpackZSTR(&bp, wlen, pszRoomMsg);
	c6ChatProcessMessage(0, pszRoom, "", pszRoomMsg);

	unpackWORD(&bp, &kind);
	unpackWORD(&bp, &kind);

	unpackWORD(&bp, &user);
	unpackWORD(&bp, &user);

	unpackWORD(&bp, &nPeople);

    for (i=0; i < nPeople; i++) {

		len = unpackBYTE(&bp);

	    pszNick = (LPSTR)mir_alloc(len + 1);
    	if (pszNick == NULL) {
			mir_free(pszRoomMsg);
			mir_free(pszRoom);
			c6LogMsg("Cannot get memory");
        	return;
    	}

		unpackZSTR(&bp, len, pszNick);

		unpackDWORD(&bp, &role);

		c6UpdateMemberStatus(pszNick, pszRoom, 1, 0, role); //1

 		mir_free(pszNick);

    }

	set_gc_active(pszRoom);

    mir_free(pszRoomMsg);
    mir_free(pszRoom);

}

//--------------------------------------------------------------------
//                       recvRoomErrorPacket
//--------------------------------------------------------------------

static void recvRoomErrorPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	BYTE  len, code;
	WORD  wlen;
	LPSTR pszRoom, pszError=NULL;

    c6LogMsg("ROOM_ERROR");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len = unpackBYTE(&bp);

    pszRoom = (LPSTR)mir_alloc(len + 1);
    if (pszRoom == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }
	unpackZSTR(&bp, len, pszRoom);

	code = unpackBYTE(&bp);

	if (code==2) {
		char szbuf[128];
		sprintf(szbuf, "%s\n%s", pszRoom, Translate("This Room required a password"));
		LogPopup(0, POPUPCOLOR_ORANGE, szbuf);
		setPasswordxRoom(pszRoom);
	    mir_free(pszRoom);
	}

	else {

		unpackWORD(&bp, &wlen);

		if (wlen > 0) {
    		pszError = (LPSTR)mir_alloc(wlen + 1);
    		if (pszError) {
				unpackZSTR(&bp, wlen, pszError);

				c6LogMsg(pszError);
				LogPopup(0, POPUPCOLOR_ORANGE, pszError);

				mir_free(pszError);

    		} else c6LogMsg("Cannot get memory");

		} else LogPopup(0, POPUPCOLOR_ORANGE, Translate("Room has Error."));

		set_gc_quit(pszRoom);
		c6GcQuit();

	    mir_free(pszRoom);
	}


}

//--------------------------------------------------------------------
//                     recvRoomBanErrorPacket
//--------------------------------------------------------------------

static void recvRoomBanErrorPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	WORD  wlen;
	DWORD dwType;
	LPSTR pszError=NULL;

    c6LogMsg("ROOM_ERROR");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data dont exist");
      return;
    }

	unpackDWORD(&bp, &dwType);

	unpackWORD(&bp, &wlen);

	pszError = (LPSTR)mir_alloc(wlen + 1);
	if (pszError) {
		unpackZSTR(&bp, wlen, pszError);

		LogPopup(0, POPUPCOLOR_ORANGE, pszError);

		mir_free(pszError);
	}

}

#endif

//--------------------------------------------------------------------
//                          recvProfilePacket
//--------------------------------------------------------------------

static void recvProfilePacket(BYTE *bpacket, int size)
{

	const BYTE str5[]={ 0x00, 0x02, 0x00, 0x01, 0x02 };
    BYTE  *bp;
	BYTE  len;
	LPSTR pszNick;
	WORD  rlen;

    profile_user_data data;

    c6LogMsg("PROFILE REPLY");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return;
    }

	len = unpackBYTE(&bp);

    pszNick = (LPSTR)mir_alloc(len + 1);
    if (pszNick == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, len, pszNick);

	unpackDWORD(&bp, (LONG*)&(data.time));

	unpackDWORD(&bp, (LONG*)&(data.ip));

	data.status = unpackBYTE(&bp);

	unpackWORD(&bp, &rlen);

	data.list = bp;

	bp += rlen*2;
	// new status
	if (!memcmp(bp, str5, 5)) {
		bp += 7;
		unpackWORD(&bp, &(data.status));
	}

    HandleGetProfile(pszNick, rlen, (LPARAM)&data);

	mir_free(pszNick);

}

//--------------------------------------------------------------------
//                            handleFileAck
//--------------------------------------------------------------------

void handleFileAck(LPSTR pszRecvr,DWORD ip,WORD port)
{

	C6FileTransfer* ft;
	DWORD dwCookie;

	if (!FindCookie(OP_FILE, pszRecvr, &dwCookie, (void *)&ft))
	{
		Netlib_Logf(hDirectNetlibUser, "Error: Received unexpected file transfer request response");
		c6LogMsg("User Receiver Error file transfer");
		return;
	}

	FreeCookie(dwCookie);

	c6LogMsg(ft->pszFileName);

	ft->hContact = HContactFromNick(0,pszRecvr);

	if (port) {

		ft->dwRemoteIP=ip;
		ft->wRemotePort=port;

		openDirectConnection(ft->hContact, ft);

	}
	else
 		ProtoBroadcastAck(C6PROTOCOLNAME, ft->hContact, ACKTYPE_FILE, ACKRESULT_DENIED, ft, 0);


}

//--------------------------------------------------------------------
//                          recvSendReplyPacket
//--------------------------------------------------------------------

static void recvSendReplyPacket(BYTE *bpacket, int size)
{

    BYTE  *bp;
	ULONG ip;
	WORD  port;
	int   r_len;
	BYTE  ip0,ip1,ip2,ip3;
	LPSTR pszRecver;

    c6LogMsg("SEND_REPLY");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return ;
    }

	// receiver
	r_len = unpackBYTE(&bp);

    pszRecver = (LPSTR)mir_alloc(r_len + 1);
    if (pszRecver == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }

	unpackZSTR(&bp, r_len, pszRecver);

	ip0 = unpackBYTE(&bp)^server_key[7];
	ip1 = unpackBYTE(&bp)^server_key[5];
	ip2 = unpackBYTE(&bp)^server_key[6];
	ip3 = unpackBYTE(&bp)^server_key[1];

    ip = (((int)ip0) << 24) | ((int)(ip1) << 16) | (((int)ip2) << 8) | (((int)ip3));

	bp += 2;

	unpackWORD(&bp, &port);

	BYTE optype = unpackBYTE(&bp);

    if (port)
    {

		c6LogMsg("Prepare sending file to %d.%d.%d.%d:%d", ip0, ip1, ip2, ip3, port);

		if (optype == 3) // file transfert
			handleFileAck(pszRecver, ip, port);
		else if (optype == 4) // audio_video
			c6LogMsg("Audio/Video");

    }
    else
    {

        c6LogMsg("Receiving file is not allowed for remote user");
		Netlib_Logf(hNetlibUser, "File transfer denied by %s,", pszRecver);
		handleFileAck(pszRecver,ip,port);

    }

	mir_free(pszRecver);

}

//--------------------------------------------------------------------
//                             strpos
//--------------------------------------------------------------------

#define NICKSTR "nickname"
#define PASSWSTR "password"

int strpos(char *szStr, char *szPattern)
{
    int pos;
	char *p = strstr(szStr, szPattern);
	if (p)
		pos = p - szStr;
	else pos = -1;

	return pos;
}

BOOL s_NickAndPass(LPSTR names,LPSTR szNick,LPSTR *pszPass)
{

	char szLstNick[32];
	BOOL bFound=FALSE;
	int i,l;

	int number = names[0];
	names++;

	*pszPass=NULL;
	i=0;
	while (i < number && !bFound) {

		l = names[0];

		names++;
		strncpy(szLstNick,names,l);
		szLstNick[l]='\0';

		names+=l;
		l = names[0];

		names++;

		*pszPass=(LPSTR)mir_alloc(l + 1);
		strncpy(*pszPass,names,l);
		(*pszPass)[l]='\0';

		names+=l;

		bFound = (strcmp(szNick,szLstNick) == 0);
		i++;

	}

	return bFound;
}

//--------------------------------------------------------------------
//                            selectUser
//--------------------------------------------------------------------

BOOL selectUser(BYTE *bpacket)
{

    char Buffer[256];
	LPSTR pszNick=NULL, pszPass=NULL;
	int iBuf=0,iNick=0;

  	int pos, pos1 = 0;
	BYTE *bp = bpacket;

  	BOOL done=FALSE;

	Buffer[iBuf++]=0x00;

    while (!done) {

		pos = strpos(bp, NICKSTR);

        if (pos > 0) {

			mir_free(pszNick);
			mir_free(pszPass);

			pos += strlen(NICKSTR)+1;
			bp += pos;

            pos1 = strpos(bp, "<");
			pszNick = (char *)mir_alloc(pos1 + 1);
			if (pszNick){
				strncpy(pszNick, bp, pos1);
				pszNick[pos1]='\0';

				Buffer[iBuf++] = pos1;
				strncpy(&Buffer[iBuf],pszNick, pos1);
				iBuf+=pos1;

		    }

			bp += pos1;

            pos = strpos(bp, PASSWSTR);
            pos += strlen(PASSWSTR)+1;
			bp += pos;

			pos1 = strpos(bp, "<");
			pszPass = (char *)mir_alloc(pos1 + 1);
			if (pszPass){
				int pos2 = pos1;
				/*if (pos2>8)
				    pos2=8;*/
				strncpy(pszPass, bp, pos2);
				pszPass[pos2]='\0';

				Buffer[iBuf++] = pos2;
				strncpy(&Buffer[iBuf],pszPass, pos2);
				iBuf+=pos2;

			}

			bp += pos1;
			iNick++;

         }
         else done = TRUE;
    }

	Buffer[0]=iNick;

	if (iNick) {

		DBVARIANT dbv;
		BOOL bLastNick=FALSE;

		if(!DBGetContactSetting(NULL,C6PROTOCOLNAME, "LastNick" ,&dbv)) {
			bLastNick=(BOOL)dbv.cVal;
			DBFreeVariant(&dbv);

   		}

		if (iNick==1 || bLastNick){

			if (iNick > 1)
		        if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {

					mir_free(pszNick);
					mir_free(pszPass);
					pszNick = (char *)mir_alloc(20);
				    strcpy(pszNick,dbv.pszVal);
					DBFreeVariant(&dbv);

					s_NickAndPass(Buffer, pszNick, &pszPass);

				}

			if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseXCAP", 0))
				setXCAPPassword(pszNick, pszPass);

			if (strlen(pszPass)>8)
				pszPass[8]='\0';

			if (c6LoginServ(pszNick, pszPass))
				DBWriteContactSettingString(NULL, C6PROTOCOLNAME, C6_LOGINID, pszNick);

			mir_free(pszNick);
			mir_free(pszPass);

		}
		else {

			mir_free(pszNick);
			mir_free(pszPass);

			if (!selectUserDlgInit(Buffer))
  				return FALSE;
		}

		return TRUE;
	}

  	return FALSE;
}

//--------------------------------------------------------------------
//                          recvUsersPacket
//--------------------------------------------------------------------

static int recvUsersPacket(BYTE *bpacket, int size)
{

   	BYTE *bp;
	WORD n_nick;

    c6LogMsg("USERS");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return 1;
    }

	unpackWORD(&bp, &n_nick);

    if (n_nick == 0) {
		c6LogMsg("INVALID_NAME");
	  	LogPopup(0, POPUPCOLOR_ORANGE, Translate("Login: INVALID NAME."));
        return 1;
    }

	// decode packet
	BlowFishDecode(n_nick, bp, 16, md5_key);

	if (!selectUser(bp))
		return 1;

	return 0;

}

//--------------------------------------------------------------------
//                          getDateMsg
//--------------------------------------------------------------------

void getDateMsg(LPSTR pszDate, time_t *tt)
{

		struct tm t;

	   	memset(&t,0x00,sizeof(t));

		if (strlen(pszDate)==19){

			char buf[5];
			strncpy(buf, pszDate, 4);
			buf[4]='\0';
			t.tm_year = atoi(buf) - 1900;

			strncpy(buf, pszDate+5, 2);
			buf[2]='\0';
			t.tm_mon = atoi(buf) - 1;

			strncpy(buf, pszDate+8, 2);
			buf[2]='\0';
			t.tm_mday = atoi(buf);

			strncpy(buf, pszDate+11, 2);
			buf[2]='\0';
			t.tm_hour = atoi(buf);

			strncpy(buf, pszDate+14, 2);
			buf[2]='\0';
			t.tm_min = atoi(buf);

			strncpy(buf, pszDate+17, 2);
			buf[2]='\0';
			t.tm_sec = atoi(buf);

		}

		*tt = mktime(&t);

}

//--------------------------------------------------------------------
//                     recvOfflineMsgPacket
//--------------------------------------------------------------------

static int recvOfflineMsgPacket(BYTE *bpacket, int size)
{

   	BYTE *bp;
	BYTE len;
	LONG id;
	WORD wlen;
	LPSTR pszSender, pszRecver, pszMsg, pszDate;

    c6LogMsg("OFFLINE_MSG");

	bp = bpacket;
	if (bp == NULL) {
      c6LogMsg("Data don't exist");
      return 1;
    }

	unpackDWORD(&bp, &id);

	if (id) {

		len = unpackBYTE(&bp);

    	pszSender = (LPSTR)mir_alloc(len + 1);
    	if (pszSender == NULL) {
			c6LogMsg("Cannot get memory");
        	return 1;
    	}

		unpackZSTR(&bp, len, pszSender);

		len = unpackBYTE(&bp);

    	pszRecver = (LPSTR)mir_alloc(len + 1);
    	if (pszRecver == NULL) {
			mir_free(pszSender);
			c6LogMsg("Cannot get memory");
        	return 1;
    	}

		unpackZSTR(&bp, len, pszRecver);

		len = unpackBYTE(&bp); // date+time
    	pszDate = (LPSTR)mir_alloc(len + 1);
    	if (pszDate == NULL) {
			mir_free(pszRecver);
			mir_free(pszSender);
			c6LogMsg("Cannot get memory");
        	return 1;
    	}

		unpackZSTR(&bp, len, pszDate);
		unpackBYTE(&bp);

		unpackWORD(&bp, &wlen);
		wlen -= 2;
		bp += 2;

    	pszMsg = (LPSTR)mir_alloc(wlen + 1);
    	if (pszMsg == NULL) {
			mir_free(pszDate);
			mir_free(pszRecver);
			mir_free(pszSender);
			c6LogMsg("Cannot get memory");
	        return 1;
    	}

		unpackZSTR(&bp, wlen, pszMsg);

		time_t tt;
		getDateMsg(pszDate, &tt);

		HandleGetMessage(pszSender, pszMsg, &tt);

		c6SendRemOLMsgServ(pszRecver, (DWORD)id);

		mir_free(pszMsg);
		mir_free(pszDate);
		mir_free(pszRecver);
    	mir_free(pszSender);
	}

	return 0;

}

//--------------------------------------------------------------------
//                         handleServerCommand
//--------------------------------------------------------------------

int handleServerCommand(BYTE cmd, BYTE *bpacket, int size, serverthread_start_info* info)
{

	switch (cmd)
    {

    	case INFOLOGIN :

        	c6LogMsg("INFOLOGIN");

        break;

      	case REDIRECT :

        	hServerConn = recvRedirectPacket(bpacket, size);
		  	if (hServerConn == NULL)
				return 1;
        break;

      	case LOGIN_ERRPASS :

        	c6LogMsg("LOGIN_ERRPASS");
		  	LogPopup(0, POPUPCOLOR_ORANGE, Translate("Login: Password Error."));
		  	Netlib_Logf(hNetlibUser, "C6 Login: Password Error.");
		   	return 1;

        break;

      	case LOGIN_USERCONN :

        	c6LogMsg("LOGIN_USERCONN");
		  	LogPopup(0, POPUPCOLOR_ORANGE, Translate("Login: User is already connected."));
		  	Netlib_Logf(hNetlibUser, "C6 Login: User is already connected.");
			return 1;

        break;

	  	case CLIENT_EXIT_OK :

        	c6LogMsg("CLIENT_EXIT_OK");

        break;

		case SEND_REPLY :
          	recvSendReplyPacket(bpacket, size);

       	break;

      	case SND_USERS :

        	c6LogMsg("SND_USERS");
          	recvSndUsersPacket(bpacket, size);

       	break;

      	case SEARCH_RESULT_NICK :
      	case SEARCH_RESULT_EMAIL :

			recvSndSearchusrPacket(bpacket, size);

        break;

      	case STATUS_USER :

        	recvStatusUserPacket(bpacket, size);

        break;

      	case INVALID_PACKET :

			c6LogMsg("INVALID_PACKET/Protocol");
		  	LogPopup(0, POPUPCOLOR_ORANGE, Translate("Invalid Packet/Protocol."));
		  	Netlib_Logf(hNetlibUser, "C6: Invalid Packet/Protocol.");

        return 1;

	  	case CHANGE_STATUS :

        	recvChgStatusPacket(bpacket, size);

		break;

      	case LOGIN_NOUSER :

			c6LogMsg("LOGIN_NOUSER");
		  	LogPopup(0, POPUPCOLOR_ORANGE, Translate("Login: No User."));
			Netlib_Logf(hNetlibUser, "C6 Login: No User.");

			return 1;
        break;

      	case SRV_MESSAGE :

        	recvSrvMessagePacket(bpacket, size);

        break;

      	case WELCOME :

			if (c6Status == ID_STATUS_CONNECTING) {

				char szUser[40]; // 20
				LPSTR pszStatusMessage = NULL;

	        	recvWelcomePacket(bpacket, size, TRUE);

		  		GetUserNickName(szUser);
				getStatusMessage(&pszStatusMessage);

				if (isKeyLogin(info->pszNick)) {
					if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseXCAP", 0)) {
						c6GetXCAPConfig(szUser);
						if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", 0)) {
							//c6LogMsg("i- %s", getTimeMsg());
							c6GetXCAPBL(szUser); // Server Buddy List
							//c6LogMsg("2- %s", getTimeMsg());
							c6SrvBlackList(DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_Permission", 0)==CONFIG_AUTHORIZE, szUser); // BlackList
							//c6LogMsg("f- %s", getTimeMsg());
						}
					}
					if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_OfflineMsg", 0))
						c6SendReqOLMsgServ(szUser);
				}

				if (info->status != C6_AWAY)
		  			c6NewChangeStatus(szUser, 0, info->status, pszStatusMessage);
				else c6NewChangeStatus(szUser, 1, C6_AVAILABLE, pszStatusMessage);

				mir_free(pszStatusMessage);

          		C6SetMyStatus(C6StatusToMiranda(info->status));

		  		DBWriteContactSettingDword(NULL, C6PROTOCOLNAME, "LogonTS", time(NULL));

		  		HandleSendContact();

        		mir_free(info->pszNick);
		  		mir_free(info->pszPass);

			} else
				recvWelcomePacket(bpacket, size, FALSE);

        break;

      	case PING :

        	c6LogMsg("PING");

		  	c6SendPongServ();

        break;

	  	case PROFILE_REPLY :

			recvProfilePacket(bpacket, size);

        break;

      	case HELO :

        	recvHeloPacket(bpacket, size);

		  	client_count = 1;

		  	if (isKeyLogin(info->pszNick)) {

				c6KeyLoginServ(info->pszNick, info->pszPass);

			}
		  	else if (c6LoginServ(info->pszNick, info->pszPass))

				DBWriteContactSettingString(NULL,C6PROTOCOLNAME,C6_LOGINID, info->pszNick);

        break;


	  	case GET_USERS :

        	if (recvUsersPacket(bpacket, size))
				return 1;

        break;

      	case SRV_MAINTENANCE :

			c6LogMsg("SERVER_MAINTENANCE");
		  	LogPopup(0, POPUPCOLOR_ORANGE, Translate("Server Maintenance."));
		  	Netlib_Logf(hNetlibUser, "C6: Server Maintenance.");

         	return 1;

	  	case SEARCH_RESULT_PROFILE :

			c6LogMsg("SEARCH USER PROFILE...");
		  	recvSndSearchusrPacket(bpacket, size);

        break;

      	case ENCODED_MSG :

			c6LogMsg("ENCODED_MSG...");
          	packet_encode(bpacket, bpacket, size);
		  	cmd = bpacket[1];

         	return handleServerCommand(cmd, bpacket+6, size-6, info);

#ifdef ROOM_C6

		case ROOM_LIST :
		case SEARCH_RESULTS :

			recvRoomsPacket(bpacket, size);

		break;

		case ROOM_NICKLIST :

			recvRoomNickListPacket(bpacket, size);

		break;

		case EXIT_ROOM_OK :

			c6GcQuit();

		break;

        case EXIT_FROMROOM :

        case ENTER_ROOM :

			recvEventFromRoomPacket(bpacket, size, cmd);

        break;

		case ROOM_NOTPRESENT: // no data

	  		LogPopup(0, POPUPCOLOR_ORANGE, Translate("Room does not Exist."));
			c6LogMsg("Room does not Exists.");
			c6GcQuit();

		break;

        case ROOM_FULL :

	  		LogPopup(0, POPUPCOLOR_ORANGE, Translate("Room is Full."));
			c6LogMsg("Unable to enter into Full Room");
			c6GcQuit();

		break;

        case ROOM_ERROR :

			recvRoomErrorPacket(bpacket, size);

		break;

        case ROOM_CREATE_BUSY :
	  		LogPopup(0, POPUPCOLOR_ORANGE, Translate("Room Create Busy."));
			c6LogMsg("Error on Create Room");
			c6GcQuit();

        break;

		case MSG_FROMROOM :

			recvMsgFromRoomPacket(bpacket, size);

		break;

        case GET_ROOM_PROFILE :

            recvProfileRoomPacket(bpacket, size);

        break;

		case ROOM_MULTILIST :

            recvRoomsMultiPacket(bpacket, size);

        break;

		case ROOM_ENTERED :

			recvRoomEnteredPacket(bpacket, size);

        break;

		case ROOM_KICK_ACK :
	  		LogPopup(0, POPUPCOLOR_ORANGE, Translate("User is Banned !"));
		break;

		case ROOM_KICK_BAN_ERROR :

			recvRoomBanErrorPacket(bpacket, size);

		break;

#endif

		case OFFLINE_MSG :

			recvOfflineMsgPacket(bpacket, size);

        break;

      	default :
			c6LogMsg("UNKNOWN_COMMAND (%d)", cmd);
		break;

   	}

  	return 0;

}

//--------------------------------------------------------------------
//                           ResetAllContact
//--------------------------------------------------------------------

void ResetAllContact(void)
{

	HANDLE hContact;
	char* szProto;


	c6LogMsg("All Contact Offline...");
	hContact= (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);

	// Offline all contacts
    while (hContact) {

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);
		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
			{
				if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0){
					if (DBGetContactSettingWord(hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE)
						!= ID_STATUS_OFFLINE)
					{
						DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE);
						DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "Timezone");
					}
				}
			}

		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}

}

//--------------------------------------------------------------------
//                             showError
//--------------------------------------------------------------------

void showError(void)
{

	LPSTR pszMsgBuf;

 	pszMsgBuf = (LPSTR) mir_alloc( 256 );
 	memset(pszMsgBuf, 0, 256);
 	FormatMessage(
	 	FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
	 	NULL,
	 	GetLastError(),
	 	MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
	 	(LPTSTR) &pszMsgBuf,
	 	0,
	 	NULL);
 	c6LogMsg(pszMsgBuf);
 	mir_free( pszMsgBuf );

}

//--------------------------------------------------------------------
//                          c6ServerDisconnect
//--------------------------------------------------------------------

void c6ServerDisconnect(void)
{

	if (hServerConn) {

		c6LogMsg("Forced Closure");

		int sck = CallService(MS_NETLIB_GETSOCKET, (WPARAM)hServerConn, (LPARAM)0);
    	if (sck!=INVALID_SOCKET) shutdown(sck, 2); // close gracefully

		Netlib_CloseHandle(hServerConn);
		hServerConn = NULL;

		ResetAllContact();

		C6SetMyStatus(ID_STATUS_OFFLINE);

		DBWriteContactSettingDword(NULL, C6PROTOCOLNAME, "LogonTS", 0); // clear logon time

		// stop welcome+
		if (ServiceExists(MS_EAX_STOPMESSAGE)) {
			CallService(MS_EAX_STOPMESSAGE, 0, 0);
		}

		// Not called from network thread?
		if (GetCurrentThreadId() != serverThreadId.dwThreadId) {

			TerminateThread(serverThreadId.hThread,-1);

    		CallService (MS_SYSTEM_THREAD_POP, 0, 0);

			CloseHandle(serverThreadId.hThread);
			c6LogMsg("Close Thread");

    	}
	}

}

//--------------------------------------------------------------------
//                            c6ServerThread
//--------------------------------------------------------------------

int c6Recv(HANDLE s, char *data, long datalen)
{
	int ret, nleft;
	BYTE *ptr;

	ptr = data;
	nleft = datalen;
   	while (nleft > 0) {
		ret = Netlib_Recv(s, ptr, nleft, MSG_DUMPASTEXT);

		if (ret == 0) {

			LogPopup(0, POPUPCOLOR_ORANGE, Translate("Packet Error, Close Connenction."));
			c6LogMsg("Clean closure of server socket");
			showError(); // deep Info
			return 0;

		}

		if (ret == SOCKET_ERROR) {

			LogPopup(0, POPUPCOLOR_ORANGE, Translate("Socket Error, Close Connenction."));
			c6LogMsg("Abortive closure of server socket");
			showError(); // deep Info
			return ret;
		}

       	nleft -= ret;
       	ptr += ret;
	}

	return datalen-nleft;
}

DWORD WINAPI c6ServerThread(serverthread_start_info* infoParam)
{

	CallService (MS_SYSTEM_THREAD_PUSH, 0, 0);

  	serverthread_start_info info;

  	info = *infoParam;
  	mir_free(infoParam);
	infoParam = NULL;

	int recvResult;
	NETLIBPACKETRECVER packetRecv;

	hServerConn = (HANDLE)CallService(MS_NETLIB_OPENCONNECTION, (WPARAM)hNetlibUser, (LPARAM)&info.nloc);

	mir_free(info.nloc.szHost);
	info.nloc.szHost = NULL;

	// Login error
	if (hServerConn == NULL)
	{

		int oldStatus = c6Status;

		hServerConn = NULL;
		c6Status = ID_STATUS_OFFLINE;
		ProtoBroadcastAck(C6PROTOCOLNAME, NULL, ACKTYPE_STATUS, ACKRESULT_SUCCESS, (HANDLE)oldStatus, c6Status);

	  	LogPopup(0, POPUPCOLOR_ORANGE, Translate("Unable to connect to login server."));
		c6LogMsg("Unable to connect to C6 login server");

    	CallService (MS_SYSTEM_THREAD_POP, 0, 0);

		return 0;
	}

	// Initialize direct connection ports
	{
		NETLIBBIND nlb = {0};

		nlb.cbSize = sizeof(nlb);
		nlb.pfnNewConnection = newConnectionReceived;

    	hDirectBoundPort = (HANDLE)CallService(MS_NETLIB_BINDPORT, (WPARAM)hDirectNetlibUser, (LPARAM)&nlb);
    	if (!hDirectBoundPort && (GetLastError() == 87)) { // this ensures old Miranda also can bind a port for a dc

      		nlb.cbSize = NETLIBBIND_SIZEOF_V1;
      		hDirectBoundPort = (HANDLE)CallService(MS_NETLIB_BINDPORT, (WPARAM)hDirectNetlibUser, (LPARAM)&nlb);

    	}
		if (hDirectBoundPort == NULL) {

			c6LogMsg("Miranda was unable to allocate a port to listen for direct p2p connections between clients. You will be able to use most of the C6 network without problems but you may be unable to send or receive files.");
			showError(); // deep Info
			wListenPort = 0;

		} else {

		wListenPort = nlb.wPort;
		dwLocalInternalIP = nlb.dwInternalIP;
		c6LogMsg("P2P Listen at %d.%d.%d.%d:%d",(dwLocalInternalIP & 0xff000000)>>24,(dwLocalInternalIP & 0x00ff0000)>>16,
				(dwLocalInternalIP & 0x0000ff00)>>8,dwLocalInternalIP & 0x000000ff,wListenPort);
		}

	}

	c6header_pkt r_pkt;
	BYTE *buffer = NULL;

	// infinite cycle for server events
	for(;;)	{

		recvResult = c6Recv(hServerConn, &r_pkt, 6);
		if (recvResult == 0 || recvResult == SOCKET_ERROR)
			break;

		c6LogMsg("%s receiving: id %#04x - cmd %#04x - cnt %d - len %d",
          getTimeMsg(),
          r_pkt.id, r_pkt.cmd, ntohs(r_pkt.count), ntohs(r_pkt.len));

  		if (r_pkt.id != 0x20) {
      		c6LogMsg("Invalid packet ID %#04x", r_pkt.id);
      		break;
   		}

   		if (r_pkt.cmd == CLIENT_EXIT_OK) {
			c6LogMsg("Ok server close");
			break;
		}

		int datalen = ntohs(r_pkt.len);

		if (datalen) {
			buffer = mir_alloc(datalen);
			recvResult = c6Recv(hServerConn, buffer, datalen);
			if (recvResult == 0 || recvResult == SOCKET_ERROR)
				break;
		}

		if (handleServerCommand(r_pkt.cmd, buffer, datalen, &info))
			break;  // Terminate

		if (buffer) {
			mir_free(buffer);
			buffer = NULL;
		}

	}

	CloseHandle(serverThreadId.hThread);

	// Close DC port
	Netlib_CloseHandle(hDirectBoundPort);
	hDirectBoundPort = 0;

	if (buffer) {
		mir_free(buffer);
		buffer = NULL;
	}

    int sck = CallService(MS_NETLIB_GETSOCKET, (WPARAM)hServerConn, (LPARAM)0);
    if (sck!=INVALID_SOCKET) shutdown(sck, 2); // close gracefully
	Netlib_CloseHandle(hServerConn);
	hServerConn = NULL;

	ResetAllContact();

	C6SetMyStatus(ID_STATUS_OFFLINE);

	DBWriteContactSettingDword(NULL, C6PROTOCOLNAME, "LogonTS", 0); // clear logon time

	// stop welcome+
	if (ServiceExists(MS_EAX_STOPMESSAGE)) {
		CallService(MS_EAX_STOPMESSAGE, 0, 0);
	}

	c6LogMsg("Server Thread Ended");

    CallService (MS_SYSTEM_THREAD_POP, 0, 0);

	return TRUE;

}

//--------------------------------------------------------------------
//                              c6Login
//--------------------------------------------------------------------

int c6Login(int status)
{

	serverthread_start_info* stsi;

	DBVARIANT dbv = {DBVT_DELETED};

	stsi = (serverthread_start_info*)mir_calloc(sizeof(serverthread_start_info));
	stsi->nloc.cbSize = sizeof(NETLIBOPENCONNECTION);
	stsi->nloc.flags = 0;

	stsi->status = status;

	// Server host name
	if (DBGetContactSetting(NULL,C6PROTOCOLNAME,"LoginServer",&dbv))
		stsi->nloc.szHost = mir_strdup(C6_DEFAULT_LOGIN_SERVER);
	else stsi->nloc.szHost = mir_strdup(dbv.pszVal);

	DBFreeVariant(&dbv);

    stsi->nloc.wPort = (WORD)DBGetContactSettingWord(NULL,C6PROTOCOLNAME,"C6Port", DEFAULT_SERVER_PORT);

	if(!DBGetContactSetting(NULL,C6PROTOCOLNAME, "LoginNickName", &dbv))
	  	stsi->pszNick = mir_strdup(dbv.pszVal);
	else
		{
			c6LogMsg("No nick !");
			LogPopup(0, POPUPCOLOR_ORANGE, Translate("Login: You have not entered a nick name."));
	  		Netlib_Logf(hNetlibUser, "C6 Login: You have not entered a nick name.");

			C6SetMyStatus(ID_STATUS_OFFLINE);

			mir_free(stsi->nloc.szHost);
			return 0;
		}

	DBFreeVariant(&dbv);

	// User password
	DBGetContactSetting(NULL, C6PROTOCOLNAME, "Password", &dbv);
	if ( dbv.pszVal && (strlen(dbv.pszVal) > 0) ) {
		CallService(MS_DB_CRYPT_DECODESTRING, strlen(dbv.pszVal) + 1, (LPARAM)dbv.pszVal);
	    stsi->pszPass = mir_strdup(dbv.pszVal);
       }
	else
		{
			c6LogMsg("No Password!");
			LogPopup(0, POPUPCOLOR_ORANGE, Translate("Login: You have not entered a password."));
	  		Netlib_Logf(hNetlibUser, "C6 Login: You have not entered a password.");

			C6SetMyStatus(ID_STATUS_OFFLINE);

			mir_free(stsi->pszNick);
			mir_free(stsi->nloc.szHost);
			return 0;
		}

	DBFreeVariant(&dbv);

	c6LogMsg("Connecting to %s:%d", stsi->nloc.szHost, stsi->nloc.wPort);

	serverThreadId.hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)c6ServerThread, (LPVOID)stsi, 0, &serverThreadId.dwThreadId);
	if (!serverThreadId.hThread){

		c6LogMsg("No Thread");
		LogPopup(0, POPUPCOLOR_ORANGE, Translate("No Thread"));
		showError();

		mir_free(stsi->pszNick);
		mir_free(stsi->pszPass);
		mir_free(stsi->nloc.szHost);
		return 0;
	}

    return 1;

}

