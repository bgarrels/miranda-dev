/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

ULONG ulLocalExternalIP;

extern HANDLE hServerConn;

extern int client_count;

extern char server_key[], md5_key[];

//--------------------------------------------------------------------
//                           sendToServer
//--------------------------------------------------------------------

int sendToServer(BYTE **bpacket, WORD size)
{
   	int length, ret;
   	c6header_pkt *s_pkt;
   	BYTE *data;

 	if (*bpacket) {

    	NETLIBBUFFER nlb = {0};
		int nRetries;

    	length = sizeof(c6header_pkt) + size;

    	data = (BYTE *)mir_alloc(length);

	    s_pkt = (c6header_pkt *) data;
    	s_pkt->id = 0x10;
    	s_pkt->cmd = 0x0f;
    	s_pkt->count = htons(client_count);
    	s_pkt->len = htons(size);

		c6LogMsg("sending: id %#04x - cmd %#04x - cnt %d - len %d (%d)",
				s_pkt->id, s_pkt->cmd, ntohs(s_pkt->count), ntohs(s_pkt->len), length);

    	packet_encode(&data[sizeof(c6header_pkt)], *bpacket, size);

    	nlb.buf = data;
    	nlb.len = length;
    	nlb.flags = MSG_RAW;

		for (nRetries = 3; nRetries >= 0; nRetries--) {

 		    ret = CallService(MS_NETLIB_SEND, (WPARAM)hServerConn, (LPARAM)&nlb);

			if (ret != SOCKET_ERROR)
				break;

			Sleep(1000);

		}

     	mir_free(data);

     	mir_free(*bpacket);
     	*bpacket = NULL;

	 	if (ret == SOCKET_ERROR)
		 	return 0;

     	client_count++;

	 	return 1;
 	}
 	return 0;
}

//--------------------------------------------------------------------
//                        packed functions ...
//--------------------------------------------------------------------

void packHDR(BYTE **bpacket, char cmd, WORD wlen)
{

	c6header_pkt *ptr = (c6header_pkt *)*bpacket;

	ptr->id = 0x10;
    ptr->cmd = cmd;
    ptr->count = htons(client_count);
    ptr->len = wlen;

	*bpacket += sizeof(c6header_pkt);

}

void packSTRwLEN(BYTE **bpacket, LPSTR str)
{

    (*bpacket)[0] = (BYTE)strlen(str);
	(*bpacket)++;

	strncpy(*bpacket, str, strlen(str));
    (*bpacket) += strlen(str);

}

void packSTR(BYTE **bpacket, WORD wlen, LPVOID str)
{

	memcpy(*bpacket, str, wlen);
    (*bpacket) += wlen;

}

void packBYTE(BYTE **bpacket, BYTE by)
{

    (*bpacket)[0] = by;
	(*bpacket)++;

}

void packWORD(BYTE **bpacket, WORD w)
{

	(*bpacket)[0] = ((w & 0xff00) >> 8);
	(*bpacket)[1] = (w & 0x00ff);

	(*bpacket) += 2;

}

void packDWORD(BYTE **bpacket, DWORD dw)
{

	(*bpacket)[0] = (BYTE)((dw & 0xff000000) >> 24);
	(*bpacket)[1] = (BYTE)((dw & 0x00ff0000) >> 16);
	(*bpacket)[2] = (BYTE)((dw & 0x0000ff00) >> 8);
	(*bpacket)[3] = (BYTE) (dw & 0x000000ff);

	(*bpacket) += 4;

}

//--------------------------------------------------------------------
//                          c6SearchByNick
//--------------------------------------------------------------------

WORD c6SearchByNick(LPSTR szUser, LPSTR szNick)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(szUser) + 1 + strlen(szNick);

    c6LogMsg("SEARCHNICK");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, SEARCHNICK, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, szUser);
	packSTRwLEN(&bpacket, szNick);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                          c6ReqClientExit
//--------------------------------------------------------------------

WORD c6ReqClientExit(LPSTR szUser)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(szUser) + 1;

    c6LogMsg("CLIENT_REQ_EXIT");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, CLIENT_REQ_EXIT, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, szUser);
	packBYTE(&bpacket, '\0');

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                        c6NetFriendStatus
//--------------------------------------------------------------------

WORD c6NetFriendStatus(const LPSTR szBuffer, int nBodyLen, int nContacts)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 2 + nBodyLen;

    c6LogMsg("REQ_USERS");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, REQ_USERS, htons(size - sizeof(c6header_pkt)));
	packWORD(&bpacket, nContacts);
	packSTR(&bpacket, nBodyLen, szBuffer);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                        c6SendGetInfoServ
//--------------------------------------------------------------------

WORD c6SendGetInfoServ(LPSTR szUser)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(szUser);

    c6LogMsg("REQ_PROFILE");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, REQ_PROFILE, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, szUser);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                     c6SendSrcByEmail2Serv
//--------------------------------------------------------------------

WORD c6SendSrcByEmail2Serv(LPSTR pszemail)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszemail);

    c6LogMsg("SEARCHEMAIL");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, SEARCHEMAIL, htons(1+strlen(pszemail)));
	packSTRwLEN(&bpacket, pszemail);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                       c6SendSrcAdvServ
//--------------------------------------------------------------------

WORD c6SendSrcAdvServ(WORD wCount, BYTE* fieldsBuffer)
{
    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 2 + wCount - 1;

    c6LogMsg("SEARCHPROFILE");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, SEARCHPROFILE, htons(size - sizeof(c6header_pkt)));
	packWORD(&bpacket, fieldsBuffer[0]);
	packSTR(&bpacket, wCount-1, &fieldsBuffer[1]);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                       c6NewChangeStatus
//--------------------------------------------------------------------

WORD c6NewChangeStatus(LPSTR pszUser,BOOL bAway,BYTE status,LPSTR pszStatusMsg)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszUser) + 8 + sizeof(BYTE);

	if (pszStatusMsg)
		size += strlen(pszStatusMsg) + 4;

    c6LogMsg("CHNG_NEWSTATUS");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, CHNG_NEWSTATUS, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszUser);
	packBYTE(&bpacket, 0x00);
	packBYTE(&bpacket, (pszStatusMsg)?0x02:0x01);
	packBYTE(&bpacket, 0x00);
	packBYTE(&bpacket, 0x01);
	packBYTE(&bpacket, 0x02);
	packBYTE(&bpacket, 0x00);
	packBYTE(&bpacket, 0x00);

	if (bAway)
		packBYTE(&bpacket, 0x03);
	else packBYTE(&bpacket, 0x02);

	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "IPVisible", 0)) // Show IP
    	status |= C6_IP_SHOWED;

   	status |= C6_FILETRASFER;

	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "AdvSearchInvisible", 0))
    	status |= 0x02;

	packBYTE(&bpacket, status);

	if (pszStatusMsg) {
		packBYTE(&bpacket, 0x00);
		packBYTE(&bpacket, 0x02);
		packBYTE(&bpacket, 0x05);
		packSTRwLEN(&bpacket, pszStatusMsg);
	}

	return sendToServer(&bp, size);

}

void strchange(LPSTR *pszMsg, int pos1, int pos2)
{

	int  i, j;
	char *pszNewMsg;

	pszNewMsg = (char*)mir_alloc(strlen(*pszMsg)+1-7);
	j = 0;
	for (i = 0; i < pos1; i++)
		pszNewMsg[j++] = (*pszMsg)[i];
	for (i = pos1+3; i < pos2; i++)
		pszNewMsg[j++] = (*pszMsg)[i];
	for (i = pos2+4; i < (int)strlen(*pszMsg); i++)
		pszNewMsg[j++] = (*pszMsg)[i];
	pszNewMsg[j]='\0';

	mir_free(*pszMsg);
	*pszMsg = pszNewMsg;

}

int htol(char *s)
{

	unsigned int i;
	int n;

	n = 0;
	for(i = 0; i < strlen(s); i++)
		if (s[i]>='0' && s[i]<='9')
			n = 16 * n  + s[i] - '0';
		else if (s[i]>='A' && s[i]<='F')
			n = n * 16 + s[i] - 'A' + 10;
		else if (s[i]>='a' && s[i]<='f')
			n = n * 16 + s[i] - 'a' + 10;

	return n;

}

void cutBBCode(LPSTR *pszMsg, BYTE *textformatting)
{

	int  pos1, pos2, i, j;
	BYTE style = 0;
	char *pszNewMsg;

	// bold
	pos2 = strpos(*pszMsg,"[/b]");
	if (pos2>0) {

		pos1 = strpos(*pszMsg,"[b]");
		if (pos1>=0 && pos2 > pos1){
			style = 1;
			strchange(pszMsg, pos1, pos2);
		}

	}
	// italic
	pos2 = strpos(*pszMsg,"[/i]");
	if (pos2>0) {

		pos1 = strpos(*pszMsg,"[i]");
		if (pos1>=0 && pos2 > pos1){
			style += 2;
			strchange(pszMsg, pos1, pos2);
		}

	}
	// underline
	pos2 = strpos(*pszMsg,"[/u]");
	if (pos2>0) {

		pos1 = strpos(*pszMsg,"[u]");
		if (pos1>=0 && pos2 > pos1){
			style += 4;
			strchange(pszMsg, pos1, pos2);
		}

	}
	if (style)
		textformatting[1] = (8+style);

	// text size
	pos2 = strpos(*pszMsg,"[/size]");
	if (pos2>0) {
		char buf[5];
		pos1 = strpos(*pszMsg,"[size=");
		if (pos1>=0) {
			int pos3 = pos1+6;
			j = 0;
			while ((*pszMsg)[pos3]!=']') buf[j++] = (*pszMsg)[pos3++];
			buf[j++]='\0';

			textformatting[6] = (BYTE)atoi(buf);

			pszNewMsg = (char*)mir_alloc(strlen(*pszMsg)+1-7-(pos3-pos1)-1);

			j = 0;
			for (i = 0; i < pos1; i++)
				pszNewMsg[j++] = (*pszMsg)[i];
			for (i = pos3+1; i < pos2; i++)
				pszNewMsg[j++] = (*pszMsg)[i];
			for (i = pos2+7; i < (int)strlen(*pszMsg); i++)
				pszNewMsg[j++] = (*pszMsg)[i];
			pszNewMsg[j]='\0';

			mir_free(*pszMsg);
			*pszMsg = pszNewMsg;
		}
	}

	// text color
	pos2 = strpos(*pszMsg, "[/color]");
	if (pos2 > 0) {
		char buf[15];
		pos1 = strpos(*pszMsg, "[color=");
		if (pos1>=0) {
			int pos3 = pos1+7;
			j = 0;
			while ((*pszMsg)[pos3] != ']') buf[j++] = (*pszMsg)[pos3++];
			buf[j++] = '\0';

			if (buf[0] == '#') { // hexadecimal

				char buf1[10];
				// Red
				strncpy(buf1, buf+1, 2);
				textformatting[2] = (BYTE)htol(buf1);
				// Green
				strncpy(buf1, buf+3, 2);
				textformatting[3] = (BYTE)htol(buf1);
				// Blue
				strncpy(buf1, buf+5, 2);
				textformatting[4] = (BYTE)htol(buf1);

			} else {

				if (!strcmp(buf, "red"))
					textformatting[2] = 0xFF;
				else if (!strcmp(buf, "green"))
					textformatting[3] = 0xFF;
				else if (!strcmp(buf, "blue"))
					textformatting[4] = 0xFF;
				else if (!strcmp(buf, "magenta")){
					textformatting[2] = 0xFF;
					textformatting[4] = 0xFF;
				}
				else if (!strcmp(buf, "yellow")){
					textformatting[2] = 0xFF;
					textformatting[3] = 0xFF;
				}
				else if (!strcmp(buf, "cyan")){
					textformatting[3] = 0xFF;
					textformatting[4] = 0xFF;
				}
				else if (!strcmp(buf, "white")){
					textformatting[2] = 0xFF;
					textformatting[3] = 0xFF;
					textformatting[4] = 0xFF;
				}

			}

			pszNewMsg = (char*)mir_alloc(strlen(*pszMsg)+1-7-(pos3-pos1)-1);

			j = 0;
			for (i = 0; i < pos1; i++)
				pszNewMsg[j++] = (*pszMsg)[i];
			for (i = pos3+1; i < pos2; i++)
				pszNewMsg[j++] = (*pszMsg)[i];
			for (i = pos2+8; i < (int)strlen(*pszMsg); i++)
				pszNewMsg[j++] = (*pszMsg)[i];
			pszNewMsg[j]='\0';

			mir_free(*pszMsg);
			*pszMsg = pszNewMsg;
		}
	}

}

//--------------------------------------------------------------------
//                          c6SendMessageServ
//--------------------------------------------------------------------

WORD c6SendMessage2Serv(int type, BYTE style, BYTE op, LPSTR szUser, LPSTR szNick, const LPSTR szMessage)
{

	BYTE textformatting[7] = { 0x00, 0x08, 0x00, 0x00, 0x00, 0x08, 0x0a };
	LPSTR szMessageCopy;
    BYTE *bpacket, *bp;

	szMessageCopy = (LPSTR)mir_alloc(strlen(szMessage)+1);
	strcpy(szMessageCopy, szMessage);

	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseBBCode", 0)) {

		cutBBCode(&szMessageCopy, textformatting);
	}

	WORD size = sizeof(c6header_pkt) + 1 + strlen(szUser) + 3 + strlen(szNick) + 4 +
	            strlen(szMessageCopy);

    c6LogMsg("MESSAGE");

	if (type == OF_MESSAGE)
		size -= 2;
	else if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseBBCode", 0))
		size += 7;

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, type, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, szUser);

	packBYTE(&bpacket, 0x00);
	packBYTE(&bpacket, 0x01);

	packSTRwLEN(&bpacket, szNick);

	if (type == OL_MESSAGE) {

		if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseBBCode", 0)) {
			packWORD(&bpacket, strlen(szMessageCopy) + 2 + 7);
			packBYTE(&bpacket, style);
		}
		else {
			packWORD(&bpacket, strlen(szMessageCopy) + 2);
			packBYTE(&bpacket, style);
		}

		packBYTE(&bpacket, op);

	} else packWORD(&bpacket, strlen(szMessageCopy));

	packSTR(&bpacket, strlen(szMessageCopy), szMessageCopy);

	if (type == OL_MESSAGE && DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseBBCode", 0)) {
		packSTR(&bpacket, 7, textformatting);
	}

	int iret = sendToServer(&bp, size);
	mir_free(szMessageCopy);

	return iret;
}

WORD c6SendMessageServ(int type, LPSTR szUser, LPSTR szNick, const LPSTR szMessage)
{
	BYTE style;
	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseBBCode", 0))
		style = NEW_STYLE_MSG;
	else style = ORDINARY_MSG;
	return c6SendMessage2Serv(type, style, ORDINARY_OP, szUser, szNick, szMessage);
}

//--------------------------------------------------------------------
//                         c6SendPongServ
//--------------------------------------------------------------------

WORD c6SendPongServ(void)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt);

    c6LogMsg("PONG");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, PONG, htons(0));

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                        c6RemoveNetFriend
//--------------------------------------------------------------------

WORD c6RemoveNetFriend(const LPSTR pszNick)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 2 + 1 + strlen(pszNick);

    c6LogMsg("DEL_USERS");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, DEL_USERS, htons(size - sizeof(c6header_pkt)));
	packWORD(&bpacket, 1);
	packSTRwLEN(&bpacket, pszNick);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                        getMyIP (in LAN doesn't work)
//--------------------------------------------------------------------

ULONG getMyIP(void)
{
	static SOCKADDR_IN sock_addr;
	int sock_len;

    int sock = CallService(MS_NETLIB_GETSOCKET, (WPARAM)hServerConn, (LPARAM)0);
    if (getsockname(sock, (struct sockaddr *) &sock_addr, &sock_len) < 0) {
    	c6LogMsg("GENERIC_COMMUNICATION_ERROR");
      	return 0;   // signal to reset internal status
    }

	return (ULONG)htonl(sock_addr.sin_addr.S_un.S_addr);

}

//--------------------------------------------------------------------
//                            c6LoginServ
//--------------------------------------------------------------------

WORD c6LoginServ(LPSTR szUser, LPSTR szPass)
{

    BYTE *bpacket, *bp;
    char pass2[16];
    char nick2[16];

	WORD size = sizeof(c6header_pkt) + 1 + strlen(szUser) + 34 + 8;

    c6LogMsg("LOGIN");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, LOGIN, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, szUser);

	nickpass_encode(szPass, pass2, 1);
	packBYTE(&bpacket, 16);
	packSTR(&bpacket, 16, pass2);

    nickpass_encode(szUser, nick2, 0);
	packBYTE(&bpacket, 16);
	packSTR(&bpacket, 16, nick2);

	BYTE m;
	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", 0))
		m = 0x0b;
	else m = 0x02;

	packBYTE(&bpacket, m);
	packBYTE(&bpacket, 0x3c);

	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "IPVisible", 0)) // Show IP
		ulLocalExternalIP = getMyIP();
	else ulLocalExternalIP = 0x7f000001; // localhost = 127.0.0.1

	packDWORD(&bpacket, htonl(ulLocalExternalIP));

	packBYTE(&bpacket, 0x00);
	packBYTE(&bpacket, 0x1e);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                       c6KeyLoginServ
//--------------------------------------------------------------------

WORD c6KeyLoginServ(LPSTR szUser, LPSTR szPass)
{

    BYTE *bpacket, *bp, *xml_blob;
    char szStr[13];
    char *buffer, *bb;

	WORD ws = 7 + 24 + 24 + 8 + strlen(szUser) + strlen(szPass);
	WORD wl = ((ws / 8) + 1) * 8;
	WORD size = sizeof(c6header_pkt) + 1 + 12 + 2 + wl + 2;

    c6LogMsg("LOGIN_AUTH");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	bb = buffer = (char *)mir_alloc(ws + 1);
  	xml_blob = (BYTE *)mir_alloc(wl);

	if (bp == NULL || bb == NULL || xml_blob == NULL) {
		mir_free(xml_blob);
		mir_free(bb);
		mir_free(bp);
    	c6LogMsg("Cannot get memory to execute command");
      	return 0;
    }

	packSTR(&buffer, 7, "<user>\r");
	packSTR(&buffer, 12, "  <username>");
	packSTR(&buffer, strlen(szUser), szUser);
	packSTR(&buffer, 12, "</username>\r");
	packSTR(&buffer, 12, "  <password>");
	packSTR(&buffer, strlen(szPass), szPass);
	packSTR(&buffer, 12, "</password>\r");
	packSTR(&buffer, 8, "</user>\r");
	packSTR(&buffer, 1, "\0");

	client_count = 1;
    packHDR(&bpacket, LOGIN_AUTH, htons(size - sizeof(c6header_pkt)));
	strcpy(szStr,"nicksforuser");
	packSTRwLEN(&bpacket, szStr);

	packWORD(&bpacket, wl);

    generMD5Key(md5_key,server_key);

  	memset(xml_blob, 0, wl);
  	memcpy(xml_blob, bb ,ws);

  	BlowFishEncode(wl, xml_blob, 16, md5_key);

	packSTR(&bpacket, wl, xml_blob);

	BYTE m;
	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", 0))
		m = 0x0b;
	else m = 0x02;

	packBYTE(&bpacket, m);
	packBYTE(&bpacket, 0x3c);

	mir_free(xml_blob);
	mir_free(bb);

	return sendToServer(&bp, size);

}

#ifdef ROOM_C6

//--------------------------------------------------------------------
//                        c6QueryRooms
//--------------------------------------------------------------------

WORD c6QueryRooms(const LPSTR pszNick)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszNick);

    c6LogMsg("QUERY_ROOMS");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, QUERY_ROOM, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszNick);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                        c6QueryRooms
//--------------------------------------------------------------------

WORD c6QueryMultiRooms(const LPSTR pszNick, int numberGroup)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszNick) + 6 + 4 + 3;

    c6LogMsg("QUERY_MULTIROOMS");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, QUERY_MULTIROOM, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszNick);

	packDWORD(&bpacket, 0);
	packBYTE(&bpacket, 0x02);
	packBYTE(&bpacket, 0x00);

	packBYTE(&bpacket, 0x01);
	packBYTE(&bpacket, 0x32);
	packBYTE(&bpacket, numberGroup); // nr. room group

	packDWORD(&bpacket, 0);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                         c6reqEnterExitRoom
//--------------------------------------------------------------------

WORD c6reqEnterExitRoom(int action, const LPSTR pszNick, LPSTR pszRoomName)
{

	if (action)
		return c6reqEnterNewRoom(pszNick, pszRoomName, NULL);

	return c6reqExitNewRoom(pszNick, pszRoomName);

}

//--------------------------------------------------------------------
//                         c6SendMessage2Room
//--------------------------------------------------------------------

WORD c6SendMessage2Room(const LPSTR pszNick, LPSTR pszRoomName, LPSTR pszMessage)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszNick) + 1 + strlen(pszRoomName) + 4 + strlen(pszMessage);

    c6LogMsg("ROOM_MSG");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, ROOM_MSG, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszNick);
	packSTRwLEN(&bpacket, pszRoomName);

	packWORD(&bpacket, 2 + strlen(pszMessage));
	packWORD(&bpacket, 0);

	packSTR(&bpacket, strlen(pszMessage), pszMessage);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                         c6reqProfileRoom
//--------------------------------------------------------------------

WORD c6reqProfileRoom(LPSTR pszRoomName)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszRoomName);

    c6LogMsg("REQUEST_ROOM_PROFILE");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, REQUEST_ROOM_PROFILE, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszRoomName);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                         c6reqEnterNewRoom
//--------------------------------------------------------------------

WORD c6reqEnterNewRoom(const LPSTR pszNick, LPSTR pszRoomName, LPSTR pszPassword)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszNick) + 1 + strlen(pszRoomName) + 6;
	if (pszPassword)
		size += strlen(pszPassword);

   	c6LogMsg("ENTER_NEWROOM");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, ENTER_NEWROOM, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszNick);
	packSTRwLEN(&bpacket, pszRoomName);

	if (pszPassword) {
		packSTRwLEN(&bpacket, pszPassword);
	}
	else packBYTE(&bpacket, 0);

	packBYTE(&bpacket, 0);
	packWORD(&bpacket, 0);
	packWORD(&bpacket, 0x08f);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                         c6reqExitNewRoom
//--------------------------------------------------------------------

WORD c6reqExitNewRoom(const LPSTR pszNick, LPSTR pszRoomName)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszNick) + 1 + strlen(pszRoomName) + 1;

   	c6LogMsg("EXIT_NEWROOM");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, EXIT_NEWROOM, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszNick);
	packSTRwLEN(&bpacket, pszRoomName);
	packBYTE(&bpacket, 0);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                         c6reqCreateNewRoom
//--------------------------------------------------------------------

WORD c6reqCreateNewRoom(LPSTR pszUser, LPSTR pszRoomName, LPSTR pszArgument, LPSTR pszPassword, int kind, BYTE numberGroup)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszUser) + 1 + strlen(pszRoomName) + 2 +
				strlen(pszArgument) + 4 + 1 + strlen(pszPassword) + 4 + 6 ;

    c6LogMsg("CREATE_NEWROOM");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, CREATE_NEWROOM, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszUser);
	packSTRwLEN(&bpacket, pszRoomName);
	packWORD(&bpacket, strlen(pszArgument));
	packSTR(&bpacket, strlen(pszArgument), pszArgument);

	if (strlen(pszPassword)) {
		// public / private /
		packDWORD(&bpacket, (kind) ? htonl(0xFFFFFF85) : htonl(0xFFFFFF84) );
		packSTRwLEN(&bpacket, pszPassword);
	}
	else {
		// public / private
		packDWORD(&bpacket, (kind) ? htonl(0x00000005) : htonl(0x00000004) );
		packBYTE(&bpacket, 0);
	}

	packWORD(&bpacket, 0);
	packWORD(&bpacket, 0x08f);

	packBYTE(&bpacket, 0x00);
	packBYTE(&bpacket, 0x02);
	packBYTE(&bpacket, 0x32);
	packBYTE(&bpacket, numberGroup); // nr. room group
	packBYTE(&bpacket, 0x46);
	packBYTE(&bpacket, 0x01);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                        c6reqBanUserNewRoom
//--------------------------------------------------------------------

WORD c6reqBanUserNewRoom(const LPSTR pszUser, LPSTR pszRoomName, LPSTR pszNick, int duration)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszUser) + 12 + 1 + strlen(pszNick) + 2 + 1 + strlen(pszRoomName) + 4;

   	c6LogMsg("BANUSER_NEWROOM");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, KICK_NEWROOM, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, pszUser);
	packBYTE(&bpacket, 0);
	packBYTE(&bpacket, 0);
	packBYTE(&bpacket, 0);
	packBYTE(&bpacket, 3);
	packWORD(&bpacket, 0);
	packWORD(&bpacket, 0x012C);
	packWORD(&bpacket, 0);
	packWORD(&bpacket, 0x0001);
	packSTRwLEN(&bpacket, pszNick);
	packBYTE(&bpacket, 0);
	packBYTE(&bpacket, 0);
	packSTRwLEN(&bpacket, pszRoomName);
	packDWORD(&bpacket, duration);

	return sendToServer(&bp, size);

}

#endif

//--------------------------------------------------------------------
//                        c6activateFileReception
//--------------------------------------------------------------------

WORD c6activateFileReception(LPSTR szUser,LPSTR szNickSender,int port)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(szUser) + 1 + strlen(szNickSender) + 2 + 2 + 1;

    c6LogMsg("ACTIVATE_REC");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, ACTIVATE_REC, htons(size - sizeof(c6header_pkt)));

	packSTRwLEN(&bpacket, szUser);
	packSTRwLEN(&bpacket, szNickSender);

	packWORD(&bpacket, 0);
	packWORD(&bpacket, port);
	packBYTE(&bpacket, 3);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                           c6SendFileServ
//--------------------------------------------------------------------

WORD c6SendFileServ(LPSTR pszUser, LPSTR pszNick)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszUser) + 1 + strlen(pszNick) + 1;

    c6LogMsg("SEND_FILE");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
    	c6LogMsg("Cannot get memory");
      	return 0;
    }

    packHDR(&bpacket, SEND_FILE, htons(size - sizeof(c6header_pkt)));

	packSTRwLEN(&bpacket, pszUser);

	packSTRwLEN(&bpacket, pszNick);

	packBYTE(&bpacket, FILE_TRANSFER_OP); // 3

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                          c6SendReqOLMsgServ
//--------------------------------------------------------------------

WORD c6SendReqOLMsgServ(LPSTR pszUser)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszUser);

    c6LogMsg("REQUEST_OLMSG");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
    	c6LogMsg("Cannot get memory");
      	return 0;
    }

    packHDR(&bpacket, REQUEST_OLMSG, htons(size - sizeof(c6header_pkt)));

	packSTRwLEN(&bpacket, pszUser);

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                        c6SendRemOLMsgServ
//--------------------------------------------------------------------

WORD c6SendRemOLMsgServ(LPSTR pszUser, DWORD id)
{

    BYTE *bpacket, *bp;

	WORD size = sizeof(c6header_pkt) + 1 + strlen(pszUser) + 2 + 4;

    c6LogMsg("REMOVE_OLMSG");

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
    	c6LogMsg("Cannot get memory");
      	return 0;
    }

    packHDR(&bpacket, REMOVE_OLMSG, htons(size - sizeof(c6header_pkt)));

	packSTRwLEN(&bpacket, pszUser);
	packWORD(&bpacket, 1);
	packDWORD(&bpacket, (id));

	return sendToServer(&bp, size);

}

//--------------------------------------------------------------------
//                     c6sendTypingNotification
//--------------------------------------------------------------------

WORD c6sendTypingNotification(LPSTR szUser, LPSTR szNick)
{

    BYTE *bpacket, *bp;
	char *szMessage = "sta scrivendo...";

	WORD size = sizeof(c6header_pkt) + 1 + strlen(szUser) + 3 + strlen(szNick) + 4 +
	            strlen(szMessage);

    c6LogMsg("SEND_TYPING");

	bp = bpacket = (BYTE *)malloc(size+1);
	if (bp == NULL) {
      c6LogMsg("Cannot get memory to execute command");
      return 0;
    }

    packHDR(&bpacket, OL_MESSAGE, htons(size - sizeof(c6header_pkt)));
	packSTRwLEN(&bpacket, szUser);

	packBYTE(&bpacket, 0x00);
	packBYTE(&bpacket, 0x01);

	packSTRwLEN(&bpacket, szNick);

	packWORD(&bpacket, strlen(szMessage) + 2);
	packBYTE(&bpacket, SELF_MSG); // 0x04
	packBYTE(&bpacket, TYPING_NOTIFY_OP); // 0x1d

	packSTR(&bpacket, strlen(szMessage), szMessage);

	return sendToServer(&bp, size);

}

