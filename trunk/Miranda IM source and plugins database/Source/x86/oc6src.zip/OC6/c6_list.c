/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

typedef struct tServerList
{
	char* name;
	struct tServerList* next;

} ServerList;

static ServerList* sttWLFirst = NULL;    // WhiteList
static ServerList* sttGroupFirst = NULL; // Groups

BOOL addWhiteList(const char* nick)
{
	ServerList* p = mir_alloc(sizeof(ServerList));
	if ( p == NULL )
		return FALSE;

	p->name = mir_strdup( nick );
	p->next = sttWLFirst;
	sttWLFirst = p;
	return TRUE;
}

void freeWhiteList(void)
{
	ServerList* p1;

	for (ServerList* p = sttWLFirst; p != NULL; p = p1) {
		p1 = p->next;

		mir_free(p->name);
		mir_free(p);
	}

	sttWLFirst = NULL;
}

void del1WhiteList(const char* nick)
{
	ServerList* prev = NULL;

	for (ServerList* p = sttWLFirst; p != NULL; p = p->next) {
		if (!strcmp(p->name, nick)) {
			if (prev == NULL)
				sttWLFirst = p->next;
			else
				prev->next = p->next;
			mir_free(p->name);
			mir_free(p);
			return;
		}
		prev = p;
	}
}

BOOL findWhiteList(const char *nick)
{
	for (ServerList* p = sttWLFirst; p != NULL; p = p->next)
		if (!strcmp(p->name, nick))
			return TRUE;

	return FALSE;
}

void enumWhiteList(HWND hwndList)
{
	for (ServerList* p = sttWLFirst; p != NULL; p = p->next)
		SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)p->name);

}

// ************* Groups ****************

BOOL addSrvGroup(const char* group)
{
	ServerList* p = mir_alloc(sizeof(ServerList));
	if (p == NULL)
		return FALSE;

	p->name = mir_strdup(group);
	p->next = sttGroupFirst;
	sttGroupFirst = p;
	return TRUE;
}

void freeSrvGroup(void)
{
	ServerList* p1;

	for (ServerList* p = sttGroupFirst; p != NULL; p = p1) {
		p1 = p->next;

		mir_free(p->name);
		mir_free(p);
	}

	sttGroupFirst = NULL;
}

BOOL findSrvGroup(const char *group)
{
	for (ServerList* p = sttGroupFirst; p != NULL; p = p->next)
		if (!strcmp(p->name, group))
			return TRUE;

	return FALSE;
}

BOOL del1SrvGroup(const char* group)
{
	ServerList* prev = NULL;

	for (ServerList* p = sttGroupFirst; p != NULL; p = p->next) {
		if (!strcmp(p->name, group)) {
			if (prev == NULL)
				sttGroupFirst = p->next;
			else
				prev->next = p->next;
			mir_free(p->name);
			mir_free(p);
			return TRUE;
		}
		prev = p;
	}
	return FALSE;
}

BOOL renameSrvGroup(const char *oldgroup, const char *newgroup)
{
	for (ServerList* p = sttGroupFirst; p != NULL; p = p->next)
		if (!strcmp(p->name, oldgroup)) {
			mir_free(p->name);
			p->name = mir_strdup(newgroup);
			return TRUE;
		}

	return FALSE;
}

void enumSrvGroup(HWND hwndList)
{
	for (ServerList* p = sttGroupFirst; p != NULL; p = p->next)
		SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)p->name);

}

