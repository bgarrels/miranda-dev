/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

extern HINSTANCE hInst;
// 1 // ridefinita v0.2
struct fieldnames_t agesField[]={
	{1    , "Not Defined"},
	{2    , "18-23"}, // 14-below
	{3    , "24-27"},
	{4    , "28-35"},
	{5    , "36-45"},
	{6    , "45-65"},
	{7    , "66-85"},
	{8    , "86-130"},
	{9    , "131-200"},
	{10   , "201-500"},
	{11   , "+500"}, // 500-above
	{0,  NULL}};

// 2
struct fieldnames_t genderField[]={
	{1, "Not Defined"},
	{2, "Male"},
	{3, "Female"},
	{0,  NULL}};

// 4
struct fieldnames_t workField[]={
	{1    , "Not Defined"},
	{2    , "agente di commercio"},
	{3    , "analista/programmatore"},
	{4    , "architetto"},
	{5    , "artigiano/a"},
	{6    , "avvocato"},
	{7    , "bancario/a"},
	{8    , "commercialista"},
	{9    , "commerciante"},
	{10   , "casalingo/a"},
	{11   , "dirigente"},
	{12   , "disoccupato/a"},
	{13   , "fotografo/a"},
	{14   , "giornalista"},
	{15   , "grafico/a"},
	{16   , "impiegato/a"},
	{17   , "imprenditore/trice"},
	{18   , "infermiere/a"},
	{19   , "ingegnere"},
	{20   , "insegnante"},
	{21   , "medico"},
	{22   , "musicista"},
	{23   , "notaio"},
	{24   , "operaio/a"},
	{25   , "operatore turistico"},
	{26   , "pensionato/a"},
	{27   , "procuratore legale"},
	{28   , "pubblicitario/a"},
	{29   , "ricercatore/trice"},
	{30   , "studente/essa"},
	{31   , "altra"},
	{32   , "agente immobiliare"},
	{33   , "quadro/funzionario"},
	{34   , "farmacista"},
	{35   , "istruttore sportivo"},
	{36   , "suora"},
	{37   , "prete"},
	{38   , "filosofo/a"},
	{39   , "scrittore/trice"}, // +
	{40   , "attore/trice"}, // +
	{41   , "modello/a"}, // +
	{0,  NULL}};

// 5
struct fieldnames_t stateField[]={
	{1, "Not Defined"},
	{2, "Italia"},
	{3, "Vaticano"},
	{4, "S.Marino"},
	{5, "Europa"},
	{6, "Africa"},
	{7, "Nord America"},
	{8, "Sud America"},
	{9, "Asia"},
	{10, "Australia-Nuova Zelanda"},
	{11, "Altro"},
	{0,  NULL}};

// 6
struct fieldnames_t countryField[]={
	{1, "Not Defined"},
	{2, "Abruzzo"},
	{3, "Basilicata"},
	{4, "Calabria"},
	{5, "Campania"},
	{6, "Emilia Romagna"},
	{7, "Friuli-Venezia Giulia"},
	{8, "Lazio"},
	{9, "Liguria"},
	{10, "Lombardia"},
	{11, "Marche"},
	{12, "Molise"},
	{13, "Piemonte"},
	{14, "Puglia"},
	{15, "Sardegna"},
	{16, "Sicilia"},
	{17, "Toscana"},
	{18, "Trentino-Alto Adige"},
	{19, "Umbria"},
	{20, "Valle d'Aosta"},
	{21, "Veneto"},
	{22, "---"},
	{23, "Agrigento"},
	{24, "Alessandria"},
	{25, "Ancona"},
	{26, "Aosta"},
	{27, "Arezzo"},
	{28, "Ascoli Piceno"},
	{29, "Asti"},
	{30, "Avellino"},
	{31, "Bari"},
	{32, "Belluno"},
	{33, "Benevento"},
	{34, "Bergamo"},
	{35, "Biella"},
	{36, "Bologna"},
	{37, "Bolzano"},
	{38, "Brescia"},
	{39, "Brindisi"},
	{40, "Cagliari"},
	{41, "Caltanissetta"},
	{42, "Campobasso"},
	{43, "Caserta"},
	{44, "Catania"},
	{45, "Catanzaro"},
	{46, "Chieti"},
	{47, "Como"},
	{48, "Cosenza"},
	{49, "Cremona"},
	{50, "Crotone"},
	{51, "Cuneo"},
	{52, "Enna"},
	{53, "Ferrara"},
	{54, "Firenze"},
	{55, "Foggia"},
	{56, "Forli'"},
	{57, "Frosinone"},
	{58, "Genova"},
	{59, "Gorizia"},
	{60, "Grosseto"},
	{61, "Imperia"},
	{62, "Isernia"},
	{63, "L'Aquila"},
	{64, "La Spezia"},
	{65, "Latina"},
	{66, "Lecce"},
	{67, "Lecco"},
	{68, "Livorno"},
	{69, "Lodi"},
	{70, "Lucca"},
	{71, "Macerata"},
	{72, "Mantova"},
	{73, "Massa Carrara"},
	{74, "Matera"},
	{75, "Messina"},
	{76, "Milano"},
	{77, "Modena"},
	{78, "Napoli"},
	{79, "Novara"},
	{80, "Nuoro"},
	{81, "Oristano"},
	{82, "Padova"},
	{83, "Palermo"},
	{84, "Parma"},
	{85, "Pavia"},
	{86, "Perugia"},
	{87, "Pesaro"},
	{88, "Pescara"},
	{89, "Piacenza"},
	{90, "Pisa"},
	{91, "Pistoia"},
	{92, "Pordenone"},
	{93, "Potenza"},
	{94, "Prato"},
	{95, "Ragusa"},
	{96, "Ravenna"},
	{97, "Reggio Calabria"},
	{98, "Reggio Emilia"},
	{99, "Rieti"},
	{100, "Rimini"},
	{101, "Roma"},
	{102, "Rovigo"},
	{103, "Salerno"},
	{104, "Sassari"},
	{105, "Savona"},
	{106, "Siena"},
	{107, "Siracusa"},
	{108, "Sondrio"},
	{109, "Taranto"},
	{110, "Teramo"},
	{111, "Terni"},
	{112, "Torino"},
	{113, "Trapani"},
	{114, "Trento"},
	{115, "Treviso"},
	{116, "Trieste"},
	{117, "Udine"},
	{118, "Varese"},
	{119, "Venezia"},
	{120, "Verbania"},
	{121, "Vercelli"},
	{122, "Verona"},
	{123, "Vibo Valentia"},
	{124, "Vicenza"},
	{125, "Viterbo"},
	{0,  NULL}};

// 7
struct fieldnames_t hobbyField[]={
	{1, "Not Defined"},
	{2, "nessuno"},
	{3, "arte/antiquariato"},
	{4, "bricolage"},
	{5, "cinema"},
	{6, "collezionismo"},
	{7, "computer"},
	{8, "cucina"},
	{9, "danza"},
	{10, "esoterismo"},
	{11, "filatelia"},
	{12, "fotografia"},
	{13, "fumetti"},
	{14, "giardinaggio"},
	{15, "internet"},
	{16, "lettura"},
	{17, "moto/motori"},
	{18, "musica (ascoltarla)"},
	{19, "musica (suonarla)"},
	{20, "ozio"},
	{21, "viaggi"},
	{22, "sesso"},
	{23, "sport (praticarlo)"},
	{24, "sport (in tv!)"},
	{25, "teatro"},
	{26, "altro"},
	{27, "discoteche"},
	{28, "scienze"},
	{29, "giochi da tavolo"},
	{30, "scrivere"},
	{31, "soldi"}, // +
	{32, "fitness"}, // +
	{33, "telefonino"}, // +
	{34, "videogiochi"}, // +
	{0,  NULL}};

// 8
struct fieldnames_t sportField[]={
	{1, "Not Defined"},
	{2, "nessuno"},
	{3, "aerobica"},
	{4, "arti marziali"},
	{5, "atletica"},
	{6, "automobilismo"},
	{7, "basket"},
	{8, "body building"},
	{9, "calcio/calcetto"},
	{10, "canottaggio/canoa"},
	{11, "ciclismo"},
	{12, "equitazione"},
	{13, "golf"},
	{14, "motociclismo"},
	{15, "nuoto"},
	{16, "pallavolo e/o beach volley"},
	{17, "pattinaggio"},
	{18, "pesca"},
	{19, "rugby"},
	{20, "sci/snowboard"},
	{21, "sport estremi"},
	{22, "surf"},
	{23, "tennis e/o squash"},
	{24, "vela"},
	{25, "altro"},
	{26, "caccia"},
	{27, "trekking"},
	{0,  NULL}};

// 9
struct fieldnames_t musicField[]={
	{1, "Not Defined"},
	{2, "classica"},
	{3, "country"},
	{4, "elettronica e dance"},
	{5, "hip hop e R'nB"},
	{6, "jazz e blues"},
	{7, "metal"},
	{8, "musica italiana"},
	{9, "pop"},
	{10, "rock"},
	{11, "varia"},
	{12, "world music"},
	{13, "altro"},
	{14, "un po' di tutto"},
	{15, "underground"},
	{0,  NULL}};

// 10
struct fieldnames_t cinemaField[]={
	{1, "Not Defined"},
	{2, "nessuno"},
	{3, "film di azione/avventura"},
	{4, "b-movies"},
	{5, "cartoni (e film di animazione)"},
	{6, "classici in bianco/nero"},
	{7, "commedie"},
	{8, "commedie all'italiana"},
	{9, "film drammatici"},
	{10, "film di fantascienza"},
	{11, "gialli"},
	{12, "film horror"},
	{13, "musical"},
	{14, "western"},
	{15, "altro"},
	{16, "film d'autore"},
	{17, "fantasy"},
	{0,  NULL}};

// 12
struct fieldnames_t dislikeField[]={
	{1, "Not Defined"},
	{2, "non odio niente! :-)"},
	{3, "gli addii"},
	{4, "i boxer fantasia"},
	{5, "il calcio"},
	{6, "i calzini bianchi corti"},
	{7, "la chirurgia plastica"},
	{8, "il computer"},
	{9, "le discoteche"},
	{10, "i fast-food"},
	{11, "i giornali e/o i telegiornali"},
	{12, "internet"},
	{13, "il lavoro"},
	{14, "la moda"},
	{15, "la politica"},
	{16, "la pubblicita'"},
	{17, "il reggiseno"},
	{18, "lo slowfood"},
	{19, "la sveglia"},
	{20, "la televisione"},
	{21, "Telecom Italia Net"},
	{22, "Titanic (il film)"},
	{23, "gli uomini troppo profumati"},
	{24, "le vamp"},
	{25, "i viaggi organizzati"},
	{26, "le gite fuori porta la domenica  "},
	{27, "la scuola"},
	{28, "i fanatici di internet"},
	{0,  NULL}};

// 0x0f
struct fieldnames_t clientField[]={
	{ID_CLIENT_ALL    , "Not Defined"},
	{ID_CLIENT_OC6    , "OpenC6"},
	{ID_CLIENT_CM5    , "C6 Messenger 5.0"},
	{ID_CLIENT_CM6    , "C6 Messenger 5.1"},
	{ID_CLIENT_CM7    , "C6 Messenger 5.2"},
	{ID_CLIENT_CM8    , "C6 Messenger 6.0"},
	{ID_CLIENT_CM9    , "C6 Messenger 6.1"},
	{ID_CLIENT_CM10   , "C6 Messenger 6.2"},
	{ID_CLIENT_CM11   , "C6 Messenger 7.0"},
	{ID_CLIENT_CM12   , "C6 Messenger 7.1"},
	{ID_CLIENT_CM13   , "C6 Messenger >= 7.2"},
	{ID_CLIENT_JAVA   , "JavaApplet"},
	{ID_CLIENT_MB     , "Message Box"},
	{0,  NULL}};

//--------------------------------------------------------------------
//                          getStringName
//--------------------------------------------------------------------

char *itos(int i) {
	static char s[10];
	itoa(i, s, 10);
	return s;
}

LPSTR getStringName(int code, struct fieldnames_t *names)
{
	BOOL bFound = FALSE;
	int i=0;

	while (!bFound){
		if (names[i].text == NULL)
			break;
		if (names[i].code == code)
			bFound=TRUE;
		else i++;
	}
	if (bFound)
		return Translate(names[i].text);
	c6LogMsg("code: %d", code);
	return itos(code);
}

//--------------------------------------------------------------------
//                            InitComboBox
//--------------------------------------------------------------------

static void InitComboBox(HWND hwndCombo,struct fieldnames_t *names)
{

	int iItem;
	int i;


	iItem = SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)"");
	SendMessage(hwndCombo, CB_SETITEMDATA, iItem, 0);
	SendMessage(hwndCombo, CB_SETCURSEL, iItem, 0);

	for (i = 0; ; i++)
	{
		if (names[i].text == NULL)
			break;
		iItem = SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)Translate(names[i].text));
		SendMessage(hwndCombo, CB_SETITEMDATA, iItem,names[i].code);
	}

}

//--------------------------------------------------------------------
//                       AdvancedSearchDlgProc
//--------------------------------------------------------------------

BOOL CALLBACK AdvancedSearchDlgProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch(message)
	{

		case WM_INITDIALOG:
			{
				TranslateDialogDefault(hwndDlg);
				InitComboBox(GetDlgItem(hwndDlg, IDC_GENDER), genderField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_AGERANGE), agesField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_STATE), stateField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_COUNTRY), countryField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_WORK), workField);

				InitComboBox(GetDlgItem(hwndDlg, IDC_HOBBY), hobbyField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_HOBBY2), hobbyField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_HOBBY3), hobbyField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_SPORT), sportField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_SPORT2), sportField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_SPORT3), sportField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_MUSIC), musicField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_CINEMA), cinemaField);
				InitComboBox(GetDlgItem(hwndDlg, IDC_DISLIKE), dislikeField);

				InitComboBox(GetDlgItem(hwndDlg, IDC_IDCLIENT), clientField);

				EnableWindow(GetDlgItem(hwndDlg, IDC_COUNTRY),FALSE);

				DBVARIANT dbv;
				if (!DBGetContactSetting(NULL, C6PROTOCOLNAME, "AdvSearchPreferred", &dbv)) {
					EnableWindow(GetDlgItem(hwndDlg, IDC_LOADPREFSEARCH), TRUE);
					DBFreeVariant(&dbv);
				}

			}
			return TRUE;

		case WM_COMMAND:
			{

				switch(LOWORD(wParam))
				{

				case IDC_SAVEPREFSEARCH :
					{

						int nDataLen;
						BYTE* bySearchData;

						if ((bySearchData = createAdvancedSearchStructure(hwndDlg, &nDataLen)) != NULL) {

							writeContactSettingBlob(NULL, "AdvSearchPreferred", bySearchData, nDataLen);
							mir_free(bySearchData);

							EnableWindow(GetDlgItem(hwndDlg, IDC_LOADPREFSEARCH), TRUE);

						}

					}
					break;

				case IDC_LOADPREFSEARCH :
					{

 					   	DBVARIANT dbv;

						if (!DBGetContactSetting(NULL, C6PROTOCOLNAME, "AdvSearchPreferred", &dbv)){

							SendMessage(hwndDlg, WM_COMMAND, (WPARAM)IDC_RESETADVSEARCH, 0);

								int i,tot;
								BYTE j, hobby, sport;

								BYTE *p = dbv.pbVal;
								tot = *p;

								hobby = sport = 0;
								p++;
								for (i=0; i < tot; i++) {

									j = *p;
									p++;

									switch ( j ) {

										case 0x01 :
											SendMessage(GetDlgItem(hwndDlg, IDC_AGERANGE), CB_SETCURSEL, (BYTE)*p, 0);
										break;
										case 0x02 :
											SendMessage(GetDlgItem(hwndDlg, IDC_GENDER), CB_SETCURSEL, (BYTE)*p, 0);
										break;
										case 0x04 :
											SendMessage(GetDlgItem(hwndDlg, IDC_WORK), CB_SETCURSEL, (BYTE)*p, 0);
										break;
										case 0x05 :
											SendMessage(GetDlgItem(hwndDlg, IDC_STATE), CB_SETCURSEL, (BYTE)*p, 0);
											if ((*p)==2)
												EnableWindow(GetDlgItem(hwndDlg, IDC_COUNTRY),TRUE);
										break;
										case 0x06 :
											SendMessage(GetDlgItem(hwndDlg, IDC_COUNTRY), CB_SETCURSEL, (BYTE)*p, 0);
										break;

										case 0x07 :
											SendMessage(GetDlgItem(hwndDlg, IDC_HOBBY+hobby), CB_SETCURSEL, (BYTE)*p, 0);
											hobby++;
										break;
										case 0x08 :
											SendMessage(GetDlgItem(hwndDlg, IDC_SPORT+sport), CB_SETCURSEL, (BYTE)*p, 0);
											sport++;
										break;
										case 0x09 :
											SendMessage(GetDlgItem(hwndDlg, IDC_CINEMA), CB_SETCURSEL, (BYTE)*p, 0);
										break;
										case 0x0A :
											SendMessage(GetDlgItem(hwndDlg, IDC_MUSIC), CB_SETCURSEL, (BYTE)*p, 0);
										break;
										case 0x0C :
											SendMessage(GetDlgItem(hwndDlg, IDC_DISLIKE), CB_SETCURSEL, (BYTE)*p, 0);
										break;
										case 0x0E :
											CheckDlgButton(hwndDlg,IDC_WITHAVATAR,TRUE);
										break;
										case 0x0F :
											SendMessage(GetDlgItem(hwndDlg, IDC_IDCLIENT), CB_SETCURSEL, (BYTE)*p, 0);
										break;
										case 0x16 :
											CheckDlgButton(hwndDlg,IDC_IDSTATUS,TRUE);
										break;

									} // switch
									p++;

								} // for
							DBFreeVariant(&dbv);
						}

					}
					break;

				case IDC_RESETADVSEARCH :
					{
						int i;
						for (i = 0; i <= (IDC_IDCLIENT - IDC_AGERANGE); i++)
							SendMessage(GetDlgItem(hwndDlg, IDC_AGERANGE+i), CB_SETCURSEL, 0, 0);
						CheckDlgButton(hwndDlg,IDC_WITHAVATAR,FALSE);
						CheckDlgButton(hwndDlg,IDC_IDSTATUS,FALSE);
						EnableWindow(GetDlgItem(hwndDlg, IDC_COUNTRY),FALSE);
					}
					break;
				case IDC_STATE :

					if (HIWORD(wParam)==CBN_SELCHANGE) {
                    	int index=SendDlgItemMessage(hwndDlg,IDC_STATE,CB_GETCURSEL,0,0L);
           				EnableWindow(GetDlgItem(hwndDlg, IDC_COUNTRY),(index!=CB_ERR && index == 2)?TRUE:FALSE);
					}
					break;

				case IDOK:
					SendMessage(GetParent(hwndDlg), WM_COMMAND, MAKEWPARAM(IDOK, BN_CLICKED), (LPARAM)GetDlgItem(GetParent(hwndDlg), IDOK));
					break;

				case IDCANCEL:
					break;

				default:
					break;

				}
				break;
			}

		default:
			break;

	}

	return FALSE;

}

//--------------------------------------------------------------------
//                          searchPackByte
//--------------------------------------------------------------------

static void searchPackByte(PBYTE *buf, int *buflen, BYTE b)
{

	*buf = (PBYTE)mir_realloc(*buf, 1 + *buflen);
	*(*buf + *buflen) = b;
	++*buflen;

}

//--------------------------------------------------------------------
//                   createAdvancedSearchStructure
//--------------------------------------------------------------------

PBYTE createAdvancedSearchStructure(HWND hwndDlg, int *length)
{

	PBYTE buf = NULL;
	int buflen = 0;
	int nCombo = 0;
	BYTE byValue;


	if (hwndDlg == NULL)
		return NULL;

	searchPackByte(&buf, &buflen, (BYTE)0);
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_AGERANGE, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_AGERANGE, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)1); // AGE
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
  	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_GENDER, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_GENDER, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)2); // GENDER
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_WORK, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_WORK, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)4); // WORK
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_STATE, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_STATE, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)5); // STATE
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	if (byValue==2) { // Italy only
		byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_COUNTRY, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_COUNTRY, CB_GETCURSEL, 0, 0), 0);
		if (byValue>1) {
		 searchPackByte(&buf, &buflen, (BYTE)6); // COUNTRY
		 searchPackByte(&buf, &buflen, byValue);
		 nCombo++;
		}
    }
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_HOBBY, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_HOBBY, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)7);  // HOBBY
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_HOBBY2, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_HOBBY2, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)7);  // HOBBY2
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_HOBBY3, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_HOBBY3, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)7);  // HOBBY3
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_SPORT, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_SPORT, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)8); // SPORT
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_SPORT2, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_SPORT2, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)8); // SPORT2
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_SPORT3, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_SPORT3, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)8); // SPORT3
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_MUSIC, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_MUSIC, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)9); // MUSIC = 9
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_CINEMA, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_CINEMA, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)10); // CINEMA
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_DISLIKE, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_DISLIKE, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)12); // DISLIKE = 12
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)IsDlgButtonChecked(hwndDlg, IDC_WITHAVATAR);
	if (byValue>0) {
	 searchPackByte(&buf, &buflen, (BYTE)0x0e); // AVATAR
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)SendDlgItemMessage(hwndDlg, IDC_IDCLIENT, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_IDCLIENT, CB_GETCURSEL, 0, 0), 0);
	if (byValue>1) {
	 searchPackByte(&buf, &buflen, (BYTE)0x0f); // CLIENT = 0x0f
	 searchPackByte(&buf, &buflen, byValue);
	 nCombo++;
	}
	byValue = (BYTE)IsDlgButtonChecked(hwndDlg, IDC_IDSTATUS);
	if (byValue>0) {
	 searchPackByte(&buf, &buflen, (BYTE)0x16); // Status = Available
	 searchPackByte(&buf, &buflen, 1);
	 nCombo++;
	 searchPackByte(&buf, &buflen, (BYTE)0x1c); // Status = Not Away
	 searchPackByte(&buf, &buflen, 0);
	 nCombo++;
	}

	buf[0] = nCombo;

	if (length)
		*length = buflen;

	return buf;

}

