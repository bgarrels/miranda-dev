/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_SERVER_H
#define __C6_SERVER_H

enum {

   INFOLOGIN = 0x01,
   REDIRECT,
   LOGIN_ERRPASS,
   LOGIN_USERCONN,
   CLIENT_EXIT_OK = 0x05,
   SND_USERS = 0x06,
   SEARCH_RESULT_EMAIL = 0x07,
   STATUS_USER = 0x0a,
   CLOSE_SERVER = 0x0c, // se non rispondi al PING
   INVALID_PACKET = 0x0d,
   LOGIN_NOUSER = 0x0e,
   SRV_MESSAGE = 0x0f,
   WELCOME = 0x10,
   PING = 0x11,
   HELO = 0x12,
   SRV_MAINTENANCE,
   PROFILE_REPLY = 0x14,
//   SND_BUTTON = 0x15,
   SEARCH_RESULT_PROFILE = 0x16,
   SEND_REPLY = 0x17,      /* for send file */
   ENCODED_MSG = 0x18,
   OFFLINE_MSG = 0x1a,     // msg for secretary
   CHANGE_STATUS = 0x1c,
   MSG_FROMROOM = 0x30,
   ROOM_NOTPRESENT = 0x31,
   ROOM_NICKLIST = 0x32,
   ENTER_ROOM = 0x33,
   EXIT_FROMROOM = 0x34,
   EXIT_ROOM_OK = 0x35,
   SEARCH_RESULTS = 0x36,
   GET_ROOM_PROFILE = 0x37,
   ROOM_FULL = 0x38,
   ROOM_CREATE_BUSY = 0x39,
   SEARCH_RESULT_NICK = 0x3a,
   ROOM_ERROR = 0x3b,
   ROOM_LIST = 0x3c,
   GET_USERS = 0x45,
   ROOM_ENTERED = 0x46,
   ROOM_MULTILIST = 0x47,
   ROOM_KICK_ACK = 0x49,
   ROOM_KICK_BAN_ERROR = 0x4a

};

/* ---------------------- Functions ---------------------- */

BYTE unpackBYTE(BYTE **bpacket);
void unpackNBYTE(BYTE **bpacket, WORD n, BYTE *pbyte);
void unpackWORD(BYTE **bpacket, WORD *pw);
void unpackDWORD(BYTE **bpacket, LONG *pl);
void unpackZSTR(BYTE **bpacket, int len, LPSTR pstr);

int  strpos(char *szStr, char *szPattern);

void c6ServerDisconnect(void);
int  c6Login(int status);

#endif /* __C6_SERVER_H */

