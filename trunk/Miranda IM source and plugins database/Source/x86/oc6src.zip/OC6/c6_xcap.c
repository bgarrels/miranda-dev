/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

#define XCAP_CLIENT_CONFIG "application/client-configuration+xml"
#define XCAP_CLIENT_RESLST "application/resource-lists+xml"
#define XCAP_CLIENT_AUTCFG "application/auth-config-c6+xml"
#define XCAP_CLIENT_EL     "application/xcap-el+xml"
#define XCAP_CLIENT_ATT    "application/xcap-att+xml"

#define CLIENT_CONFIG 1
#define CLIENT_RESLST 2
#define CLIENT_AUTCFG 3
#define CLIENT_EL     4
#define CLIENT_ATT    5

char _base64user[64];

extern HANDLE hNetlibUser; // xcap

BOOL noUploadXCAP = FALSE;

//--------------------------------------------------------------------
//                          c6GetXCAPfromServ
//--------------------------------------------------------------------

char *getXCAPContentType(int iContentType)
{

	switch (iContentType)
	{
		case CLIENT_CONFIG:
		return XCAP_CLIENT_CONFIG;

		case CLIENT_RESLST:
		return XCAP_CLIENT_RESLST;

		case CLIENT_AUTCFG:
		return XCAP_CLIENT_AUTCFG;

		case CLIENT_EL:
		return XCAP_CLIENT_EL;

		default:
		return XCAP_CLIENT_ATT;
	}

}

int getRandomNumber(void)
{

	SYSTEMTIME st;

	GetLocalTime(&st);

	srand(st.wMilliseconds + (st.wSecond + st.wMinute*60 + st.wHour*3600)*1000);
    return (rand() % 65535);

}

void saveOnFile(LPSTR pszUser, LPSTR pszName, NETLIBHTTPREQUEST * nlreply)
{
	FILE *f;
    WORD tPathLen;
	LPSTR pszFile;

	pszFile = (LPSTR)mir_alloc(MAX_PATH);
    CallService(MS_DB_GETPROFILEPATH, MAX_PATH, (LPARAM)pszFile);

    tPathLen = strlen(pszFile);
    tPathLen += mir_snprintf(pszFile + tPathLen, MAX_PATH-tPathLen, "\\%s\\%s_%s.xml", C6PROTOCOLNAME, pszUser, pszName);

 	if ((f = fopen(pszFile, "wt")) != NULL) {

		fwrite(nlreply->pData, nlreply->dataLength, 1, f);

		fclose(f);
		mir_free(pszFile);
	}

}

static BOOL getvalueortag(BYTE *buffer, int *j0, char *s, char *value)
{

	unsigned int j, i;
 	char c;
 	BOOL bFound, bTag;

 	bFound = bTag = FALSE;
	j = *j0;
 	while (buffer[j]!='\0' && !bFound) {
		c = buffer[j++];
		if (c == '<') {
			bFound = TRUE;
			i = 0;
			while (!bTag && buffer[j] != '>') {
				c = buffer[j++];
				if (c == '=')
					bTag = TRUE;
				else s[i++] = c;
			}
			s[i] = '\0';
			j++;
			if (s[0]=='/') {
				value[0] = '\0';
				*j0 = j;
				return bFound;
			}
			if (bTag) { // tag
				i = 0;
				if (buffer[j]=='\"') j++;
				while (buffer[j] != '>')
					value[i++] = buffer[j++];

				if (i) {
					if (value[i-1]=='/') i--;
					if (value[i-1]=='\"') i--;
					value[i] = '\0';
				}
			} else {
				i = 0;
				while (buffer[j] != '<')
					value[i++] = buffer[j++];
				value[i] = '\0';
			}
		}
  	}
	*j0 = j;
	return bTag;

}

static BOOL getvaluebytag(BYTE *buffer, int *j0, char *s, char *value)
{

	unsigned int j, i;
 	char c;
 	BOOL bFound;

 	bFound = FALSE;
	j = *j0;
 	while (buffer[j]!='\0' && !bFound) {
		c = buffer[j++];
		if (c == '<') {
			i = 0;
			while (buffer[j] != '>') {
				c = buffer[j++];
				if (c == s[i])
					i++;
				else i = 0;
				if (i == strlen(s))
					bFound = TRUE;
			}
			j++;
			if (bFound) {
				i = 0;
				while (buffer[j] != '<')
					value[i++] = buffer[j++];
				value[i] = '\0';
			}
		}
  	}
	*j0 = j;
	return bFound;

}

NETLIBHTTPREQUEST *c6httpRequest(int requestType, LPSTR pszURL, LPSTR pszData, int iContentType)
{
	NETLIBHTTPREQUEST nlhr;
    NETLIBHTTPHEADER headers[7];
    char szlen[5], szauth[128];

    ZeroMemory(&nlhr, sizeof(nlhr));
    nlhr.cbSize = sizeof(nlhr);
    nlhr.requestType = requestType;
    nlhr.flags = NLHRF_DUMPASTEXT|NLHRF_HTTP11;
    nlhr.szUrl = pszURL;
    nlhr.headersCount = (pszData) ? 7 : 6;
    nlhr.headers = headers;

	if (pszData) {
		nlhr.pData = pszData;
		nlhr.dataLength = strlen(pszData);
	}

    headers[0].szName = "Content-Type";
    headers[0].szValue = getXCAPContentType(iContentType);

	sprintf(szauth, "Basic %s", _base64user);

    headers[1].szName = "Authorization";
    headers[1].szValue = szauth;
    headers[2].szName = "User-Agent";
    headers[2].szValue = "File Session";
    headers[3].szName = "Host";
    headers[3].szValue = "xcap.community.virgilio.it";
    headers[4].szName = "Connection";
    headers[4].szValue = "Keep-Alive";
    headers[5].szName = "Cache-Control";
    headers[5].szValue = "no-cache";

	if (pszData) {
	    headers[6].szName = "Content-Length";
		sprintf(szlen, "%d", nlhr.dataLength);
	    headers[6].szValue = szlen;
	}

    return (NETLIBHTTPREQUEST *) CallService(MS_NETLIB_HTTPTRANSACTION, (WPARAM) hNetlibUser, (LPARAM) & nlhr);
}

WORD c6GetXCAPConfig(LPSTR pszUser)
{
	NETLIBHTTPREQUEST *nlreply;
    char szURL[256];
	int random;

	random = getRandomNumber();
    mir_snprintf(szURL, 256, "http://xcap.community.virgilio.it/services/client-configuration/users/%s/config.xml?%d", pszUser, random);

	nlreply = c6httpRequest(REQUEST_GET, szURL, NULL, CLIENT_CONFIG);
    if (nlreply) {

    	if (nlreply->resultCode >= 200 && nlreply->resultCode < 300 && nlreply->dataLength) {
			BYTE iCheck;
			char buffer[50];

			int j = 0;
			if (getvaluebytag(nlreply->pData, &j, "warnings", buffer)) {

				iCheck = CONFIG_NOWARNING;
				if (!strcmp(buffer, "warning"))
					iCheck = CONFIG_NOTIFICATION;
				else if (!strcmp(buffer, "permission"))
					iCheck = CONFIG_AUTHORIZE;

				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_Permission", (BYTE)iCheck);
			} else c6LogMsg("Unable to Return XCAP");

			j = 0;
			if (getvaluebytag(nlreply->pData, &j, "reachability", buffer)) {

				iCheck = CONFIG_EMAIL;
				if (!strcmp(buffer, "messenger"))
					iCheck = CONFIG_MESSENGER;

				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_OfflineMsg", (BYTE)iCheck);
			} else c6LogMsg("Unable to Return XCAP");

			if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_File", 0))
				saveOnFile(pszUser, "xcap_cfg", nlreply);

		}
		CallService(MS_NETLIB_FREEHTTPREQUESTSTRUCT, 0, (LPARAM) nlreply);
	}
	return 0;

}

void setXCAPPassword(LPSTR pszNick, LPSTR pszPassword)
{

	BYTE *pContext;
	WORD cbContext = strlen(pszNick) + 1 + strlen(pszPassword) + 1;

	pContext = (BYTE *)mir_alloc(cbContext);
	sprintf(pContext, "%s:%s\0", pszNick, pszPassword);

	NETLIBBASE64 nlb;

   	nlb.pszEncoded = (char *)_base64user;
	nlb.cchEncoded = sizeof(_base64user);
	nlb.pbDecoded = pContext;
	nlb.cbDecoded = cbContext - 1;

	if (CallService( MS_NETLIB_BASE64ENCODE, 0, (LPARAM) &nlb )) {
		char *szUrlEncoded = (char*)CallService(MS_NETLIB_URLENCODE,0,(LPARAM)_base64user);
		strcpy(_base64user, szUrlEncoded);
		HeapFree(GetProcessHeap(),0,szUrlEncoded);
	}
	mir_free(pContext);
}

WORD c6httpModRequest(int requestType, LPSTR pszURL, LPSTR pszData, int iContentType)
{

	NETLIBHTTPREQUEST *nlreply;
	int iret = 0;

    nlreply = c6httpRequest(requestType, pszURL, pszData, iContentType);
	if(nlreply==NULL) {
		c6LogMsg(Translate("http Request failed: 1"));
		if (GetLastError()==ERROR_INVALID_PARAMETER)
			noUploadXCAP = TRUE;

		showError();
		iret = 1;
	}
	else {
		if(nlreply->resultCode<200 || nlreply->resultCode>=300 || nlreply->dataLength) {
			c6LogMsg(Translate("http Request failed: 2"));
			iret = 2;
		}
		CallService(MS_NETLIB_FREEHTTPREQUESTSTRUCT,0,(LPARAM)nlreply);
	}
	return iret;
}

WORD c6SetXCAPConfig(LPSTR pszUser, int nsel, int mode)
{

    LPSTR pszURL;
	LPSTR pszData;
	pszURL = mir_alloc(256);

	if (nsel == 1)
	    mir_snprintf(pszURL, 256,
		"http://xcap.community.virgilio.it/services/client-configuration/users/%s/config.xml/~~/client-configuration/warnings", pszUser);
    else mir_snprintf(pszURL, 256,
		"http://xcap.community.virgilio.it/services/client-configuration/users/%s/config.xml/~~/client-configuration/reachability", pszUser);

	if (nsel == 1) {
		if (mode == CONFIG_NOWARNING)
			pszData = "<warnings>\n\tnowarning\n</warnings>";
		else if (mode == CONFIG_NOTIFICATION)
			pszData = "<warnings>\n\twarning\n</warnings>";
	   	else pszData = "<warnings>\n\tpermission\n</warnings>";
	}
	else {
		if (mode == CONFIG_MESSENGER)
			pszData = "<reachability>\n\tmessenger\n</reachability>";
	   	else pszData = "<reachability>\n\tmail\n</reachability>";
	}
	WORD iret = c6httpModRequest(REQUEST_PUT, pszURL, pszData, CLIENT_EL);
	mir_free(pszURL);

	return iret;

}

WORD c6GetXCAPBL(LPSTR pszUser)
{

	NETLIBHTTPREQUEST *nlreply;
    char szURL[256];
	int random;

	random = getRandomNumber();
    mir_snprintf(szURL, 256, "http://xcap.community.virgilio.it/services/resource-lists/users/%s/buddy.xml?%d", pszUser, random);

	nlreply = c6httpRequest(REQUEST_GET, szURL, NULL, CLIENT_RESLST);
    if (nlreply) {

    	if (nlreply->dataLength) {

			int j;
			char group[256], buddy[256], szbuf[256];

			j = 0;
			while (j < strlen(nlreply->pData)) {

				if (getvalueortag(nlreply->pData, &j, szbuf, buddy)) { // tag
					if (!strcmp(szbuf, "list name") && strcmp(buddy, "Lista Amici")) { // gruppo
						strcpy(group, buddy);
						createCListGroup(group);

						addSrvGroup(group);
					}
				} else {
					if (!strcmp(szbuf, "display-name")) { // buddy
						HANDLE hContact = (HANDLE)AddToListDirect(0, buddy, group);
						if (hContact) {
							DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "CSS");
					    	writeDbInfoSettingString(hContact, "CSS", pszUser);
						}
					}
				}

			}

			if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_File", 0))
				saveOnFile(pszUser, "xcap_bl", nlreply);

		}
		CallService(MS_NETLIB_FREEHTTPREQUESTSTRUCT, 0, (LPARAM) nlreply);
	}
	return 0;

}

LPSTR groupEncode(LPSTR pszGroup)
{
	LPSTR pszGroupEncoded = mir_alloc(256);
	char *szUrlEncoded = (char*)CallService(MS_NETLIB_URLENCODE,0,(LPARAM)pszGroup);
	strcpy(pszGroupEncoded, szUrlEncoded);
	HeapFree(GetProcessHeap(),0,szUrlEncoded);
	return pszGroupEncoded;
}

WORD c6RemoveXCAPBuddy(LPSTR pszNick, LPSTR pszGroup)
{

    LPSTR pszURL, pszData, pszGroupEncoded;
	char szUser[40];

	pszURL = mir_alloc(256);
	pszData = mir_alloc(256);

	pszGroupEncoded = groupEncode(pszGroup);

	GetUserNickName(szUser);
	mir_snprintf(pszData, 256, "resource-lists/list%%5B@name=%%22Lista%%20Amici%%22%%5D/list%%5B@name=%%22%s%%22%%5D/entry%%5B@uri=%%22sip:%s@c6.virgilio.it%%22%%5D",
				pszGroupEncoded, pszNick);
	mir_snprintf(pszURL, 256, "http://xcap.community.virgilio.it/services/resource-lists/users/%s/buddy.xml/~~/%s", szUser, pszData);

	WORD iret = c6httpModRequest(REQUEST_DELETE, pszURL, NULL, CLIENT_EL);

	mir_free(pszGroupEncoded);
	mir_free(pszData);
	mir_free(pszURL);

	return iret;

}

WORD c6AddXCAPBuddy(LPSTR pszNick, LPSTR pszGroup)
{

    LPSTR pszURL, pszData, pszGroupEncoded;
	char szUser[40];

	pszURL = mir_alloc(256);
	pszData = mir_alloc(256);

	pszGroupEncoded = groupEncode(pszGroup);

	mir_snprintf(pszData, 256, "resource-lists/list%%5B@name=%%22Lista%%20Amici%%22%%5D/list%%5B@name=%%22%s%%22%%5D/entry%%5B@uri=%%22sip:%s@c6.virgilio.it%%22%%5D",
				pszGroupEncoded, pszNick);

	GetUserNickName(szUser);
	mir_snprintf(pszURL, 256, "http://xcap.community.virgilio.it/services/resource-lists/users/%s/buddy.xml/~~/%s", szUser, pszData);

	mir_snprintf(pszData, 256, "<entry uri=\"sip:%s@c6.virgilio.it\">\r\n<display-name>%s</display-name>\r\n</entry>\r\n", pszNick, pszNick);

	WORD iret = c6httpModRequest(REQUEST_PUT, pszURL, pszData, CLIENT_EL);

	mir_free(pszGroupEncoded);
	mir_free(pszData);
	mir_free(pszURL);

	return iret;
}

WORD c6AddXCAPWBList(const LPSTR psztype, LPSTR pszNick)
{

    LPSTR pszURL, pszData;
	char szUser[40];

	pszURL = mir_alloc(256);
	pszData = mir_alloc(256);

	mir_snprintf(pszData, 256, "auth-config-c6/%s/entry%%5B@uri=%%22sip:%s@c6.virgilio.it%%22%%5D", psztype, pszNick);

	GetUserNickName(szUser);
	mir_snprintf(pszURL, 256, "http://xcap.community.virgilio.it/services/auth-config-c6/users/%s/auth.xml/~~/%s", szUser, pszData);

	mir_snprintf(pszData, 256, "<entry uri=\"sip:%s@c6.virgilio.it\">\r\n<display-name>%s</display-name>\r\n</entry>\r\n", pszNick, pszNick);

	WORD iret = c6httpModRequest(REQUEST_PUT, pszURL, pszData, CLIENT_EL);

	mir_free(pszData);
	mir_free(pszURL);

	return iret;

}

WORD c6AddXCAPWhiteList(LPSTR pszNick)
{
	return c6AddXCAPWBList("whitelist", pszNick);
}

WORD c6AddXCAPBlackList(LPSTR pszNick)
{
	return c6AddXCAPWBList("blacklist", pszNick);
}

WORD c6DelXCAPWBList(const LPSTR psztype, LPSTR pszNick)
{

    LPSTR pszURL, pszData;
	char szUser[40];

	pszURL = mir_alloc(256);
	pszData = mir_alloc(256);

	mir_snprintf(pszData, 256, "auth-config-c6/%s/entry%%5B@uri=%%22sip:%s@c6.virgilio.it%%22%%5D", psztype, pszNick);

	GetUserNickName(szUser);
	mir_snprintf(pszURL, 256, "http://xcap.community.virgilio.it/services/auth-config-c6/users/%s/auth.xml/~~/%s", szUser, pszData);

	WORD iret = c6httpModRequest(REQUEST_DELETE, pszURL, NULL, CLIENT_EL);

	mir_free(pszData);
	mir_free(pszURL);

	return iret;
}

WORD c6DelXCAPWhiteList(LPSTR pszNick)
{
	return c6DelXCAPWBList("whitelist", pszNick);
}

WORD c6DelXCAPBlackList(LPSTR pszNick)
{
	return c6DelXCAPWBList("blacklist", pszNick);
}

WORD c6GetXCAPAuthList(int type, LPSTR pszUser, HWND hwndList)
{

	NETLIBHTTPREQUEST *nlreply;
	LPSTR pszTypeList;
    char szURL[256];
	int random;

	if (type)
		pszTypeList = "whitelist";
	else pszTypeList = "blacklist";

	random = getRandomNumber();
    mir_snprintf(szURL, 256, "http://xcap.community.virgilio.it/services/auth-config-c6/users/%s/auth.xml?%d", pszUser, random);

	nlreply = c6httpRequest(REQUEST_GET, szURL, NULL, CLIENT_AUTCFG);
    if (nlreply) {

    	if (nlreply->dataLength) {

			int j, tl = 0;
			char buddy[256], szbuf[256];

			j = 0;
			while (j < strlen(nlreply->pData)) {

				if (getvalueortag(nlreply->pData, &j, szbuf, buddy)==0) { // tag
					if (!strcmp(szbuf, pszTypeList)) { // buddy
						tl = 1;
					}
					else if (!strcmp(szbuf, "display-name") && tl) { // buddy
							SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)buddy);

					} else tl = 0;
				}
			}

			if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_File", 0))
				saveOnFile(pszUser, "xcap_auth", nlreply);
		}

		CallService(MS_NETLIB_FREEHTTPREQUESTSTRUCT, 0, (LPARAM) nlreply);
	}
	return 0;
}

WORD c6RemoveXCAPGroup(LPSTR pszGroup)
{

    LPSTR pszURL, pszData, pszGroupEncoded;
	char szUser[40];

	pszURL = mir_alloc(256);
	pszData = mir_alloc(256);

	pszGroupEncoded = groupEncode(pszGroup);

	mir_snprintf(pszData, 256, "resource-lists/list%%5B@name=%%22Lista%%20Amici%%22%%5D/list%%5B@name=%%22%s%%22%%5D", pszGroupEncoded);

	GetUserNickName(szUser);
	mir_snprintf(pszURL, 256, "http://xcap.community.virgilio.it/services/resource-lists/users/%s/buddy.xml/~~/%s", szUser, pszData);

	WORD iret = c6httpModRequest(REQUEST_DELETE, pszURL, NULL, CLIENT_ATT);

	mir_free(pszGroupEncoded);
	mir_free(pszData);
	mir_free(pszURL);

	return iret;
}

WORD c6RenameXCAPGroup(LPSTR pszOldGroup, LPSTR pszNewGroup)
{

    LPSTR pszURL, pszData, pszGroupEncoded;
	char szUser[40];

	pszURL = mir_alloc(256);
	pszData = mir_alloc(256);
	pszGroupEncoded = mir_alloc(256);

	char *szUrlEncoded = (char*)CallService(MS_NETLIB_URLENCODE,0,(LPARAM)pszOldGroup);
	strcpy(pszGroupEncoded, szUrlEncoded);
	HeapFree(GetProcessHeap(),0,szUrlEncoded);

	mir_snprintf(pszData, 256, "resource-lists/list%%5B@name=%%22Lista%%20Amici%%22%%5D/list%%5B@name=%%22%s%%22%%5D/@name", pszGroupEncoded);

	GetUserNickName(szUser);
	mir_snprintf(pszURL, 256, "http://xcap.community.virgilio.it/services/resource-lists/users/%s/buddy.xml/~~/%s", szUser, pszData);

	mir_snprintf(pszData, 256, "%s", pszNewGroup); // utf8 ???

	WORD iret = c6httpModRequest(REQUEST_PUT, pszURL, pszData, CLIENT_ATT);

	mir_free(pszGroupEncoded);
	mir_free(pszData);
	mir_free(pszURL);

	return iret;
}

WORD c6SrvBlackList(BOOL bWhiteList, LPSTR pszUser)
{
	NETLIBHTTPREQUEST *nlreply;
    char szURL[256];
	int random;

	random = getRandomNumber();
    mir_snprintf(szURL, 256, "http://xcap.community.virgilio.it/services/auth-config-c6/users/%s/auth.xml?%d", pszUser, random);

	nlreply = c6httpRequest(REQUEST_GET, szURL, NULL, CLIENT_AUTCFG);
    if (nlreply) {

    	if (nlreply->dataLength) {

			int j, tl = 0;
			char buddy[256], szbuf[256];

			j = 0;
			while (j < strlen(nlreply->pData)) {

				if (getvalueortag(nlreply->pData, &j, szbuf, buddy)==0) { // tag
					if (bWhiteList && !strcmp(szbuf, "whitelist")) { // buddy
						tl = 1;
					}
					if (!strcmp(szbuf, "blacklist")) { // buddy
						tl = 2;
					} else if (!strcmp(szbuf, "display-name")) { // buddy

						if (tl==1)
							addWhiteList(buddy);
						else if (tl==2)
							addSrvIgnoreList(buddy, IGNOREEVENT_ALL);

					} else tl = 0;
				}
			}

			if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_File", 0))
				saveOnFile(pszUser, "xcap_auth", nlreply);
		}

		CallService(MS_NETLIB_FREEHTTPREQUESTSTRUCT, 0, (LPARAM) nlreply);
	}
	return 0;
}

