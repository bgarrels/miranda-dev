/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2009 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

static DWORD dwCookieSeq;
static c6_cookie_info *cookie = NULL;
static int cookieCount = 0;
CRITICAL_SECTION cookieMutex;

extern int c6Status;

extern BOOL gbUnicodeCore;

//--------------------------------------------------------------------
//                         C6StatusToMiranda
//--------------------------------------------------------------------

int C6StatusToMiranda(WORD nC6Status)
{

	int nMirandaStatus;

	if (nC6Status == 0xFFFF || nC6Status == C6_OFFLINE || nC6Status == 0)

		nMirandaStatus = ID_STATUS_OFFLINE;

	else if (nC6Status & C6_AWAY)
		    nMirandaStatus = ID_STATUS_AWAY;
	else
		if (nC6Status & C6_AVAILABLE)
		    nMirandaStatus = ID_STATUS_ONLINE;
	else
		if (nC6Status & C6_BUSY)
			nMirandaStatus = ID_STATUS_OCCUPIED;
	else
		if (nC6Status & C6_NETFRIENDS)
			nMirandaStatus = ID_STATUS_NA;
/*    else
		if (nC6Status == 0)
			nMirandaStatus = ID_STATUS_CONNECTING;*/
	else
		nMirandaStatus = ID_STATUS_OFFLINE;

	return nMirandaStatus;

}

//--------------------------------------------------------------------
//                           MirandaStatusToC6
//--------------------------------------------------------------------

WORD MirandaStatusToC6(int nMirandaStatus)
{

	WORD nC6Status;

	switch (nMirandaStatus)
	{

	case ID_STATUS_ONLINE:
		nC6Status = C6_AVAILABLE;
		break;

	case ID_STATUS_NA:
		nC6Status = C6_NETFRIENDS;
		break;

	case ID_STATUS_OCCUPIED:
/*	case ID_STATUS_DND:
	case ID_STATUS_ONTHEPHONE:
	case ID_STATUS_OUTTOLUNCH:*/
		nC6Status = C6_BUSY;
		break;

	case ID_STATUS_OFFLINE:
		nC6Status = C6_OFFLINE;
		break;

	case ID_STATUS_AWAY:
		nC6Status = C6_AWAY;
		break;

	default:
		nC6Status = C6_AVAILABLE;
		break;

	}

	return nC6Status;

}

//--------------------------------------------------------------------
//                           IDClientToPosImg
//--------------------------------------------------------------------

#ifndef C6_FINGERPRINT

int IDClientToPosImg(BYTE id)
{

    int posImg;

	switch (id)
	{

	case ID_CLIENT_MIRANDA:
		posImg = -1; // already exists
		break;
	case ID_CLIENT_OC6:
		posImg = 0;
		break;
	case ID_CLIENT_CM3:
	case ID_CLIENT_CM4:
		posImg = 1;
		break;
	case ID_CLIENT_CM5:
	case ID_CLIENT_CM6:
	case ID_CLIENT_CM7:
		posImg = 2;
		break;
	case ID_CLIENT_JAVA:
	case ID_CLIENT_MB:
		posImg = 4;
		break;
	case ID_CLIENT_CM8:
	case ID_CLIENT_CM9:
	case ID_CLIENT_CM10:
		posImg = 3;
		break;
	case ID_CLIENT_CM11:
		posImg = 5;
		break;
 	default:
	    posImg=-1;
		break;
	}

	return posImg;

}

#endif

//--------------------------------------------------------------------
//                           InitCookies
//--------------------------------------------------------------------

void InitCookies(void)
{
  	InitializeCriticalSection(&cookieMutex);

  	cookieCount = 0;
  	cookie = NULL;
  	dwCookieSeq = 1;
}


void UninitCookies(void)
{
  	mir_free(cookie);
  	cookie=NULL;

  	DeleteCriticalSection(&cookieMutex);
}

void AllocateCookie(BYTE optype, LPSTR pszUser, void *pvExtra)
{

  	EnterCriticalSection(&cookieMutex);

  	cookie = (c6_cookie_info *)mir_realloc(cookie, sizeof(c6_cookie_info) * (cookieCount + 1));
  	cookie[cookieCount].dwCookie = dwCookieSeq++;
	cookie[cookieCount].optype = optype;
  	cookie[cookieCount].pszUser = pszUser;
  	cookie[cookieCount].pvExtra = pvExtra;
  	cookieCount++;

	c6LogMsg("cookie added (%d) n. %d", optype, cookieCount);

  	LeaveCriticalSection(&cookieMutex);

}

int FindCookie(BYTE optype, LPSTR pszUser, DWORD *dwCookie, void **ppvExtra)
{
	int i;
	int nFound = 0;

	EnterCriticalSection(&cookieMutex);

	for (i = 0; i < cookieCount; i++)
	{
		if (cookie[i].optype == optype)
			if (pszUser==NULL || !strcmp(pszUser, cookie[i].pszUser)) {

				if (ppvExtra)
					*ppvExtra = cookie[i].pvExtra;
				if (dwCookie)
					*dwCookie = cookie[i].dwCookie;
 				// Cookie found, exit loop
				nFound = 1;
				break;

			}
	}

	LeaveCriticalSection(&cookieMutex);

	return nFound;
}

int FindCookieByData(void *pvExtra, DWORD *pdwCookie)
{

	int i;
	int nFound = 0;

	EnterCriticalSection(&cookieMutex);

	for (i = 0; i < cookieCount; i++)
	{
		if (cookie[i].optype == OP_FILE)
			if (pvExtra == cookie[i].pvExtra) {
				if (pdwCookie)
					*pdwCookie = cookie[i].dwCookie;

				// Cookie found, exit loop
				nFound = 1;
				break;
			}
	}

	LeaveCriticalSection(&cookieMutex);

	return nFound;
}

void FreeCookie(DWORD dwCookie)
{

	int i;

	EnterCriticalSection(&cookieMutex);

	for (i = 0; i < cookieCount; i++)
	{
		if (dwCookie==0 || dwCookie == cookie[i].dwCookie)
		{
			cookieCount--;
			memmove(&cookie[i], &cookie[i+1], sizeof(c6_cookie_info) * (cookieCount - i));
			cookie = (c6_cookie_info*)mir_realloc(cookie, sizeof(c6_cookie_info) * cookieCount);

			c6LogMsg("cookie deleted");
			// Cookie found, exit loop
			break;
		}
	}

	LeaveCriticalSection(&cookieMutex);

}

//--------------------------------------------------------------------
//                           GenerateCookie
//--------------------------------------------------------------------

HANDLE GenerateCookie (void)
{
	static LONG cookie = 0;
	InterlockedIncrement (&cookie);
	return (HANDLE) cookie;
}

//--------------------------------------------------------------------
//                             amIOnline
//--------------------------------------------------------------------

BOOL amIOnline(void)
{
	if (c6Status != ID_STATUS_OFFLINE && c6Status != ID_STATUS_CONNECTING)
		return TRUE;
	return FALSE;
}

//--------------------------------------------------------------------
//                           HContactFromNick
//--------------------------------------------------------------------

HANDLE HContactFromNick(DWORD dwFlags, char *szNick)
{

	HANDLE hContact;
	char* szProto;
	DBVARIANT dbv;
	BOOL bFound = FALSE;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	while (hContact != NULL)
	{

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
			if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {
	        	if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
					if (strcmp(szNick,dbv.pszVal)==0)
						bFound = TRUE;
					DBFreeVariant(&dbv);
					if (bFound)
					    return hContact;
				}
			}

		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}

	//not present: add
	hContact = (HANDLE)CallService(MS_DB_CONTACT_ADD, 0, 0);
	CallService(MS_PROTO_ADDTOCONTACT, (WPARAM)hContact, (LPARAM)C6PROTOCOLNAME);

    if (!dwFlags&PALF_TEMPORARY && amIOnline()) {
		DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "Status", ID_STATUS_ONLINE);
		Add1NetFriend(szNick);
		c6LogMsg("Contact Added in CList!");
	}

	DBWriteContactSettingString(hContact, C6PROTOCOLNAME, C6_LOGINID, szNick);
	DBWriteContactSettingByte(hContact, "CList", "NotOnList", 1);
	DBWriteContactSettingByte(hContact, "CList", "Hidden", 1);

	return hContact;
}

//--------------------------------------------------------------------
//                           isNetFriend
//--------------------------------------------------------------------

BOOL isNetFriend(LPSTR pszNick)
{
	HANDLE hContact;
	char* szProto;
	DBVARIANT dbv;
	BOOL bFound = FALSE;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	while (hContact != NULL)
	{

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
			if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0){
	        	if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
					if (strcmp(pszNick, dbv.pszVal)==0)
						bFound = TRUE;
					DBFreeVariant(&dbv);

					if (bFound) {
						if (DBGetContactSettingByte(hContact, "CList", "NotOnList", 0))
							bFound = FALSE; // temporary friend

						return bFound;
					}
				}
			}

		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}
	return bFound;
}

//--------------------------------------------------------------------
//                           HContactfNickNoAdd
//--------------------------------------------------------------------

HANDLE HContactfNickNoAdd(char *szNick)
{

	HANDLE hContact;
	char* szProto;
	DBVARIANT dbv;
	BOOL bFound = FALSE;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	while (hContact != NULL)
	{

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
			if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {
	        	if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
					if (strcmp(szNick,dbv.pszVal)==0)
						bFound = TRUE;
					DBFreeVariant(&dbv);
					if (bFound)
					    return hContact;
				}
			}

		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}
	return 0;
}

//--------------------------------------------------------------------
//                           isYouTalking
//--------------------------------------------------------------------

BOOL areYouTalking(HANDLE hContact)
{
   	MessageWindowInputData mid;
	MessageWindowData mwd;

	if (hContact) {
		mid.cbSize = sizeof(MessageWindowInputData);
		mid.hContact = hContact;
		mid.uFlags = MSG_WINDOW_UFLAG_MSG_BOTH;

		mwd.cbSize = sizeof(MessageWindowData);
		mwd.hContact = hContact;

	   	int i = CallService(MS_MSG_GETWINDOWDATA, (WPARAM)&mid, (LPARAM)&mwd);

		if (i == 0 && mwd.hwndWindow && mwd.uState)
			return TRUE;
	}
	return FALSE;
}

#ifdef FULL_C6

//--------------------------------------------------------------------
//                           PolishDirImageThread
//--------------------------------------------------------------------

void PolishDirImageThread(LPVOID param)
{
    WORD tPathLen;
	LPSTR pszDest;
 	WIN32_FIND_DATA FindFileData;
 	HANDLE hFindFile;
	char szUser[40];

 	int done;

	if (param)
		CallService (MS_SYSTEM_THREAD_PUSH, 0, 0);

	GetUserNickName(szUser);

	pszDest = (LPSTR)mir_alloc(MAX_PATH);
    CallService(MS_DB_GETPROFILEPATH, MAX_PATH, (LPARAM)pszDest);

    tPathLen = strlen(pszDest);
    tPathLen += mir_snprintf(pszDest + tPathLen, MAX_PATH-tPathLen, "\\%s\\*.jpg", C6PROTOCOLNAME);

   	done = TRUE;
   	hFindFile = FindFirstFile(pszDest, &FindFileData);
   	if (hFindFile!=INVALID_HANDLE_VALUE) {
	 	while (done) {

			if (strcmp(FindFileData.cFileName,".") && strcmp(FindFileData.cFileName,"..")) {

				char szNick[40]; // 20
				char   *ptr,*p;

				p = FindFileData.cFileName;
 				ptr = strrchr(FindFileData.cFileName, '.');

				strncpy(szNick, FindFileData.cFileName, ptr-p);
				szNick[ptr-p]='\0';

				if (!isNetFriend(szNick) && strcmp(szNick, szUser)) {

					char szFile[MAX_PATH];

					strncpy(szFile, pszDest, strlen(pszDest)-5);
					szFile[strlen(pszDest)-5] = '\0';
					strcat(szFile, FindFileData.cFileName);

					DeleteFile(szFile);
					/*if (DeleteFile(szFile))
						c6LogMsg("...Deleted !");*/
				}

			}

	  		done=FindNextFile(hFindFile, &FindFileData);

	 	}
	 	FindClose(hFindFile);
    }

	mir_free(pszDest);

	if (param)
		CallService (MS_SYSTEM_THREAD_POP, 0, 0);

}

//--------------------------------------------------------------------
//                           PolishDirImage
//--------------------------------------------------------------------

void PolishDirImage(BOOL bNothread)
{
	DWORD id;

	if (bNothread)
		PolishDirImageThread(&bNothread);
	else CloseHandle (CreateThread (NULL, 0, (LPTHREAD_START_ROUTINE)PolishDirImageThread, NULL, 0, &id));
}

#endif

//--------------------------------------------------------------------
//                           MWQuakeThread
//--------------------------------------------------------------------

DWORD MWQuakeThread(LPVOID param)
{

	POINT fivepoints[]={
		{2  , 2}, {-2 , 2}, {-2 , -2}, {2 , -2}, {0 , 0}
	};

	CallService (MS_SYSTEM_THREAD_PUSH, 0, 0);

	HANDLE hwnd = (HANDLE)param;
	RECT r;
	int cx,cy,i;

	GetWindowRect(hwnd, &r);
	cx = cy = 2;
	for (i=0; i< 10 ; i++) {

	    cx = fivepoints[i % 5].x;
		cy = fivepoints[i % 5].y;

		SetWindowPos(hwnd, 0, r.left+cx, r.top+cy, 0, 0 ,SWP_NOZORDER|SWP_NOSIZE);
		Sleep(25);

	}

	CallService (MS_SYSTEM_THREAD_POP, 0, 0);

	return 0;

}

//--------------------------------------------------------------------
//                           DingExecute
//--------------------------------------------------------------------

BOOL DingExecute(LPSTR pszNick)
{
   	MessageWindowInputData mid;
	MessageWindowData mwd;
	HANDLE hwnd;

	HANDLE hContact = HContactfNickNoAdd(pszNick);
	if (hContact) {
		mid.cbSize = sizeof(MessageWindowInputData);
		mid.hContact = hContact;
		mid.uFlags = MSG_WINDOW_UFLAG_MSG_BOTH;

		mwd.cbSize = sizeof(MessageWindowData);
		mwd.hContact = hContact;

	   	int i = CallService(MS_MSG_GETWINDOWDATA, (WPARAM)&mid, (LPARAM)&mwd);

		if (i == 0 && mwd.hwndWindow && mwd.uState) {
			hwnd = GetAncestor(mwd.hwndWindow, GA_ROOT);
		}
		else {
			hwnd = (HWND)CallService(MS_CLUI_GETHWND, 0, 0);
		}

		if (hwnd) {
			char szSndName[20];

			strcpy(szSndName, C6PROTOCOLNAME);
			strcat(szSndName, "/Ding");

			SkinPlaySound(szSndName);

			DWORD id;

			CloseHandle (CreateThread (NULL, 0, (LPTHREAD_START_ROUTINE)MWQuakeThread, (LPVOID)hwnd, 0, &id));

			return TRUE;
		}
	}
	return FALSE;
}

//--------------------------------------------------------------------
//                           GetUserNickName
//--------------------------------------------------------------------

BOOL GetUserNickName(LPSTR pszUser)
{
    DBVARIANT dbv;
	BOOL bRet;

	bRet = !DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv);
    if(bRet) {
	    strcpy(pszUser, dbv.pszVal);
		DBFreeVariant(&dbv);
	}
	return bRet;
}

//--------------------------------------------------------------------
//                         ResetSettingsOnLoad
//--------------------------------------------------------------------

void ResetSettingsOnLoad(void)
{

	HANDLE hContact;
	char *szProto;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);

	while (hContact)
	{
		szProto = (char *)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);
		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
		if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0)
		{

			DBWriteContactSettingDword(hContact, C6PROTOCOLNAME, "LogonTS", 0);
			DBWriteContactSettingDword(hContact, C6PROTOCOLNAME, "UserIP", 0);
			DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "UserPort", 0);
			DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "C6Status", C6_OFFLINE);
			if (DBGetContactSettingWord(hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE) != ID_STATUS_OFFLINE)
				DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE);
			DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "Timezone");

			DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "UserTyping"); // new 0.2.x
		}
		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}

}

//--------------------------------------------------------------------
//                           GetIgnoreMsg
//--------------------------------------------------------------------

LPSTR GetIgnoreMsg(void)
{
	DBVARIANT dbv;
	LPSTR IM;

	if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, "IgnoreMsg", &dbv)) {
		IM = mir_alloc(strlen(dbv.pszVal) + 1);
        strcpy(IM, dbv.pszVal);
		DBFreeVariant(&dbv);
	}
	else {
		IM = mir_alloc(strlen(Translate(DEFAULT_IGNOREMSG))+1);
		strcpy(IM, Translate(DEFAULT_IGNOREMSG));
	}

	return IM;
}

//--------------------------------------------------------------------
//                LogPopup (from clistnicerplus/init.c)
//--------------------------------------------------------------------

int LogPopup(HANDLE hContact, COLORREF colorBack, LPSTR pszMsg)
{
    POPUPDATA ppd;
	char *szbuf;

	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "DeepInfoDebug", 0)) { // Deep Info

		szbuf = mir_alloc(strlen(pszMsg)+1);
    	strcpy(szbuf, pszMsg);

/*    	if(CallService(MS_POPUP_QUERY, PUQS_GETSTATUS, 0) == 1)*/
		if (ServiceExists(MS_POPUP_ADDPOPUP)) {

    	    ZeroMemory((void *)&ppd, sizeof(ppd));
    	    ppd.lchContact = hContact;
    	    ppd.lchIcon = LoadSkinnedIcon(SKINICON_EVENT_MESSAGE);
    	    if(hContact != 0)
    	        strncpy(ppd.lpzContactName, (char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0), MAX_CONTACTNAME);
    	    else
    	        strncpy(ppd.lpzContactName, "Message", 7);
    	    strcpy(ppd.lpzText, "C6: ");
			strncat(ppd.lpzText, szbuf, MAX_SECONDLINE - 4);
	        ppd.PluginData = 0;
    	    ppd.colorText = RGB(0,0,0);
    	    ppd.colorBack = colorBack;

    	    CallService(MS_POPUP_ADDPOPUP, (WPARAM)&ppd, 0);
    	}
		mir_free(szbuf);
	}
    return 0;
}

//--------------------------------------------------------------------
//                        writeDbInfoSettingString
//--------------------------------------------------------------------

BOOL writeDbInfoSettingString(HANDLE hContact, const char* szSetting, char* buf)
{

    if (strlen(buf))
		DBWriteContactSettingString(hContact, C6PROTOCOLNAME, szSetting, buf);
	else
		DBDeleteContactSetting(hContact, C6PROTOCOLNAME, szSetting);

	return TRUE;

}

//--------------------------------------------------------------------
//                        writeDbInfoSettingWord
//--------------------------------------------------------------------

BOOL writeDbInfoSettingWord(HANDLE hContact, const char *szSetting, WORD wVal)
{

	if (wVal != 0)
		DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, szSetting, wVal);
	else
		DBDeleteContactSetting(hContact, C6PROTOCOLNAME, szSetting);

	return TRUE;

}

//--------------------------------------------------------------------
//                        writeContactSettingBlob
//--------------------------------------------------------------------

int writeContactSettingBlob(HANDLE hContact, const char *szSetting, const char *val, const int cbVal)
{
  	DBCONTACTWRITESETTING cws;

  	cws.szModule = C6PROTOCOLNAME;
  	cws.szSetting = szSetting;
  	cws.value.type = DBVT_BLOB;
  	cws.value.pbVal = (char*)val;
  	cws.value.cpbVal = cbVal;
  	return CallService(MS_DB_CONTACT_WRITESETTING, (WPARAM)hContact, (LPARAM)&cws);
}

//--------------------------------------------------------------------
//                          getStatusMessage
//--------------------------------------------------------------------

void getStatusMessage(LPSTR *pszStatusMessage)
{

    DBVARIANT dbv;

    if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, "StatusMessage", &dbv)) {
		*pszStatusMessage = (LPSTR)mir_alloc(strlen(dbv.pszVal) + 1);
		strcpy(*pszStatusMessage, dbv.pszVal);
		DBFreeVariant(&dbv);
	} else *pszStatusMessage = NULL;

}

//--------------------------------------------------------------------
//                             isKeyLogin
//--------------------------------------------------------------------

BOOL isKeyLogin(LPSTR pszUser)
{
	return (strchr(pszUser,'@') != NULL);
}

//--------------------------------------------------------------------
//                            isNewKeyLogin
//--------------------------------------------------------------------

BOOL isNewKeyLogin(void)
{
    DBVARIANT dbv;
	LPSTR pszNick = NULL;
	BOOL ret = FALSE;

	if (!DBGetContactSetting(NULL, C6PROTOCOLNAME, "LoginNickName", &dbv)) {
	  	pszNick = mir_strdup(dbv.pszVal);
		DBFreeVariant(&dbv);
		ret = isKeyLogin(pszNick);
		mir_free(pszNick);
	}
	return ret;
}

//--------------------------------------------------------------------
//                            getIDCountry
//--------------------------------------------------------------------

WORD getIDCountry(BYTE info)
{
	WORD idCountry;
	switch (info) {
		case 2: // Italy
			idCountry = 39;
			break;
		case 3: // Vatican City
			idCountry = 379;
			break;
		case 4: // S.Marino
			idCountry = 378;
			break;
		default :
			idCountry = 0;
			break;
	}
	return idCountry;
}

//--------------------------------------------------------------------
//                         Contact Typing
//--------------------------------------------------------------------

BOOL checkContactTyping(HANDLE hContact)
{

	if (CallService(MS_IGNORE_ISIGNORED, (WPARAM)hContact, (LPARAM)IGNOREEVENT_TYPINGNOTIFY)) {

		c6LogMsg("User Typing ignoring...");
		return 0;

	}
	return DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "UserTyping", 0);

}

void setContactTyping(HANDLE hContact, BYTE byValue)
{

//	c6LogMsg("setContactTyping = %d", byValue);
	DBWriteContactSettingByte(hContact, C6PROTOCOLNAME, "UserTyping", (BYTE)byValue);

}

//--------------------------------------------------------------------
//                              getOC6DataDir
//--------------------------------------------------------------------

void getOC6DataDir(LPSTR pszDest, int cbLen)
{

	WORD tPathLen;
    CallService(MS_DB_GETPROFILEPATH, cbLen, (LPARAM)pszDest);

    tPathLen = strlen(pszDest);
    tPathLen += mir_snprintf(pszDest + tPathLen, MAX_PATH-tPathLen, "\\%s\\", C6PROTOCOLNAME);
}

//--------------------------------------------------------------------
//                              createCListGroup
//--------------------------------------------------------------------

int createCListGroup(const char* szGroupName)
{

// code from: src/modules/clist/groups.c
// function: static int GroupNameExists(const TCHAR *name, int skipGroup)

	char str[33];
	int i;
	DBVARIANT dbv;

	for ( i = 0;; i++ ) {
		itoa( i, str, 10 );
		if ( DBGetContactSettingTString( NULL, "CListGroups", str, &dbv ))
			break;
		TCHAR* name = dbv.ptszVal;
		if ( name[0]!='\0' && !_tcscmp( name+1, szGroupName )) {
			// Already exists, no need to create
			DBFreeVariant(&dbv);
			return 0;
		}
		DBFreeVariant(&dbv);
	}

  	int hGroup = CallService(MS_CLIST_GROUPCREATE, 0, 0);

	CLIST_INTERFACE *clint = NULL;

	if (ServiceExists(MS_CLIST_RETRIEVE_INTERFACE))
    	clint = (CLIST_INTERFACE*)CallService(MS_CLIST_RETRIEVE_INTERFACE, 0, 0);

	if (gbUnicodeCore && clint && clint->version >= 1) { // we've got unicode interface, use it

		wchar_t *pwszGroupName;
		pwszGroupName = mir_a2u_cp(szGroupName, CP_ACP);

    	clint->pfnRenameGroup(hGroup, (TCHAR*)pwszGroupName);
		mir_free(pwszGroupName);
  	}
  	else CallService(MS_CLIST_GROUPRENAME, hGroup, (LPARAM)szGroupName);

  	return hGroup;
}

LPSTR get2Ansi(const char *szOldName)
{
	LPSTR pszbuf;
	if (gbUnicodeCore)
		pszbuf = mir_u2a_cp(szOldName, CP_ACP);
	else {
		pszbuf = mir_alloc(MAX_PATH + 1);
		strcpy(pszbuf, szOldName);
	}
	return pszbuf;
}

//--------------------------------------------------------------------
//                            checkContactSS
//--------------------------------------------------------------------

int checkContactSS(HANDLE hContact)
{

	char szUser[40]; // 20
	int i = 0;
	DBVARIANT dbv;

	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", 0)) {
   		if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, "CSS", &dbv)) {
			GetUserNickName(szUser);
			i = (!strcmp(szUser, dbv.pszVal));
			DBFreeVariant(&dbv);
		}
	}
	return i;
}

//--------------------------------------------------------------------
//                            removeContactSS
//--------------------------------------------------------------------

int removeContactSS(HANDLE hContact, char *szNick)
{
	DBVARIANT dbv;

	if (checkContactSS(hContact)) {
	    if (!DBGetContactSetting(hContact, "CList", "Group", &dbv)) {
			LPSTR pszGroupName = mir_alloc(256);

			strcpy(pszGroupName, dbv.pszVal);
			c6LogMsg("nick: %s (%s)...", szNick, pszGroupName);
			DBFreeVariant(&dbv);
			if (!c6RemoveXCAPBuddy(szNick, pszGroupName))
				c6LogMsg("...deleted from Server!");

			mir_free(pszGroupName);
		}
	}
	return 0;
}

//--------------------------------------------------------------------
//                            add2ignoreList
//--------------------------------------------------------------------

int addSrvIgnoreList(char *szNick, int mask)
{
	HANDLE hContact;
	char* szProto;
	DBVARIANT dbv;
	BOOL bFound = FALSE;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	while (hContact != NULL && !bFound)
	{

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
			if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {
	        	if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
					if (strcmp(szNick,dbv.pszVal)==0)
						bFound = TRUE;
					DBFreeVariant(&dbv);
				}
			}

		if (!bFound)
			hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}

	//not present: add
	if (!bFound)
		hContact = (HANDLE)CallService(MS_DB_CONTACT_ADD, 0, 0);
	CallService(MS_PROTO_ADDTOCONTACT, (WPARAM)hContact, (LPARAM)C6PROTOCOLNAME);
	CallService(MS_PROTO_ADDTOCONTACT,(WPARAM)hContact,(LPARAM)"Ignore");
	DBWriteContactSettingString(hContact, C6PROTOCOLNAME, C6_LOGINID, szNick);
	DBWriteContactSettingByte(hContact, "CList", "NotOnList", 1);
	DBWriteContactSettingByte(hContact, "CList", "Hidden", 1);

	CallService(MS_IGNORE_IGNORE, (WPARAM)hContact, mask);//IGNOREEVENT_ALL);

	return 0;

}

//--------------------------------------------------------------------
//                            enumSrvContacts
//--------------------------------------------------------------------

void enumSrvContacts(HWND hwndList, HWND hwndCombo)
{
	HANDLE hContact;
	char* szProto;
	DBVARIANT dbv;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	while (hContact != NULL)
	{

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
			if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {

        		if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {

					if (checkContactSS(hContact))
						SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)dbv.pszVal);
					else SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)dbv.pszVal);

					DBFreeVariant(&dbv);
				}
			}

		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}

}

//--------------------------------------------------------------------
//                            requestClient
//--------------------------------------------------------------------

typedef struct GetInfo_s {
	DWORD dwFlags;
	LPSTR pszNick;
} GetInfo;

void requestClient(LPSTR szNick)
{
	GetInfo *gi = (GetInfo *)mir_alloc(sizeof(GetInfo));
	memset(gi, 0, sizeof(GetInfo));

	gi->dwFlags = 3;
	gi->pszNick = mir_strdup(szNick);
	AllocateCookie(OP_GETINFO, gi->pszNick, gi);
}

BOOL getClient(LPSTR pszNick, DWORD *dwFlags)
{
	GetInfo* gi;
	DWORD dwCookie;

	if (!FindCookie(OP_GETINFO, pszNick, &dwCookie, (void *)&gi))
	{
		return FALSE;
	}

	*dwFlags = gi->dwFlags;
	mir_free(gi->pszNick);
	mir_free(gi);
	FreeCookie(dwCookie);
	return TRUE;
}
