//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_DLG                         101
#define IDI_MAIN                        104
#define IDD_ADVANCED                    107
#define IDR_MENU                        108
#define IDC_SEARCH                      1000
#define IDC_ANY                         1001
#define IDC_ALL                         1002
#define IDC_NOT                         1003
#define IDC_RESULTS                     1004
#define IDC_CONTACTPROGRESS             1005
#define IDC_EVENTPROGRESS               1006
#define IDC_PHRASE                      1007
#define IDC_ADVANCED                    1011
#define IDC_COMBO_INOUT                 1012
#define IDC_FROM_CHECK                  1014
#define IDC_FROMDATE                    1015
#define IDC_FROMTIME                    1016
#define IDC_UNTIL_CHECK                 1017
#define IDC_UNTILDATE                   1018
#define IDC_UNTILTIME                   1019
#define IDC_MAX_RESULTS                 1021
#define IDC_CASESENSITIVE               1023
#define IDC_CONTACT_TREE                1024
#define IDC_ALL_CONTACTS                1025
#define GRP_CONTACTS                    1026
#define IDC_COMBO1                      1027
#define IDC_SORTBY_COMBO                1027
#define IDC_RESULTS_MSG                 1028
#define IDC_STATIC_SORTBY               1029
#define IDC_GRPBX_TOP                   2000
#define IDC_GRPBX_PRGRS                 2001
#define IDM_EXPORTTOTXT                 40004
#define IDM_COPYTOCLIPBOARD             40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
