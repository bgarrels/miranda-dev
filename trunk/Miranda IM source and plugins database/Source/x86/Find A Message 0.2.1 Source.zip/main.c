#include "commonheaders.h"

//========================
//  MirandaPluginInfo
//========================
PLUGININFO pluginInfo={
	sizeof(PLUGININFO),
	"Find A Message",
	PLUGIN_MAKE_VERSION(0,2,1,0),
	"Find a message in your history...",
	"Jonathan Gordon",
	"ICQ 98791178, MSN jonnog@hotmail.com",
	"� 2003 Jonathan Gordon, jdgordy@gmail.com",
	"",		// www
	0,		//not transient
	0		//doesn't replace anything built-in
};
__declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	return &pluginInfo;
}

//========================
//  WINAPI DllMain
//========================

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst=hinstDLL;
	return TRUE;
}

//===================
// MainInit
//===================

int MainInit(WPARAM wParam,LPARAM lParam)
{
	return 0;
}

static int FindAMessageMenuCommand(WPARAM wParam,LPARAM lParam)
{
	HANDLE hContact=(HANDLE)wParam;
	HWND hwnd = NULL;
//	
	hwnd = CreateDialog(hInst,MAKEINTRESOURCE(IDD_DLG),0,FindAMsgDlgProc);

	return 0;
}

//===========================
// Load (hook ModulesLoaded)
//===========================
int __declspec(dllexport) Load(PLUGINLINK *link)
{ 	CLISTMENUITEM mi;
	pluginLink = link; 
	CreateServiceFunction("FindAMessage/MenuCommand",FindAMessageMenuCommand);
	ZeroMemory(&mi,sizeof(mi));
	mi.cbSize=sizeof(mi);
	mi.position=600000000;
	mi.flags=0;
	mi.hIcon= LoadIcon(hInst,MAKEINTRESOURCE(IDI_MAIN));
	mi.pszName=Translate("&Find a Message");
	mi.pszService="FindAMessage/MenuCommand";
	mi.pszContactOwner=NULL;

	CallService(MS_CLIST_ADDMAINMENUITEM,0,(LPARAM)&mi);

	// make sure we are not searching when the plugin starts up, incase not stopped correctly
	DBWriteContactSettingByte(NULL, modname, "Searching", 0);

	// columns setup
	DBWriteContactSettingByte(NULL, modname, "Column_Time", COLUMN_TIME);
	DBWriteContactSettingByte(NULL, modname, "Column_Proto", COLUMN_PROTO);
	DBWriteContactSettingByte(NULL, modname, "Column_InOut", COLUMN_INOUT);
	DBWriteContactSettingByte(NULL, modname, "Column_Nick",COLUMN_NICK);
	DBWriteContactSettingByte(NULL, modname, "Column_Msg", COLUMN_MSG);
	// advanced options defaults
	DBWriteContactSettingByte(NULL, modname, "SearchOptionInOut", (BYTE)DBGetContactSettingByte(NULL, modname, "SearchOptionInOut",0));
	DBWriteContactSettingByte(NULL, modname, "SearchOptionCaseSensitive", (BYTE)DBGetContactSettingByte(NULL, modname, "SearchOptionCaseSensitive",0));
	DBWriteContactSettingByte(NULL, modname, "SearchOptionMaxResults", (BYTE)DBGetContactSettingByte(NULL, modname, "SearchOptionMaxResults",0));
	DBWriteContactSettingDword(NULL, modname, "SearchOptionStartTime", (DWORD)DBGetContactSettingDword(NULL, modname, "SearchOptionStartTime",0));
	DBWriteContactSettingDword(NULL, modname, "SearchOptionEndTime", (DWORD)DBGetContactSettingDword(NULL, modname, "SearchOptionEndTime",0));

return 0; 
}


int __declspec(dllexport) Unload(void) 
{ 
	return 0;
} 


// thread stuff
struct FORK_ARG {
	HANDLE hEvent;
	void (__cdecl *threadcode)(void*);
	unsigned (__stdcall *threadcodeex)(void*);
	void *arg;
};

void __cdecl forkthread_r(void *param) 
{    
   struct FORK_ARG *fa=(struct FORK_ARG*)param; 
   void (*callercode)(void*)=fa->threadcode; 
   void *arg=fa->arg; 

   CallService(MS_SYSTEM_THREAD_PUSH,0,0); 

   SetEvent(fa->hEvent); 

   __try { 
      callercode(arg); 
   } __finally { 
      CallService(MS_SYSTEM_THREAD_POP,0,0); 
   } 

   return; 
} 

unsigned long forkthread (   void (__cdecl *threadcode)(void*),unsigned long stacksize,void *arg) 
{ 
   unsigned long rc; 
   struct FORK_ARG fa; 

   fa.hEvent=CreateEvent(NULL,FALSE,FALSE,NULL); 
   fa.threadcode=threadcode; 
   fa.arg=arg; 

   rc=_beginthread(forkthread_r,stacksize,&fa); 

   if ((unsigned long)-1L != rc) { 
      WaitForSingleObject(fa.hEvent,INFINITE); 
   } 
   CloseHandle(fa.hEvent); 

   return rc; 
}

// random stuff
int Openfile(char * outputFile)
{
	OPENFILENAME ofn;
	char filename[MAX_PATH] = "";
	char filter[32] = "All Files\0*.*\0";
	int r;
	char title[12]= "Save Results";
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFile = filename;
	ofn.lpstrFilter = filter;
	ofn.Flags = OFN_HIDEREADONLY | OFN_SHAREAWARE | OFN_PATHMUSTEXIST; 
	ofn.lpstrTitle = title;
	ofn.nMaxFile = MAX_PATH;

		r = GetSaveFileName((LPOPENFILENAME)&ofn);
		if (!r)
			return 0;
	lstrcpy(outputFile,filename);
	return 1;
}

//=======================================================
//DBGetContactSettingString
//=======================================================
int DBGetContactSettingString(HANDLE hContact, char* szModule, char* szSetting, char* value)
{
	DBVARIANT dbv;
	if (!DBGetContactSetting(hContact, szModule, szSetting, &dbv))
	{
		strcpy(value, dbv.pszVal);
		DBFreeVariant(&dbv);
		return 1;
	}
	else 
	{
		DBFreeVariant(&dbv);
		return 0;
	}
	
	return 0;
}

void checkGroups(char* group)
{
	int i;
    char str[50], name[256];
    DBVARIANT dbv;

	if (lstrlen(group) < 1)
		return;

    for (i = 0;; i++) 
	{
        itoa(i, str, 10);
        if (DBGetContactSetting(NULL, "CListGroups", str, &dbv))
            break;
        if (dbv.type == DBVT_ASCIIZ)
		{
			if (dbv.pszVal[0] != '\0' && !lstrcmpi(dbv.pszVal + 1, group)) 
			{
				DBFreeVariant(&dbv);
				return;
			}
		
	        DBFreeVariant(&dbv);
        }
    }
    name[0] = 1 | GROUPF_EXPANDED;
    strncpy(name + 1, group, sizeof(name) - 1);
    name[strlen(group) + 1] = '\0';
    DBWriteContactSettingString(NULL, "CListGroups", str, name);
    CallService(MS_CLUI_GROUPADDED, i + 1, 0);
}

void export2txt(HWND hwnd)
{
	FILE* file;
	char FileName[MAX_PATH];
	char tmp[601];
	int i, results;
	if (!Openfile(FileName)) return;
	if (!(file = fopen(FileName, "w")))
	{
		msg("Couldnt open the file to save results.", modname);
		return;
	}
	if (!(results = ListView_GetItemCount(GetDlgItem(hwnd, IDC_RESULTS))))
	{
		msg("Nothing to save", modname);
		fclose(file);
		return;
	}
	fprintf(file, "Results returned by \"Find A Message\" using the following search settings\r\n");
	if (GetWindowTextLength(GetDlgItem(hwnd, IDC_ANY)))
	{
		GetDlgItemText(hwnd, IDC_ANY, tmp, sizeof(tmp));
		fprintf(file, "Any of the words: %s\r\n", tmp);
	}
	if (GetWindowTextLength(GetDlgItem(hwnd, IDC_ALL)))
	{
		GetDlgItemText(hwnd, IDC_ALL, tmp, sizeof(tmp));
		fprintf(file, "All the words: %s\r\n", tmp);
	}
	if (GetWindowTextLength(GetDlgItem(hwnd, IDC_NOT)))
	{
		GetDlgItemText(hwnd, IDC_NOT, tmp, sizeof(tmp));
		fprintf(file, "None of the words: %s\r\n", tmp);
	}
	if (GetWindowTextLength(GetDlgItem(hwnd, IDC_PHRASE)))
	{
		GetDlgItemText(hwnd, IDC_PHRASE, tmp, sizeof(tmp));
		fprintf(file, "The phrase: %s\r\n", tmp);
	}
	GetDlgItemText(hwnd, IDC_RESULTS_MSG, tmp, sizeof(tmp));
	fprintf(file, "The search %s\r\n\r\n", tmp);
	for (i=0; i<results; i++)
	{
		ListView_GetItemText(GetDlgItem(hwnd, IDC_RESULTS), i, COLUMN_NICK, tmp, sizeof(tmp));
		fprintf(file, "%s ", tmp);
		ListView_GetItemText(GetDlgItem(hwnd, IDC_RESULTS), i, COLUMN_INOUT, tmp, sizeof(tmp));
		fprintf(file, "(%sbound) ", tmp);
		ListView_GetItemText(GetDlgItem(hwnd, IDC_RESULTS), i, COLUMN_PROTO, tmp, sizeof(tmp));
		fprintf(file, "on %s ", tmp);
		ListView_GetItemText(GetDlgItem(hwnd, IDC_RESULTS), i, COLUMN_TIME, tmp, sizeof(tmp));
		fprintf(file, "@ %s\r\n", tmp);
		ListView_GetItemText(GetDlgItem(hwnd, IDC_RESULTS), i, COLUMN_MSG, tmp, sizeof(tmp));
		fprintf(file, "%s\r\n\r\n", tmp);
	}
	fclose(file);
}
