#ifndef _COMMONGEADERS_H
#define _COMMONGEADERS_H

#define _WIN32_WINNT 0x0500
#define _WIN32_IE 0x4000
//#define UNICODE

//=====================================================
//	Includes (yea why not include lots of stuff :p )
//=====================================================
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <time.h>
#include <stddef.h>
#include <process.h>
#include <string.h>
#include "../miranda_src/SDK/Headers_c/newpluginapi.h"
#include "../miranda_src/SDK/Headers_c/m_clist.h"
#include "../miranda_src/SDK/Headers_c/m_clui.h"
#include "../miranda_src/SDK/Headers_c/m_skin.h"
#include "../miranda_src/SDK/Headers_c/m_langpack.h"
#include "../miranda_src/SDK/Headers_c/m_protomod.h"
#include "../miranda_src/SDK/Headers_c/m_database.h"
#include "../miranda_src/SDK/Headers_c/m_system.h"
#include "../miranda_src/SDK/Headers_c/m_protocols.h"
#include "../miranda_src/SDK/Headers_c/m_userinfo.h"
#include "../miranda_src/SDK/Headers_c/m_options.h"
#include "../miranda_src/SDK/Headers_c/m_protosvc.h"
#include "../miranda_src/SDK/Headers_c/m_utils.h"
#include "../miranda_src/SDK/Headers_c/m_ignore.h"
#include "../miranda_src/SDK/Headers_c/m_clc.h"
#include "../miranda_src/SDK/Headers_c/m_history.h"
#include "../miranda_src/SDK/Headers_c/win2k.h"
//#include "../miranda_src/SDK/Headers_c/m_uninstaller.h"
//#include <winbase.h>
#include "resource.h"

//=======================================================
//	Definitions
//=======================================================
#define modname			"findAmsg"
#define msg(a,b)		MessageBox(0,a,b,MB_OK)

typedef struct {
	int time;
	HANDLE hDbEvent;
	HANDLE hContact;
} Message;	

#define MAX_PROTOS 20
#define MAX_GROUPS 20


// columns
#define COLUMN_PROTO	(BYTE)DBGetContactSettingByte(NULL, modname, "Column_Proto",2)
#define COLUMN_NICK		(BYTE)DBGetContactSettingByte(NULL, modname, "Column_Nick",0)
#define COLUMN_TIME		(BYTE)DBGetContactSettingByte(NULL, modname, "Column_Time",1)
#define COLUMN_INOUT	(BYTE)DBGetContactSettingByte(NULL, modname, "Column_InOut",3)
#define COLUMN_MSG		(BYTE)DBGetContactSettingByte(NULL, modname, "Column_Msg",4)

#define COLUMNS			5


PLUGINLINK *pluginLink;
HINSTANCE hInst;
void export2txt(HWND);
unsigned long forkthread (   void (__cdecl *threadcode)(void*),unsigned long stacksize,void *arg) ;
// search dlg
BOOL CALLBACK FindAMsgDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void __cdecl findmessages(LPVOID di)  ;
int CALLBACK SortGeneralListFunc(LPARAM lParam1,LPARAM lParam2,LPARAM lParamSort);
BOOL CALLBACK AdvancedSettingsDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

int DBGetContactSettingString(HANDLE hContact, char* szModule, char* szSetting, char* value);



#endif

