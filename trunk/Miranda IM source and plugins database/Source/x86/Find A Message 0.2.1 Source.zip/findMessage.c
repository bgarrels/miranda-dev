#include "commonheaders.h"

char* strstr_notCaseSensitive(char *s1, char *s2, int caseSensitive) 
{ 
   int i,j,k; 
   if (caseSensitive) return strstr(s1,s2);
   for(i=0;s1[i];i++) 
      for(j=i,k=0;tolower(s1[j])==tolower(s2[k]);j++,k++) 
         if(!s2[k+1]) 
            return (s1+i); 

   return NULL; 
} 

void __cdecl findmessages(LPVOID di) 
{ 
	// variables..
	HWND hwnd = (HWND)di; 
	int i;
	char strdatetime[64],msgBuffer[600], progress[1024], *pch;
	char anywords[1024];char allwords[1024];char notwords[1024];char phrase[1024];
	// counters
	int results = 0, TotalContacts = CallService(MS_DB_CONTACT_GETCOUNT, 0, 0), SearchedContacts = 0, TotalContactMessages, SearchedContactMessages = 0, msgfoundcount = 0, msgcount=0;
	// advanced settings
	int checkAllContacts = DBGetContactSettingByte(NULL, modname, "SearchOptionCheckAllContacts",1);
	int caseSensitive = DBGetContactSettingByte(NULL, modname, "SearchOptionCaseSensitive",0);
	int startTime = DBGetContactSettingDword(NULL, modname, "SearchOptionStartTime",0);
	int endTime = DBGetContactSettingDword(NULL, modname, "SearchOptionEndTime",0);
	int max_results = DBGetContactSettingByte(NULL, modname, "SearchOptionMaxResults",0);
	int searchInOutAll = DBGetContactSettingByte(NULL, modname, "SearchOptionInOut",0); // 0 = all, 1 = in, 2 = out
	// DB vars
	HANDLE hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	HANDLE hDbEvent;
    DBEVENTINFO dbei = { 0 };
	int newBlobSize,oldBlobSize;
	
	char wordsANYlistTmp[20][32]= {"\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0"};
	char wordsNOTlistTmp[20][32]= {"\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0"};
	char wordsALLlistTmp[20][32]= {"\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0","\0"};
	int doany =0, donone = 0, doall = 0, numberOfALLwords, dophrase;
	int printMessage=0;
	int searchallContacts = DBGetContactSettingByte(NULL, modname, "SearchAllContacts", 1);

	// make sure the hwnd is actually valid..
	if (!IsWindow(hwnd)) return;

	DBWriteContactSettingByte(NULL, modname, "Searching", 1);
	EnableWindow(GetDlgItem(hwnd, IDC_ADVANCED),0); 
	// get the words to search and break em up
	if (DBGetContactSettingString(NULL, modname, "anywords", anywords))
	{
		if (anywords[0] != '\0')
		{
			pch = strtok (anywords," ,.");
			for (i=0;i<20 && pch;i++)
			{
				strncpy(wordsANYlistTmp[i], pch, 32);
				pch = strtok (NULL, " ,.");
			}
			doany = 1;
		}
	}

	if (DBGetContactSettingString(NULL, modname, "allwords", allwords))
	{
		if (allwords[0] != '\0')
		{
			pch = strtok (allwords," ,.");
			for (numberOfALLwords=0;numberOfALLwords<20 && pch;numberOfALLwords++)
			{
				strncpy(wordsALLlistTmp[numberOfALLwords], pch,32);
				pch = strtok (NULL, " ,.");
			}
			doall = 1;
		}
	}
	if (DBGetContactSettingString(NULL, modname, "notwords", notwords))
	{
		if (notwords[0] != '\0')
		{
			pch = strtok (notwords," ,.");
			for (i=0;i<20 && pch;i++)
			{
				strncpy(wordsNOTlistTmp[i], pch,32);
				pch = strtok (NULL, " ,.");
			}
			donone = 1;
		}
	}
	if (DBGetContactSettingString(NULL, modname, "phrase", phrase))
		dophrase = 1;


	while (hContact && (!max_results || (max_results > msgfoundcount)))
	{
		const char* szProto = (const char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0); 	
		if (szProto && (CallProtoService(szProto, PS_GETCAPS, PFLAGNUM_1, 0) & PF1_IM)) // make sure the proto supports msgs
		{
			// check if we want to search this contact, or we r searching all contacts
			if (!searchallContacts && !DBGetContactSettingByte(hContact, modname, "SearchContact", 1)) 
			{
				hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)(HANDLE)hContact, 0);
				continue;
			}
			SearchedContactMessages = 0;
			TotalContactMessages = CallService(MS_DB_EVENT_GETCOUNT, (WPARAM)hContact, 0);
			hDbEvent = (HANDLE)CallService(MS_DB_EVENT_FINDLAST,(WPARAM)hContact, 0); // find the contacts last msg, returns 0 on success
			
			while (hDbEvent && (!max_results || (max_results > msgfoundcount)))
			{
				int exactChk =1, allChk = 1, notChk = 1, anyChk = !doany;
				// check if they want to kill the search
				if (!DBGetContactSettingByte(NULL, modname, "Searching", 0))
				{
					SetDlgItemText(hwnd, IDC_RESULTS_MSG, Translate("Search Canceled"));
					return;
				}
				
				_snprintf(progress, sizeof(progress),Translate("Progress: %d/%d Contacts Searched. %d/%d Messages Searched"),SearchedContacts, TotalContacts, SearchedContactMessages, TotalContactMessages);
				SetDlgItemText(hwnd, IDC_RESULTS_MSG, progress);
				// get the event
				ZeroMemory(&dbei,sizeof(dbei));
				dbei.cbSize=sizeof(dbei);
				dbei.pBlob=NULL;
				oldBlobSize=0;
					
				newBlobSize=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)hDbEvent,0);
				if(newBlobSize>oldBlobSize) {
					dbei.pBlob=(PBYTE)realloc(dbei.pBlob,newBlobSize);
					oldBlobSize=newBlobSize;
				}
				dbei.cbBlob=oldBlobSize;
				if (CallService(MS_DB_EVENT_GET,(WPARAM)hDbEvent,(LPARAM)&dbei)) break; // get the next contact if the event is screwed up
				// check incoming outgoing messages
				if ((dbei.eventType == EVENTTYPE_MESSAGE) &&
					( ((searchInOutAll == 1) && (dbei.flags & DBEF_SENT)) ||
						 ((searchInOutAll == 2) && !(dbei.flags & DBEF_SENT))
						 ) )
				{
					hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDPREV,(WPARAM)hDbEvent,0);
					continue;
				}
				SearchedContactMessages++;
				// check the time
				if ( (startTime && (startTime >= dbei.timestamp)) || (endTime && (endTime <= dbei.timestamp)) ) 
				{
					hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDPREV,(WPARAM)hDbEvent,0);
					continue;
				}
				// now check the message for the strings...
				msgcount++;
				strncpy(msgBuffer, dbei.pBlob, 600);
				if (oldBlobSize > 599)
					strcpy(&msgBuffer[596], "...");

				// exact string
				if (phrase[0] != '\0' && !strstr_notCaseSensitive(msgBuffer,phrase,caseSensitive))
					exactChk = 0;
				for (i=0; i<10; i++)
				{
					// any words
					if (wordsANYlistTmp[i][0] != '\0' && strstr_notCaseSensitive(msgBuffer,wordsANYlistTmp[i],caseSensitive))
					{
						anyChk = 1;
					}
					// not words
					if (wordsNOTlistTmp[i][0] != '\0' && strstr_notCaseSensitive(msgBuffer,wordsNOTlistTmp[i],caseSensitive))
					{
						notChk = 0;
					}
					//all words
					if (wordsALLlistTmp[i][0] != '\0' && !strstr_notCaseSensitive(msgBuffer,wordsALLlistTmp[i],caseSensitive))
					{
						allChk = 0;
					}
				}
			
				if (exactChk && allChk && notChk && anyChk ) 
				{						
					// if the msg is good.
					LVITEM lvItem;
					DBTIMETOSTRING dbtts;
					int index;
					Message *lparam = (Message*)malloc(sizeof(Message));
					lparam->hDbEvent = hDbEvent;
					lparam->hContact = hContact;
				//	lparam->time = dbtts.
					// remove ugly blocks where whitespace should be
					while (msgBuffer[i] != '\0')
					{
						if (msgBuffer[i] == '\r' ||
							msgBuffer[i] == '\n' ||
							msgBuffer[i] == '\t')
							msgBuffer[i] = ' ';
						i++;
					}
					// copy the msg info to the msgList array
					dbtts.cbDest = sizeof(strdatetime);
					dbtts.szDest=strdatetime;
					dbtts.szFormat="d t";
					CallService(MS_DB_TIME_TIMESTAMPTOSTRING,dbei.timestamp,(LPARAM)&dbtts);
					lvItem.mask = LVIF_PARAM;
					lvItem.iItem = 0;
					lvItem.iSubItem = 0;
					lvItem.lParam = (LPARAM)lparam;
					
					index = ListView_InsertItem(GetDlgItem(hwnd, IDC_RESULTS),&lvItem);
					ListView_SetItemText(GetDlgItem(hwnd, IDC_RESULTS),index,COLUMN_NICK,(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0));
					ListView_SetItemText(GetDlgItem(hwnd, IDC_RESULTS),index,COLUMN_PROTO,(char*)szProto);
					ListView_SetItemText(GetDlgItem(hwnd, IDC_RESULTS),index,COLUMN_TIME,dbtts.szDest);
					ListView_SetItemText(GetDlgItem(hwnd, IDC_RESULTS),index,COLUMN_MSG,msgBuffer);
					if (dbei.flags & DBEF_SENT)
					{
						ListView_SetItemText(GetDlgItem(hwnd, IDC_RESULTS),index,COLUMN_INOUT,"Out");
					}
					else ListView_SetItemText(GetDlgItem(hwnd, IDC_RESULTS),index,COLUMN_INOUT,"In");
					msgfoundcount++;
				}
			// grab the next msg 
			hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDPREV,(WPARAM)hDbEvent,0);
			} // end dbevent while loop
		SearchedContacts++;
		} // end contact proto check 
		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)(HANDLE)hContact, 0);
	} // end hcontact while loop
	free(dbei.pBlob);
	_snprintf(progress, sizeof(progress),Translate("Finished... %d Contacts Searched. %d Messages Found"),SearchedContacts, msgfoundcount);
	SetDlgItemText(hwnd, IDC_RESULTS_MSG,progress );
	SetDlgItemText(hwnd,IDC_SEARCH, "Search");
	DBWriteContactSettingByte(NULL, modname, "Searching", 0);
	// re-enable the advanced button
	EnableWindow(GetDlgItem(hwnd, IDC_ADVANCED),1);
	return;
}
