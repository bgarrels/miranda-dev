#include "commonheaders.h"


static int MessageDialogResize(HWND hwndDlg,LPARAM lParam,UTILRESIZECONTROL *urc)
{
	switch(urc->wId) {
		case IDC_GRPBX_TOP:
		case IDC_GRPBX_PRGRS:
		case IDC_RESULTS_MSG:
			return RD_ANCHORX_WIDTH|RD_ANCHORY_TOP;
		case IDC_SEARCH:
		case IDCANCEL:
		case IDC_ADVANCED:
			return RD_ANCHORX_RIGHT|RD_ANCHORY_TOP;
		case IDC_RESULTS:
			return RD_ANCHORX_WIDTH|RD_ANCHORY_HEIGHT;
		case IDC_ANY:
		case IDC_ALL:
		case IDC_NOT:
		case IDC_PHRASE:
			return RD_ANCHORX_WIDTH|RD_ANCHORY_TOP;
		default:
			return RD_ANCHORX_LEFT|RD_ANCHORY_TOP;
	}
}

BOOL CALLBACK FindAMsgDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg) {
		case WM_INITDIALOG:
		{
			DBWriteContactSettingByte(NULL, modname, "SearchAllContacts", 1);
			SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(hInst,MAKEINTRESOURCE(IDI_MAIN)));
			// results table
			{ 
				int index =1;
				LVCOLUMN sLC;

				sLC.mask = LVCF_FMT | LVCF_TEXT | LVCF_SUBITEM | LVCF_WIDTH;
				sLC.fmt = LVCFMT_LEFT;
				// so the columns are created in the correct order
				ListView_SetExtendedListViewStyle(GetDlgItem(hwnd, IDC_RESULTS), 32); //LVS_EX_FULLROWSELECT
				for (index=0; index < COLUMNS; index++)
				{
					if (index == COLUMN_PROTO)
					{
						sLC.pszText = Translate("Protocol"); sLC.cx = 60;
						ListView_InsertColumn(GetDlgItem(hwnd, IDC_RESULTS),COLUMN_PROTO,&sLC);
					}
					else if (index == COLUMN_NICK)
					{
						sLC.pszText = Translate("Contact"); sLC.cx = 120;
						ListView_InsertColumn(GetDlgItem(hwnd, IDC_RESULTS),COLUMN_NICK,&sLC);
					}
					else if (index == COLUMN_TIME)
					{						
						sLC.pszText = Translate("Time/Date"); sLC.cx = 120; // perfect size
						ListView_InsertColumn(GetDlgItem(hwnd, IDC_RESULTS),COLUMN_TIME,&sLC);
					}
					else if (index == COLUMN_MSG)
					{
						sLC.pszText = Translate("Message"); sLC.cx = 600;
						ListView_InsertColumn(GetDlgItem(hwnd, IDC_RESULTS),COLUMN_MSG,&sLC);
					}
					else if (index == COLUMN_INOUT)
					{
						sLC.pszText = Translate("I/O"); sLC.cx = 30;
						ListView_InsertColumn(GetDlgItem(hwnd, IDC_RESULTS),COLUMN_INOUT,&sLC);
					}
				}
			}			
		}
		return TRUE;
		case WM_GETMINMAXINFO:
		{
			MINMAXINFO *mmi=(MINMAXINFO*)lParam;
			mmi->ptMinTrackSize.x=545; 
			mmi->ptMinTrackSize.y=300;
			return 0;
		}
		case WM_SIZE:
		{
			UTILRESIZEDIALOG urd;
			ZeroMemory(&urd,sizeof(urd));
			urd.cbSize=sizeof(urd);
			urd.hInstance=hInst;
			urd.hwndDlg=hwnd;
			urd.lParam=(LPARAM)0;
			urd.lpTemplate=MAKEINTRESOURCE(IDD_DLG);
			urd.pfnResizer=MessageDialogResize;
			CallService(MS_UTILS_RESIZEDIALOG,0,(LPARAM)&urd);
			break;

		}
		case WM_COMMAND:
			
			switch(LOWORD(wParam)) {
			case IDC_SEARCH:
				{
					if (!DBGetContactSettingByte(NULL, modname, "Searching", 0))
					{
						char tmp[1024];
						int i=0;
						LVITEM lvi;
						SetDlgItemText(hwnd,IDC_SEARCH, "Stop");
						// clear previous results
						if (ListView_GetItemCount(GetDlgItem(hwnd, IDC_RESULTS)))
						{
							for (i=0; i<ListView_GetItemCount(GetDlgItem(hwnd, IDC_RESULTS)); i++)
							{
								lvi.iItem = i;
								lvi.lParam = 0;
								if (ListView_GetItem(GetDlgItem(hwnd,IDC_RESULTS), &lvi) && lvi.lParam)
									free((Message*)lvi.lParam);
							}

							ListView_DeleteAllItems(GetDlgItem(hwnd, IDC_RESULTS));
						}
						if(GetWindowTextLength(GetDlgItem(hwnd,IDC_ANY))) 
						{
							GetDlgItemText(hwnd,IDC_ANY,tmp,sizeof(tmp));
							DBWriteContactSettingString(NULL, modname, "anywords", tmp);
						}
						else DBWriteContactSettingString(NULL, modname, "anywords", "");
						if(GetWindowTextLength(GetDlgItem(hwnd,IDC_NOT))) 
						{
							GetDlgItemText(hwnd,IDC_NOT,tmp,sizeof(tmp));
							DBWriteContactSettingString(NULL, modname, "notwords", tmp);
						}
						else DBWriteContactSettingString(NULL, modname, "notwords", "");
						if(GetWindowTextLength(GetDlgItem(hwnd,IDC_ALL))) 
						{
							GetDlgItemText(hwnd,IDC_ALL,tmp,sizeof(tmp));
							DBWriteContactSettingString(NULL, modname, "allwords", tmp);
						}
						else DBWriteContactSettingString(NULL, modname, "allwords", "");
						if(GetWindowTextLength(GetDlgItem(hwnd,IDC_PHRASE))) 
						{
							GetDlgItemText(hwnd,IDC_PHRASE,tmp,sizeof(tmp));
							DBWriteContactSettingString(NULL, modname, "phrase", tmp);
						}
						else DBWriteContactSettingString(NULL, modname, "phrase", "");
						
						// start the new thread and search...
						forkthread(findmessages, 0, (LPVOID)hwnd  ); 
					}
					else 
					{
						DBWriteContactSettingByte(NULL, modname, "Searching", 0);
						SetDlgItemText(hwnd,IDC_SEARCH, "Search");
						EnableWindow(GetDlgItem(hwnd, IDC_ADVANCED),1); 
					}
					
				}
			break;
			case IDCANCEL:
			{
				DestroyWindow(hwnd);
			}
			break;
			case IDC_ADVANCED:
			{
				CreateDialogParam(hInst,MAKEINTRESOURCE(IDD_ADVANCED),hwnd,AdvancedSettingsDlgProc, (WPARAM)0);
			}
			break;

			}
		break;
		case WM_NOTIFY:
		{
			switch(((NMHDR*)lParam)->code)
			{
				case LVN_COLUMNCLICK:
				{
					NMLISTVIEW *nmLV = (NMLISTVIEW*)lParam;
					if (DBGetContactSettingByte(NULL, modname, "SortOrderColumn",COLUMN_NICK) == nmLV->iSubItem)
						DBWriteContactSettingByte(NULL, modname, "SortOrder", (BYTE)!DBGetContactSettingByte(NULL, modname, "SortOrder",0));
					else DBWriteContactSettingByte(NULL, modname, "SortOrderColumn", (BYTE)nmLV->iSubItem);
					
					ListView_SortItems(GetDlgItem(hwnd, IDC_RESULTS),SortGeneralListFunc,(LPARAM)GetDlgItem(hwnd, IDC_RESULTS));
				} 
				break;
				case NM_CLICK:
				{	
					LVHITTESTINFO hti;
					hti.pt=((NMLISTVIEW*)lParam)->ptAction;
					ListView_SubItemHitTest(GetDlgItem(hwnd,IDC_RESULTS),&hti);
				//	if(hti.flags!=LVHT_ONITEMICON || hti.iSubItem) break;
					ListView_SetItemState(GetDlgItem(hwnd, IDC_RESULTS),hti.iItem,LVIS_SELECTED ,LVIS_SELECTED); // select item
					break;
				}
				case NM_RCLICK:
				{	
					HMENU hMenu, hSubMenu;
                    POINT pt;
					LVITEM lvi;
					LVHITTESTINFO hti;
					Message *msgInfo;
					
					hti.pt=((NMLISTVIEW*)lParam)->ptAction;
					ListView_SubItemHitTest(GetDlgItem(hwnd,IDC_RESULTS),&hti);
					lvi.mask = LVIF_PARAM;
					lvi.iItem = hti.iItem;
					lvi.lParam = 0;
					if (!ListView_GetItem(GetDlgItem(hwnd,IDC_RESULTS), &lvi) && !lvi.lParam)
					{
					//	msg("ListView_GetItem failed",modname);
						break;
					}
					msgInfo = (Message*)lvi.lParam;

					if (!ListView_GetItemCount(GetDlgItem(hwnd, IDC_RESULTS))) break;
					GetCursorPos(&pt);
                    hMenu = LoadMenu(hInst, MAKEINTRESOURCE(IDR_MENU));
                    hSubMenu = GetSubMenu(hMenu, 0);
                    CallService(MS_LANGPACK_TRANSLATEMENU, (WPARAM) hSubMenu, 0);
                    switch (TrackPopupMenu(hSubMenu, TPM_RETURNCMD, pt.x, pt.y, 0, hwnd, NULL)) {
                        case IDM_EXPORTTOTXT:
							export2txt(hwnd);
							break;
						case IDM_COPYTOCLIPBOARD:
						{
							// copy the msg from the database... doesnt work...
							// always gets the 1st msg from the contact
							HGLOBAL hData;
							
							DBEVENTINFO dbei = { 0 };
							int oldBlobSize , newBlobSize;

							if(!OpenClipboard(hwnd)) break;
							EmptyClipboard();
							ZeroMemory(&dbei,sizeof(dbei));
							dbei.cbSize=sizeof(dbei);
							dbei.pBlob=NULL;
							oldBlobSize=0;
							// get the msg with the correct blob size
							newBlobSize=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)msgInfo->hDbEvent,0);
							if(newBlobSize>oldBlobSize) {
								dbei.pBlob=(PBYTE)realloc(dbei.pBlob,newBlobSize);
								oldBlobSize=newBlobSize+1;
							}
							dbei.cbBlob=oldBlobSize;
							if (CallService(MS_DB_EVENT_GET,(WPARAM)msgInfo->hDbEvent,(LPARAM)&dbei)) break; 
							// make sure its actually a msg
							if (dbei.eventType == EVENTTYPE_MESSAGE)
							{
								hData=GlobalAlloc(GMEM_MOVEABLE,oldBlobSize+1);
								lstrcpy((char*)GlobalLock(hData),dbei.pBlob);
								GlobalUnlock(hData);
								SetClipboardData(CF_TEXT,hData);
								CloseClipboard();
							}
						break;
						}
                    }
                    DestroyMenu(hMenu);
					break;
				}
				case NM_DBLCLK:
				{	
					LVITEM lvi;
					LVHITTESTINFO hti;
					Message *msgInfo;
					
					hti.pt=((NMLISTVIEW*)lParam)->ptAction;
					ListView_SubItemHitTest(GetDlgItem(hwnd,IDC_RESULTS),&hti);
					lvi.mask = LVIF_PARAM;
					lvi.iItem = hti.iItem;
					lvi.lParam = 0;
					if (!ListView_GetItem(GetDlgItem(hwnd,IDC_RESULTS), &lvi) && !lvi.lParam)
					{
						msg("ListView_GetItem failed",modname);
						break;
					}
					msgInfo = (Message*)lvi.lParam;
					CallService(MS_HISTORY_SHOWCONTACTHISTORY, (WPARAM)msgInfo->hContact,0);

					break;
				}
			}
		}
	}
	return 0;
}
	
int CALLBACK SortGeneralListFunc(LPARAM lParam1,LPARAM lParam2,LPARAM lParamSort)
{
	HWND hListView = (HWND)lParamSort;
	Message *msg1 = (Message*)lParam1, *msg2 = (Message*)lParam2;
	
	char szText[64];
	char szText2[64];
	int nItem1 ;
	int nItem2 ;
	int sortBy = DBGetContactSettingByte(NULL, modname, "SortOrderColumn",COLUMN_NICK);
	LVFINDINFO lvf;
	int sortorder = DBGetContactSettingByte(NULL, modname, "SortOrder",0);

	lvf.flags = LVFI_PARAM;
    lvf.lParam = lParam1;
    nItem1 = ListView_FindItem(hListView,-1,&lvf);
    lvf.lParam = lParam2;
    nItem2 = ListView_FindItem(hListView,-1,&lvf);

	// extremely simple error checking
	// but it works :)
	if ((nItem1 == -1) || (nItem2 == -1))
	{
		return(0);
	}

	if (sortBy == COLUMN_TIME)
	{
		itoa(msg1->time, szText, 10);
		itoa(msg2->time, szText2, 10);
		return(sortorder ? strcmp(szText, szText2) : strcmp(szText2,szText));
	}
	else if (sortBy == COLUMN_NICK)
	{
		return(sortorder ? strcmp((char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)msg1->hContact,0), (char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)msg2->hContact,0)) : strcmp((char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)msg2->hContact,0), (char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)msg1->hContact,0)));
	}
	else if (sortBy == COLUMN_PROTO)
	{
		return(sortorder ? strcmp((char*)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)msg1->hContact,0), (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)msg2->hContact,0)) : strcmp((char*)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)msg2->hContact,0), (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)msg1->hContact,0)));
	}
	else if (sortBy == COLUMN_INOUT)
	{
		DBEVENTINFO dbei = { 0 };
		int io1 = 0, io2 = 0;
		ZeroMemory(&dbei,sizeof(dbei));
		dbei.cbSize=sizeof(dbei);
		dbei.pBlob=NULL;
		if (CallService(MS_DB_EVENT_GET,(WPARAM)msg1->hDbEvent,(LPARAM)&dbei)) return 0;
		(dbei.flags & DBEF_SENT)? strcpy(szText, "Out"):strcpy(szText, "In");
		ZeroMemory(&dbei,sizeof(dbei));
		dbei.cbSize=sizeof(dbei);
		dbei.pBlob=NULL;
		if (CallService(MS_DB_EVENT_GET,(WPARAM)msg2->hDbEvent,(LPARAM)&dbei)) return 0;
		(dbei.flags & DBEF_SENT)? strcpy(szText2, "Out"):strcpy(szText2, "In");
		return(sortorder ? strcmp(szText, szText2) : strcmp(szText2,szText));
	}				
//	msg(szText, szText2);
	return(0);
}

static void CheckBranches(HWND hwndTree, HTREEITEM hHeading)
{
	BOOL bChecked = TRUE;
	TVITEM tvi;

	if(hHeading == 0)
		return;

	tvi.mask=TVIF_HANDLE|TVIF_STATE;
	tvi.hItem = hHeading;
	TreeView_GetItem(hwndTree,&tvi);
	if (((tvi.state&TVIS_STATEIMAGEMASK)>>12==2))
		bChecked = FALSE;
	tvi.hItem=TreeView_GetNextItem(hwndTree, hHeading, TVGN_CHILD);
	tvi.stateMask = TVIS_STATEIMAGEMASK|TVIS_SELECTED;
	while(tvi.hItem) {
		tvi.state=INDEXTOSTATEIMAGEMASK(bChecked?2:1);
		TreeView_SetItem(hwndTree,&tvi);		
		tvi.hItem=TreeView_GetNextSibling(hwndTree,tvi.hItem);
	}
}
void GroupByGroups(HWND hwnd)
{
	TVINSERTSTRUCT tvi;
	DBVARIANT dbv;
	int i=0, groupCount;
	char str[5];
	HTREEITEM groups[MAX_PROTOS], noGroup;
	HANDLE hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	char groupNames[MAX_PROTOS][64] = {0};
	char contactGroup[64];

	for (i = 0;; i++) 
	{
		itoa(i, str, 10);
		if (DBGetContactSetting(NULL, "CListGroups", str, &dbv)) break;
		strncpy(groupNames[i],&dbv.pszVal[1],strlen(&dbv.pszVal[1]));
		tvi.hParent = NULL;
		tvi.hInsertAfter = TVI_SORT;
		tvi.item.mask = TVIF_TEXT|TVIF_CHILDREN|TVIF_STATE|TVIF_PARAM;
		tvi.item.state = TVIS_BOLD;
		tvi.item.stateMask = TVIS_BOLD;
		tvi.item.pszText = groupNames[i];
		tvi.item.cChildren = 1;
		tvi.item.lParam = 0;
		groups[i] = TreeView_InsertItem(GetDlgItem(hwnd, IDC_CONTACT_TREE), &tvi);
	//	TreeView_Expand(GetDlgItem(hwnd, IDC_CONTACT_TREE),groups[1],
	}
	groupCount = i;
	// add group for no group
	tvi.hParent = NULL;
	tvi.hInsertAfter = TVI_FIRST;
	tvi.item.mask = TVIF_TEXT|TVIF_CHILDREN|TVIF_STATE|TVIF_PARAM;
	tvi.item.state = TVIS_BOLD;
	tvi.item.stateMask = TVIS_BOLD;
	tvi.item.pszText = "No Group";
	tvi.item.cChildren = 1;
	tvi.item.lParam = 0;
	noGroup = TreeView_InsertItem(GetDlgItem(hwnd, IDC_CONTACT_TREE), &tvi);
	// go through the list of contacts and add them to the correct group
	while (hContact)
	{
		const char* szProto = (const char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0); 	
		if (szProto && (CallProtoService(szProto, PS_GETCAPS, PFLAGNUM_1, 0) & PF1_IM)) // make sure the proto supports msgs
		{
			tvi.hParent = NULL;
			for (i=0; i<groupCount; i++)
			{
				if (DBGetContactSetting(hContact, "CList", "Group", &dbv)) tvi.hParent = noGroup;
				else 
				{
					strncpy(contactGroup, dbv.pszVal, 64);
					if (!strcmp(contactGroup, groupNames[i])) 
					{
						tvi.hParent = groups[i];
						break;
					}
				}
			}
			tvi.hInsertAfter = TVI_LAST;
			tvi.item.mask = TVIF_TEXT|TVIF_PARAM;
			tvi.item.lParam = (LPARAM)hContact;
			tvi.item.pszText = (char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0);
			TreeView_InsertItem(GetDlgItem(hwnd, IDC_CONTACT_TREE), &tvi);
		}
		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)(HANDLE)hContact, 0);
	}
	// remove any groups that are empty
	for (i = 0;i<=MAX_PROTOS; i++) 
	{
		if (!TreeView_GetChild(GetDlgItem(hwnd, IDC_CONTACT_TREE),groups[i]))
			TreeView_DeleteItem(GetDlgItem(hwnd, IDC_CONTACT_TREE),groups[i]);
	}
}
void GroupByProto(HWND hwnd)
{
	TVINSERTSTRUCT tvi;
	int i=0;
	HTREEITEM groups[MAX_PROTOS];
	HANDLE hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	char groupNames[MAX_PROTOS][64] = {0};

	tvi.hParent = NULL;
	tvi.hInsertAfter = TVI_ROOT;
	tvi.item.mask = TVIF_TEXT|TVIF_CHILDREN|TVIF_STATE|TVIF_PARAM;
	tvi.item.state = TVIS_BOLD;
	tvi.item.stateMask = TVIS_BOLD;
	tvi.item.cChildren = 1;
	tvi.item.lParam = 0;
	
	// go through the list of contacts and add them to the correct group
	while (hContact)
	{
		const char* szProto = (const char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0); 	
		if (szProto && (CallProtoService(szProto, PS_GETCAPS, PFLAGNUM_1, 0) & PF1_IM)) // make sure the proto supports msgs
		{
			for (i=0; i<MAX_PROTOS; i++)
			{
				if (!strcmp(szProto, groupNames[i]))
				{
					tvi.hParent = groups[i];
					break;
				}
				else if (groupNames[i][0] == '\0')
				{
					tvi.hParent = NULL;
					tvi.hInsertAfter = TVI_ROOT;
					tvi.item.mask = TVIF_TEXT|TVIF_CHILDREN|TVIF_STATE|TVIF_PARAM;
					tvi.item.state = TVIS_BOLD;
					tvi.item.stateMask = TVIS_BOLD;
					tvi.item.cChildren = 1;
					tvi.item.lParam = 0;
					tvi.item.pszText  = (char*)szProto;
					strcpy(groupNames[i], szProto);
					groups[i] = TreeView_InsertItem(GetDlgItem(hwnd, IDC_CONTACT_TREE), &tvi);
					tvi.hParent = groups[i];
					break;
				}
			}
			tvi.hInsertAfter = TVI_LAST;
			tvi.item.mask = TVIF_TEXT|TVIF_PARAM;
			tvi.item.lParam = (LPARAM)hContact;
			tvi.item.pszText = (char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,0);
			TreeView_InsertItem(GetDlgItem(hwnd, IDC_CONTACT_TREE), &tvi);
		}
		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)(HANDLE)hContact, 0);
	}
	// remove any groups that are empty
	for (i = 0;i<=MAX_PROTOS; i++) 
	{
		if (!TreeView_GetChild(GetDlgItem(hwnd, IDC_CONTACT_TREE),groups[i]))
			TreeView_DeleteItem(GetDlgItem(hwnd, IDC_CONTACT_TREE),groups[i]);
	}
}

void UnixTimeToSystemTime(time_t unixtime, SYSTEMTIME* systemtime)
{
	FILETIME filetime; 
	LONGLONG longlong = Int32x32To64(unixtime, 10000000) + 116444736000000000; 
	filetime.dwLowDateTime = (DWORD) longlong; 
	filetime.dwHighDateTime = longlong >> 32; // ignore the warnign here
	FileTimeToSystemTime(&filetime, systemtime); 
}

BOOL CALLBACK AdvancedSettingsDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg) {
		case WM_INITDIALOG:
		{
			char tmp[32];
			SYSTEMTIME st;
			int time;
			// hide search window...
//			ShowWindow(GetParent(hwnd), SW_HIDE);
			// time dates
			time = DBGetContactSettingDword(NULL, modname, "SearchOptionStartTime",0);
			if (time)
			{
				CheckDlgButton(hwnd, IDC_FROM_CHECK, 1);
				EnableWindow(GetDlgItem(hwnd, IDC_FROMTIME), 1);

				DateTime_SetFormat(GetDlgItem(hwnd, IDC_FROMTIME), "dd' 'MMM' 'yyyy'    'hh':'mm tt");

				UnixTimeToSystemTime(time, &st);
				DateTime_SetSystemtime(GetDlgItem(hwnd, IDC_FROMTIME),GDT_VALID,&st);
			}
			else 
			{
				EnableWindow(GetDlgItem(hwnd, IDC_FROMTIME), 0);
			}

			time = DBGetContactSettingDword(NULL, modname, "SearchOptionEndTime",0);
			if (time)
			{
				CheckDlgButton(hwnd, IDC_UNTIL_CHECK, 1);
				EnableWindow(GetDlgItem(hwnd, IDC_UNTILTIME), 1);

				DateTime_SetFormat(GetDlgItem(hwnd, IDC_UNTILTIME), "dd' 'MMM' 'yyyy'    'hh':'mm tt");

				UnixTimeToSystemTime(time, &st);
				DateTime_SetSystemtime(GetDlgItem(hwnd, IDC_UNTILTIME),GDT_VALID,&st);
			}
			else 
			{
				EnableWindow(GetDlgItem(hwnd, IDC_UNTILTIME), 0);
			}
			

			// in/out combo
			SendMessage(GetDlgItem(hwnd,IDC_COMBO_INOUT),CB_ADDSTRING,0, (LPARAM)"All messages");
			SendMessage(GetDlgItem(hwnd,IDC_COMBO_INOUT),CB_ADDSTRING,0, (LPARAM)"Only Incoming messages");
			SendMessage(GetDlgItem(hwnd,IDC_COMBO_INOUT),CB_ADDSTRING,0, (LPARAM)"Only Outgoing messages");
			SendMessage(GetDlgItem(hwnd,IDC_COMBO_INOUT),CB_SETCURSEL,DBGetContactSettingByte(NULL, modname, "SearchOptionInOut",0),0);
			
			// case sensitive and max results
			SetDlgItemText(hwnd,IDC_MAX_RESULTS, itoa(DBGetContactSettingByte(NULL, modname, "SearchOptionMaxResults",0), tmp, 10));
			CheckDlgButton(hwnd, IDC_CASESENSITIVE, DBGetContactSettingByte(NULL, modname, "SearchOptionCaseSensitive",0));
			SetWindowLong(GetDlgItem(hwnd,IDC_CONTACT_TREE),GWL_STYLE,GetWindowLong(GetDlgItem(hwnd,IDC_CONTACT_TREE),GWL_STYLE)|TVS_NOHSCROLL|TVS_CHECKBOXES);
			// groups list
			
			if (DBGetContactSettingByte(NULL, modname, "SearchAllContacts",1))
			{
				CheckDlgButton(hwnd, IDC_ALL_CONTACTS, 1);
				EnableWindow(GetDlgItem(hwnd, IDC_CONTACT_TREE), 0);
				EnableWindow(GetDlgItem(hwnd, IDC_STATIC_SORTBY), 0);
				EnableWindow(GetDlgItem(hwnd, IDC_SORTBY_COMBO), 0);
			}

			SendMessage(GetDlgItem(hwnd,IDC_SORTBY_COMBO),CB_ADDSTRING,0, (LPARAM)"Protocol");
			SendMessage(GetDlgItem(hwnd,IDC_SORTBY_COMBO),CB_ADDSTRING,0, (LPARAM)"CList Groups");
			SendMessage(GetDlgItem(hwnd,IDC_SORTBY_COMBO),CB_SETCURSEL,DBGetContactSettingByte(NULL, modname, "SearchOptionSortBy",0),0);
			
			if (!DBGetContactSettingByte(NULL, modname, "SearchOptionSortBy",0))
				GroupByGroups(hwnd);
			else GroupByProto(hwnd);
			return TRUE;
		}
		case WM_COMMAND:
			switch(LOWORD(wParam)) {
			case IDC_FROM_CHECK:
				EnableWindow(GetDlgItem(hwnd, IDC_FROMTIME), IsDlgButtonChecked(hwnd, IDC_FROM_CHECK));
			break;
			case IDC_UNTIL_CHECK:
				EnableWindow(GetDlgItem(hwnd, IDC_UNTILDATE), IsDlgButtonChecked(hwnd, IDC_UNTIL_CHECK));
			break;

			case IDC_ALL_CONTACTS:
				if (IsDlgButtonChecked(hwnd, IDC_ALL_CONTACTS))
				{
					EnableWindow(GetDlgItem(hwnd, IDC_CONTACT_TREE), 0);
					EnableWindow(GetDlgItem(hwnd, IDC_STATIC_SORTBY), 0);
					EnableWindow(GetDlgItem(hwnd, IDC_SORTBY_COMBO), 0);
				}
				else
				{
					EnableWindow(GetDlgItem(hwnd, IDC_CONTACT_TREE), 1);
					EnableWindow(GetDlgItem(hwnd, IDC_STATIC_SORTBY), 1);
					EnableWindow(GetDlgItem(hwnd, IDC_SORTBY_COMBO), 1);
				}
			break;
			case IDC_SORTBY_COMBO:
				if (HIWORD(wParam) == CBN_SELCHANGE)
				{
					int index = SendMessage(GetDlgItem(hwnd,IDC_SORTBY_COMBO),CB_GETCURSEL,0,0);
					TreeView_DeleteAllItems(GetDlgItem(hwnd, IDC_CONTACT_TREE));
					if (!index) GroupByGroups(hwnd);
					else GroupByProto(hwnd);
				}
			break;
			case IDOK:
			{
				SYSTEMTIME s1;
				struct tm t1;
				DBWriteContactSettingByte(NULL, modname, "SearchOptionInOut", (BYTE)SendMessage(GetDlgItem(hwnd,IDC_COMBO_INOUT),CB_GETCURSEL,0, 0));
				DBWriteContactSettingByte(NULL, modname, "SearchOptionCaseSensitive", (BYTE)IsDlgButtonChecked(hwnd, IDC_CASESENSITIVE));
				if (!GetWindowTextLength(GetDlgItem(hwnd, IDC_MAX_RESULTS)))
					DBWriteContactSettingByte(NULL, modname, "SearchOptionMaxResults", 0);
				else 
				{
					char tmp[6];
					GetDlgItemText(hwnd, IDC_MAX_RESULTS, tmp, sizeof(tmp));
					DBWriteContactSettingByte(NULL, modname, "SearchOptionMaxResults", (BYTE)atoi(tmp));
				}
				if (IsDlgButtonChecked(hwnd, IDC_FROM_CHECK))
				{
					DateTime_GetSystemtime(GetDlgItem(hwnd, IDC_FROMTIME), &s1);
					t1.tm_mday = s1.wDay;
					t1.tm_mon = (s1.wMonth - 1);
					t1.tm_year = (s1.wYear - 1900);					
					t1.tm_hour = s1.wHour;
					t1.tm_min = s1.wMinute;
					t1.tm_sec = s1.wSecond;
					DBWriteContactSettingDword(NULL, modname, "SearchOptionStartTime", (DWORD)mktime(&t1));
				}
				else DBWriteContactSettingDword(NULL, modname, "SearchOptionStartTime",0);
				
				if (IsDlgButtonChecked(hwnd, IDC_UNTIL_CHECK))
				{
					DateTime_GetSystemtime(GetDlgItem(hwnd, IDC_UNTILTIME), &s1);
					t1.tm_mday = s1.wDay;
					t1.tm_mon = (s1.wMonth - 1);
					t1.tm_year = (s1.wYear - 1900);
					t1.tm_hour = s1.wHour;
					t1.tm_min = s1.wMinute;
					t1.tm_sec = s1.wSecond;
					DBWriteContactSettingDword(NULL, modname, "SearchOptionEndTime", (DWORD)mktime(&t1));
				}
				else DBWriteContactSettingDword(NULL, modname, "SearchOptionEndTime",0);
				// set checked contacts to be searched...
				if (IsDlgButtonChecked(hwnd, IDC_ALL_CONTACTS))
					DBWriteContactSettingByte(NULL, modname, "SearchAllContacts", 1);
				else
/* the following code to go through the whole tree is nicked from codeguru.. 
http://www.codeguru.com/Cpp/controls/treeview/treetraversal/comments.php/c683/?thread=7680 */
				{
					TVITEM item;
					HWND m_hwnd = GetDlgItem(hwnd, IDC_CONTACT_TREE);
					HTREEITEM lastItem;
					item.mask = TVIF_STATE|TVIF_PARAM;
					item.hItem = TVI_ROOT;
					do 
					{
						do 
						{
							lastItem = item.hItem;
							if (lastItem != TVI_ROOT) 
							{
								TreeView_GetItem( m_hwnd, &item );
		/* these next 3 lines are not from code guru..... */
								((item.state&TVIS_STATEIMAGEMASK)>>12==1)?
									DBWriteContactSettingByte((HANDLE)item.lParam, modname, "SearchContact", 0):
									DBWriteContactSettingByte((HANDLE)item.lParam, modname, "SearchContact", 1);
								
							}
						} while ( (item.hItem = TreeView_GetChild( m_hwnd, lastItem )) );
					while ( (! (item.hItem = TreeView_GetNextSibling( m_hwnd, lastItem ))) && (lastItem = item.hItem = TreeView_GetParent( m_hwnd, lastItem )) ) {}

					} while ( item.hItem );
					DBWriteContactSettingByte(NULL, modname, "SearchAllContacts", 0);
				}
/*****************************************************************************/
				DBWriteContactSettingByte(NULL, modname, "SearchOptionSortBy",(BYTE)SendMessage(GetDlgItem(hwnd,IDC_SORTBY_COMBO),CB_GETCURSEL,0,0));
			}// fall through
			case IDCANCEL:
				// hide search window...
//				ShowWindow(GetParent(hwnd), SW_SHOW);
				DestroyWindow(hwnd);
			break;
			

			}
		break;
		case WM_NOTIFY:
		{
			switch(((LPNMHDR)lParam)->idFrom) 
			{
				case IDC_CONTACT_TREE:
					if(((LPNMHDR)lParam)->code==NM_CLICK) 
					{
						TVHITTESTINFO hti;
						hti.pt.x=(short)LOWORD(GetMessagePos());
						hti.pt.y=(short)HIWORD(GetMessagePos());
						ScreenToClient(((LPNMHDR)lParam)->hwndFrom,&hti.pt);
						
						if(TreeView_HitTest(((LPNMHDR)lParam)->hwndFrom,&hti))
						{
							if(hti.flags&TVHT_ONITEMSTATEICON) 
							{
								TVITEM tvi = {0};
								tvi.mask=TVIF_HANDLE|TVIF_STATE;
								tvi.hItem=hti.hItem;
								TreeView_GetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
								CheckBranches(GetDlgItem(hwnd, IDC_CONTACT_TREE),tvi.hItem);
							}
						}
					}
				break;
			}
		}
		break;
	}
	return 0;
}