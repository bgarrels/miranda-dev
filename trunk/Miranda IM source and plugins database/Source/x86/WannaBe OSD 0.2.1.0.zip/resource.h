//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by wbOSD.rc
//
#define IDD_DIALOG1                     101
#define IDC_BUTTON1                     1001
#define IDC_BUTTON2                     1002
#define IDC_BUTTON3                     1003
#define IDC_BUTTON6                     1004
#define IDC_BUTTON4                     1008
#define IDC_EDIT1                       1009
#define IDC_CHECK1                      1010
#define IDC_CHECK3                      1013
#define IDC_EDIT4                       1015
#define IDC_EDIT5                       1016
#define IDC_CHECK4                      1017
#define IDC_TREE1                       1018
#define IDC_CHECK5                      1019
#define IDC_CHECK6                      1020
#define IDC_BUTTON5                     1021
#define IDC_CHECK7                      1022
#define IDC_CHECK8                      1023
#define IDC_CHECK2                      1023
#define IDC_SLIDER1                     1024
#define IDC_ALPHATXT                    1025
#define IDC_EDIT2                       1027
#define IDC_BUTTON7                     1028
#define IDC_TREE2                       1029
#define IDC_RADIO1                      1101
#define IDC_RADIO2                      1102
#define IDC_RADIO3                      1103
#define IDC_RADIO4                      1104
#define IDC_RADIO5                      1105
#define IDC_RADIO6                      1106
#define IDC_RADIO7                      1107
#define IDC_RADIO8                      1108
#define IDC_RADIO9                      1109
#define IDC_RADIO10                     1120
#define IDC_RADIO11                     1121
#define IDC_RADIO12                     1122
#define IDC_RADIO13                     1123
#define IDC_RADIO14                     1124
#define IDC_RADIO15                     1125
#define IDC_RADIO16                     1126
#define IDC_RADIO17                     1127
#define IDC_RADIO18                     1128

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
