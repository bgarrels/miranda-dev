/*

Facebook plugin for Miranda Instant Messenger
_____________________________________________

Copyright � 2009 Michal Zelinka

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

File name      : $URL: https://eternityplugins.googlecode.com/svn/trunk/facebook/constants.h $
Revision       : $Revision: 58 $
Last change by : $Author: n3weRm0re.ewer $
Last change on : $Date: 2009-10-10 16:33:05 +0200 (Sat, 10 Oct 2009) $

*/

#pragma once

// Version management
#include "build.h"
#define __VERSION_DWORD             PLUGIN_MAKE_VERSION(0, 0, 0, 6)
#define __PRODUCT_DWORD             PLUGIN_MAKE_VERSION(0, 8, 0, 34)
#define __VERSION_STRING            "0.0.0.6"
#define __PRODUCT_STRING            "0.8.0.34"
#define __VERSION_VS_FILE           0,0,0,6
#define __VERSION_VS_PROD           0,8,0,34
#define __VERSION_VS_FILE_STRING    "0, 0, 0, 6"
#define __VERSION_VS_PROD_STRING    "0, 8, 0, 34"
#define __API_VERSION_STRING        "1.2"

// API versions
// 1.2 -- buddy_list updates allow non-cumulative update data
// 1.1 -- buddy_list now includes some reduntant data
// 1.0 -- initial implementation

// Product management
#define FACEBOOK_NAME               "Facebook"
#define FACEBOOK_URL_HOMEPAGE       "http://www.facebook.com/"

// Connection
#define FACEBOOK_SERVER_REGULAR     "http://www.facebook.com/"
#define FACEBOOK_SERVER_MOBILE      "http://m.facebook.com/"
#define FACEBOOK_SERVER_CHAT        "http://%s.channel%s.facebook.com/"
#define FACEBOOK_SERVER_LOGIN       "https://login.facebook.com/"
#define FACEBOOK_SERVER_APPS        "http://apps.facebook.com/"
#define PLUGIN_HOSTING_URL          "http://code.google.com/p/eternityplugins/"

// Limits
#define FACEBOOK_MESSAGE_LIMIT      1024
#define FACEBOOK_MESSAGE_LIMIT_TEXT "1024"
#define FACEBOOK_MIND_LIMIT         420
#define FACEBOOK_MIND_LIMIT_TEXT    "420"
#define FACEBOOK_TIMEOUTS_LIMIT     2
#define FACEBOOK_GROUP_NAME_LIMIT   100

// Defaults
#define FACEBOOK_MINIMAL_POLL_RATE              10
#define FACEBOOK_DEFAULT_POLL_RATE              24 // in seconds
#define FACEBOOK_MAXIMAL_POLL_RATE              60

#define FACEBOOK_DEFAULT_AVATAR_URL "http://static.ak.fbcdn.net/pics/q_silhouette.gif"

// Facebook request types // TODO: Provide MS_ and release in FB plugin API?
#define FACEBOOK_REQUEST_LOGIN                  100 // connecting physically
#define FACEBOOK_REQUEST_LOGOUT                 101 // disconnecting physically
#define FACEBOOK_REQUEST_KEEP_ALIVE             102 // keeping online status alive without idle
#define FACEBOOK_REQUEST_HOME                   110 // getting __post_form_id__ + __fb_dtsg__ + ...
#define FACEBOOK_REQUEST_BUDDY_LIST             120 // getting regular updates (friends online, ...)
#define FACEBOOK_REQUEST_RECONNECT              130 // getting __sequence_num__ and __channel_id__
#define FACEBOOK_REQUEST_PROFILE_GET            200 // getting others' profiles
#define FACEBOOK_REQUEST_STATUS_SET             251 // setting my "What's on my mind?"
#define FACEBOOK_REQUEST_MESSAGE_SEND           300 // sending message
#define FACEBOOK_REQUEST_MESSAGES_RECEIVE       301 // receiving messages
#define FACEBOOK_REQUEST_NOTIFICATIONS_RECEIVE  401 // receiving notifications

// Reconnect flags
#define FACEBOOK_RECONNECT_LOGIN        "6" // When logging in
#define FACEBOOK_RECONNECT_KEEP_ALIVE   "3" // After a period, used to keep session alive

// User-Agents
static char* user_agents[] = {
	"Miranda IM (default)",
	"FacebookTouch2.5",
	"Facebook/2.5 CFNetwork/342.1 Darwin/9.4.1",
	"Lynx/2.8.4rel.1 libwww-FM/2.14",
	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322)",
	"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)",
	"Mozilla/4.08 [en] (WinNT; U ;Nav)",
	"Mozilla/5.0 (compatible; Konqueror/3.5; Linux 2.6.21-rc1; x86_64; cs, en_US) KHTML/3.5.6 (like Gecko)",
	"Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.8.1.9) Gecko/20071025 Firefox/2.0.0.9",
	"Opera/8.01 (J2ME/MIDP; Opera Mini/3.0.6306/1528; nb; U; ssr)",
	"Opera/9.27 (Windows NT 5.1; U; en)",
	"Opera/9.64 (Windows NT 5.1; U; en)",
	"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.2.15 Version/10.00",
	"Opera/9.80 (Macintosh; Intel Mac OS X; U; en) Presto/2.2.15 Version/10.00",
	"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7; en-US) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/3.0.183 Safari/531.0",
	"Mozilla/5.0 (iPod; U; CPU iPhone OS 2_2_1 like Mac OS X; en-us) AppleWebKit/525.18.1 (KHTML, like Gecko) Version/3.1.1 Mobile/5H11a Safari/525.20",
	"HTC-8900/1.2 Mozilla/4.0 (compatible; MSIE 6.0; Windows CE; IEMobile 7.6) UP.Link/6.3.0.0.0",
	"BlackBerry8320/4.3.1 Profile/MIDP-2.0 Configuration/CLDC-1.1",
	"Opera/9.60 (J2ME/MIDP; Opera Mini/4.2.13337/504; U; en) Presto/2.2.0",
	"Nokia6230/2.0+(04.43)+Profile/MIDP-2.0+Configuration/CLDC-1.1+UP.Link/6.3.0.0.0",
	"Mozilla/5.0 (webOS/1.0; U; en-US) AppleWebKit/525.27.1 (KHTML, like Gecko) Version/1.0 Safari/525.27.1 Pre/1.0",
};
