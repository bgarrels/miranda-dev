Send/Recieve Advanced Messaging Module with Msg Saving for Miranda IM 0.3.3
Based on cvs source (13.01.2004)
Build #2 (18.01.2004) // 0.3.2.2


Features
--------
 * ability to save unsent msgs
 * slightly improved msg windows
 * char counter moved to 'Send' button


Instalation
-----------

 Copy sramm.dll into Miranda plugins folder.
 Restart Miranda and select it in appeared windows.


Using
-----

 To save typed msg press 'Save'.

 Or just close window if you checked 'Save on Close'
 in Options - Events - Messaging - Message Windows



Enjoy! 8-)



BRg,
Bio


mailto: bio(at)msx(dot)ru
