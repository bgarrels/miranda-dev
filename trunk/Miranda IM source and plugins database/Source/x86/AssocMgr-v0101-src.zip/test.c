/*

'File Association Manager'-Plugin for Miranda IM

Copyright (C) 2005-2007 H. Herkenrath

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (AssocMgr-License.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// -- Includes
#include "common.h"
#include <m_protosvc.h>
#include <m_addcontact.h>
#include <m_message.h>
#include <m_icq.h>

extern HINSTANCE hInst;
// -----------------------------------------

// Implemented in aim.dll
#define AIM_PROTO "AIM"
//#define IDI_AIM 201 // TOC/TOC2
#define IDI_AIM 1000 // Oscar
int aim_util_isme(char *nick) { nick; return 0; }
HANDLE aim_buddy_get(char *nick, int create, int inlist, int noadd, char *group) { nick; create; inlist; noadd; group; return INVALID_HANDLE_VALUE; }
void aim_gchat_joinrequest(char *room, int exchange) { room; exchange; return; }

static int ServiceParseAimLink(WPARAM wParam, LPARAM lParam)
{
	// Does not yet support Unicode (instead of char* use TCHAR*)
	// taken out from aim.dll

    char *s;
	wParam; // unreferenced
    s = (char*)lParam;
	if (!_strnicmp(s, "addbuddy?", 9)) { // group is currently ignored
		char *tok, *sn = NULL, *group = NULL;
		ADDCONTACTSTRUCT acs;
		PROTOSEARCHRESULT psr;
		
		s += 9;
		if (!(*s)) return 1;
		tok = strtok(s, "&");
        while (tok != NULL) {
            if (!_strnicmp(tok, "screenname=", 11)) {
                sn = tok+11;
            }
            if (!_strnicmp(tok, "groupname=", 10)) {
                group = tok+10;
            }
            tok = strtok(NULL, "&");
        }
		if (sn&&strlen(sn)&&!aim_util_isme(sn)&&!aim_buddy_get(sn,0,0,0,NULL)) {
			acs.handleType=HANDLE_SEARCHRESULT;
			acs.szProto=AIM_PROTO;
			acs.psr=&psr;
			ZeroMemory(&psr, sizeof(PROTOSEARCHRESULT));
			psr.cbSize=sizeof(PROTOSEARCHRESULT);
			psr.nick=sn;
			CallService(MS_ADDCONTACT_SHOW,(WPARAM)NULL,(LPARAM)&acs);
		}
	}
    else if (!_strnicmp(s, "goim?", 5)) {
        char *tok, *sn = NULL, *msg = NULL;

        s += 5;
        if (!(*s)) return 1;
        tok = strtok(s, "&");
        while (tok != NULL) {
            if (!_strnicmp(tok, "screenname=", 11)) {
                sn = tok+11;
            }
            if (!_strnicmp(tok, "message=", 8)) {
                msg = tok+8;
            }
            tok = strtok(NULL, "&");
        }
        if (sn && ServiceExists(MS_MSG_SENDMESSAGE)) {
            HANDLE hContact = aim_buddy_get(sn, 1, 0, 0, NULL);
            if (hContact)
                CallService(MS_MSG_SENDMESSAGE, (WPARAM)hContact, (LPARAM)msg);
        }
    }
    else if (!_strnicmp(s, "gochat?", 7)) {
        char *tok, *rm = NULL, *ex;
        int exchange = 0;

        s += 7;
        if (!(*s)) return 1;
        tok = strtok(s, "&");
        while (tok != NULL) {
            if (!_strnicmp(tok, "roomname=", 9)) {
                rm = tok+9;
            }
            if (!_strnicmp(tok, "exchange=", 9)) {
                ex = tok+9;
                exchange = atoi(ex);
            }
            tok = strtok(NULL, "&");
        }
        if (rm && exchange > 0) {
            aim_gchat_joinrequest(rm, exchange);
        }
    }
    return 0;
}

#define IDI_ICQ 101
typedef struct {
	int cbSize;
	char uin[64];
	BOOL bMessage;
} ICQFILEINFO;

int GetIcqInfo(char *szBuf, ICQFILEINFO *ifi)
{
/*
// send a message content
[ICQ Message User]
UIN=6124334
// add a user content
[ICQ User]
UIN=6124334
Email=
NickName=
FirstName=
LastName=
*/
	/* why not use strtok? */
	char *p,*v;
	p=strchr(szBuf,10);
	while (p != NULL) {
		*p=0;
		/* got the line, look for the = */
		v=strchr(szBuf,'=');
		if (v) {
			/* everything before 'v' is the name in szBuf, v++ is the value */
			*v=0;
			v++;
			if (szBuf && *v != 0) {
				/* all the .icq files I've seen only have UIN= in them */
				if (!strcmp(szBuf,"UIN")) {
					strncpy(ifi->uin,v,sizeof(ifi->uin));
					return 1;
				} //if
			} //if
		} //if
		szBuf=++p;
		p=strchr(szBuf,10);
	} //while
	return 0;
}

static int ServiceOpenIcqFile(WPARAM wParam, LPARAM lParam)
{
	int res = 1;
	FILE *fp;	
	wParam; // unreferenced
	fp=fopen((char*)lParam,"r");
	if (fp) {
		char szBuf[0x1000];
		memset(&szBuf,0,sizeof(szBuf));			
		if (fread(&szBuf,1,sizeof(szBuf),fp)) {
			ICQFILEINFO ifi;
			memset(&ifi,0,sizeof(ICQFILEINFO));
			ifi.cbSize=sizeof(ICQFILEINFO);
			if (GetIcqInfo(szBuf,&ifi)) {
				ADDCONTACTSTRUCT acs;
				PROTOSEARCHRESULT psr;
				res = 0;
				acs.handleType=HANDLE_SEARCHRESULT;
				acs.szProto="ICQ";
				acs.psr=&psr;
				ZeroMemory(&psr, sizeof(PROTOSEARCHRESULT));
				psr.cbSize=sizeof(PROTOSEARCHRESULT);
				psr.nick=ifi.uin;
				CallService(MS_ADDCONTACT_SHOW,(WPARAM)NULL,(LPARAM)&acs);
			} //if
		} //if
		fclose(fp);
	} //if
	return res;
}


static int TestingService(WPARAM wParam, LPARAM lParam)
{
	wParam; // unreferenced
	MessageBoxEx(NULL,(TCHAR*)lParam,_T("Testing Service"),MB_OK|MB_SETFOREGROUND|MB_TOPMOST|MB_TASKMODAL,LANGIDFROMLCID((LCID)CallService(MS_LANGPACK_GETLOCALE,0,0)));
	return 0;
}


// --------------------------------

void InitTest(void)
{
	CreateServiceFunction("AssocMgr/TestingService",TestingService);
	AssocMgr_AddNewUrlTypeT("testurl:",TranslateT("Miranda Test Protocol"),NULL,0,"AssocMgr/TestingService",0);

	CreateServiceFunction("AssocMgr/ParseAimLink",ServiceParseAimLink);
	AssocMgr_AddNewUrlTypeT("aim:",TranslateT("AOL Instant Messenger Links (demo purpose)"),GetModuleHandleA("aim.dll"),0,"AssocMgr/TestingService",0);

	CreateServiceFunction("AssocMgr/OpenIcqFile",ServiceOpenIcqFile);
	AssocMgr_AddNewFileTypeT(".icq","application/x-icq",TranslateT("ICQ Link File (demo purpose)"),TranslateT("&Add to Contact List..."),GetModuleHandleA("icq.dll"),IDI_ICQ,"AssocMgr/TestingService",FTDF_BROWSERAUTOOPEN);
	AssocMgr_AddNewFileTypeT(".test",NULL,TranslateT("Miranda Test File"),NULL,hInst,IDI_MIRANDAFILE,"AssocMgr/TestingService",0);
	AssocMgr_AddNewFileTypeT(".dat",NULL,TranslateT("Miranda IM Database (not recommended)"),NULL,hInst,IDI_MIRANDAFILE,NULL,FTDF_DEFAULTDISABLED);
	AssocMgr_AddNewFileTypeT(".mir",NULL,TranslateT("Miranda Installer Package (demo purpose)"),TranslateT("&Install"),hInst,IDI_MIRANDAFILE,"AssocMgr/TestingService",0);
}


void UninitTest(void)
{
}
