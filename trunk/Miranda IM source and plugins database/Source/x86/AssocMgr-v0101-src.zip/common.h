/*

'File Association Manager'-Plugin for Miranda IM

Copyright (C) 2005-2007 H. Herkenrath

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (AssocMgr-License.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#define _WIN32_WINNT 0x0600
#define __RPCASYNC_H__         /* VC6 has a mistake in there (warning) */
#include <windows.h>
#pragma warning(disable:4201)  /* nonstandard extension used : nameless struct/union */
#pragma warning(disable:4115)  /* V6 has a mistake in there */
#include <shlobj.h>            /* for SHChangeNotify() */
#pragma warning(default:4115)
#include <commctrl.h>
#pragma warning(default:4201)
#include <tchar.h>
#include <win2k.h>
#include <stdio.h>             /* for mir_snprintf() */

#ifndef HWND_MESSAGE
   #define HWND_MESSAGE ((HWND)-3)
#endif

#ifndef FTA_AlwaysUnsafe
   #define FTA_Show         0x00000002
   #define FTA_AlwaysUnsafe 0x00020000
   #define FTA_HasExtension 0x00000004
   #define FTA_OpenIsSafe   0x00010000
#endif

#ifndef LVM_ENABLEGROUPVIEW
	typedef struct tagLVGROUP
	{
		UINT    cbSize;
		UINT    mask;
		LPWSTR  pszHeader;
		int     cchHeader;

		LPWSTR  pszFooter;
		int     cchFooter;

		int     iGroupId;

		UINT    stateMask;
		UINT    state;
		UINT    uAlign;
	#if _WIN32_WINNT >= 0x0600
		LPWSTR  pszSubtitle;
		UINT    cchSubtitle;
		LPWSTR  pszTask;
		UINT    cchTask;
		LPWSTR  pszDescriptionTop;
		UINT    cchDescriptionTop;
		LPWSTR  pszDescriptionBottom;
		UINT    cchDescriptionBottom;
		int     iTitleImage;
		int     iExtendedImage;
		int     iFirstItem;         // Read only
		UINT    cItems;             // Read only
		LPWSTR  pszSubsetTitle;     // NULL if group is not subset
		UINT    cchSubsetTitle;
	#endif
	} LVGROUP, *PLVGROUP;

	#define LVGF_GROUPID 0x00000010
	#define LVGF_HEADER 0x00000001

	#define LVIF_GROUPID            0x0100
	#define LVM_ENABLEGROUPVIEW     (LVM_FIRST + 157)
	#define LVM_HASGROUP            (LVM_FIRST + 161)
	#define LVM_INSERTGROUP         (LVM_FIRST + 145)
	#define LVM_ISGROUPVIEWENABLED  (LVM_FIRST + 175)
	#define LVM_MOVEGROUP           (LVM_FIRST + 151) 
	#define ListView_EnableGroupView(hwnd, fEnable) \
	   SNDMSG((hwnd), LVM_ENABLEGROUPVIEW, (WPARAM)fEnable, 0)
	#define ListView_IsGroupViewEnabled(hwnd) \
	   (BOOL)SNDMSG((hwnd), LVM_ISGROUPVIEWENABLED, 0, 0)
	#define ListView_InsertGroup(hwnd, index, pgrp) \
	   SNDMSG((hwnd), LVM_INSERTGROUP, (WPARAM)index, (LPARAM)pgrp)
	#define ListView_HasGroup(hwnd, dwGroupId) \
	   SNDMSG((hwnd), LVM_HASGROUP, dwGroupId, 0)
	#define ListView_MoveGroup(hwnd, iGroupId, toIndex) \
	   SNDMSG((hwnd), LVM_MOVEGROUP, (WPARAM)iGroupId, (LPARAM)toIndex)

#endif

#ifndef ListView_SetCheckState 
	#define ListView_GetCheckState(hwndLV, i) \
	   ((((UINT)(SNDMSG((hwndLV), LVM_GETITEMSTATE, (WPARAM)i, LVIS_STATEIMAGEMASK))) >> 12) -1)
	#define ListView_SetCheckState(h, i, f) \
	   ListView_SetItemState(h, i, INDEXTOSTATEIMAGEMASK((f) + 1), LVIS_STATEIMAGEMASK) 
#endif

	#undef LVITEM
	#undef LPLVITEM
	#define LVITEM    LVITEM2
	#define LPLVITEM  LPLVITEM2
	typedef struct _LVITEM2 { 
		UINT mask; 
		int iItem; 
		int iSubItem; 
		UINT state; 
		UINT stateMask; 
		LPTSTR pszText; 
		int cchTextMax; 
		int iImage; 
		LPARAM lParam;
	#if (_WIN32_IE >= 0x0300)
		int iIndent;
	#endif
	#if (_WIN32_WINNT >= 0x560)
		int iGroupId;
		UINT cColumns; // tile view columns
		PUINT puColumns;
	#endif
	#if (_WIN32_WINNT >= 0x0600)
		int* piColFmt;
		int iGroup;
	#endif
	} LVITEM2, *LPLVITEM2; 


#define MIRANDA_VER  0x0700
#include <newpluginapi.h>
#include <m_system.h>
#include <m_database.h>
#include <m_utils.h>
#include <m_langpack.h>
#include <m_plugins.h>
#include <m_options.h>
#include <m_skin.h>
#include <m_clist.h>

#include "m_assocmgr.h"
#include "utils.h"
#include "reg.h"
#include "assoclist.h"
#include "dde.h"
#include "test.h"
#include "resource.h"
