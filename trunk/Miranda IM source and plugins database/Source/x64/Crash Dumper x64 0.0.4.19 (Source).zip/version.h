#define __FILEVERSION_STRING        0,0,4,19
#define __VERSION_STRING            "0.0.4.19"
#define __VERSION_DWORD             PLUGIN_MAKE_VERSION(0, 0, 4, 19)
