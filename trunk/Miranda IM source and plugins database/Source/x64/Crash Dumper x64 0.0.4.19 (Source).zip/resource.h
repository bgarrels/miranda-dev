//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by crshdmp.rc
//
#define IDD_VIEWVERSION                 101
#define IDR_CONTEXT                     102
#define IDI_VI                          104
#define IDI_VISHOW                      105
#define IDI_VITOCLIP                    106
#define IDI_VITOFILE                    107
#define IDI_VIUPLOAD                    108
#define IDD_OPTIONS                     109
#define IDC_VIEWVERSIONINFO             1001
#define IDC_FILEVER                     1003
#define IDC_CLIPVER                     1004
#define IDC_USERNAME                    1006
#define IDC_PASSWORD                    1007
#define IDC_UPLOADCHN                   1008
#define IDC_CLASSICDATES                1009
#define IDM_COPY                        40002
#define IDM_COPYALL                     40003
#define IDM_SELECTALL                   40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
