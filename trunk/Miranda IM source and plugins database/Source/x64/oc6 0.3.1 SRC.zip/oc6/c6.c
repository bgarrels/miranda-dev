/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * Note :
 *  This project is built on ICQOscarJ skeleton
 *  Documentation C6 Protocol at http://openc6.extracon.it
 *  Thanks also OpenC6 project at http://openc6.sourceforge.net
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

#ifndef strlwr
#define strlwr _strlwr
#endif

HINSTANCE hInst;

PLUGINLINK *pluginLink;

struct MM_INTERFACE mmi;
struct UTF8_INTERFACE utfi;
//struct LIST_INTERFACE li;

HANDLE hNetlibUser = NULL;
HANDLE hDirectNetlibUser = NULL; // P2P

HANDLE hHookUserInfoInit = NULL;

// Menu Item
HANDLE hSCLMenuItem = NULL;
HANDLE hLCLMenuItem = NULL;
HANDLE hSecrMenuItem = NULL;
HANDLE hWSMenuItem = NULL;
HANDLE hWDMenuItem = NULL;
HANDLE hDingMenuItem = NULL;
HANDLE hOLMsgMenuItem = NULL;
HANDLE hStatMsgMenuItem = NULL;
#ifdef _C6_ROOM
HANDLE hGCMenuItem = NULL;
HANDLE hRCMenuItem = NULL;
#endif

// Icon
HICON hIconSCL;
HICON hIconLCL;
HICON hIconSecr;
HICON hIconWS;
HICON hIconWD;
HICON hIconDing;
HICON hIconStatMsg;
#ifdef _C6_ROOM
HICON hIconGC;
HICON hIconNewGC;
#endif

#ifdef _C6_ROOM
extern BOOL bGroupChat;
#endif

extern BOOL bSecretariat;

#ifdef _C6_FULL

HANDLE hIcoLibChanged = NULL;

HANDLE hHookExtraIconsRebuild = NULL;
HANDLE hHookExtraIconsApply = NULL;

BYTE gbAvatarsEnabled;

#ifndef _C6_FINGERPRINT
#define NUMHICONS 6

HICON hIconClient[NUMHICONS];

HANDLE hExtraImage[NUMHICONS];
#endif

#endif // _C6_FULL

int c6Status = ID_STATUS_OFFLINE;

BOOL gbUnicodeCore;

extern HANDLE hServerConn;

#ifdef _C6_ROOM

static COLORREF crCols[16] = {0x00000000, 0x00FF0000, 0x0000FF00, 0x000000FF, 0x00FFFF00, 0x0000FFFF, 0x00FF00FF, 0x00C00000,
                              0x0000C000, 0x000000C0, 0x00C0C000, 0x0000C0C0, 0x00C000C0, 0x00C0C0C0, 0x004080FF, 0x00A4A0A0};

HANDLE hChatEvent = NULL, hChatMenu = NULL, hChatWnd = NULL;

#endif

static int OnSystemPreShutdown(WPARAM wParam, LPARAM lParam);

PLUGININFOEX pluginInfo = {
  	sizeof(PLUGININFOEX),
  	"C6 Protocol",
  	PLUGIN_MAKE_VERSION(0,3,1,0),
	"Atlantide/C6 Protocol for Miranda IM",
	"MG Lena",
	"r3vindt(AT)altervista(DOT)org",
	"GPL 2004-2011 MGL",
	"http://r3vindt.altervista.org",
	0,		//not transient
	0,		//doesn't replace anything built-in
  	{0x7e580452, 0xc7c2, 0x4aa6, { 0xa0, 0xc6, 0xa2, 0x7c, 0x89, 0x7a, 0x1a, 0xcc }} // {7E580452-C7C2-4AA6-A0C6-A27C897A1ACC}
};

#pragma argsused
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{

  	if (fdwReason == DLL_PROCESS_ATTACH)
 		hInst = hinstDLL;

  	return TRUE;
}

#ifdef _C6_FULL
#ifndef _C6_FINGERPRINT

//--------------------------------------------------------------------
//                    CListMW_ExtraIconsRebuild
//--------------------------------------------------------------------

int CListMW_ExtraIconsRebuild(WPARAM wParam, LPARAM lParam)
{

	int i;
	if(ServiceExists(MS_CLIST_EXTRA_ADD_ICON)) {
		for(i = 0; i < NUMHICONS; i++) {
			hExtraImage[i] = (HANDLE)CallService(MS_CLIST_EXTRA_ADD_ICON, (WPARAM)hIconClient[i],0);
		}
	}

	return 0;
}

//--------------------------------------------------------------------
//                     CListMW_ExtraIconsApply
//--------------------------------------------------------------------

int CListMW_ExtraIconsApply(WPARAM wParam, LPARAM lParam)
{

	if(ServiceExists(MS_CLIST_EXTRA_SET_ICON)) {
		BYTE IDClient = DBGetContactSettingByte((HANDLE)wParam, C6PROTOCOLNAME, "IDClientMod", 0);
		if(IDClient > 0 && IDClientToPosImg(IDClient)>=0) {
			IconExtraColumn iec;
			iec.cbSize = sizeof(iec);
			iec.hImage = hExtraImage[IDClientToPosImg(IDClient)];
			iec.ColumnType = 7; //EXTRA_ICON_ADV1;
			CallService(MS_CLIST_EXTRA_SET_ICON, (WPARAM)wParam, (LPARAM)&iec);
		} else {
			IconExtraColumn iec;
			iec.cbSize = sizeof(iec);
			iec.hImage = (HANDLE)-1;
			iec.ColumnType = 7; //EXTRA_ICON_ADV1;
			CallService(MS_CLIST_EXTRA_SET_ICON, (WPARAM)wParam, (LPARAM)&iec);
		}
	}
	return 0;
}
#endif // _C6_FINGERPRINT

#endif // _C6_FULL

//--------------------------------------------------------------------
//                       AddToListMenuCommand
//--------------------------------------------------------------------

static int AddToListMenuCommand(WPARAM wParam, LPARAM lParam)
{

	return addToListDlgInit();

}

//--------------------------------------------------------------------
//                         SecretariatCommand
//--------------------------------------------------------------------

static int SecretariatCommand(WPARAM wParam, LPARAM lParam)
{

	return secretariatDlgInit(TRUE);

}

//--------------------------------------------------------------------
//                            SavefileCL
//--------------------------------------------------------------------

int SavefileCL(char *outputFile)
{

	char *szFilter;
	char *title = Translate("Save on file");
 	OPENFILENAME ofn;
 	char szFile[MAX_PATH] = "";

 	szFile[0] = '\0';

	szFilter=(char *)mir_alloc(MAX_PATH);
	_snprintf(szFilter, MAX_PATH - 1, "%s\0*.*\0", Translate("All Files"));
 	ZeroMemory(&ofn, sizeof(ofn));
 	ofn.lStructSize = sizeof(OPENFILENAME);
 	ofn.lpstrFilter = szFilter;
 	ofn.lpstrFile= szFile;
 	ofn.nMaxFile = MAX_PATH;
 	ofn.lpstrTitle = title;

 	if (GetSaveFileName((LPOPENFILENAME)&ofn)) {
		lstrcpy(outputFile,szFile);
		mir_free(szFilter);
		return 1;
  	}
	mir_free(szFilter);
 	return 0;

}

//--------------------------------------------------------------------
//                           SaveCLMenuCommand
//--------------------------------------------------------------------

static int SaveCLMenuCommand(WPARAM wParam,LPARAM lParam)
{

    FILE *f;
	char szFile[MAX_PATH];

	// open dialog
	if (SavefileCL(szFile)) {

 		// write file
 		if ((f = fopen(szFile, "wt")) == NULL)
    		return 0;

		HANDLE hContact;
		char* szProto;
		char szNick[40]; // 20
		DBVARIANT dbv;

 		// search nick in contact list
		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
		while (hContact != NULL) {

			szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

			if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
				if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {
	        		if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {

						_snprintf(szNick, 40, "%s\n", dbv.pszVal); // 20
						fwrite(szNick,strlen(szNick),1,f);

						DBFreeVariant(&dbv);
				}
			}

			hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
		}

		fclose(f);
		MessageBox(GetFocus(), Translate("Save C6 Contacts"), "Miranda IM", MB_ICONINFORMATION);

	}

	return 0;

}

//--------------------------------------------------------------------
//                            OpenfileCL
//--------------------------------------------------------------------

int OpenfileCL(char * outputFile)
{

	char *szFilter;
 	char *title = Translate("Load from file");
 	OPENFILENAME ofn;
 	char szFile[MAX_PATH] = "";

 	szFile[0] = '\0';

	szFilter=(char *)mir_alloc(MAX_PATH);
	_snprintf(szFilter, MAX_PATH - 1, "%s\0*.*\0", Translate("All Files"));
 	ZeroMemory(&ofn, sizeof(ofn));
 	ofn.lStructSize = sizeof(OPENFILENAME);
 	ofn.lpstrFilter = szFilter;
 	ofn.lpstrFile= szFile;
 	ofn.nMaxFile = MAX_PATH;
 	ofn.lpstrTitle = title;

 	if (GetOpenFileName((LPOPENFILENAME)&ofn)) {
		lstrcpy(outputFile,szFile);
		mir_free(szFilter);
	return 1;
  	}
	mir_free(szFilter);
	return 0;

}

//--------------------------------------------------------------------
//                            fscanfln
//--------------------------------------------------------------------

int fscanfln(FILE *f, int size, char *s)
{
	char c;
	int n = 0;

	do {
		if (fread(&c, sizeof(char), 1, f) != 1) c = '\n';
		s[n] = c;
		n++;
	} while(c != '\n' && n < size);

	s[n-1] = '\0';

	return n;
}

//--------------------------------------------------------------------
//                              LoadLNF
//--------------------------------------------------------------------

int LoadLNF(FILE *f)
{

	char szNick[40]; // 20
	char *p;

	while (!feof(f)) {

		fscanfln(f, 40, szNick);
		p = strtok(szNick, "=");
		if (p) {

			if (strlen(p)==3) { // only 3 chars = 00n
				p = strtok(NULL, "\0");
				if (p) {
					if (strlen(p))
						AddToListDirect(0, p, "");
				}

			}
		}
	}

	return 0;

}
//--------------------------------------------------------------------
//                           LoadCLMenuCommand
//--------------------------------------------------------------------

static int LoadCLMenuCommand(WPARAM wParam,LPARAM lParam)
{

    FILE *f;
	char szFile[MAX_PATH], szNick[40]; // 20

	if (OpenfileCL(szFile)) {

 		// read file
 		if ((f = fopen(szFile, "rt")) == NULL)
    		return 0;

		// control file type
		fscanfln(f, 40, szNick);
		if (!strcmp(szNick, "[Buddys]"))

			LoadLNF(f); // file LNF of C6 Msg

		else {

			fseek(f, 0, SEEK_SET); // repositioning file poiter to begin

			while (!feof(f)) {

				fscanfln(f, 40, szNick);

				if (strlen(szNick))
	    			AddToListDirect(0, szNick, "");
			}
		}

		fclose(f);
		MessageBox(GetFocus(), Translate("Load C6 Contacts"), "Miranda IM", MB_ICONINFORMATION);

	}

	return 0;

}

#ifdef _C6_FULL

//--------------------------------------------------------------------
//                            InitIcoLib
//--------------------------------------------------------------------

static void InitIcoLib(void)
{

	SKINICONDESC sid={0};
    char szFilename[MAX_PATH];
	char szModule[128];

    GetModuleFileName(hInst, szFilename, MAX_PATH);

    sid.cbSize = sizeof(SKINICONDESC);
    sid.pszSection = C6PROTOCOLNAME; //"C6";
    sid.pszDefaultFile = szFilename;

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "SCL");
    sid.pszName = szModule;
    sid.pszDescription = Translate("Save Contact List");
    sid.iDefaultIndex = -IDI_SCL;
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "LCL");
    sid.pszName = szModule;
    sid.pszDescription = Translate("Load Contact List");
    sid.iDefaultIndex = -IDI_LCL;
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "Segr");
    sid.pszName = szModule;
    sid.pszDescription = Translate("Secretariat");
    sid.iDefaultIndex = -IDI_SECR;
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "WS");
    sid.pszName = szModule;
    sid.pszDescription = Translate("Web Search");
    sid.iDefaultIndex = -IDI_WS;
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "GC");
    sid.pszName = szModule;
    sid.pszDescription = Translate("Group Chat");
    sid.iDefaultIndex = -IDI_GC;
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "NEWGC");
    sid.pszName = szModule;
    sid.pszDescription = Translate("New Room");
    sid.iDefaultIndex = -IDI_NEWGC;
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "StatMsg");
    sid.pszName = szModule;
    sid.pszDescription = Translate("Status Message");
    sid.iDefaultIndex = -IDI_STATMSG;
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "WD");
    sid.pszName = szModule;
	sid.pszDescription = Translate("Web Details");
	sid.iDefaultIndex = -IDI_WD;
	CallService(MS_SKIN2_ADDICON, 0, (LPARAM)&sid);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "DING");
    sid.pszName = szModule;
	sid.pszDescription = Translate("Ding");
	sid.iDefaultIndex = -IDI_DING;
	CallService(MS_SKIN2_ADDICON, 0, (LPARAM)&sid);

	_snprintf(szModule, 128, "eventicon_%s%d", C6PROTOCOLNAME, C6_DB_EVENT_TYPE_CHATSTATES); // eventicon_%s%d
    sid.pszName = szModule;
	sid.pszDescription = Translate("Chat Invite Event");
	sid.iDefaultIndex = -IDI_GC;
	CallService(MS_SKIN2_ADDICON, 0, (LPARAM)&sid);

#ifndef _C6_FINGERPRINT

	char szClient[128];

	_snprintf(szModule, 128, "%s/%s", C6PROTOCOLNAME, Translate("Client Icons"));
	sid.pszSection = szModule;

	sid.iDefaultIndex = -IDI_CL_OPENC6;
	_snprintf(szClient, 128, "%s_CL_%s", C6PROTOCOLNAME, "OPENC6");
    sid.pszName = szClient;
    sid.pszDescription = "OpenC6";
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	sid.iDefaultIndex = -IDI_CL_CM4X;
	_snprintf(szClient, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM4X");
    sid.pszName = szClient;
    sid.pszDescription = "C6 Msg 4.x";
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	sid.iDefaultIndex = -IDI_CL_CM50;
	_snprintf(szClient, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM50");
    sid.pszName = szClient;
    sid.pszDescription = "C6 Msg 5.x";
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	sid.iDefaultIndex = -IDI_CL_CM60;
	_snprintf(szClient, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM60");
    sid.pszName = szClient;
    sid.pszDescription = "C6 Msg 6.x"; // 6.0
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	sid.iDefaultIndex = -IDI_CL_CM70;
	_snprintf(szClient, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM70");
    sid.pszName = szClient;
    sid.pszDescription = "C6 Msg 7.x"; // 7.0
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

	sid.iDefaultIndex = -IDI_CL_CMJAVA;
	_snprintf(szClient, 128, "%s_CL_%s", C6PROTOCOLNAME, "CMJAVA");
    sid.pszName = szClient;
    sid.pszDescription = "JavaApplet";
    CallService(MS_SKIN2_ADDICON, 0, (LPARAM) &sid);

#endif

}

//--------------------------------------------------------------------
//                          IcoLibReloadIcons
//--------------------------------------------------------------------

void IcoLibReloadIcons(void)
{

	char szModule[128];

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "SCL");
    hIconSCL = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "LCL");
    hIconLCL = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "Segr");
    hIconSecr = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "WS");
    hIconWS = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "WD");
    hIconWD = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "DING");
    hIconDing = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "StatMsg");
    hIconStatMsg = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);

#ifdef _C6_ROOM

	if (bGroupChat){

		_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "GC");
		hIconGC = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
		_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "NEWGC");
		hIconNewGC = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);

	}

#endif

#ifndef _C6_FINGERPRINT

	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "OPENC6");
	hIconClient[0] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM4X");
	hIconClient[1] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM50");
	hIconClient[2] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM60");
	hIconClient[3] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CMJAVA");
	hIconClient[4] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM70");
	hIconClient[5] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);

#endif

#ifdef _C6_FULL

#ifndef _C6_FINGERPRINT

	CListMW_ExtraIconsRebuild(0,0);

	HANDLE hContact;
	char *szProto;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);

	while (hContact)
	{
		szProto = (char *)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);
		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))

			if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {

				CListMW_ExtraIconsApply((WPARAM)hContact,0);

		}
		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}
#endif

#endif // _C6_FULL

	CLISTMENUITEM clmi;

	memset( &clmi, 0, sizeof( clmi ));
	clmi.cbSize = sizeof( clmi );

	clmi.hIcon = hIconSCL;
	clmi.flags = CMIM_ICON;
	CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hSCLMenuItem,(LPARAM)&clmi);

	clmi.hIcon = hIconLCL;
	clmi.flags = CMIM_ICON;
	CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hLCLMenuItem,(LPARAM)&clmi);

	clmi.hIcon = hIconSecr;
	clmi.flags = CMIM_ICON;
	CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hSecrMenuItem,(LPARAM)&clmi);

	clmi.hIcon = hIconWS;
	clmi.flags = CMIM_ICON;
	CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hWSMenuItem,(LPARAM)&clmi);

	clmi.hIcon = hIconStatMsg;
	clmi.flags = CMIM_ICON;
	CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hStatMsgMenuItem,(LPARAM)&clmi);

#ifdef _C6_ROOM
	if (bGroupChat){
		clmi.hIcon = hIconGC;
		clmi.flags = CMIM_ICON;
		CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hGCMenuItem,(LPARAM)&clmi);
		clmi.hIcon = hIconNewGC;
		clmi.flags = CMIM_ICON;
		CallService(MS_CLIST_MODIFYMENUITEM,(WPARAM)hRCMenuItem,(LPARAM)&clmi);
	}
#endif

}

//--------------------------------------------------------------------
//                            IcoLibChanged
//--------------------------------------------------------------------

static int IcoLibChanged(WPARAM wParam, LPARAM lParam)
{
    IcoLibReloadIcons();
    return 0;
}

#endif // _C6_FULL

//--------------------------------------------------------------------
//                            IconsInit
//--------------------------------------------------------------------

void IconsInit(void)
{

	char szModule[128];

#ifdef _C6_FULL

	InitIcoLib();
    hIcoLibChanged = HookEvent(ME_SKIN2_ICONSCHANGED, IcoLibChanged);

	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "SCL");
   	hIconSCL = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "LCL");
   	hIconLCL = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "Segr");
   	hIconSecr = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "WS");
   	hIconWS = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "WD");
   	hIconWD = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "DING");
   	hIconDing = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "StatMsg");
    hIconStatMsg = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);

#ifdef _C6_ROOM

	if (bGroupChat){

		_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "GC");
		hIconGC = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
		_snprintf(szModule, 128, "%s_%s", C6PROTOCOLNAME, "NEWGC");
		hIconNewGC = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);

	}
#endif

#ifndef _C6_FINGERPRINT

	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "OPENC6");
	hIconClient[0] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM4X");
	hIconClient[1] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM50");
	hIconClient[2] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM60");
	hIconClient[3] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CMJAVA");
	hIconClient[4] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	_snprintf(szModule, 128, "%s_CL_%s", C6PROTOCOLNAME, "CM70");
	hIconClient[5] = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
#endif


#endif // _C6_FULL

}

//--------------------------------------------------------------------
//                            DetailPlusMenu
//--------------------------------------------------------------------

// MenuItem callback function
int DetailPlusMenu(WPARAM wParam, LPARAM lParam)
{

    char szUrl[MAX_PATH];
    HANDLE hContact = (HANDLE)wParam;
    DBVARIANT dbv;

	if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
		_snprintf(szUrl, MAX_PATH - 1, "http://people.virgilio.it/profilo/%s?pmk=c6", dbv.pszVal);

		CallService(MS_UTILS_OPENURL, 1,( LPARAM )szUrl);

		DBFreeVariant(&dbv);
    }
	return 0;
}

//--------------------------------------------------------------------
//                            WebSearchMenu
//--------------------------------------------------------------------

int WebSearchMenu(WPARAM wParam, LPARAM lParam)
{

    char szUrl[MAX_PATH];

	_snprintf(szUrl, MAX_PATH - 1, "http://search.virgiliopeople.virgilio.it/avanzata");

	CallService(MS_UTILS_OPENURL, 1,( LPARAM )szUrl);

	return 0;
}

#ifdef _C6_ROOM

//--------------------------------------------------------------------
//                            MultiChatMenu
//--------------------------------------------------------------------

int MultiChatMenu(WPARAM wParam, LPARAM lParam)
{

	roomListDlgInit();

	if (amIOnline())
		roomListDlgRefresh();

	return 0;
}

//--------------------------------------------------------------------
//                            RoomCreateMenu
//--------------------------------------------------------------------

int RoomCreateMenu(WPARAM wParam, LPARAM lParam)
{

	if (amIOnline())

		createRoomDlgInit();

	return 0;
}

#endif

//--------------------------------------------------------------------
//                              DingMenu
//--------------------------------------------------------------------

int DingMenu(WPARAM wParam, LPARAM lParam)
{

	char srvcfunction[128];
	CCSDATA ccs;

	ccs.hContact = (HANDLE)wParam;
	ccs.szProtoService = PSS_MESSAGE;
	ccs.wParam = 0;
	ccs.lParam = (LPARAM)mir_strdup("<ding>");

	strcpy(srvcfunction, C6PROTOCOLNAME);
	strcat(srvcfunction, PSS_MESSAGE);
	CallService(srvcfunction, 0, (LPARAM)&ccs);

	return 0;
}

//--------------------------------------------------------------------
//                          ReadMessageMenu
//--------------------------------------------------------------------

int ReadMessageMenu(WPARAM wParam, LPARAM lParam)
{

	return getOnlineMessage((HANDLE)wParam);

}

//--------------------------------------------------------------------
//                       AddToContactMenuItem
//--------------------------------------------------------------------

// Add DetailPlus & Ding menu items in contact menu
void AddToContactMenuItem(void) {

	CLISTMENUITEM mi={0};
	char szModule[128];

	_snprintf(szModule, 128, "%s/ReadMsgMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)ReadMessageMenu);
	mi.cbSize = sizeof(mi);
	mi.pszName = Translate("Read Online Message");
	mi.pszService = szModule;
	mi.position = 1000000;
	mi.hIcon = hIconStatMsg;
	mi.pszContactOwner = C6PROTOCOLNAME;
	mi.flags = CMIF_NOTOFFLINE;
	hOLMsgMenuItem = (void *)CallService(MS_CLIST_ADDCONTACTMENUITEM, 0, (LPARAM)&mi);

	_snprintf(szModule, 128, "%s/VPMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)DetailPlusMenu);
	mi.position = 1000010;
	mi.hIcon = hIconWD;
	mi.pszName = Translate("View Profile");
	mi.pszService = szModule;
	mi.flags = 0;

	hWDMenuItem = (void *)CallService(MS_CLIST_ADDCONTACTMENUITEM, 0, (LPARAM)&mi);

	_snprintf(szModule, 128, "%s/DingMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)DingMenu);
	mi.pszName = Translate("Ding");
	mi.pszService = szModule;
	mi.position = 1000020;
	mi.hIcon = hIconDing;
	mi.flags = CMIF_NOTOFFLINE;
	hDingMenuItem = (void *)CallService(MS_CLIST_ADDCONTACTMENUITEM, 0, (LPARAM)&mi);

}

//--------------------------------------------------------------------
//                        SetCustomStatusMenu
//--------------------------------------------------------------------

int SetCustomStatusMenu(WPARAM wParam, LPARAM lParam)
{

	setStatusMessage();
	return 0;

}

//--------------------------------------------------------------------
//                            C6MainMenu
//--------------------------------------------------------------------

void C6MainMenu(void)
{
	CLISTMENUITEM mi;
	char szModule[128];

	ZeroMemory(&mi,sizeof(mi));
	mi.cbSize=sizeof(mi);
	mi.popupPosition=200010000;
	mi.pszPopupName=C6PROTOCOLNAME;
//	mi.pszPopupName="C6 "; // at least 3 characters !!!

	_snprintf(szModule, 128, "%s/A2CLMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)AddToListMenuCommand);
	mi.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_C6));
	mi.pszName = Translate("Add Contact");
	mi.pszService = szModule;
	mi.position = 200010000;
	CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);

	_snprintf(szModule, 128, "%s/SCLMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)SaveCLMenuCommand);
	mi.position = 200010005;
	mi.hIcon = hIconSCL;
	mi.pszName = Translate("Save Contact List");
	mi.pszService = szModule;
	hSCLMenuItem = (void *)CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);

	_snprintf(szModule, 128, "%s/LCLMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)LoadCLMenuCommand);
	mi.position = 200010010;
	mi.hIcon = hIconLCL;
	mi.pszName = Translate("Load Contact List");
	mi.pszService = szModule;
	hLCLMenuItem = (void *)CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);

	_snprintf(szModule, 128, "%s/SMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)SecretariatCommand);
	mi.position = 200110000; // After a separator + 100000
	mi.hIcon = hIconSecr;
	mi.pszName = Translate("Secretariat");
	mi.pszService = szModule;
	hSecrMenuItem = (void *)CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);

	_snprintf(szModule, 128, "%s/WSMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)WebSearchMenu);
	mi.position = 200210000; // After a separator + 100000
	mi.hIcon = hIconWS;
	mi.pszName = Translate("Web Search");
	mi.pszService = szModule;
	hWSMenuItem = (void *)CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);

#ifdef _C6_ROOM

	if (bGroupChat) {

		_snprintf(szModule, 128, "%s/RLMenuCommand", C6PROTOCOLNAME);
	    CreateServiceFunction(szModule, (MIRANDASERVICE)MultiChatMenu);
		mi.position = 200310000; // After a separator + 100000
		mi.hIcon = hIconGC;
		mi.pszName = Translate("Group Chat");
		mi.pszService = szModule;
		hGCMenuItem = (void *)CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);

		_snprintf(szModule, 128, "%s/RCMenuCommand", C6PROTOCOLNAME);
		CreateServiceFunction(szModule, (MIRANDASERVICE)RoomCreateMenu);
		mi.position = 200310005; // After a separator + 100000
		mi.hIcon = hIconNewGC;
		mi.pszName = Translate("New Room");
		mi.pszService = szModule;
//		mi.flags = CMIF_NOTOFFLINE;
		hRCMenuItem = (void *)CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);

	}

#endif

	_snprintf(szModule, 128, "%s/CSMenuCommand", C6PROTOCOLNAME);
	CreateServiceFunction(szModule, (MIRANDASERVICE)SetCustomStatusMenu);
	mi.position = 200410000; // After a separator + 100000
	mi.hIcon = hIconStatMsg;
	mi.pszName = Translate("Set Status Message");
	mi.pszService = szModule;
//	mi.flags = CMIF_NOTOFFLINE;
	hStatMsgMenuItem = (void *)CallService(MS_CLIST_ADDMAINMENUITEM, 0, (LPARAM)&mi);

}

//--------------------------------------------------------------------
//                         MirandaPluginInfo
//--------------------------------------------------------------------

PLUGININFOEX __declspec(dllexport) *MirandaPluginInfoEx(DWORD mirandaVersion)
{
	if (mirandaVersion < PLUGIN_MAKE_VERSION(0, 8, 2, 1)) {
		MessageBox( NULL, "The OC6 protocol plugin cannot be loaded. It requires Miranda IM 0.8.2.1 or later.", "C6 Protocol Plugin",
		MB_OK|MB_ICONWARNING|MB_SETFOREGROUND|MB_TOPMOST );
    	return NULL;
  	}
  	return &pluginInfo;
}

static const MUUID interfaces[] = {MIID_PROTOCOL, MIID_LAST};
__declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

//--------------------------------------------------------------------
//                            UpdateSupport
//--------------------------------------------------------------------

static char *CreateVersionStringPluginEx(PLUGININFOEX *pluginInfo, char *buf) {
	return CreateVersionString(pluginInfo->version, buf);
}

void UpdateSupport(void)
{

    if (ServiceExists(MS_UPDATE_REGISTER)) {
    // updater plugin support
    	static char szCurrentVersion[30];
    	static char *szVersionUrl = "http://r3vindt.altervista.org/c6_version.txt";
#ifdef _C6_FULL

#ifdef _C6_X64
    	static char *szUpdateUrl = "http://r3vindt.altervista.org/oc6_test_x64.zip";
#else
    	static char *szUpdateUrl = "http://r3vindt.altervista.org/oc6_test.zip";
#endif

#else

#ifdef _C6_X64
		static char *szUpdateUrl = "http://r3vindt.altervista.org/oc6lt_test_x64.zip";
#else
    	static char *szUpdateUrl = "http://r3vindt.altervista.org/oc6lt_test.zip";
#endif

#endif
    	static char *szFLVersionUrl = "http://addons.miranda-im.org/details.php?action=viewfile&id=2450";
    	static char *szFLUpdateurl = "http://addons.miranda-im.org/feed.php?dlfile=2450";
    	static char *szPrefix = "oc6 ";

    	static Update upd = {0};

    	upd.cbSize = sizeof(upd);
    	upd.szComponentName = pluginInfo.shortName;
    	upd.pbVersion = (BYTE *)CreateVersionStringPluginEx(&pluginInfo, szCurrentVersion);
    	upd.cpbVersion = strlen((char *)upd.pbVersion);
    	upd.szVersionURL = szFLVersionUrl;
    	upd.szUpdateURL = szFLUpdateurl;
    	upd.pbVersionPrefix = (BYTE *)"<span class=\"fileNameHeader\">C6 Protocol ";

    	upd.szBetaUpdateURL = szUpdateUrl;
    	upd.szBetaVersionURL = szVersionUrl;
    	upd.pbBetaVersionPrefix = (BYTE *)szPrefix;
    	upd.pbVersion = (BYTE *)szCurrentVersion;
    	upd.cpbVersion = strlen(szCurrentVersion);

    	upd.cpbVersionPrefix = strlen((char *)upd.pbVersionPrefix);
    	upd.cpbBetaVersionPrefix = strlen((char *)upd.pbBetaVersionPrefix);

   		CallService(MS_UPDATE_REGISTER, 0, (LPARAM)&upd);
	}

}

//--------------------------------------------------------------------
//                        OnPreBuildContactMenu
//--------------------------------------------------------------------

void CListShowMenuItem(HANDLE hMenuItem, BYTE bShow, int dwExtra)
{
	CLISTMENUITEM mi = {0};

	mi.cbSize = sizeof(mi);
	if (bShow)
		mi.flags = CMIM_FLAGS | dwExtra;
	else
		mi.flags = CMIM_FLAGS | CMIF_HIDDEN;

	CallService(MS_CLIST_MODIFYMENUITEM, (WPARAM)hMenuItem, (LPARAM)&mi);
}

int OnPreBuildContactMenu(WPARAM wParam, LPARAM lParam)
{

	char *szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)(HANDLE)wParam, 0);
	if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME)) {
		BOOL bChatRoom = (DBGetContactSettingByte((HANDLE)wParam, C6PROTOCOLNAME, "ChatRoom", 0) == 1);

		CListShowMenuItem(hOLMsgMenuItem, !bChatRoom, CMIF_NOTOFFLINE);
		CListShowMenuItem(hWDMenuItem, !bChatRoom, 0);
		CListShowMenuItem(hDingMenuItem, !bChatRoom, CMIF_NOTOFFLINE);
		c6LogMsg("OnPreBuildContactMenu (%d)", bChatRoom);
	}

	return 0;
}

//--------------------------------------------------------------------
//                        OnSystemModulesLoaded
//--------------------------------------------------------------------

static int OnSystemModulesLoaded(WPARAM wParam,LPARAM lParam)
{
    NETLIBUSER nlu = {0};
	char pszP2PName[MAX_PATH+3];
	char szModule[MAX_PATH+3];

	strcpy(pszP2PName, C6PROTOCOLNAME);

	nlu.cbSize = sizeof(nlu);
	nlu.flags = NUF_OUTGOING | NUF_HTTPCONNS; // added for xcap: NUF_HTTPCONNS
	_snprintf(szModule, MAX_PATH, "%s %s", C6PROTOCOLNAME, Translate("server connection"));
	nlu.szDescriptiveName =	szModule;
	nlu.szSettingsModule = pszP2PName;
	hNetlibUser = ( HANDLE )CallService( MS_NETLIB_REGISTERUSER, 0, (LPARAM)&nlu );

	strcpy(pszP2PName, C6PROTOCOLNAME);

	nlu.cbSize = sizeof(nlu);

	strcat(pszP2PName,"P2P");

	nlu.flags = NUF_OUTGOING | NUF_INCOMING;
	_snprintf(szModule, MAX_PATH, "%s %s",C6PROTOCOLNAME, Translate("client-to-client connections"));
	nlu.szDescriptiveName =	szModule;
	nlu.szSettingsModule = pszP2PName;
	nlu.minIncomingPorts = 1;
	hDirectNetlibUser = (HANDLE)CallService(MS_NETLIB_REGISTERUSER, 0, (LPARAM)&nlu );

    hHookUserInfoInit = HookEvent(ME_USERINFO_INITIALISE, OnDetailsInit);

#ifdef _C6_FULL
#ifndef _C6_FINGERPRINT
	hHookExtraIconsRebuild = HookEvent(ME_CLIST_EXTRA_LIST_REBUILD, CListMW_ExtraIconsRebuild);

	hHookExtraIconsApply = HookEvent(ME_CLIST_EXTRA_IMAGE_APPLY, CListMW_ExtraIconsApply);
#endif
#endif

#ifdef _C6_ROOM

	if ( ServiceExists( MS_GC_REGISTER )) {

		bGroupChat = TRUE;

		GCREGISTER gcr = {0};
		gcr.cbSize = sizeof( GCREGISTER );

		gcr.dwFlags = GC_CHANMGR;

		gcr.iMaxText = 0;
		gcr.nColors = 16;
		gcr.pColors = &crCols[0];
		gcr.pszModuleDispName = C6PROTOCOLNAME;
		gcr.pszModule = C6PROTOCOLNAME;
		CallService( MS_GC_REGISTER, 0, ( LPARAM )&gcr );

		hChatEvent = HookEvent( ME_GC_EVENT, c6GcEventHook );
		hChatMenu = HookEvent( ME_GC_BUILDMENU, c6GcMenuHook );
		hChatWnd = HookEvent( ME_MSG_WINDOWEVENT, c6GcWindowEvent );

	}

#endif

    // Before Menu Create !!!
    IconsInit();

    C6MainMenu();
	SecrMenuChange(bSecretariat);

	AddToContactMenuItem();

	UpdateSupport();

	InitServerLists();

#ifdef _C6_ROOM

	DBEVENTTYPEDESCR dbEventType = {0};
	dbEventType.cbSize = sizeof(DBEVENTTYPEDESCR);
	dbEventType.eventType = C6_DB_EVENT_TYPE_CHATSTATES;
	dbEventType.module = C6PROTOCOLNAME;
	dbEventType.descr = "Chat state notifications";

	CallService(MS_DB_EVENT_REGISTERTYPE, 0, (LPARAM)&dbEventType);
	CreateProtoServiceFunction(C6PROTOCOLNAME, MS_CHAT_SHOWINVITE, (MIRANDASERVICE)ShowInviteWindow);

	HookEvent(ME_DB_EVENT_ADDED, InviteEventAdded);

#endif

	return 0;
}

//--------------------------------------------------------------------
//                                 Load
//--------------------------------------------------------------------

void strlower(char *s)
{
	int i;
	for (i = 0; i < strlen(s); i++)
		s[i] = tolower(s[i]);
}

int __declspec(dllexport) Load(PLUGINLINK *link)
{
    PROTOCOLDESCRIPTOR pd;

    pluginLink = link;

	//mir_getLI( &li );
    mir_getMMI( &mmi );
    mir_getUTFI( &utfi );

    char szVer[MAX_PATH];

    CallService(MS_SYSTEM_GETVERSIONTEXT, MAX_PATH, (LPARAM)szVer);
    //strlwr(szVer); // make sure it is lowercase
	strlower(szVer);
    gbUnicodeCore = (strstr(szVer, "unicode") != NULL);

	if (!DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseDefaultLog", 0))
    	logDlgInit();

	bSecretariat = !DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "NoSecretariat", 0);
	if (bSecretariat)
		secretariatDlgInit(FALSE);

    // *** FirstRun Advise ***
	c6FirstRunCheck();

	HookEvent(ME_OPT_INITIALISE, c6OptInit);

	HookEvent(ME_SYSTEM_MODULESLOADED, OnSystemModulesLoaded);
	HookEvent(ME_SYSTEM_PRESHUTDOWN, OnSystemPreShutdown);
    HookEvent(ME_CLIST_PREBUILDCONTACTMENU, OnPreBuildContactMenu);

	InitCookies();

	// sound added
	char szName[30];
	char szSndName[40];

	strcpy(szSndName, C6PROTOCOLNAME);
	strcat(szSndName, "/Ding");

	_snprintf(szName, sizeof(szName), "%s: %s", C6PROTOCOLNAME, Translate("Ding"));
   	SkinAddNewSound(szSndName, szName, "");

	strcpy(szSndName, C6PROTOCOLNAME);
	strcat(szSndName, "/Secretariat");

	_snprintf(szName, sizeof(szName), "%s: %s", C6PROTOCOLNAME, Translate("Secretariat"));
   	SkinAddNewSound(szSndName, szName, "");

	strcpy(szSndName, C6PROTOCOLNAME);
	strcat(szSndName, "/Invitation");

	_snprintf(szName, sizeof(szName), "%s: %s", C6PROTOCOLNAME, Translate("Invitation"));
   	SkinAddNewSound(szSndName, szName, "");
	// sound.

	ZeroMemory(&pd, sizeof(pd));
	pd.cbSize = sizeof(pd);
	pd.szName = C6PROTOCOLNAME;
	pd.type = PROTOTYPE_PROTOCOL;
	CallService(MS_PROTO_REGISTERMODULE, 0, (LPARAM)&pd);

#ifdef _C6_FULL
	gbAvatarsEnabled = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "AvatarsEnabled", DEFAULT_AVATARS_ENABLED);
#endif

	//set all contacts to 'offline'
	ResetSettingsOnLoad();

	LoadC6Services();

	return 0;
}

static int OnSystemPreShutdown(WPARAM wParam, LPARAM lParam)
{ 	// all threads should be terminated here

#ifdef _C6_FULL
	// remove unused avatar
	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "AvatarsAutoClean", 0)) {
		PolishDirImage(TRUE);
	}
#endif

#ifdef _C6_ROOM
	roomListDlgDone();
#endif

	secretariatDlgDone();

	if (!DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseDefaultLog", 0))
	    logDlgDone();

  	return 0;
}

//--------------------------------------------------------------------
//                              Unload
//--------------------------------------------------------------------

int __declspec(dllexport) Unload(void)
{

	freeWhiteList();
	freeSrvGroup();

#ifdef _C6_ROOM

	if ( hChatEvent  ) UnhookEvent( hChatEvent );
	if ( hChatMenu   ) UnhookEvent( hChatMenu );
	if ( hChatWnd   ) UnhookEvent( hChatWnd );

#endif

	UninitServerLists();

    Netlib_CloseHandle( hDirectNetlibUser );
	UninitCookies();

    Netlib_CloseHandle( hNetlibUser );

	if (hHookUserInfoInit)
		UnhookEvent(hHookUserInfoInit);

#ifdef _C6_FULL

    if (hIcoLibChanged)
        UnhookEvent(hIcoLibChanged);
	if (hHookExtraIconsRebuild)
		UnhookEvent(hHookExtraIconsRebuild);
	if (hHookExtraIconsApply)
		UnhookEvent(hHookExtraIconsApply);

#endif // _C6_FULL

	return 0;

}
