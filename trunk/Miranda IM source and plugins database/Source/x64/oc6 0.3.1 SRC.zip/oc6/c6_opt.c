/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

BOOL bSecretariat;

static BOOL CALLBACK DlgProcC6Opts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
static BOOL CALLBACK DlgProcC6FeaturesOpts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
static BOOL CALLBACK DlgProcC6ContactsOpts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

static BOOL CALLBACK serverListDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

extern HINSTANCE hInst;

extern HWND hwndRaw;

extern HANDLE hSecrMenuItem;

extern BOOL noUploadXCAP;

#ifdef _C6_FULL
extern BYTE gbAvatarsEnabled;
#endif

//--------------------------------------------------------------------
//                            c6OptInit
//--------------------------------------------------------------------

int c6OptInit(WPARAM wParam,LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp;

	ZeroMemory(&odp, sizeof(odp));
	odp.cbSize      = sizeof(odp);
	odp.position    = -790000000;
	odp.hInstance   = hInst;

	odp.pszTemplate = MAKEINTRESOURCE(IDD_OPT_C6);
	odp.pszTitle    = C6PROTOCOLNAME;
	odp.pszGroup    = LPGEN("Network");
	odp.pszTab      = LPGEN("Account");
	odp.flags       = ODPF_BOLDGROUPS;
	odp.nIDBottomSimpleControl = IDC_STC6GROUP;
	odp.pfnDlgProc  = (DLGPROC)DlgProcC6Opts;
	CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);

	odp.nIDBottomSimpleControl = 0;
	odp.pszTab      = LPGEN("Features");
	odp.pszTemplate = MAKEINTRESOURCE(IDD_OPT_FEATURES);
	odp.pfnDlgProc  = (DLGPROC)DlgProcC6FeaturesOpts;
	CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);

	odp.pszTab      = LPGEN("Contacts");
	odp.pszTemplate = MAKEINTRESOURCE(IDD_OPT_C6_CONTACTS);
	odp.pfnDlgProc  = (DLGPROC)DlgProcC6ContactsOpts;
	CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);

	return 0;
}

//--------------------------------------------------------------------
//                           DlgProcC6Opts
//--------------------------------------------------------------------

static BOOL CALLBACK DlgProcC6Opts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch (msg) {

		case WM_INITDIALOG:
		{
			DBVARIANT dbv;

			TranslateDialogDefault(hwndDlg);

			if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, "LoginNickName" ,&dbv)) {
				SetDlgItemText(hwndDlg, IDC_HANDLE,dbv.pszVal);
				DBFreeVariant(&dbv);
			}
			if(!DBGetContactSetting(NULL,C6PROTOCOLNAME,"Password",&dbv)) {

				CallService(MS_DB_CRYPT_DECODESTRING, strlen(dbv.pszVal)+1, (LPARAM)dbv.pszVal);
				SetDlgItemText(hwndDlg, IDC_PASSWORD, dbv.pszVal);
				DBFreeVariant(&dbv);

			}
			if(!DBGetContactSetting(NULL,C6PROTOCOLNAME,"LoginServer",&dbv)){
				SetDlgItemText(hwndDlg, IDC_LOGINSERVER,dbv.pszVal);
				DBFreeVariant(&dbv);
			}
			else SetDlgItemText(hwndDlg,IDC_LOGINSERVER,C6_DEFAULT_LOGIN_SERVER);
			SetDlgItemInt(hwndDlg, IDC_C6PORT, DBGetContactSettingWord(NULL, C6PROTOCOLNAME, "C6Port", DEFAULT_SERVER_PORT),FALSE);


			return TRUE;
	   }
		case WM_COMMAND:
		  switch (LOWORD(wParam))
			{
				case IDC_C6ACCOUNTLINK :

					CallService(MS_UTILS_OPENURL, 1, (LPARAM)URL_REGISTER);

					return TRUE;

			}
          if (
           (LOWORD(wParam) == IDC_HANDLE || LOWORD(wParam) == IDC_PASSWORD || LOWORD(wParam) == IDC_LOGINSERVER || LOWORD(wParam) == IDC_C6PORT)
            &&
           (HIWORD(wParam) != EN_CHANGE || (HWND)lParam != GetFocus())
           ) return 0;
		  SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);

		  break;
		case WM_NOTIFY:
			switch (((LPNMHDR)lParam)->code)
			{
				case PSN_APPLY:
				{
					int reconnectRequired = 0;
					char str[128];
					char nickname[128];
					DBVARIANT dbv;

					GetDlgItemText(hwndDlg, IDC_HANDLE, nickname, sizeof(nickname));
					dbv.pszVal = NULL;
					if(DBGetContactSetting(NULL, C6PROTOCOLNAME, "LoginNickName", &dbv) || strcmp(nickname, dbv.pszVal))
						reconnectRequired = 1;
					if(dbv.pszVal != NULL) DBFreeVariant(&dbv);
					DBWriteContactSettingString(NULL, C6PROTOCOLNAME, "LoginNickName", nickname);

					GetDlgItemText(hwndDlg, IDC_PASSWORD, str, sizeof(str));
					CallService(MS_DB_CRYPT_ENCODESTRING, sizeof(str), (LPARAM)str);
					dbv.pszVal = NULL;
					if(DBGetContactSetting(NULL, C6PROTOCOLNAME, "Password", &dbv) || strcmp(str, dbv.pszVal))
						reconnectRequired = 1;
					if(dbv.pszVal != NULL) DBFreeVariant(&dbv);
					DBWriteContactSettingString(NULL, C6PROTOCOLNAME, "Password", str);

					GetDlgItemText(hwndDlg, IDC_LOGINSERVER, str, sizeof(str));
					DBWriteContactSettingString(NULL, C6PROTOCOLNAME, "LoginServer", str);

					DBWriteContactSettingWord(NULL, C6PROTOCOLNAME, "C6Port", (WORD)GetDlgItemInt(hwndDlg, IDC_C6PORT, NULL, FALSE));


					if(reconnectRequired)

						MessageBox(hwndDlg, Translate("The changes you have made require you to reconnect to the C6 Messenger network before they take effect"), "C6 Options", MB_OK);

					return TRUE;
				}
              break;
			}
	}
	return FALSE;
}

static BOOL CALLBACK DlgProcC6FeaturesOpts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch ( msg ) {

		case WM_INITDIALOG:
		TranslateDialogDefault( hwndDlg );
		{

			DBVARIANT dbv;

			BYTE byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "LastNick", 0);
			SendDlgItemMessage(hwndDlg, IDC_LASTNICK,BM_SETCHECK,(WPARAM)byValue, 0L);

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "NoSecretariat", 0);
			SendDlgItemMessage(hwndDlg, IDC_NOSECRETARIAT,BM_SETCHECK,(WPARAM)byValue, 0L);

			if (byValue)
				EnableWindow(GetDlgItem(hwndDlg, IDC_HIDESECRETARIAT), FALSE);
			else {
				byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "HideSecretariat", 0);
				SendDlgItemMessage(hwndDlg, IDC_HIDESECRETARIAT,BM_SETCHECK,(WPARAM)byValue, 0L);
			}

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "IPVisible", 0);
			SendDlgItemMessage(hwndDlg, IDC_IPVISIBLE, BM_SETCHECK, (WPARAM)byValue, 0L);

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "AdvSearchInvisible", 0);
			SendDlgItemMessage(hwndDlg, IDC_INVISADVSEARCH, BM_SETCHECK, (WPARAM)byValue, 0L);

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseBBCode", 0);
			SendDlgItemMessage(hwndDlg, IDC_MSGBBCODE, BM_SETCHECK, (WPARAM)byValue, 0L);

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", 0);
			SendDlgItemMessage(hwndDlg, IDC_C6TYPINGNOTIFY, BM_SETCHECK, (WPARAM)byValue, 0L);

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "DeepInfoDebug", 1);
			SendDlgItemMessage(hwndDlg, IDC_DEEPINFO, BM_SETCHECK,(WPARAM)byValue, 0L);

			if (ServiceExists(MS_EAX_ADDMESSAGE) || CallService(MS_POPUP_QUERY, PUQS_GETSTATUS, 0) == 1) {
				byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "ShowWelcome", 0);
				SendDlgItemMessage(hwndDlg, IDC_WELCOME, BM_SETCHECK, (WPARAM)byValue, 0L);
			}
			else EnableWindow(GetDlgItem(hwndDlg, IDC_WELCOME), FALSE);

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseDefaultLog", 0);
			SendDlgItemMessage(hwndDlg, IDC_C6DEFAULTLOG, BM_SETCHECK, (WPARAM)byValue, 0L);

			if (byValue==0)
				EnableWindow(GetDlgItem(hwndDlg, IDC_C6LOG), TRUE);

			if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, "IgnoreMsg", &dbv)) {
				SetDlgItemText(hwndDlg, IDC_IGNOREMSG, dbv.pszVal);
				DBFreeVariant(&dbv);
			}
			else SetDlgItemText(hwndDlg, IDC_IGNOREMSG, Translate(DEFAULT_IGNOREMSG));

		}
		return TRUE;

		case WM_COMMAND:
		  switch (LOWORD(wParam))
			{

				case IDC_C6LOG :

					ShowWindow(hwndRaw, SW_SHOW);

					return TRUE;

			}
		  SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);

		  break;

		case WM_NOTIFY:
			if ((((LPNMHDR)lParam)->code) == PSN_APPLY ) {

					char str[128];
					int iCheck;

					iCheck = SendDlgItemMessage(hwndDlg, IDC_LASTNICK, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "LastNick", (BYTE)iCheck);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_NOSECRETARIAT, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "NoSecretariat", (BYTE)iCheck);
					bSecretariat = !iCheck;
					if (bSecretariat)
						secretariatDlgInit(FALSE);
					else secretariatDlgDone();
					SecrMenuChange(bSecretariat);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_HIDESECRETARIAT, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "HideSecretariat", (BYTE)iCheck);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_IPVISIBLE, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "IPVisible", (BYTE)iCheck);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_INVISADVSEARCH, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "AdvSearchInvisible", (BYTE)iCheck);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_MSGBBCODE, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "UseBBCode", (BYTE)iCheck);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_C6TYPINGNOTIFY, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", (BYTE)iCheck);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_DEEPINFO, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "DeepInfoDebug", (BYTE)iCheck);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_WELCOME, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "ShowWelcome", (BYTE)iCheck);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_C6DEFAULTLOG, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "UseDefaultLog", (BYTE)iCheck);
					if (!iCheck)
						logDlgInit();
					else logDlgDone();
					EnableWindow(GetDlgItem(hwndDlg, IDC_C6LOG), !iCheck);

					GetDlgItemText(hwndDlg,IDC_IGNOREMSG, str, sizeof(str));
					DBWriteContactSettingString(NULL, C6PROTOCOLNAME, "IgnoreMsg", str);

			return TRUE;
		}
	}

	return FALSE;
}

static BOOL CALLBACK DlgProcC6ContactsOpts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch ( msg ) {

		case WM_INITDIALOG:
		TranslateDialogDefault( hwndDlg );
		{

			BYTE byValue, bUseXCAP;

			bUseXCAP = FALSE;
			if (isNewKeyLogin()) {
				bUseXCAP = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseXCAP", 0);
				SendDlgItemMessage(hwndDlg, IDC_C6USEXCAP, BM_SETCHECK, (WPARAM)bUseXCAP, 0L);
			} else {

				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "UseXCAP", 0);
				EnableWindow(GetDlgItem(hwndDlg, IDC_C6USEXCAP), FALSE);

				noUploadXCAP = TRUE;
				EnableWindow(GetDlgItem(hwndDlg, IDC_FORCEAUTH), FALSE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_SAVEXCAP), FALSE);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", (BYTE)0);
				EnableWindow(GetDlgItem(hwndDlg, IDC_SERVERCONTACTS), FALSE);
			}

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", 0);
			if (byValue)
				SendDlgItemMessage(hwndDlg, IDC_SERVERCONTACTS, BM_SETCHECK, (WPARAM)1, 0L);
			else EnableWindow(GetDlgItem(hwndDlg, IDC_FORCEAUTH), FALSE);

			if (!amIOnline() || noUploadXCAP || byValue==0) {
				//EnableWindow(GetDlgItem(hwndDlg, IDC_FORCEAUTH), FALSE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_MANAGESERVERLST), FALSE);
			}

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ForceAuthCList", 0);
			if (byValue)
				SendDlgItemMessage(hwndDlg, IDC_FORCEAUTH, BM_SETCHECK, (WPARAM)1, 0L);

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_Permission", 0);
			if (byValue==CONFIG_NOWARNING)
				SendDlgItemMessage(hwndDlg, IDC_NOPERMISSION, BM_SETCHECK, (WPARAM)1, 0L);
			else if (byValue==CONFIG_NOTIFICATION)
				SendDlgItemMessage(hwndDlg, IDC_NOTIFPERM, BM_SETCHECK, (WPARAM)1, 0L);
			else SendDlgItemMessage(hwndDlg, IDC_WARNINGPER, BM_SETCHECK, (WPARAM)1, 0L);

			if (!amIOnline() || noUploadXCAP || !bUseXCAP) {
				EnableWindow(GetDlgItem(hwndDlg, IDC_NOPERMISSION), FALSE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_WARNINGPER), FALSE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_NOTIFPERM), FALSE);
			}

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_OfflineMsg", 0);
			if (byValue)
				SendDlgItemMessage(hwndDlg, IDC_OFMSGONMSGR, BM_SETCHECK, (WPARAM)1, 0L);
			else SendDlgItemMessage(hwndDlg, IDC_OFMSGONMAIL, BM_SETCHECK, (WPARAM)1, 0L);

			if (!amIOnline() || noUploadXCAP || !bUseXCAP) {
				EnableWindow(GetDlgItem(hwndDlg, IDC_OFMSGONMSGR), FALSE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_OFMSGONMAIL), FALSE);
			}

			if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_File", 0))
				SendDlgItemMessage(hwndDlg, IDC_SAVEXCAP, BM_SETCHECK, (WPARAM)1, 0L);

#ifdef _C6_FULL
			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "AvatarsEnabled", DEFAULT_AVATARS_ENABLED);
			SendDlgItemMessage(hwndDlg, IDC_AVATARSUPPORT, BM_SETCHECK,(WPARAM)byValue, 0L);

			byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "AvatarsAutoClean", 0);
			SendDlgItemMessage(hwndDlg, IDC_AVATARAUTOCLEAN, BM_SETCHECK,(WPARAM)byValue, 0L);
//			EnableWindow(GetDlgItem(hwndDlg, IDC_AVATARAUTOCLEAN), FALSE);
#endif

		}
		return TRUE;

		case WM_COMMAND:
		  switch (LOWORD(wParam))
			{

			    case IDC_MANAGESERVERLST:

	      			DialogBox(hInst, MAKEINTRESOURCE(IDD_C6SERVERLIST), hwndDlg, (DLGPROC)serverListDlgProc);

					return TRUE;
#ifdef _C6_FULL
				case IDC_AVATARCLEANING :

					PolishDirImage(FALSE);

					return TRUE;
#endif
			}
		  SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);

		  break;

		case WM_NOTIFY:
			if ((((LPNMHDR)lParam)->code) == PSN_APPLY ) {

				int iCheck;
				BYTE byValue;

				iCheck = SendDlgItemMessage(hwndDlg, IDC_C6USEXCAP, BM_GETCHECK, 0, 0L);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "UseXCAP", (BYTE)iCheck);

				iCheck = SendDlgItemMessage(hwndDlg, IDC_SAVEXCAP, BM_GETCHECK, 0, 0L);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_File", (BYTE)iCheck);

				iCheck = SendDlgItemMessage(hwndDlg, IDC_SERVERCONTACTS, BM_GETCHECK, 0, 0L);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", (BYTE)iCheck);
				EnableWindow(GetDlgItem(hwndDlg, IDC_FORCEAUTH), iCheck);

				iCheck = SendDlgItemMessage(hwndDlg, IDC_FORCEAUTH, BM_GETCHECK, 0, 0L);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ForceAuthCList", (BYTE)iCheck);

				iCheck = SendDlgItemMessage(hwndDlg, IDC_NOPERMISSION, BM_GETCHECK, 0, 0L);
				if (iCheck==0) {
					iCheck = SendDlgItemMessage(hwndDlg, IDC_NOTIFPERM, BM_GETCHECK, 0, 0L);
					if (iCheck==0)
						iCheck = CONFIG_AUTHORIZE;
					else iCheck = CONFIG_NOTIFICATION;
				}
				else iCheck = CONFIG_NOWARNING;
				byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_Permission", 0);
				if (byValue != iCheck && amIOnline()) { // update
					char szUser[20];
					GetUserNickName(szUser);

					if (!c6SetXCAPConfig(szUser, 1, iCheck)) {
						DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_Permission", (BYTE)iCheck);
						c6LogMsg("Update XCAP_Permission");
					}
				}

				iCheck = SendDlgItemMessage(hwndDlg, IDC_OFMSGONMSGR, BM_GETCHECK, 0, 0L);
				byValue = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_OfflineMsg", 0);
				if (byValue != iCheck && amIOnline()) { // update
					char szUser[20];
					GetUserNickName(szUser);

					if (!c6SetXCAPConfig(szUser, 0, iCheck)) {
						DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_OfflineMsg", (BYTE)iCheck);
						c6LogMsg("Update XCAP_OfflineMsg");
					}
				}

#ifdef _C6_FULL
					gbAvatarsEnabled = SendDlgItemMessage(hwndDlg, IDC_AVATARSUPPORT, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "AvatarsEnabled", (BYTE)gbAvatarsEnabled);

					iCheck = SendDlgItemMessage(hwndDlg, IDC_AVATARAUTOCLEAN, BM_GETCHECK, 0, 0L);
					DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "AvatarsAutoClean", (BYTE)iCheck);

#endif

			return TRUE;
		}
	}

	return FALSE;
}

//--------------------------------------------------------------------
//                          serverListDlgProc
//--------------------------------------------------------------------

static void addComboNick(HWND hwndCombo, HWND hwndList)
{

	HANDLE hContact;
	char* szProto;
	DBVARIANT dbv;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	while (hContact != NULL)
	{

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
			if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {
	        	if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {

					if (SendMessage(hwndList, LB_FINDSTRING, -1, (LPARAM)dbv.pszVal) == LB_ERR)
						SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)dbv.pszVal);

					DBFreeVariant(&dbv);
				}
			}

		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}
}

static BOOL CALLBACK serverListDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	int tl = (int) GetProp(hwndDlg, "lpTyeListData");

	switch (msg) {

  		case WM_INITDIALOG:
		{

			TranslateDialogDefault(hwndDlg);
      		SendMessage(hwndDlg, WM_SETICON, ICON_BIG, (LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_C6)));

			EnableWindow(GetDlgItem(hwndDlg, IDC_ADD), FALSE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_DEL), FALSE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_SELUSER), FALSE);
			SetProp(hwndDlg, "lpTyeListData", (HANDLE) -1);
		}
		break;

  		case WM_CLOSE:
			RemoveProp(hwndDlg, "lpTyeListData");
			c6LogMsg("Close Server's list");
    		EndDialog(hwndDlg, 0);

	    	break;

  		case WM_COMMAND:
    		{
      			switch (LOWORD(wParam)) {

					case IDC_WL:
					case IDC_BL:
					{
						tl = LOWORD(wParam) == IDC_WL;
						SetProp(hwndDlg, "lpTyeListData", (HANDLE) tl);

						EnableWindow(GetDlgItem(hwndDlg, IDC_WL), FALSE);
						EnableWindow(GetDlgItem(hwndDlg, IDC_BL), FALSE);
						SetDlgItemText(hwndDlg, IDC_INFOLIST, Translate("Get List from Server..."));

						LPSTR pszUser = mir_alloc(40);
						GetUserNickName(pszUser);

						HWND hwndList = GetDlgItem(hwndDlg, IDC_SERVERLIST);
						SendMessage(hwndList, LB_RESETCONTENT, 0, 0L);

						if (tl==1)
							enumWhiteList(hwndList);
						else
							c6GetXCAPAuthList(tl, pszUser, hwndList);
						mir_free(pszUser);

						EnableWindow(GetDlgItem(hwndDlg, IDC_WL), TRUE);
						EnableWindow(GetDlgItem(hwndDlg, IDC_BL), TRUE);

						SetDlgItemText(hwndDlg, IDC_INFOLIST, tl ? Translate("WhiteList") : Translate("BlackList"));

						EnableWindow(GetDlgItem(hwndDlg, IDC_DEL), TRUE);
						EnableWindow(GetDlgItem(hwndDlg, IDC_ADD), (LOWORD(wParam) == IDC_BL));

						if (tl==0) { // blacklist
							addComboNick(GetDlgItem(hwndDlg, IDC_SELUSER), hwndList);
							EnableWindow(GetDlgItem(hwndDlg, IDC_SELUSER), TRUE);
						}
						else {
							SendDlgItemMessage(hwndDlg, IDC_SELUSER, CB_RESETCONTENT, 0, 0L);
							EnableWindow(GetDlgItem(hwndDlg, IDC_SELUSER), FALSE);
						}
					}
					break;

					case IDC_SL : {

						SetDlgItemText(hwndDlg, IDC_INFOLIST, "Server Group List");
						HWND hwndList = GetDlgItem(hwndDlg, IDC_SERVERLIST);
						SendMessage(hwndList, LB_RESETCONTENT, 0, 0L);
						EnableWindow(GetDlgItem(hwndDlg, IDC_SELUSER), TRUE);
						SendDlgItemMessage(hwndDlg, IDC_SELUSER, CB_RESETCONTENT, 0, 0L);
						enumSrvContacts(hwndList, GetDlgItem(hwndDlg, IDC_SELUSER));
						EnableWindow(GetDlgItem(hwndDlg, IDC_ADD), FALSE);
						EnableWindow(GetDlgItem(hwndDlg, IDC_DEL), FALSE);

					}
					break;

					case IDC_DEL:
					{
					 	DWORD i = SendDlgItemMessage(hwndDlg, IDC_SERVERLIST, LB_GETCURSEL, 0, 0L);
			 			if (i != LB_ERR) {

							LPSTR pszNick = mir_alloc(40);
			 				SendDlgItemMessage(hwndDlg, IDC_SERVERLIST, LB_GETTEXT, (WPARAM)i, (LPARAM)pszNick);

							int iret = 1;
							if (tl==1) { // whitelist
								iret = c6DelXCAPWhiteList(pszNick);
								del1WhiteList(pszNick);
							}
							else if (tl==0) // blacklist
								iret = c6DelXCAPBlackList(pszNick);
							if (iret==0)
								SendDlgItemMessage(hwndDlg, IDC_SERVERLIST, LB_DELETESTRING, (WPARAM)i, 0L);

							mir_free(pszNick);
						}
					}
					break;

					case IDC_ADD:
					{
					 	DWORD i = SendDlgItemMessage(hwndDlg, IDC_SELUSER, CB_GETCURSEL, 0, 0L);
			 			if (i != CB_ERR) {

							LPSTR pszNick = mir_alloc(40);
							GetDlgItemText(hwndDlg, IDC_SELUSER, pszNick, 40);
							// rimuovi dalla lista amici...
							HANDLE hContact = HContactfNickNoAdd(pszNick);
							if (hContact)
								removeContactSS(hContact, pszNick);
			 				//SendDlgItemMessage(hwndDlg, IDC_SELUSER, CB_GETLBTEXT, (WPARAM)i, (LPARAM)pszNick);
							if (!c6AddXCAPBlackList(pszNick)) {
								SendDlgItemMessage(hwndDlg, IDC_SERVERLIST, LB_ADDSTRING, 0, (LPARAM)pszNick);
								addSrvIgnoreList(pszNick, IGNOREEVENT_ALL);
							}
							mir_free(pszNick);
						}
					}
					break;

				}
    		}
    	break;
  	}

  	return FALSE;

}

void SecrMenuChange(BOOL bShow)
{

	CLISTMENUITEM clmi;

	memset( &clmi, 0, sizeof(clmi));
	clmi.cbSize = sizeof(clmi);

	clmi.flags = (bShow) ? 0 : CMIF_GRAYED;
	clmi.flags |= CMIM_FLAGS;
	CallService(MS_CLIST_MODIFYMENUITEM, (WPARAM)hSecrMenuItem, (LPARAM)&clmi);

}


