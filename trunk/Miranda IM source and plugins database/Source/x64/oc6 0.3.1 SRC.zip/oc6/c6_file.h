/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_FILE_H
#define __C6_FILE_H

typedef struct C6FileTransfer_s {
	HANDLE hContact;
	DWORD dwFileSize;
	DWORD dwRemoteIP;
	WORD  wRemotePort;
	DWORD dwBytesDone;
	HANDLE hConnection;
	int outCountFile;
	int sending;
	BOOL bStopFile;
	LPSTR pszReceiver;
	LPSTR pszSender;
	LPSTR pszFileName;
} C6FileTransfer;

#define DIRECTCONN_SENDINGFILE   0
#define DIRECTCONN_RECEIVINGFILE 1

typedef struct {
	HANDLE hConnection;
	int incoming;
	DWORD dwRemotePort;
	DWORD dwRemoteInternalIP;
	DWORD dwThreadId;
	C6FileTransfer *ft;
} directconnect;

void openDirectConnection(HANDLE hContact, void* ft);

void newConnectionReceived(HANDLE hNewConnection, DWORD dwRemoteIP);
void c6CancelFileTransfer(HANDLE hContact, C6FileTransfer* ft);

#endif /* __C6_FILE_H */
