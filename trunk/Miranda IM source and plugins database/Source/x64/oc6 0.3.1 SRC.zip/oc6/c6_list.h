/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_LIST_H
#define __C6_LIST_H

/* ---------------------- Functions ---------------------- */

BOOL addWhiteList(const char* nick);
void freeWhiteList(void);
void del1WhiteList(const char* nick);
BOOL findWhiteList(const char *nick);
void enumWhiteList(HWND hwndList);

BOOL addSrvGroup(const char* group);
void freeSrvGroup(void);
BOOL findSrvGroup(const char *group);
BOOL del1SrvGroup(const char* group);
BOOL renameSrvGroup(const char *oldgroup, const char *newgroup);

void enumSrvGroup(HWND hwndList);

#endif /* __C6_LIST_H */

