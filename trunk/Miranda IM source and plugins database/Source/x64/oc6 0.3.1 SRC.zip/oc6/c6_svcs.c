/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

static HANDLE hHookContactDeleted = NULL;
static HANDLE hHookGroupChange = NULL;
static HANDLE hHookMsgWnd = NULL;

extern HINSTANCE hInst;

extern int c6Status;

extern WORD wListenPort;

#ifndef _C6_FINGERPRINT
extern HANDLE hExtraImage[];
#endif

extern BOOL bSecretariat;

#ifdef _C6_FULL
extern BYTE gbAvatarsEnabled;
#endif

extern struct fieldnames_t agesField[];
extern struct fieldnames_t workField[];
extern struct fieldnames_t stateField[];
extern struct fieldnames_t countryField[];
extern struct fieldnames_t hobbyField[];
extern struct fieldnames_t musicField[];
extern struct fieldnames_t cinemaField[];
extern struct fieldnames_t sportField[];
extern struct fieldnames_t dislikeField[];

typedef struct SendMsgData_s {
	HANDLE contact;
	HANDLE cookie;
	char szUser[40]; // 20
	char szNick[40]; // 20
	LPSTR text;
} SendMsgData;

typedef struct SearchData_s {
	HANDLE cookie;
	WORD nCount;
	BYTE *pNickArray;
} SearchData;

struct fieldnames_t clientIDField[]={
	// C6 Messenger 4.1/4.2/4.8 // Doesn't Work from 25-10-2005
	{ID_CLIENT_MIRANDA  , "Miranda IM"},
	{ID_CLIENT_OC6      , "OpenC6"},
	{ID_CLIENT_CM3      , "C6 Messenger 4.x"},
	{ID_CLIENT_CM4      , "C6 Messenger 4.8"},
	{ID_CLIENT_CM5      , "C6 Messenger 5.0"},
	{ID_CLIENT_CM6      , "C6 Messenger 5.1"},
	{ID_CLIENT_CM7      , "C6 Messenger 5.2"},
	{ID_CLIENT_CM8      , "C6 Messenger 6.0"},
	{ID_CLIENT_CM9      , "C6 Messenger 6.1"},
	{ID_CLIENT_CM10     , "C6 Messenger 6.2"},
	{ID_CLIENT_CM11     , "C6 Messenger 7.0"},
	{ID_CLIENT_CM12     , "C6 Messenger 7.1"},
	{ID_CLIENT_CM13     , "C6 Messenger >=7.2"},
	{ID_CLIENT_JAVA     , "Java C6Applet"},
	{ID_CLIENT_MB       , "Java C6 Message Box"},
	{0,  NULL}};

//--------------------------------------------------------------------
//                           C6GetCaps
//--------------------------------------------------------------------

static int C6GetCaps(WPARAM wParam, LPARAM lParam)
{
	if(wParam==PFLAGNUM_1)

	    return PF1_IM | PF1_BASICSEARCH | PF1_ADDSEARCHRES |
			PF1_EXTSEARCH | PF1_CONTACTRECV | PF1_FILE |
			PF1_EXTSEARCHUI | PF1_SEARCHBYEMAIL | PF1_CHANGEINFO | PF1_AUTHREQ;

	if(wParam==PFLAGNUM_2)
		return PF2_ONLINE | PF2_LIGHTDND | PF2_LONGAWAY | PF2_SHORTAWAY;
	if(wParam==PFLAGNUM_3)
		return PF2_ONLINE | PF2_LIGHTDND | PF2_LONGAWAY | PF2_SHORTAWAY; // for away message;
	if(wParam==PFLAGNUM_4) {
		int nReturn = PF4_NOCUSTOMAUTH;

		if(DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", 0))
			nReturn |= PF4_SUPPORTTYPING;

#ifdef _C6_FULL
    	if (gbAvatarsEnabled)
      		nReturn |= PF4_AVATARS;
#endif
		if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ForceAuthCList", 0))
			nReturn |= PF4_FORCEAUTH;

		return nReturn;
	}
	if(wParam==PFLAG_UNIQUEIDTEXT)
		return (int)Translate("ID"); // Nick
    if(wParam==PFLAG_UNIQUEIDSETTING)
        return (int) C6_LOGINID;
    if(wParam==PFLAG_MAXLENOFMESSAGE)
        return 512;
	return 0;
}

//--------------------------------------------------------------------
//                           C6GetName
//--------------------------------------------------------------------

static int C6GetName(WPARAM wParam,LPARAM lParam)
{
  if (lParam)
  {
	strncpy((char*)lParam,C6PROTOCOLNAME,wParam);
	return 0;
  }

  return 1; // Failure
}

//--------------------------------------------------------------------
//                           C6LoadIcon
//--------------------------------------------------------------------

static int C6LoadIcon(WPARAM wParam,LPARAM lParam)
{
	UINT id;

	switch(wParam&0xFFFF) {
		case PLI_PROTOCOL:
			id=IDI_C6;
			break;
		default: return (int)(HICON)NULL;
	}
	return (int)LoadImage(hInst, MAKEINTRESOURCE(id), IMAGE_ICON,
		GetSystemMetrics(wParam & PLIF_SMALL ? SM_CXSMICON : SM_CXICON),
		GetSystemMetrics(wParam & PLIF_SMALL ? SM_CYSMICON : SM_CYICON), 0);
}

//--------------------------------------------------------------------
//                           C6SetStatus
//--------------------------------------------------------------------

int C6SetStatus(WPARAM wParam,LPARAM lParam)
{

 	int oldStatus = c6Status;
	char szUser[40]; // 20

 	int nNewStatus = wParam;

 	if (nNewStatus != oldStatus)
	 	{

      	// New status is OFFLINE
	  	if (nNewStatus == ID_STATUS_OFFLINE) {

		    if (c6Status == ID_STATUS_CONNECTING) {

				c6ServerDisconnect();

			}
			else {

				GetUserNickName(szUser);
            	c6ReqClientExit(szUser);

			}

			c6GcAllQuit(); // Close GroupChat Windows

	    }
		else {

		    if (c6Status == ID_STATUS_CONNECTING)
				return 0; // waiting...

			switch (wParam) {

				case ID_STATUS_CONNECTING:
					{
						return 0;
					}

				// We are offline and need to connect
				default:

					if (c6Status == ID_STATUS_OFFLINE) {

						c6LogMsg("Status: Connecting...");
						c6Status = ID_STATUS_CONNECTING;
					    ProtoBroadcastAck(C6PROTOCOLNAME, NULL, ACKTYPE_STATUS, ACKRESULT_SUCCESS, (HANDLE)oldStatus, c6Status);

						c6Login(MirandaStatusToC6(nNewStatus));

		        		return 0;

					}

					{

						LPSTR pszStatusMessage;

						c6LogMsg("Change Status");

						GetUserNickName(szUser);
						getStatusMessage(&pszStatusMessage);

						if (nNewStatus == ID_STATUS_AWAY)
							c6NewChangeStatus(szUser, 1, MirandaStatusToC6(c6Status), pszStatusMessage);
						else c6NewChangeStatus(szUser, 0, MirandaStatusToC6(nNewStatus), pszStatusMessage);

						mir_free(pszStatusMessage);

					}
					break;

			}

		    //broadcast the message
		    c6Status = wParam;
			ProtoBroadcastAck(C6PROTOCOLNAME,NULL,ACKTYPE_STATUS,ACKRESULT_SUCCESS, (HANDLE)oldStatus,wParam);
		}
   	}

 	return 0;

}

//--------------------------------------------------------------------
//                           C6SetOnlineStatus
//--------------------------------------------------------------------

int C6SetMyStatus(WPARAM wParam)
{

	int oldStatus = c6Status;

	c6Status = wParam;
	ProtoBroadcastAck(C6PROTOCOLNAME,NULL,ACKTYPE_STATUS,ACKRESULT_SUCCESS, (HANDLE)oldStatus,wParam);
	return oldStatus;

}

//--------------------------------------------------------------------
//                           C6GetStatus
//--------------------------------------------------------------------

int C6GetStatus(WPARAM wParam,LPARAM lParam)
{
	if (c6Status == ID_STATUS_AWAY)

		return ID_STATUS_AWAY;

	else if (c6Status == ID_STATUS_ONLINE)

		return ID_STATUS_ONLINE;

	else if (c6Status == ID_STATUS_NA)

		return ID_STATUS_NA;

	else if (c6Status == ID_STATUS_OCCUPIED)

		return ID_STATUS_OCCUPIED;

	else if (c6Status == ID_STATUS_CONNECTING)

		return ID_STATUS_CONNECTING;

	else

		return ID_STATUS_OFFLINE;
}

//--------------------------------------------------------------------
//                           C6CreateAdvSearchUI
//--------------------------------------------------------------------

int C6CreateAdvSearchUI(WPARAM wParam, LPARAM lParam)
{
	if (lParam && hInst)
	{
		// Success
		return (int)CreateDialog(hInst , MAKEINTRESOURCE(IDD_ADVSEARCH), (HWND)lParam, (DLGPROC)AdvancedSearchDlgProc);

	}
	return 0; // Failure
}


//--------------------------------------------------------------------
//                           C6SearchByAdvanced
//--------------------------------------------------------------------

int C6SearchByAdvanced(WPARAM wParam, LPARAM lParam)
{

	if (amIOnline() && IsWindow((HWND)lParam))
	{

		int nDataLen;
		BYTE* bySearchData;


		if ((bySearchData = createAdvancedSearchStructure((HWND)lParam, &nDataLen)) != NULL)
		{

			int result;

			result = c6SendSrcAdvServ(nDataLen, bySearchData);
			mir_free(bySearchData);

			return result; // Success

		}

	}

	return 0; // Failure

}

//--------------------------------------------------------------------
//                           SearchThread
//--------------------------------------------------------------------

static char *pszemail = NULL;
DWORD WINAPI SearchThread (LPVOID param)
{

	const BYTE str5[] = { 0x00, 0x02, 0x00, 0x01, 0x02 };
   	struct id_blk {
		BYTE id[5];
	} *p_status;

	BYTE *p;
	char *pszNick;
	BYTE l;
	LONG status;
	WORD i, len_nicks;
	char strstat[80];

	CallService (MS_SYSTEM_THREAD_PUSH, 0, 0);

	SearchData* data = (SearchData*) (param);

	p = data->pNickArray;

	len_nicks = 2 * data->nCount;

	for (i = 0; i < data->nCount; i++) {
     	l = *p;
    	len_nicks += l;
      	p += 2 + l;
   	}

	//WORD pos_nick = 0;
	p = data->pNickArray;

	for (i = 0; i < data->nCount; i++) {

     	l = *p;

	  	pszNick = (char*)mir_alloc(l + 1);
	    strncpy(pszNick, (char*)p + 1, l);
	    pszNick[l] = '\0';

		p_status = (struct id_blk*) ((data->pNickArray) + len_nicks + i*13);

		if (!memcmp(p_status->id, str5, 5)) {

			status = (LONG)(*(((BYTE*)(p_status) + 7)) << 8 | *((BYTE*)(p_status) + 8));

		} else status = (BYTE)*(p + l + 1);

		if (pszemail)
			status = 0x0ffff;

		if ((status & C6_OFFLINE)==C6_OFFLINE)
			_snprintf(strstat, 80, "Offline (0x%X)", status);
		else _snprintf(strstat, 80, "%s%s%s%s (0x%X)",
											(status == 0)?"Connecting":
					                          (status & C6_AWAY)==C6_AWAY?"Away":
					                          (status & C6_AVAILABLE)==C6_AVAILABLE?"Available":
					                          (status & C6_NETFRIENDS)==C6_NETFRIENDS?"NetFriend":
											  (status & C6_BUSY)==C6_BUSY?"Busy":"",
											(status & C6_MEETING)==C6_MEETING?",Meeting":"",
											(status & C6_FILESHARED)==C6_FILESHARED?",FileSharing":"",
											(status & C6_IP_SHOWED)==C6_IP_SHOWED?",IP":"",
											status);

		C6SEARCHRESULT sr = {0};

	    sr.hdr.cbSize = sizeof(sr);

		sr.hdr.id = pszNick; // v0.9
		sr.hdr.nick = pszNick;
		sr.hdr.firstName = strstat;
		sr.hdr.lastName = NULL;
		sr.hdr.email = pszemail;
		sr.status = status;

	    // Finally, broadcast the result
	 	ProtoBroadcastAck(C6PROTOCOLNAME, NULL,	ACKTYPE_SEARCH, ACKRESULT_DATA, (HANDLE)data->cookie, (LPARAM)&sr);

      	p += 2 + l;

		mir_free(pszNick);

 	}

    c6LogMsg("End Search");

	// Broadcast "Last result" ack if this was the last user found
	ProtoBroadcastAck(C6PROTOCOLNAME, NULL,	ACKTYPE_SEARCH, ACKRESULT_SUCCESS, (HANDLE)data->cookie, 0);

	mir_free(data->pNickArray);
	mir_free(data);

	mir_free(pszemail);
	pszemail = NULL;

	CallService (MS_SYSTEM_THREAD_POP, 0, 0);
	return 0;
}

//--------------------------------------------------------------------
//                           SearchLaunch
//--------------------------------------------------------------------

int SearchLaunch(WORD Number, int size, BYTE *plist)
{
	WORD cookie = 1;
	// IMPORTANTE: si deve mettere lo stesso valore di ritorno della funzione chiamante
	// in questo caso � send_packet che ritorna 1 se ha successo !

	if (Number) {

		SearchData* data = (SearchData*)mir_alloc(sizeof(SearchData));
		data->cookie = (HANDLE)cookie;
		data->nCount = Number;
		data->pNickArray = mir_alloc(size - 2);//plist; - 8
		memcpy(data->pNickArray, plist, size - 2);// - 8
		DWORD id;

		CloseHandle (CreateThread (NULL, 0, SearchThread, data, 0, &id));

		return (int) cookie;
	}
	else // Failure
		ProtoBroadcastAck(C6PROTOCOLNAME, NULL, ACKTYPE_SEARCH, ACKRESULT_SUCCESS, (HANDLE)cookie, 0);

	mir_free(pszemail);
	pszemail = NULL;

	return 0;
}

//--------------------------------------------------------------------
//                           AddToListDirect
//--------------------------------------------------------------------

int AddToListDirect(DWORD dwFlags,char *szNick, char *szGroupName)
{

	HANDLE hContact;

	hContact = HContactFromNick(dwFlags, szNick);

	if (hContact)
	{

		if (strlen(szGroupName))
			DBWriteContactSettingString(hContact, "CList", "Group", szGroupName);

		if ((!dwFlags&PALF_TEMPORARY) && DBGetContactSettingByte(hContact, "CList", "NotOnList", 1)) {

			DBDeleteContactSetting(hContact, "CList", "NotOnList");
			DBDeleteContactSetting(hContact, "CList", "Hidden");
		}

		return (int)hContact; // Success

	}

	return 0; // Failure

}

//--------------------------------------------------------------------
//                           SetNetFriendStatus
//--------------------------------------------------------------------

void SetNetFriendStatus(char *szNick, int wStatus, BOOL bShow, LPSTR pszMsg)
{
	HANDLE hContact;

	hContact = HContactFromNick(bShow, szNick);

    DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "Status", (WORD)C6StatusToMiranda(wStatus));
	if (bShow && wStatus != C6_OFFLINE) {

		DBWriteContactSettingByte(hContact, "CList", "Hidden", 0);

		if (pszMsg){
			DBWriteContactSettingString(hContact, "CList", "StatusMsg", pszMsg);
		}
		else {
			DBDeleteContactSetting(hContact, "CList", "StatusMsg");
		}

       	SYSTEMTIME lst;

	   	GetLocalTime(&lst);
	   	struct tm t;

	   	memset(&t,0x00,sizeof(t));

       	t.tm_sec    = lst.wSecond;
   	   	t.tm_min    = lst.wMinute;
       	t.tm_hour   = lst.wHour;
       	t.tm_mday   = lst.wDay;
       	t.tm_mon    = lst.wMonth -1;
       	t.tm_year   = lst.wYear - 1900;
       	t.tm_wday   = lst.wDayOfWeek;

		TIME_ZONE_INFORMATION tzi;

 		switch (GetTimeZoneInformation(&tzi)) {
  			case TIME_ZONE_ID_STANDARD: t.tm_isdst  = 0;
				break;
  			case TIME_ZONE_ID_DAYLIGHT: t.tm_isdst  = 1;
				break;
  			default : t.tm_isdst  = 0;
 		}

	   DBWriteContactSettingDword(hContact, C6PROTOCOLNAME, "LastOnline", mktime(&t));

	}

}

//--------------------------------------------------------------------
//                           Add1NetFriend
//--------------------------------------------------------------------

int Add1NetFriend(char *szNick)
{
	char* pBody;
	char* pBuffer;

	int	nBodyLength = strlen(szNick) + 1;

	pBuffer = pBody = (char *)mir_calloc(nBodyLength);

	*pBuffer = strlen(szNick);
	pBuffer += 1;
	strcpy(pBuffer, szNick);

	c6NetFriendStatus(pBody, nBodyLength, 1);
	mir_free(pBody);
	return 1;
}

//--------------------------------------------------------------------
//                           HandleSendContact
//--------------------------------------------------------------------

WORD HandleSendContact(void)
{

	HANDLE hContact;
	char* szProto;
	DBVARIANT dbv;
	int i, nContacts = 0, nBodyLength = 0;
    char* pBody;
	char* pBuffer;

	hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
	while (hContact != NULL)
	{

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
			if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {
	        	if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv) &&
					DBGetContactSettingByte(hContact, "CList", "NotOnList", 0)==0) {
					if (!CallService(MS_IGNORE_ISIGNORED, (WPARAM)hContact, (LPARAM)IGNOREEVENT_USERONLINE)) {
            	    	nContacts++;
						nBodyLength += (strlen(dbv.pszVal) + 1);
						DBFreeVariant(&dbv);
					}
				}
			}

		hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
	}

    if (nBodyLength) {
	    hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);

		pBuffer = pBody = (char *)mir_calloc(nBodyLength);

		i = 0;
	    while (i < nContacts) {
		    szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		    if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
				if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0){
					if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv) &&
						DBGetContactSettingByte(hContact, "CList", "NotOnList", 0)==0) {

						if (!CallService(MS_IGNORE_ISIGNORED, (WPARAM)hContact, (LPARAM)IGNOREEVENT_USERONLINE)) {

	  						*pBuffer = strlen(dbv.pszVal);
							pBuffer += 1;
							strncpy(pBuffer, dbv.pszVal, strlen(dbv.pszVal));
							pBuffer += strlen(pBuffer);

							DBFreeVariant(&dbv);

							i++;
				    	}
					}
				}

			hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);

		} // while
		i = c6NetFriendStatus(pBody, nBodyLength, nContacts);
		mir_free(pBody);
		return i;
	}

	return 0;

}

//--------------------------------------------------------------------
//                           AutoResponse
//--------------------------------------------------------------------

DWORD WINAPI AutoResponse(LPSTR pszNick, LPSTR pszMsg)
{
    DBVARIANT dbv;
    char szUser[40]; // 20

   	if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
    	strcpy(szUser,dbv.pszVal);
		DBFreeVariant(&dbv);
		}

	c6SendMessageServ(OL_MESSAGE, szUser, pszNick, pszMsg);

	return 0;
}

//--------------------------------------------------------------------
//                           HandleGetMessage
//--------------------------------------------------------------------

void HandleGetMessage(char *szNick, char *szMsg, time_t *tt)
{

	CCSDATA ccs;
	PROTORECVEVENT pre;
	BOOL bNF, bMessage2CL;

	bNF = isNetFriend(szNick);

	DWORD i = (bSecretariat && !bNF && (c6Status != ID_STATUS_ONLINE));

	ccs.szProtoService = PSR_MESSAGE;
	ccs.hContact = HContactFromNick(i, szNick);

	if (CallService(MS_IGNORE_ISIGNORED, (WPARAM)ccs.hContact, (LPARAM)IGNOREEVENT_MESSAGE)) {

		// Ignore Message => Options/C6/IgnoreMsg
		LPSTR pszBlackList = GetIgnoreMsg();

		if (strlen(pszBlackList))
			AutoResponse(szNick, pszBlackList);

		mir_free(pszBlackList);

		return;
	}

	bMessage2CL = TRUE;

	if (!areYouTalking(ccs.hContact)) {

	if (c6Status == ID_STATUS_NA && !bNF) {

		// status AWAY = NF
		LPSTR pszNFOnly = (LPSTR)CallService(MS_AWAYMSG_GETSTATUSMSG, (WPARAM)ID_STATUS_NA, 0);

		if (DBGetContactSettingWord(ccs.hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE) != ID_STATUS_OFFLINE)
			if (pszNFOnly)
				AutoResponse(szNick, pszNFOnly);

		if (bSecretariat) {
			LogPopup(ccs.hContact, POPUPCOLOR_WHITE, Translate("Message in Secretariat"));
			insertInSecretariat(0, szNick, szMsg, tt);
		}

		if (pszNFOnly)
			mir_free(pszNFOnly);

		bMessage2CL = !bSecretariat;
	}
	else if (c6Status == ID_STATUS_OCCUPIED) {

		// status BUSY
		LPSTR pszBusy = (LPSTR)CallService(MS_AWAYMSG_GETSTATUSMSG, (WPARAM)ID_STATUS_OCCUPIED, 0);

		if (DBGetContactSettingWord(ccs.hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE) != ID_STATUS_OFFLINE)
			if (pszBusy)
				AutoResponse(szNick, pszBusy);
		if (bSecretariat) {
			LogPopup(ccs.hContact, POPUPCOLOR_WHITE, Translate("Message in Secretariat"));
			insertInSecretariat(bNF ? 1 : 0, szNick, szMsg, tt);
		}

		if (pszBusy)
			mir_free(pszBusy);

		bMessage2CL = !bSecretariat;
	}
	else if (c6Status == ID_STATUS_AWAY) {

		// status AWAY
		LPSTR pszAway = (LPSTR)CallService(MS_AWAYMSG_GETSTATUSMSG, (WPARAM)ID_STATUS_AWAY, 0);

		if (DBGetContactSettingWord(ccs.hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE) != ID_STATUS_OFFLINE)
			if (pszAway)
				AutoResponse(szNick, pszAway);
		if (bSecretariat) {
			LogPopup(ccs.hContact, POPUPCOLOR_WHITE, Translate("Message in Secretariat"));
			insertInSecretariat(bNF ? 1 : 0, szNick, szMsg, tt);
		}

		if (pszAway)
			mir_free(pszAway);

		bMessage2CL = !bSecretariat;
	}
	}

	if ( bMessage2CL ) {

		if (strcmp(szMsg,"<ding>")==0) {
			// Ding !
			c6LogMsg("Ding!");
			DingExecute(szNick);
		}

		ccs.wParam = 0;
	 	ccs.lParam = (LPARAM)&pre;
	 	pre.flags = 0;
	 	pre.timestamp = (tt) ? (*tt) : time(NULL);
	 	pre.szMessage = (char *)szMsg;
	 	pre.lParam = 0;
	 	CallService(MS_PROTO_CHAINRECV, 0, (LPARAM)&ccs);

    }
}

//--------------------------------------------------------------------
//                           HandleGetProfile
//--------------------------------------------------------------------

WORD HandleGetProfile(char *szNick, int len, LPARAM lParam)
{

	HANDLE hContact;
	int i, icat;
	BOOL bHobby, bSport;
	profile_user_data* usrd = (profile_user_data*)lParam;

	hContact = HContactFromNick(0, szNick);

	DWORD dwFlags;
	if (getClient(szNick, &dwFlags)) {

		if (dwFlags & 1)
	  		DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "C6Status", usrd->status);

		GetInfoData *p = usrd->list;

		if ((dwFlags & 2)==2)
		for (i = 0 ; i < len; i++) {

    		if (p->descr==0x0F) { // client version

					if (p->info >= ID_CLIENT_CM10)
						setContactTyping(hContact, 1);
					return 0;
				}
			p++;
		}

		//c6LogMsg("solo getClient");
		return 0;
	}

    DBWriteContactSettingDword(hContact, C6PROTOCOLNAME, "UserIP", usrd->ip);
  	DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "C6Status", usrd->status);
    DBWriteContactSettingDword(hContact, C6PROTOCOLNAME, "LogonTS", usrd->time);

	DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "Status", (WORD)C6StatusToMiranda(usrd->status));

    // reset dbsetting
	for (i = 0 ; i < 8; i++) {
		char idstr[33];

		_snprintf(idstr, 33, "Interest%dCat", i);
		DBDeleteContactSetting(hContact, C6PROTOCOLNAME, idstr);
		_snprintf(idstr, 33, "Interest%dText", i);
		DBDeleteContactSetting(hContact, C6PROTOCOLNAME, idstr);
    }

    DBWriteContactSettingByte(hContact, C6PROTOCOLNAME, "C6Flags", (BYTE)0x00);

    DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "SettingCaps");

	if (len == 0) { // prova almeno un client...
		if (strstr(szNick, "@jabber"))
			writeDbInfoSettingString(hContact, "MirVer", "Jabber");
		else if (strstr(szNick, "@gmail"))
			writeDbInfoSettingString(hContact, "MirVer", "Gmail");
	}

	GetInfoData *p = usrd->list;

	icat = 0;
	bHobby = FALSE;
	bSport = FALSE;
	for (i = 0 ; i < len; i++) {
       if (p->descr == 7)
		   bHobby = TRUE;
	   else if (p->descr == 8)
	       bSport = TRUE;
	   p++;
	}
	if (bHobby) icat++;
	if (bSport) icat++;

	p = usrd->list;

	for (i = 0 ; i < len; i++) {

    	switch (p->descr) {

			case 1 : // RANGE_AGE
			 	if (p->info > 1)
			    	writeDbInfoSettingString(hContact, "Age", getStringName(p->info, agesField));
		 		break;
		 	case 2 : // GENDER
			 	if (p->info > 1)
	   				DBWriteContactSettingByte(hContact, C6PROTOCOLNAME, "Gender", (BYTE)(p->info == 3 ? 'F' : 'M'));
  		     	else
	   				// Undefined gender
			    	DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "Gender");
		 		break;
		 	case 4 : // WORK
			 	if (p->info > 1)
			    	writeDbInfoSettingString(hContact, "Company", getStringName(p->info, workField));
  		     	else
	   				// Undefined gender
			    	DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "Company");
		 		break;
		 	case 5 : // STATE
			 	if (p->info > 1){

					if ((p->info > 1 && p->info < 5) || p->info > 11) {
						DBWriteContactSettingWord(hContact, C6PROTOCOLNAME, "Country", getIDCountry(p->info));
						if (usrd->status!=0) // online
							DBWriteContactSettingByte(hContact, C6PROTOCOLNAME, "Timezone", (BYTE)-2);
					}
					else writeDbInfoSettingString(hContact, "Country", getStringName(p->info, stateField));
				}
  			    else
			    	DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "Country");
		 		break;
		 	case 13 : // COUNTRY
			 	if (p->info > 1)
				    writeDbInfoSettingString(hContact, "State", getStringName(p->info, countryField));
  			    else
			    	DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "State");
		 		break;
		 	case 6 : // CITY
			 	if (p->info > 1)
			    	writeDbInfoSettingString(hContact, "City", getStringName(p->info, countryField));
  		     	else
				    DBDeleteContactSetting(hContact, C6PROTOCOLNAME, "City");
				break;
		 	case 7 : // HOBBY
				{

				DBVARIANT dbv;
              	char idstr[33];
			  	char szbuf[100];

			  	_snprintf(idstr, 33, "Interest%dCat", 0);
			  	writeDbInfoSettingString(hContact, idstr, Translate("Hobby"));


			  	_snprintf(idstr, 33, "Interest%dText", 0);
              	if (!DBGetContactSetting(hContact, C6PROTOCOLNAME, idstr, &dbv)) {
					strcpy(szbuf,dbv.pszVal);
					strcat(szbuf,", ");
					DBFreeVariant(&dbv);
                } else szbuf[0]='\0';

			  	strcat(szbuf, getStringName(p->info, hobbyField));
			  	writeDbInfoSettingString(hContact, idstr, szbuf);
				}

				break;
		 	case 8 : // SPORT
				{

				DBVARIANT dbv;
              	char idstr[33];
			  	char szbuf[100];

			  	_snprintf(idstr, 33, "Interest%dCat", 1);
			  	writeDbInfoSettingString(hContact, idstr, Translate("Sport"));

			  	_snprintf(idstr, 33, "Interest%dText", 1);
              	if (!DBGetContactSetting(hContact, C6PROTOCOLNAME, idstr, &dbv)) {
					strcpy(szbuf,dbv.pszVal);
					strcat(szbuf,", ");
					DBFreeVariant(&dbv);
                } else szbuf[0]='\0';

			  	strcat(szbuf,getStringName(p->info, sportField));
			  	writeDbInfoSettingString(hContact, idstr, szbuf);
				}
				break;
		 	case 9 : // MUSIC
				{

				char idstr[33];

			  	_snprintf(idstr, 33, "Interest%dCat", icat);
			  	writeDbInfoSettingString(hContact, idstr, Translate("Music"));

			  	_snprintf(idstr, 33, "Interest%dText", icat);
			  	writeDbInfoSettingString(hContact, idstr, getStringName(p->info, musicField));
			  	icat++;
				}
				break;
		 	case 10 : // CINEMA
				{
              	char idstr[33];

			  	_snprintf(idstr, 33, "Interest%dCat", icat);
			  	writeDbInfoSettingString(hContact, idstr, Translate("Cinema"));

			  	_snprintf(idstr, 33, "Interest%dText", icat);
			  	writeDbInfoSettingString(hContact, idstr, getStringName(p->info, cinemaField));
			  	icat++;
			 	}
				break;
		 	case 0x0c : // DISLIKE
				{
              	char idstr[33];

			  	_snprintf(idstr, 33, "Interest%dCat", icat);
			  	writeDbInfoSettingString(hContact, idstr, Translate("Dislike"));

			  	_snprintf(idstr, 33, "Interest%dText", icat);
			  	writeDbInfoSettingString(hContact, idstr, getStringName(p->info, dislikeField));
			  	icat++;
			 	}
				break;
		 	case 0x0e : // AVATAR
				{
				if (p->info == 1) {

   					DBVARIANT dbv;

#ifdef _C6_FULL
  					if (gbAvatarsEnabled) {
			    		PROTO_AVATAR_INFORMATION ai;
						LPSTR pszFile;

						if (getAvatarFile(szNick, &pszFile)) {

    	    				ai.cbSize = sizeof(ai);
    	    			 	ai.format = PA_FORMAT_JPEG; // this is for error only
    	    			 	ai.hContact = hContact;
    	    			 	strcpy(ai.filename, pszFile);

							ProtoBroadcastAck(C6PROTOCOLNAME, hContact, ACKTYPE_AVATAR, ACKRESULT_SUCCESS, (HANDLE)&ai, (LPARAM)NULL);

						}
						mir_free(pszFile);
					}

#endif

					DBGetContactSetting(hContact, C6PROTOCOLNAME, "C6Flags", &dbv);
					dbv.cVal |= C6FLAGS_AVATAR;
					DBWriteContactSettingByte(hContact, C6PROTOCOLNAME, "C6Flags", (BYTE)dbv.cVal);
		            DBFreeVariant(&dbv);

				}

			 	}
			 	break;
		 	case 11 : // Network
		    	{
              		char idstr[33];
			  		char szbuf[50];

			  		_snprintf(idstr, 33, "Interest%dCat", icat);
			  		writeDbInfoSettingString(hContact, idstr, Translate("Network"));

			  		_snprintf(idstr, 33, "Interest%dText", icat);
			  		_snprintf(szbuf, 50, "%d", p->info);
			  		writeDbInfoSettingString(hContact, idstr, szbuf);
			  		icat++;

			  		DBVARIANT dbv;

			  		DBGetContactSetting(hContact, C6PROTOCOLNAME, "C6Flags", &dbv);
			  		dbv.cVal |= C6FLAGS_NETWORK;
			  		DBWriteContactSettingByte(hContact, C6PROTOCOLNAME, "C6Flags", (BYTE)dbv.cVal);
		      		DBFreeVariant(&dbv);
			 	}
			 	break;
		 	case 0x0F	 : // client version
		    	{

					BYTE client = p->info;
					BOOL okSetClient = TRUE;

					if (client == ID_CLIENT_OC6)

						if (!((usrd->status & C6_OFFLINE)==C6_OFFLINE)) {

							if (((usrd->status & 0x200)==0x200)) // new_version >= 0.1.0.4
								client = ID_CLIENT_MIRANDA;

						} else okSetClient = FALSE;

					if (client == ID_CLIENT_CM10)
						if (!((usrd->status & C6_OFFLINE)==C6_OFFLINE)) {
							if (((usrd->status & 0x200)==0x200)) // new_version >= 0.2.0.0
								client = ID_CLIENT_MIRANDA;
						} else okSetClient = FALSE;

					if (okSetClient) { // if (client == ID_CLIENT_OC6 && status == C6_OFFLINE) skip!

#ifndef _C6_FINGERPRINT
						DBWriteContactSettingByte(hContact, C6PROTOCOLNAME, "IDClientMod", client);
#endif
						writeDbInfoSettingString(hContact, "MirVer", getStringName(client, clientIDField));

#ifdef _C6_FULL

#ifndef _C6_FINGERPRINT
			 			if(ServiceExists(MS_CLIST_EXTRA_SET_ICON)) {

							IconExtraColumn iec;

							iec.cbSize = sizeof(iec);

							if (IDClientToPosImg(client)>=0)
								iec.hImage = hExtraImage[IDClientToPosImg(client)];
							else iec.hImage = (HANDLE)-1;
							iec.ColumnType = EXTRA_ICON_ADV1;

							if (CallService(MS_CLIST_EXTRA_SET_ICON, (WPARAM)hContact, (LPARAM)&iec))
								c6LogMsg("Error: SetIcon");
			 			}
#endif

#endif
					} // onSetClient
				}
			 	break;
		 	case 3	 : // Orientation
		    	{
              	char idstr[33];
			  	char szbuf[50];

			  	_snprintf(idstr, 33, "Interest%dCat", icat);
			  	writeDbInfoSettingString(hContact, idstr, Translate("Orientation"));

			  	_snprintf(idstr, 33, "Interest%dText", icat);
			  	_snprintf(szbuf, 50, "%s", (p->info == 2)?Translate("Men"):Translate("Women"));
			  	writeDbInfoSettingString(hContact, idstr, szbuf);
			  	icat++;
			 	}
			 	break;
		 	default	 :
		    	{

    			DBVARIANT dbv;

				DBGetContactSetting(hContact, C6PROTOCOLNAME, "C6Flags", &dbv);
				dbv.cVal |= C6FLAGS_EXTRAX;

				DBWriteContactSettingByte(hContact, C6PROTOCOLNAME, "C6Flags", (BYTE)dbv.cVal);
		        DBFreeVariant(&dbv);

			 	}
			 	break;

			} // switch

		p++;

    } // for

	ProtoBroadcastAck(C6PROTOCOLNAME, hContact, ACKTYPE_GETINFO, ACKRESULT_SUCCESS, (HANDLE)1 ,0);

	return 0;
}

//--------------------------------------------------------------------
//                           C6GetInfo
//--------------------------------------------------------------------

int C6GetInfo(WPARAM wParam, LPARAM lParam)
{

	if (lParam && amIOnline())
	{

		CCSDATA* ccs = (CCSDATA*)lParam;
        DBVARIANT dbv;
		char szNick[40]; // 20

		BOOL bChatRoom = (DBGetContactSettingByte(ccs->hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 1);

        if(!DBGetContactSetting(ccs->hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
			strcpy(szNick,dbv.pszVal);
			DBFreeVariant(&dbv);
         }

		if (!bChatRoom && strlen(szNick))
		{

			c6SendGetInfoServ(szNick);

			return 0; // Success

		}

	}

	return 1; // Failure

}

//--------------------------------------------------------------------
//                           SendMsgThread
//--------------------------------------------------------------------

DWORD WINAPI SendMsgThread (LPVOID param)
{

	CallService (MS_SYSTEM_THREAD_PUSH, 0, 0);

	WORD wRecipientStatus;
	WORD ret;

	SendMsgData* data = (SendMsgData*) (param);

	wRecipientStatus = DBGetContactSettingWord(data->contact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE);

	if (c6Status == ID_STATUS_OFFLINE) {

	    ProtoBroadcastAck(C6PROTOCOLNAME, data->contact, ACKTYPE_MESSAGE, ACKRESULT_FAILED, (HANDLE)data->cookie, (LPARAM)Translate("You cannot send messages when you are offline."));
		ret = 0;

		}
	else if (strlen(data->text) > 512) {

		ProtoBroadcastAck(C6PROTOCOLNAME, data->contact, ACKTYPE_MESSAGE, ACKRESULT_FAILED, (HANDLE)data->cookie, (LPARAM)Translate("Messages to contacts must be shorter than 512 characters."));
		ret = 0;

		}
    // Looks OK
	else {

		if (wRecipientStatus == ID_STATUS_OFFLINE) {

       		c6LogMsg("Contact Offline");
	  		LogPopup(0, POPUPCOLOR_ORANGE, Translate("Contact is Offline, message sended anyway."));
			ret = c6SendMessageServ(OF_MESSAGE, data->szUser, data->szNick, data->text);

		}
		else {
			ret = c6SendMessageServ(OL_MESSAGE, data->szUser, data->szNick, data->text);

		}
	}

	Sleep(500);

	if (ret)
		ProtoBroadcastAck (C6PROTOCOLNAME, data->contact, ACKTYPE_MESSAGE, ACKRESULT_SUCCESS,
			(HANDLE)data->cookie, 0);
	else
		ProtoBroadcastAck (C6PROTOCOLNAME, data->contact, ACKTYPE_MESSAGE, ACKRESULT_FAILED,
			(HANDLE)data->cookie, (LPARAM) Translate ("Cannot send message"));

	mir_free(data->text);
	mir_free(data);

	CallService (MS_SYSTEM_THREAD_POP, 0, 0);

	return 0;

}

//--------------------------------------------------------------------
//                           C6SendMessage
//--------------------------------------------------------------------

int C6SendMessage(WPARAM wParam, LPARAM lParam)
{
	CCSDATA* ccs = (CCSDATA*) lParam;
	if (ccs && ccs->hContact && ccs->lParam) {

		HANDLE cookie = GenerateCookie();
		DBVARIANT dbv;

		SendMsgData* data = (SendMsgData*)mir_alloc(sizeof(SendMsgData));

        if(!DBGetContactSetting(ccs->hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
			strcpy(data->szNick,dbv.pszVal);
			DBFreeVariant(&dbv);
        }

    	if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
	    	strcpy(data->szUser,dbv.pszVal);
		    DBFreeVariant(&dbv);
		}

		data->contact = ccs->hContact;
		data->text = mir_strdup((LPSTR)(ccs->lParam));
		data->cookie = cookie;
		DWORD id;
		CloseHandle (CreateThread (NULL, 0, SendMsgThread, data, 0, &id));
		return (int) cookie;
	}
	return 0;
}

//--------------------------------------------------------------------
//                           C6RecvMessage
//--------------------------------------------------------------------

int C6RecvMessage(WPARAM wParam, LPARAM lParam)
{

	DBEVENTINFO dbei;
	CCSDATA* ccs = (CCSDATA*)lParam;
	PROTORECVEVENT* pre = (PROTORECVEVENT*)ccs->lParam;

	DBDeleteContactSetting(ccs->hContact, "CList", "Hidden");

	ZeroMemory(&dbei, sizeof(dbei));
	dbei.cbSize = sizeof(dbei);
	dbei.szModule = C6PROTOCOLNAME;
	dbei.timestamp = pre->timestamp;
	dbei.flags = pre->flags & (PREF_CREATEREAD ? DBEF_READ : 0);
	dbei.eventType = EVENTTYPE_MESSAGE;
	dbei.cbBlob = strlen(pre->szMessage) + 1;
	dbei.pBlob = (PBYTE)pre->szMessage;

	CallService(MS_DB_EVENT_ADD, (WPARAM)ccs->hContact, (LPARAM)&dbei);

	if (checkContactTyping(ccs->hContact))
    	CallService(MS_PROTO_CONTACTISTYPING, (WPARAM)ccs->hContact, PROTOTYPE_CONTACTTYPING_OFF);

	return 0;

}

//--------------------------------------------------------------------
//                           C6SearchByEmail
//--------------------------------------------------------------------

int C6SearchByEmail(WPARAM wParam, LPARAM lParam)
{

	if (lParam && amIOnline() && (strlen((char*)lParam) > 0))
	{

		// Success
		LPSTR pszEmail = (char *)lParam;

		mir_free(pszemail);
		pszemail = (char*)mir_alloc(strlen(pszEmail) + 1);
		strcpy(pszemail, pszEmail);

		return c6SendSrcByEmail2Serv(pszemail);

	}

	return 0; // Failure

}

//--------------------------------------------------------------------
//                           C6BasicSearch
//--------------------------------------------------------------------

int C6BasicSearch(WPARAM wParam, LPARAM lParam)
{

  	if (lParam) {

		char* pszSearch = (char*)lParam;

    	if (strlen(pszSearch)) {

			int nHandle = 0;
	  		char szUser[40]; // 20
			GetUserNickName(szUser);

	  		if (amIOnline()) {

		  		nHandle = c6SearchByNick(szUser, pszSearch);

			}

        	// Success
        	return nHandle;
      	}

	}

  	// Failure
  	return 0;

}

//--------------------------------------------------------------------
//                           C6AddToList
//--------------------------------------------------------------------
// WARNING: don't work in clist_modern -> No Hidden but Show
int C6AddToList(WPARAM wParam, LPARAM lParam)
{

	if (lParam) {

		C6SEARCHRESULT *isr = (C6SEARCHRESULT*)lParam;

		if (isr->hdr.cbSize == sizeof(C6SEARCHRESULT)){
			int ret = (int)AddToListDirect(wParam, isr->hdr.nick, "");

		    SetNetFriendStatus(isr->hdr.nick, isr->status, 0, NULL);

		    return ret;
		}
	}

	return 0; // Failure

}

//--------------------------------------------------------------------
//                           C6AddedToList
//--------------------------------------------------------------------

int C6AddedToList(WPARAM wParam, LPARAM lParam)
{

	c6LogMsg("You Were Added!");

	return 0; // Failure

}


//--------------------------------------------------------------------
//                           LoadC6Services
//--------------------------------------------------------------------

static int c6DbContactDeleted(WPARAM wParam, LPARAM lParam)
{

	DBVARIANT dbv;
	char szNick[40]; // 20

    if(!DBGetContactSetting((HANDLE)wParam, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
		strcpy(szNick, dbv.pszVal);
		c6LogMsg(szNick);
		DBFreeVariant(&dbv);
    }

	LPSTR pszFile;

	GetFullAvatarFileName(szNick, &pszFile, 255);

	if (DeleteFile(pszFile)) {
		c6LogMsg(pszFile);
		c6LogMsg("...Deleted !");
	}

	mir_free(pszFile);

	if (amIOnline()) {

   	    c6RemoveNetFriend(szNick);
		removeContactSS((HANDLE)wParam, szNick);

	}

	return 0;
}

//--------------------------------------------------------------------
//                          HandleFileRequest
//--------------------------------------------------------------------

void HandleFileRequest(LPSTR pszSender, LPSTR pszDescription)
{

	char* pszFileName = NULL;

	HANDLE hContact = HContactfNickNoAdd(pszSender);
	if (CallService(MS_IGNORE_ISIGNORED, (WPARAM)hContact, (LPARAM)IGNOREEVENT_FILE)){

		c6LogMsg("File sender ignoring...");
		c6LogMsg("nick: %s", pszSender);
		return ;

	}

	if (!pszDescription || (strlen(pszDescription) == 0))
		pszDescription = Translate("No description given");

	pszFileName = mir_alloc(MAX_PATH);

	char *p;
	if ((p = strstr(pszDescription, "Vuoi ricevere il file")) != NULL) {

		strcpy(pszFileName, p + 22);
		p=strtok(pszFileName, " ");
		if (p)
			strcpy(pszFileName, p);
		c6LogMsg(pszFileName);

	}
	else {

		strcpy(pszFileName, "unknown");

	}

	CCSDATA ccs;
	PROTORECVEVENT pre;
	char* szBlob;

	C6FileTransfer *ft = (C6FileTransfer *)mir_alloc(sizeof(C6FileTransfer));
	memset(ft, 0, sizeof(C6FileTransfer));

	// Send chain event
	szBlob = (char*)mir_alloc(sizeof(DWORD) + strlen(pszFileName) + strlen(pszDescription) + 2);
	*(PDWORD)szBlob = (DWORD)ft;
	strcpy(szBlob + sizeof(DWORD), pszFileName);
	strcpy(szBlob + sizeof(DWORD) + strlen(pszFileName) + 1, pszDescription);
	ccs.szProtoService = PSR_FILE;
	ccs.hContact = hContact;
	ccs.wParam = 0;
	ccs.lParam = (LPARAM)&pre;
	pre.flags = 0;
	pre.timestamp = time(NULL);
	pre.szMessage = szBlob;
	pre.lParam = 0;

	ft->hContact = ccs.hContact;
	ft->pszSender = mir_strdup(pszSender);
	AllocateCookie(OP_FILE, ft->pszSender, ft);

	CallService(MS_PROTO_CHAINRECV, 0, (LPARAM)&ccs);
	mir_free(szBlob);
	szBlob=NULL;

	mir_free(pszFileName);
	pszFileName=NULL;

}

//--------------------------------------------------------------------
//                           C6RecvFile
//--------------------------------------------------------------------

int C6RecvFile(WPARAM wParam, LPARAM lParam)
{
	DBEVENTINFO dbei;
	CCSDATA* ccs = (CCSDATA*)lParam;
	PROTORECVEVENT* pre = (PROTORECVEVENT*)ccs->lParam;
	char* szDesc;
	char* szFile;

	DBDeleteContactSetting(ccs->hContact, "CList", "Hidden");

	szFile = pre->szMessage + sizeof(DWORD);
	szDesc = szFile + strlen(szFile) + 1;

	ZeroMemory(&dbei, sizeof(dbei));
	dbei.cbSize = sizeof(dbei);
	dbei.szModule = C6PROTOCOLNAME;
	dbei.timestamp = pre->timestamp;
	dbei.flags = (pre->flags & PREF_CREATEREAD) ? DBEF_READ : 0;
	dbei.eventType = EVENTTYPE_FILE;
	dbei.cbBlob = sizeof(DWORD) + strlen(szFile) + strlen(szDesc) + 2;
	dbei.pBlob = (PBYTE)pre->szMessage;

	CallService(MS_DB_EVENT_ADD, (WPARAM)ccs->hContact, (LPARAM)&dbei);

	return 0;
}

//--------------------------------------------------------------------
//                            C6FileAllow
//--------------------------------------------------------------------

int C6FileAllow(WPARAM wParam, LPARAM lParam)
{
	if (lParam)
	{
		CCSDATA* ccs = (CCSDATA*)lParam;
    	DBVARIANT dbv;
		char szUser[32];

    	if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
	    	strcpy(szUser,dbv.pszVal);
			DBFreeVariant(&dbv);
		}

		if (strlen(szUser) && amIOnline() && ccs->hContact && ccs->lParam && ccs->wParam) {
			char szNickSender[32];

    		if(!DBGetContactSetting(ccs->hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
	    		strcpy(szNickSender,dbv.pszVal);
				DBFreeVariant(&dbv);
			}

	 		if (!c6activateFileReception(szUser, szNickSender, wListenPort))
				return 0; // Failure

			return ccs->wParam; // Success = ft var.
		}
	}

	return 0; // Failure
}

//--------------------------------------------------------------------
//                             C6FileDeny
//--------------------------------------------------------------------

int C6FileDeny(WPARAM wParam, LPARAM lParam)
{
	int nReturnValue = 1;

	if (lParam)
	{
		CCSDATA *ccs = (CCSDATA *)lParam;
		C6FileTransfer* ft = ((C6FileTransfer *)ccs->wParam);
    	DBVARIANT dbv;
		char szUser[32];

    	if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
	    	strcpy(szUser,dbv.pszVal);
			DBFreeVariant(&dbv);
		}

		if (strlen(szUser) && amIOnline() && ccs->hContact && ccs->wParam) {

			char szNickSender[32];

    		if(!DBGetContactSetting(ccs->hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
	    		strcpy(szNickSender,dbv.pszVal);
				DBFreeVariant(&dbv);
			}

			c6LogMsg(szNickSender);
	 		if (!c6activateFileReception(szUser,szNickSender,0))
				return 0; // Failure

			c6CancelFileTransfer(ccs->hContact, ft);

			nReturnValue = 0; // Success
		}

	}

	return nReturnValue;
}

//--------------------------------------------------------------------
//                            C6FileCancel
//--------------------------------------------------------------------

int C6FileCancel(WPARAM wParam, LPARAM lParam)
{

	if (lParam && amIOnline()) {
		CCSDATA* ccs = (CCSDATA*)lParam;
    	DBVARIANT dbv;
		char szNick[32];

    	if(!DBGetContactSetting(ccs->hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
	    	strcpy(szNick,dbv.pszVal);
			DBFreeVariant(&dbv);
		}

		if (ccs->hContact && strlen(szNick) && ccs->wParam)	{

			C6FileTransfer * ft = (C6FileTransfer * ) ccs->wParam;

			c6CancelFileTransfer(ccs->hContact, ft);

			return 0; // Success

		}
	}

	return 1; // Failure
}

//--------------------------------------------------------------------
//                             C6SendFile
//--------------------------------------------------------------------

int C6SendFile(WPARAM wParam, LPARAM lParam)
{
	if (lParam && amIOnline())
	{
		CCSDATA* ccs = (CCSDATA*)lParam;

		if (ccs->hContact && ccs->lParam && ccs->wParam)
		{
			HANDLE hContact = ccs->hContact;
			char** files = (char**)ccs->lParam;
    		DBVARIANT dbv;
			char szNick[32];

			char szUser[32];

			if (DBGetContactSettingByte(ccs->hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 1) {
				MessageBox(0, "File won't sended to ChatRoom", "Error", MB_ICONSTOP);
				return 0;
			}

	    	if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
		    	strcpy(szUser,dbv.pszVal);
				DBFreeVariant(&dbv);
			}

    		if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
	    		strcpy(szNick, dbv.pszVal);
				DBFreeVariant(&dbv);
			}


			if (strlen(szNick))	{

				if (DBGetContactSettingWord(hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE) != ID_STATUS_OFFLINE) {

					C6FileTransfer *ft = (C6FileTransfer *)mir_alloc(sizeof(C6FileTransfer));
					if (ft==NULL){
						LogPopup(0, POPUPCOLOR_ORANGE, Translate("File Transfer: No Memory available."));
						return 0;
					}

					ft->pszFileName = (LPSTR)mir_alloc(MAX_PATH);
				    ft->pszFileName = files[0];
					ft->pszSender = mir_strdup(szUser);
					ft->pszReceiver = mir_strdup(szNick);
					AllocateCookie(OP_FILE, ft->pszReceiver, ft);

					if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", 0)) { // meglio una variabile !!!!

						LPSTR pszThisFileName, pszMsg = mir_alloc(MAX_PATH);

						if ((pszThisFileName = strrchr(ft->pszFileName, '\\')) == NULL)
							pszThisFileName = ft->pszFileName;
						else pszThisFileName++;

						mir_snprintf(pszMsg, MAX_PATH, "Vuoi ricevere il file %s ? c6cmd://Accept?Type=FILE&Value=YES c6cmd://Accept?Type=FILE&Value=NO", pszThisFileName);

						c6SendMessage2Serv(OL_MESSAGE, SELF_MSG, REQUEST_FILE, szUser, szNick, pszMsg);
						mir_free(pszMsg);

    				} else
						c6SendFileServ(szUser, szNick);

					return (int)(HANDLE)ft; // Success
				}
			}
		}
	}

	return 0; // Failure
}

//--------------------------------------------------------------------
//                            C6SendUserIsTyping
//--------------------------------------------------------------------

void handleTypingNotification(LPSTR szNick, LPSTR szMsg)
{

  	HANDLE hContact;

	hContact = HContactFromNick(0, szNick);

	if (!DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "UserTyping", 0))
		setContactTyping(hContact, 1);

  	// Notify user
	if (!strcmp(szMsg,"sta scrivendo...")) {
    	CallService(MS_PROTO_CONTACTISTYPING, (WPARAM)hContact, (LPARAM)10);
		c6LogMsg("%s typing a message...", szNick);
	}

  return;

}


int C6SendUserIsTyping(WPARAM wParam, LPARAM lParam)
{

  	int nResult = 1;
  	HANDLE hContact = (HANDLE)wParam;

  	if (hContact && amIOnline())
		if (DBGetContactSettingWord(hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE)!=ID_STATUS_OFFLINE)
		   if (checkContactTyping(hContact)) {

   				DBVARIANT dbv;
				char szNick[40];
				char szUser[40];

    			if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
	    			strcpy(szUser,dbv.pszVal);
					DBFreeVariant(&dbv);
				}

		   		if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
		    		strcpy(szNick, dbv.pszVal);
					DBFreeVariant(&dbv);
				}

		      	switch (lParam) {
		      	case PROTOTYPE_SELFTYPING_ON:
					c6LogMsg("SELFTYPING ON");
		        	c6sendTypingNotification(szUser, szNick);
		        	nResult = 0;
		        break;

		      	case PROTOTYPE_SELFTYPING_OFF:
					c6LogMsg("SELFTYPING OFF");
		        	nResult = 0;
		        break;

		      	default:
		        break;
		      	}

			}

  	return nResult;

}

//--------------------------------------------------------------------
//                            C6SendAuthRequest
//--------------------------------------------------------------------

int C6SendAuthRequest(WPARAM wParam, LPARAM lParam)
{
  	if (lParam && amIOnline()) {

		int ssc = (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", 0));

    	CCSDATA* ccs = (CCSDATA*)lParam;

    	if (ccs->hContact && ssc) {

			DBVARIANT dbv;
			char szNick[40]; // 20

		    if(!DBGetContactSetting(ccs->hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
				strcpy(szNick, dbv.pszVal);
				DBFreeVariant(&dbv);

			    if(!DBGetContactSetting(ccs->hContact, "CList", "Group", &dbv)) {

					LPSTR pszGroupName = mir_alloc(256);

					strcpy(pszGroupName, dbv.pszVal);
					DBFreeVariant(&dbv);

					if (!c6AddXCAPBuddy(szNick, pszGroupName))
						c6LogMsg("...Added buddy to Server List!");

					mir_free(pszGroupName);

			        return 0; // Success
				}

			}

    	}
  	}

  	return 1; // Failure
}

void handleRecvAuthRequest(char *szNick)
{
	CCSDATA ccs;
	PROTORECVEVENT pre;
	BOOL bNF;

	bNF = isNetFriend(szNick);

	DWORD i = (bSecretariat && !bNF && (c6Status != ID_STATUS_ONLINE));

	c6LogMsg("nick: %s auth request...", szNick);

	ccs.hContact = HContactFromNick(i, szNick);

	if (CallService(MS_IGNORE_ISIGNORED, (WPARAM)ccs.hContact, (LPARAM)IGNOREEVENT_AUTHORIZATION)){

		c6LogMsg("Ignore...");
		c6LogMsg("nick: %s", szNick);
		return ;

	}

	ccs.szProtoService = PSR_AUTH;
  	ccs.wParam = 0;
  	ccs.lParam = (LPARAM)&pre;
  	pre.flags = 0;
  	pre.timestamp = time(NULL);

	//blob is: UIN=0(DWORD), hContact(DWORD), nick(ASCIIZ), ""(ASCIIZ), ""(ASCIIZ), ""(ASCIIZ), ""(ASCIIZ)
	pre.lParam = sizeof( DWORD ) * 2 + strlen( szNick ) + 5;

	PBYTE pCurBlob = ( PBYTE )mir_alloc( pre.lParam );
	pre.szMessage = ( char* )pCurBlob;

	*( PDWORD )pCurBlob = 0; pCurBlob+=sizeof( DWORD );
	*( PDWORD )pCurBlob = ( DWORD )ccs.hContact; pCurBlob+=sizeof( DWORD );
	strcpy(( char* )pCurBlob, szNick); pCurBlob += strlen( szNick )+1;
	*pCurBlob = '\0'; pCurBlob++;	   //firstName
	*pCurBlob = '\0'; pCurBlob++;	   //lastName
	*pCurBlob = '\0'; pCurBlob++;	   //email
	*pCurBlob = '\0';         	       //reason

	// TODO: Change for new auth system, include all known informations
  	CallService(MS_PROTO_CHAINRECV, 0, (LPARAM)&ccs);

}

int c6RecvAuth(WPARAM wParam, LPARAM lParam)
{

    c6LogMsg("c6RecvAuth");

	DBEVENTINFO dbei = { 0 };
	CCSDATA *ccs = (CCSDATA*)lParam;
	PROTORECVEVENT *pre = (PROTORECVEVENT*)ccs->lParam;

	DBDeleteContactSetting(ccs->hContact, "CList", "Hidden");

	dbei.cbSize = sizeof(dbei);
	dbei.szModule = C6PROTOCOLNAME;
	dbei.timestamp = pre->timestamp;
	dbei.flags = pre->flags & ( PREF_CREATEREAD ? DBEF_READ : 0 );
	dbei.eventType = EVENTTYPE_AUTHREQUEST;

	/* Just copy the Blob from PSR_AUTH event. */
	dbei.cbBlob = pre->lParam;
	dbei.pBlob = (PBYTE)pre->szMessage;
	CallService(MS_DB_EVENT_ADD, 0, (LPARAM)&dbei);

	return 0;
}

int c6AuthAllow(WPARAM wParam, LPARAM lParam)
{
  	if (amIOnline() && (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", 0)) && wParam) {

		DBEVENTINFO dbei;
		memset(&dbei, 0, sizeof(DBEVENTINFO));
		dbei.cbSize = sizeof(dbei);

		if (( dbei.cbBlob = CallService(MS_DB_EVENT_GETBLOBSIZE, wParam, 0)) == -1 )
			return 1;

		dbei.pBlob = (PBYTE)mir_alloc( dbei.cbBlob );
		if ( CallService(MS_DB_EVENT_GET, wParam, (LPARAM)&dbei ))
			return 1;

		if ( dbei.eventType != EVENTTYPE_AUTHREQUEST )
			return 1;

		if (strcmp( dbei.szModule, C6PROTOCOLNAME ))
			return 1;

		HANDLE hContact = ( dbei.pBlob + sizeof( DWORD ) );
		char* nick = ( char* )( dbei.pBlob + sizeof( DWORD )*2 );

	    if (strlen(nick)==0)
			return 1;

		if (!findWhiteList(nick))
			c6AddXCAPWhiteList(nick);
		else c6LogMsg("Already authorized: %s", nick);

    	return 0; // Success
  	}

  	return 1; // Failure
}

//--------------------------------------------------------------------
//                           c6DbGroupChange
//--------------------------------------------------------------------

int c6DbGroupChange(WPARAM wParam,LPARAM lParam)
{
	if (!amIOnline() || !(DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "XCAP_ServerSideCList", 0)) ) return 0;

	const HANDLE hContact = (HANDLE)wParam;
	const CLISTGROUPCHANGE* grpchg = (CLISTGROUPCHANGE*)lParam;

	if (hContact == NULL)
	{
		if (grpchg->pszNewName == NULL && grpchg->pszOldName != NULL)
		{

			char* szOldName = get2Ansi(grpchg->pszOldName);

			if (del1SrvGroup(szOldName))
				if (!c6RemoveXCAPGroup(szOldName))
					c6LogMsg("Remove group: %s", szOldName);

			mir_free(szOldName);

		}
		else if (grpchg->pszNewName != NULL && grpchg->pszOldName != NULL)
		{

			char* szNewName = get2Ansi(grpchg->pszNewName);
			char* szOldName = get2Ansi(grpchg->pszOldName);

			if (renameSrvGroup(szOldName, szNewName))
				if (!c6RenameXCAPGroup(szOldName, szNewName))
					c6LogMsg("Rename group from %s to %s", szOldName, szNewName);

			mir_free(szOldName);
			mir_free(szNewName);

		}
	}
	else
	{
		char* szProto;
		char szNick[40];

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME)) { // c6 contact !

			if (checkContactSS(hContact)) {

				DBVARIANT dbv;
	        	if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
					strcpy(szNick, dbv.pszVal);
					DBFreeVariant(&dbv);

					char* szOldName = grpchg->pszOldName ? get2Ansi(grpchg->pszOldName) : NULL;
					if (szOldName && !c6RemoveXCAPBuddy(szNick, szOldName)) {
						c6LogMsg("Remove from old group: %s", szOldName);
						mir_free(szOldName);
					}

					char* szNewName = grpchg->pszNewName ? get2Ansi(grpchg->pszNewName) : NULL;
					if (szNewName && !c6AddXCAPBuddy(szNick, szNewName)) {
						c6LogMsg("Added to new group: %s", szNewName);

						if (!findSrvGroup(szNewName))
							addSrvGroup(szNewName);

						mir_free(szNewName);
					}
				}
			}
		}

	}
	return 0;
}

#ifdef _C6_FULL

//--------------------------------------------------------------------
//                           c6GetMyAvatar
//--------------------------------------------------------------------

int c6GetMyAvatar(WPARAM wParam, LPARAM lParam)
{

	char *buffer = (char *)wParam;
	int size = (int)lParam;

	if (!gbAvatarsEnabled) return -2;

	if (buffer == NULL || size <= 0)
		return -3;

	DBVARIANT dbv;
	int ret = -3;

	if (!DBGetContactSettingString(NULL, C6PROTOCOLNAME, "AvatarFile", &dbv)) {

		if (access(dbv.pszVal, 0) == 0) {
			strncpy(buffer, dbv.pszVal, size-1);
			buffer[size-1] = '\0';

			ret = 0;
		}
		DBFreeVariant(&dbv);

		if (ret)
			DBDeleteContactSetting(NULL, C6PROTOCOLNAME, "AvatarFile");
	}
	else { // prova a prelevarlo dalla rete...
		LPSTR pszFile = LoadMyAvatar();
		if (pszFile) {
			strncpy(buffer, pszFile, size-1);

			writeDbInfoSettingString(NULL, "AvatarFile", pszFile);
			mir_free(pszFile);
			c6LogMsg("My Avatar was downloaded");

			ret = 0;
		}
	}

	return ret;

}

#endif

//--------------------------------------------------------------------
//                           c6WindowEvent
//--------------------------------------------------------------------

int c6WindowEvent(WPARAM wParam, LPARAM lParam)
{
	MessageWindowEventData* msgEvData  = (MessageWindowEventData*)lParam;

	if (!amIOnline()) return 0;

	if(DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "TypingNotify", 0))
	if ( msgEvData->uType == MSG_WINDOW_EVT_OPENING ) {

		char* szProto;

		szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)msgEvData->hContact, 0);
		if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME)) { // c6 contact !

			DBVARIANT dbv;
			char szNick[40]; // 20

			if (!checkContactTyping(msgEvData->hContact))
		    if(!DBGetContactSetting(msgEvData->hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
				strcpy(szNick, dbv.pszVal);

				DBFreeVariant(&dbv);
				requestClient(szNick);
				c6SendGetInfoServ(szNick);
			}
		}

	}
	return 0;
}

//--------------------------------------------------------------------
//                          HandleInviteMessage
//--------------------------------------------------------------------

#ifdef _C6_ROOM

int HandleInviteMessage(char *szNick, char *szMsg)
{

	LPSTR pszRoomName = NULL;
	LPSTR pszComment = NULL;

	HANDLE hContact = HContactfNickNoAdd(szNick);
	if (CallService(MS_IGNORE_ISIGNORED, (WPARAM)hContact, (LPARAM)IGNOREEVENT_MESSAGE)){

		c6LogMsg("Ignoring... %s", szNick);
		return 1;

	}

	c6LogMsg(szMsg);

	char *p;
	if ((p = strstr(szMsg, "room://")) != NULL) {

		pszRoomName = mir_alloc(MAX_PATH);
		strcpy(pszRoomName, p + 7);
		p = strtok(pszRoomName, "\"");
		if (p)
			strcpy(pszRoomName, p);
		c6LogMsg("room: %s (%d)", pszRoomName, strlen(pszRoomName));

		pszComment = p + (strlen(pszRoomName) + 3);
		if (pszComment)
			c6LogMsg("%s (%d)", pszComment, strlen(pszComment));
		else pszComment = "";

	} else return 2;

	DBEVENTINFO dbei;

	int dim = strlen(pszRoomName) + strlen(pszComment) + 2;
	PBYTE pBlob = (PBYTE)mir_alloc(dim);

	dbei.cbSize = sizeof(dbei);
	dbei.pBlob = pBlob;
	dbei.cbBlob = dim;

	strcpy(( char* )pBlob, pszRoomName); pBlob += strlen( pszRoomName ) + 1;
	strcpy(( char* )pBlob, pszComment);

	dbei.eventType = C6_DB_EVENT_TYPE_CHATSTATES;
	dbei.flags = 0;
	dbei.timestamp = time(NULL);
	dbei.szModule = C6PROTOCOLNAME;
	CallService(MS_DB_EVENT_ADD, (WPARAM)hContact, (LPARAM)&dbei);

	mir_free(pszRoomName);
	return 0;

}

#endif

//--------------------------------------------------------------------
//                           InitServerLists
//--------------------------------------------------------------------

void InitServerLists(void)
{

  	hHookContactDeleted = HookEvent(ME_DB_CONTACT_DELETED, c6DbContactDeleted);
	hHookGroupChange = HookEvent(ME_CLIST_GROUPCHANGE, c6DbGroupChange);
	hHookMsgWnd = HookEvent(ME_MSG_WINDOWEVENT, c6WindowEvent);

}

void UninitServerLists(void)
{

  	if (hHookContactDeleted)
    	UnhookEvent(hHookContactDeleted);
	if (hHookGroupChange)
		UnhookEvent(hHookGroupChange);
	if (hHookMsgWnd)
		UnhookEvent(hHookMsgWnd);

}

//--------------------------------------------------------------------
//                           LoadC6Services
//--------------------------------------------------------------------

int LoadC6Services(void)
{

	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_GETCAPS, (MIRANDASERVICE)C6GetCaps);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_GETNAME, (MIRANDASERVICE)C6GetName);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_LOADICON, (MIRANDASERVICE)C6LoadIcon);

	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_SETSTATUS, (MIRANDASERVICE)C6SetStatus);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_GETSTATUS, (MIRANDASERVICE)C6GetStatus);

	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_BASICSEARCH, (MIRANDASERVICE)C6BasicSearch);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_CREATEADVSEARCHUI, (MIRANDASERVICE)C6CreateAdvSearchUI);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_SEARCHBYADVANCED, (MIRANDASERVICE)C6SearchByAdvanced);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_SEARCHBYEMAIL, (MIRANDASERVICE)C6SearchByEmail);

	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_MESSAGE, (MIRANDASERVICE)C6SendMessage);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PSR_MESSAGE, (MIRANDASERVICE)C6RecvMessage);

	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_GETINFO, (MIRANDASERVICE)C6GetInfo);

	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_ADDTOLIST, (MIRANDASERVICE)C6AddToList);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_ADDED, (MIRANDASERVICE)C6AddedToList);

	CreateProtoServiceFunction(C6PROTOCOLNAME, PSR_FILE, (MIRANDASERVICE)C6RecvFile);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_FILEALLOW, (MIRANDASERVICE)C6FileAllow);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_FILEDENY, (MIRANDASERVICE)C6FileDeny);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_FILECANCEL, (MIRANDASERVICE)C6FileCancel);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_FILE, (MIRANDASERVICE)C6SendFile);

	CreateProtoServiceFunction(C6PROTOCOLNAME, PSR_AUTH, (MIRANDASERVICE)c6RecvAuth);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_AUTHREQUEST, (MIRANDASERVICE)C6SendAuthRequest);
	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_AUTHALLOW, (MIRANDASERVICE)c6AuthAllow);

#ifdef _C6_FULL
	CreateProtoServiceFunction(C6PROTOCOLNAME, PS_GETMYAVATAR, (MIRANDASERVICE)c6GetMyAvatar);
#endif

	CreateProtoServiceFunction(C6PROTOCOLNAME, PSS_USERISTYPING, (MIRANDASERVICE)C6SendUserIsTyping);

	return 0;
}



