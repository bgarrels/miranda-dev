/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_XCAP_H
#define __C6_XCAP_H

#define CONFIG_NOWARNING    0
#define CONFIG_NOTIFICATION 1
#define CONFIG_AUTHORIZE    2

#define CONFIG_EMAIL      0
#define CONFIG_MESSENGER  1

void setXCAPPassword(LPSTR pszNick, LPSTR pszPassword);

WORD c6GetXCAPConfig(LPSTR pszUser);
WORD c6SetXCAPConfig(LPSTR pszUser, int nsel, int mode);
WORD c6GetXCAPBL(LPSTR pszUser);
WORD c6RemoveXCAPBuddy(LPSTR pszNick, LPSTR pszGroup);
WORD c6AddXCAPBuddy(LPSTR pszNick, LPSTR pszGroup);

WORD c6AddXCAPWhiteList(LPSTR pszNick);
WORD c6AddXCAPBlackList(LPSTR pszNick);

WORD c6DelXCAPWhiteList(LPSTR pszNick);
WORD c6DelXCAPBlackList(LPSTR pszNick);

WORD c6RemoveXCAPGroup(LPSTR pszGroup);
WORD c6RenameXCAPGroup(LPSTR pszOldGroup, LPSTR pszNewGroup);

WORD c6GetXCAPAuthList(int type, LPSTR pszUser, HWND hwndList);
WORD c6SrvBlackList(BOOL bWhiteList, LPSTR pszUser);

#endif /* __C6_XCAP_H */

