/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

#include <sys/stat.h>

enum {

   FILE_TR_INIT = 0x01,
   FILE_TR_CHUNK = 0x02,
   FILE_TR_OK = 0x03,
   FILE_TR_END = 0x04,
   FILE_TR_BAD = 0x05,
   FILE_TR_STOP = 0x06

};

typedef struct directthreadstartinfo_t
{
	int incoming;       // incoming = 1, outgoing = 0
	HANDLE hConnection;
	HANDLE hContact;
	DWORD dwRemoteIP;
	C6FileTransfer *ft;
} directthreadstartinfo;

extern HANDLE hDirectNetlibUser;

static DWORD c6DirectThread(directthreadstartinfo* dtsi);

int sendDirectPacket(HANDLE hConnection, BYTE **bpacket, WORD size)
{
   	int  ret;

 	if (*bpacket){

    	NETLIBBUFFER nlb = {0};
		int nRetries;

    	nlb.buf = (char*)*bpacket;
    	nlb.len = size;
    	nlb.flags = MSG_RAW;

		for (nRetries = 3; nRetries >= 0; nRetries--) {

 		    ret = CallService(MS_NETLIB_SEND,(WPARAM)hConnection,(LPARAM)&nlb);

			if (ret != SOCKET_ERROR)
				break;

			Sleep(1000);

		}

     mir_free(*bpacket);
     *bpacket = NULL;

	 if (ret == SOCKET_ERROR)
		 return 0;

	 return 1;

 	}

 	return 0;

}

void newConnectionReceived(HANDLE hNewConnection, DWORD dwRemoteIP)
{

	directthreadstartinfo* dtsi;

	// Start a new thread for the incomming connection
	dtsi = (directthreadstartinfo*)mir_alloc(sizeof(directthreadstartinfo));
	dtsi->hConnection = hNewConnection;
	dtsi->incoming = DIRECTCONN_RECEIVINGFILE;
	dtsi->dwRemoteIP = dwRemoteIP;

	C6FileTransfer *ft;

	if (!FindCookie(OP_FILE, NULL, NULL, (void*)&ft))
	{
		Netlib_Logf(hDirectNetlibUser, "Error: Received unexpected file transfer request response");
		c6LogMsg("User Receiver Error file transfer");
		return;
	}

	FreeCookie(0);

	dtsi->ft=(C6FileTransfer*) ft;
	ft->hConnection = dtsi->hConnection;

	c6LogMsg("---Open Direct Thread (Receiving)---");
    DWORD LTIDS;
	HANDLE hThreadServer = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)c6DirectThread, (LPVOID)dtsi,0,&LTIDS);

	CloseHandle(hThreadServer);

}

// Called from c6_server.c:handleFileAck
void openDirectConnection(HANDLE hContact, void* ft)
{

	directthreadstartinfo* dtsi;

	// Create a new connection
	dtsi = (directthreadstartinfo*)mir_alloc(sizeof(directthreadstartinfo));
	dtsi->incoming = DIRECTCONN_SENDINGFILE;
	dtsi->hContact = hContact;
	dtsi->ft=(C6FileTransfer*) ft;

	c6LogMsg("---Open Direct Thread (Sending)---");
    DWORD LTIDS;
	HANDLE hThreadServer = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)c6DirectThread, (LPVOID)dtsi,0,&LTIDS);

	CloseHandle(hThreadServer);
}

void getFileInfo(directconnect *dc)
{
	struct _stat statbuf;

	if (_stat(dc->ft->pszFileName, &statbuf)==0){

		dc->ft->dwFileSize = statbuf.st_size;

	}

}

static void file_buildProtoFileTransferStatus(C6FileTransfer* ft, PROTOFILETRANSFERSTATUS_V1* pfts)
{

	memset(pfts, 0, sizeof(PROTOFILETRANSFERSTATUS_V1));
	pfts->cbSize = sizeof(PROTOFILETRANSFERSTATUS_V1);
	pfts->hContact = ft->hContact;
	pfts->sending = 1;
	pfts->files = NULL;
	pfts->totalFiles = 1;
	pfts->currentFileNumber = 0;
	pfts->totalBytes = ft->dwFileSize;
	pfts->totalProgress = ft->dwBytesDone;
	pfts->currentFile = ft->pszFileName;
	pfts->currentFileSize = ft->dwFileSize;
	pfts->currentFileProgress = ft->dwBytesDone;

}

static int file_sendData(directconnect* dc)
{

 	FILE *f;
	BYTE *bpacket, *bp;
	BYTE *buf;
	int bytesReq, bytesRead;

	if ((f = fopen(dc->ft->pszFileName, "rb")) != NULL) {

		if (dc->ft->dwBytesDone)
			fseek(f,dc->ft->dwBytesDone,SEEK_SET);

		bytesReq = 4096; // 1024;
		buf = (BYTE *)mir_alloc(bytesReq);
		bytesRead = fread(buf, sizeof(BYTE), bytesReq, f);  // data
		fclose(f);

		int size = bytesRead+8;

		bp = bpacket = (BYTE *)mir_alloc(size + 1);
		if (bp == NULL) {
			mir_free(buf);
			c6LogMsg("Cannot get memory");
			return 1;
		}

		packBYTE(&bpacket, 0x30);
		packBYTE(&bpacket, FILE_TR_CHUNK);
		packWORD(&bpacket, (dc->ft->outCountFile)++);
		packWORD(&bpacket, bytesRead+2);
		packWORD(&bpacket, bytesRead);
		packSTR(&bpacket, bytesRead, (char*)buf);
		sendDirectPacket(dc->hConnection, &bp, size);
		mir_free(buf);
		buf=NULL;

	}

	dc->ft->dwBytesDone += bytesRead;

	if (bytesRead<bytesReq){

		dc->ft->bStopFile=TRUE;

	}

	PROTOFILETRANSFERSTATUS_V1 pfts;

	file_buildProtoFileTransferStatus(dc->ft, &pfts);
	ProtoBroadcastAck(C6PROTOCOLNAME, dc->ft->hContact, ACKTYPE_FILE, ACKRESULT_DATA, dc->ft, (LPARAM)&pfts);

	return 0;

}

static void file_recvData(BYTE *packet, directconnect* dc)
{

 	FILE *f;
	BYTE *bpacket, *bp;
	WORD bytesWrite;

	if ((f = fopen(dc->ft->pszFileName, "ab")) != NULL) {

		bp = packet;
		unpackWORD(&bp, &bytesWrite);

		c6LogMsg("%ld", bytesWrite);

	   	fwrite(bp, bytesWrite, 1, f);
		fclose(f);

		bp = bpacket = (BYTE *)mir_alloc(6 + 1);
		if (bp == NULL) {
			c6LogMsg("Cannot get memory");
			return ;
		}

		packBYTE(&bpacket, 0x30);
		packBYTE(&bpacket, FILE_TR_OK);
		packWORD(&bpacket, (dc->ft->outCountFile)++);
		packWORD(&bpacket, 0);
		sendDirectPacket(dc->hConnection, &bp, 6);

	}

	dc->ft->dwBytesDone += bytesWrite;

	PROTOFILETRANSFERSTATUS_V1 pfts;

	file_buildProtoFileTransferStatus(dc->ft, &pfts);
	ProtoBroadcastAck(C6PROTOCOLNAME, dc->ft->hContact, ACKTYPE_FILE, ACKRESULT_DATA, dc->ft, (LPARAM)&pfts);

}

static int file_endData(directconnect* dc)
{

	BYTE *bpacket, *bp;

	bp = bpacket = (BYTE *)mir_alloc(6 + 1);
	if (bp == NULL) {
		c6LogMsg("Cannot get memory");
		return 1;
	}

	packBYTE(&bpacket, 0x30);
	packBYTE(&bpacket, FILE_TR_END);
	packWORD(&bpacket, (dc->ft->outCountFile)++);
	packWORD(&bpacket, 0);
	sendDirectPacket(dc->hConnection, &bp, 6);

	ProtoBroadcastAck(C6PROTOCOLNAME, dc->ft->hContact, ACKTYPE_FILE, ACKRESULT_SUCCESS, dc->ft, 0);

	Netlib_CloseHandle(dc->hConnection);
	dc->hConnection = NULL;

	return 0;

}

static void file_endrecvData(directconnect* dc)
{

	ProtoBroadcastAck(C6PROTOCOLNAME, dc->ft->hContact, ACKTYPE_FILE, ACKRESULT_SUCCESS, dc->ft, 0);

	Netlib_CloseHandle(dc->hConnection);
	dc->hConnection = NULL;

}

void GetPathFileName(LPSTR pszNick, LPSTR pszFile, LPSTR *pszDest, int cbLen)
{

	*pszDest = (LPSTR)mir_alloc(cbLen);

	CallService(MS_FILE_GETRECEIVEDFILESFOLDER, (int)HContactfNickNoAdd(pszNick), (LPARAM)*pszDest);
    CreateDirectory(*pszDest, NULL);
	strcat(*pszDest, pszFile);

}

static void file_initData(BYTE *packet, directconnect* dc)
{

	BYTE *bpacket, *bp;
	LPSTR pszNick, pszFile;

	bp = packet;
	BYTE len = unpackBYTE(&bp);

    pszNick = (LPSTR)mir_alloc(len + 1);
    if (pszNick == NULL) {
		c6LogMsg("Cannot get memory");
        return;
    }
	unpackZSTR(&bp, len, pszNick);

	len = unpackBYTE(&bp);

    pszFile = (LPSTR)mir_alloc(len + 1);
    if (pszFile == NULL) {
		mir_free(pszNick);
		c6LogMsg("Cannot get memory");
        return;
    }
	unpackZSTR(&bp, len, pszFile);
	unpackDWORD(&bp, (DWORD*)&(dc->ft->dwFileSize));

	c6LogMsg("%d", dc->ft->dwFileSize);

	GetPathFileName(dc->ft->pszSender, pszFile, &(dc->ft->pszFileName), 255);

	mir_free(pszFile);
	mir_free(pszNick);

 	FILE *f;

	if ((f = fopen(dc->ft->pszFileName, "wb")) == NULL) {
		c6LogMsg("error on create file");
		return ;
	}
	fclose(f);

	int size = 6;

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
		c6LogMsg("Cannot get memory");
		return ;
	}

	dc->ft->outCountFile = 1;
	dc->ft->sending = 1;
	dc->ft->dwBytesDone=0;

	packBYTE(&bpacket, 0x30);
	packBYTE(&bpacket, FILE_TR_OK);
	packWORD(&bpacket, (dc->ft->outCountFile)++);
	packWORD(&bpacket, 0);
	sendDirectPacket(dc->hConnection, &bp, size);

}

static void file_initFile(directconnect* dc)
{

	BYTE *bpacket, *bp;
	LPSTR pszThisFileName = mir_strdup(dc->ft->pszFileName);

	if (((pszThisFileName = strrchr(pszThisFileName, '\\')) == NULL) &&
		((pszThisFileName = strrchr(pszThisFileName, '/')) == NULL)) {
			pszThisFileName = dc->ft->pszFileName;
	} else pszThisFileName++;

	WORD size = 6 + 1 + strlen(dc->ft->pszReceiver) + 1 + strlen(pszThisFileName) + 4;

	bp = bpacket = (BYTE *)mir_alloc(size + 1);
	if (bp == NULL) {
    	c6LogMsg("Cannot get memory");
    	return ;
    }

	getFileInfo(dc);

	dc->ft->outCountFile=1;
	dc->ft->sending=1;

	packBYTE(&bpacket, 0x30);
	packBYTE(&bpacket, FILE_TR_INIT);
	packWORD(&bpacket, dc->ft->outCountFile++);
	packWORD(&bpacket, size-6);
    packSTRwLEN(&bpacket, dc->ft->pszReceiver);
	packSTRwLEN(&bpacket, pszThisFileName);
	packDWORD(&bpacket, dc->ft->dwFileSize);

	sendDirectPacket(dc->hConnection, &bp, size);

	mir_free(pszThisFileName);

	dc->ft->dwBytesDone=0;
	dc->ft->bStopFile=FALSE;

}

int handleFileCommand(BYTE cmd, BYTE *bpacket, int size, directconnect* dc)
{

	switch (cmd)
    {

    	case FILE_TR_OK :
		{
			int iret;

        	c6LogMsg("OK->CHUNK");

			if (dc->ft->bStopFile)
				iret=file_endData(dc);
			else iret=file_sendData(dc);

        	return iret;
		}
      	case FILE_TR_INIT :

			c6LogMsg("INIT->FILECreate");
			file_initData(bpacket, dc);

        break;

      	case FILE_TR_CHUNK :

			c6LogMsg("CHUNK->OK");
			file_recvData(bpacket, dc);

        break;

    	case FILE_TR_END :

			c6LogMsg("END->CloseFile");
			file_endrecvData(dc);

        break;

      	case FILE_TR_STOP :

			c6LogMsg("STOP->FILETransfer");
			return 1;

        break;

      	case FILE_TR_BAD :

			c6LogMsg("BAD->FILETransfer");
			return 1;

        break;
	}

  	return 0;

}

typedef struct c6file_pkt_s {
      unsigned char id;
      unsigned char cmd;
      unsigned short count;
      unsigned short len;
   } c6file_pkt;

int continuefiledata =0;
BYTE *bufferfiledata = NULL;

static int handleFilePackets(BYTE *buffer, int len, directconnect* dc)
{

   	c6file_pkt *r_pkt = (c6file_pkt*)buffer;

   	if (continuefiledata) {

		r_pkt = (c6file_pkt*)bufferfiledata;

		if (continuefiledata<ntohs(r_pkt->len))
			memmove(&bufferfiledata[continuefiledata],buffer,len);
	   	continuefiledata += len;

		if (continuefiledata==ntohs(r_pkt->len)+6){

   			if (handleFileCommand(r_pkt->cmd, &bufferfiledata[6], ntohs(r_pkt->len)-6, dc)){
				mir_free(bufferfiledata);
				bufferfiledata = NULL;
				continuefiledata = 0;
				return -1;  // Terminate
			}
			mir_free(bufferfiledata);
			bufferfiledata=NULL;
			continuefiledata=0;
		}

	   	return len;
	}

  	if (r_pkt->id != 0x30) {

    	c6LogMsg("INVALID_PROTOCOL");
		c6LogMsg("invalid packet ID %#04x", r_pkt->id);
      	return -1;

   	}

   	if (ntohs(r_pkt->len) + 6 <= len)
		continuefiledata = 0;
   	else {
		continuefiledata = len;
		mir_free(bufferfiledata);
		bufferfiledata = (BYTE*)mir_alloc(ntohs(r_pkt->len) + 7);
		if (bufferfiledata)
			memmove(bufferfiledata, buffer, len);
		else return -1;
	}

	if (continuefiledata==0)
   		if (handleFileCommand(r_pkt->cmd, &buffer[6], len-6, dc))
			return -1;  // Terminate

	return len;

}

// Called from ...
static DWORD c6DirectThread(directthreadstartinfo *dtsi)
{

	CallService (MS_SYSTEM_THREAD_PUSH, 0, 0);

	directconnect dc;
	NETLIBPACKETRECVER packetRecv={0};
	HANDLE hPacketRecver;
	int recvResult;

	// Initialize DC struct
	dc.dwThreadId = GetCurrentThreadId();
	dc.incoming = dtsi->incoming;
	dc.hConnection = dtsi->hConnection;
	dc.ft = dtsi->ft;

	mir_free(dtsi);
	dtsi = NULL;

	if (dc.incoming==DIRECTCONN_SENDINGFILE) // Sending_file
	{

		NETLIBOPENCONNECTION nloc = {0};
		IN_ADDR addr;

		dc.dwRemoteInternalIP = dc.ft->dwRemoteIP;
		dc.dwRemotePort = dc.ft->wRemotePort;

		nloc.cbSize = sizeof(nloc);
		nloc.flags = 0;

		addr.S_un.S_addr = htonl(dc.dwRemoteInternalIP);

		nloc.szHost = inet_ntoa(addr);
		nloc.wPort = (WORD)dc.dwRemotePort;
		Netlib_Logf(hDirectNetlibUser, "Direct: connecting to %s:%u", nloc.szHost, nloc.wPort);

		c6LogMsg("Direct: connecting to %s:%u", nloc.szHost, nloc.wPort);

		dc.hConnection = (HANDLE)CallService(MS_NETLIB_OPENCONNECTION, (WPARAM)hDirectNetlibUser, (LPARAM)&nloc);
    	if (!dc.hConnection && (GetLastError() == 87)) { // this ensures that an old Miranda can also connect
      		nloc.cbSize = NETLIBOPENCONNECTION_V1_SIZE;
      		dc.hConnection = (HANDLE)CallService(MS_NETLIB_OPENCONNECTION, (WPARAM)hDirectNetlibUser, (LPARAM)&nloc);
    	}

		if (dc.hConnection == NULL)
		{

			Netlib_Logf(hDirectNetlibUser, "Direct: connect() failed (%d)", GetLastError());
		    LogPopup(0, POPUPCOLOR_ORANGE, Translate("Failed Connected."));

			c6LogMsg("No connection");
			ProtoBroadcastAck(C6PROTOCOLNAME, dc.ft->hContact, ACKTYPE_FILE, ACKRESULT_FAILED, dc.ft, 0);

    		CallService (MS_SYSTEM_THREAD_POP, 0, 0);

			return 0;

		}

		dc.ft->hConnection = dc.hConnection;

		// sending: File Name & Size
		file_initFile(&dc);
	}

	hPacketRecver = (HANDLE)CallService(MS_NETLIB_CREATEPACKETRECVER, (WPARAM)dc.hConnection, 8192);
	packetRecv.cbSize = sizeof(packetRecv);
	packetRecv.bytesUsed = 0;

	// Packet receiving loop

	packetRecv.dwTimeout = 5000; // INFINITE

	while(dc.hConnection)
	{

		recvResult = CallService(MS_NETLIB_GETMOREPACKETS, (WPARAM)hPacketRecver, (LPARAM)&packetRecv);

		if (recvResult == 0)
		{
			Netlib_Logf(hDirectNetlibUser, "Clean closure of direct socket (%p)", dc.hConnection);
			break;
		}

		if (recvResult == SOCKET_ERROR)
		{

			if (GetLastError() == -1) // ERROR_TIMEOUT
			{
				Netlib_Logf(hDirectNetlibUser, "FileTransfer: Timeout Error on Connection. Closing.");
				break;
			}
			else
			{
				Netlib_Logf(hDirectNetlibUser, "Abortive closure of FileTransfer Socket (%p) (%d)", dc.hConnection, GetLastError());
				break;
			}


		}

 		packetRecv.bytesUsed = handleFilePackets(packetRecv.buffer, packetRecv.bytesAvailable, &dc);
		if (packetRecv.bytesUsed < 0) {

			c6LogMsg("Wanted closure of file socket");
			break;
		}

	}

	// End of packet receiving loop

	if (dc.incoming==DIRECTCONN_RECEIVINGFILE)
		Netlib_CloseHandle(hPacketRecver);
	Netlib_Logf(hDirectNetlibUser, "Direct conn closed (%p)", dc.hConnection);

	if(dc.hConnection)
		Netlib_CloseHandle(dc.hConnection);

	if(dc.ft->sending)
    	ProtoBroadcastAck(C6PROTOCOLNAME, dc.ft->hContact, ACKTYPE_FILE, ACKRESULT_FAILED, dc.ft, 0);

 	mir_free(dc.ft->pszReceiver);
 	mir_free(dc.ft->pszSender);
	mir_free(dc.ft->pszFileName);
	mir_free(dc.ft);

	c6LogMsg("---Close File Thread---");

    CallService (MS_SYSTEM_THREAD_POP, 0, 0);

	return 0;

}

void c6CancelFileTransfer(HANDLE hContact, C6FileTransfer* ft)
{

	DWORD dwCookie;

	if (FindCookieByData(ft, &dwCookie))
		FreeCookie(dwCookie);

}

