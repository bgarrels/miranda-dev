/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

#include <wininet.h> // HINTERNET

#ifdef _C6_FULL

#define URLPHOTO "http://multimedia.community.virgilio.it/contenuti/"
#define BUFSIZE 512

#endif

extern HANDLE hInst;

extern ULONG ulLocalExternalIP;
extern WORD wListenPort;

#ifdef _C6_FULL
extern BYTE gbAvatarsEnabled;
#endif

extern int c6Status;

static BOOL CALLBACK c6DlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

#ifdef _C6_FULL

static BOOL CALLBACK AvatarDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
void   GetFullAvatarFileName(LPSTR pszNick, LPSTR *pszDest, int cbLen);
#endif

static void SetValue(HWND hwndDlg, int idCtrl, HANDLE hContact, char *szModule, char *szSetting, int special);

#define SVS_NORMAL        0
#define SVS_GENDER        1
#define SVS_ZEROISUNSPEC  2
#define SVS_IP            3
#define SVS_COUNTRY       4
#define SVS_MONTH         5
#define SVS_SIGNED        6
#define SVS_TIMEZONE      7
#define SVS_TIMESTAMP     8
#define SVS_C6STATUS      9
#define SVS_C6FLAGS      10
#define SVS_MIRVER       11

//--------------------------------------------------------------------
//                           OnDetailsInit
//--------------------------------------------------------------------

int OnDetailsInit(WPARAM wParam, LPARAM lParam)
{

	char* szProto;
  	OPTIONSDIALOGPAGE odp;
	memset(&odp, 0, sizeof(OPTIONSDIALOGPAGE));

  	szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, lParam, 0);
  	if ((szProto == NULL || strcmp(szProto, C6PROTOCOLNAME)) && lParam)
    	return 0;

  	odp.cbSize = sizeof(odp);
  	odp.hInstance = hInst;
  	odp.pfnDlgProc = (DLGPROC)c6DlgProc;
  	odp.position = -1900000000;
  	odp.pszTemplate = MAKEINTRESOURCE(IDD_INFO_C6);
  	odp.pszTitle = Translate(C6PROTOCOLNAME);

  	CallService(MS_USERINFO_ADDPAGE, wParam, (LPARAM)&odp);

#ifdef _C6_FULL
  	if ((lParam != 0) && gbAvatarsEnabled) {

		odp.pfnDlgProc = (DLGPROC)AvatarDlgProc;
    	odp.position = -1899999999;
    	odp.pszTemplate = MAKEINTRESOURCE(IDD_INFO_AVATAR);
      	if (lParam)
        	odp.pszTitle = "Avatar";
      	else
        	odp.pszTitle = "%s Avatar";

    	CallService(MS_USERINFO_ADDPAGE, wParam, (LPARAM)&odp);
  	}
#endif

  	return 0;

}

//--------------------------------------------------------------------
//                            c6DlgProc
//--------------------------------------------------------------------

static BOOL CALLBACK c6DlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch (msg)
	{

	case WM_INITDIALOG:

		TranslateDialogDefault(hwndDlg);

		return TRUE;

	case WM_NOTIFY:
		{
			switch (((LPNMHDR)lParam)->idFrom)
			{

			case 0:
				{

					switch (((LPNMHDR)lParam)->code) {

					case PSN_INFOCHANGED:
						{
              char* szProto;
              HANDLE hContact = (HANDLE)((LPPSHNOTIFY)lParam)->lParam;

              if (hContact == NULL)
                szProto = C6PROTOCOLNAME;
              else
                szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

              if (szProto == NULL)
                break;

			  SetValue(hwndDlg, IDC_ONLINESINCE, hContact, szProto, "LogonTS", SVS_TIMESTAMP);
			  SetValue(hwndDlg, IDC_C6NICK, hContact, szProto, C6_LOGINID, SVS_ZEROISUNSPEC);

              if (hContact) {

				ShowWindow(GetDlgItem(hwndDlg,IDC_CHANGEMYDETAILS), SW_HIDE);

                SetValue(hwndDlg, IDC_IP, hContact, szProto, "UserIP", SVS_IP);
                SetValue(hwndDlg, IDC_PORT, hContact, szProto, "UserPort", SVS_ZEROISUNSPEC);
                SetValue(hwndDlg, IDC_MIRVER, hContact, szProto, "MirVer", SVS_ZEROISUNSPEC);
                SetValue(hwndDlg, IDC_C6STATUS, hContact, szProto, "C6Status", SVS_C6STATUS);
				SetValue(hwndDlg, IDC_LASTONLINE, hContact, szProto, "LastOnline", SVS_TIMESTAMP);
				SetValue(hwndDlg, IDC_C6FLAGS, hContact, szProto, "C6Flags", SVS_C6FLAGS);

              }
              else {

                SetValue(hwndDlg, IDC_IP, hContact, (char*)DBVT_DWORD, (char*)ulLocalExternalIP, SVS_IP);
                SetValue(hwndDlg, IDC_PORT, hContact, (char*)DBVT_WORD, (char*)wListenPort, SVS_ZEROISUNSPEC);
                SetValue(hwndDlg, IDC_MIRVER, hContact, (char*)DBVT_ASCIIZ, "Miranda IM", SVS_ZEROISUNSPEC);
                SetValue(hwndDlg, IDC_C6STATUS, hContact, (char*)DBVT_WORD, (char*)MirandaStatusToC6(c6Status), SVS_C6STATUS);
                SetValue(hwndDlg, IDC_C6FLAGS, hContact, (char*)DBVT_BYTE, 0, SVS_C6FLAGS);

              }
            }
            break;
					}
				}
				break;
			}
		}
		break;

  case WM_COMMAND:
    switch(LOWORD(wParam))
    {

    case IDC_CHANGEMYDETAILS:
		CallService(MS_UTILS_OPENURL,1,( LPARAM ) "http://virgiliopeople.virgilio.it/gestione/pages/gestioneNick.html?pmk=c6");
      break;

    case IDCANCEL:
      	SendMessage(GetParent(hwndDlg),msg,wParam,lParam);
      break;
		}
    break;
  }

  return FALSE;
}

#ifdef _C6_FULL

typedef struct AvtDlgProcData_t
{
  HANDLE hContact;
  HANDLE hEventHook;
} AvtDlgProcData;

#define HM_REBIND_AVATAR  (WM_USER + 1024)

//--------------------------------------------------------------------
//                           AvatarDlgProc
//--------------------------------------------------------------------

static BOOL CALLBACK AvatarDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch (msg) {

	case WM_INITDIALOG:
    	TranslateDialogDefault(hwndDlg);
    	{

      	AvtDlgProcData* pData = (AvtDlgProcData*)mir_alloc(sizeof(AvtDlgProcData));

      	pData->hContact = (HANDLE)lParam;

      	if (pData->hContact)
        	pData->hEventHook = HookEventMessage(ME_PROTO_ACK, hwndDlg, HM_REBIND_AVATAR);
      	SetWindowLong(hwndDlg, USERDATA, (LONG)pData);

	  	ShowWindow(GetDlgItem(hwndDlg, IDC_GETAVATAR), SW_SHOW);

      	if (pData->hContact) {
			DBVARIANT dbv;
			DBGetContactSetting(pData->hContact, C6PROTOCOLNAME, "C6Flags", &dbv);
			if ((dbv.cVal & C6FLAGS_AVATAR)==C6FLAGS_AVATAR)
				SendMessage(hwndDlg, WM_COMMAND, IDC_GETAVATAR, 0L);
        	DBFreeVariant(&dbv);
		}


    }
    return TRUE;

  case HM_REBIND_AVATAR:
    {
      AvtDlgProcData* pData = (AvtDlgProcData*)GetWindowLong(hwndDlg, USERDATA);
      ACKDATA* ack = (ACKDATA*)lParam;

      if (!pData->hContact) break; // we do not use this for us

      if (ack->type == ACKTYPE_AVATAR && ack->hContact == pData->hContact)
      {

        if (ack->result == ACKRESULT_SUCCESS) {
        	// load avatar
          	PROTO_AVATAR_INFORMATION* AI = (PROTO_AVATAR_INFORMATION*)ack->hProcess;

          	HBITMAP avt = (HBITMAP)CallService(MS_UTILS_LOADBITMAP, 0, (WPARAM)AI->filename);

          	if (avt) avt = (HBITMAP)SendDlgItemMessage(hwndDlg, IDC_AVATAR, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)avt);
          	if (avt) DeleteObject(avt); // we release old avatar if any

		}
      }
    }
		break;

  case WM_COMMAND:
    switch(LOWORD(wParam))
    {
    case IDC_GETAVATAR:
      {
	    DBVARIANT dbv;
		char szNick[32];
        AvtDlgProcData* pData = (AvtDlgProcData*)GetWindowLong(hwndDlg, USERDATA);

	    if(!DBGetContactSetting(pData->hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
			strcpy(szNick,dbv.pszVal);
			DBFreeVariant(&dbv);

			PROTO_AVATAR_INFORMATION ai;
			LPSTR pszFile;

			if (getAvatarFile(szNick, &pszFile)) {

				ai.cbSize = sizeof(ai);
        		ai.format = PA_FORMAT_JPEG; // only jpeg file type
        		ai.hContact = pData->hContact;
        		strcpy(ai.filename, pszFile);

				ProtoBroadcastAck(C6PROTOCOLNAME, pData->hContact, ACKTYPE_AVATAR, ACKRESULT_SUCCESS, (HANDLE)&ai, (LPARAM)NULL);

			}
			mir_free(pszFile);

        }
      } // case
      break;
    } // switch
    break;

  case WM_DESTROY:
    {
      AvtDlgProcData* pData = (AvtDlgProcData*)GetWindowLong(hwndDlg, USERDATA);
      if (pData->hContact)
        UnhookEvent(pData->hEventHook);
      SetWindowLong(hwndDlg, USERDATA, (LONG)0);
	  mir_free(pData);
	  pData=NULL;

    }
    break;
  }

  return FALSE;
}

#endif // _C6_FULL

//--------------------------------------------------------------------
//                             SetValue
//--------------------------------------------------------------------

static void SetValue(HWND hwndDlg, int idCtrl, HANDLE hContact, char* szModule, char* szSetting, int special)
{
  DBVARIANT dbv = {0};
  char str[80];
  char* pstr;
  int unspecified = 0;

  dbv.type = DBVT_DELETED;

  if ((hContact == NULL) && ((int)szModule < 0x100))
  {
    dbv.type = (BYTE)szModule;

    switch((int)szModule)
    {
    case DBVT_BYTE:
      dbv.cVal = (BYTE)szSetting;
      break;
    case DBVT_WORD:
      dbv.wVal = (WORD)szSetting;
      break;
    case DBVT_DWORD:
      dbv.dVal = (DWORD)szSetting;
      break;
    case DBVT_ASCIIZ:
      dbv.pszVal = szSetting;
      break;
    default:
      unspecified = 1;
      dbv.type = DBVT_DELETED;
    }
  }
  else
  {
	  if (szModule == NULL)
		  unspecified = 1;
	  else
		  unspecified = DBGetContactSetting(hContact, szModule, szSetting, &dbv);
  }

	if (!unspecified)
	{
		switch (dbv.type)
		{

		case DBVT_BYTE:
			if (special == SVS_GENDER)
			{
				if (dbv.cVal == 'M')
					pstr = Translate("Male");
				else if (dbv.cVal == 'F')
					pstr = Translate("Female");
				else
					unspecified = 1;
			}
			else if (special == SVS_MONTH)
			{
				if (dbv.bVal>0 && dbv.bVal<=12)
				{
					pstr = str;
					GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SABBREVMONTHNAME1-1+dbv.bVal, str,sizeof(str));
				}
				else
					unspecified = 1;
			}
			else if (special == SVS_TIMEZONE)
			{
				if (dbv.cVal == -100)
					unspecified = 1;
				else
				{
					pstr = str;
					_snprintf(str, 80, dbv.cVal ? "GMT%+d:%02d":"GMT", -dbv.cVal/2, (dbv.cVal&1)*30);
				}
			}
			else if (special == SVS_C6FLAGS)
			{
					pstr = str;
					_snprintf(str, 80, "%s%s%s",
					                    (dbv.cVal & C6FLAGS_AVATAR)==C6FLAGS_AVATAR?"Avatar ":"",
										(dbv.cVal & C6FLAGS_NETWORK)==C6FLAGS_NETWORK?"Network ":"",
										(dbv.cVal & C6FLAGS_EXTRAX)==C6FLAGS_EXTRAX?"Extra ":"");
			}
			else
			{
				unspecified = (special == SVS_ZEROISUNSPEC && dbv.bVal == 0);
				pstr = (char*)itoa(special == SVS_SIGNED ? dbv.cVal:dbv.bVal, str, 10);
			}
			break;

		case DBVT_WORD:
			if (special == SVS_C6STATUS)
			{
				pstr = str;
				if ((dbv.wVal & C6_OFFLINE)==C6_OFFLINE || dbv.wVal==0){
						_snprintf(str, 80, "Offline (0x%X)", dbv.wVal);
				} else
					 _snprintf(str, 80, "Online: %s%s%s (0x%X)",
					                        (dbv.wVal & C6_AWAY)==C6_AWAY?"Away":
					                        (dbv.wVal & C6_AVAILABLE)==C6_AVAILABLE?"Available":
					                        (dbv.wVal & C6_NETFRIENDS)==C6_NETFRIENDS?"NetFriend":
											(dbv.wVal & C6_BUSY)==C6_BUSY?"Busy":"",
											(dbv.wVal & C6_MEETING)==C6_MEETING?" Meeting":"",
											(dbv.wVal & C6_FILESHARED)==C6_FILESHARED?" FileSharing":"",
											 dbv.wVal);
			}
			else
			{
				unspecified = (special == SVS_ZEROISUNSPEC && dbv.wVal == 0);
				pstr = (char*)itoa(special == SVS_SIGNED ? dbv.sVal:dbv.wVal, str, 10);
			}
			break;

		case DBVT_DWORD:
			unspecified = (special == SVS_ZEROISUNSPEC && dbv.dVal == 0);
			if (special == SVS_IP)
			{
				struct in_addr ia;
				ia.S_un.S_addr = htonl(dbv.dVal);
				pstr = inet_ntoa(ia);
				if (dbv.dVal == 0)
					unspecified=1;
			}
			else if (special == SVS_TIMESTAMP)
			{
				if (dbv.dVal == 0)
					unspecified = 1;
				else
				{
					pstr = asctime(localtime(&dbv.dVal));
					pstr[24] = '\0'; // Remove newline
				}
			}
			else
				pstr = (char*)itoa(special == SVS_SIGNED ? dbv.lVal:dbv.dVal, str, 10);
			break;

		case DBVT_ASCIIZ:
			unspecified = (special == SVS_ZEROISUNSPEC && dbv.pszVal[0] == '\0');
			pstr = dbv.pszVal;
			break;

		default:
			pstr = str;
			lstrcpy(str,"???");
			break;
		}
	}

	EnableWindow(GetDlgItem(hwndDlg, idCtrl), !unspecified);
	if (unspecified)
		SetDlgItemText(hwndDlg, idCtrl, Translate("<not specified>"));
	else
		SetDlgItemText(hwndDlg, idCtrl, pstr);

  	if (dbv.pszVal!=szSetting)
		DBFreeVariant(&dbv);
}

//--------------------------------------------------------------------
//                        GetFullAvatarFileName
//--------------------------------------------------------------------

void GetFullAvatarFileName(LPSTR pszNick, LPSTR *pszDest, int cbLen)
{
    WORD tPathLen;

	*pszDest = (LPSTR)mir_alloc(cbLen);
    CallService(MS_DB_GETPROFILEPATH, cbLen, (LPARAM)*pszDest);

    tPathLen = strlen(*pszDest);
    tPathLen += mir_snprintf(*pszDest + tPathLen, MAX_PATH-tPathLen, "\\%s\\", C6PROTOCOLNAME);
    CreateDirectory(*pszDest, NULL);
	strcat(*pszDest, pszNick);
    strcat(*pszDest, ".jpg");

}

#ifdef _C6_FULL

//--------------------------------------------------------------------
//                             file_exists
//--------------------------------------------------------------------

BOOL file_exists(char *filename){
	return (BOOL)(access(filename, 0) == 0);
}

//--------------------------------------------------------------------
//                           getAvatarFile
//--------------------------------------------------------------------

BOOL getAvatarFile(LPSTR pszNick, LPSTR *pszDest)
{
	HINTERNET hIn, hURL;
 	DWORD dwNumberOfBytesRead;
 	FILE *f;
 	BOOL bret;
	char szFile[MAX_PATH];

	char Buffer[BUFSIZE];

	GetFullAvatarFileName(pszNick, pszDest, 255);

 	bret=FALSE;

	if (!file_exists(*pszDest)) {

        c6LogMsg("Download Avatar...");
 		hIn=InternetOpen("miranda32.exe", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
 		if (hIn) {

			strcpy(szFile, URLPHOTO);
			strcat(szFile, pszNick);
			strcat(szFile, ",t00.jpg");
			c6LogMsg(szFile);

   			hURL=InternetOpenUrl(hIn, szFile, NULL, 0, 0, 0);
   			if (hURL) {

    	 		if ((f = fopen(*pszDest, "wb")) != NULL) {
    	        	do {

    	   				InternetReadFile(hURL,&Buffer,BUFSIZE,&dwNumberOfBytesRead);
    	   				fwrite(Buffer, dwNumberOfBytesRead, 1, f);

    	  			} while (dwNumberOfBytesRead != 0);
    	  			fclose(f);
		  			bret=TRUE;

		 		}
    	 		InternetCloseHandle(hURL);
			}
   			InternetCloseHandle(hIn);
  		}
    } else bret=TRUE;
 	return bret;

}

LPSTR LoadMyAvatar(void)
{
	LPSTR pszFile;
	char szUser[40];

	if (GetUserNickName(szUser))
		if (getAvatarFile(szUser, &pszFile))
			return pszFile;

	return NULL;

}

#endif // _C6_FULL
