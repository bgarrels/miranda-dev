/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __ENCODING_H
#define __ENCODING_H

extern char reordered_key[8];
extern char server_key[8];

/* ---------------------- Functions ---------------------- */

void GenerKey(unsigned char *pDest,unsigned char *pSorg);
void nickpass_encode(unsigned char *StrCode, unsigned char *StrDest, int Psw);
void reorder_key_server(const unsigned char *unordered, unsigned char *ordered);
void packet_encode(unsigned char *dst, unsigned char *src, int len);

#endif /* __ENCODING_H */

