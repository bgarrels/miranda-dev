/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_USERINFO_H
#define __C6_USERINFO_H

/* ---------------------- Functions ---------------------- */

int  OnDetailsInit(WPARAM wParam, LPARAM lParam);
BOOL getAvatarFile(LPSTR pszNick, LPSTR *pszDest);
void GetFullAvatarFileName(LPSTR pszNick, LPSTR *pszDest, int cbLen);
BOOL file_exists(char *filename);

LPSTR LoadMyAvatar(void);


#endif /* __C6_USERINFO_H */
