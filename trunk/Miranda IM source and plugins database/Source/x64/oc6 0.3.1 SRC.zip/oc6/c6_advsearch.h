/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_ADVSEARCH_H
#define __C6_ADVSEARCH_H

typedef struct fieldnames_t {
	int code;
	char *text;
};

/* ---------------------- Functions ---------------------- */

BOOL  CALLBACK AdvancedSearchDlgProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam);
PBYTE createAdvancedSearchStructure(HWND hwndDlg, int *length);
LPSTR getStringName(int code, struct fieldnames_t *names);

#endif /* __C6_ADVSEARCH_H */
