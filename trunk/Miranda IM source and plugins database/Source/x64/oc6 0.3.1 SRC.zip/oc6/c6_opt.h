/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_OPT_H
#define __C6_OPT_H

/* ---------------------- Functions ---------------------- */

int  c6OptInit(WPARAM wParam,LPARAM lParam);
void SecrMenuChange(BOOL bShow);

#endif /* __C6_OPT_H */

