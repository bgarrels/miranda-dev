/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#include "c6.h"

HWND hwndRaw = NULL;
HWND hwndSecr = NULL;
HWND hwndGC = NULL;

extern HANDLE hNetlibUser;

extern int c6Status;

#ifdef _C6_ROOM

enum ROOM_TYPE
{
    PUBLIC_C6 = 0x03,
    PUBLIC_NET = 0x05,
    PRIVATE_NET = 0x04,
    C6_FULL = 0x0f
};

int numberGroup = 0;

BOOL bTimerAutoUpdate = FALSE;

BOOL bLBStopView = FALSE;

typedef struct RoomListData
{
 	int  iIndex;
	int  iSubItem;
	int  iLastColumnSortIndex;
	BOOL bSortAscending;
};

char *updateField[]={
	LPGEN("No Update"),
	LPGEN("Update every 1 Minute"),
	LPGEN("Update every 3 Minutes"),
	LPGEN("Update every 5 Minutes"),
	 NULL};

// dal 24/3/2009
char *groupField[]={
	LPGEN("No Category"),
	LPGEN("Events"),
	LPGEN("Welcome"),
	LPGEN("Love"),
	LPGEN("Travel"),
	LPGEN("Cities"),
	LPGEN("Cinema/Tv"),
	LPGEN("Music"),
	LPGEN("News/Economy"),
	LPGEN("Sport"),
	LPGEN("Hi Tech"),
	LPGEN("Hot"),
	 NULL};

#endif

extern HINSTANCE hInst;

void InitComboBoxRoom(HWND hwndCombo,char **names);

//--------------------------------------------------------------------
//                           windowCentered
//--------------------------------------------------------------------

void windowCentered(HWND subhwnd){
	RECT rt;
	int iX, iY, iW, iH;

	GetWindowRect(subhwnd, &rt);
	iW = (rt.right-rt.left);
	iH = (rt.bottom-rt.top);
	iX =(GetSystemMetrics(SM_CXSCREEN)-iW) / 2;
	iY =(GetSystemMetrics(SM_CYSCREEN)-iH) / 2;

	SetWindowPos(subhwnd, HWND_TOP, iX, iY, iW, iH, SWP_NOACTIVATE);
}

//--------------------------------------------------------------------
//                          firstRunDlgProc
//--------------------------------------------------------------------

BOOL CALLBACK firstRunDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch (msg) {

  		case WM_INITDIALOG:
	    {

			TranslateDialogDefault(hwndDlg);
      		SendMessage(hwndDlg, WM_SETICON, ICON_SMALL, (LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_C6)));

    	}
    	break;

  		case WM_CLOSE:
    		EndDialog(hwndDlg, 0);
    	break;

  		case WM_COMMAND:
    		{
      			switch (LOWORD(wParam)) {

      				case IDC_REGISTER:
        				{
          					CallService(MS_UTILS_OPENURL, 1, (LPARAM)URL_REGISTER);
          					break;
        				}

				      case IDOK:
        				{
          					char szbuf[128];

				        	GetDlgItemText(hwndDlg, IDC_UKEY, szbuf, sizeof(szbuf));
							DBWriteContactSettingString(NULL,C6PROTOCOLNAME,"LoginNickName", szbuf);

          					GetDlgItemText(hwndDlg, IDC_PW, szbuf, sizeof(szbuf));
          					CallService(MS_DB_CRYPT_ENCODESTRING, sizeof(szbuf), (LPARAM) szbuf);
							DBWriteContactSettingString(NULL, C6PROTOCOLNAME, "Password", szbuf);
        				}

      				case IDCANCEL:
        				{
          					// Mark first run as completed
							DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "FirstRun", 1);
          					EndDialog(hwndDlg, IDCANCEL);

        				}
			        break;
			}
    	}
    	break;
  	}

  	return FALSE;

}

void c6FirstRunCheck(void)
{

	if (!DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "FirstRun", 0)){

		DialogBox(hInst, MAKEINTRESOURCE(IDD_C6ACCOUNT), NULL, (DLGPROC)firstRunDlgProc);

	}

}

//--------------------------------------------------------------------
//                          setCustStatusProc
//--------------------------------------------------------------------

#pragma argsused
BOOL CALLBACK setCustStatusProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message) {
	case WM_INITDIALOG :
		{

			LPSTR pszStatusMessage;
			getStatusMessage(&pszStatusMessage);

			if (pszStatusMessage)
				SetDlgItemText(hDlg, IDC_CUSTSTAT, pszStatusMessage);

			mir_free(pszStatusMessage);
			TranslateDialogDefault(hDlg);

		}
	 return FALSE;
	case WM_COMMAND :
	 	switch (LOWORD(wParam)) {
		case IDOK :
			{

				char szStatusMessage[256];
				char szUser[20];

				GetUserNickName(szUser);
				GetDlgItemText(hDlg, IDC_CUSTSTAT, szStatusMessage, 255);
				writeDbInfoSettingString(NULL, "StatusMessage", szStatusMessage);

				c6NewChangeStatus(szUser, 0, MirandaStatusToC6(c6Status), (strlen(szStatusMessage)) ? szStatusMessage : NULL);


				EndDialog(hDlg, 1);

			}
		   return TRUE;
	  	case IDCANCEL :
		 	EndDialog(hDlg, 0);
	   	return TRUE;
   	  	default:
	   	return(TRUE);
	  	}
	default : return(FALSE);
  	}

}

int setStatusMessage(void)
{

	if (amIOnline())
		return DialogBox(hInst, MAKEINTRESOURCE(IDD_C6SETSTATMSG), NULL, (DLGPROC)setCustStatusProc);

	return 0;
}

//--------------------------------------------------------------------
//                           getOnlineMsgProc
//--------------------------------------------------------------------

#pragma argsused
BOOL CALLBACK getOnlineMsgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message) {
	case WM_INITDIALOG :
		{

			DBVARIANT dbv = {0};
		  	if (!DBGetContactSetting((HANDLE)lParam, "CList", "StatusMsg", &dbv))
				if (dbv.pszVal)
					SetDlgItemText(hDlg, IDC_CUSTSTAT, dbv.pszVal);

			SetWindowText(hDlg, Translate("Online Message"));
			SendDlgItemMessage(hDlg, IDC_CUSTSTAT, EM_SETREADONLY, 1, 0L);
			SetWindowPos(GetDlgItem(hDlg, IDCANCEL), 0, 100, 40, 0, 0, SWP_NOSIZE|SWP_NOZORDER);
			SetDlgItemText(hDlg, IDCANCEL, Translate("Close"));
			EnableWindow(GetDlgItem(hDlg, IDOK), FALSE);
			ShowWindow(GetDlgItem(hDlg, IDOK), SW_HIDE);

			TranslateDialogDefault(hDlg);

		}
	 return FALSE;
	case WM_COMMAND :
	 	switch (LOWORD(wParam)) {
		case IDOK :
	  	case IDCANCEL :
		 	EndDialog(hDlg, 0);
	   	return TRUE;
   	  	default:
	   	return(TRUE);
	  	}
	default : return(FALSE);
  	}

}

int getOnlineMessage(HANDLE hContact)
{
	return DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_C6SETSTATMSG), NULL, (DLGPROC)getOnlineMsgProc, (LPARAM)hContact);
}

//--------------------------------------------------------------------
//                           secretariatProc
//--------------------------------------------------------------------

#pragma argsused
long CALLBACK secretariatProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	HIMAGELIST himgList;
 	HICON hicon;
 	LPNM_LISTVIEW pnmhdr;

 	switch (message) {

	case WM_INITDIALOG : {

		char szProtoName[100];

		TranslateDialogDefault(hDlg);
		SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_C6)));

		_snprintf(szProtoName, 100, "%s %s", C6PROTOCOLNAME, Translate("Secretariat"));
		SetWindowText(hDlg,szProtoName);

      	LV_COLUMN col;

 		col.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;
 		col.fmt  = LVCFMT_LEFT;
 		col.pszText = Translate("Author");
 		col.cchTextMax = 0;
 		col.cx = 96;
 		col.iSubItem = 0;
 		ListView_InsertColumn(GetDlgItem(hDlg,IDC_SECR_LISTVIEW), 0, &col);

 		col.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;
 		col.fmt  = LVCFMT_RIGHT;
 		col.pszText = Translate("Time");
 		col.cchTextMax = 0;
 		col.cx = 50;
 		col.iSubItem = 0;
		ListView_InsertColumn(GetDlgItem(hDlg,IDC_SECR_LISTVIEW), 1, &col);

 		col.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;
 		col.fmt  = LVCFMT_LEFT;
 		col.pszText = Translate("Message");
 		col.cchTextMax = 0;
 		col.cx = 188;
 		col.iSubItem = 0;
		ListView_InsertColumn(GetDlgItem(hDlg,IDC_SECR_LISTVIEW), 2, &col);

		himgList = ImageList_Create(16,16,ILC_COLOR8 | ILC_MASK,1,0);
	    hicon = LoadImage(hInst, MAKEINTRESOURCE(IDI_C6), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON),0);
	    ImageList_AddIcon(himgList, hicon);
		ImageList_AddIcon(himgList, LoadSkinnedProtoIcon(C6PROTOCOLNAME, ID_STATUS_NA));
		SendMessage(GetDlgItem(hDlg, IDC_SECR_LISTVIEW), LVM_SETIMAGELIST,(WPARAM)(LVSIL_SMALL),(LPARAM)(UINT)(HIMAGELIST)himgList);

		windowCentered(hDlg);
		SendMessage(GetDlgItem(hDlg,IDC_SECR_LISTVIEW),LVM_SETEXTENDEDLISTVIEWSTYLE ,
		                   (WPARAM)0,(LPARAM)(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT));

	  }
	 return (TRUE);
	case WM_NOTIFY :
		pnmhdr=(LPNM_LISTVIEW)lParam;
		switch (pnmhdr->hdr.code) {
			case NM_DBLCLK :
				if (pnmhdr->hdr.idFrom==IDC_SECR_LISTVIEW) {

					char szAuthor[20], szMsg[512];

					if (pnmhdr->iItem >= 0){

						ListView_GetItemText(GetDlgItem(hDlg,IDC_SECR_LISTVIEW), pnmhdr->iItem, 0, szAuthor, 20);
						if (MessageBox(0, szAuthor, Translate("Reply To..."), MB_YESNO)==IDYES) {

							ListView_GetItemText(GetDlgItem(hDlg,IDC_SECR_LISTVIEW), pnmhdr->iItem, 2, szMsg, 512);
							CCSDATA ccs;
							PROTORECVEVENT pre;

							ccs.szProtoService = PSR_MESSAGE;
							ccs.hContact = HContactFromNick(PALF_TEMPORARY, szAuthor);

					    	DBWriteContactSettingWord(ccs.hContact, C6PROTOCOLNAME, "Status", ID_STATUS_ONLINE);

							ccs.wParam = 0;
	 						ccs.lParam = (LPARAM)&pre;
	 						pre.flags = 0;
	 						pre.timestamp = time(NULL);
	 						pre.szMessage = (char *)szMsg;
	 						pre.lParam = 0;
	 						CallService(MS_PROTO_CHAINRECV, 0, (LPARAM)&ccs);

							Sleep(100);
							CallService(MS_CLIST_CONTACTDOUBLECLICKED, (WPARAM) ccs.hContact, 0);
						}
				    }

				}
			}
		return(TRUE);
	case WM_COMMAND :
	 switch (LOWORD(wParam))
	  {
		case IDC_DELETE_MSG :
		  	ListView_DeleteAllItems(GetDlgItem(hDlg,IDC_SECR_LISTVIEW));
		  return(TRUE);
		case IDC_CLOSE:
			ShowWindow(hDlg, SW_HIDE);
		 return(TRUE);
		case IDCANCEL:
			ShowWindow(hDlg, SW_HIDE);
		 return(TRUE);
		default:
		 return(TRUE);
	  }
	case WM_DESTROY:
		himgList=(HIMAGELIST)SendDlgItemMessage(hDlg,IDC_SECR_LISTVIEW,LVM_GETIMAGELIST,0,0);
		ImageList_Destroy(himgList);
		break;
	default : return(FALSE);

  	}
  	return(TRUE);

}

//--------------------------------------------------------------------
//                        insertInSecretariat
//--------------------------------------------------------------------

void insertInSecretariat(int iImage, LPSTR pszNick, LPSTR pszMsg, time_t *tt)
{
	LV_ITEM lvi;

	secretariatDlgInit(!DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "HideSecretariat", 0));

	memset(&lvi,0x00,sizeof(LV_ITEM));
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
 	lvi.iItem = 0x7FFF;
	lvi.iSubItem = 0;
	lvi.iImage   = iImage;
 	lvi.pszText = (LPSTR)pszNick;
 	lvi.cchTextMax = sizeof(pszNick);

    int index = ListView_InsertItem(GetDlgItem(hwndSecr,IDC_SECR_LISTVIEW), &lvi);

    char szTime[26];
	if (tt) { // OfflineMessage
		_snprintf(szTime, 26, "%s", asctime(localtime(tt)));
		szTime[24]='\0';
	}
	else {
	    SYSTEMTIME lst;

		GetLocalTime(&lst);
		_snprintf(szTime, 26, "%02d:%02d", lst.wHour, lst.wMinute);
	}

 	memset(&lvi,0x00,sizeof(LV_ITEM));
	lvi.mask = LVIF_TEXT;
 	lvi.iItem = index;
    lvi.iSubItem = 1;
 	lvi.pszText = (LPSTR)szTime;
 	lvi.cchTextMax = sizeof(szTime);

    ListView_SetItem(GetDlgItem(hwndSecr,IDC_SECR_LISTVIEW), &lvi);

 	memset(&lvi,0x00,sizeof(LV_ITEM));
	lvi.mask = LVIF_TEXT;
 	lvi.iItem = index;
    lvi.iSubItem = 2;
 	lvi.pszText = (LPSTR)pszMsg;
 	lvi.cchTextMax = sizeof(pszMsg);

    ListView_SetItem(GetDlgItem(hwndSecr,IDC_SECR_LISTVIEW), &lvi);

	FlashWindow(hwndSecr, FALSE);

	char szSndName[30];

	strcpy(szSndName, C6PROTOCOLNAME);
	strcat(szSndName, "/Secretariat");

	SkinPlaySound(szSndName);

}

//--------------------------------------------------------------------
//                           secretariatDlgInit
//--------------------------------------------------------------------

int secretariatDlgInit(BOOL bShow)
{

    if (!hwndSecr) {

		hwndSecr = CreateDialog(hInst, MAKEINTRESOURCE(IDD_SECRETARIAT), NULL, (DLGPROC)secretariatProc);

    }
    if (hwndSecr && bShow)
		ShowWindow(hwndSecr, SW_SHOW);

	return (int)hwndSecr;
}

//--------------------------------------------------------------------
//                           secretariatDlgDone
//--------------------------------------------------------------------

void secretariatDlgDone(void)
{

    DestroyWindow(hwndSecr);
	hwndSecr = 0;

}

//--------------------------------------------------------------------
//                             logProcC6
//--------------------------------------------------------------------

#pragma argsused
BOOL CALLBACK logProcC6(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message) {
	case WM_INITDIALOG :
		{
		char szProtoName[100];

		TranslateDialogDefault(hDlg);
		_snprintf(szProtoName, 100, "%s %s", C6PROTOCOLNAME, Translate("Log"));
		SetWindowText(hDlg,szProtoName);

		SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_C6)));
		}
	return FALSE;
	case WM_COMMAND :
		switch (LOWORD(wParam))	{
	  	case IDOK :
			SetDlgItemText(hwndRaw, IDC_DATA, "");
		return TRUE;
	  	case IDCANCEL :
		 	ShowWindow(hwndRaw, SW_HIDE);
	   	return TRUE;
   	  	default:
	   	return(TRUE);
	  	}
   	case WM_SIZE :
    	SetWindowPos(GetDlgItem(hDlg, IDC_DATA), 0, 0, 0, LOWORD(lParam), HIWORD(lParam) - 40, SWP_NOMOVE|SWP_NOZORDER);
    	SetWindowPos(GetDlgItem(hDlg, IDCANCEL), 0, (LOWORD(lParam)-70)/2+50, HIWORD(lParam) - 25, 0, 0, SWP_NOSIZE|SWP_NOZORDER);
    	SetWindowPos(GetDlgItem(hDlg, IDOK), 0, (LOWORD(lParam)-70)/2-50, HIWORD(lParam) - 25, 0, 0, SWP_NOSIZE|SWP_NOZORDER);
   	return FALSE;
	case WM_DESTROY :
		  EndDialog(hDlg, 0);
	return(TRUE);
	default : return(FALSE);
  	}

}

//--------------------------------------------------------------------
//                               c6LogMsg
//--------------------------------------------------------------------

void c6LogMsg(const char *fmt,...)
{

	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseDefaultLog", 0)) {

		Netlib_Logf(hNetlibUser, fmt);

	} else if (hwndRaw) {

		va_list va;
 		char *sztmp;
		long length;

    	sztmp = (char*)mir_alloc(1024);

		va_start(va, fmt);
		mir_vsnprintf(sztmp, 1024 - 2, fmt, va);
		va_end(va);

		if (sztmp[strlen(sztmp)-1] == '\n')
			sztmp[strlen(sztmp)-1] = '\0';
		strcat(sztmp, "\r\n");

   	    length = SendDlgItemMessage(hwndRaw, IDC_DATA, WM_GETTEXTLENGTH, 0, 0);
   	    SendDlgItemMessage(hwndRaw, IDC_DATA, EM_SETSEL, length, (LPARAM)length);
   	    SendDlgItemMessage(hwndRaw, IDC_DATA, EM_REPLACESEL, 0, (LPARAM)sztmp);
   	    SendDlgItemMessage(hwndRaw, IDC_DATA, EM_SETSEL, 0, (LPARAM)1);

		mir_free(sztmp);
	}

}

//--------------------------------------------------------------------
//                             logDlgInit
//--------------------------------------------------------------------

int logDlgInit(void)
{

    if (!hwndRaw) {
	    hwndRaw = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DEBUGWND), NULL, (DLGPROC)logProcC6);
	}
	return (int)hwndRaw;

}

//--------------------------------------------------------------------
//                             logDlgDone
//--------------------------------------------------------------------

void logDlgDone(void)
{

	DestroyWindow(hwndRaw);
	hwndRaw = 0;

}

//--------------------------------------------------------------------
//                             addToListC6
//--------------------------------------------------------------------

#pragma argsused
long CALLBACK addToListC6(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	char szNick[40]; // 20

 	switch (message) {
	case WM_INITDIALOG :
		{
		TranslateDialogDefault(hDlg);

		char szProtoName[100];
		_snprintf(szProtoName, 100, "%s %s", C6PROTOCOLNAME, Translate("Add Contact"));
		SetWindowText(hDlg,szProtoName);


		windowCentered(hDlg);
		}
	 return 0;
	case WM_COMMAND :
	 switch (LOWORD(wParam))
	  {
		case IDOK:
			GetDlgItemText(hDlg,IDC_ENICKTOLIST, szNick, 40);
			{	ADDCONTACTSTRUCT acs;

				C6SEARCHRESULT sr = {0};

	    		sr.hdr.cbSize = sizeof(sr);

				sr.hdr.nick = szNick;
				sr.hdr.firstName = NULL;
				sr.hdr.lastName = NULL;
				sr.hdr.email = NULL;
				sr.status = C6_OFFLINE;

				acs.handle=NULL;
				acs.handleType=HANDLE_SEARCHRESULT;
				acs.szProto=C6PROTOCOLNAME;
				acs.psr=(PROTOSEARCHRESULT*)&sr;
				CallService(MS_ADDCONTACT_SHOW,(WPARAM)NULL,(LPARAM)&acs);
			}
		  EndDialog(hDlg, TRUE);
		 return(TRUE);
		case IDCANCEL:
		  EndDialog(hDlg, FALSE);
		 return(TRUE);
		default:
		 return(TRUE);
	  }
	default : return(FALSE);
  	}

}

//--------------------------------------------------------------------
//                           addToListDlgInit
//--------------------------------------------------------------------

int addToListDlgInit(void)
{

	HWND hwnd = CreateDialog(hInst, MAKEINTRESOURCE(IDD_ADDTOLIST), NULL, (DLGPROC)addToListC6);
	if (hwnd) ShowWindow(hwnd, SW_SHOW);
	else MessageBox(GetFocus(),"Error Not AddToList Dlg","Miranda IM", MB_ICONINFORMATION);

	return (int)hwnd;
}

//--------------------------------------------------------------------
//                           selUserComboBox
//--------------------------------------------------------------------

void selUserComboBox(HWND hwndCombo, LPSTR names)
{

	int iItem;
	int i, number, j, l;
	char szNick[20], szPredNick[20];
	DBVARIANT dbv;
	LPSTR szPass;

	number = names[0];
	names++;

    if(!DBGetContactSetting(NULL, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {

	    strcpy(szPredNick, dbv.pszVal);
		DBFreeVariant(&dbv);

	}

	j = 0;

	for (i = 0; i<number; i++)
	{
		l = names[0];

		names++;
		strncpy(szNick, names, l);
		szNick[l]='\0';

		names+=l;
		iItem = SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)szNick);
		if (strcmp(szNick, szPredNick)==0)
			j = i;

		l = names[0];

		names++;
		szPass=(LPSTR)mir_alloc(l + 1);
		strncpy(szPass, names, l);
		szPass[l]='\0';

		names+=l;
		SendMessage(hwndCombo, CB_SETITEMDATA, iItem, (LPARAM)szPass);
	}

	SendMessage(hwndCombo, CB_SETCURSEL, (WPARAM)j, 0L);

}

//--------------------------------------------------------------------
//                         freeSelUserComboBox
//--------------------------------------------------------------------

void freeSelUserComboBox(HWND hwndCombo)
{

	int iItem;
	int i;
	LPSTR pszPass;

	iItem = SendMessage(hwndCombo, CB_GETCOUNT, 0, 0L);
	for (i = 0; i<iItem; i++)
	{
		pszPass = (LPSTR)SendMessage(hwndCombo, CB_GETITEMDATA, i, 0L);
		mir_free(pszPass);
	}

}

//--------------------------------------------------------------------
//                           selectUserProc
//--------------------------------------------------------------------

#pragma argsused
long CALLBACK selectUserProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	char szNick[20];
 	LPSTR pszPass;
 	int iItem;

 	switch (message) {
	case WM_INITDIALOG :
		{

		TranslateDialogDefault(hDlg);

		char szProtoName[100];
		_snprintf(szProtoName, 100, "%s %s", C6PROTOCOLNAME, Translate("Select User"));
		SetWindowText(hDlg, szProtoName);

		selUserComboBox(GetDlgItem(hDlg, IDC_SELUSER), (LPVOID)lParam);
		windowCentered(hDlg);
		}
	 return 0;
	case WM_COMMAND :
		switch (LOWORD(wParam)) {

		case IDOK:
		 	GetDlgItemText(hDlg, IDC_SELUSER, szNick, 20);
		  	iItem = SendDlgItemMessage(hDlg, IDC_SELUSER, CB_GETCURSEL, 0, 0L);
		  	if (iItem!=CB_ERR) {

				pszPass=(LPSTR)SendDlgItemMessage(hDlg, IDC_SELUSER, CB_GETITEMDATA, iItem, 0L);

			  	if (DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "UseXCAP", 0))
					setXCAPPassword(szNick, pszPass);

				if (strlen(pszPass)>8)
					pszPass[8]='\0';

		  	  	if (c6LoginServ(szNick, pszPass))
			  		DBWriteContactSettingString(NULL,C6PROTOCOLNAME,C6_LOGINID, szNick);

		  	  	freeSelUserComboBox(GetDlgItem(hDlg, IDC_SELUSER));

			} else MessageBox(GetFocus(), "No Password Detected", "Miranda IM", MB_ICONSTOP);
		  	EndDialog(hDlg, TRUE);
		return(TRUE);
		case IDCANCEL:
	  	  	freeSelUserComboBox(GetDlgItem(hDlg, IDC_SELUSER));
			EndDialog(hDlg, FALSE);
		return(TRUE);
		default:
		return(TRUE);
		}
	default : return(FALSE);
  	}

}

//--------------------------------------------------------------------
//                           selectUserDlgInit
//--------------------------------------------------------------------

int selectUserDlgInit(LPSTR lpBuffer)
{

	return DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_SELECTUSER), NULL, (DLGPROC)selectUserProc, (LPARAM)lpBuffer);

}

#ifdef _C6_ROOM

typedef struct {
	LPSTR pszRoom;
	int iNumber;
	int iType;
} C6CMPSTR;

//--------------------------------------------------------------------
//                            getTypeRoom
//--------------------------------------------------------------------

LPSTR getTypeRoom(BYTE kind)
{

    switch (kind & 0x07) {

		case PUBLIC_C6:
        	return Translate("C6 Public");
        case PUBLIC_NET:
        	return Translate("Netfriend Public");
        case PRIVATE_NET:
        	return Translate("Netfriend Private");
    	default:
        	return Translate("C6 Private");
    }

}

//--------------------------------------------------------------------
//                         insertInRoomList
//--------------------------------------------------------------------

void insertInRoomList(HWND hwndLV, LPSTR pszRoom, int iNumber, int iType)
{
	LV_ITEM lvi;

	memset(&lvi,0x00,sizeof(LV_ITEM));
	lvi.mask = LVIF_TEXT|LVIF_PARAM;;
 	lvi.iItem = 0x7FFF;
	lvi.iSubItem = 0;
 	lvi.pszText = (LPSTR)pszRoom;
 	lvi.cchTextMax = sizeof(pszRoom);

	C6CMPSTR *cstr=(C6CMPSTR *)mir_alloc(sizeof(C6CMPSTR));

	cstr->pszRoom = mir_strdup(pszRoom);
	cstr->iNumber = iNumber;
	cstr->iType = iType;

	lvi.lParam = (LPARAM)cstr;

    int index = ListView_InsertItem(hwndLV, &lvi);

    char szNumber[5];

	_snprintf(szNumber, 5, "%d", iNumber);

 	memset(&lvi,0x00,sizeof(LV_ITEM));
	lvi.mask = LVIF_TEXT;
 	lvi.iItem = index;
    lvi.iSubItem = 1;
 	lvi.pszText = (LPSTR)szNumber;
 	lvi.cchTextMax = sizeof(szNumber);

    ListView_SetItem(hwndLV, &lvi);

    char szType[25];

	strcpy(szType, getTypeRoom(iType));

 	memset(&lvi,0x00,sizeof(LV_ITEM));
	lvi.mask = LVIF_TEXT;
 	lvi.iItem = index;
    lvi.iSubItem = 2;
 	lvi.pszText = (LPSTR)szType;
 	lvi.cchTextMax = sizeof(szType);

    ListView_SetItem(hwndLV, &lvi);

}

//--------------------------------------------------------------------
//                          cleanLVParam
//--------------------------------------------------------------------

void cleanLVParam(HWND hwndLV)
{
	int i;
	LV_ITEM lvi;

	int tot=ListView_GetItemCount(hwndLV);
	for (i=0;i<tot;i++){

		memset(&lvi,0x00,sizeof(LV_ITEM));
		lvi.mask = LVIF_PARAM;
 		lvi.iItem = i;
    	lvi.iSubItem = 0;

    	ListView_GetItem(hwndLV, &lvi);
		C6CMPSTR *cstr=(C6CMPSTR *)lvi.lParam;
		mir_free((LPSTR)cstr->pszRoom);
		mir_free(cstr);

	}
}

//--------------------------------------------------------------------
//                          getLVRoomKind
//--------------------------------------------------------------------

int getLVRoomKind(HWND hwndLV, int index)
{
	LV_ITEM lvi;

	memset(&lvi,0x00,sizeof(LV_ITEM));
	lvi.mask = LVIF_PARAM;
	lvi.iItem = index;
   	lvi.iSubItem = 0;

    ListView_GetItem(hwndLV, &lvi);
	C6CMPSTR *cstr=(C6CMPSTR *)lvi.lParam;
	return cstr->iType;
}

//--------------------------------------------------------------------
//                           roomListListView
//--------------------------------------------------------------------

void roomListListView(HWND hwndLV, LPSTR names)
{

	int i, number, l, nPeople, kind;
	char szRoom[120];

	number = names[0] << 8 ;
	number |= names[1] ;
	names += 2;

    for (i = 0; i < number; i++) {

		l = names[0];

		names++;
		strncpy(szRoom, names, l);
		szRoom[l] = '\0';

		names += l;

		nPeople = names[0] << 8 ;
		nPeople |= (unsigned char)names[1] ;
		names += 2;

		kind = names[0];

		names += 3;

		insertInRoomList(hwndLV, szRoom, nPeople, kind);
	}

	_snprintf(szRoom, 120, Translate("%d room(s)"), number);
	SetWindowText(GetDlgItem(GetParent(hwndLV), IDC_NUMBERROOM), szRoom);

}

//--------------------------------------------------------------------
//                        roomListMultiListView
//--------------------------------------------------------------------

void roomListMultiListView(HWND hwndLV, LPSTR names)
{

	int i, number, l, nPeople, kind, ntype;
	char szRoom[120];

	number = names[0] << 8 ;
	number |= names[1] ;
	names += 2;

    for (i = 0; i < number; i++) {

		l = names[0];

		names++;
		strncpy(szRoom, names, l);
		szRoom[l] = '\0';

		names += l;

		nPeople = names[0] << 8 ;
		nPeople |= (unsigned char)names[1] ;
		names += 5;

		kind = names[0];

		names += 1;
		ntype = names[0] << 8 ;
		ntype |= names[1] ;

		names += 2;
		names += ntype * 2 + 4;

		insertInRoomList(hwndLV, szRoom, nPeople, kind);
	}

	_snprintf(szRoom, 120, Translate("%d room(s)"), number);
	SetWindowText(GetDlgItem(GetParent(hwndLV), IDC_NUMBERROOM), szRoom);

}

//--------------------------------------------------------------------
//                      programme functions ...
//--------------------------------------------------------------------

typedef struct programme_l
{
	int hour,minute;
  	char pszRoomName[120];
    char pszComment[120];
};

void newreport(HWND hDlg,int hour,int minute,LPSTR pszRoomName,LPSTR pszComment)
{

 	struct programme_l *prlst;
 	int    i;

 	prlst = (struct programme_l*)mir_alloc(sizeof(struct programme_l));

 	if (prlst) {
	 	prlst->hour=hour;
		prlst->minute=minute;
		strcpy(prlst->pszRoomName,pszRoomName);
		strcpy(prlst->pszComment,pszComment);

		bLBStopView = TRUE;

 		i=SendDlgItemMessage(hDlg,IDC_PR_LIST, LB_ADDSTRING, 0, (LPARAM)pszRoomName);
	 	SendDlgItemMessage(hDlg,IDC_PR_LIST, LB_SETITEMDATA, i,(LPARAM)prlst);

		bLBStopView = FALSE;
	}

}

typedef FILE *PFILE;

static BOOL searchhtmtag(PFILE *f,char *s)
{

	unsigned int i;
 	char c;
 	BOOL bFound;

 	bFound = FALSE;
 	while (!feof(*f) && !bFound) {
		fscanf(*f, "%c", &c);
		if (c=='<'){
			i=0;
			while (fscanf(*f, "%c", &c) != EOF && c != '>') {
				if (c == s[i])
					i++;
				else i = 0;
				if (i == strlen(s))
					bFound = TRUE;
			}
		}
  	}
	return bFound;

}

int loadhtm(PFILE *f, char *tag, char *s)
{

	unsigned int i;
 	unsigned char c;
 	BOOL bFound;

	s[0] = '\0';
	// skip tag
	bFound = FALSE;
	while (!feof(*f) && !bFound){
		fscanf(*f, "%c", &c);
		if (c == '<'){
			DWORD pos = ftell(*f);
			i=0;
			while (fscanf(*f, "%c", &c) != EOF && c != '>') {
				if (c == tag[i])
					i++;
				else i = 0;
				if (i == strlen(tag)){
					fseek(*f, pos-1, SEEK_SET);
					return 1;
				}
			}
		}
		else if (c!='\n' && c!='\r' && c!=' ' && c!=0xA0){
			bFound=TRUE;
		}
	}

	i = 0;
	if (!feof(*f)){

		s[i++] = c;
		while (fscanf(*f, "%c", &c) != EOF && c != '<' && i < 50) {
			s[i++] = c;
		}
		if (!feof(*f)){
			DWORD pos = ftell(*f);
			fseek(*f, pos-1, SEEK_SET);
		}
	}
	s[i] = '\0';

	return 0;

}

static BOOL m_isdigit(char c)
{
	return (c=='0' || c=='1' || c=='2' || c=='3' || c=='4' ||
	        c=='5' || c=='6' || c=='7' || c=='8' || c=='9' );
}

static void gethhmm(char *s, int *hh, int *mm)
{

	unsigned int i = 0;

	while (!m_isdigit(s[i]) && i < strlen(s)) i++;

	char *p = strtok(&s[i], ":");
	if (p){
		*hh = atoi(p);
		p = strtok(NULL, " ");
		if (p)
			*mm = atoi(p);
	}

}

static void decodehtm(HWND hDlg, LPSTR pszFile, int jump, char *szsearch)
{

	PFILE stream;
 	int hh, mm, j;
 	LPSTR pszTime, pszRoomName, pszArgument;

 	if ((stream = fopen(pszFile,"rb")) != NULL) {

		while (!feof(stream))
			if (searchhtmtag(&stream, szsearch)) {

				pszTime = mir_alloc(120);
	  			loadhtm(&stream, szsearch, pszTime);

				hh = mm = 0;
				gethhmm(pszTime, &hh, &mm);

				pszRoomName = mir_alloc(120);

				loadhtm(&stream, szsearch, pszRoomName);

				pszArgument = mir_alloc(500);

				j = jump;
				BOOL bFound = FALSE;

				while (j > 0 && !bFound){
					if (loadhtm(&stream, szsearch, pszArgument))
						bFound = TRUE;
					j--;
				}

				if (strlen(pszRoomName))
		  			newreport(hDlg, hh, mm, pszRoomName, pszArgument);

				mir_free(pszTime);
				mir_free(pszRoomName);
				mir_free(pszArgument);

     		}

		fclose(stream);
 	}

}

int setProgrammeDate(HWND hDlg,LPSTR pszFile)
{

	HANDLE hFile;
 	FILETIME   ftLastWrite;
 	SYSTEMTIME st;
	char szbuf[20];

 	hFile = CreateFile(pszFile,GENERIC_READ,FILE_SHARE_READ,
		  				(LPSECURITY_ATTRIBUTES) NULL, OPEN_EXISTING,
		  				FILE_ATTRIBUTE_NORMAL, (HANDLE) NULL);
 	if (hFile == (HANDLE) INVALID_HANDLE_VALUE)
		return 1;

 	GetFileTime(hFile, NULL, NULL, &ftLastWrite);
 	FileTimeToSystemTime(&ftLastWrite, &st);

	CloseHandle((HANDLE) hFile);
	_snprintf(szbuf, 20, "( %02d/%02d/%04d )", st.wDay, st.wMonth, st.wYear);
	SetDlgItemText(hDlg, IDC_PR_FILEDATE, szbuf);
	return 0;

}

//--------------------------------------------------------------------
//                        loadProgrammeThread
//--------------------------------------------------------------------

typedef struct ProgrammeData_s {
	HWND hDlg;
} ProgrammeData;

DWORD WINAPI loadProgrammeThread(LPVOID param)
{

	CallService (MS_SYSTEM_THREAD_PUSH, 0, 0);

	ProgrammeData* data = (ProgrammeData*) (param);
	LPSTR pszFile;

	SetDlgItemText(data->hDlg,IDC_PR_STATUS,Translate("Loading..."));

	if (getProgrammeFile(&pszFile)) {

		decodehtm(data->hDlg,pszFile,1,"span class=\"date\"");
		setProgrammeDate(data->hDlg, pszFile);
		mir_free(pszFile);

	}

	mir_free(data);

	InvalidateRect(data->hDlg,NULL,TRUE);

	SetDlgItemText(data->hDlg,IDC_PR_STATUS,Translate("Ok"));
	EnableWindow(GetDlgItem(data->hDlg,IDC_PR_REFRESH),TRUE);

	CallService (MS_SYSTEM_THREAD_POP, 0, 0);

	return 0;

}

//--------------------------------------------------------------------
//                        roomListCompareFunc
//--------------------------------------------------------------------

int CALLBACK roomListCompareFunc(LPARAM lParam1,LPARAM lParam2,LPARAM lParamSort)
{

	C6CMPSTR *cstr1 = (C6CMPSTR *)lParam1;
	C6CMPSTR *cstr2 = (C6CMPSTR *)lParam2;
	struct RoomListData *dat=(struct RoomListData*)lParamSort;
	LPSTR pszBuf1,pszBuf2;
	int iCmp=0;

	if (lParam1==0 || lParam2==0)  return (0);
	switch (dat->iSubItem){
		case 0 : // room name
			pszBuf1 = mir_strdup(cstr1->pszRoom);
			pszBuf2 = mir_strdup(cstr2->pszRoom);
		break;
		case 1 : // users number
			if (cstr1->iNumber > cstr2->iNumber)
				iCmp = -1;
			else if (cstr1->iNumber < cstr2->iNumber)
				iCmp = 1;
			else iCmp = 0;
		break;
		default : // room type
			pszBuf1 = (LPSTR)mir_alloc(10);
			pszBuf2 = (LPSTR)mir_alloc(10);
			_snprintf(pszBuf1, 10, "%d", cstr1->iType);
			_snprintf(pszBuf2, 10, "%d", cstr2->iType);
		break;
	}

	if (dat->iSubItem==0 || dat->iSubItem==2) {
		iCmp = lstrcmpi(pszBuf1,pszBuf2);
		mir_free(pszBuf1);
		mir_free(pszBuf2);
	}

	if (dat->bSortAscending)
		iCmp = -iCmp;
	return ((iCmp != 0) ? iCmp : 0);

}

//--------------------------------------------------------------------
//                           createRoomProc
//--------------------------------------------------------------------

#pragma argsused
long CALLBACK createRoomProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

 switch (message)
  {
	case WM_INITDIALOG :
		{
			TranslateDialogDefault(hDlg);

			InitComboBoxRoom(GetDlgItem(hDlg, IDC_MULTIVIEW), &groupField[1]);
			SendDlgItemMessage(hDlg, IDC_MULTIVIEW, CB_SETCURSEL, 1, 0L);

			char szProtoName[100];
			_snprintf(szProtoName, 100, "%s %s", C6PROTOCOLNAME, Translate("Create Room"));
			SetWindowText(hDlg,szProtoName);

			char szUser[20];
			GetUserNickName(szUser);
			SetDlgItemText(hDlg,IDC_RC_NICK,szUser);

			SendDlgItemMessage(hDlg,IDC_RC_PUBLIC, BM_SETCHECK, (WPARAM)1, 0L);

			char szArgument[128];
			_snprintf(szArgument, 128, "%s %s", Translate("Room create by"), szUser);
			SetDlgItemText(hDlg,IDC_RC_ARGUMENT,szArgument);
			windowCentered(hDlg);


		}
	 return 0;
	case WM_COMMAND :
	 switch (LOWORD(wParam))
	  {
		case IDC_RC_CREATE :
			{

				char szUser[20],szArgument[128],szPassword[128];
				int category;
				LPSTR pszRoomName;

				GetDlgItemText(hDlg, IDC_RC_NICK, szUser, 20);
				pszRoomName=(LPSTR)mir_alloc(121);

				GetDlgItemText(hDlg, IDC_RC_ROOMNAME, pszRoomName, 120);
				GetDlgItemText(hDlg, IDC_RC_ARGUMENT, szArgument, 128);

				int kind = SendDlgItemMessage(hDlg, IDC_RC_PUBLIC, BM_GETCHECK, 0, 0L);

				GetDlgItemText(hDlg, IDC_RC_PASSWORD, szPassword, 128);
				category = SendDlgItemMessage(hDlg, IDC_MULTIVIEW, CB_GETCURSEL, 0, 0L);

				if (strlen(pszRoomName)) {
					// new room
					category++;
					if (c6reqCreateNewRoom(szUser, pszRoomName, szArgument, szPassword, kind, category))
						c6GcInit(pszRoomName, 1);

					mir_free(pszRoomName);
					EndDialog(hDlg, TRUE);
				}
				else {
					MessageBox(GetFocus(),Translate("No Room Name Specified"),"Miranda IM",MB_ICONSTOP);
					mir_free(pszRoomName);
				}
			}
		 return TRUE;
		case IDCANCEL:
		  EndDialog(hDlg, FALSE);
		 return(TRUE);
		default:
		 return(TRUE);
	  }
	default : return(FALSE);
  }
}

//--------------------------------------------------------------------
//                           createRoomDlgInit
//--------------------------------------------------------------------

int createRoomDlgInit(void)
{

	return DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_CREATEROOM), NULL, (DLGPROC)createRoomProc, (LPARAM)0);

}

//--------------------------------------------------------------------
//                         InitComboBoxRoom
//--------------------------------------------------------------------

void InitComboBoxRoom(HWND hwndCombo,char **names)
{

	int i;

	for (i = 0; ; i++)
	{
		if (names[i] == NULL)
			break;
		SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)Translate(names[i]));
	}

	SendMessage(hwndCombo, CB_SETCURSEL, 0, 0L);

}

//--------------------------------------------------------------------
//                           multiChatProc
//--------------------------------------------------------------------

#pragma argsused
long CALLBACK multiChatProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	struct RoomListData *dat;

	dat = (struct RoomListData*)GetWindowLong(hDlg, USERDATA);
 	switch (message) {
	case WM_INITDIALOG : {

		TranslateDialogDefault(hDlg);

		hwndGC = hDlg;

		char szProtoName[100];
		_snprintf(szProtoName, 100, "%s %s", C6PROTOCOLNAME, Translate("Group Chat"));
		SetWindowText(hDlg,szProtoName);

      	LV_COLUMN col;

 		col.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;
 		col.fmt  = LVCFMT_LEFT;
 		col.pszText = Translate("Room");
 		col.cchTextMax = 0;
 		col.cx = 135;
 		col.iSubItem = 0;
 		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 0, &col);

 		col.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;
 		col.fmt  = LVCFMT_RIGHT;
 		col.pszText = Translate("Users");
 		col.cchTextMax = 0;
 		col.cx = 50;
 		col.iSubItem = 0;
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 1, &col);

 		col.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;
 		col.fmt  = LVCFMT_LEFT;
 		col.pszText = Translate("Type");
 		col.cchTextMax = 0;
 		col.cx = 90;
 		col.iSubItem = 0;
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 2, &col);

		dat = (struct RoomListData*)mir_alloc(sizeof(struct RoomListData));
		SetWindowLong(hDlg, USERDATA, (LONG)dat);
		dat->iIndex = 0;
		dat->iSubItem = 0;
		dat->iLastColumnSortIndex = 0;
		dat->bSortAscending = TRUE;

		InitComboBoxRoom(GetDlgItem(hDlg, IDC_AUTOUPDATE), updateField);

		InitComboBoxRoom(GetDlgItem(hDlg, IDC_MULTIVIEW), groupField);

		char szFile[MAX_PATH];
		getOC6DataDir(szFile, MAX_PATH);
		strcat(szFile, "palinsesto2.html");

		{

			BYTE i = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "GroupChatAutoProfile", 0);
			SendDlgItemMessage(hDlg, IDC_AUTOPROFILE, BM_SETCHECK, (WPARAM)i, 0L);

			i = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "GroupChatUpdate", 0);
			SendDlgItemMessage(hDlg, IDC_AUTOUPDATE, CB_SETCURSEL, (WPARAM)i, 0L);
			if (i)
				SendMessage(hDlg, WM_COMMAND, (WPARAM)MAKELONG(IDC_AUTOUPDATE, CBN_SELCHANGE), 0L);

			dat->iLastColumnSortIndex = dat->iSubItem = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "GroupChatRoomSort", 0);

			i = DBGetContactSettingByte(NULL, C6PROTOCOLNAME, "GroupChatMultiView", 0);
			SendDlgItemMessage(hDlg, IDC_MULTIVIEW, CB_SETCURSEL, (WPARAM)i, 0L);
			if (i)
				SendMessage(hDlg, WM_COMMAND, (WPARAM)MAKELONG(IDC_MULTIVIEW, CBN_SELCHANGE), 0L);

			decodehtm(hDlg, szFile, 1, "span class=\"date\"");

		}

		setProgrammeDate(hDlg, szFile);

		windowCentered(hDlg);

		SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_C6)));
		}
	 return 0;
	case WM_NOTIFY : {
		LPNM_LISTVIEW pnmhdr=(LPNM_LISTVIEW)lParam;
		switch (pnmhdr->hdr.code) {
			case NM_CLICK :
				if (pnmhdr->iItem >= 0)	{
					char szRoom[120];
					dat->iIndex = pnmhdr->iItem;
					ListView_GetItemText(GetDlgItem(hDlg,IDC_ROOMLIST), pnmhdr->iItem, 0, szRoom, 120);
					SetDlgItemText(hDlg,IDC_ROOMNAME,szRoom);
					if (SendDlgItemMessage(hDlg, IDC_AUTOPROFILE, BM_GETCHECK, 0, 0L))
						SendMessage(hDlg, WM_COMMAND, (WPARAM)MAKELONG(IDC_PROFILEROOM,0), 0L);
				}
				break;
			case NM_DBLCLK :
				if (pnmhdr->hdr.idFrom==IDC_ROOMLIST) {

					if (pnmhdr->iItem >= 0) {

						char pszMsg[128];
						LPSTR pszRoom = (LPSTR)mir_alloc(121);

						ListView_GetItemText(GetDlgItem(hDlg,IDC_ROOMLIST), pnmhdr->iItem, 0, pszRoom, 120);

						int kind=getLVRoomKind(GetDlgItem(hDlg,IDC_ROOMLIST), pnmhdr->iItem);

						if ((kind & 0x07)!=PUBLIC_C6)
							_snprintf(pszMsg, 128, Translate("Warning: The content of this Room is not controlled by Virgilio"));

						if ((kind & 0x07)==PUBLIC_C6 ||
							((kind & 0x07)!=PUBLIC_C6 && MessageBox(0, pszMsg, Translate("Miranda IM"), MB_YESNO|MB_ICONASTERISK)==IDYES) )
							{

							char szUser[40];
							GetUserNickName(szUser);
							if (c6reqEnterExitRoom(1, szUser, pszRoom)){

								c6GcInit(pszRoom, 0);
							}

						}
						mir_free(pszRoom);
				    }

				}
				break;
			case LVN_COLUMNCLICK:
				{
					if(pnmhdr->iSubItem!=dat->iLastColumnSortIndex)
					{
							dat->bSortAscending=TRUE;
							dat->iLastColumnSortIndex=pnmhdr->iSubItem;
					} else dat->bSortAscending=!dat->bSortAscending;

					dat->iSubItem=pnmhdr->iSubItem;

					ListView_SortItems(GetDlgItem(hDlg, IDC_ROOMLIST), roomListCompareFunc, (LPARAM)dat);
					break;
				}

			}
		}
		return(TRUE);
	case WM_COMMAND :
	 switch (LOWORD(wParam))
	  {
		case IDC_REFRESHROOM:

			roomListDlgRefresh();

		  return(TRUE);
		case IDC_MULTIVIEW :
			if ((HIWORD(wParam) == CBN_SELCHANGE)) {

				numberGroup = SendDlgItemMessage(hDlg, IDC_MULTIVIEW, CB_GETCURSEL, 0, 0L);

			}
		 return(TRUE);
		case IDC_PROFILEROOM :
			{
				char szRoom[120];
				GetDlgItemText(hDlg,IDC_ROOMNAME,szRoom,120);
				if (strlen(szRoom) && amIOnline())
					c6reqProfileRoom(szRoom);
			}
		  return(TRUE);

		case IDC_ENTERROOM :
			{
				LPSTR pszRoom = mir_alloc(121);
				GetDlgItemText(hDlg, IDC_ROOMNAME, pszRoom, 120);

				if (strlen(pszRoom) && MessageBox(0, Translate("Try To enter in This Room?\nWarning: It Can be a Private NetFriend Room."), Translate("Miranda IM"), MB_YESNO|MB_ICONASTERISK)==IDYES) {

					char szUser[40];
					GetUserNickName(szUser);
					if (c6reqEnterExitRoom(1, szUser, pszRoom)) {

						c6GcInit(pszRoom, 0);

					}
				}

				mir_free(pszRoom);

			}
		 return(TRUE);
		case IDC_AUTOUPDATE :
			if ((HIWORD(wParam) == CBN_SELCHANGE)) {

				int i = SendDlgItemMessage(hDlg, IDC_AUTOUPDATE, CB_GETCURSEL, 0, 0L);
				int iDelay;
				if (i==1)
					iDelay=1;
				else if (i==2)
					iDelay=3;
				if (i==3)
					iDelay=5;
				if (bTimerAutoUpdate)
					KillTimer(hDlg, 101);
				if (i)
					if (SetTimer(hDlg, 101, 60000*iDelay, (TIMERPROC)multiChatProc))
						bTimerAutoUpdate=TRUE;

			}
		 return(TRUE);
		case IDC_PR_REFRESH :
			{

				SendDlgItemMessage(hDlg,IDC_PR_LIST,LB_RESETCONTENT,0,0L);
				EnableWindow(GetDlgItem(hDlg,IDC_PR_REFRESH),FALSE);

				ProgrammeData* data = (ProgrammeData*)mir_alloc(sizeof(ProgrammeData));
				data->hDlg = hDlg;

				DWORD id;
				CloseHandle (CreateThread (NULL, 0, (LPTHREAD_START_ROUTINE)loadProgrammeThread, (LPVOID)data, 0, &id));

			}
		return(TRUE);

	 	case IDC_PR_LIST :

			if ((HIWORD(wParam) == LBN_SELCHANGE)) {
			 	DWORD i=SendDlgItemMessage(hDlg,IDC_PR_LIST,LB_GETCURSEL,0,0L);
			 	if (i!=LB_ERR) {
			 		struct programme_l* prlst = (struct programme_l*)SendDlgItemMessage(hDlg,IDC_PR_LIST, LB_GETITEMDATA, (WPARAM)i, 0L);
			 		if (prlst) {
						SetDlgItemText(hDlg,IDC_ROOMNAME,prlst->pszRoomName);
						if (SendDlgItemMessage(hDlg, IDC_AUTOPROFILE, BM_GETCHECK, 0, 0L))
							SendMessage(hDlg, WM_COMMAND, (WPARAM)MAKELONG(IDC_PROFILEROOM,0), 0L);
					}
				}
			}
			if ((HIWORD(wParam) == LBN_DBLCLK)) {
			 	DWORD i=SendDlgItemMessage(hDlg,IDC_PR_LIST,LB_GETCURSEL,0,0L);
			 	if (i!=LB_ERR) {
			 		struct programme_l* prlst = (struct programme_l*)SendDlgItemMessage(hDlg,IDC_PR_LIST, LB_GETITEMDATA, (WPARAM)i, 0L);
			 		if (prlst) {
						if (MessageBox(GetFocus(),prlst->pszRoomName,Translate("Entry Into..."),MB_YESNO)==IDYES) {
							char szUser[40];
							GetUserNickName(szUser);
							if (c6reqEnterExitRoom(1, szUser, prlst->pszRoomName)){

								c6GcInit(prlst->pszRoomName, 0);

							}
						}
					}
				}
			}
			return(TRUE);
		case IDC_NEWROOM :
			if (amIOnline())
				 createRoomDlgInit();
		 return(TRUE);
		case IDCANCEL:
		  	ShowWindow(hDlg, SW_HIDE);
		 return(TRUE);
		default:
		 return(TRUE);
	  }
	case WM_TIMER :
		if (IsWindowVisible(hDlg))
			SendMessage(hDlg, WM_COMMAND, (WPARAM)MAKELONG(IDC_REFRESHROOM, 0), 0L);
		 return(TRUE);
	case WM_MEASUREITEM:
	{
	 	LPMEASUREITEMSTRUCT lpmis = (LPMEASUREITEMSTRUCT) lParam;
	 	if (lpmis->CtlType==ODT_LISTBOX)
	  		lpmis->itemHeight=32;
	}
	return TRUE;
	case WM_DRAWITEM:
	{
	 LPDRAWITEMSTRUCT lpdis = (DRAWITEMSTRUCT FAR*) lParam;
	 if (wParam!=IDC_PR_LIST) return 0;
	 if (!bLBStopView)
	 switch (lpdis->itemAction) {
		case ODA_DRAWENTIRE:
		case ODA_SELECT:
			{
			struct programme_l* prlst = (struct programme_l*)SendDlgItemMessage(hDlg,IDC_PR_LIST, LB_GETITEMDATA, (WPARAM)lpdis->itemID, 0L);
		 	if (prlst) {
				char szbuf[128];
				RECT rclip;

				SetTextAlign(lpdis->hDC,TA_LEFT);
			  	SetBkMode(lpdis->hDC,TRANSPARENT);
				HFONT hfont = CreateFont(-11, 0, 0, 0, 700, 0, 0, 0, 0, 1, 2, 1, 34, "MS Sans Serif");

 				HFONT oldfont = SelectObject(lpdis->hDC, hfont);

			    SetRect(&rclip, lpdis->rcItem.left, lpdis->rcItem.top, lpdis->rcItem.right, lpdis->rcItem.bottom);
				if ((lpdis->itemState &ODS_SELECTED) == ODS_SELECTED)	{
					FillRect(lpdis->hDC, &rclip, (HBRUSH) (COLOR_WINDOWTEXT+1));
			  		SetTextColor(lpdis->hDC, GetSysColor(COLOR_WINDOW));
				} else {
					FillRect(lpdis->hDC, &rclip, (HBRUSH) (COLOR_WINDOW+1));
			  		SetTextColor(lpdis->hDC, GetSysColor(COLOR_WINDOWTEXT));
				}
			    // hour:minute
			  	_snprintf(szbuf, 128, "%02d:%02d", prlst->hour, prlst->minute);
   				SetRect(&rclip, lpdis->rcItem.left + 10, lpdis->rcItem.top, lpdis->rcItem.left + 50, lpdis->rcItem.bottom - 16);
				ExtTextOut(lpdis->hDC, lpdis->rcItem.left + 10, lpdis->rcItem.top ,ETO_CLIPPED, &rclip,
					szbuf, strlen(szbuf), (LPINT)NULL);

			  	// roomname
			  	_snprintf(szbuf, 128, "%s", prlst->pszRoomName);
   				SetRect(&rclip, lpdis->rcItem.left+50,lpdis->rcItem.top,lpdis->rcItem.right-5,lpdis->rcItem.bottom-16);
				ExtTextOut(lpdis->hDC, lpdis->rcItem.left + 50, lpdis->rcItem.top, ETO_CLIPPED, &rclip,
					szbuf, strlen(szbuf), (LPINT)NULL);

				DeleteObject(hfont);
				SelectObject(lpdis->hDC,oldfont);
			  	// comment
			  	_snprintf(szbuf, 128, "%s", prlst->pszComment);
   				SetRect(&rclip, lpdis->rcItem.left + 50, lpdis->rcItem.top + 16, lpdis->rcItem.right - 5, lpdis->rcItem.bottom);
				ExtTextOut(lpdis->hDC,lpdis->rcItem.left+50,lpdis->rcItem.top+16,ETO_CLIPPED,&rclip,
					szbuf, strlen(szbuf), (LPINT)NULL);

			}
		  	}
			return TRUE;
		case ODA_FOCUS:
		 	return 1;
	 	}
	 }
	 return 0;
	case WM_DELETEITEM :
	 {
	  	LPDELETEITEMSTRUCT lpdi;
	  	struct programme_l* prlst;

		lpdi = (LPDELETEITEMSTRUCT) lParam;
	  	if (lpdi->CtlType!=ODT_LISTBOX)
			return 0;
	  	if ((prlst = (struct programme_l*)lpdi->itemData)!=NULL) {
			mir_free(prlst);

		}
	 }
	 return TRUE;
	case WM_DESTROY :
			{

				int i = SendDlgItemMessage(hDlg, IDC_AUTOUPDATE, CB_GETCURSEL, 0, 0L);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "GroupChatUpdate", (BYTE)i);
				i = SendDlgItemMessage(hDlg, IDC_AUTOPROFILE, BM_GETCHECK, 0, 0L);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "GroupChatAutoProfile", (BYTE)i);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "GroupChatRoomSort", (BYTE)dat->iLastColumnSortIndex);
				i = SendDlgItemMessage(hDlg, IDC_MULTIVIEW, CB_GETCURSEL, 0, 0L);
				DBWriteContactSettingByte(NULL, C6PROTOCOLNAME, "GroupChatMultiView", (BYTE)i);

			}

			if (bTimerAutoUpdate)
				KillTimer(hDlg, 101);
			cleanLVParam(GetDlgItem(hDlg,IDC_ROOMLIST));
			SendDlgItemMessage(hDlg,IDC_PR_LIST,LB_RESETCONTENT,0,0L);
			mir_free(dat);
		 return(TRUE);
	default : return(FALSE);
  }
}

//--------------------------------------------------------------------
//                           roomListDlgInit
//--------------------------------------------------------------------

int roomListDlgInit(void)
{

	if (hwndGC == NULL)
		CreateDialog(hInst, MAKEINTRESOURCE(IDD_MULTICHAT), NULL, (DLGPROC)multiChatProc);
	ShowWindow(hwndGC, SW_SHOW);

	return 1;

}

//--------------------------------------------------------------------
//                           roomListDlgDone
//--------------------------------------------------------------------

void roomListDlgDone(void)
{

	if (hwndGC){
    	DestroyWindow(hwndGC);
		hwndGC = 0;
	}

}

//--------------------------------------------------------------------
//                         roomListDlgBuf
//--------------------------------------------------------------------

void roomListDlgBuf(int action, LPSTR lpBuffer)
{

	ShowWindow(hwndGC, SW_SHOW);

	if (lpBuffer){

		if (numberGroup && action)
			roomListMultiListView(GetDlgItem(hwndGC, IDC_ROOMLIST), lpBuffer);
		else roomListListView(GetDlgItem(hwndGC, IDC_ROOMLIST), lpBuffer);

		struct RoomListData *dat;
		dat = (struct RoomListData*)GetWindowLong(hwndGC, USERDATA);
		ListView_SortItems(GetDlgItem(hwndGC, IDC_ROOMLIST), roomListCompareFunc, (LPARAM)dat);
	}


}

//--------------------------------------------------------------------
//                        roomListDlgRefresh
//--------------------------------------------------------------------

void roomListDlgRefresh(void)
{

	cleanLVParam(GetDlgItem(hwndGC,IDC_ROOMLIST));
	ListView_DeleteAllItems(GetDlgItem(hwndGC,IDC_ROOMLIST));

	if (c6Status != ID_STATUS_OFFLINE) {

		char szUser[40]; // 20
		GetUserNickName(szUser);

		if (numberGroup){

			c6QueryMultiRooms(szUser,numberGroup);

		}
		else c6QueryRooms(szUser);
	}

}

//--------------------------------------------------------------------
//                           c6SetProfileRoom
//--------------------------------------------------------------------

void c6SetProfileRoom(LPSTR pszRoomName,LPSTR pszRoomInfo,LPSTR pszRoomOwner,BYTE kind,WORD nUsers)
{
	char szbuf[640];

	_snprintf(szbuf, 640, "%s", pszRoomName);
	SetWindowText(GetDlgItem(hwndGC,IDC_ROOMNAME),szbuf);

	_snprintf(szbuf, 640, "%s", pszRoomInfo);
	SetWindowText(GetDlgItem(hwndGC,IDC_PROFILERESULT),szbuf);

	_snprintf(szbuf, 640, "%s", pszRoomOwner);
	SetWindowText(GetDlgItem(hwndGC,IDC_ROOMOWNER),szbuf);

	_snprintf(szbuf, 640, "%s", getTypeRoom(kind));
	SetWindowText(GetDlgItem(hwndGC,IDC_ROOMKIND),szbuf);

	_snprintf(szbuf, 640, "%d", nUsers);
	SetWindowText(GetDlgItem(hwndGC,IDC_ROOMUSERS),szbuf);

}

//--------------------------------------------------------------------
//                           addItemModule
//--------------------------------------------------------------------

int addItemModule(HWND hwnd, LPSTR lpszItem)
{

	LVITEM lvi;
 	int    i;

 	memset(&lvi,0x00,sizeof(LV_ITEM));
 	lvi.mask = LVIF_TEXT | LVIF_STATE;
 	lvi.iItem = 0x7FFF;
 	lvi.pszText = (LPSTR)lpszItem;
 	lvi.cchTextMax = sizeof(lpszItem);

 	ListView_InsertItem(GetDlgItem(hwnd, IDC_IV_LIST), &lvi);
 	i=ListView_GetItemCount(GetDlgItem(hwnd, IDC_IV_LIST)) - 1;
 	ListView_SetItemState(GetDlgItem(hwnd,IDC_IV_LIST), i, (UINT)(((int)0 + 1) << 12), LVIS_STATEIMAGEMASK);
 	return i;

}

//--------------------------------------------------------------------
//                           inviteUserProc
//--------------------------------------------------------------------

#pragma argsused
long CALLBACK inviteUserProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

 switch (message)
  {
	case WM_INITDIALOG :
		{
			HANDLE hContact;
			char* szProto;
			DBVARIANT dbv;

			TranslateDialogDefault(hDlg);

			char szProtoName[100];
			_snprintf(szProtoName, 100, "%s %s", C6PROTOCOLNAME, Translate("Invite User"));
			SetWindowText(hDlg, szProtoName);

			SetDlgItemText(hDlg, IDC_IV_ROOM, (LPSTR)lParam);

		 	LV_COLUMN col;

 			col.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;
 			col.fmt  = LVCFMT_LEFT;
 			col.pszText = "Users";
 			col.cchTextMax = 0;
 			col.cx = 216;
 			col.iSubItem = 0;
 			ListView_InsertColumn(GetDlgItem(hDlg,IDC_IV_LIST), 0, &col);

     		SendDlgItemMessage(hDlg, IDC_IV_LIST, LVM_SETEXTENDEDLISTVIEWSTYLE,
	  						(WPARAM)0, (LPARAM)(LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT));

			hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDFIRST, 0, 0);
			while (hContact != NULL) {

				szProto = (char*)CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM)hContact, 0);

				if (szProto != NULL && !strcmp(szProto, C6PROTOCOLNAME))
					if (DBGetContactSettingWord(hContact, C6PROTOCOLNAME, "Status", ID_STATUS_OFFLINE) != ID_STATUS_OFFLINE)
						if(DBGetContactSettingByte(hContact, C6PROTOCOLNAME, "ChatRoom", 0) == 0) {
		    	    		if(!DBGetContactSetting(hContact, C6PROTOCOLNAME, C6_LOGINID, &dbv)) {
								if (strlen(dbv.pszVal))
	 								addItemModule(hDlg, dbv.pszVal);
							DBFreeVariant(&dbv);
						}
					}

				hContact = (HANDLE)CallService(MS_DB_CONTACT_FINDNEXT, (WPARAM)hContact, 0);
			}

			windowCentered(hDlg);

		}
	 return 0;
	case WM_COMMAND :
	 switch (LOWORD(wParam))
	  {
		case IDC_IV_INVITE :
			{

				int i;
				char szUser[40], szNick[40]; // 20
				LPSTR pszMessage=(LPSTR)mir_alloc(256);
				LPSTR pszComment=(LPSTR)mir_alloc(128);
				LPSTR pszRoom=(LPSTR)mir_alloc(128);

				for (i=0;i<ListView_GetItemCount(GetDlgItem(hDlg,IDC_IV_LIST));i++)
					if ((ListView_GetItemState(GetDlgItem(hDlg,IDC_IV_LIST), i, LVIS_STATEIMAGEMASK)>>12)-1) {
						// invite !
	          			ListView_GetItemText(GetDlgItem(hDlg,IDC_IV_LIST),i,0,(LPSTR)szNick,sizeof(szNick));

						GetDlgItemText(hDlg, IDC_IV_MESSAGE, pszComment, 128);
						GetDlgItemText(hDlg, IDC_IV_ROOM, pszRoom, 128);

						mir_snprintf(pszMessage, 128, "ti invita ad entrare nella stanza \"room://%s\" - %s", pszRoom, pszComment);
						GetUserNickName(szUser);

						c6SendMessage2Serv(OL_MESSAGE, 13, ORDINARY_OP, szUser, szNick, pszMessage);

					}

				mir_free(pszRoom);
				mir_free(pszComment);
				mir_free(pszMessage);

				EndDialog(hDlg, TRUE);
			}
		 return TRUE;
		case IDCANCEL:
		  EndDialog(hDlg, FALSE);
		 return(TRUE);
		default:
		 return(TRUE);
	  }
	default : return(FALSE);
  }
}

//--------------------------------------------------------------------
//                         inviteUserDlgInit
//--------------------------------------------------------------------

int inviteUserDlgInit(LPSTR pszRoomName)
{

	return DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_INVITEUSER), NULL, (DLGPROC)inviteUserProc, (LPARAM)pszRoomName);

}

//--------------------------------------------------------------------
//                         setPasswordxRoomProc
//--------------------------------------------------------------------

#pragma argsused
BOOL CALLBACK passwordxRoomProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	static LPSTR pszRoomName;

	switch (message) {
	case WM_INITDIALOG :
		{

			pszRoomName = (LPSTR)lParam;
			TranslateDialogDefault(hDlg);
			SetWindowText(hDlg, Translate("set Password for Room"));

		}
	 return FALSE;
	case WM_COMMAND :
	 	switch (LOWORD(wParam)) {
		case IDOK :
			{

				char szPassword[121];
				char szUser[20];

				GetUserNickName(szUser);
				GetDlgItemText(hDlg, IDC_CUSTSTAT, szPassword, 120);

				if (strlen(szPassword))
					c6reqEnterNewRoom(szUser, pszRoomName, szPassword);
				else {
					c6GcQuit();
				}

				EndDialog(hDlg, 1);

			}
		   return TRUE;
	  	case IDCANCEL :
			c6GcQuit();
		 	EndDialog(hDlg, 0);
	   	return TRUE;
   	  	default:
	   	return(TRUE);
	  	}
	default : return(FALSE);
  	}

}

int setPasswordxRoom(LPSTR pszRoom)
{

	return DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_C6SETSTATMSG), NULL, (DLGPROC)passwordxRoomProc, (LPARAM)pszRoom);

}

/* code like from miranda/src/modules/skin/skinicons.c */
void Button_SetIcon_IcoLib(HWND hwndDlg, int itemId, int iconId, const char* tooltip)
{
	char szModule[128];
	HWND hWnd = GetDlgItem( hwndDlg, itemId );
	_snprintf(szModule, 128, "core_main_%d", iconId);
	HICON hIcon = (HICON) CallService(MS_SKIN2_GETICON, 0, (LPARAM) szModule);
	SendMessage( hWnd, BM_SETIMAGE, IMAGE_ICON, (LPARAM)hIcon);
	SendMessage( hWnd, BUTTONSETASFLATBTN, 0, 0 );
	SendMessage( hWnd, BUTTONADDTOOLTIP, (WPARAM)tooltip, 0);
}

/* code like from miranda/src/modules/skin/skinicons.c */
void Button_FreeIcon_IcoLib(HWND hwndDlg, int itemId)
{
	HICON hIcon = ( HICON )SendDlgItemMessage(hwndDlg, itemId, BM_SETIMAGE, IMAGE_ICON, 0 );
	CallService(MS_SKIN2_RELEASEICON, (WPARAM)hIcon, 0);
}

struct InviteRcvData {
	HANDLE hContact;
	HANDLE hDbEvent;
};

#define SKINICON_ORDER_USERDETAILS 9
#define SKINICON_ORDER_DOWNARROW  11
#define SKINICON_ORDER_HISTORY    10

BOOL CALLBACK InviteRecvProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	struct InviteRcvData *dat = (struct InviteRcvData *)GetWindowLong(hwndDlg, USERDATA);

	switch (msg) {
	case WM_INITDIALOG:
		{
			TranslateDialogDefault(hwndDlg);
			SendMessage(hwndDlg, WM_SETICON, ICON_SMALL, (LPARAM) LoadIcon(hInst, MAKEINTRESOURCE(IDI_GC)));

			Button_SetIcon_IcoLib(hwndDlg, IDC_DETAILS, SKINICON_ORDER_USERDETAILS, "View User's Details");
			Button_SetIcon_IcoLib(hwndDlg, IDC_USERMENU, SKINICON_ORDER_DOWNARROW, "User Menu");
			Button_SetIcon_IcoLib(hwndDlg, IDC_HISTORY, SKINICON_ORDER_HISTORY, "View User's History");

			dat =(struct InviteRcvData*)mir_alloc(sizeof(struct InviteRcvData));
			SetWindowLong(hwndDlg, USERDATA, (LONG)dat);

			dat->hContact = ((CLISTEVENT*)lParam)->hContact;
			dat->hDbEvent = ((CLISTEVENT*)lParam)->hDbEvent;

			DBEVENTINFO dbei;
			TCHAR* contactName;

			ZeroMemory(&dbei,sizeof(dbei));
			dbei.cbSize=sizeof(dbei);
			dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)dat->hDbEvent,0);
			dbei.pBlob=(PBYTE)mir_alloc(dbei.cbBlob);
			CallService(MS_DB_EVENT_GET,(WPARAM)dat->hDbEvent,(LPARAM)&dbei);
			SetDlgItemText(hwndDlg, IDC_ROOMNAME, (char*)dbei.pBlob);
			SetDlgItemText(hwndDlg, IDC_MESSAGE, (char*)dbei.pBlob + strlen((char*)dbei.pBlob) + 1);
			mir_free(dbei.pBlob);

			CallService(MS_DB_EVENT_MARKREAD,(WPARAM)dat->hContact,(LPARAM)dat->hDbEvent);

			contactName = (TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)dat->hContact,GCDNF_TCHAR);

			SetDlgItemText(hwndDlg, IDC_NAME, contactName);
		}

		return TRUE;

	case WM_MEASUREITEM:
		return CallService(MS_CLIST_MENUMEASUREITEM,wParam,lParam);

	case WM_DRAWITEM:
		{
			LPDRAWITEMSTRUCT dis=(LPDRAWITEMSTRUCT)lParam;
			if(dis->hwndItem==GetDlgItem(hwndDlg, IDC_PROTOCOL)) {
				char *szProto;

				szProto=(char*)CallService(MS_PROTO_GETCONTACTBASEPROTO,(WPARAM)dat->hContact,0);
				if (szProto) {
					HICON hIcon;

					hIcon = ( HICON )CallProtoService(szProto,PS_LOADICON,PLI_PROTOCOL|PLIF_SMALL,0);
					if (hIcon) {
						DrawIconEx(dis->hDC,dis->rcItem.left,dis->rcItem.top,hIcon,GetSystemMetrics(SM_CXSMICON),GetSystemMetrics(SM_CYSMICON),0,NULL,DI_NORMAL);
						DestroyIcon( hIcon );
					}
				}
			}
		}
		return CallService(MS_CLIST_MENUDRAWITEM,wParam,lParam);

	case WM_COMMAND:
		switch(LOWORD(wParam)) {
		case IDC_USERMENU:
			{
				RECT rc;
				HMENU hMenu = (HMENU)CallService(MS_CLIST_MENUBUILDCONTACT, (WPARAM)dat->hContact, 0);
				GetWindowRect(GetDlgItem(hwndDlg, IDC_USERMENU), &rc);
				TrackPopupMenu(hMenu, 0, rc.left, rc.bottom, 0, hwndDlg, NULL);
				DestroyMenu(hMenu);
			}
			break;

		case IDC_DETAILS:
			CallService(MS_USERINFO_SHOWDIALOG, (WPARAM)dat->hContact, 0);
			break;

		case IDC_HISTORY:
			CallService(MS_HISTORY_SHOWCONTACTHISTORY, (WPARAM)dat->hContact, 0);
			break;

		case IDC_ENTERROOM :
			{
				LPSTR pszRoom = mir_alloc(128);

				GetDlgItemText(hwndDlg, IDC_ROOMNAME, pszRoom, 128);
				c6LogMsg("room: %s", pszRoom);

				char szUser[40];
				GetUserNickName(szUser);
				if (c6reqEnterExitRoom(1, szUser, pszRoom)) {

					c6GcInit(pszRoom, 0);
				}
				mir_free(pszRoom);

			}
		case IDCANCEL:
			DestroyWindow(hwndDlg);
			return TRUE;
		}
		break;

	case WM_DESTROY:
		Button_FreeIcon_IcoLib(hwndDlg,IDC_HISTORY);
		Button_FreeIcon_IcoLib(hwndDlg,IDC_DETAILS);
		Button_FreeIcon_IcoLib(hwndDlg,IDC_USERMENU);

		mir_free(dat);
		break;
	}
	return FALSE;
}


int ShowInviteWindow(WPARAM wParam, LPARAM lParam)
{
	CreateDialogParam(hInst, MAKEINTRESOURCE(IDD_INVITERECV), NULL, (DLGPROC)InviteRecvProc, (LPARAM)((CLISTEVENT *)lParam));
	return 0;
}

int InviteEventAdded(WPARAM wParam, LPARAM lParam)
{
	CLISTEVENT cle;
	DBEVENTINFO dbei;
	TCHAR *contactName;
	TCHAR szTooltip[256];
	char szservice[100];

	ZeroMemory(&dbei, sizeof(dbei));
	dbei.cbSize = sizeof(dbei);
	dbei.cbBlob = 0;
	CallService(MS_DB_EVENT_GET,lParam,(LPARAM)&dbei);
	if(dbei.flags&(DBEF_SENT|DBEF_READ) || dbei.eventType!=C6_DB_EVENT_TYPE_CHATSTATES) return 0;

	char szSndName[30];
	strcpy(szSndName, C6PROTOCOLNAME);
	strcat(szSndName, "/Invitation");
	SkinPlaySound(szSndName);

	ZeroMemory(&cle, sizeof(cle));
	cle.cbSize = sizeof(cle);
	cle.hContact = (HANDLE)wParam;
	cle.hDbEvent = (HANDLE)lParam;
	cle.hIcon = (HICON)CallService(MS_DB_EVENT_GETICON, LR_SHARED, (LPARAM)&dbei);
	mir_snprintf(szservice, 100, "%s%s", C6PROTOCOLNAME, MS_CHAT_SHOWINVITE);
	cle.pszService = szservice;
	cle.flags = CLEF_TCHAR;

	contactName = (TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME, wParam, GCDNF_TCHAR);
	mir_sntprintf(szTooltip,sizeof(szTooltip),TranslateT("Invite from %s"),contactName);
	cle.ptszTooltip = szTooltip;
	CallService(MS_CLIST_ADDEVENT, 0, (LPARAM)&cle);
	return 0;
}

#endif // _C6_ROOM

