/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * Original copyright : (C) 2003 by Giorgio A.
 *          email     : openc6@hotmail.com
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_AUTH_H
#define __C6_AUTH_H

/* ---------------------- Functions ---------------------- */

void BlowFishEncode(int len, BYTE *source, int len_key, BYTE* init);
void BlowFishDecode(int len, BYTE *source, int len_key, BYTE* init);
void generMD5Key(unsigned char *md5_key,unsigned char const *server_key);

#endif /* __C6_AUTH_H */

