/*
 * OC6 Protocol Plugin for Miranda IM
 * Copyright (C) 2004-2011 MG Lena <r3vindt(AT)altervista(DOT)org>
 *
 * All distributed forms of this file must retain this notice.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
*/

#ifndef __C6_SVCS_H
#define __C6_SVCS_H

#define C6_DEFAULT_LOGIN_SERVER "c6login.tin.it"
#define DEFAULT_SERVER_PORT 4800

#define URL_REGISTER "http://registrazioni.virgilio.it/ML/form?entryPoint=C6&urlRitorno%3Dhttp://mycommunity.virgilio.it/profilo/mioprofilo/ProfiloAction.do%3FuserAction%3DInit%26URL%3Dhttp://mycommunity.virgilio.it/profilo/generale/mu.jsp%26redUrl%3Dhttp://community.virgilio.it/home/index.html%26entryPoint=C6"

#define C6PROTOCOLNAME "OC6"

#define C6_LOGINID     "Nick"

#define DEFAULT_AVATARS_ENABLED 1

#define DEFAULT_IGNOREMSG LPGEN("Sorry, You are in My Ignore List!")

// C6 status
#define C6_AWAY           0x100
#define C6_FILESHARED      0x80
#define C6_FILETRASFER     0x40
#define C6_MEETING         0x20 // client allow conferency => audio/video => netmeeting
#define	C6_BUSY            0x10
#define	C6_NETFRIENDS	   0x08
#define	C6_AVAILABLE	   0x04
#define	C6_IP_SHOWED	   0x01
#define	C6_OFFLINE  	   0xFF

// userinfo flags
#define C6FLAGS_AVATAR     0x01
#define C6FLAGS_NETWORK    0x02
#define C6FLAGS_EXTRAX     0x04

// client ID
#define ID_CLIENT_ALL      0x01
#define ID_CLIENT_OC6      0x02
#define ID_CLIENT_CM3      0x03
#define ID_CLIENT_CM4      0x04
#define ID_CLIENT_CM5      0x05
#define ID_CLIENT_CM6      0x06
#define ID_CLIENT_CM7      0x07
#define ID_CLIENT_JAVA     0x08
#define ID_CLIENT_CM8      0x09
#define ID_CLIENT_CM9      0x0A
#define ID_CLIENT_CM10     0x0B
#define ID_CLIENT_CM11     0x0C
#define ID_CLIENT_MB       0x0D
#define ID_CLIENT_CM12     0x0E
#define ID_CLIENT_CM13     0x0F
#define ID_CLIENT_MIRANDA  0x40


typedef struct c6header_pkt_s {
      unsigned char id;
      unsigned char cmd;
      unsigned short count;
      unsigned short len;
} c6header_pkt;

typedef struct GetInfoData_s {
	BYTE descr;
	BYTE info;
} GetInfoData;

typedef struct profile_user_data_s {
	  DWORD time;
	  DWORD ip;
	  WORD  status;
	  GetInfoData *list;
} profile_user_data;

typedef struct {   //extended search result structure, used for all searches
	PROTOSEARCHRESULT hdr;
	BYTE status;
} C6SEARCHRESULT;

#ifdef _C6_X64
#define USERDATA GWLP_USERDATA
#else
#define USERDATA GWL_USERDATA
#endif

/* ---------------------- Functions ---------------------- */

int  Add1NetFriend(char *szNick);
int  AddToListDirect(DWORD dwFlags,char *szNick, char *szGroupName);
void HandleGetMessage(char *szNick,char *szMsg, time_t *tt);
WORD HandleGetProfile(char *szNick, int len, LPARAM lParam);
int  SearchLaunch(WORD Number, int size, BYTE *plist);
void SetNetFriendStatus(char *szNick, int wStatus, BOOL bShow, LPSTR pszMsg);

int  Add1NetFriend(char *szNick);
WORD HandleSendContact(void);
int  C6SetMyStatus(WPARAM wParam);

void InitServerLists(void);
void UninitServerLists(void);
int  LoadC6Services(void);

void HandleFileRequest(LPSTR pszSender,LPSTR pszDescription);

int  DetailPlusMenu(WPARAM wParam, LPARAM lParam);

void handleTypingNotification(LPSTR szNick, LPSTR szMsg);
void handleRecvAuthRequest(char *szNick);

int C6GetEventTextChatStates( WPARAM wParam, LPARAM lParam );
int HandleInviteMessage(char *szNick, char *szMsg);

#endif /* __C6_SVCS_H */

