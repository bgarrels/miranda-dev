#define __FILEVERSION_STRING        0,3,8,19
#define __VERSION_STRING            "0.3.8.19"
#define __VERSION_DWORD             PLUGIN_MAKE_VERSION(0, 3, 8, 19)

#define BETA		                FALSE
#define AUTH		                "NoName, borkra"
