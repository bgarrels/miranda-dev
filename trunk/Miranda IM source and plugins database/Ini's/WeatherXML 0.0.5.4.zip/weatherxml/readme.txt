This package include the INI for Weather Protocol that retrieve weather info 
 from www.weather.com

It was introduced by CNSK and updated by BloodySword 2009-07-16 and updated by Krzysztof 2011-12-12.

 Change "Miranda->Options->Plugins->Weather->Change Display Text->Brief Info"
   to something like this:
   
Weather condition for %n as of %u
---------------------------------------------
%c 
Temperature: %t
Feel: %f
Pressure: %p
Wind: %i %w
Humidity: %m
Dew point: %e
Visibility: %v

Sunrise: %r
Sunset: %y
Moon: %[Moon]

%[Forecast Day 1]
%[Forecast Day 2]
%[Forecast Day 3]
%[Forecast Day 4]
%[Forecast Day 5]
%[Forecast Day 6]
%[Forecast Day 7]
%[Forecast Day 8]
