//English Translation

function Translate() {
    
    mStartConversation = 'Not Yet Started';
    sStarted = 'Started at ';
    sDuration = 'Duration : ';
    sConversation = 'This conversation :';
    tCaptionTitle = 'User session stats';
    tCloseTip = 'Click here to close';
    tMinimizeTip = "Click here for avatar only";
    tMaximizeTip = "Click here for all infos";
    sMessage = 'message(s) sent';
    sFile = 'file(s) sent';
    sURL = 'url(s) sent';
    sName = 'Name :';
    sProtocol = 'Protocol :';
    sId = 'ID :';
    sSay = 'say';
    sSaid = 'said';
    sURLFrom = 'URL from';
    sFileFrom = 'File from';
    sStatusMsg = 'Status Message :';
    
    if(userIn == '&nbsp;') 
    {
        sSaid = '';
        sSay = '';
    }
    
   
    
    sTooltipIn = '<table class="tooltipIn">' + 
                '   <tr>' +
                '       <td valign="top" rowspan="2" width="' + avatar.width * tAvatarPercent +'px"><img height="' + avatar.height * tAvatarPercent +'px" width="' + avatar.width * tAvatarPercent +'px" id="avatarIn" src="blank.gif" class="avatarIn"/><br>' + 
                '           <b>' + userIn + '</b> on ' + protocol + '<br>' + 
                '       </td>' +
                '       <td rowspan="2">&nbsp;&nbsp;</td>' +
                '       <td valign="top" colspan="2"><b>Current Conversation :</b></td>' +
                '   </tr>' +
                '   <tr>' +
                '       <td>&nbsp;</td>' +
                '       <td valign="top">- ' + '<a id="StartConversation">' + mStartConversation  +'</a><br>' + 
                '           - <a id="ConversationDuration">Duration : ' + mConversationDuration  +'</a><br> ' +
                '           - <a id="nbrMsgIn">' + nbrMsgIn + '</a> message(s) sent <br>' +
                '           - <a id="nbrFileIn">' + nbrFileIn + '</a> file(s) sent<br>'+
                '           - <a id="nbrUrlIn">' + nbrUrlIn + '</a> url(s) sent ' +
                '           - <a id="nbrMsgIn">' + nbrMsgIn + '</a> ' + sMessage + ' <br>' +
                '       </td>' +
                '   </tr>' + 
                '</table>';
    
    sTooltipInSmall = '<table class="tooltipIn" >' + 
                        '   <tr>' +
                        '       <td valign="top" align="center" rowspan="2"><img height="' + avatar.height * tAvatarPercent +'px" width="' + avatar.width * tAvatarPercent +'px" id="avatarIn" src="blank.gif"  class="avatarIn"/></td>' +
                        '   </tr>' + 
                        '</table>';
                    
    avatar.src = avatarOut;  //To have the avatar dimention of your own
    
  
    
    sTooltipOut = '<table class="tooltipOut">' + 
                '   <tr>' +
                '       <td valign="top" rowspan="2" width="' + avatar.width * tAvatarPercent +'px"><img height="' + avatar.height * tAvatarPercent +'px" width="' + avatar.width * tAvatarPercent +'px" id="avatarOut" src="blank.gif" class="avatarOut"/><br>' + 
                '           <b>' + userOut + '</b> on ' + protocol + '<br>' + 
                '       </td>' +
                '       <td rowspan="2">&nbsp;&nbsp;</td>' + 
                '       <td valign="top" colspan="2"><b>Current Conversation :</b></td>' +
                '   </tr>' +
                '   <tr>' +
                '       <td>&nbsp;</td>' +
                '       <td valign="top">- ' + '<a id="StartConversation">' + mStartConversation  +'</a><br>' + 
                '           - <a id="ConversationDuration">Duration : ' + mConversationDuration  +'</a><br> ' +
                '           - <a id="nbrMsgOut">' + nbrMsgOut + '</a> message(s) sent <br>' +
                '           - <a id="nbrFileOut">' + nbrFileOut + '</a> file(s) sent<br>'+
                '           - <a id="nbrUrlOut">' + nbrUrlOut + '</a> url(s) sent ' +
                '           - <a id="nbrMsgOut">' + nbrMsgOut + '</a> ' + sMessage + ' <br>' +
                '       </td>' +
                '   </tr>' + 
                '</table>';
                    
    sTooltipOutSmall = '<table class="tooltipOut">' + 
                        '   <tr>' +
                        '       <td valign="top" align="center" rowspan="2"><img height="' + avatar.height * tAvatarPercent +'px" width="' + avatar.width * tAvatarPercent +'px" id="avatarOut" src="blank.gif"  class="avatarOut"/></td>' + 
                        '   </tr>' + 
                        '</table>';

    tCloseTextIn = '<a style="cursor: hand;" onclick="cClick();"><img src="blank.gif"  class="iconCloseIn" title="' + tCloseTip + '"/></a>';
    tCloseTextOut = '<a style="cursor: hand;" onclick="cClick();"><img src="blank.gif"  class="iconCloseOut" title="' + tCloseTip + '"/></a>';
    tMinimizeOut = '<a style="cursor: hand; text-align: left;" onclick="cClick();return StickyToolTipOutSmall();"><img src="blank.gif"  class="iconMinimizeOut" title="' + tMinimizeTip + '"/></a>';
    tMinimizeIn = '<a style="cursor: hand; text-align: left;" onclick="cClick();return StickyToolTipInSmall();"><img src="blank.gif"  class="iconMinimizeIn" title="' + tMinimizeTip + '"/></a>';
    tMaximizeOut = '<a style="cursor: hand; text-align: left;" onclick="cClick();return StickyToolTipOut();"><img src="blank.gif"  class="iconMaximizeOut" title="' + tMaximizeTip + '"/></a>';
    tMaximizeIn = '<a style="cursor: hand; text-align: left;" onclick="cClick();return StickyToolTipIn();"><img src="blank.gif"  class="iconMaximizeIn" title="' + tMaximizeTip + '"/></a>';
}