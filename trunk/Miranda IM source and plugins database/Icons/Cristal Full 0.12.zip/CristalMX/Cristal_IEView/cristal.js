//Overlib encapsulated functions

function ToolTipIn() {
    olLoaded = true; 
    overlib(sTooltipIn,CAPICON,'blank.gif',CAPICONCLASS,'iconUserInfo',CAPTION,'Your Sessions Stats',FGCOLOR,tTextColorBKIn,CAPTIONFONT,tCaptionFontIn,CAPTIONSIZE,tCaptionSizeIn,
            BGCOLOR,tCaptionColorBKIn,CAPCOLOR,tCaptionColorIn,WIDTH,twidthIn,ABOVE,SHADOW,SHADOWCOLOR,tShadowColorIn,SHADOWOPACITY,tShadowOpacityIn,BORDER,tBorderSize,DELAY,tDelay,TIMEOUT,tTimeout);
}
function ToolTipOut() {
    olLoaded = true;
    overlib(sTooltipOut,CAPICON,'blank.gif',CAPICONCLASS,'iconUserInfo',CAPTION,'My Sessions Stats',FGCOLOR,tTextColorBKOut,CAPTIONFONT,tCaptionFontOut,CAPTIONSIZE,tCaptionSizeOut,
            BGCOLOR,tCaptionColorBKOut,CAPCOLOR,tCaptionColorOut,WIDTH,twidthOut,ABOVE,SHADOW,SHADOWCOLOR,tShadowColorOut,SHADOWOPACITY,tShadowOpacityOut,BORDER,tBorderSize,DELAY,tDelay,TIMEOUT,tTimeout);
}

function StickyToolTipIn() {
    var bodyWidth = document.body.clientWidth - (2 * tBorder);
    if(tBorder < 1)
    {
        tBorder = 1;
        overlib(sTooltipIn,CAPICON,'blank.gif',CAPICONCLASS,'iconUserInfo',CAPTION,tCaptionTitle,FGCOLOR,tTextColorBKIn,CAPTIONFONT,tCaptionFontIn,CAPTIONSIZE,tCaptionSizeIn,FOLLOWSCROLL,
                BGCOLOR,tCaptionColorBKIn,CAPCOLOR,tCaptionColorIn,WIDTH,bodyWidth,ABOVE,STICKY,
                CLOSEFONT,tCloseFontIn,CLOSESIZE,tCloseSizeIn,CLOSECOLOR,tCloseColorIn,RELY,tBorder,EXCLUSIVE,BORDER,tBorderSize,CLOSETEXT,tMinimizeIn + tCloseTextIn);
    }
    else
    {
        overlib(sTooltipIn,CAPICON,'blank.gif',CAPICONCLASS,'iconUserInfo',CAPTION,tCaptionTitle,FGCOLOR,tTextColorBKIn,CAPTIONFONT,tCaptionFontIn,CAPTIONSIZE,tCaptionSizeIn,FOLLOWSCROLL,
                BGCOLOR,tCaptionColorBKIn,CAPCOLOR,tCaptionColorIn,WIDTH,bodyWidth,ABOVE,STICKY,
                CLOSEFONT,tCloseFontIn,CLOSESIZE,tCloseSizeIn,CLOSECOLOR,tCloseColorIn,RELX,tBorder,RELY,tBorder,EXCLUSIVE,BORDER,tBorderSize,CLOSETEXT,tMinimizeIn + tCloseTextIn);

    }
}
function StickyToolTipOut() {
    var bodyWidth = document.body.clientWidth - (2 * tBorder);
    if(tBorder < 1)
    {
        tBorder = 1;
        overlib(sTooltipOut,CAPICON,'blank.gif',CAPICONCLASS,'iconUserInfo',CAPTION,tCaptionTitle,FGCOLOR,tTextColorBKOut,CAPTIONFONT,tCaptionFontOut,CAPTIONSIZE,tCaptionSizeOut,FOLLOWSCROLL,
                BGCOLOR,tCaptionColorBKOut,CAPCOLOR,tCaptionColorOut,WIDTH,bodyWidth,ABOVE,STICKY,
                CLOSEFONT,tCloseFontOut,CLOSESIZE,tCloseSizeOut,CLOSECOLOR,tCloseColorOut,RELY,tBorder,EXCLUSIVE,BORDER,tBorderSize,CLOSETEXT,tMinimizeOut + tCloseTextOut);
    }
    else
    {
        overlib(sTooltipOut,CAPICON,'blank.gif',CAPICONCLASS,'iconUserInfo',CAPTION,tCaptionTitle,FGCOLOR,tTextColorBKOut,CAPTIONFONT,tCaptionFontOut,CAPTIONSIZE,tCaptionSizeOut,FOLLOWSCROLL,
                BGCOLOR,tCaptionColorBKOut,CAPCOLOR,tCaptionColorOut,WIDTH,bodyWidth,ABOVE,STICKY,
                CLOSEFONT,tCloseFontOut,CLOSESIZE,tCloseSizeOut,CLOSECOLOR,tCloseColorOut,RELX,tBorder,RELY,tBorder,EXCLUSIVE,BORDER,tBorderSize,CLOSETEXT,tMinimizeOut + tCloseTextOut);

    }
}

function StickyToolTipInSmall() {
    var bodyWidth = document.body.clientWidth;
    var avatar = new Image();
    avatar.src = avatarIn;
    var size =  (avatar.width * tAvatarPercent + 16);
    if(size < 62) size = 62;       
    var xPos = bodyWidth - size
    bodyWidth = size;
     
    overlib(sTooltipInSmall,CAPICON,'blank.gif',CAPICONCLASS,'iconUserInfo',CAPTION,' ',FGCOLOR,tTextColorBKIn,CAPTIONFONT,tCaptionFontIn,CAPTIONSIZE,tCaptionSizeIn,FOLLOWSCROLL,
            BGCOLOR,tCaptionColorBKIn,CAPCOLOR,tCaptionColorIn,WIDTH,bodyWidth,ABOVE,STICKY,
            CLOSEFONT,tCloseFontIn,CLOSESIZE,tCloseSizeIn,CLOSECOLOR,tCloseColorIn,RELX,xPos,RELY,1,EXCLUSIVE,BORDER,tBorderSize,CLOSECLICK,CLOSETEXT,tMaximizeIn + tCloseTextIn);

}
function StickyToolTipOutSmall() {
    var bodyWidth = document.body.clientWidth;
    var avatar = new Image();
    avatar.src = avatarOut;
    var size =  (avatar.width * tAvatarPercent + 16);
    if(size < 62) size = 62;       
    var xPos = bodyWidth - size
    bodyWidth = size;
    
    overlib(sTooltipOutSmall,CAPICON,'blank.gif',CAPICONCLASS,'iconUserInfo',CAPTION,' ',FGCOLOR,tTextColorBKOut,CAPTIONFONT,tCaptionFontOut,CAPTIONSIZE,tCaptionSizeOut,FOLLOWSCROLL,
            BGCOLOR,tCaptionColorBKOut,CAPCOLOR,tCaptionColorOut,WIDTH,bodyWidth,ABOVE,STICKY,
            CLOSEFONT,tCloseFontOut,CLOSESIZE,tCloseSizeOut,CLOSECOLOR,tCloseColorOut,RELX,xPos,RELY,1,EXCLUSIVE,BORDER,tBorderSize,CLOSECLICK,CLOSETEXT,tMaximizeOut + tCloseTextOut);

}

function DoTranslate(){
    if(!bTranslated)
    {
        Translate();
        bTranslated = true;
    }
}

function StartConversation() {
    if(!bStarted)
    {
        now = new Date();
        now.getDate();
        var h = String(now.getHours() );
        var m = String(now.getMinutes());
        var s = String(now.getSeconds());
        
        if(h.length < 2) h = '0' + h;
        if(m.length < 2) m = '0' + m;
        if(s.length < 2) s = '0' + s;
        
        mStartConversation = 'Started at ' + h + ':' + m + ':' + s ;
        var t = document.getElementById('StartConversation');
        if( t != null)
        {
            t.innerHTML = mStartConversation;
        }
        bStarted = true;
    }
}

function UpdateDuration() {
   if(timerID) {
      clearTimeout(timerID);
      clockID  = 0;
   }
    if(bStarted)
    {
        var h = String(now.getHours() );
        var m = String(now.getMinutes());
        var s = String(now.getSeconds());
        
        if(h.length < 2) h = '0' + h;
        if(m.length < 2) m = '0' + m;
        if(s.length < 2) s = '0' + s;
        
        mStartConversation = sStarted + h + ':' + m + ':' + s ;
        var t = document.getElementById('StartConversation');
        if( t != null)
        {
            t.innerHTML = mStartConversation;
        }
        t = document.getElementById('nbrMsgIn');
        if(t != null) t.innerHTML = nbrMsgIn;
        t = document.getElementById('nbrMsgOut');
        if(t != null) t.innerHTML = nbrMsgOut;
        t = document.getElementById('nbrUrlIn');
        if(t != null) t.innerHTML = nbrUrlIn;
        t = document.getElementById('nbrUrlOut');
        if(t != null) t.innerHTML = nbrUrlOut;
        t = document.getElementById('nbrFileIn');
        if(t != null) t.innerHTML = nbrFileIn;
        t = document.getElementById('nbrFileOut');
        if(t != null) t.innerHTML = nbrFileOut;
    }
    if(bStarted)
    {

        var   tDate = new Date();
        tDate.getDate();
        
        var   tDiff = tDate.getTime() - now.getTime();
        
        tDate.setTime(tDiff);
        
        var h = String((tDate.getHours() + (tDate.getTimezoneOffset()/60)));
        var m = String(tDate.getMinutes());
        var s = String(tDate.getSeconds());
        
        if(h.length < 2) h = '0' + h;
        if(m.length < 2) m = '0' + m;
        if(s.length < 2) s = '0' + s;
        
        mConversationDuration = h + ':' + m  + ':' + s ;
        var t = document.getElementById('ConversationDuration');
        if( t != null)
        {
            t.innerHTML = sDuration + mConversationDuration;
        }
        
    }
   
   timerID = setTimeout('UpdateDuration()', 1000);
}

function CloseToolTip()
{
        var t = document.getElementById('overDiv');
        if( t != null)
        {
            t.style = "position:absolute; visibility:hidden; z-index:1000;";
        }
}

function getavatar(avatar)
{
    if (avatar != ""){
    
        if( avatar.indexOf('.xml',0)!=-1)
        {
            var xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
            xmlDoc.async="false";
            xmlDoc.load(avatar);
            nodes=xmlDoc.documentElement.childNodes;
            document.write('<object name="movie" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"  class="headeravaflash">'
            + '<param name=movie value=' + nodes(0).text + '>'
            + '<param name=quality value=high>'
            + '<embed src=' + nodes(0).text + ' quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" class="headeravaflash">'
            + '</embed></object>');
        
        }
        else
        {
            document.write('<img src="' + avatar + '" border="" alt="" class="headerava">');
        }
    }
}





