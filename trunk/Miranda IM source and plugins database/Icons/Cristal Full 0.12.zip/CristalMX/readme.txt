Cristal Full
iconpacks for Miranda IM
Compled by Angeli-Ka 

Some icons made from:
CristalMX http://mavisxp.com/crystal/
and XML Weather 1.10 by Daniel Brauer http://www.dockzone.de/

Yahoo, Tlen, Gadu-Gadu, Skype icons-are made by me.

You can't use any files from this archive, for other then personal proposes, without my permission.

contains:
- Protocol iconpacks: ICQ, MSN, AIM, Jabber, IRC, GaduGadu, MetaContacts, Tlen,
 QQ, Yahoo, RSS, Weather,WebView, mTV, Skype, WorldTime, Ping, WinPopup, Mail.ru agent,battle.net, mRadio.
- Proto_connect icons for all protocol iconpacks. Need clist_mw or clist_modern instaled
- Global iconpacks.
- Main iconpack.
- Extra iconpack for clist_mw&clist_modern.(for clist_nicer change it with IconLib using "import icon" button)
Put all items from above in "icons" folder in your Miranda directory.
- tabSRMM iconpack (change with IconLib or put it in "plugins" folder)
- TopToolBar icons 16x16
- Database editor plugin iconpack.
- nConvers iconpack(nc_icons.dll). Change it with IconLib Manager using "import icon" button (load packs don't work.. yet)
- newstory iconpack (change with IconLib)
- overlay iconpack for clist_nicer.(change it with IconLib using "load icon set"  button)
- Default proto_avatar images for loadavatars.
- Clist_nicer theme.
- Iconpack for worldtime plugin.(change it with IconLib)
- Skin for clist-modern
- Skin for PoUp+
- proto_connect icons for clist_nicer (change it with IconLib using "import icon" button)
- GMailNotify iconpack.
- FileAsMessage iconpack.
- Updater plugin iconpack.
- History++ iconpack.
