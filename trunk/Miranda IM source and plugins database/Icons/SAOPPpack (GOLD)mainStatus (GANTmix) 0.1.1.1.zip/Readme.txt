SAOPPpack (GOLD)mainStatus (GANTmix)

by SAOPP [ icq: 342834289 | www.samlab.ru | msn: saopp.zori@gmail.com ]

Main icon from GATNpack, some icons mixed with some parts of this package:
http://www.miranda-im.org/download/details.php?action=viewfile&id=1939 by Volter15.
All other icons mingled with some parts of my package:
http://www.miranda-im.org/download/details.php?action=viewfile&id=1909 BIG thnx to Faith Healer ;)

-> in 0.0.0.2:

- New offline icon