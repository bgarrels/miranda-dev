SAOPP ICQ Smile connecting icons

by SAOPP [ icq: 342834289 | www.samlab.ru | saopp.zori@gmail.com ]

Use it with this pack:
http://www.miranda-im.org/download/details.php?action=viewfile&id=1939 by Volter15
...or as you like ;)