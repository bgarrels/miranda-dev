﻿Proto icons with default overlay (Jabber - VK, Facebook, Gtalk, Gmail)


!!!УСТАНОВКА!!!
1.	Запускайте iceit.exe

2.	пропишите путь для сборки миранды (где хотите изменить иконки) кликнув [...] и выбирете файл miranda32.exe

3.	в окне ниже выберете типы плагины к-е хотите пропатчить. (или нажмите Select ALL)

4.	Жмите [ICE it...]
если возле плагинов появилась зеленая надпись [succes] то все прошло успешно.


2010-2011. ksunechkin 
twitter.com/ksunechkin
