--------------------------------
High Color Mirabilis-style Icons
--------------------------------

Most icons were captured from another unimportant ICQ clone that's not developed anymore.
The Miranda logo was redesigned by myself ofcourse.

Unless you're running Windows ME (and I guess you don't ;-) ) the Miranda system tray icon will probably look ugly because of the 16-color limitation.

I suggest this link to fix your explorer to enable high color icons in the system tray (It's litteraly a matter of flipping a bit): http://www.chez.com/hoiby/TrayIconIn256Color/index.html

