a0x set3 [2.0.0.1] contains:

- Gadu-Gadu
- Tlen [Blue and Green]
- ICQ
- IRC
- Google Talk [2Versions]
- MSN [2Versions]
- Skype
- Yahoo
- C6
- AIM
- Jabber
- Weather
- Global [5Versions]
- Overlay
- Main [2Versions]
- mRadio
- MultiWindow [3Versions]
- mTV
- RSS
- YAMN
- NiMContact
- Phantom
- MRA
- Merge/MetaContacts
- WinPopup

There is also Protocol Connection icon for this set, you can find it here:
=> http://miranda-im.org/download/details.php?action=viewfile&id=2380

=================================================
TO DO:
- protocol connection icons for all protocols
- TopToolBar icons
- TabSRMM icons
=================================================

If You want to mobilize me to ulterior work, my e-mail is: a0x@toya.net.pl [ICQ#:215563463]:)
I'm waiting for opinions and suggestions...

For unofficial, prerelease updates visit: http://set3.a0x.info

=======================================================================================================
Yoa are allowed to use my icons and other files for personal pusposes only. If You want to modify them and publish, ask for my permission.
=======================================================================================================

29.08.2006
a0x
