..\Faux Aqua Icon Set by NETknightX (C) 2002-2003\..................

	Hello! This is an icon set for Miranda Instant Messenger (http://miranda-icq.sourceforge.net). There are two main sets of icons, 32-bit and 8-bit. The 32-bit icons are only meant for Windows XP. The 8-bit icons are for all other versions of Windows. Also, these icons are 16x16, so they will probably look terrible if viewed at a larger size. Looks best using  the included background.

To use the included background, you must enable "Tile Vertically" and "Tile Horizontally" in the options.

	For questions, suggestions and/or bug reports, please contact me using the methods shown below.


..\Package\.........................................
	- Faux Aqua ICQ 8Bit.dll           (Windows 9x/ME/NT/2000)
     	- Faux Aqua ICQ 32Bit.dll          (Windows XP)
   	- Faux Aqua MSN 8Bit.dll           (Windows 9x/ME/NT/2000)
   	- Faux Aqua MSN 32Bit.dll          (WinXP)
	- fauxaqua.gif			   (Background)
	- preview.gif                    (preview)
	- Readme.txt (what you are reading now)

..\Requirements\....................................
	- Windows XP for 32-bit icons
	- Windows 9x/ME/NT/2k for 8-bit icons
	- Miranda 0.1.2.0 or later

..\Installatation\.....................................
- can be installed anywhere
	- icons
		1. Use Contact List\Icons\Import Icons
		2. select MSN icons
		3. then with the Icon Index window open, search for Faux Aqua MSN 32Bit.dll or 8 bit , as required
		3. drag and drop icons to appropriate place

	- background
		1. Use Contact List\Contact list Background
		2. tick use background bitmap
		3. browse and select fauxaqua.gif
		4. tick "Tile Vertically" and "Tile Horizontally"

..\Contact\.........................................
	- ICQ: 4554842
	- MSN: netknightx@hotmail.com
	- Email: netknightx@hotmail.com


..\Version History\.................................
v2.01
	-Add installation instructions, special thanks to darren
v1.00
	- Initial release