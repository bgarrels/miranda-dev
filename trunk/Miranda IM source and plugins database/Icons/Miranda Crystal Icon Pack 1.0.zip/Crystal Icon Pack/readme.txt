Update 23.06.2011
Added alternative icons for Gmail and XMPP

Update 27.03.2011
Added alternative icons for GG, Tlen, XMPP, X-fire

Icon set for:
Gadu-Gadu
Tlen
Dobreprogramy
Gtalk
XMPP
Facebook
Xfire
IRC
AIM
ICQ
MSN
Yahoo
Skype
Metacontacts
Global

32x32 and 16x16 px icons.

Tyczek (tyczek88@gmail.com) 2011