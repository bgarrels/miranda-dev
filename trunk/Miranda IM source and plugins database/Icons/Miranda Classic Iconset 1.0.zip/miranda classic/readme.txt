--- Attention! Read Carefully ---

Miranda Classic Iconset

These icons were made from scratch by me, and are meant for personal use only. That means that you can use them, but not modify them or use them in a commercial form without letting me know.

Copyright(c) Cristhian Serur a.k.a. Symbiotic Balance

http://www.symbioticbalance.com.ar