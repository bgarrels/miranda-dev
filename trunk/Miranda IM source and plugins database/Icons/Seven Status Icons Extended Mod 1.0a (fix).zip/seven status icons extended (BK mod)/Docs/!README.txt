﻿seven status icons extended mod by ksunechkin

original idea & basic by belf (http://belf.ovh.org/) 
оригинальная идея и базовый набор "belf" 

Based on Seven Icons by belf & original protocols icons

Набор системных иконок для Miranda IM основанных на Fugue Seven Icons by belf & оригинальных иконках протоколов

Changes compared with the original set:
Added icons for: ICQ, JABBER, mod XMPP, MRA, MSN

Изменения в сравнении с оригинальным набором:
Добавлены иконки для: ICQ, JABBER, mod XMPP, MRA, MSN

 

Этот Иконпак совместим с Miranda ICE Icon pack patcher (by Induction):
This icon pack is compatible with Miranda ICE Icon pack patcher (by Induction):
http://induction.mirandaim.ru/downloads/resources.zip


!!!УСТАНОВКА!!!
Copy files proto_*.dll into the folder Miranda IM\Icons\
Скорпировать файлы proto_*.dll в папку Miranda IM\Icons\

or
Либо

1.	Запускайте iceit.exe

2.	пропишите путь для сборки миранды (где хотите изменить иконки) кликнув [...] и выбирете файл miranda32.exe

3.	в окне ниже выберете типы плагины к-е хотите пропатчить. (или нажмите Select ALL)

4.	Жмите [ICE it...]
если возле плагинов появилась зеленая надпись [succes] то все прошло успешно.


2010-2011. ksunechkin 
Cайт - http://mimnative.googlecode.com/
