This is proto connection icon designed to fit my set 3 icons [ http://miranda-im.org/download/details.php?action=viewfile&id=2334 ]. To use it, rename the file so it has protocol name instead of "protocol name" [for example: proto_conn_icq.dll] :P You have to make a copy for each protocol with its name.
I hope you like it:)

If You want to mobilize me to ulterior work, my e-mail is: a0x@toya.net.pl [ICQ#:215563463]:)
I'm waiting for opinions and suggestions...
=======================================================================================================
Yoa are allowed to use my icons and other files for personal pusposes only. If You want to modify them and publish, ask for my permission.
=======================================================================================================

a0x
23.09.2005