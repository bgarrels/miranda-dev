About
-----

Miranda Icon Builder 
Version 1.0.1
by Art Fedorov


Contents
--------

1. Description
2. Installation
3. Known Issues
4. Source
5. Licence
6. Changes
7. Feedback


1. Description
--------------

This program allows you to create Icon Packs
for Miranda IM easily, without having to manually
create bulky .rc, install compilers and such.

With Icon Builer you can create, manage and 
compile icon DLLs really fast!


2. Installation
---------------

Just unzip the archive into any folder and run
IconBuilder.exe
 

3. Known Issues
---------------

* If you create project, save it, close it, remove 
(or rename) icons which were present in project,
then when you open the project next time, you 
will definitly have errors. The best way to solve
it is to create new project (or hand-edit 
existing on, .ibp file is norma .ini file)


4. Source
---------

Source code can be found at miranda web-site.

Link: http://miranda-im.org/

                                     
5. License
----------

This program is free software; you can 
redistribute it and/or modify it under the terms
of the GNU General Public License as published by
the Free Software Foundation; either version 2
of the License, or (at your option) any later
version.

This program is distributed in the hope that it
will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU
General Public License along with this program;
if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA  
02111-1307, USA.


6. Changes
----------

1.0.1
+ Fixed hanging on build under Win9x/ME systems

1.0.0
Initial release.


7. Feedback
------------

Contact me at artemf@mail.ru

Any kind of feedback is appreciated, especially 
feedback on bugs.

Art Fedorov
artemf@mail.ru