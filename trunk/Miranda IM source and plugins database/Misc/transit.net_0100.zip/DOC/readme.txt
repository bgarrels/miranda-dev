Transit.NET by sourcefreak (miranda@sourcefreak.de / http://sourcefreak.de)
---------------------------------------------------------------------------

Descrption: Transit.NET is a standalone core and contribution updater for Miranda IM (http://miranda-im.org)

Features:

Usage:


Download: 
Discussion: 
Donation: http://donation.sourcefreak.de