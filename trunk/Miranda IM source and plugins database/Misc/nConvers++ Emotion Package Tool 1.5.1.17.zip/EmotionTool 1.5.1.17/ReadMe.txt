What's new in 1.5.1.17:
+ Animated smiles support added (gif)!
+ Gif support for static images added.
+ Now you can assign for every smile both animated image and static image.
+ Possibility to save images from xep to disk (gif,bmp).
- Fixed bug "in some cases file was saving in wrong folder".
- Fixed bug with deleting smiles.
- Fixed bug with deleting images.
- Fixed bug with moving smile after import.
- Fixed bugs with image size property.
- Fixed bugs with 32 bit icons.
* Added cancel to all messageboxes.
Many other fixes and improvements...

What's new in 1.0.4.7:
* Updated to the latest version of TRegExpr (same that using in latest nConvers++).
+ Added possibility to view all regular expressions in one edit window.
- Fixed bug "when deleting icon from images list - unpredictable icon deleted, or all icons disappear everywhere in XEP".
- Fixed bug "when exporting icons, they are always clipping to 16x16".
- Fixed bug "in some cases 'Data has been changed do you want to save?' messagebox not shown".
- Fixed bug "protocol combobox's fills with empty members when traveling through the emotions".
* In some controls font changed to monospaced 'Courier New' for better readability and editing.
Some other fixes and improvements...

SUKER: sukerrussia@mail.ru