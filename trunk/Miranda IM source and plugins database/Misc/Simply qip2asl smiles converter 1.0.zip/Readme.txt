Name: Simple QIP2ASL smile converter 
Autor: Shutov Konstantin (aka Cattabit) kshutov@gmail.com
