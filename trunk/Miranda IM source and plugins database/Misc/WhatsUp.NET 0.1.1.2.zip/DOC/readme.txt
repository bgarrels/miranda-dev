WhatsUp.NET by sourcefreak (miranda@sourcefreak.de / http://sourcefreak.de)
---------------------------------------------------------------------------

Descrption: WhatsUp.NET is a standalone addons downloader for Miranda IM addons (http://miranda-im.org)

Features:
- Download up to 10 addons at once
- Optional extract to a specified directory
- Delete downloaded addons (manually)
- Open addon URL for a complete description
- Update backend files which are older than 24 hours
- Search category for an addon
- Search Addons website (Miranda IM or Google search)
- Show last 15 new and updated addons

Usage:
- Browse to the desired category
- Tick desired addon (up to 10 addons)
- Right-click and click download

Download:http://addons.miranda-im.org/details.php?action=viewfile&id=3819
Discussion: http://forums.miranda-im.org/showthread.php?t=19267
Donation: http://donation.sourcefreak.de