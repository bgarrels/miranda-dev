Name: Simple QIP2ASL smile converter 
Autor: Shutov Konstantin (aka Cattabit) kshutov@gmail.com

Converts qip's *.ini file in smile's diretry to *.asl file, which can be used in Miranda.


Just put this jar-file in directory, which containt smile-pictures and qip's ini-file, and run it.
