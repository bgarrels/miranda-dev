# (c) Victor Sergienko, 2007, singalen at gmail dot com
# This is absolute freeware.
# Requires Miranda >= 0.7.0.a39, MirPy >= 0.1.3.1
#
# 0.1 - Initial revision
# 0.2 - Modified to really work with latest MirPy (should be backward-compatible with CreateService() etc)

import clist
import MirPy

# Local names
# Local service name, should be unique
CLIST_EVENT_PREBUILDMENU = "CList/PreBuildContactMenu"
CLIST_MENU_SERVICE = "Contact//SwitchIgnoreOnline"

# m_ignore.h
IGNOREEVENT_USERONLINE = 4 

# "Ignore event" service
MS_IGNORE_ISIGNORED = "Ignore/IsIgnored"
MS_IGNORE_IGNORE = "Ignore/Ignore"
MS_IGNORE_UNIGNORE = "Ignore/Unignore"

# m_icolib.h
MS_SKIN2_GETICON = "Skin2/Icons/GetIcon"
MS_SKIN2_RELEASEICON = "Skin2/Icons/ReleaseIcon"

# skinicons.c
ONLINE_ICON_NAME = "core_main_4"

class MenuItem:
	"""Menu item descriptor structure"""

	def __init__(self):
		self.handle = 0
		self.name = "Online notification"
		self.position = 0 # ???
		self.owner = None
		self.flags = 64 # onlist
		self.hIcon = 0
		#CreateService
		csMethod = getattr(MirPy, "CreateRealService", None)
		if csMethod: 
			res = MirPy.CreateRealService(CLIST_MENU_SERVICE, self.OnContactMenu)
		else:
			res = MirPy.CreateService(CLIST_MENU_SERVICE, self.OnContactMenu)
		#print "CreateService(CLIST_MENU_SERVICE)=", res
		self.AddContactMenu()

	def __del__(self):
		clist.UnhookClistEvent(CLIST_EVENT_PREBUILDMENU, self.OnPrebuildMenu)
		#if handle: clist.RemoveContactMenuItem(handle)

		#MirPy.DestroyRealService(CLIST_MENU_SERVICE)
		csMethod = getattr(MirPy, "DestroyRealService", None)
		if csMethod: 
			res = MirPy.DestroyRealService(CLIST_MENU_SERVICE, self.OnContactMenu)
		else:
			res = MirPy.DestroyService(CLIST_MENU_SERVICE, self.OnContactMenu)

		if MirPy.ServiceExists(MS_SKIN2_RELEASEICON):
			MirPy.CallService(MS_SKIN2_RELEASEICON, 0, ONLINE_ICON_NAME) # might need to use hIcon
		#print "Item %s deleted" % (handle)

	def AddContactMenu(self):
		if MirPy.ServiceExists(MS_SKIN2_GETICON):
  			self.hIcon = MirPy.CallService(MS_SKIN2_GETICON, 0, ONLINE_ICON_NAME)

		self.handle = clist.AddContactMenuItem(
			self.name, self.position, CLIST_MENU_SERVICE, 
			self.owner, self.flags, self.hIcon)

		hooked = clist.HookClistEvent(CLIST_EVENT_PREBUILDMENU, self.OnPrebuildMenu)
		#print "clist.AddContactMenuItem %s: icon %s, hook %s\n" % (self.handle, self.hIcon, hooked)

	def OnPrebuildMenu(self, hContact, lParam):
		localFlags = self.flags
		ignored = MirPy.CallService(MS_IGNORE_ISIGNORED, hContact, IGNOREEVENT_USERONLINE)
		if not ignored: localFlags |= 2 # checked
		#print "Prebuild menu: ignored ", ignored

		clist.ModifyMenuItem(self.handle, self.name, localFlags, self.hIcon)

	def OnContactMenu(self, hContact, lParam):
		ignore = GetContactIgnore(hContact)
		if hContact > 0:
			SetContactIgnore(hContact, not ignore)
		#print "Called toggle contact status ignore (%s) = %s" % (hContact, ignore)
	
def GetContactIgnore(hContact):
	result = MirPy.CallService(MS_IGNORE_ISIGNORED, hContact, IGNOREEVENT_USERONLINE)
	#print "GetContactIgnore (%s) = %s" % (hContact, result)
	return result

def SetContactIgnore(hContact, ignore):
	service = MS_IGNORE_UNIGNORE
	if ignore: service = MS_IGNORE_IGNORE
	result = MirPy.CallService(service, hContact, IGNOREEVENT_USERONLINE)
	return result

def OnMirPyClose():
	del item
	print "Module", __name__, "is about to be stopped"

item = MenuItem()
print __name__, "was loaded"
