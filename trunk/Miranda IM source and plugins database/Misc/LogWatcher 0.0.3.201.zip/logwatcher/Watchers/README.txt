
Watchers are included as examples, some are old and may not work at all, some may not work as expected on anybody elses computer, and some will require some editing to function properly.

The watchers meant for public consumption are: DC++PM, Downloads, EventLog, FTP Client and KerioPF
