============================================
Gaia10 Miranda IM Contact List             *
by novoo (http://www.clrs.us)              *
============================================

Required:

- Windows 2000, XP, Vista or 7
- Miranda IM (latest build from miranda-im.org)
- modern_clist Plugin



When you're using this skin, you should:

- disable the Miranda IM status bar
- enable rounded corners for avatars (2px radius)


Enjoy!

novoo 
(http://www.novoo.deviantart.com)