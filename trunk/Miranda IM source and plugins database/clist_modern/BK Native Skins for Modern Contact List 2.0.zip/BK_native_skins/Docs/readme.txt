﻿BK_native - Skins for Modern Contact List is compatible with Non-Layered mode by ksunechkin.
Conform with default style of Windows Vista/7.

Requirements: Modern Contact List (NOT LAYRED MODE!!!!!!! )

INSTALL - copy folder "skins" to you miranda path folder

Based on ParticleInner for MCL 1.0 by yethee
http://addons.miranda-im.org/details.php?action=viewfile&id=4226

OFFICIAL SITE - http://code.google.com/p/mimnative/

2010-2011. ksunechkin