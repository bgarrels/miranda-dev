Pure Adium for Miranda IM
Original Resources by Hirogen (http://cypohirogen.deviantart.com)
Miranda IM port by Yukihatsu a.k.a Andy N. (http://yukihatsu.deviantart.com)

Permission to port this to Miranda IM granted by Hirogen.

Okay.. This is not necessary but.. If you really want to get the same look as in the preview, follow these instructions.

1. Set the Online Contacts font to Red: 80, Green: 166, Blue:240 (Options>Customize>List Text)
2. It is also recommended to disable the group display (Options>Contact List>General)
3. Set the contact list to resize automatically to 24% Options>Contact List>Behaviour)
4. Set the Min Row Height to 17 pixels. (Options>Contact List>Row Items>Row)
5. The font used in the preview is Calibri Bold pre-smoothed, which is not included. So.. you'll have to find a replacement. :D
6. Replace the status icons with the one included in the pack. You may have to apply the icons one by one. (Options>Customize>Icons)

And..

-In case you can't resize your Contact List, apply the Default theme and resize it from there. Then reapply the Pure Adium theme.
-Oh, and this skin is made as minimal as possible without much buttons. There's a close button on the upper left of the contact list for you to
 close the window. ;)


That's all I guess. If there are any suggestions, please send them to yukihatsu@gmail.com. Thanks.

-Andy N.