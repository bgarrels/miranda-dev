Dream theme pack for Miranda IM
v.0.01
Author= Angeli-Ka

based on image by Valkyre (http://img424.imageshack.us/img424/9461/listandwindow3rn.jpg)

include:
skin for clist_nicer
skin for clist_modern
skin for popUp+
skin for tabsrmm
splash screen
template for IEView
template for tabsrmm message log

requirements:
at least latest TEST builds for all plugins.
first look in http://www.miranda-im.org/development/, on author's sites.. then in File Listing

installation:
[part of this  is copyed from "SlimBlack Themepack" readme, thanks a lot Defiance for spare my time]

Unzip dreamtheme.zip in main Miranda directory


Splash
To use the splash image you need Splash screen plugin installed:
http://addons.miranda-im.org/details.php?action=viewfile&id=2624
-Go to Options -> Customize -> SplashScreen
-Press the "..." button next to Splash textbox and browse to <miranda path>\Skins\DreamSplash.png
-Apply it

CList Modern Layered
To use the CList Modern skin you need one of the latest builds of CList Modern Layered:
http://modern.saopp.info/
-Go to Options -> Customize -> Skin -> Load/Save tab
-Select <miranda path>\Skins\DreamModern\Dream.msf in the Available skins box
-Press the Apply button just below the box


Clist Nicer+
To use the Clist_nicer skin you need one of the latest builds available in the Miranda nightlies.
-Go to Options -> Customize -> Contact list skin ->load and apply tab
-Press "..." next to the textbox and browse to <miranda path>\Skins\Dream\DreamNicer\Dream.clist
-Apply it
tip:
you can skin frames with or wihout titlebars by ticking this options in main menu->frames for each frame individually.

TabSRMM skin and themplate
To use the TabSRMM skin you need TabSRMM 0.9.9.204 or later available in the Miranda nightlies:
-Go to Options ->Customize -> Message Window skin-> load and apply tab
-Check the "load front and colors provided by skin"
-Press "..." next to the textbox and browse to <miranda path>\TabSRMM\skins\dream\Dream.tsk
-Apply it
tips:
disable all static edges and borders in tabsrmm options.(tabs and layout tab)
check "tabs at the bottom" in container options(right click on button bar)


PopUp+
To use the PopUp+ skin you need PopUp+ 2.0.3.97 or later:
http://files.nullbyte.org.ua/popup-plus/popup.2.0.3.97.rc2.zip
-Go to Options -> Popups -> Plus
-hit 'reload' button
-Select "dream" in the Chose preferred skin droplist
-Apply it

IEView templates
To use the IEView templates you need download it from http://developer.berlios.de/projects/mgoodies
-Go to Options -> message sessions -> message log tab
-Press "..." next to the 'use templates" textbox and browse to <miranda path>\Skins\Dream\skins\DreamIEView\dream.ivt
-Apply it
tip:
disable borders from IEView options.

copirights:
All copyrights for this files belong to me.
Don't use any of files from this archive for other than personal
purposes without my permission.

special thanks to LOV for redacting IEView templates.