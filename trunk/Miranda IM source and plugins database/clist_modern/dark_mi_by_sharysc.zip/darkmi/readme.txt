Deavy's Dark Miranda skin for Modern Clist (Miranda IM)
*psd sources included*

======================================
That you must know at the beginning
-----------------------------------
At first, all fonts that I use in this skin is Trebuchet MS.

Few words about colors (they all in rgb-palette):

NOTE, THAT IS IMPORTANT!
Set "Frame color" in Options->Contact list->Window to 31-32-34 if you want transparent frame with My Details, 
Traffic Counter or with something yet (in the settings of this plugins you need to set background color to 
31-32-34 too).

For all text I used mainly:
255-255-255 (Opened group header, status bar, nickname in MyDetails plugin)
100-100-100 (closed group header)
170-170-170  (for example standart contacts, other strings in MyDetails plugin, Traffic counter plugin etc)


And probably most important -- more experiment with Miranda IM Options!
It not so difficultly, as seems on the face of it!

======================================
Installing
----------
Just extract content of downloaded package into "Miranda IM\Skins" directory and select Dark MI skin 
in Miranda Options. You can delete Sources directory if you don't want change anything.

NOTE, that this skin will change your current fonts to Trebuchet MS.

======================================
Contacts, bugs, troubleshootings, etc.
--------------------------------------

If you enjoy this skin, please leave comments at the DeviantART.com. %-)
Also you can send me e-mail: deavyinc at gmail.com
Or to talk with me in on-line via:
 - ICQ (UIN: 249169964)
 - JABBER (deavyinc@gmail.com)
 - YAHOO (deavyinc@yahoo.com)
 - MSN (deavyinc@hotmail.com)

Necessarily contact with me if you found a bugs and I'll fix it 8-)