﻿Seven BK Mod Skins by ksunechkin - Skins for Modern Contact List

Conform with default style of Windows Vista/7.
3 various of skins - Seven BK Mod, Seven BK Mod Magneta, Seven BK Mod Blue

Requirements: Modern Contact List

INSTALL - copy folder "skins" to you miranda path folder

Based on Seven for MCL 2.3 by Belf (http://belf.ovh.org)

OFFICIAL SITE MOD - http://mimnative.googlecode.com/

2011. ksunechkin