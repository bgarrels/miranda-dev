﻿Sun Glass for MCList (111) (by kiwi0fruit)
Requirements: Modern Contact List

Based on Ubuntu PopUps and Aero Glass v2 skin by FediaFedia (fediafedia.deviantart.com).
http://fediafedia.deviantart.com/art/Aero-v2-skin-for-miranda-118326320

Contanis toolbar icons by JiomAk [http://miranda-planet.com/forum/index.php?autocom=downloads&showfile=1035].