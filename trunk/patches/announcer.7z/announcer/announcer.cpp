/*=============================================================================
Copyright (c) 2012, Mike Kaganski
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met: 

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer. 
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies, 
either expressed or implied, of the Copyright Owner.
=============================================================================*/

#include "stdafx.h"

#include <list>
#include "PrSht.h"
#include "Commctrl.h"

// Miranda IM API
#pragma warning ( push )
#pragma warning ( disable : 4996 ) // only useful in debug mode

#define MIRANDA_VER 0x0800

#include "newpluginapi.h"
#include "m_database.h"
#include "m_popup.h"
#include "m_contacts.h"
#include "m_options.h"
#include "m_langpack.h"
#include "m_icolib.h"

#pragma warning ( pop )

#include "versioninfo.h"
#include "resource.h"

// {491B68CE-6D5F-11E1-B432-64F84824019B}
#define MIID_ANNOUNCER { 0x491B68CE, 0x6D5F, 0x11E1, { 0xB4, 0x32, 0x64, 0xF8, 0x48, 0x24, 0x01, 0x9B } }

#define PARAM_TIMEOUT  "PopupTimeout"
#define PARAM_BKCOLOR  "PopupBackColor"
#define PARAM_TXTCOLOR "PopupTextColor"
#define PARAM_TITLE    "PopupTitle"

#define SIZEOF(M) (sizeof(M)/sizeof(M[0]))

typedef std::list<wchar_t*> StrList;

const int      MAX_TIMEOUT  = 60*60*24*7;               // 1 week :)
const COLORREF DEF_BKCOLOUR = (RGB(0xFF, 0xFF, 0x00));

HINSTANCE g_hInst;
HANDLE g_hook[2];

CRITICAL_SECTION g_CritSect; // To avoid crash when announcement arrives simultaneously with configuration changes

PLUGINLINK *pluginLink;
MM_INTERFACE mmi;
UTF8_INTERFACE utfi;

int	             g_PopupTimeout;
COLORREF         g_BackColor;
COLORREF         g_TextColor;
wchar_t          g_PopupTitle[MAX_CONTACTNAME];
StrList          g_Announcers;

inline void ClearStrList(StrList& l)
{
  for (StrList::iterator i=l.begin(); i!=l.end(); ++i)
    mir_free(*i);
  l.clear();
}

template<typename T>
inline T Constrain(T val, T lo, T hi)
{
  return max(lo, min(hi, val));
}

// Result must be disposed of using mir_free()
wchar_t* GetLBText(HWND hWndLB, LRESULT i)
{
  LRESULT len = SendMessage(hWndLB, LB_GETTEXTLEN, i, 0);
  if (!len || (len == LB_ERR))
    return 0;
  wchar_t* str = static_cast<wchar_t*>(mir_alloc((len+1)*sizeof(wchar_t)));
  if (str)
    if (SendMessage(hWndLB, LB_GETTEXT, i, reinterpret_cast<LPARAM>(str)) == LB_ERR) {
      mir_free(str);
      str = 0;
    }
  return str;
}

// Result must be disposed of using mir_free()
wchar_t* GetWndText(HWND hWnd)
{
  int sz = GetWindowTextLength(hWnd);
  if (!sz)
    return 0;

  wchar_t* str = static_cast<wchar_t*>(mir_alloc((sz+1)*sizeof(wchar_t)));
  if (str)
    GetWindowText(hWnd, str, sz+1);
  return str;
}

inline int GetUserData(HWND hwnd)
{
  return static_cast<int>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
}

inline void SetUserData(HWND hwnd, int val)
{
  SetWindowLongPtr(hwnd, GWLP_USERDATA, val);
}

struct SysAnnounceParam {
  wchar_t* msg;
  wchar_t* title;
};

static DWORD WINAPI SysAnnounceMsg(LPVOID lpThreadParameter)
{
  SysAnnounceParam* sap = static_cast<SysAnnounceParam*>(lpThreadParameter);
  MessageBoxW(0, sap->msg, sap->title, MB_OK | MB_ICONINFORMATION | MB_TOPMOST);
  mir_free(sap->msg);
  mir_free(sap->title);
  mir_free(sap);
  return 0;
}

inline HICON GetIcon()
{
  HICON i = reinterpret_cast<HICON>(CallService(MS_SKIN2_GETICON, 0, reinterpret_cast<LPARAM>("PopUp_Misc_Notification")));
  return i ? i : static_cast<HICON>(LoadImage(0,
                                              MAKEINTRESOURCE(OIC_INFORMATION),
                                              IMAGE_ICON,
                                              GetSystemMetrics(SM_CXSMICON),
                                              GetSystemMetrics(SM_CYSMICON),
                                              LR_SHARED));
}

void SysAnnounceUsingSettings(wchar_t* msg,
                              wchar_t* title,
                              COLORREF bkColor,
                              COLORREF txtColor,
                              int timeout)
{
  POPUPDATAW pdx;
  pdx.lchContact = 0;
//  pdx.lchIcon = LoadIcon(0, IDI_INFORMATION);
  pdx.lchIcon = GetIcon();
  mir_sntprintf(pdx.lpwzContactName, MAX_CONTACTNAME, L"%s", title);
  mir_sntprintf(pdx.lpwzText, MAX_SECONDLINE, L"%s", msg);
  pdx.colorBack = bkColor;
  pdx.colorText = txtColor;
  pdx.PluginWindowProc = 0;
  pdx.PluginData = 0;
  pdx.iSeconds = timeout;

  if (PUAddPopUpW(&pdx) < 0) // PopUp failed
    if (SysAnnounceParam* sap = static_cast<SysAnnounceParam*>(mir_alloc(sizeof(SysAnnounceParam)))) {
      sap->msg = msg;     msg = 0;
      sap->title = title; title = 0;
      CloseHandle(CreateThread(0, 0, SysAnnounceMsg, sap, 0, 0));
    }

  if (msg)   mir_free(msg);
  if (title) mir_free(title);
}

// msg is automatically disposed inside this function using mir_free()
inline void SysAnnounce(wchar_t* msg)
{
  EnterCriticalSection(&g_CritSect);
  SysAnnounceUsingSettings(msg, mir_wstrdup(g_PopupTitle), g_BackColor, g_TextColor, g_PopupTimeout);
  LeaveCriticalSection(&g_CritSect);
}

// ME_DB_EVENT_FILTER_ADD
int OnDBEventFilterAdd(WPARAM wParam, LPARAM lParam)
{
  if (!lParam)
    return 0;
  DBEVENTINFO *dbei = reinterpret_cast<DBEVENTINFO*>(lParam);
  if (dbei->eventType != EVENTTYPE_MESSAGE)
    return 0;
  if (dbei->flags & DBEF_SENT)
    return 0;

  HANDLE hContact = reinterpret_cast<HANDLE>(wParam);

  CONTACTINFO ci = {0};
  ci.cbSize = sizeof(ci);
  ci.hContact = hContact;
  ci.szProto = dbei->szModule;
  ci.dwFlag = CNF_UNIQUEID | CNF_UNICODE;
  if (CallService(MS_CONTACT_GETCONTACTINFO, 0, (LPARAM) &ci) == 0) {
    if (ci.type == CNFT_ASCIIZ) {
      bool match = false;
      EnterCriticalSection(&g_CritSect);
      for (StrList::const_iterator i=g_Announcers.begin(); i!=g_Announcers.end(); ++i)
        if (_wcsicmp(ci.pszVal, *i) == 0) {
          match = true;
          break;
        }
      LeaveCriticalSection(&g_CritSect);
      mir_free(ci.pszVal);
      if (match) {
        SysAnnounce(DbGetEventTextW(dbei, CP_ACP));

        if (db_byte_get(hContact, "CList", "NotOnList", 0)) {
          db_unset(hContact, "CList", "NotOnList");
          db_byte_set(hContact, "CList", "Hidden", 1);
        }

        return 1;
      }
    }
  }

  return 0;
}

#define ADV_LIST (PLUGIN_NAME "_List")

INT_PTR CALLBACK MainDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch (msg) {
  case WM_INITDIALOG:
    TranslateDialogDefault(hwnd);

    SendDlgItemMessage(hwnd, IDC_ADVTIMEOUTSPIN, UDM_SETRANGE32, -1, MAX_TIMEOUT);
    SetDlgItemInt(hwnd, IDC_ADVTIMEOUTEDIT, g_PopupTimeout, TRUE);
    SetUserData(GetDlgItem(hwnd, IDC_ADVTIMEOUTEDIT), g_PopupTimeout); // Last good value

		SendDlgItemMessage(hwnd, IDC_ADVBACKCOLOR, CPM_SETDEFAULTCOLOUR, 0, DEF_BKCOLOUR);
		SendDlgItemMessage(hwnd, IDC_ADVBACKCOLOR, CPM_SETCOLOUR, 0, g_BackColor);

		SendDlgItemMessage(hwnd, IDC_ADVTEXTCOLOR, CPM_SETDEFAULTCOLOUR, 0, 0);
		SendDlgItemMessage(hwnd, IDC_ADVTEXTCOLOR, CPM_SETCOLOUR, 0, g_TextColor);

    SendDlgItemMessage(hwnd, IDC_ADVTITLEEDIT, EM_SETLIMITTEXT, MAX_CONTACTNAME-1, 0);
    SetDlgItemText(hwnd, IDC_ADVTITLEEDIT, g_PopupTitle);

    for (StrList::const_iterator i=g_Announcers.begin(); i!=g_Announcers.end(); ++i)
      SendDlgItemMessage(hwnd, IDC_ADVLIST, LB_ADDSTRING, 0, (LPARAM) *i);
    
    SetUserData(hwnd, 1); // Init complete - allow modifications
    return TRUE;
  case WM_COMMAND:
    if (GetUserData(hwnd)) { // Init complete - allow modifications
      HWND hThisControl = reinterpret_cast<HWND>(lParam); // use only when LOWORD(wParam) == ControlID
      switch (LOWORD(wParam)) {
      case IDC_ADVLIST:
        switch (HIWORD(wParam)) {
        case LBN_SELCHANGE:
          EnableWindow(GetDlgItem(hwnd, IDC_ADVREMOVEBUTTON), SendDlgItemMessage(hwnd, IDC_ADVLIST, LB_GETCURSEL, 0, 0) != LB_ERR);
          break;
        }
        break; // IDC_ADVLIST
      case IDC_ADVEDIT:
        EnableWindow(GetDlgItem(hwnd, IDC_ADVADDBUTTON), GetWindowTextLength(hThisControl));
        break; // IDC_ADVEDIT
      case IDC_ADVADDBUTTON:
        if (HIWORD(wParam) == BN_CLICKED)
          if (wchar_t* str = GetWndText(GetDlgItem(hwnd, IDC_ADVEDIT))) {
            SendDlgItemMessage(hwnd, IDC_ADVLIST, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(str));
            mir_free(str);
            PropSheet_Changed(GetParent(hwnd), hwnd);
            SetDlgItemText(hwnd, IDC_ADVEDIT, 0);
          }
        break; // IDC_ADVADDBUTTON
      case IDC_ADVREMOVEBUTTON:
        if (HIWORD(wParam) == BN_CLICKED) {
          HWND hList = GetDlgItem(hwnd, IDC_ADVLIST);
          LRESULT i = SendMessage(hList, LB_GETCURSEL, 0, 0);
          if (i != LB_ERR) {
            if (wchar_t* str = GetLBText(hList, i)) {
              SetDlgItemText(hwnd, IDC_ADVEDIT, str);
              mir_free(str);
            }
            SendMessage(hList, LB_DELETESTRING, i, 0);
            PropSheet_Changed(GetParent(hwnd), hwnd);
            EnableWindow(hThisControl, SendMessage(hList, LB_GETCURSEL, 0, 0) != LB_ERR);
          }
        }
        break; // IDC_ADVREMOVEBUTTON
      case IDC_ADVTITLEEDIT:
        if (HIWORD(wParam) == EN_UPDATE)
          PropSheet_Changed(GetParent(hwnd), hwnd);
        break; // IDC_ADVTITLEEDIT
      case IDC_ADVBACKCOLOR:
      case IDC_ADVTEXTCOLOR:
        if ((HIWORD(wParam) == CPN_COLOURCHANGED) &&
            ((g_BackColor != SendDlgItemMessage(hwnd, IDC_ADVBACKCOLOR, CPM_GETCOLOUR, 0, 0)) ||
             (g_TextColor != SendDlgItemMessage(hwnd, IDC_ADVTEXTCOLOR, CPM_GETCOLOUR, 0, 0))))
          PropSheet_Changed(GetParent(hwnd), hwnd);
        break; // IDC_ADVBACKCOLOR
      case IDC_ADVTIMEOUTEDIT:
        switch (HIWORD(wParam)) {
        case EN_UPDATE:
          {
            int i = static_cast<int>(GetDlgItemInt(hwnd, IDC_ADVTIMEOUTEDIT, 0, TRUE));
            if ((i < -1) || (i > MAX_TIMEOUT)) {
              // Revert to last good value
              SetDlgItemInt(hwnd, IDC_ADVTIMEOUTEDIT, GetUserData(hThisControl), TRUE);
            }
            else {
              SetUserData(hThisControl, i); // Last good value
              if (i != g_PopupTimeout)
                PropSheet_Changed(GetParent(hwnd), hwnd);
            }
          }
          break; // EN_UPDATE
        }
        break; // IDC_ADVTIMEOUTEDIT
      case IDC_TESTBUTTON:
        if (HIWORD(wParam) == BN_CLICKED)
          SysAnnounceUsingSettings(GetWndText(hThisControl),
                                   GetWndText(GetDlgItem(hwnd, IDC_ADVTITLEEDIT)),
                                   static_cast<COLORREF>(SendDlgItemMessage(hwnd, IDC_ADVBACKCOLOR, CPM_GETCOLOUR, 0, 0)),
                                   static_cast<COLORREF>(SendDlgItemMessage(hwnd, IDC_ADVTEXTCOLOR, CPM_GETCOLOUR, 0, 0)),
                                   static_cast<int>(GetDlgItemInt(hwnd, IDC_ADVTIMEOUTEDIT, 0, TRUE)));
        break; // IDC_TESTBUTTON
      }
    }
    break;
  case WM_NOTIFY:
    {
      NMHDR* nmhdr = reinterpret_cast<NMHDR*>(lParam);
      switch (nmhdr->code) {
      case PSN_APPLY:
        {
          EnterCriticalSection(&g_CritSect);

          CallService(MS_DB_MODULE_DELETE, 0, (LPARAM)ADV_LIST);
          ClearStrList(g_Announcers);
          LRESULT i = SendDlgItemMessage(hwnd, IDC_ADVLIST, LB_GETCOUNT, 0, 0);
          if (i != LB_ERR)
            while (i--)
              if (wchar_t* str = GetLBText(GetDlgItem(hwnd, IDC_ADVLIST), i)) {
                g_Announcers.push_back(str);
                char buf[21]; // Max int64 in decimal representation (incl. sign and trailing zero)
                mir_snprintf(buf, SIZEOF(buf), "%i", i);
                DBWriteContactSettingWString(0, ADV_LIST, buf, str);
              }

          if (wchar_t* str = GetWndText(GetDlgItem(hwnd, IDC_ADVTITLEEDIT))) {
            mir_sntprintf(g_PopupTitle, MAX_CONTACTNAME, L"%s", str);
            mir_free(str);
            DBWriteContactSettingWString(0, PLUGIN_NAME, PARAM_TITLE, g_PopupTitle);
          }

          db_dword_set(0, PLUGIN_NAME, PARAM_BKCOLOR,
                       g_BackColor = static_cast<COLORREF>(SendDlgItemMessage(hwnd, IDC_ADVBACKCOLOR, CPM_GETCOLOUR, 0, 0)));
          db_dword_set(0, PLUGIN_NAME, PARAM_TXTCOLOR,
                       g_TextColor = static_cast<COLORREF>(SendDlgItemMessage(hwnd, IDC_ADVTEXTCOLOR, CPM_GETCOLOUR, 0, 0)));
          db_dword_set(0, PLUGIN_NAME, PARAM_TIMEOUT,
                       g_PopupTimeout = static_cast<int>(GetDlgItemInt(hwnd, IDC_ADVTIMEOUTEDIT, 0, TRUE)));

          LeaveCriticalSection(&g_CritSect);
        }

        return TRUE;
      }
    }
    break;
  }
  return FALSE;
}

// ME_OPT_INITIALISE
int OnOptInitialise(WPARAM wParam, LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp = {0};
	odp.cbSize = sizeof(odp);
	odp.ptszGroup = _T("Events");
	odp.ptszTitle = _T(PLUGIN_NAME);
	odp.position = -1;
	odp.hInstance = g_hInst;
	odp.flags = ODPF_TCHAR;
	odp.ptszTab = _T("Main");
	odp.pszTemplate = MAKEINTRESOURCEA(IDD_DLGMAIN);
	odp.pfnDlgProc = MainDlgProc;

  CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);
	return 0;
}

extern "C" __declspec(dllexport) const MUUID* MirandaPluginInterfaces()
{
  static const MUUID interfaces[] = { MIID_ANNOUNCER, MIID_LAST };
  return interfaces;
}

extern "C" __declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
  if (mirandaVersion < PLUGIN_MAKE_VERSION( 0, 8, 0, 0 ))
    return NULL;

  static PLUGININFOEX pluginInfoEx = {
    sizeof(PLUGININFOEX), // cbSize
    PLUGIN_DECOR_NAME,    // shortName
    ANN_VERSION,          // version
    PLUGIN_DESCRIPTION,   // description
    PLUGIN_AUTHOR,        // author
    PLUGIN_AUTH_EMAIL,    // authorEmail
    COPYRIGHT,            // copyright
    "",                   // homepage
    UNICODE_AWARE,        // flags
    0,                    // replacesDefaultModule
    MIID_ANNOUNCER        // uuid
  };

  return &pluginInfoEx;
}

int SettingEnumProc(const char *szSetting, LPARAM lParam)
{
  wchar_t* a = DBGetStringW(0, ADV_LIST, szSetting);
  if (a) g_Announcers.push_back(a);
  return 0;
}

extern "C" __declspec(dllexport) int Load(PLUGINLINK *link)
{
  InitializeCriticalSection(&g_CritSect);

  pluginLink = link;
  mir_getMMI(&mmi);
  mir_getUTFI(&utfi);

  g_PopupTimeout = Constrain(static_cast<int>(db_dword_get(0, PLUGIN_NAME, PARAM_TIMEOUT, -1)), -1, MAX_TIMEOUT);
  g_BackColor = db_dword_get(0, PLUGIN_NAME, PARAM_BKCOLOR, DEF_BKCOLOUR);
  g_TextColor = db_dword_get(0, PLUGIN_NAME, PARAM_TXTCOLOR, 0);

  DBVARIANT dbv;
  if (DBGetContactSettingWString(0, PLUGIN_NAME, PARAM_TITLE, &dbv) != 0) // Fail
    mir_sntprintf(g_PopupTitle, MAX_CONTACTNAME, TranslateW(L"Announce"));
  else {
    mir_sntprintf(g_PopupTitle, MAX_CONTACTNAME, L"%s", dbv.pwszVal);
    DBFreeVariant(&dbv);
  }

  DBCONTACTENUMSETTINGS dbces;
  dbces.pfnEnumProc = SettingEnumProc;
  dbces.szModule = ADV_LIST;
  CallService(MS_DB_CONTACT_ENUMSETTINGS, 0, (LPARAM) &dbces);

  g_hook[0] = HookEvent(ME_DB_EVENT_FILTER_ADD, OnDBEventFilterAdd);
  g_hook[1] = HookEvent(ME_OPT_INITIALISE, OnOptInitialise);
  return 0;
}

extern "C" __declspec(dllexport) int Unload(void)
{
  UnhookEvent(g_hook[0]);
  UnhookEvent(g_hook[1]);

  ClearStrList(g_Announcers);

  DeleteCriticalSection(&g_CritSect);

  return 0;
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
  g_hInst = hModule;
  switch (ul_reason_for_call)
  {
  case DLL_PROCESS_ATTACH:
  case DLL_THREAD_ATTACH:
  case DLL_THREAD_DETACH:
  case DLL_PROCESS_DETACH:
    break;
  }
  return TRUE;
}
