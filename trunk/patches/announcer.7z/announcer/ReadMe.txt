﻿==================================================
Announcer plugin for Miranda IM (v. 8.0 and later)
==================================================

Copyright (c) 2012, Mike Kaganski
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met: 

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer. 
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies, 
either expressed or implied, of the Copyright Owner.

==================================================

The Visual Studio project was created with MS VC++ 2010 Express with Microsoft
Windows SDK v7.1 (http://www.microsoft.com/download/en/details.aspx?id=8279)
installed. You will need the SDK if you need to build 64-bit version of the
plugin using the Express SKU of MS Visual Studio.

To automate the configuration of the plugin, you may use these settings in
Miranda IM autoexec.ini file:

[Announcer]
;PopupTitle defaults to the localized "Announce" string
PopupTitle=uAnnounce
;PopupBackColor defaults to yellow
PopupBackColor=d65535
;PopupTextColor defaults to black
PopupTextColor=d0
;PopupTimeout defaults to infinity, maximum positive value is 604800 (1 week)
PopupTimeout=d-1

;This is the list of contacts (their IDs) that will be treated as announcers,
;i.e. their messages will only show PopUps, and not open conversation.
;Also, if a user receives a message from one of these IDs, and this ID is not
;in his/her contact list, this contact is created hidden to avoid cluttering
;the contact list. This contact may be made visible by either adding it again
;manually, or in Options->Events->Ignore. There is no default. You may add any
;number of IDs (up to )
;The example is suitable for the XMPP announcement mechanism (tested to work
;with ejabberd server). The second line is necessary for those who added the
;full announcement jid to their contact list.
[Announcer_List]
0=uexample.com
1=uexample.com/announce/online

