#ifndef __ANNOUNCER_VERSIONINFO_H__
#define __ANNOUNCER_VERSIONINFO_H__

#define ANN_MAKE_VERSION(a,b,c,d)   (((((DWORD)(a))&0xFF)<<24)|((((DWORD)(b))&0xFF)<<16)|((((DWORD)(c))&0xFF)<<8)|(((DWORD)(d))&0xFF))
#define ANN_STR_(x) #x
#define ANN_STR(x) ANN_STR_(x)

#define ANN_VERSION_A 0
#define ANN_VERSION_B 0
#define ANN_VERSION_C 0
#define ANN_VERSION_D 1

#define ANN_VERSION ANN_MAKE_VERSION(ANN_VERSION_A, ANN_VERSION_B, ANN_VERSION_C, ANN_VERSION_D)
#define ANN_VERSION_TEXT ANN_STR(ANN_VERSION_A) "." ANN_STR(ANN_VERSION_B) "." ANN_STR(ANN_VERSION_C) "." ANN_STR(ANN_VERSION_D)

#ifdef _M_X64
#define ARCHNAME " (x64)"
#else
#define ARCHNAME " (x86)"
#endif

#define PLUGIN_NAME        "Announcer"
#define PLUGIN_DECOR_NAME  PLUGIN_NAME ARCHNAME
#define PLUGIN_FULL_NAME   PLUGIN_NAME " plugin for Miranda IM" ARCHNAME
#define PLUGIN_DESCRIPTION "Show announcements as popups\r\n" \
                           "Pretty popups are shown only if a popup plugin is installed.\r\n" \
                           "Otherwise, simple message box will open."

#define PLUGIN_AUTHOR      "Mike Kaganski"
#define PLUGIN_AUTH_EMAIL  "mikekaganski@gmail.com"

#define PLUGIN_YEAR        "2012"
#define COPYRIGHT          "� " PLUGIN_YEAR " " PLUGIN_AUTHOR

#endif // __ANNOUNCER_VERSIONINFO_H__
