#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DLGMAIN                             100
#define IDC_ADVTEXTCOLOR                        1000
#define IDC_ADVTIMEOUTSPIN                      1006
#define IDC_ADVLIST                             1008
#define IDC_ADVEDIT                             1009
#define IDC_ADVADDBUTTON                        1010
#define IDC_ADVREMOVEBUTTON                     1011
#define IDC_ADVTITLEEDIT                        1012
#define IDC_ADVBACKCOLOR                        1013
#define IDC_ADVTIMEOUTEDIT                      1014
#define IDC_TESTBUTTON                          1015
