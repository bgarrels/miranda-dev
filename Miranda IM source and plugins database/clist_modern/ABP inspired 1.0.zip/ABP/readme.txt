CC-BY-SA license.
by Belf (belforator@gmail.com)
Homepage http://belf.ovh.org

Skin for Modern Contact List inspired by toastbrotpascal ABP 1.2 Rainmeter theme (http://toastbrotpascal.deviantart.com/art/ABP-1-2-173567354).