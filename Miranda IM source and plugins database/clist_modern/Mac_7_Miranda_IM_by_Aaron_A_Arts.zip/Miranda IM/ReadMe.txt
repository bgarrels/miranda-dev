install fonts

open folder theme and copy folder 00Mac into C:\Program Files\Miranda IM\Skins 

Then use the options dialog to apply.... 



If none of this sounds familar.. and you don't know what i'm talking about..
then you need to do more research before downloading random skins =) 

-aaron