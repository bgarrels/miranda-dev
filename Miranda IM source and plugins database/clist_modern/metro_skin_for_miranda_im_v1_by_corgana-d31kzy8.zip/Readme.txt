Made By: Justin

www.jhanagan.com
corgana.deviantart.com
www.flickr.com/photos/corgana

Step 1: Install fonts from fonts folder.
Step 2: Copy "Metro" folder to /Miranda IM/Skins
Step 3: Change all your friends names to lowercase first names only
Step 4: Swankify your desktop


=================================================
OPTIONS MENU CONFIG:
=================================================

-----Contact List-------------------------------

Disable Groups
Lock Manual Resize (Make sure it's 160px wide if you want it to blend nicely with Omnimo 2)
Ignore empty extra icon places

	-----Row Items--------------------------

	Min row height: 52px
	Row border: 1px

		-----Avatar Tab-----------------

		Ignore size for row height calcs
		Max width&height 70px

		-----Second Line----------------
		
		Show Second Line
		Status



-----Customise----------------------------------

	-----Fonts & Colors---------------------

		-----Contact Names--------------

		(Highlight everything)
		Text Color: Black
		Font: Zegoe U, Light, Size 18

		-----Row Items--------------

		Second Line
		Font Color: Grey (89,89,89)
		Zegoe Caps, Bold, Size 5

=================================================
Thanks for Downloading!
=================================================