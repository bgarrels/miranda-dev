-[tabSRMM readme]--------------------------------------------------

You NEED TO COPY THE tabsrmm_icons.dll to your Miranda Plugins folder
(just the same location where tabsrmm*.DLL resides OR to the \icons 
subfolder just below your main miranda installation directory.

tabSRMM will search for a valid tabsrmm_icons.dll in the following order:

1. plugins folder
2. icons folder

If none can be found, you'll get a warning message. You can still continue 
to run tabSRMM, but you'll get no icons on the toolbar and most likely 
icons will be missing in other places too (status bar, for example).

You can also use the IcoLib plugin.
-----------------------------------

http://addons.miranda-im.org/details.php?action=viewfile&id=1895

If installed, tabSRMM will support the configuration of icons at runtime, 
using the services provided by IcoLib. You still need to install a tabSRMM
icon pack, because the icons from the icon pack will be used to setup the 
default icons for IcoLib.

take a look here: http://addons.miranda-im.org/details.php?action=viewfile&id=3163

tabsrmm_icons.dll was realized with Heaventools PE Explorer.  

-[tabSRMM icon index]--------------------------------------------------

 [toolbar]
1  history
2  message log option
3  add
4  multisend
5  typing notify
6  quote text
7  save
8  send
9  avatar menu
10 close
11 about
50 emoticons
51 bold
52 italic
53 underline
54 font face
55 font color

 [message log]
110 in
111 out
112 status change

 [default]
113 alert error
130 typing notify on
131 typing notify off
132 secure im on
133 secure im off
134 sounds on
135 sounds off
136 static container icons
137 session list
138 favorite contacts
139 recent session
140 setup sidebar
141 contact preferencies
160 down
161 left
162 up
163 right
170 unknown
171 unknown

 [animated tray]
190 frame1
191 frame2
192 frame3
193 frame4

200 message log option
201 color
202
203
204
205
206 (10x10)
207 (10x10)
208 (10x10)
209 (10x10)
210 empty
211 (10x10)
212 empty
213
214
250 right
251 left
252 in
253 out
254 status change
255
256 in
257 out
258 
259
260
261
262 out
263 in
264 (1x28)
265 (24x28)

