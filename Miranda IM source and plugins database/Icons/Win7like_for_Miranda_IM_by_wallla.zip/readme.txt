A Iconset for Miranda IM that matches the Windows 7 Icons in the Systray.


v1.1 - added lunch & phone
v1.0 - initial release


walla, 2010