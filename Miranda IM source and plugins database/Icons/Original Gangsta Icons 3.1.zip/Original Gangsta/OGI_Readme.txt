Original Gangsta!
_______________________

This is a set of nice icons for use with Miranda IM. Use them whatever way you like! However, if you redistribute in any way give me credit.



Installing.
_______________________

1. Navigate to the system menu and select "Options"
2. Make sure the checkbox "Expert options" in the lower left of the window is checked.
3. Go to "Contact list" -> "Icons"
4. Select a protocol in the "Show category" drop down box.
5. Click "the button "Load icon set"
6. Locate the files containing the appropriate icons (eg. XP_icq.dll) and click "Open"
7. The icons should now show up in the preview pane.
8. Repeat from step 4 to set up other protocols.
9. Click "OK" to apply changes and close the options window.



//MatriX #109476464