An GoogleTalk-Icon-Pack for Miranda-IM [http://www.miranda-im.org].
I've done this work, 'cause I needed an Icon-Pack for GoogleTalk myself !
I hope it will be usefull for you ,too.


To use the icons, just copy 'proto_GoogleTalk.dll' into your miranda\icons\ - folder !

ATTENTION : If you use a GoogleTalk-Plugin like JGmail you got to rename the proto_GoogleTalk.dll to, in this case proto_JGmail.dll !


For creating the proto_GoogleTalk.dll I used 'Miranda Icon Builder'.

Work done by dapizzafressa [http://www.dapizzafressa.de.gg]
Have a nice time ^^
