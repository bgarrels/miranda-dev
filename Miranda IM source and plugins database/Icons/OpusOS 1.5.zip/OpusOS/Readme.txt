OpusOS for Miranda was created by Jim-Phelps (http://jim-phelps.deviantart.com)

Full permission to use the icons was received from the author of the original Trillian-skin, Armlann.