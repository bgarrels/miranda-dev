
Icon set for:
Gadu-Gadu
Tlen
Dobreprogramy
Gtalk
XMPP
Facebook
Xfire
IRC
AIM
ICQ
MSN
Metacontacts
Global

32x32 and 16x16 px icons.

Tyczek (tyczek88@gmail.com) 2011