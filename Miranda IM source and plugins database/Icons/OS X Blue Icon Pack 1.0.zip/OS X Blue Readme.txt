Miranda OS X Blue Icon Pack by Hale (C) 2004


Inspired by Mac OS X and NETknightX's Faux Aqua 2.01 Icon Set. These 32-bit icons for Miranda Instant Messenger (http://www.miranda-im.org/) have been designed for WindowsXP. They look best using the included background, originally supplied by NETknightX in said Faux Aqua Icon Set.


Installation
~Zip file
	1. Extract the downloadable zip file to your main Miranda directory

~Icons
	1. In Miranda open Miranda IM Options, Contact List, Icons, Import Icons
	2. Select the OSX Blue.dll Icon library from the Icons folder where you extracted it above
	3. Drag and drop the icons from the Icon Index window on to where you want each to appear in the Miranda IM Options, Icons window
	4. Click OK

~Background
	1. In Miranda open Miranda IM Options, Contact List, List Background
	2. Check the box next to Use Background Bitmap
	3. In the box type or Browse To the background.gif in the Icons folder where you extracted it above
	4. Check the boxes next to Tile Horizontally, and Tile Vertically
	5. Make sure the box next to Stretch to Height is not checked
	/For a Selection Colour I use Red 0, Green 155, Blue 255/
	6. Click OK


Contact
~MSN	HaleC2@hotmail.com
~eMail	HaleC2@hotmail.com