MBot 0.0.3.4-1 Custom AutoReplier PHP Script 0.1.1.0
Only Russian language
by Dionys (contact: skiner@inbox.ru)

Command (send any chat window or contact window for create autoreply for current contact):
!arc <Text>			- start autoreply for current contact with specified text
!ara <Text>			- start autoreply for all with specified text
!ar-online <Text>	- start autoreply for "Online" status with specified text
!ar-away <Text>		- start autoreply for "Away" status with specified text
!ar-dnd <Text>		- start autoreply for "DND" status with specified text
!ar-na <Text>		- start autoreply for "NA" status with specified text
!ar-occup <Text>	- start autoreply for "Occupied" status with specified text
!ar-freechat <Text>	- start autoreply for "Free chat" status with specified text
!ar-invis <Text>	- start autoreply for "Invisible" status with specified text
!sarc				- stop autoreply for current contact
!sara				- stop autoreply for all incoming message
!sar-online			- stop autoreply for "Online" status
!sar-away			- stop autoreply for "Away" status
!sar-dnd			- stop autoreply for "DND" status
!sar-na				- stop autoreply for "NA" status
!sar-occup			- stop autoreply for "Occupied" status
!sar-freechat		- stop autoreply for "Free chat" status
!sar-invis			- stop autoreply for "Invisible" status
!!sar				- stop autoreply
!pass <Text>		- set password for access important contact
!showpass			- show password

If AutoReplier is started, contact after sending message will receive the warning (the message will be written in history).
All next messages of the current contact will be blocked in the next 300 sec.
If contact will sending password - will be able to send messages.
Upon receipt of such messages will play a special sound.