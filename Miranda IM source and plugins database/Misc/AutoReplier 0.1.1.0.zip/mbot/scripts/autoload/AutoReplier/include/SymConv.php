<?php
/*
* Symbol converter PHP script 1.1 [ANSI]
* Copyright (c) 2009 by Dionys
* Contact: skiner@inbox.ru
*/

/* Convert cyrillic ANSI symbols to ASCII symbols */
function ansi2ascii($str)
{
	for ($i = 0; $i < strlen($str); $i++)
	{
		$ch = $str[$i];
		switch($ch)
		{
			case chr(0xC0): $out .= chr(0x80); break;	// � win-1251 to ascii
			case chr(0xE0): $out .= chr(0xA0); break;	// � win-1251 to ascii
			case chr(0xC1): $out .= chr(0x81); break;	// � win-1251 to ascii
			case chr(0xE1): $out .= chr(0xA1); break;	// � win-1251 to ascii
			case chr(0xC2): $out .= chr(0x82); break;	// � win-1251 to ascii
			case chr(0xE2): $out .= chr(0xA2); break;	// � win-1251 to ascii
			case chr(0xC3): $out .= chr(0x83); break;	// � win-1251 to ascii
			case chr(0xE3): $out .= chr(0xA3); break;	// � win-1251 to ascii
			case chr(0xC4): $out .= chr(0x84); break;	// � win-1251 to ascii
			case chr(0xE4): $out .= chr(0xA4); break;	// � win-1251 to ascii
			case chr(0xC5): $out .= chr(0x85); break;	// � win-1251 to ascii
			case chr(0xE5): $out .= chr(0xA5); break;	// � win-1251 to ascii
			case chr(0xA8): $out .= chr(0xF0); break;	// � win-1251 to ascii
			case chr(0xB8): $out .= chr(0xF1); break;	// � win-1251 to ascii
			case chr(0xC6): $out .= chr(0x86); break;	// � win-1251 to ascii
			case chr(0xE6): $out .= chr(0xA6); break;	// � win-1251 to ascii
			case chr(0xC7): $out .= chr(0x87); break;	// � win-1251 to ascii
			case chr(0xE7): $out .= chr(0xA7); break;	// � win-1251 to ascii
			case chr(0xC8): $out .= chr(0x88); break;	// � win-1251 to ascii
			case chr(0xE8): $out .= chr(0xA8); break;	// � win-1251 to ascii
			case chr(0xC9): $out .= chr(0x89); break;	// � win-1251 to ascii
			case chr(0xE9): $out .= chr(0xA9); break;	// � win-1251 to ascii
			case chr(0xCA): $out .= chr(0x8A); break;	// � win-1251 to ascii
			case chr(0xEA): $out .= chr(0xAA); break;	// � win-1251 to ascii
			case chr(0xCB): $out .= chr(0x8B); break;	// � win-1251 to ascii
			case chr(0xEB): $out .= chr(0xAB); break;	// � win-1251 to ascii
			case chr(0xCC): $out .= chr(0x8C); break;	// � win-1251 to ascii
			case chr(0xEC): $out .= chr(0xAC); break;	// � win-1251 to ascii
			case chr(0xCD): $out .= chr(0x8D); break;	// � win-1251 to ascii
			case chr(0xED): $out .= chr(0xAD); break;	// � win-1251 to ascii
			case chr(0xCE): $out .= chr(0x8E); break;	// � win-1251 to ascii
			case chr(0xEE): $out .= chr(0xAE); break;	// � win-1251 to ascii
			case chr(0xCF): $out .= chr(0x8F); break;	// � win-1251 to ascii
			case chr(0xEF): $out .= chr(0xAF); break;	// � win-1251 to ascii
			case chr(0xD0): $out .= chr(0x90); break;	// � win-1251 to ascii
			case chr(0xF0): $out .= chr(0xE0); break;	// � win-1251 to ascii
			case chr(0xD1): $out .= chr(0x91); break;	// � win-1251 to ascii
			case chr(0xF1): $out .= chr(0xE1); break;	// � win-1251 to ascii
			case chr(0xD2): $out .= chr(0x92); break;	// � win-1251 to ascii
			case chr(0xF2): $out .= chr(0xE2); break;	// � win-1251 to ascii
			case chr(0xD3): $out .= chr(0x93); break;	// � win-1251 to ascii
			case chr(0xF3): $out .= chr(0xE3); break;	// � win-1251 to ascii
			case chr(0xD4): $out .= chr(0x94); break;	// � win-1251 to ascii
			case chr(0xF4): $out .= chr(0xE4); break;	// � win-1251 to ascii
			case chr(0xD5): $out .= chr(0x95); break;	// � win-1251 to ascii
			case chr(0xF5): $out .= chr(0xE5); break;	// � win-1251 to ascii
			case chr(0xD6): $out .= chr(0x96); break;	// � win-1251 to ascii
			case chr(0xF6): $out .= chr(0xE6); break;	// � win-1251 to ascii
			case chr(0xD7): $out .= chr(0x97); break;	// � win-1251 to ascii
			case chr(0xF7): $out .= chr(0xE7); break;	// � win-1251 to ascii
			case chr(0xD8): $out .= chr(0x98); break;	// � win-1251 to ascii
			case chr(0xF8): $out .= chr(0xE8); break;	// � win-1251 to ascii
			case chr(0xD9): $out .= chr(0x99); break;	// � win-1251 to ascii
			case chr(0xF9): $out .= chr(0xE9); break;	// � win-1251 to ascii
			case chr(0xDA): $out .= chr(0x9A); break;	// � win-1251 to ascii
			case chr(0xFA): $out .= chr(0xEA); break;	// � win-1251 to ascii
			case chr(0xDB): $out .= chr(0x9B); break;	// � win-1251 to ascii
			case chr(0xFB): $out .= chr(0xEB); break;	// � win-1251 to ascii
			case chr(0xDC): $out .= chr(0x9C); break;	// � win-1251 to ascii
			case chr(0xFC): $out .= chr(0xEC); break;	// � win-1251 to ascii
			case chr(0xDD): $out .= chr(0x9D); break;	// � win-1251 to ascii
			case chr(0xFD): $out .= chr(0xED); break;	// � win-1251 to ascii
			case chr(0xDE): $out .= chr(0x9E); break;	// � win-1251 to ascii
			case chr(0xFE): $out .= chr(0xEE); break;	// � win-1251 to ascii
			case chr(0xDF): $out .= chr(0x9F); break;	// � win-1251 to ascii
			case chr(0xFF): $out .= chr(0xEF); break;	// � win-1251 to ascii
			default : $out .= $ch;						// skip
		}
	}
	return $out;	
}

/* Convert cyrillic UTF symbols to ANSI symbols */
function utf2ansi($str)
{
	for ($i = 0; $i < strlen($str); $i++)
	{
		$ch = $str[$i];

		if($ch == chr(0xD0))
			$utf_mark = 'D0';
		if($ch == chr(0xD1))
			$utf_mark = 'D1';

		switch($ch)
		{
			case chr(0xD0): $out .= ""; break;			// null
			case chr(0xD1): $out .= ""; break;			// null
			case chr(0x90): $out .= chr(0xC0); break;	// � utf-8 to ansi
			case chr(0xB0): $out .= chr(0xE0); break;	// � utf-8 to ansi
			case chr(0x91):
						if($utf_mark == 'D0')
						{
							$out .= chr(0xC1); break;	// � utf-8 to ansi
						}
						if($utf_mark == 'D1')
						{
							$out .= chr(0xB8); break;	// � utf-8 to ansi
						}
			case chr(0xB1): $out .= chr(0xE1); break;	// � utf-8 to ansi
			case chr(0x92): $out .= chr(0xC2); break;	// � utf-8 to ansi
			case chr(0xB2): $out .= chr(0xE2); break;	// � utf-8 to ansi
			case chr(0x93): $out .= chr(0xC3); break;	// � utf-8 to ansi
			case chr(0xB3): $out .= chr(0xE3); break;	// � utf-8 to ansi
			case chr(0x94): $out .= chr(0xC4); break;	// � utf-8 to ansi
			case chr(0xB4): $out .= chr(0xE4); break;	// � utf-8 to ansi
			case chr(0x95): $out .= chr(0xC5); break;	// � utf-8 to ansi
			case chr(0xB5): $out .= chr(0xE5); break;	// � utf-8 to ansi
			case chr(0x81):
						if($utf_mark == 'D0')
						{
							$out .= chr(0xA8); break;	// � utf-8 to ansi
						}
						if($utf_mark == 'D1')
						{
							$out .= chr(0xF1); break;	// � utf-8 to ansi
						}					
			case chr(0x96): $out .= chr(0xC6); break;	// � utf-8 to ansi
			case chr(0xB6): $out .= chr(0xE6); break;	// � utf-8 to ansi
			case chr(0x97): $out .= chr(0xC7); break;	// � utf-8 to ansi
			case chr(0xB7): $out .= chr(0xE7); break;	// � utf-8 to ansi
			case chr(0x98): $out .= chr(0xC8); break;	// � utf-8 to ansi
			case chr(0xB8): $out .= chr(0xE8); break;	// � utf-8 to ansi
			case chr(0x99): $out .= chr(0xC9); break;	// � utf-8 to ansi
			case chr(0xB9): $out .= chr(0xE9); break;	// � utf-8 to ansi
			case chr(0x9A): $out .= chr(0xCA); break;	// � utf-8 to ansi
			case chr(0xBA): $out .= chr(0xEA); break;	// � utf-8 to ansi
			case chr(0x9B): $out .= chr(0xCB); break;	// � utf-8 to ansi
			case chr(0xBB): $out .= chr(0xEB); break;	// � utf-8 to ansi
			case chr(0x9C): $out .= chr(0xCC); break;	// � utf-8 to ansi
			case chr(0xBC): $out .= chr(0xEC); break;	// � utf-8 to ansi
			case chr(0x9D): $out .= chr(0xCD); break;	// � utf-8 to ansi
			case chr(0xBD): $out .= chr(0xED); break;	// � utf-8 to ansi
			case chr(0x9E): $out .= chr(0xCE); break;	// � utf-8 to ansi
			case chr(0xBE): $out .= chr(0xEE); break;	// � utf-8 to ansi
			case chr(0x9F): $out .= chr(0xCF); break;	// � utf-8 to ansi
			case chr(0xBF): $out .= chr(0xEF); break;	// � utf-8 to ansi
			case chr(0xA0): $out .= chr(0xD0); break;	// � utf-8 to ansi
			case chr(0x80): $out .= chr(0xF0); break;	// � utf-8 to ansi
			case chr(0xA1): $out .= chr(0xD1); break;	// � utf-8 to ansi
			case chr(0xA2): $out .= chr(0xD2); break;	// � utf-8 to ansi
			case chr(0x82): $out .= chr(0xF2); break;	// � utf-8 to ansi
			case chr(0xA3): $out .= chr(0xD3); break;	// � utf-8 to ansi
			case chr(0x83): $out .= chr(0xF3); break;	// � utf-8 to ansi
			case chr(0xA4): $out .= chr(0xD4); break;	// � utf-8 to ansi
			case chr(0x84): $out .= chr(0xF4); break;	// � utf-8 to ansi
			case chr(0xA5): $out .= chr(0xD5); break;	// � utf-8 to ansi
			case chr(0x85): $out .= chr(0xF5); break;	// � utf-8 to ansi
			case chr(0xA6): $out .= chr(0xD6); break;	// � utf-8 to ansi
			case chr(0x86): $out .= chr(0xF6); break;	// � utf-8 to ansi
			case chr(0xA7): $out .= chr(0xD7); break;	// � utf-8 to ansi
			case chr(0x87): $out .= chr(0xF7); break;	// � utf-8 to ansi
			case chr(0xA8): $out .= chr(0xD8); break;	// � utf-8 to ansi
			case chr(0x88): $out .= chr(0xF8); break;	// � utf-8 to ansi
			case chr(0xA9): $out .= chr(0xD9); break;	// � utf-8 to ansi
			case chr(0x89): $out .= chr(0xF9); break;	// � utf-8 to ansi
			case chr(0xAA): $out .= chr(0xDA); break;	// � utf-8 to ansi
			case chr(0x8A): $out .= chr(0xFA); break;	// � utf-8 to ansi
			case chr(0xAB): $out .= chr(0xDB); break;	// � utf-8 to ansi
			case chr(0x8B): $out .= chr(0xFB); break;	// � utf-8 to ansi
			case chr(0xAC): $out .= chr(0xDC); break;	// � utf-8 to ansi
			case chr(0x8C): $out .= chr(0xFC); break;	// � utf-8 to ansi
			case chr(0xAD): $out .= chr(0xDD); break;	// � utf-8 to ansi
			case chr(0x8D): $out .= chr(0xFD); break;	// � utf-8 to ansi
			case chr(0xAE): $out .= chr(0xDE); break;	// � utf-8 to ansi
			case chr(0x8E): $out .= chr(0xFE); break;	// � utf-8 to ansi
			case chr(0xAF): $out .= chr(0xDF); break;	// � utf-8 to ansi
			case chr(0x8F): $out .= chr(0xFF); break;	// � utf-8 to ansi
			default : $out .= $ch;						// skip
		}
	}
	return $out;
}

/* Convert cyrillic ASCII symbols to ANSI symbols */
function ascii2ansi($str)
{
	for ($i = 0; $i < strlen($str); $i++)
	{
		$ch = $str[$i];
		switch($ch)
		{
			case chr(0x80): $out .= chr(0xC0); break;	// � ascii to win-1251
			case chr(0xA0): $out .= chr(0xE0); break;	// � ascii to win-1251
			case chr(0x81): $out .= chr(0xC1); break;	// � ascii to win-1251
			case chr(0xA1): $out .= chr(0xE1); break;	// � ascii to win-1251
			case chr(0x82): $out .= chr(0xC2); break;	// � ascii to win-1251
			case chr(0xA2): $out .= chr(0xE2); break;	// � ascii to win-1251
			case chr(0x83): $out .= chr(0xC3); break;	// � ascii to win-1251
			case chr(0xA3): $out .= chr(0xE3); break;	// � ascii to win-1251
			case chr(0x84): $out .= chr(0xC4); break;	// � ascii to win-1251
			case chr(0xA4): $out .= chr(0xE4); break;	// � ascii to win-1251
			case chr(0x85): $out .= chr(0xC5); break;	// � ascii to win-1251
			case chr(0xA5): $out .= chr(0xE5); break;	// � ascii to win-1251
			case chr(0xF0): $out .= chr(0xA8); break;	// � ascii to win-1251
			case chr(0xF1): $out .= chr(0xB8); break;	// � ascii to win-1251
			case chr(0x86): $out .= chr(0xC6); break;	// � ascii to win-1251
			case chr(0xA6): $out .= chr(0xE6); break;	// � ascii to win-1251
			case chr(0x87): $out .= chr(0xC7); break;	// � ascii to win-1251
			case chr(0xA7): $out .= chr(0xE7); break;	// � ascii to win-1251
			case chr(0x88): $out .= chr(0xC8); break;	// � ascii to win-1251
			case chr(0xA8): $out .= chr(0xE8); break;	// � ascii to win-1251
			case chr(0x89): $out .= chr(0xC9); break;	// � ascii to win-1251
			case chr(0xA9): $out .= chr(0xE9); break;	// � ascii to win-1251
			case chr(0x8A): $out .= chr(0xCA); break;	// � ascii to win-1251
			case chr(0xAA): $out .= chr(0xEA); break;	// � ascii to win-1251
			case chr(0x8B): $out .= chr(0xCB); break;	// � ascii to win-1251
			case chr(0xAB): $out .= chr(0xEB); break;	// � ascii to win-1251
			case chr(0x8C): $out .= chr(0xCC); break;	// � ascii to win-1251
			case chr(0xAC): $out .= chr(0xEC); break;	// � ascii to win-1251
			case chr(0x8D): $out .= chr(0xCD); break;	// � ascii to win-1251
			case chr(0xAD): $out .= chr(0xED); break;	// � ascii to win-1251
			case chr(0x8E): $out .= chr(0xCE); break;	// � ascii to win-1251
			case chr(0xAE): $out .= chr(0xEE); break;	// � ascii to win-1251
			case chr(0x8F): $out .= chr(0xCF); break;	// � ascii to win-1251
			case chr(0xAF): $out .= chr(0xEF); break;	// � ascii to win-1251
			case chr(0x90): $out .= chr(0xD0); break;	// � ascii to win-1251
			case chr(0xE0): $out .= chr(0xF0); break;	// � ascii to win-1251
			case chr(0x91): $out .= chr(0xD1); break;	// � ascii to win-1251
			case chr(0xE1): $out .= chr(0xF1); break;	// � ascii to win-1251
			case chr(0x92): $out .= chr(0xD2); break;	// � ascii to win-1251
			case chr(0xE2): $out .= chr(0xF2); break;	// � ascii to win-1251
			case chr(0x93): $out .= chr(0xD3); break;	// � ascii to win-1251
			case chr(0xE3): $out .= chr(0xF3); break;	// � ascii to win-1251
			case chr(0x94): $out .= chr(0xD4); break;	// � ascii to win-1251
			case chr(0xE4): $out .= chr(0xF4); break;	// � ascii to win-1251
			case chr(0x95): $out .= chr(0xD5); break;	// � ascii to win-1251
			case chr(0xE5): $out .= chr(0xF5); break;	// � ascii to win-1251
			case chr(0x96): $out .= chr(0xD6); break;	// � ascii to win-1251
			case chr(0xE6): $out .= chr(0xF6); break;	// � ascii to win-1251
			case chr(0x97): $out .= chr(0xD7); break;	// � ascii to win-1251
			case chr(0xE7): $out .= chr(0xF7); break;	// � ascii to win-1251
			case chr(0x98): $out .= chr(0xD8); break;	// � ascii to win-1251
			case chr(0xE8): $out .= chr(0xF8); break;	// � ascii to win-1251
			case chr(0x99): $out .= chr(0xD9); break;	// � ascii to win-1251
			case chr(0xE9): $out .= chr(0xF9); break;	// � ascii to win-1251
			case chr(0x9A): $out .= chr(0xDA); break;	// � ascii to win-1251
			case chr(0xEA): $out .= chr(0xFA); break;	// � ascii to win-1251
			case chr(0x9B): $out .= chr(0xDB); break;	// � ascii to win-1251
			case chr(0xEB): $out .= chr(0xFB); break;	// � ascii to win-1251
			case chr(0x9C): $out .= chr(0xDC); break;	// � ascii to win-1251
			case chr(0xEC): $out .= chr(0xFC); break;	// � ascii to win-1251
			case chr(0x9D): $out .= chr(0xDD); break;	// � ascii to win-1251
			case chr(0xED): $out .= chr(0xFD); break;	// � ascii to win-1251
			case chr(0x9E): $out .= chr(0xDE); break;	// � ascii to win-1251
			case chr(0xEE): $out .= chr(0xFE); break;	// � ascii to win-1251
			case chr(0x9F): $out .= chr(0xDF); break;	// � ascii to win-1251
			case chr(0xEF): $out .= chr(0xFF); break;	// � ascii to win-1251
			default : $out .= $ch;						// skip
		}
	}
	return $out;	
}

/* Convert cyrillic ANSI symbols to UTF symbols */
function ansi2utf($str)
{
	for ($i = 0; $i < strlen($str); $i++)
	{
		$ch = $str[$i];
		switch($ch)
		{
			case chr(0xC0): $out .= chr(0xD0).chr(0x90); break;	// � win-1251 to utf
			case chr(0xE0): $out .= chr(0xD0).chr(0xB0); break;	// � win-1251 to utf
			case chr(0xC1): $out .= chr(0xD0).chr(0x91); break;	// � win-1251 to utf
			case chr(0xE1): $out .= chr(0xD0).chr(0xB1); break;	// � win-1251 to utf
			case chr(0xC2): $out .= chr(0xD0).chr(0x92); break;	// � win-1251 to utf
			case chr(0xE2): $out .= chr(0xD0).chr(0xB2); break;	// � win-1251 to utf
			case chr(0xC3): $out .= chr(0xD0).chr(0x93); break;	// � win-1251 to utf
			case chr(0xE3): $out .= chr(0xD0).chr(0xB3); break;	// � win-1251 to utf
			case chr(0xC4): $out .= chr(0xD0).chr(0x94); break;	// � win-1251 to utf
			case chr(0xE4): $out .= chr(0xD0).chr(0xB4); break;	// � win-1251 to utf
			case chr(0xC5): $out .= chr(0xD0).chr(0x95); break;	// � win-1251 to utf
			case chr(0xE5): $out .= chr(0xD0).chr(0xB5); break;	// � win-1251 to utf
			case chr(0xA8): $out .= chr(0xD0).chr(0x81); break;	// � win-1251 to utf
			case chr(0xB8): $out .= chr(0xD1).chr(0x91); break;	// � win-1251 to utf
			case chr(0xC6): $out .= chr(0xD0).chr(0x96); break;	// � win-1251 to utf
			case chr(0xE6): $out .= chr(0xD0).chr(0xB6); break;	// � win-1251 to utf
			case chr(0xC7): $out .= chr(0xD0).chr(0x97); break;	// � win-1251 to utf
			case chr(0xE7): $out .= chr(0xD0).chr(0xB7); break;	// � win-1251 to utf
			case chr(0xC8): $out .= chr(0xD0).chr(0x98); break;	// � win-1251 to utf
			case chr(0xE8): $out .= chr(0xD0).chr(0xB8); break;	// � win-1251 to utf
			case chr(0xC9): $out .= chr(0xD0).chr(0x99); break;	// � win-1251 to utf
			case chr(0xE9): $out .= chr(0xD0).chr(0xB9); break;	// � win-1251 to utf
			case chr(0xCA): $out .= chr(0xD0).chr(0x9A); break;	// � win-1251 to utf
			case chr(0xEA): $out .= chr(0xD0).chr(0xBA); break;	// � win-1251 to utf
			case chr(0xCB): $out .= chr(0xD0).chr(0x9B); break;	// � win-1251 to utf
			case chr(0xEB): $out .= chr(0xD0).chr(0xBB); break;	// � win-1251 to utf
			case chr(0xCC): $out .= chr(0xD0).chr(0x9C); break;	// � win-1251 to utf
			case chr(0xEC): $out .= chr(0xD0).chr(0xBC); break;	// � win-1251 to utf
			case chr(0xCD): $out .= chr(0xD0).chr(0x9D); break;	// � win-1251 to utf
			case chr(0xED): $out .= chr(0xD0).chr(0xBD); break;	// � win-1251 to utf
			case chr(0xCE): $out .= chr(0xD0).chr(0x9E); break;	// � win-1251 to utf
			case chr(0xEE): $out .= chr(0xD0).chr(0xBE); break;	// � win-1251 to utf
			case chr(0xCF): $out .= chr(0xD0).chr(0x9F); break;	// � win-1251 to utf
			case chr(0xEF): $out .= chr(0xD0).chr(0xBF); break;	// � win-1251 to utf
			case chr(0xD0): $out .= chr(0xD0).chr(0xA0); break;	// � win-1251 to utf
			case chr(0xF0): $out .= chr(0xD1).chr(0x80); break;	// � win-1251 to utf
			case chr(0xD1): $out .= chr(0xD0).chr(0xA1); break;	// � win-1251 to utf
			case chr(0xF1): $out .= chr(0xD1).chr(0x81); break;	// � win-1251 to utf
			case chr(0xD2): $out .= chr(0xD0).chr(0xA2); break;	// � win-1251 to utf
			case chr(0xF2): $out .= chr(0xD1).chr(0x82); break;	// � win-1251 to utf
			case chr(0xD3): $out .= chr(0xD0).chr(0xA3); break;	// � win-1251 to utf
			case chr(0xF3): $out .= chr(0xD1).chr(0x83); break;	// � win-1251 to utf
			case chr(0xD4): $out .= chr(0xD0).chr(0xA4); break;	// � win-1251 to utf
			case chr(0xF4): $out .= chr(0xD1).chr(0x84); break;	// � win-1251 to utf
			case chr(0xD5): $out .= chr(0xD0).chr(0xA5); break;	// � win-1251 to utf
			case chr(0xF5): $out .= chr(0xD1).chr(0x85); break;	// � win-1251 to utf
			case chr(0xD6): $out .= chr(0xD0).chr(0xA6); break;	// � win-1251 to utf
			case chr(0xF6): $out .= chr(0xD1).chr(0x86); break;	// � win-1251 to utf
			case chr(0xD7): $out .= chr(0xD0).chr(0xA7); break;	// � win-1251 to utf
			case chr(0xF7): $out .= chr(0xD1).chr(0x87); break;	// � win-1251 to utf
			case chr(0xD8): $out .= chr(0xD0).chr(0xA8); break;	// � win-1251 to utf
			case chr(0xF8): $out .= chr(0xD1).chr(0x88); break;	// � win-1251 to utf
			case chr(0xD9): $out .= chr(0xD0).chr(0xA9); break;	// � win-1251 to utf
			case chr(0xF9): $out .= chr(0xD1).chr(0x89); break;	// � win-1251 to utf
			case chr(0xDA): $out .= chr(0xD0).chr(0xAA); break;	// � win-1251 to utf
			case chr(0xFA): $out .= chr(0xD1).chr(0x8A); break;	// � win-1251 to utf
			case chr(0xDB): $out .= chr(0xD0).chr(0xAB); break;	// � win-1251 to utf
			case chr(0xFB): $out .= chr(0xD1).chr(0x8B); break;	// � win-1251 to utf
			case chr(0xDC): $out .= chr(0xD0).chr(0xAC); break;	// � win-1251 to utf
			case chr(0xFC): $out .= chr(0xD1).chr(0x8C); break;	// � win-1251 to utf
			case chr(0xDD): $out .= chr(0xD0).chr(0xAD); break;	// � win-1251 to utf
			case chr(0xFD): $out .= chr(0xD1).chr(0x8D); break;	// � win-1251 to utf
			case chr(0xDE): $out .= chr(0xD0).chr(0xAE); break;	// � win-1251 to utf
			case chr(0xFE): $out .= chr(0xD1).chr(0x8E); break;	// � win-1251 to utf
			case chr(0xDF): $out .= chr(0xD0).chr(0xAF); break;	// � win-1251 to utf
			case chr(0xFF): $out .= chr(0xD1).chr(0x8F); break;	// � win-1251 to utf
			default : $out .= $ch;								// skip
		}
	}
	return $out;	
}
?>