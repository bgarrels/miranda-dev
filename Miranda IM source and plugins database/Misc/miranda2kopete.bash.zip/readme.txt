ich benutze Kopete und habe ein script geschrieben, um die History Mirandas aufs Kopete-Format zu speichern.
um es zu benutzen, brauchst du das Plug-in "History++" zu Miranda hinzuzuf�gen, dann musst du *f�r jeden* Kontakten die History in einem Datei auf XML-Format speichern.
es ist nicht perfekt aber wirkt ausreichend.

wenn du unbedingt Pidgin benutzen willst, kannst du von diesem script starten, um ein neues zu entwickeln.