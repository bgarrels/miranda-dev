#! /bin/bash

MIRANDAFILE=""
ME="_me_not_set"
PROTOCOL="_protocol_not_set"
PROTDIR="_protdir_not_set"
CONTACT="_contact_not_set"
CONTACTID="_contact*ID*_not_set"
MYCONTACTID="_MYcontact*ID*_not_set"
IDs=("")
NEWLINEPLACEHOLDER="__NEW_LINE_PLACEHOLDER__"

## Kopete stuff:

function getProtDir
{
   case "$1" in
         "MSN") echo WlmProtocol
           ;;
       "SKYPE") echo SkypeProtocol
           ;;
       "YAHOO") echo YahooProtocol
           ;;
      "JABBER") echo JabberProtocol
           ;;
   esac
}

##  1. open Miranda IM History file
##  2. Understand PROTOCOL
##  3. Understand MYSELF contact id
##  4. Understand CONTACT contact id
##  5. Generate output file:
##     5.0 write_message_list_and_then_split_by_YEAR+MONTH
##     5.1 for each YEAH+MONTH:
##       5.1.1 write_header
##       5.1.2 while not read <EOFTAG> ; do write_event; done
##       5.1.3 write_footer

function write_header
{
   YEAR=$1
   MONTH=$2
   cat <<EOF
<!DOCTYPE Kopete-History>
<kopete-history version="0.9">
 <head>
  <date month="$MONTH" year="$YEAR"/>
  <contact contactId="$MYCONTACTID" type="myself"/>
  <contact contactId="$CONTACTID"/>
 </head>
EOF
}

function write_footer
{
  cat <<EOF
</kopete-history>
EOF

}

function die
{
   echo $* >&2
   exit 3
}

function check_input_file
{
   if (( $# < 1 )); then
      echo "wrong parameters!" >&2
      exit 1
   fi

   MIRANDAFILE="$1"

   ME=`cat "$MIRANDAFILE" | grep "<!ENTITY ME" | sed "s#<!ENTITY ME \"\(.*\)\">#\1#"`

   CONTACT=`sort -u "$MIRANDAFILE" | grep "<CONTACT>" | sed "s#[ \t]*<CONTACT>\(.*\)</CONTACT>[ \t]*#\1#"`
   [ "$CONTACT" ] || die INVALID_CONTACT

   PROTOCOLNUMBER=`sort -u "$MIRANDAFILE" | grep "<PROTOCOL>" | wc -l`
   if (( $PROTOCOLNUMBER != 1 )); then
      echo "check protocol(s) used in this history!">&2
      exit 2
   fi
   PROTOCOL=`sort -u "$MIRANDAFILE" | grep "<PROTOCOL>" | sed "s#[ \t]*<PROTOCOL>\(.*\)</PROTOCOL>[ \t]*#\1#"`
   [ $(getProtDir $PROTOCOL) ] || die INVALID_PROTOCOL $PROTOCOL
   
   PROTDIR=$(getProtDir $PROTOCOL)

   idnumber=0
   while read iddu; do
     IDs[idnumber]=$iddu
     ((idnumber++))
   done < <(sort -u "$MIRANDAFILE" | grep "<ID>.\{1,\}</ID>" | sed "s#[ \t]*<ID>\(.*\)</ID>[ \t]*#\1#")
   if (( $idnumber != 2 )); then
      echo "check ID(s) used in this history!">&2
      exit 2
   fi

}


function record_event #"$evtFrom" "$evtID" "$evtYear" "$evtMonth" "$evtDay" "$evtTime" "$evtType" "$evtProtocol" "$evtMessage"
{
#   xpectedParms=(evtFrom evtID evtYear evtMonth evtDay evtTime evtType evtProtocol evtMessage)
#   parms=($*)
#   
#   for (( i=0; i<${#xpectedParms[@]}-1; i++ )); do echo eval ${xpectedParms[$i]}="${parms[$i]}"; done
#
#   #the last one:
#   echo eval ${xpectedParms[$i]}="${parms[@]:$i}"

   if [ "$evtFrom" == "&ME;" ]; then
     evtFrom="$ME"
     msgIN=0
     if [ "$evtProtocol" == "SKYPE" ]; then
       #override INPUT ID in case of Skype
       evtID="Skype"
     fi
     MYCONTACTID="$evtID"
   else
     msgIN=1
     CONTACTID="$evtID"
   fi

   cat <<EOF
 <msg nick="$evtFrom" in="$msgIN" from="$evtID" time="$evtDay $evtTime">$evtMessage</msg>
EOF
}

function parse_history
{
   processing_event=0
   while read line; do
     case "$line" in 
        "<EVENT>")  # new event
                    (($processing_event)) && die NESTED_EVENTS
                    processing_event=1
                    
                    evtContact=""
                    evtFrom=""
                    evtTime=""
                    evtDate=""
                    evtProtocol=""
                    evtID=""
                    evtType=""
                    evtMessage=""
                    maybe_split=0
                            
                    ;;
       "</EVENT>")  # close event"
                    (($processing_event)) || die NO_EVENT_TO_CLOSE
                    record_event "$evtFrom" "$evtID" "$evtYear" "$evtMonth" "$evtDay" "$evtTime" "$evtType" "$evtProtocol" "$evtMessage" >> "$WORKDIR/$CONTACT.$evtYear.$evtMonth.tmpxml"
                    processing_event=0
                    maybe_split=0
                    ;;
                *)  # process tags
                    if (( $processing_event )) ; then
                     #read TAG CLOSE_TAG VALUE < <(echo "$line" | sed "s#[ \t]*<\(.*\)>\(.*\)</\(.*\)>[ \t]*#\1 \3 \2#")
                     VALUE=(`echo "$line" | sed "s#[ \t]*<\(.*\)>\(.*\)</\(.*\)>[ \t]*#\1 \3 \2#"`)
                     TAG=${VALUE[0]}
                     CLOSE_TAG=${VALUE[1]}
                     VALUE=${VALUE[@]:2}
                     if [ "$TAG" != "$CLOSE_TAG" ]; then
                       maybemessage=(`echo "$line" | sed "s#[ \t]*\(<MESSAGE>\)\(.*\)[ \t]*#\1 \2#"`)
                       if [ "${maybemessage[0]}" == "<MESSAGE>" ]; then # is it a message split in more lines?
                          maybe_split=1
                          #hack it...
                          TAG="MESSAGE"
                          VALUE=${maybemessage[@]:1}
                       else
                          (( maybe_split )) || die $TAG $CLOSE_TAG INVALID_TAG_PAIR
                       fi
                     fi

                     case "<$TAG>" in 
                       "<CONTACT>") # <CONTACT>Ju,tartinomane....!!!</CONTACT>
                                    evtContact="$VALUE"
                                    ;;
                          "<FROM>") #<FROM>&ME;</FROM>
                                    evtFrom="$VALUE"
                                    ;;
                          "<TIME>") #<TIME>19:54:58</TIME>
                                    evtTime="$VALUE"
                                    ;;
                          "<DATE>") # <DATE>2008-05-23</DATE>
                                    evtDate=(${VALUE//-/ })
                                    evtYear=${evtDate[0]}
                                    evtMonth=${evtDate[1]}
                                    evtDay=${evtDate[2]}
                                    ;;
                      "<PROTOCOL>") #<PROTOCOL>MSN</PROTOCOL>
                                    evtProtocol="$VALUE"
#                                   if [ "$evtProtocol" != "$PROTOCOL" ]; then
#                                     it should never come here, because of all the checks in check_input_file
#                                     die INVALID_PROTOCOL
#                                   fi
                                    ;;
                            "<ID>") #<ID>whatifgodwasoneofus@hotmail.com</ID>
                                    evtID="$VALUE"
                                    ;;
                          "<TYPE>") #<TYPE>&MSG;</TYPE>
                                    evtType="$VALUE"
                                    ;;
                       "<MESSAGE>") # <MESSAGE>ciao, sono cristiano :)</MESSAGE>
                                    evtMessage="$VALUE"
                                    ;;
                                 *) if ((maybe_split)); then
                                      maybeline=(`echo "$line" | sed "s#\(.*\)\(</MESSAGE>\)[ \t]*#\2 \1#"`)
                                      if [ "${maybeline[0]}" == "</MESSAGE>" ] ; then 
                                        # it's the end of multi-line message
                                        # and we already have a message
                                        evtMessage="$evtMessage${NEWLINEPLACEHOLDER}${maybeline[@]:1}"
                                        maybe_split=0
                                      else
                                        # continue grabbing the multi-line message
                                        evtMessage="$evtMessage${NEWLINEPLACEHOLDER}$line"
                                      fi
                                    else
                                       #echo "Warning: UNEXPECTED_TAG $TAG - pushing in as message" >&2
                                       evtMessage="$evtMessage${NEWLINEPLACEHOLDER}[$TAG: $VALUE]"
                                    fi
                                    ;;
                     esac
                    fi
                    ;;
     esac
   done < <(cat "$MIRANDAFILE")
}

function split_history
{
  if [ $PROTOCOL == "SKYPE" ]; then
    mycid="Skype"
  else
    mycid=${MYCONTACTID//./-}
  fi
  TARGETDIR="$PROTDIR/$mycid"
  [ -d "$TARGETDIR" ] || mkdir -p "$TARGETDIR"

  cid=${CONTACTID//./-}

  for file in "$WORKDIR"/* ; do
    fname=$(basename "$file")
    val=(`echo "$fname" | sed "s/.*\.\([0-9]\{4,4\}\)\.\([0-1][0-9]\)\.tmpxml$/\1 \2/"`)
    year=${val[0]}
    month=${val[1]}
    TARGETFILE="$TARGETDIR/${cid}.${year}${month}.xml"
               
    [ -f "$TARGETFILE" ] && die $TARGETFILE FILE_EXIST

    write_header $year $month > "$TARGETFILE"
    cat "$file" | sort -t \" -k 8,9 | sed "s/${NEWLINEPLACEHOLDER}/\n/g" >>"$TARGETFILE"
    write_footer >>"$TARGETFILE"
  done
}

## main:

check_input_file "$@"
                 
WORKDIR="work/$PROTDIR/$CONTACT"
if [ -d "$WORKDIR" ]; then
  rm -rf "$WORKDIR"/*
else
  mkdir -p "$WORKDIR"
fi

[ -d "$WORKDIR" ] || die CANNOT_CREATE_TMPFOLDER

parse_history

split_history

DONEDIR="done"
        
[ -d "$DONEDIR" ] || mkdir -p "$DONEDIR"
[ -d "$DONEDIR" ] || mkdir -p "$DONEDIR"
                              
mv "$MIRANDAFILE" "$DONEDIR"
