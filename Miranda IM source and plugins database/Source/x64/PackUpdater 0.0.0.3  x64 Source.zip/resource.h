//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDI_MENU                        101
#define IDD_UPDATE                      102
#define IDD_DOWNLOAD                    103
#define IDD_DIALOG1                     104
#define IDD_OPT_UPDATENOTIFY            104
#define IDC_UPDATETEXT                  1001
#define IDC_CURVER                      1002
#define IDC_NEWVER                      1003
#define IDINFO                          1004
#define IDC_PB                          1005
#define IDC_LABEL                       1006
#define IDC_ENABLEUPDATES               1700
#define IDC_ENABLEALPHA                 1701


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
