// ZeroUpdate.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "resource.h"
#include <deque>
#include "Wininet.h"
#include "Urlmon.h"
#include <prsht.h>
#include <string>

#define PBM_MARQUEE		8
#define	PBM_SETMARQUEE	WM_USER + 10

using std::deque;
using std::string;

struct FILEURL
{
	char szDownloadURL[2048];
	char szDiskPath[MAX_PATH];
};

struct FILEINFO
{
	char szCurVer[16];
	char szNewVer[16];
	char szLastVer[16];
	char szInfoURL[2048];
	char szMessage[5000];
	//char szPath[MAX_PATH];
	bool bRun;
	FILEURL Version;
	FILEURL File;
};


HINSTANCE hInst;
PLUGINLINK *pluginLink;
PLUGININFO pluginInfo={
	sizeof(PLUGININFO),
	"ZeroUpdate",
	PLUGIN_MAKE_VERSION(0,0,0,3),
	"Simple updater for Miranda IM premodified packs",
	"ZERO_BiT, Mataes",
	"zero-bit@mail.ru, mataes2007@gmail.com",
	"� 2007 ZERO_BiT, 2010 Mataes",
	"http://mataes.googlecode.com/svn/Miranda/Plugins/ZeroUpdate/",
	0,		//not transient
	0//,		//doesn't replace anything built-in
    //{ 0x29517be5, 0x779a, 0x48e5, { 0x89, 0x50, 0xcb, 0x4d, 0xe1, 0xd4, 0x31, 0x72 } } //{29517BE5-779A-48e5-8950-CB4DE1D43172}
};
deque<FILEINFO> Files;
int FileCount = 0;
bool AutoUpdate = false;
char szIni[MAX_PATH];
char szRoot[MAX_PATH];
//char szUpdateDir[MAX_PATH];
char szDialogMsg[2048];
FILEINFO* pFileInfo = NULL;
FILEURL* pFileUrl = NULL;
HANDLE hOptHook = NULL;
HANDLE hLoadHook = NULL;
HANDLE hPackUpdaterFolder = NULL;


BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved);
int MenuCommand(WPARAM wParam,LPARAM lParam);
bool Init();
void CheckUpdates(bool bSilent = true);
bool DownloadFile(LPSTR szURL, LPSTR szLocal);
DWORD WINAPI ThreadProc(LPVOID lpParameter);
INT_PTR CALLBACK DlgUpdate(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK DlgDownload(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
static int OptInit(WPARAM wParam, LPARAM lParam);
static int ModulesLoaded(WPARAM wParam, LPARAM lParam);
static BOOL CALLBACK UpdateNotifyOptsProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
extern "C" __declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion);
extern "C" __declspec(dllexport) int Load(PLUGINLINK *link);
extern "C" __declspec(dllexport) int Unload(void);

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst=hinstDLL;
	return TRUE;
}


extern "C" __declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	return &pluginInfo;
}

int __declspec(dllexport) Load(PLUGINLINK *link)
{
	CLISTMENUITEM mi;
	pluginLink=link;
	if (ServiceExists(MS_FOLDERS_REGISTER_PATH))
	{
		hPackUpdaterFolder = FoldersRegisterCustomPathT(MODULE, "Pack Updater", MIRANDA_PATH"\\"DEFAULT_UPDATES_FOLDER);
	}
	if (!Init())
		return 0;
	// Add menu item
	CreateServiceFunction("ZeroUpdate/CheckUpdates",MenuCommand);
	ZeroMemory(&mi,sizeof(mi));
	mi.cbSize=sizeof(mi);
	mi.position=-0x7FFFFFFF;
	mi.flags=0;
	mi.hIcon=LoadIcon(hInst, MAKEINTRESOURCE(IDI_MENU));
	mi.pszName = Translate("Check for pack updates");
	mi.pszService="ZeroUpdate/CheckUpdates";
	CallService(MS_CLIST_ADDMAINMENUITEM,0,(LPARAM)&mi);

	// Add options hook
	hOptHook = HookEvent(ME_OPT_INITIALISE, OptInit);
	hLoadHook = HookEvent(ME_SYSTEM_MODULESLOADED, ModulesLoaded);
	
	return 0;
}

extern "C" __declspec(dllexport) int Unload(void)
{
	return 0;
}

bool Init()
{
	char szBuff[2048];
	DWORD ret = 0;

	mir_sntprintf(szIni, MAX_PATH, _T("%s"), Utils_ReplaceVarsT(_T("%miranda_path%\\Plugins\\ZeroUpdate.ini")));
	CallService(MS_UTILS_PATHTOABSOLUTET, (WPARAM)szIni, (LPARAM)szIni);

	if (ServiceExists(MS_FOLDERS_GET_PATH))
	{
		FoldersGetCustomPathT(hPackUpdaterFolder, szRoot, MAX_PATH, "");
	}
	else
	{
	mir_sntprintf(szRoot, MAX_PATH, _T("%s"), Utils_ReplaceVarsT(_T("%miranda_path%\\"DEFAULT_UPDATES_FOLDER)));
	CallService(MS_UTILS_PATHTOABSOLUTET, (WPARAM)szRoot, (LPARAM)szRoot);
	}
	ret = GetPrivateProfileString("Settings", "FileCount", "", szBuff, 2048, szIni);
	if (!ret) // It seems there's no ini file...
		return false;
	FileCount = atoi(szBuff);
	GetPrivateProfileString("Settings", "AutoUpdate", "", szBuff, 2048, szIni);
	AutoUpdate = (bool)atoi(szBuff);
	return true;
}

int MenuCommand(WPARAM wParam,LPARAM lParam)
{
	CheckUpdates(false);
	return 0;
}

void CheckUpdates(bool bSilent)
{
	char szBuff[10240], szTemp[MAX_PATH], tmp[5];
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	int UpdatesCount = 0;

	Files.clear();
	if (ServiceExists(MS_FOLDERS_GET_PATH))
	{
		FoldersGetCustomPathT(hPackUpdaterFolder, szRoot, MAX_PATH, "");
	}
	else
	{
		mir_sntprintf(szRoot, MAX_PATH, _T("%s"), Utils_ReplaceVarsT(_T("%miranda_path%\\"DEFAULT_UPDATES_FOLDER)));
		CallService(MS_UTILS_PATHTOABSOLUTET, (WPARAM)szRoot, (LPARAM)szRoot);
	}

	GetPrivateProfileString("Settings", "FileCount", "", szBuff, 2048, szIni);
	FileCount = atoi(szBuff);
	CreateDirectory(szRoot, NULL);

	// Load files info
	for (int i = 0; i < FileCount; i++)
	{
		FILEINFO FileInfo = {"", "", "", "", "", false, {"", ""}, {"", ""}};

		strcpy(szBuff, "File ");
		itoa(i + 1, tmp, 10);
		strcat(szBuff, tmp);
		GetPrivateProfileString(szBuff, "VersionURL", "", FileInfo.Version.szDownloadURL, 2048, szIni);
		if (!strcmp(FileInfo.Version.szDownloadURL, "")) // URL is not set
			continue;
		GetPrivateProfileString(szBuff, "CurrentVersion", "", FileInfo.szCurVer, 16, szIni);
		GetPrivateProfileString(szBuff, "LastVersion", "", FileInfo.szLastVer, 16, szIni);
		strcpy(FileInfo.Version.szDiskPath, szRoot);
		strcat(FileInfo.Version.szDiskPath, "\\tmp.ini");
		Files.push_back(FileInfo);
	}

	if (!FileCount)
		if (!bSilent)
			MessageBox(NULL, Translate("No updates found."), Translate("Pack Updater"), MB_ICONINFORMATION);
	//MessageBox(NULL, "Enumerating files", "", 0);
	for (int i = 0; i < FileCount; i++)
	{
		// Download version info
		pFileUrl = &Files[i].Version;
		strcpy(szDialogMsg, Translate("Downloading version info..."));
		if (!DialogBox(hInst, MAKEINTRESOURCE(IDD_DOWNLOAD), NULL, DlgDownload))
			continue;

		// Read version info
		GetPrivateProfileString("FileInfo", "FileVersion", "", Files[i].szNewVer, 16, Files[i].Version.szDiskPath);
		GetPrivateProfileString("FileInfo", "Message", "", Files[i].szMessage, 5000, Files[i].Version.szDiskPath);
		GetPrivateProfileString("FileInfo", "DownloadURL", "", Files[i].File.szDownloadURL, 2048, Files[i].Version.szDiskPath);
		GetPrivateProfileString("FileInfo", "DiskFileName", "", szBuff, MAX_PATH, Files[i].Version.szDiskPath);

		if (strstr(szBuff, "\\"))
		{
			MessageBox(NULL, Translate("Name of Update's file is not supported."), Translate("Pack Updater"), MB_ICONINFORMATION);
			break;
		}
		CreateDirectory(szRoot, NULL);
		strcpy(Files[i].File.szDiskPath, szRoot);
		strcat(Files[i].File.szDiskPath, "\\");
		strcat(Files[i].File.szDiskPath, szBuff);
		GetPrivateProfileString("FileInfo", "RunFile", "1", szBuff, MAX_PATH, Files[i].Version.szDiskPath);
		Files[i].bRun = (bool)atoi(szBuff);
		GetPrivateProfileString("FileInfo", "InfoURL", "", Files[i].szInfoURL, 2048, Files[i].Version.szDiskPath);
		DeleteFile(Files[i].Version.szDiskPath);

		// Compare versions
		if ((strcmp(Files[i].szCurVer, Files[i].szNewVer))<0) // Yeah, we've got new version.
		{
			// Did we see this one before and are we in silent mode?
			if (!strcmp(Files[i].szLastVer, Files[i].szNewVer) && bSilent)
				continue;

			UpdatesCount++;
			// Save last version
			strcpy(Files[i].szLastVer, Files[i].szNewVer);
			strcpy(szBuff, "File ");
			itoa(i + 1, szTemp, 10);
			strcat(szBuff, szTemp);
			WritePrivateProfileString(szBuff, "LastVersion", Files[i].szLastVer, szIni);
			// Show dialog
			pFileInfo = &Files[i];
			if (IDOK == DialogBox(hInst, MAKEINTRESOURCE(IDD_UPDATE), NULL, DlgUpdate))
			{
				// download update
				strcpy(szDialogMsg, Translate("Downloading pack updates..."));
				pFileUrl = &Files[i].File;
				if (DialogBox(hInst, MAKEINTRESOURCE(IDD_DOWNLOAD), NULL, DlgDownload))
				{
					strcpy(Files[i].szCurVer, Files[i].szNewVer);
					WritePrivateProfileString(szBuff, "CurrentVersion", Files[i].szCurVer, szIni);
					if (Files[i].bRun)
					{
						if (IDYES == MessageBox(NULL, Translate("Download complete. Start updating? All your data will be saved and Miranda IM will be closed."), Translate("Pack Updater"), MB_YESNO | MB_ICONQUESTION))
						{
							memset(&si, 0, sizeof(STARTUPINFO));
							memset(&pi, 0, sizeof(PROCESS_INFORMATION));
							si.cb = sizeof(STARTUPINFO);
							CreateProcess(Files[i].File.szDiskPath, "", NULL, NULL, FALSE, NULL, NULL, NULL, &si, &pi);
							//if (bSilent)
							//	ExitProcess(0); // Close the hard way
							//else
								CallService("CloseAction", 0, 0);
						}
						else
						{
							strcpy(szBuff, Translate("You have chosen not to install the update immediately.\nYou can install it manually from this location:\n\n"));
							strcat(szBuff, Files[i].File.szDiskPath);
							MessageBox(NULL, szBuff, Translate("Pack Updater"), MB_ICONINFORMATION);
						}
					}
				}
			}
		}
	}
	if (!UpdatesCount)
		if (!bSilent)
			MessageBox(NULL, Translate("No updates found."), Translate("Pack Updater"), MB_ICONINFORMATION);
}


INT_PTR CALLBACK DlgUpdate(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	char szBuff[1024];

	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		SetWindowText(hDlg, Translate("Update found!"));
		SetWindowText(GetDlgItem(hDlg, IDC_UPDATETEXT), Translate(pFileInfo->szMessage));
		strcpy(szBuff, Translate("Current version:"));
		strcat(szBuff, " ");
		strcat(szBuff, pFileInfo->szCurVer);
		SetWindowText(GetDlgItem(hDlg, IDC_CURVER), szBuff);
		strcpy(szBuff, Translate("New version:"));
		strcat(szBuff, " ");
		strcat(szBuff, pFileInfo->szNewVer);
		SetWindowText(GetDlgItem(hDlg, IDC_NEWVER), szBuff);
		SetWindowText(GetDlgItem(hDlg, IDOK), Translate("Download update"));
		SetWindowText(GetDlgItem(hDlg, IDINFO), Translate("View info"));
		SetWindowText(GetDlgItem(hDlg, IDCANCEL), Translate("Cancel"));
		if (!strcmp(pFileInfo->szInfoURL, ""))
			ShowWindow(GetDlgItem(hDlg, IDINFO), SW_HIDE);
		return (INT_PTR)TRUE;
	case WM_CREATE:
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hDlg, IDCANCEL);
			break;
		case IDOK:
			EndDialog(hDlg, IDOK);
			break;
		case IDINFO:
			CallService(MS_UTILS_OPENURL, TRUE, (LPARAM)pFileInfo->szInfoURL);
			break;
		}
		return (INT_PTR)TRUE;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK DlgDownload(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		SetWindowText(GetDlgItem(hDlg, IDC_LABEL), szDialogMsg);
		SetWindowLong(GetDlgItem(hDlg, IDC_PB), GWL_STYLE, GetWindowLong(GetDlgItem(hDlg, IDC_PB), GWL_STYLE) | PBM_MARQUEE);
		SendMessage(GetDlgItem(hDlg, IDC_PB), PBM_SETMARQUEE, 1, 50);
		CreateThread(NULL, NULL, ThreadProc, (LPVOID)hDlg, NULL, NULL);
		return (INT_PTR)TRUE;
	}
	return (INT_PTR)FALSE;
}

static BOOL CALLBACK UpdateNotifyOptsProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	char buff[10];

	switch (msg) 
	{
	case WM_INITDIALOG:
		TranslateDialogDefault(hwndDlg);
		CheckDlgButton(hwndDlg, IDC_ENABLEUPDATES, (int)AutoUpdate);
		return TRUE;
	case WM_COMMAND:
		switch (LOWORD(wParam)) 
		{
		case IDC_ENABLEUPDATES:
			SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);
			break;
		}
		break;

	case WM_NOTIFY:
		{
			NMHDR *hdr = (NMHDR *)lParam;
			if (hdr&&hdr->code==PSN_APPLY) 
			{
				AutoUpdate = (bool)IsDlgButtonChecked(hwndDlg, IDC_ENABLEUPDATES);
				itoa((int)AutoUpdate, buff, 10);
				WritePrivateProfileString("Settings", "AutoUpdate", buff, szIni);
			}
			break;
		}
	}
	return FALSE;
}


DWORD WINAPI ThreadProc(LPVOID lpParameter)
{
	if (!DownloadFile(pFileUrl->szDownloadURL, pFileUrl->szDiskPath))
	{
		MessageBox(NULL, Translate("An error occured while downloading the update"), Translate("Pack Updater"), MB_ICONSTOP);
		EndDialog((HWND)lpParameter, 0);
	}
	EndDialog((HWND)lpParameter, 1);
	return 0;
}

static int OptInit(WPARAM wParam, LPARAM lParam)
{
 	OPTIONSDIALOGPAGE odp;

	ZeroMemory(&odp, sizeof(odp));
    odp.cbSize = sizeof(odp);
    odp.position = 100000000;
    odp.hInstance = hInst;
    odp.pszTemplate = MAKEINTRESOURCEA(IDD_OPT_UPDATENOTIFY);
    odp.pszGroup = "Events";
    odp.pszTitle = "Pack Updater";
    odp.pfnDlgProc = UpdateNotifyOptsProc;
    odp.flags = ODPF_BOLDGROUPS;
    CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);
    return 0;


}

bool DownloadFile(LPSTR szURL, LPSTR szLocal)
{
	HINTERNET hInet = NULL, hUrl = NULL;
	HANDLE hFile = NULL;
	char buff[2048];
	DWORD dwBytes;
	bool ret = false;

	hInet = InternetOpen("Zero Update", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, NULL);
	if (!hInet)
		goto cleanup;
	hUrl = InternetOpenUrl(hInet, szURL, NULL, NULL, INTERNET_FLAG_RELOAD, NULL);
	if (!hUrl)
		goto cleanup;
	hFile = CreateFile(szLocal, GENERIC_READ | GENERIC_WRITE, NULL, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (!hFile)
		goto cleanup;
	do
	{
		if (!InternetReadFile(hUrl, buff, 2048, &dwBytes))
			goto cleanup;
		if (!WriteFile(hFile, buff, dwBytes, &dwBytes, NULL))
			goto cleanup;
	} while (dwBytes >= 2048);
	ret = true;

cleanup:
		if (hInet)
			InternetCloseHandle(hInet);
		if (hUrl)
			InternetCloseHandle(hUrl);
		if (hFile)
			CloseHandle(hFile);
		return ret;
}

static int ModulesLoaded(WPARAM wParam, LPARAM lParam)
{
	if (AutoUpdate)
		CheckUpdates();
	return 0;
}