#ifndef _SERVICES_INC
#define _SERVICES_INC

void InitServices();
void DeinitServices();

extern int num_classes;
extern POPUPCLASS *classes;

#endif
