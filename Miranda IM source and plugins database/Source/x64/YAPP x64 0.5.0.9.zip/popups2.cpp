// popups2.cpp : Defines the entry point for the DLL application.
//

#include "common.h"
#include "popups2.h"
#include "version.h"
#include "message_pump.h"
#include "options.h"
#include "popwin.h"
#include "notify.h"

HMODULE hInst = 0;
HANDLE mainThread = 0;

MNOTIFYLINK *notifyLink = 0;

int code_page = CP_ACP;

// used to work around a bug in neweventnotify and others with the address passed in the GetPluginData function
bool ignore_gpd_passed_addy = false;

FontIDW font_id_firstline = {0}, font_id_secondline = {0}, font_id_time = {0};
ColourIDW colour_id_bg = {0}, colour_id_border = {0}, colour_id_sidebar = {0};
COLORREF colBg = GetSysColor(COLOR_3DSHADOW);
HFONT hFontFirstLine = 0, hFontSecondLine = 0, hFontTime = 0;
COLORREF colFirstLine = RGB(255, 0, 0), colSecondLine = 0, colTime = RGB(0, 0, 255), colBorder = RGB(0, 0, 0), colSidebar = RGB(128, 128, 128);


// hooked here so it's in the main thread
HANDLE hAvChangeEvent = 0;

PLUGININFO pluginInfo={
	sizeof(PLUGININFO),
	__PLUGIN_NAME,
	PLUGIN_MAKE_VERSION(__MAJOR_VERSION, __MINOR_VERSION, __RELEASE_NUM, __BUILD_NUM),
	__DESC,
	__AUTHOR,
	__AUTHOREMAIL,
	__COPYRIGHT,
	__AUTHORWEB,
	0,		//not transient
	0		//doesn't replace anything built-in
};

PLUGINLINK *pluginLink = 0;

extern "C" BOOL APIENTRY DllMain( HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	hInst = hModule;
	//DisableThreadLibraryCalls(hInst);
    return TRUE;
}

extern "C" POPUPS2_API PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	return &pluginInfo;
}

int ReloadFont(WPARAM wParam, LPARAM lParam) {
	LOGFONT log_font;

	if(hFontFirstLine) DeleteObject(hFontFirstLine);
	colFirstLine = CallService(MS_FONT_GETW, (WPARAM)&font_id_firstline, (LPARAM)&log_font);
	hFontFirstLine = CreateFontIndirect(&log_font);
	if(hFontSecondLine) DeleteObject(hFontSecondLine);
	colSecondLine = CallService(MS_FONT_GETW, (WPARAM)&font_id_secondline, (LPARAM)&log_font);
	hFontSecondLine = CreateFontIndirect(&log_font);
	if(hFontTime) DeleteObject(hFontTime);
	colTime = CallService(MS_FONT_GETW, (WPARAM)&font_id_time, (LPARAM)&log_font);
	hFontTime = CreateFontIndirect(&log_font);

	colBg = CallService(MS_COLOUR_GETW, (WPARAM)&colour_id_bg, 0);
	colBorder = CallService(MS_COLOUR_GETW, (WPARAM)&colour_id_border, 0);
	colSidebar = CallService(MS_COLOUR_GETW, (WPARAM)&colour_id_sidebar, 0);

	return 0;
}

HANDLE hEventReloadFont = 0;

int ModulesLoaded(WPARAM wParam, LPARAM lParam) {
	MNotifyGetLink();

	if(ServiceExists(MS_UPDATE_REGISTER)) {
		// register with updater
		Update update = {0};
		char szVersion[16];

		update.cbSize = sizeof(Update);

		update.szComponentName = pluginInfo.shortName;
		update.pbVersion = (BYTE *)CreateVersionString(pluginInfo.version, szVersion);
		update.cpbVersion = strlen((char *)update.pbVersion);

		update.szUpdateURL = UPDATER_AUTOREGISTER;
		
		// these are the three lines that matter - the archive, the page containing the version string, and the text (or data) 
		// before the version that we use to locate it on the page
		// (note that if the update URL and the version URL point to standard file listing entries, the backend xml
		// data will be used to check for updates rather than the actual web page - this is not true for beta urls)
		update.szBetaUpdateURL = "http://www.scottellis.com.au/miranda_plugins/yapp.zip";
		update.szBetaVersionURL = "http://www.scottellis.com.au/miranda_plugins/ver_yapp.html";
		update.pbBetaVersionPrefix = (BYTE *)"YAPP version ";
		
		update.cpbBetaVersionPrefix = strlen((char *)update.pbBetaVersionPrefix);

		CallService(MS_UPDATE_REGISTER, 0, (WPARAM)&update);
	}

	if(ServiceExists(MS_FONT_REGISTERW)) {
		font_id_firstline.cbSize = sizeof(FontIDW);
		font_id_firstline.flags = FIDF_ALLOWEFFECTS;
		wcscpy(font_id_firstline.group, TranslateT("Popups"));
		wcscpy(font_id_firstline.name, TranslateT("First Line"));
		strcpy(font_id_firstline.dbSettingsGroup, MODULE);
		strcpy(font_id_firstline.prefix, "FontFirst");
		font_id_firstline.order = 0;

		font_id_secondline.cbSize = sizeof(FontIDW);
		font_id_secondline.flags = FIDF_ALLOWEFFECTS;
		wcscpy(font_id_secondline.group, TranslateT("Popups"));
		wcscpy(font_id_secondline.name, TranslateT("Second Line"));
		strcpy(font_id_secondline.dbSettingsGroup, MODULE);
		strcpy(font_id_secondline.prefix, "FontSecond");
		font_id_secondline.order = 1;

		font_id_time.cbSize = sizeof(FontIDW);
		font_id_time.flags = FIDF_ALLOWEFFECTS;
		wcscpy(font_id_time.group, TranslateT("Popups"));
		wcscpy(font_id_time.name, TranslateT("Time"));
		strcpy(font_id_time.dbSettingsGroup, MODULE);
		strcpy(font_id_time.prefix, "FontTime");
		font_id_time.order = 2;

		CallService(MS_FONT_REGISTERW, (WPARAM)&font_id_firstline, 0);
		CallService(MS_FONT_REGISTERW, (WPARAM)&font_id_secondline, 0);
		CallService(MS_FONT_REGISTERW, (WPARAM)&font_id_time, 0);
		
		colour_id_bg.cbSize = sizeof(ColourIDW);
		wcscpy(colour_id_bg.group, TranslateT("Popups"));
		wcscpy(colour_id_bg.name, TranslateT("Background"));
		strcpy(colour_id_bg.dbSettingsGroup, MODULE);
		strcpy(colour_id_bg.setting, "ColourBg");
		colour_id_bg.defcolour = GetSysColor(COLOR_3DSHADOW);
		colour_id_bg.order = 0;

		colour_id_border.cbSize = sizeof(ColourIDW);
		wcscpy(colour_id_border.group, TranslateT("Popups"));
		wcscpy(colour_id_border.name, TranslateT("Border"));
		strcpy(colour_id_border.dbSettingsGroup, MODULE);
		strcpy(colour_id_border.setting, "ColourBorder");
		colour_id_border.defcolour = RGB(0, 0, 0);
		colour_id_border.order = 1;

		colour_id_sidebar.cbSize = sizeof(ColourIDW);
		wcscpy(colour_id_sidebar.group, TranslateT("Popups"));
		wcscpy(colour_id_sidebar.name, TranslateT("Sidebar"));
		strcpy(colour_id_sidebar.dbSettingsGroup, MODULE);
		strcpy(colour_id_sidebar.setting, "ColourSidebar");
		colour_id_sidebar.defcolour = RGB(128, 128, 128);
		colour_id_sidebar.order = 2;

		CallService(MS_COLOUR_REGISTERW, (WPARAM)&colour_id_bg, 0);
		CallService(MS_COLOUR_REGISTERW, (WPARAM)&colour_id_border, 0);
		CallService(MS_COLOUR_REGISTERW, (WPARAM)&colour_id_sidebar, 0);
		
		ReloadFont(0, 0);

		hEventReloadFont = HookEvent(ME_FONT_RELOAD, ReloadFont);
	} else {
		LOGFONT lf = {0};
		lf.lfCharSet = DEFAULT_CHARSET;
		lf.lfHeight = -14;
		lf.lfWeight = FW_BOLD;
		hFontFirstLine = CreateFontIndirect(&lf);

		lf.lfHeight = -12;
		lf.lfWeight = 0;
		hFontSecondLine = CreateFontIndirect(&lf);

		lf.lfHeight = -8;
		lf.lfWeight = 0;
		hFontTime = CreateFontIndirect(&lf);
	}
	
	hAvChangeEvent = HookEvent(ME_AV_AVATARCHANGED, AvatarChanged);

	LoadModuleDependentOptions(); 

	if(GetModuleHandle(_T("neweventnotify")))
	{
		ignore_gpd_passed_addy = true;
	}

	return 0;
}

int PreShutdown(WPARAM wParam, LPARAM lParam) {
	if(hAvChangeEvent) UnhookEvent(hAvChangeEvent);
	DeinitMessagePump();
	return 0;
}

HANDLE hEventPreShutdown, hEventModulesLoaded;

extern "C" int POPUPS2_API Load(PLUGINLINK *link) {
	pluginLink = link;
	DuplicateHandle(GetCurrentProcess(), GetCurrentThread(), GetCurrentProcess(), &mainThread, THREAD_SET_CONTEXT, FALSE, 0);

	INITCOMMONCONTROLSEX icex;

	// Ensure that the common control DLL is loaded (for listview)
	icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	icex.dwICC  = ICC_LISTVIEW_CLASSES;
	InitCommonControlsEx(&icex); 	

	InitMessagePump();
	InitOptions();
	InitNotify();

	hEventPreShutdown = HookEvent(ME_SYSTEM_PRESHUTDOWN, PreShutdown);
	hEventModulesLoaded = HookEvent(ME_SYSTEM_MODULESLOADED, ModulesLoaded);

	return 0;
}

extern "C" int POPUPS2_API Unload() {
	if(hEventReloadFont) UnhookEvent(hEventReloadFont);
	UnhookEvent(hEventPreShutdown);
	UnhookEvent(hEventModulesLoaded);
	DeinitNotify();
	if(ServiceExists(MS_FONT_REGISTERW)) {
		DeleteObject(hFontFirstLine);
		DeleteObject(hFontSecondLine);
		DeleteObject(hFontTime);
	} // otherwise, no need to delete the handle
	return 0;
}
