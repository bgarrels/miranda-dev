//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by tipper.rc
//
#define IDD_OPT_LAYOUT                  101
#define IDD_OPT_CONTENT                 102
#define IDD_SUBST                       103
#define IDD_ITEM                        104
#define IDD_OPT2                        105
#define IDD_OPT_WINDOW                  106
#define IDC_ED_WIDTH                    1005
#define IDC_ED_MAXHEIGHT                1006
#define IDC_SPIN_WIDTH                  1007
#define IDC_SPIN_MAXHEIGHT              1008
#define IDC_ED_INDENT                   1009
#define IDC_SPIN_INDENT                 1010
#define IDC_ED_PADDING                  1011
#define IDC_SPIN_PADDING                1012
#define IDC_ED_TRANS                    1013
#define IDC_SPIN_TRANS                  1014
#define IDC_CHK_BORDER                  1015
#define IDC_CHK_ROUNDCORNERS            1016
#define IDC_ED_MINWIDTH                 1017
#define IDC_CHK_ANIMATE                 1018
#define IDC_CHK_TRANSBG                 1019
#define IDC_CHK_SHADOW                  1020
#define IDC_SPIN_MINWIDTH               1021
#define IDC_ED_MINHEIGHT                1022
#define IDC_SPIN_MINHEIGHT              1023
#define IDC_ED_SBWIDTH                  1024
#define IDC_SPIN_SBWIDTH                1025
#define IDC_ED_TEXTPADDING              1026
#define IDC_ED_AVSIZE                   1027
#define IDC_SPIN_AVSIZE                 1028
#define IDC_ED_HOVER                    1029
#define IDC_SPIN_HOVER                  1030
#define IDC_SPIN_TEXTPADDING            1031
#define IDC_CMB_ICON                    1032
#define IDC_CMB_AV                      1033
#define IDC_CMB_AV2                     1034
#define IDC_CMB_ICON2                   1034
#define IDC_CMB_POS                     1034
#define IDC_LST_ITEMS                   1035
#define IDC_ED_AVPADDING                1035
#define IDC_BTN_ADD                     1036
#define IDC_SPIN_AVPADDING              1036
#define IDC_BTN_REMOVE                  1037
#define IDC_CHK_ROUNDCORNERS2           1037
#define IDC_CHK_ROUNDCORNERSAV          1037
#define IDC_BTN_UP                      1038
#define IDC_BTN_DOWN                    1039
#define IDC_CHK_NOFOCUS                 1040
#define IDC_BTN_EDIT                    1041
#define IDC_CHK_NOFOCUS2                1041
#define IDC_CHK_NORESIZEAV              1041
#define IDC_LST_SUBST                   1042
#define IDC_BTN_ADD2                    1043
#define IDC_ED_MODULE                   1044
#define IDC_BTN_REMOVE2                 1044
#define IDC_CHK_PROTOMOD                1045
#define IDC_BTN_UP2                     1045
#define IDC_CHK_RIGHTLABEL              1045
#define IDC_ED_SETTING                  1046
#define IDC_CMB_TRANSLATE               1047
#define IDC_BTN_EDIT2                   1047
#define IDC_ED_LABEL                    1048
#define IDC_CHK_STATUSMSG               1048
#define IDC_CHK_SBAR                    1048
#define IDC_CHK_LASTMSG                 1049
#define IDC_ED_VALUE                    1050
#define IDC_CHK_LINEABOVE               1051
#define IDC_CHK_VALNEWLINE              1052
#define IDC_CUSTOM1                     1052
#define IDC_BORDERCOLOUR                1052
#define IDC_CMB_LV                      1053
#define IDC_CMB_VV                      1054
#define IDC_CMB_LH                      1055
#define IDC_CMB_VH                      1056
#define IDC_ED_BGFN                     1057
#define IDC_BTN_BROWSE                  1058
#define IDC_CHECK1                      1059
#define IDC_CHK_STRETCHBG               1059

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
