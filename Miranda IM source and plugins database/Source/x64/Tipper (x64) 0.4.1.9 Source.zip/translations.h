#ifndef _TRANSLATIONS_INC
#define _TRANSLATIONS_INC

#include "m_tipper.h"

extern int num_tfuncs;
extern DBVTranslation *translations;

void InitTranslations();
void DeinitTranslations();

#endif
