#ifndef __popup_history_h__
#define __popup_history_h__

#define HISTORY_SIZE 200 //number of popup history items

#define PHDF_UNICODE 1 

struct PopupHistoryData{
	DWORD flags; //PHDF_* flags
	union{
		char *message;
		wchar_t *messageW;
	};
	union{
		char *title;
		wchar_t *titleW;
	};
	time_t timestamp;
};

class PopupHistoryList{
	protected:
	private:
		PopupHistoryData *historyData; //historyData[0] - oldest, historyData[size - 1] - newest
		int count;
		int size;
		
		void DeleteData(int index);
		void AddItem(PopupHistoryData item); //adds a PopupHistoryData item
		void RemoveItem(int index);
		
	public:
		PopupHistoryList();
		~PopupHistoryList();
		
		void Add(char *title, char *message, time_t timestamp);
		void Add(wchar_t *title, wchar_t *message, time_t timestamp);
		
		PopupHistoryData *Get(int index);
		
		void Clear();
		int Count();
		int Size();
};

/*Shows a history with the last popups.
Useful if you've missed a popup when it appeared.
wParam - 0
lParam - 0
*/
#define MS_POPUP_SHOWHISTORY "PopUp/ShowHistory"

extern PopupHistoryList lstPopupHistory; //defined in main.cpp
extern HWND hHistoryWindow; //the history window
void RefreshPopupHistory(HWND hWnd);

BOOL CALLBACK DlgProcHistLst(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

#endif //__popup_history_h__
