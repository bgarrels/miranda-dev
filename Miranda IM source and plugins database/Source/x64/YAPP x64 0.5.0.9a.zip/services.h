#ifndef _SERVICES_INC
#define _SERVICES_INC

void InitServices();
void DeinitServices();

/*
int CreatePopupA(WPARAM wParam, LPARAM lParam);
int CreatePopupExA(WPARAM wParam, LPARAM lParam);
int CreatePopupW(WPARAM wParam, LPARAM lParam);
int ChangeTextW(WPARAM wParam, LPARAM lParam);
int ChangeTextA(WPARAM wParam, LPARAM lParam);
int GetContact(WPARAM wParam, LPARAM lParam);
int GetPluginData(WPARAM wParam, LPARAM lParam);
int IsSecondLineShown(WPARAM wParam, LPARAM lParam);
int PopupQuery(WPARAM wParam, LPARAM lParam);
int PopupChange(WPARAM wParam, LPARAM lParam);
int ShowMessage(WPARAM wParam, LPARAM lParam);

int PopUp_ShowHistory(WPARAM wParam, LPARAM lParam);

int TogglePopups(WPARAM wParam, LPARAM lParam);
*/

#endif
