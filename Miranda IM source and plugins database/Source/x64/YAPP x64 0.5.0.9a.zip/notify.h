#ifndef _NOTIFY_IMP_INC
#define _NOTIFY_IMP_INC

void InitNotify();
void DeinitNotify();

#endif
