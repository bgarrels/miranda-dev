/*
    AdvancedAutoAway Plugin for Miranda-IM (www.miranda-im.org)
    Copyright 2003-2006 P. Boon

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	
	Some code is copied from Miranda's AutoAway module
*/
#include "../commonstatus.h"
#include "advancedautoaway.h"
#include "../resource.h"
#include <commctrl.h>

#ifdef _DEBUG
	#define SECS_PER_MINUTE		20 /* speedup */
#else
	#define SECS_PER_MINUTE		60 /* default I believe */
#endif

// {F0FDF73A-753D-499d-8DBA-336DB79CDD41}
#define MIID_ADVAUTOAWAY { 0xf0fdf73a, 0x753d, 0x499d, { 0x8d, 0xba, 0x33, 0x6d, 0xb7, 0x9c, 0xdd, 0x41 } }

#define TRIGGERPLUGIN /* remove this to compile without it */

#ifdef TRIGGERPLUGIN
extern int InitTrigger();
extern int DeInitTrigger();
#endif

HINSTANCE hInst;
PLUGINLINK *pluginLink;

struct MM_INTERFACE mmi;
AAAOPTPAGE *aop = NULL;
FULL_AUTOAWAYSETTING** autoAwaySettings = NULL;
static PROTOCOLSETTINGEX** confirmSettings = NULL;
int protoCount = 0;
static BOOL ignoreLockKeys = FALSE;
static BOOL ignoreSysKeys = FALSE;
static BOOL ignoreAltCombo = FALSE;
static BOOL monitorMouse = TRUE;
static BOOL monitorKeyboard = TRUE;
static HWND confirmDialog;
static HANDLE hAutoAwayOptionsHook;
static HANDLE hAutoAwayShutDownHook;
static HANDLE hCSModuleLoadedHook;
static HANDLE hProtoAckHook;
static HANDLE hStateChangedEvent;
static HANDLE hRegisterOptionsPageService;
static int mouseStationaryTimer;
HHOOK hMirandaMouseHook = NULL;
HHOOK hMirandaKeyBoardHook = NULL;
#pragma data_seg("Shared")
DWORD lastInput = 0;
POINT lastMousePos = {0};
HHOOK hMouseHook = NULL;
HHOOK hKeyBoardHook = NULL;
#pragma data_seg()
#pragma comment(linker, "/section:Shared,rws")
DWORD lastMirandaInput = 0;
static BOOL (WINAPI * MyGetLastInputInfo)(PLASTINPUTINFO);
static UINT hAutoAwayTimer;
// prototypes
extern DWORD StatusModeToProtoFlag(int status);
extern int InitCommonStatus();
static BOOL (WINAPI * MyGetLastInputInfo)(PLASTINPUTINFO);
void LoadOptions(FULL_AUTOAWAYSETTING** loadSettings, BOOL override);
int LoadAutoAwaySetting(FULL_AUTOAWAYSETTING* autoAwaySetting, char* protoName);
static int CSModuleLoaded(WPARAM wParam, LPARAM lParam);
static int HookWindowsHooks(int hookMiranda, int hookAll);
static int UnhookWindowsHooks();
static LRESULT CALLBACK MouseHookFunction(int code, WPARAM wParam, LPARAM lParam);
static LRESULT CALLBACK KeyBoardHookFunction(int code, WPARAM wParam, LPARAM lParam);
static LRESULT CALLBACK MirandaMouseHookFunction(int code, WPARAM wParam, LPARAM lParam);
static LRESULT CALLBACK MirandaKeyBoardHookFunction(int code, WPARAM wParam, LPARAM lParam);
static BOOL IsSaverRunning();
BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved);
__declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion);
int __declspec(dllexport) Load(PLUGINLINK *link);
int __declspec(dllexport) Unload(void);

static VOID CALLBACK AutoAwayTimer(HWND hwnd,UINT message,UINT idEvent,DWORD dwTime);
extern int AutoAwayOptInitialise(WPARAM wParam,LPARAM lParam);
extern int AutoAwayMsgOptInitialise(WPARAM wParam,LPARAM lParam);
extern int SetStatus(WPARAM wParam, LPARAM lParam);
extern int ShowConfirmDialog(WPARAM wParam, LPARAM lParam);
extern char *StatusModeToDbSetting(int status,const char *suffix);

typedef HDESK (WINAPI* pfnOpenInputDesktop)( DWORD, BOOL, DWORD );
static pfnOpenInputDesktop openInputDesktop = NULL;
typedef HDESK (WINAPI* pfnCloseDesktop)( HDESK );
static pfnCloseDesktop closeDesktop = NULL;

// ========================== Load from DB ==========================
void LoadOptions(FULL_AUTOAWAYSETTING** loadSettings, BOOL override) {

	// if override is enabled, samesettings will be ignored (for options loading)
	int i;
	char* protoName;
	int monitorMiranda = FALSE; // use windows hooks?
	int monitorAll = FALSE; // use windows hooks?

	if (!override)
		UnhookWindowsHooks();
	if (hAutoAwayTimer != 0)
		KillTimer(NULL, hAutoAwayTimer);
	ignoreLockKeys = DBGetContactSettingByte(NULL, MODULENAME, SETTING_IGNLOCK, FALSE);
	ignoreSysKeys = DBGetContactSettingByte(NULL, MODULENAME, SETTING_IGNSYSKEYS, FALSE);
	ignoreAltCombo = DBGetContactSettingByte(NULL, MODULENAME, SETTING_IGNALTCOMBO, FALSE);
	monitorMouse = DBGetContactSettingByte(NULL, MODULENAME, SETTING_MONITORMOUSE, TRUE);
	monitorKeyboard = DBGetContactSettingByte(NULL, MODULENAME, SETTING_MONITORKEYBOARD, TRUE);
	lastInput = lastMirandaInput = GetTickCount();
	for (i=0;i<protoCount;i++) {
		if ((DBGetContactSettingByte(NULL, MODULENAME, SETTING_SAMESETTINGS, 0)) && !override)
			protoName = SETTING_ALL;
		else
			protoName = loadSettings[i]->protocolSetting->szName;
		LoadAutoAwaySetting(loadSettings[i], protoName);
		if (!override) {
            if (loadSettings[i]->optionFlags&FLAG_MONITORMIRANDA)
				monitorMiranda = TRUE;
			else if ( (MyGetLastInputInfo==NULL) || ignoreLockKeys || ignoreSysKeys || ignoreAltCombo || (monitorMouse != monitorKeyboard) )
				monitorAll = TRUE;
		}
	}
	if (DBGetContactSettingByte(NULL, "Idle", "AAEnable", 0))
		return;
	HookWindowsHooks(monitorMiranda, monitorAll);
	hAutoAwayTimer = SetTimer(NULL,0, DBGetContactSettingWord(NULL, MODULENAME, SETTING_AWAYCHECKTIMEINSECS, 5)*1000,AutoAwayTimer);
}

int LoadAutoAwaySetting(FULL_AUTOAWAYSETTING* autoAwaySetting, char* protoName) {

	char setting[128];
	_snprintf(setting, sizeof(setting), "%s_OptionFlags", protoName);
	autoAwaySetting->optionFlags = DBGetContactSettingByte(NULL,MODULENAME,setting,FLAG_LV2ONINACTIVE|FLAG_RESET);
	_snprintf(setting, sizeof(setting), "%s_AwayTime", protoName);
	autoAwaySetting->awayTime = DBGetContactSettingWord(NULL,MODULENAME,setting,SETTING_AWAYTIME_DEFAULT);
	_snprintf(setting, sizeof(setting), "%s_NATime", protoName);
	autoAwaySetting->naTime = DBGetContactSettingWord(NULL,MODULENAME,setting,SETTING_NATIME_DEFAULT);
	_snprintf(setting, sizeof(setting), "%s_StatusFlags", protoName);
	autoAwaySetting->statusFlags = DBGetContactSettingWord(NULL,MODULENAME,setting, StatusModeToProtoFlag(ID_STATUS_ONLINE)|StatusModeToProtoFlag(ID_STATUS_FREECHAT));
	{
		int flags;
		if (DBGetContactSettingByte(NULL, MODULENAME, SETTING_SAMESETTINGS, 0))
			flags = 0xFFFFFF;
		else
			flags = CallProtoService(protoName, PS_GETCAPS,PFLAGNUM_2,0)&~CallProtoService(protoName, PS_GETCAPS, (WPARAM)PFLAGNUM_5, 0);
		_snprintf(setting, sizeof(setting), "%s_Lv1Status", protoName);
		autoAwaySetting->lv1Status = DBGetContactSettingWord(NULL, MODULENAME, setting, (flags&StatusModeToProtoFlag(ID_STATUS_AWAY))?ID_STATUS_AWAY:ID_STATUS_OFFLINE);
		_snprintf(setting, sizeof(setting), "%s_Lv2Status", protoName);
		autoAwaySetting->lv2Status = DBGetContactSettingWord(NULL, MODULENAME, setting, (flags&StatusModeToProtoFlag(ID_STATUS_NA))?ID_STATUS_NA:ID_STATUS_OFFLINE);
	}

	return 0;
}

static int ProcessProtoAck(WPARAM wParam,LPARAM lParam) {

	ACKDATA *ack=(ACKDATA*)lParam;
	int i;
	
	if(ack->type!=ACKTYPE_STATUS) return 0;
	if(ack->result!=ACKRESULT_SUCCESS) return 0;
	log_debugA("ProcessProtoAck: ack->szModule: %s", ack->szModule);
	for (i=0;i<protoCount;i++) {
		log_debugA("chk: %s", autoAwaySettings[i]->protocolSetting->szName);
		if (!strcmp(autoAwaySettings[i]->protocolSetting->szName, ack->szModule)) {
			log_debugA("ack->szModule: %s autoAwaySettings[i]->statusChanged: %d", ack->szModule, autoAwaySettings[i]->statusChanged);
			if (!autoAwaySettings[i]->statusChanged) {
				autoAwaySettings[i]->mStatus = TRUE;
			}
			autoAwaySettings[i]->statusChanged = FALSE;
		}
	}

	return 0;
}

/* this function is from the original auto-away module */
static BOOL IsWorkstationLocked (void)
{
	BOOL rc = FALSE;

	if (openInputDesktop != NULL) {
		HDESK hDesk = openInputDesktop(0, FALSE, DESKTOP_SWITCHDESKTOP);
		if (hDesk == NULL)
			rc = TRUE;
		else if (closeDesktop != NULL)
			closeDesktop(hDesk);
	}
	return rc;
}

static PROTOCOLSETTINGEX **GetProtoSettingsCopy(PROTOCOLSETTINGEX **protoSettings) {

	PROTOCOLSETTINGEX** ps;
	int i;

	ps = malloc(protoCount*sizeof(PROTOCOLSETTINGEX *));
	if (ps == NULL) {
		return NULL;
	}
	for(i=0;i<protoCount;i++) {
		ps[i] = malloc(sizeof(PROTOCOLSETTINGEX));
		if (ps[i] == NULL) {
			return NULL;
		}
		memcpy(ps[i], protoSettings[i], sizeof(PROTOCOLSETTINGEX));
		if (protoSettings[i]->szMsg != NULL)
			ps[i]->szMsg = _strdup(protoSettings[i]->szMsg);
	}

	return ps;
}

static int changeState(FULL_AUTOAWAYSETTING* setting, STATES newState) {

	if (setting->curState == newState)
		return 0;
	setting->oldState = setting->curState;
	setting->curState = newState;
	{ // debug
		char *szOld, *szNew;
		switch(setting->oldState) {
		case ACTIVE:
			szOld = "ACTIVE";
			break;
		case STATUS1_SET:
			szOld = "STATUS1_SET";
			break;
		case STATUS2_SET:
			szOld = "STATUS2_SET";
			break;
		case SET_ORGSTATUS:
			szOld = "SET_ORGSTATUS";
			break;
		case HIDDEN_ACTIVE:
			szOld = "HIDDEN_ACTIVE";
			break;
		default:
			szOld = "ERROR";
			break;
		}
		switch(setting->curState) {
		case ACTIVE:
			szNew = "ACTIVE";
			break;
		case STATUS1_SET:
			szNew = "STATUS1_SET";
			break;
		case STATUS2_SET:
			szNew = "STATUS2_SET";
			break;
		case SET_ORGSTATUS:
			szNew = "SET_ORGSTATUS";
			break;
		case HIDDEN_ACTIVE:
			szNew = "HIDDEN_ACTIVE";
			break;
		default:
			szNew = "ERROR";
			break;
		}
		log_debugA("%s state change: %s -> %s", setting->protocolSetting->szName, szOld, szNew);
	}
	NotifyEventHooks(hStateChangedEvent, (WPARAM)0, (LPARAM)(AUTOAWAYSETTING*)setting);
	if ( (setting->curState != SET_ORGSTATUS) && (setting->curState != ACTIVE) && (setting->statusChanged) ) {
		/* change the awaymessage */
		if (setting->protocolSetting->szMsg != NULL) {
			free(setting->protocolSetting->szMsg);
			setting->protocolSetting->szMsg = NULL;
		}
		if (DBGetContactSettingByte(NULL, MODULENAME, StatusModeToDbSetting(setting->protocolSetting->status, SETTING_MSGCUSTOM), FALSE)) {
			DBVARIANT dbv;
			if(!DBGetContactSetting(NULL, MODULENAME, StatusModeToDbSetting(setting->protocolSetting->status, SETTING_STATUSMSG), &dbv)) {
				setting->protocolSetting->szMsg = _strdup(dbv.pszVal);
				DBFreeVariant(&dbv);
			}
		}
	}
	else if (setting->protocolSetting->szMsg != NULL) {
		free(setting->protocolSetting->szMsg);
		setting->protocolSetting->szMsg = NULL;
	}
	
	return 0;
}

static VOID CALLBACK AutoAwayTimer(HWND hwnd,UINT message,UINT idEvent,DWORD dwTime) {
	
	int i;
	int statusChanged = FALSE;
	int confirm = FALSE;

	for(i=0;i<protoCount;i++) {
		int sts1Time, sts2Time, sts1setTime, currentMode;
		BOOL screenSaver, locked;

		autoAwaySettings[i]->protocolSetting->status = ID_STATUS_DISABLED;
		screenSaver = locked = FALSE;
		if (autoAwaySettings[i]->optionFlags&FLAG_MONITORMIRANDA)
			mouseStationaryTimer = (GetTickCount() - lastMirandaInput)/1000;
		else {
			if (MyGetLastInputInfo!=NULL) {
				LASTINPUTINFO lii;
				ZeroMemory(&lii,sizeof(lii));
				lii.cbSize=sizeof(lii);
				MyGetLastInputInfo(&lii);
				mouseStationaryTimer=(GetTickCount()-lii.dwTime)/1000;
			}
			else
				mouseStationaryTimer = (GetTickCount() - lastInput)/1000;
		}
		sts1Time = autoAwaySettings[i]->awayTime * SECS_PER_MINUTE;
		sts2Time = autoAwaySettings[i]->naTime * SECS_PER_MINUTE;
		sts1setTime = autoAwaySettings[i]->sts1setTimer==0?0:(GetTickCount() - autoAwaySettings[i]->sts1setTimer)/1000;
		currentMode = CallProtoService(autoAwaySettings[i]->protocolSetting->szName,PS_GETSTATUS,0, 0);
		if (autoAwaySettings[i]->optionFlags&FLAG_ONSAVER) {
			SystemParametersInfo(SPI_GETSCREENSAVERRUNNING, 0, &screenSaver, FALSE);
		}
		if (autoAwaySettings[i]->optionFlags&FLAG_ONLOCK) {
			locked = IsWorkstationLocked();
		}
		/* check states */
		if (autoAwaySettings[i]->curState == ACTIVE) {
			if ( ( ((mouseStationaryTimer >= sts1Time) && (autoAwaySettings[i]->optionFlags&FLAG_ONMOUSE) ) || (screenSaver) || (locked) ) && (currentMode != autoAwaySettings[i]->lv1Status) && (autoAwaySettings[i]->statusFlags&StatusModeToProtoFlag(currentMode)) ) {
				/* from ACTIVE to STATUS1_SET */
				autoAwaySettings[i]->protocolSetting->lastStatus = autoAwaySettings[i]->originalStatusMode = CallProtoService(autoAwaySettings[i]->protocolSetting->szName,PS_GETSTATUS,0, 0);
				autoAwaySettings[i]->protocolSetting->status = autoAwaySettings[i]->lv1Status;
				autoAwaySettings[i]->sts1setTimer = GetTickCount();
				sts1setTime = 0;
				autoAwaySettings[i]->statusChanged = statusChanged = TRUE;
				changeState(autoAwaySettings[i], STATUS1_SET);
			}
			else if ( (mouseStationaryTimer >= sts2Time) && (currentMode == autoAwaySettings[i]->lv1Status) && (currentMode != autoAwaySettings[i]->lv2Status) && (autoAwaySettings[i]->optionFlags&FLAG_SETNA)  && (autoAwaySettings[i]->statusFlags&StatusModeToProtoFlag(currentMode)) ) {
				/* from ACTIVE to STATUS2_SET */
				autoAwaySettings[i]->protocolSetting->lastStatus = autoAwaySettings[i]->originalStatusMode = CallProtoService(autoAwaySettings[i]->protocolSetting->szName,PS_GETSTATUS,0, 0);
				autoAwaySettings[i]->protocolSetting->status = autoAwaySettings[i]->lv2Status;
				autoAwaySettings[i]->statusChanged = statusChanged = TRUE;
				changeState(autoAwaySettings[i], STATUS2_SET);
			}
		}
		if (autoAwaySettings[i]->curState == STATUS1_SET) {
			if ( 
				((mouseStationaryTimer < sts1Time) && (!screenSaver) && (!locked)) && 
				!(autoAwaySettings[i]->optionFlags&FLAG_RESET) ) {
				/* from STATUS1_SET to HIDDEN_ACTIVE */
					changeState(autoAwaySettings[i], HIDDEN_ACTIVE);
					autoAwaySettings[i]->protocolSetting->lastStatus = CallProtoService(autoAwaySettings[i]->protocolSetting->szName,PS_GETSTATUS,0, 0);
			}
			else if ( ((mouseStationaryTimer < sts1Time) && (!screenSaver) && (!locked)) && 
				((autoAwaySettings[i]->optionFlags&FLAG_LV2ONINACTIVE) || (!(autoAwaySettings[i]->optionFlags&FLAG_SETNA))) &&
				(autoAwaySettings[i]->optionFlags&FLAG_RESET) ) {
				/* from STATUS1_SET to SET_ORGSTATUS */
				changeState(autoAwaySettings[i], SET_ORGSTATUS);
			}
			else if ( (autoAwaySettings[i]->optionFlags&FLAG_SETNA) && (sts1setTime >= sts2Time) ) {
				/* when set STATUS2, currentMode doesn't have to be in the selected status list (statusFlags) */
				/* from STATUS1_SET to STATUS2_SET */
				autoAwaySettings[i]->protocolSetting->lastStatus = CallProtoService(autoAwaySettings[i]->protocolSetting->szName,PS_GETSTATUS,0, 0);
				autoAwaySettings[i]->protocolSetting->status = autoAwaySettings[i]->lv2Status;
				autoAwaySettings[i]->statusChanged = statusChanged = TRUE;
				changeState(autoAwaySettings[i], STATUS2_SET);
			}
		}
		if (autoAwaySettings[i]->curState == STATUS2_SET) {
			if ( ((mouseStationaryTimer < sts2Time) && (!screenSaver) && (!locked)) && 
				(autoAwaySettings[i]->optionFlags&FLAG_RESET) ) {
				/* from STATUS2_SET to SET_ORGSTATUS */
				changeState(autoAwaySettings[i], SET_ORGSTATUS);
			}
			else if ( ((mouseStationaryTimer < sts2Time) && (!screenSaver) && (!locked)) && 
				!(autoAwaySettings[i]->optionFlags&FLAG_RESET) ) {
				/* from STATUS2_SET to HIDDEN_ACTIVE */
				/* Remember: after status1 is set, and "only on inactive" is NOT set, it implies !reset. */
				changeState(autoAwaySettings[i], HIDDEN_ACTIVE);
				autoAwaySettings[i]->protocolSetting->lastStatus = CallProtoService(autoAwaySettings[i]->protocolSetting->szName,PS_GETSTATUS,0, 0);
			}
		}
		if (autoAwaySettings[i]->curState == HIDDEN_ACTIVE) {
			if (autoAwaySettings[i]->mStatus) {
				/* HIDDEN_ACTIVE to ACTIVE */
				//autoAwaySettings[i]->statusChanged = FALSE;
				changeState(autoAwaySettings[i], ACTIVE);
				autoAwaySettings[i]->sts1setTimer = 0;
				autoAwaySettings[i]->mStatus = FALSE;
			}
			else if ( (autoAwaySettings[i]->optionFlags&FLAG_SETNA) && (currentMode == autoAwaySettings[i]->lv1Status) &&
				(currentMode != autoAwaySettings[i]->lv2Status) && (autoAwaySettings[i]->statusFlags&StatusModeToProtoFlag(currentMode)) &&
				((mouseStationaryTimer >= sts2Time) || ((sts1setTime >= sts2Time) && (!(autoAwaySettings[i]->optionFlags&FLAG_LV2ONINACTIVE)))) ) {
				/* HIDDEN_ACTIVE to STATUS2_SET */
				autoAwaySettings[i]->protocolSetting->lastStatus = autoAwaySettings[i]->originalStatusMode = CallProtoService(autoAwaySettings[i]->protocolSetting->szName,PS_GETSTATUS,0, 0);
				autoAwaySettings[i]->protocolSetting->status = autoAwaySettings[i]->lv2Status;
				autoAwaySettings[i]->statusChanged = statusChanged = TRUE;
				changeState(autoAwaySettings[i], STATUS2_SET);
			}
		}
		if (autoAwaySettings[i]->curState == SET_ORGSTATUS) {
			/* SET_ORGSTATUS to ACTIVE */
			autoAwaySettings[i]->protocolSetting->lastStatus = CallProtoService(autoAwaySettings[i]->protocolSetting->szName,PS_GETSTATUS,0, 0);
			autoAwaySettings[i]->protocolSetting->status = autoAwaySettings[i]->originalStatusMode;
			confirm = (autoAwaySettings[i]->optionFlags&FLAG_CONFIRM)?TRUE:confirm;
			autoAwaySettings[i]->statusChanged = statusChanged = TRUE;
			changeState(autoAwaySettings[i], ACTIVE);
			autoAwaySettings[i]->sts1setTimer = 0;
		}
		autoAwaySettings[i]->mStatus = FALSE;
	}
	if ( (confirm) || (statusChanged) ) {
		PROTOCOLSETTINGEX **ps;

		ps = GetProtoSettingsCopy(confirmSettings);
		if (ps == NULL) {
			return;
		}
		for (i=0;i<protoCount;i++) {
			if (ps[i]->status == ID_STATUS_DISABLED) {
				ps[i]->szName = "";
			}
		}
		
		if (confirm)
			confirmDialog = (HWND)CallService(MS_CS_SHOWCONFIRMDLGEX, (WPARAM)&ps, DBGetContactSettingWord(NULL, MODULENAME, SETTING_CONFIRMDELAY, 5));
		else if (statusChanged)
			CallService(MS_CS_SETSTATUSEX, (WPARAM)&ps, 0);
		
		for(i=0;i<protoCount;i++) {
			if (ps[i]->szMsg != NULL)
				free(ps[i]->szMsg);
			free(ps[i]);
		}
		free(ps);
	}
}
	
// ========================== Windows hooks ==========================
static int HookWindowsHooks(int hookMiranda, int hookAll)
{
	if (hookMiranda) {
		if ( (monitorKeyboard) && (hMirandaKeyBoardHook == NULL) )
			hMirandaKeyBoardHook = SetWindowsHookEx(WH_KEYBOARD,MirandaKeyBoardHookFunction,NULL,GetCurrentThreadId());
		if ( (monitorMouse) && (hMirandaMouseHook == NULL) )
			hMirandaMouseHook = SetWindowsHookEx(WH_MOUSE,MirandaMouseHookFunction,NULL,GetCurrentThreadId());
	}
	if (hookAll) {
		MyGetLastInputInfo=NULL;
		if ( (monitorKeyboard) && (hKeyBoardHook == NULL) )
			hKeyBoardHook = SetWindowsHookEx(WH_KEYBOARD,KeyBoardHookFunction,hInst,0);
		if ( (monitorMouse) && (hMouseHook == NULL) )
			hMouseHook = SetWindowsHookEx(WH_MOUSE,MouseHookFunction,hInst,0);
	}

	return 0;
}

static int UnhookWindowsHooks()
{
	UnhookWindowsHookEx(hMouseHook);
	UnhookWindowsHookEx(hKeyBoardHook);
	UnhookWindowsHookEx(hMirandaMouseHook);
	UnhookWindowsHookEx(hMirandaKeyBoardHook);

	hMouseHook = hKeyBoardHook = hMirandaMouseHook = hMirandaKeyBoardHook = NULL;

	return 0;
}

static LRESULT CALLBACK MirandaMouseHookFunction(int code, WPARAM wParam, LPARAM lParam) {

	if (code >= 0) {
		DWORD pid;
		PMOUSEHOOKSTRUCT mouseInfo = (PMOUSEHOOKSTRUCT)lParam;
		POINT pt = mouseInfo->pt;
		
		/* TioDuke's KeyBoardNotifyExt: only update if a Miranda window is focused */
		GetWindowThreadProcessId(GetForegroundWindow(), &pid);
		if (pid != GetCurrentProcessId()) {
			return CallNextHookEx(hMirandaMouseHook, code, wParam, lParam);
		}
		if (pt.x!=lastMousePos.x || pt.y!=lastMousePos.y) {
			lastMousePos = pt;
			lastMirandaInput = GetTickCount();	 
		}
	}
				
	return CallNextHookEx(hMirandaMouseHook, code, wParam, lParam);
}

static LRESULT CALLBACK MirandaKeyBoardHookFunction(int code, WPARAM wParam, LPARAM lParam)
{
	if (code >= 0) {
		if (ignoreAltCombo) {//&& ((HIWORD(lParam)&KF_ALTDOWN) || (wParam == VK_MENU)) ) {
			if ( ((GetKeyState(VK_MENU) < 0) || (wParam == VK_MENU)) ||
				((GetKeyState(VK_TAB) < 0) || (wParam == VK_TAB)) ||
				((GetKeyState(VK_SHIFT) < 0) || (wParam == VK_SHIFT)) ||
				((GetKeyState(VK_CONTROL) < 0) || (wParam == VK_CONTROL)) ||
				((GetKeyState(VK_ESCAPE) < 0) || (wParam == VK_ESCAPE)) ||
				((GetKeyState(VK_LWIN) < 0) || (wParam == VK_LWIN)) ||
				((GetKeyState(VK_RWIN) < 0) || (wParam == VK_RWIN)) ) {
				return CallNextHookEx(hMirandaKeyBoardHook, code, wParam, lParam);
			}
		}
		switch (wParam) {
		case VK_NUMLOCK:
		case VK_CAPITAL:
		case VK_SCROLL:
			if (!ignoreLockKeys) {
				lastMirandaInput = GetTickCount();
			}
			break;
		case VK_TAB:
		case VK_SHIFT:
		case VK_CONTROL:
		case VK_MENU:
		case VK_ESCAPE:
		case VK_LWIN:
		case VK_RWIN:
			if (!ignoreSysKeys) {
				lastMirandaInput = GetTickCount();
			}
			break;
		default:
			lastMirandaInput = GetTickCount();
			break;
		}
	}
	
	return CallNextHookEx(hMirandaKeyBoardHook, code, wParam, lParam);
}

static LRESULT CALLBACK MouseHookFunction(int code, WPARAM wParam, LPARAM lParam) {

	if (code >= 0) {
		PMOUSEHOOKSTRUCT mouseInfo = (PMOUSEHOOKSTRUCT)lParam;
		POINT pt = mouseInfo->pt;

		/* TioDuke's KeyBoardNotifyExt: also grab clicks */
		if ((wParam >= WM_NCLBUTTONDOWN && wParam <= WM_NCXBUTTONDBLCLK && wParam != 0x00AA) || (wParam >= WM_LBUTTONDOWN && wParam <= WM_XBUTTONDBLCLK)) {
			lastInput = GetTickCount();
		}
		if (pt.x!=lastMousePos.x || pt.y!=lastMousePos.y) {
			lastMousePos = pt;
			lastInput = GetTickCount();	 
		}
	}
				
	return CallNextHookEx(hMouseHook, code, wParam, lParam);
}

static LRESULT CALLBACK KeyBoardHookFunction(int code, WPARAM wParam, LPARAM lParam)
{
	if (code >= 0) {
		if (ignoreAltCombo) {//&& ((HIWORD(lParam)&KF_ALTDOWN) || (wParam == VK_MENU)) ) {
			if ( ((GetKeyState(VK_MENU) < 0) || (wParam == VK_MENU)) ||
				((GetKeyState(VK_TAB) < 0) || (wParam == VK_TAB)) ||
				((GetKeyState(VK_SHIFT) < 0) || (wParam == VK_SHIFT)) ||
				((GetKeyState(VK_CONTROL) < 0) || (wParam == VK_CONTROL)) ||
				((GetKeyState(VK_ESCAPE) < 0) || (wParam == VK_ESCAPE)) ||
				((GetKeyState(VK_LWIN) < 0) || (wParam == VK_LWIN)) ||
				((GetKeyState(VK_RWIN) < 0) || (wParam == VK_RWIN)) ) {
				return CallNextHookEx(hKeyBoardHook, code, wParam, lParam);
			}
		}
		switch (wParam) {
		case VK_NUMLOCK:
		case VK_CAPITAL:
		case VK_SCROLL:
			if (!ignoreLockKeys) {
				lastInput = GetTickCount();
			}
			break;
		case VK_TAB:
		case VK_SHIFT:
		case VK_CONTROL:
		case VK_MENU:
		case VK_ESCAPE:
		case VK_LWIN:
		case VK_RWIN:
			if (!ignoreSysKeys) {
				lastInput = GetTickCount();
			}
			break;
		default:
			lastInput = GetTickCount();
			break;
		}
	}
	
	return CallNextHookEx(hKeyBoardHook, code, wParam, lParam);
}

static int RegisterOptionPage(WPARAM wParam, LPARAM lParam)
{
	AAAOPTPAGE *page;

	page = (AAAOPTPAGE *)lParam;
	if (aop != NULL) {
		if (aop->pszText != NULL) {
			free(aop->pszText);
		}
	}
	aop = malloc(sizeof(AAAOPTPAGE));
	CopyMemory(aop, page, sizeof(AAAOPTPAGE));
	if (page->pszText != NULL) {
		aop->pszText = _strdup(page->pszText);
	}

	return 0;
}

// ========================== Inits & stuff ==========================
static int AutoAwayShutdown(WPARAM wParam,LPARAM lParam)
{
	int i;
	KillTimer(NULL, hAutoAwayTimer);
	for (i=0;i<protoCount;i++) {
		free(autoAwaySettings[i]);
		free(confirmSettings[i]);
	}
	free(autoAwaySettings);
	free(confirmSettings);
#ifdef TRIGGERPLUGIN
	DeInitTrigger();
#endif
	UnhookEvent(hAutoAwayOptionsHook);
	UnhookEvent(hAutoAwayShutDownHook);
	UnhookEvent(hCSModuleLoadedHook);
	UnhookEvent(hProtoAckHook);
	UnhookWindowsHooks();
	DestroyHookableEvent(hStateChangedEvent);
	DestroyServiceFunction(hRegisterOptionsPageService);
		
	return 0;
}

int LoadAutoAwayProtocolSettings(void)
{
	int i,count;
	PROTOCOLDESCRIPTOR **protos;
	CallService(MS_PROTO_ENUMPROTOCOLS,(WPARAM)&count,(LPARAM)&protos);
	confirmSettings = (PROTOCOLSETTINGEX**)malloc(count*sizeof(PROTOCOLSETTINGEX*));
	autoAwaySettings = (FULL_AUTOAWAYSETTING**)malloc(count*sizeof(FULL_AUTOAWAYSETTING*));
	if ((confirmSettings == NULL) || (autoAwaySettings == NULL)) MessageBox(NULL, "malloc failed", "LoadAutoAwayProtocolSettings", MB_OK);
	protoCount = 0;

	for(i=0;i<count;i++) {
		if(protos[i]->type!=PROTOTYPE_PROTOCOL || CallProtoService(protos[i]->szName,PS_GETCAPS,PFLAGNUM_2,0)==0) continue;

		autoAwaySettings[protoCount] = malloc(sizeof(FULL_AUTOAWAYSETTING));
		confirmSettings[protoCount] = malloc(sizeof(PROTOCOLSETTINGEX));
		if ((confirmSettings[protoCount] == NULL) || (autoAwaySettings[protoCount] == NULL)) MessageBox(NULL, "malloc failed", "LoadAutoAwayProtocolSettings", MB_OK);
		confirmSettings[protoCount]->cbSize = sizeof(PROTOCOLSETTINGEX);
		confirmSettings[protoCount]->szName =  protos[i]->szName;
		confirmSettings[protoCount]->lastStatus = confirmSettings[protoCount]->status = autoAwaySettings[protoCount]->originalStatusMode = ID_STATUS_CURRENT;
		confirmSettings[protoCount]->szMsg = NULL;
		autoAwaySettings[protoCount]->curState = ACTIVE;
		autoAwaySettings[protoCount]->mStatus = FALSE;
		autoAwaySettings[protoCount]->protocolSetting = confirmSettings[protoCount];
		
		protoCount += 1;
	}

	autoAwaySettings = (FULL_AUTOAWAYSETTING**)realloc(autoAwaySettings, protoCount*sizeof(FULL_AUTOAWAYSETTING*));
	confirmSettings = (PROTOCOLSETTINGEX**)realloc(confirmSettings, protoCount*sizeof(PROTOCOLSETTINGEX*));
	if ((autoAwaySettings == NULL) || (confirmSettings == NULL)) MessageBox(NULL, "realloc failed", "LoadAutoAwayProtocolSettings", MB_OK);
	
	return 0;
}

static int CSModuleLoaded(WPARAM wParam, LPARAM lParam)
{
	protoCount = wParam;
	if (protoCount == 0) return -1;
	hAutoAwayOptionsHook = HookEvent(ME_OPT_INITIALISE,AutoAwayOptInitialise);
	hAutoAwayShutDownHook = HookEvent(ME_SYSTEM_OKTOEXIT,AutoAwayShutdown);
	hProtoAckHook = HookEvent(ME_PROTO_ACK, ProcessProtoAck);
	mouseStationaryTimer=0;
	lastInput = lastMirandaInput = GetTickCount();
	LoadAutoAwayProtocolSettings();
	if ( (IsWinVer2000Plus()) && (!DBGetContactSettingByte(NULL, MODULENAME, SETTING_IGNLOCK, FALSE)) )
		MyGetLastInputInfo=(BOOL (WINAPI *)(PLASTINPUTINFO))GetProcAddress(GetModuleHandle("user32"),"GetLastInputInfo");
	else
		MyGetLastInputInfo=NULL;
	LoadOptions(autoAwaySettings, FALSE);
#ifdef TRIGGERPLUGIN
	InitTrigger();
#endif

	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////
// dll entry point

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved) {

	hInst = hinstDLL;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////////////
// returns plugin's standard information

PLUGININFO pluginInfo = {
	sizeof(PLUGININFO),
	"Advanced Auto Away",
	__VERSION_DWORD,
	"AdvancedAutoAway, an Auto Away module with some more options than the original.",
	"P Boon",
	"unregistered@users.sourceforge.net",
	"(c) 2003-2006 P. Boon",
	"http://www.miranda-im.org/",
	0,
	DEFMOD_RNDAUTOAWAY    // replaces autoaway module; this one acts per protocol
                         // we do NOT replace the IDLE module
};

__declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion) {

	return &pluginInfo;
}

/////////////////////////////////////////////////////////////////////////////////////////
// returns plugin's extended information

PLUGININFOEX pluginInfoEx = {
	sizeof(PLUGININFOEX),
	"Advanced Auto Away",
	__VERSION_DWORD,
	"AdvancedAutoAway, an Auto Away module with some more options than the original.",
	"P Boon",
	"unregistered@users.sourceforge.net",
	"(c) 2003-2008 P. Boon, George Hazan",
	"http://www.miranda-im.org/",
	0, DEFMOD_RNDAUTOAWAY,
	MIID_ADVAUTOAWAY
};

__declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	return &pluginInfoEx;
}

/////////////////////////////////////////////////////////////////////////////////////////
// returns plugin's interfaces information

static const MUUID interfaces[] = { MIID_AUTOAWAY, MIID_LAST };

__declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

/////////////////////////////////////////////////////////////////////////////////////////
// plugin's entry point

int __declspec(dllexport) Load(PLUGINLINK *link)
{
	HMODULE hUser32 = GetModuleHandleA("user32");
	openInputDesktop = ( pfnOpenInputDesktop )GetProcAddress (hUser32, "OpenInputDesktop");
	closeDesktop = ( pfnCloseDesktop )GetProcAddress (hUser32, "CloseDesktop");

	pluginLink = link;
	mir_getMMI(&mmi);

	InitCommonStatus();
	hCSModuleLoadedHook = HookEvent(ME_CS_CSMODULELOADED, CSModuleLoaded);
	hStateChangedEvent = CreateHookableEvent(ME_AAA_STATECHANGED);
	hRegisterOptionsPageService = CreateServiceFunction(MS_AAA_REGISTEROPTIONPAGE, RegisterOptionPage);
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////
// plugin's exit point

int __declspec(dllexport) Unload(void)
{
	return 0;
}
