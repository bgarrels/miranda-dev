/*
    AdvancedAutoAway Plugin for Miranda-IM (www.miranda-im.org)
    KeepStatus Plugin for Miranda-IM (www.miranda-im.org)
    StartupStatus Plugin for Miranda-IM (www.miranda-im.org)
    Copyright 2003-2006 P. Boon

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "commonstatus.h"

// handles for hooks and other Miranda thingies
static HANDLE hModulesLoadedHook ;
static HANDLE hShutdownHook;
static HANDLE hCSSetStatusExService;
static HANDLE hCSShowConfirmDlgExService;
static HANDLE hCSStatusChangedExEvent;
static HANDLE hCSModuleLoadedEvent;
static HANDLE hCSGetProtoCountService;
// variables (general)
static int protoCount = 0;
extern struct MM_INTERFACE mmi;
// prototypes
char *StatusModeToDbSetting(int status,const char *suffix);
DWORD StatusModeToProtoFlag(int status);
int SetStatusEx(WPARAM wParam, LPARAM lParam);
int InitCommonStatus();
static int ModulesLoaded(WPARAM wParam, LPARAM lParam);
static int CreateServices();
int GetProtoCount();
static int Exit(WPARAM wParam, LPARAM lParam);
// extern
extern int ShowConfirmDialogEx(WPARAM wParam, LPARAM lParam);

// some helpers from awaymsg.c ================================================================
char *StatusModeToDbSetting(int status,const char *suffix)
{
	char *prefix;
	static char str[64];

	switch(status) {
		case ID_STATUS_AWAY: prefix="Away";	break;
		case ID_STATUS_NA: prefix="Na";	break;
		case ID_STATUS_DND: prefix="Dnd"; break;
		case ID_STATUS_OCCUPIED: prefix="Occupied"; break;
		case ID_STATUS_FREECHAT: prefix="FreeChat"; break;
		case ID_STATUS_ONLINE: prefix="On"; break;
		case ID_STATUS_OFFLINE: prefix="Off"; break;
		case ID_STATUS_INVISIBLE: prefix="Inv"; break;
		case ID_STATUS_ONTHEPHONE: prefix="Otp"; break;
		case ID_STATUS_OUTTOLUNCH: prefix="Otl"; break;
		default: return NULL;
	}
	lstrcpy(str,prefix); lstrcat(str,suffix);
	return str;
}

DWORD StatusModeToProtoFlag(int status)
{
	// *not* the same as in core, <offline>
	switch(status) {
		case ID_STATUS_ONLINE: return PF2_ONLINE;
		case ID_STATUS_OFFLINE: return PF2_OFFLINE;
		case ID_STATUS_INVISIBLE: return PF2_INVISIBLE;
		case ID_STATUS_OUTTOLUNCH: return PF2_OUTTOLUNCH;
		case ID_STATUS_ONTHEPHONE: return PF2_ONTHEPHONE;
		case ID_STATUS_AWAY: return PF2_SHORTAWAY;
		case ID_STATUS_NA: return PF2_LONGAWAY;
		case ID_STATUS_OCCUPIED: return PF2_LIGHTDND;
		case ID_STATUS_DND: return PF2_HEAVYDND;
		case ID_STATUS_FREECHAT: return PF2_FREECHAT;
	}
	return 0;
}

int GetActualStatus(PROTOCOLSETTINGEX *protoSetting)
{
	if (protoSetting->status == ID_STATUS_LAST) {
		if ( (protoSetting->lastStatus < MIN_STATUS) || (protoSetting->lastStatus > MAX_STATUS) )
			return CallProtoService(protoSetting->szName, PS_GETSTATUS, 0, 0);
		return protoSetting->lastStatus;
	}
	if (protoSetting->status == ID_STATUS_CURRENT)
		return CallProtoService(protoSetting->szName, PS_GETSTATUS, 0, 0);

	if ( (protoSetting->status < ID_STATUS_OFFLINE) || (protoSetting->status > ID_STATUS_OUTTOLUNCH) ) {
		log_debugA("invalid status detected: %d", protoSetting->status);
		return 0;
	}
	return protoSetting->status;
}

// helper, from core
static char *GetDefaultMessage(int status)
{
	switch(status) {
		case ID_STATUS_AWAY: return Translate("I've been away since %time%.");
		case ID_STATUS_NA: return Translate("Give it up, I'm not in!");
		case ID_STATUS_OCCUPIED: return Translate("Not right now.");
		case ID_STATUS_DND: return Translate("Give a guy some peace, would ya?");
		case ID_STATUS_FREECHAT: return Translate("I'm a chatbot!");
		case ID_STATUS_ONLINE: return Translate("Yep, I'm here.");
		case ID_STATUS_OFFLINE: return Translate("Nope, not here.");
		case ID_STATUS_INVISIBLE: return Translate("I'm hiding from the mafia.");
		case ID_STATUS_ONTHEPHONE: return Translate("That'll be the phone.");
		case ID_STATUS_OUTTOLUNCH: return Translate("Mmm...food.");
		case ID_STATUS_IDLE: return Translate("idleeeeeeee");
	}
	return NULL;
}

char *GetDefaultStatusMessage(PROTOCOLSETTINGEX *ps, int newstatus)
{
	char *sMsg;

	sMsg = NULL;
	if (ps->szMsg != NULL) {// custom message set
		sMsg = _strdup(ps->szMsg);
		log_infoA("CommonStatus: Status message set by calling plugin");
	}
	else {
		char *tMsg;
			
		if (ServiceExists(MS_AWAYMSG_GETSTATUSMSG)) {
			if ( (ServiceExists(MS_SA_ISSARUNNING)) && (CallService(MS_SA_ISSARUNNING, 0, 0)) ) {
				tMsg = (char*)CallService(MS_AWAYMSG_GETSTATUSMSG, (WPARAM)newstatus, (LPARAM)ps->szName);
			}
			else {
				tMsg = (char*)CallService(MS_AWAYMSG_GETSTATUSMSG, (WPARAM)newstatus, 0);
			}
			if (tMsg != NULL) {
				sMsg = _strdup(tMsg);
			}
			mir_free(tMsg);
			log_debug("CommonStatus: Status message retrieved from general awaysys");
		}
		else if (sMsg == NULL) {
			tMsg = GetDefaultMessage(newstatus); /* awaysys doesn't define the service above */
			if (tMsg != NULL) {
				sMsg = _strdup(tMsg);
			}
			log_debug("CommonStatus: Status message retrieved from defaults");
		}
	}
	
	return sMsg;
}

static int equalsGlobalStatus(PROTOCOLSETTINGEX **ps) {

	PROTOCOLDESCRIPTOR **protos;
	int i, j, count, pstatus, gstatus;

	pstatus = gstatus = 0;
	for (i=0;i<protoCount;i++) {
		if ( (ps[i]->szMsg != NULL) && (GetActualStatus(ps[i]) != ID_STATUS_OFFLINE) ) {
			return 0;
		}
	}
	CallService(MS_PROTO_ENUMPROTOCOLS,(WPARAM)&count,(LPARAM)&protos);
	for (i=0;i<count;i++) {
		if(protos[i]->type!=PROTOTYPE_PROTOCOL || CallProtoService(protos[i]->szName,PS_GETCAPS,PFLAGNUM_2,0)==0) continue;
		pstatus = 0;
		for (j=0;j<protoCount;j++) {
			if (!strcmp(protos[i]->szName, ps[j]->szName)) {
				pstatus = GetActualStatus(ps[j]);
			}
		}
		if (pstatus == 0) {
			pstatus = CallProtoService(protos[i]->szName, PS_GETSTATUS, 0, 0);
		}
		if (DBGetContactSettingByte(NULL, protos[i]->szName, "LockMainStatus", 0)) {
			// if proto is locked, pstatus must be the current status
			if (pstatus != CallProtoService(protos[i]->szName, PS_GETSTATUS, 0, 0)) {
				return 0;
			}
		}
		else {
			if (gstatus == 0) {
				gstatus = pstatus;
			}
			if (pstatus != gstatus) {
				return 0;
			}
		}
	}

	return gstatus;
}

static int nasSetStatus(PROTOCOLSETTINGEX **protoSettings, int newstatus)
{
	NAS_PROTOINFO npi;
	char **nasProtoMessages, *nasGlobalMsg;
	int i, j, msgCount, maxMsgCount;

	if (!ServiceExists(MS_NAS_SETSTATE)) {
		return -1;
	}
		
	nasGlobalMsg = NULL;
	msgCount = maxMsgCount = 0;
	if (newstatus == 0) {
	/* 
	The global status will not be changed. Still, we'd like to set the global status message for NAS.
	This should only be done if all protocols will change in this call. Otherwise, the chance exists
	that an already set status message will be overwritten. The global status message will be set for 
	the status message which is to be set for most of the protocols. Protocols are only considered 
	which have szMsg==NULL. After the global status message is set, the protocols for which another
	message and/or status have to be set will be overwritten.
		*/
		ZeroMemory(&npi, sizeof(NAS_PROTOINFO));
		npi.cbSize = sizeof(NAS_PROTOINFO);
		npi.status = 0;
		npi.szProto = NULL;
		CallService(MS_NAS_GETSTATE, (WPARAM)&npi, (LPARAM)1);
		nasProtoMessages = calloc(protoCount,sizeof(char *));
		if (nasProtoMessages == NULL) {
			return -1;
		}
		// fill the array of proto message for NAS, this will be used anyway
		for (i=0;i<protoCount;i++) {
			if ( (!CallService(MS_PROTO_ISPROTOCOLLOADED, 0, (LPARAM)protoSettings[i]->szName)) || (protoSettings[i]->szMsg != NULL) ) {
				continue;
			}
			ZeroMemory(&npi, sizeof(NAS_PROTOINFO));
			npi.cbSize = sizeof(NAS_PROTOINFO);
			npi.status = GetActualStatus(protoSettings[i]);
			npi.szProto = protoSettings[i]->szName;
			if (CallService(MS_NAS_GETSTATE, (WPARAM)&npi, (LPARAM)1) == 0) {
				nasProtoMessages[i] = npi.szMsg;
			}
		}
		// if not all proto's are to be set here, we don't set the global status message
		for (i=0;i<protoCount;i++) {
			if (!CallService(MS_PROTO_ISPROTOCOLLOADED, 0, (LPARAM)protoSettings[i]->szName)) {
				break;
			}
		}
		if (i == protoCount) {
			for (i=0;i<protoCount;i++) {
				msgCount = 0;
				for (j=i;j<protoCount;j++) {
					if ( (nasProtoMessages[i] != NULL) && (nasProtoMessages[j] != NULL) && (!strcmp(nasProtoMessages[i], nasProtoMessages[j])) ) {
						msgCount += 1;
						//log_infoA("Adding %s (%u) to %s (%u)", protoSettings[j]->szName, protoSettings[j]->status, protoSettings[i]->szName, protoSettings[i]->status);
					}
				}
				if ( (msgCount > maxMsgCount) && ((protoCount == 1) || (msgCount > 1)) ) {
					maxMsgCount = msgCount;
					nasGlobalMsg = _strdup(nasProtoMessages[i]);
				}
			}
		}
		if (nasGlobalMsg != NULL) {
			// set global message
			ZeroMemory(&npi, sizeof(NAS_PROTOINFO));
			npi.cbSize = sizeof(NAS_PROTOINFO);
			npi.status = 0; // status is not important for global message
			npi.szMsg = mir_strdup(nasGlobalMsg);
			npi.Flags |= PIF_NO_CLIST_SETSTATUSMODE;
			log_infoA("CommonStatus sets global status message for NAS which is to be changed for %d protocols", maxMsgCount);
			CallService(MS_NAS_SETSTATE, (WPARAM)&npi, (LPARAM)1);
		}
		for (i=0;i<protoCount;i++) {
			if (!CallService(MS_PROTO_ISPROTOCOLLOADED, 0, (LPARAM)protoSettings[i]->szName)) {
				continue;
			}
			ZeroMemory(&npi, sizeof(NAS_PROTOINFO));
			npi.cbSize = sizeof(NAS_PROTOINFO);
			npi.status = GetActualStatus(protoSettings[i]);
			npi.szProto = protoSettings[i]->szName;
			if (protoSettings[i]->szMsg != NULL) {
				npi.szMsg = mir_strdup(protoSettings[i]->szMsg);
				log_infoA("CommonStatus will set status %u for %s and message specified by plugin using NAS (%x)", npi.status, npi.szProto, npi.szMsg);
			}
			else if ( (nasProtoMessages[i] != NULL) && (nasGlobalMsg != NULL) && (!strcmp(nasProtoMessages[i], nasGlobalMsg)) ) {
				npi.szMsg = NULL;
				log_infoA("CommonStatus will set status %u for %s and global message using NAS", npi.status, npi.szProto);
			}
			else {
				npi.szMsg = nasProtoMessages[i];
				log_infoA("CommonStatus will set status %u for %s and message from NAS using NAS", npi.status, npi.szProto);
			}
			CallService(MS_NAS_SETSTATE, (WPARAM)&npi, (LPARAM)1);
		}
		if (nasGlobalMsg != NULL) {
			free(nasGlobalMsg);
		}
		free(nasProtoMessages);
	}
	else {
		ZeroMemory(&npi, sizeof(NAS_PROTOINFO));
		npi.cbSize = sizeof(NAS_PROTOINFO);
		npi.szProto = NULL; // global
		npi.szMsg = NULL; // global
		npi.status = newstatus;
		log_debug("CommonStatus sets global status %u using NAS", newstatus);
		CallService(MS_NAS_SETSTATE, (WPARAM)&npi, (LPARAM)1);
	}

	return 0;
}

int SetStatusEx(WPARAM wParam, LPARAM lParam)
{	
	int i, j, newstatus, oldstatus;
	PROTOCOLSETTINGEX** protoSettings;
	char *sMsg, *szFormattedMsg;

	protoSettings = *(PROTOCOLSETTINGEX***)wParam;
	if (protoSettings == NULL)
		return -1;
	
	/* 
		issue with setting global status;
		things get messy because SRAway hooks ME_CLIST_STATUSMODECHANGE, so the status messages of SRAway and
		commonstatus will clash
	*/
	NotifyEventHooks(hCSStatusChangedExEvent, (WPARAM)&protoSettings, (LPARAM)0);
	newstatus = equalsGlobalStatus(protoSettings);

	if (!nasSetStatus(protoSettings, newstatus)) {
		return 0;
	}
	
	if (newstatus != 0) {
		if (!ServiceExists(MS_CLIST_SETSTATUSMODE)) {
			log_debug("CommonStatus: MS_CLIST_SETSTATUSMODE not available!");
			return -1;
		}
		log_debug("CommonStatus: setting global status %u", newstatus);
		CallService(MS_CLIST_SETSTATUSMODE, (WPARAM)newstatus, 0);
		return 0;
	}
	for (i=0;i<protoCount;i++) {
		if (!CallService(MS_PROTO_ISPROTOCOLLOADED, 0, (LPARAM)protoSettings[i]->szName)) {
			//log_debug("CommonStatus: %s is not loaded", protoSettings[i]->szName);
			continue;
		}
		sMsg = NULL;
		// some checks
		newstatus = GetActualStatus(protoSettings[i]);
		if (newstatus == 0) {
			log_debug("CommonStatus: incorrect status for %s (%d)", protoSettings[i]->szName, protoSettings[i]->status);
			continue;
		}
		oldstatus = CallProtoService(protoSettings[i]->szName, PS_GETSTATUS, 0, 0);
		// set last status
		protoSettings[i]->lastStatus = oldstatus;
		if (oldstatus <= MAX_CONNECT_RETRIES) {// ignore if connecting, but it didn't came this far if it did
			log_debug("CommonStatus: %s is already connecting", protoSettings[i]->szName);
			continue;
		}
		// status checks
		if ( (newstatus != ID_STATUS_OFFLINE) && ( (!(CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_2, 0)&Proto_Status2Flag(newstatus))) || ((CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_5, 0)&Proto_Status2Flag(newstatus)))) ) {
			// status and status message for this status not supported
			//log_debug("CommonStatus: status not supported %s", protoSettings[i]->szName);
			continue;
		}
		if  ( (newstatus == oldstatus) && ((!(CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_1, 0)&PF1_MODEMSGSEND&~PF1_INDIVMODEMSG)) || (!(CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_3, 0)&Proto_Status2Flag(newstatus)))) ) {
			// no status change and status messages not supported
			//log_debug("CommonStatus: no change, %s (%d %d)", protoSettings[i]->szName, oldstatus, newstatus);
			continue;
		}
		// set the status
		if ( (newstatus != oldstatus) && (!((CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_1, 0)&PF1_MODEMSGSEND&~PF1_INDIVMODEMSG) && (CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_3, 0)&Proto_Status2Flag(newstatus)) && (ServiceExists(MS_NAS_SETSTATE)))) ) {
			log_debug("CommonStatus sets status for %s to %d", protoSettings[i]->szName, newstatus);
			CallProtoService(protoSettings[i]->szName, PS_SETSTATUS, (WPARAM)newstatus, 0);
		}
		// get status message
		if  ( (!(CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_1, 0)&PF1_MODEMSGSEND&~PF1_INDIVMODEMSG)) || (!(CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_3, 0)&Proto_Status2Flag(newstatus))) ) {
			continue;
		}
		sMsg = GetDefaultStatusMessage(protoSettings[i], newstatus);
		if (ServiceExists(MS_VSRAMM_SETAWAYMSG)) {
			PROTOMSGINFO pmi;

			pmi.statusMode = protoSettings[i]->status;
			pmi.szProto = protoSettings[i]->szName;
			pmi.msg = sMsg;
			log_debug("CommonStatus sets status message for %s using VSRAMM", protoSettings[i]->szName);
			CallService(MS_VSRAMM_SETAWAYMSG, (WPARAM)0, (LPARAM)&pmi);
		}
		else {
			if (sMsg != NULL) {
				/* replace the default vars in msg  (I believe this is from core) */
				for (j=0;sMsg[j];j++) {
					char substituteStr[128];
					
					if (sMsg[j]!='%') continue;
					if (!_strnicmp(sMsg+j,"%time%",6))
						GetTimeFormat(LOCALE_USER_DEFAULT,TIME_NOSECONDS,NULL,NULL,substituteStr,128);
					else if (!_strnicmp(sMsg+j,"%date%",6))
						GetDateFormat(LOCALE_USER_DEFAULT,DATE_SHORTDATE,NULL,NULL,substituteStr,128);
					else 
						continue;
					if(lstrlen(substituteStr)>6) 
						sMsg = (char*)realloc(sMsg, lstrlen(sMsg)+1+lstrlen(substituteStr)-6);
					MoveMemory(sMsg+j+lstrlen(substituteStr), sMsg+j+6,lstrlen(sMsg)-j-5);
					CopyMemory(sMsg+j, substituteStr, lstrlen(substituteStr));
				}
				szFormattedMsg = variables_parsedup(sMsg, protoSettings[i]->szName, NULL);
				if (szFormattedMsg != NULL) {
					free(sMsg);
					sMsg = szFormattedMsg;
				}
			}
			log_debug("CommonStatus sets status message for %s directly", protoSettings[i]->szName);
			CallProtoService(protoSettings[i]->szName, PS_SETAWAYMSG, (WPARAM)newstatus, (LPARAM)sMsg);
			if (sMsg != NULL) {
				free(sMsg);
			}
		}
	}

	return 0;
}

static int GetProtocolCountService(WPARAM wParam, LPARAM lParam)
{
	return GetProtoCount();
}

int GetProtoCount() {

	int i, count, pCount;
	PROTOCOLDESCRIPTOR **protos;
    
	pCount = 0;
	CallService(MS_PROTO_ENUMPROTOCOLS,(WPARAM)&count,(LPARAM)&protos);
	for(i=0;i<count;i++) {
		if(protos[i]->type!=PROTOTYPE_PROTOCOL || CallProtoService(protos[i]->szName,PS_GETCAPS,PFLAGNUM_2,0)==0) continue;
		pCount += 1;
	}

	return pCount;
}

int InitCommonStatus()
{
	if (!CreateServices()) {
		hModulesLoadedHook = HookEvent(ME_SYSTEM_MODULESLOADED, ModulesLoaded);
	  	hShutdownHook = HookEvent(ME_SYSTEM_OKTOEXIT, Exit);
	}

	return 0;
}

static int ModulesLoaded(WPARAM wParam, LPARAM lParam)
{
	protoCount = GetProtoCount();
	NotifyEventHooks(hCSModuleLoadedEvent, protoCount, 0);
	
	return 0;
}

static int CreateServices()
{
	if (ServiceExists(MS_CS_SETSTATUSEX)) 
		return -1;

	hCSSetStatusExService = CreateServiceFunction(MS_CS_SETSTATUSEX, SetStatusEx);
	hCSShowConfirmDlgExService = CreateServiceFunction(MS_CS_SHOWCONFIRMDLGEX, ShowConfirmDialogEx);
	hCSStatusChangedExEvent = CreateHookableEvent(ME_CS_STATUSCHANGEEX);
	hCSGetProtoCountService = CreateServiceFunction(MS_CS_GETPROTOCOUNT, GetProtocolCountService);
	hCSModuleLoadedEvent = CreateHookableEvent(ME_CS_CSMODULELOADED);
	
	return 0;
}

static int Exit(WPARAM wParam, LPARAM lParam) {

	UnhookEvent(hShutdownHook);
	UnhookEvent(hModulesLoadedHook);
	if (hCSSetStatusExService != 0) {
		DestroyHookableEvent(hCSStatusChangedExEvent);
		DestroyHookableEvent(hCSModuleLoadedEvent);
		DestroyServiceFunction(hCSSetStatusExService);
		DestroyServiceFunction(hCSShowConfirmDlgExService);
	}

	return 0;
}
