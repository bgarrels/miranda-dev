/*
    AdvancedAutoAway Plugin for Miranda-IM (www.miranda-im.org)
    KeepStatus Plugin for Miranda-IM (www.miranda-im.org)
    StartupStatus Plugin for Miranda-IM (www.miranda-im.org)
    Copyright 2003-2006 P. Boon

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "commonstatus.h" 
#include "resource.h"
#include <commctrl.h>

// variables
static HWND win;
static PROTOCOLSETTINGEX** confirmSettings;
static int timeOut;
static int protoCount; // use from commonstatus
#define TIMER_ID	1
// prototypes
extern HINSTANCE hInst;
static BOOL CALLBACK ConfirmDlgProc(HWND hwndDlg,UINT msg,WPARAM wParam,LPARAM lParam);
static int SetStatusList(PROTOCOLSETTINGEX** protoSettings, HWND hwndDlg);
int ShowConfirmDialogEx(WPARAM wParam, LPARAM lParam);
static int ShowStatusMessageDialog(WPARAM wParam, LPARAM lParam);

extern int GetProtoCount();

static BOOL CALLBACK ConfirmDlgProc(HWND hwndDlg,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg) {
	case WM_INITDIALOG:
		{
			LVCOLUMN lvCol;
			HWND hList=GetDlgItem(hwndDlg,IDC_STARTUPLIST);
			
			TranslateDialogDefault(hwndDlg);
			// create columns
			SendMessage(hList,LVM_SETEXTENDEDLISTVIEWSTYLE,0,LVS_EX_FULLROWSELECT);
			memset(&lvCol,0,sizeof(lvCol));
			lvCol.mask=LVCF_TEXT|LVCF_WIDTH|LVCF_SUBITEM;
			lvCol.pszText=Translate("Protocol");
			SendMessage(hList,LVM_INSERTCOLUMN,0,(LPARAM)&lvCol);
			lvCol.cx = 100;
			lvCol.pszText=Translate("Status");
			SendMessage(hList,LVM_INSERTCOLUMN,1,(LPARAM)&lvCol);
			lvCol.pszText=Translate("Message");
			SendMessage(hList,LVM_INSERTCOLUMN,2,(LPARAM)&lvCol);
			// create items
			SetStatusList(confirmSettings, hwndDlg);
			//
			EnableWindow(GetDlgItem(hwndDlg, IDC_SETSTSMSG), FALSE);
			// fill profile combo box
			if (!ServiceExists(MS_SS_GETPROFILE))
				EnableWindow(GetDlgItem(hwndDlg, IDC_PROFILE), FALSE);
			else {
				int profileCount, i, item;
				int defaultProfile;
				char profileName[128];

				profileCount = (int)CallService(MS_SS_GETPROFILECOUNT, (WPARAM)&defaultProfile, 0);
				for (i=0;i<profileCount;i++) {
					CallService(MS_SS_GETPROFILENAME, i, (LPARAM)profileName);
					item = SendDlgItemMessage(hwndDlg,IDC_PROFILE,CB_ADDSTRING,0,(LPARAM)profileName);
					SendDlgItemMessage(hwndDlg,IDC_PROFILE,CB_SETITEMDATA,item,(LPARAM)i);
				}
				if (profileCount == 0)
					EnableWindow(GetDlgItem(hwndDlg, IDC_PROFILE), FALSE);
			}
			// start timer
			if (timeOut > 0) {
				char text[32];
				_snprintf(text, sizeof(text), Translate("Closing in %d"), timeOut);
				SetDlgItemText(hwndDlg, IDC_CLOSE, text);
				SetTimer(hwndDlg, TIMER_ID, 1000, NULL);
			}
		}
		break;

	case WM_TIMER:
		{
			char text[32];
			_snprintf(text, sizeof(text), Translate("Closing in %d"), timeOut-1);
			SetDlgItemText(hwndDlg, IDC_CLOSE, text);
			if (timeOut <= 0) {
				KillTimer(hwndDlg, TIMER_ID);
				SendMessage(hwndDlg, UM_CLOSECONFIRMDLG, 0, 0);
			}
			else timeOut -= 1;
	   }
		break;

	case WM_COMMAND:
		// stop timer
		KillTimer(hwndDlg, TIMER_ID);
		SetDlgItemText(hwndDlg, IDC_CLOSE, Translate("Close"));
		if ( (HIWORD(wParam) == CBN_SELCHANGE) || (HIWORD(wParam) == BN_CLICKED) || (HIWORD(wParam) == NM_CLICK) ) { // something clicked
			switch (LOWORD(wParam)) {
			case IDC_PROFILE:
				{
					int profile, i;

					profile = (int)SendDlgItemMessage(hwndDlg, IDC_PROFILE, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_PROFILE, CB_GETCURSEL, 0, 0), 0);
					for (i=0;i<protoCount;i++) {
						if (confirmSettings[i]->szMsg != NULL) {
							free(confirmSettings[i]->szMsg);
							confirmSettings[i]->szMsg = NULL;
						}
					}
					CallService(MS_SS_GETPROFILE, (WPARAM)profile, (LPARAM)&confirmSettings);
					for (i=0;i<protoCount;i++) {
						if (confirmSettings[i]->szMsg != NULL) // we free this later, copy to our memory space
							confirmSettings[i]->szMsg = _strdup(confirmSettings[i]->szMsg);
					}						
					SetStatusList(confirmSettings, hwndDlg);
				}
				break;

			case IDC_STATUS:
				{
					LVITEM lvItem;
					char last[80];
					char current[80];
					PROTOCOLSETTINGEX* proto;
					int actualStatus;

					memset(&lvItem,0,sizeof(lvItem));
					lvItem.mask=LVIF_TEXT|LVIF_PARAM;
					lvItem.iSubItem=0;
					lvItem.iItem = ListView_GetNextItem(GetDlgItem(hwndDlg,IDC_STARTUPLIST),-1,LVNI_SELECTED);
					if (lvItem.iItem == -1) break;
					ListView_GetItem(GetDlgItem(hwndDlg,IDC_STARTUPLIST), &lvItem);
					proto = (PROTOCOLSETTINGEX*)lvItem.lParam;
					actualStatus = proto->status = (int)SendDlgItemMessage(hwndDlg, IDC_STATUS, CB_GETITEMDATA, SendDlgItemMessage(hwndDlg, IDC_STATUS, CB_GETCURSEL, 0, 0), 0);
					// LAST STATUS
					if (proto->status == ID_STATUS_LAST) {
						_snprintf(last, sizeof(last), "%s (%s)", Translate("<last>"), (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, (WPARAM)proto->lastStatus, (LPARAM)0));
						ListView_SetItemText(GetDlgItem(hwndDlg,IDC_STARTUPLIST), lvItem.iItem, 1, last);
						actualStatus = proto->lastStatus;
					}
					// CURRENT STATUS
					else if (proto->status == ID_STATUS_CURRENT) {
						int currentStatus;

						currentStatus = CallProtoService(proto->szName,PS_GETSTATUS, 0, 0);
						_snprintf(current, sizeof(current), "%s (%s)", Translate("<current>"), (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, (WPARAM)currentStatus, (LPARAM)0));
						ListView_SetItemText(GetDlgItem(hwndDlg,IDC_STARTUPLIST), lvItem.iItem, 1, current);
						actualStatus = currentStatus;
					}
					else ListView_SetItemText(GetDlgItem(hwndDlg,IDC_STARTUPLIST), lvItem.iItem, 1, (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, (WPARAM)proto->status, (LPARAM)0));

					if  ( (!((CallProtoService(proto->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_1, 0)&PF1_MODEMSGSEND)&~PF1_INDIVMODEMSG)) || (!(CallProtoService(proto->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_3, 0)&Proto_Status2Flag(actualStatus))) )
						EnableWindow(GetDlgItem(hwndDlg, IDC_SETSTSMSG), FALSE);
					else if ( (proto->status == ID_STATUS_LAST) || (proto->status == ID_STATUS_CURRENT) )
						EnableWindow(GetDlgItem(hwndDlg, IDC_SETSTSMSG), TRUE);
					else
						EnableWindow(GetDlgItem(hwndDlg, IDC_SETSTSMSG), (CallProtoService(proto->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_3, 0)&Proto_Status2Flag(actualStatus))?TRUE:FALSE);
					SetStatusList(confirmSettings, hwndDlg);
				}
				break;

			case IDC_SETSTSMSG:
				{
					LVITEM lvItem;
					PROTOCOLSETTINGEX* proto;

					memset(&lvItem,0,sizeof(lvItem));
					lvItem.mask=LVIF_TEXT|LVIF_PARAM;
					lvItem.iSubItem=0;
					lvItem.iItem = ListView_GetNextItem(GetDlgItem(hwndDlg,IDC_STARTUPLIST),-1,LVNI_SELECTED);
					if (lvItem.iItem == -1) break;
					ListView_GetItem(GetDlgItem(hwndDlg,IDC_STARTUPLIST), &lvItem);
					proto = (PROTOCOLSETTINGEX*)lvItem.lParam;
					ShowStatusMessageDialog((WPARAM)hwndDlg, (LPARAM)proto);
				}
				break;

			case IDC_CLOSE:
				SendMessage(hwndDlg, UM_CLOSECONFIRMDLG, 0, 0);
				break;

			case IDC_CANCEL:
				DestroyWindow(hwndDlg);
				break;
			}
		}
		break;
	
	case WM_NOTIFY:
		switch(((NMHDR*)lParam)->idFrom) {
		case IDC_STARTUPLIST:
			switch(((NMHDR*)lParam)->code) {
			// fill combobox
			case NM_CLICK:
				{
					LVITEM lvItem;
					PROTOCOLSETTINGEX* proto;
					char last[80];
					char current[80];
					int item, flags, i, currentStatus, actualStatus;
					char* statusMode;
					
					KillTimer(hwndDlg, TIMER_ID);
					SetDlgItemText(hwndDlg, IDC_CLOSE, Translate("Close"));

					memset(&lvItem,0,sizeof(lvItem));
					lvItem.mask=LVIF_TEXT|LVIF_PARAM;
					lvItem.iSubItem=0;
					lvItem.iItem = ListView_GetNextItem(GetDlgItem(hwndDlg,IDC_STARTUPLIST),-1,LVNI_SELECTED);
				
					if (ListView_GetItem(GetDlgItem(hwndDlg,IDC_STARTUPLIST), &lvItem) == FALSE) {
						SetStatusList(confirmSettings, hwndDlg);
						break;
					}
					proto = (PROTOCOLSETTINGEX*)lvItem.lParam;
									
					flags = CallProtoService(proto->szName, PS_GETCAPS,PFLAGNUM_2,0)&~CallProtoService(proto->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_5, 0);
					// clear box and add new status, loop status and check if compatible with proto
					SendDlgItemMessage(hwndDlg, IDC_STATUS, CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
					actualStatus = proto->status;
					// last
					_snprintf(last, sizeof(last), "%s (%s)", Translate("<last>"), (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, (WPARAM)proto->lastStatus, (LPARAM)0));
					item = SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_ADDSTRING,0,(LPARAM)last);
					SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_SETITEMDATA,item,(LPARAM)ID_STATUS_LAST);
					if (proto->status == ID_STATUS_LAST) {
						SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_SETCURSEL,(WPARAM)item,0);
						actualStatus = proto->lastStatus;
					}
					// current
					currentStatus = CallProtoService(proto->szName,PS_GETSTATUS, 0, 0);
					_snprintf(current, sizeof(current), "%s (%s)", Translate("<current>"), (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, (WPARAM)currentStatus, (LPARAM)0));
					item = SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_ADDSTRING,0,(LPARAM)current);
					SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_SETITEMDATA,item,(LPARAM)ID_STATUS_CURRENT);
					if (proto->status == ID_STATUS_CURRENT) {
						SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_SETCURSEL,(WPARAM)item,0);
						actualStatus = currentStatus;
					}
					for(i=0;i<sizeof(statusModeList)/sizeof(statusModeList[0]);i++) {
						if ( ((flags&statusModePf2List[i]) || (statusModePf2List[i] == PF2_OFFLINE)) && (!((!(flags)&Proto_Status2Flag(statusModePf2List[i]))) || ((CallProtoService(proto->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_5, 0)&Proto_Status2Flag(statusModePf2List[i])))) ) {
							statusMode = (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, (WPARAM)statusModeList[i], (LPARAM)0);
							item=SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_ADDSTRING,0,(LPARAM)statusMode);
							SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_SETITEMDATA,item,(LPARAM)statusModeList[i]);
							if (statusModeList[i] == proto->status)
								SendDlgItemMessage(hwndDlg,IDC_STATUS,CB_SETCURSEL,(WPARAM)item,0);
						}
					}
					// enable status box
					EnableWindow(GetDlgItem(hwndDlg,IDC_STATUS), (ListView_GetNextItem(GetDlgItem(hwndDlg,IDC_STARTUPLIST),-1,LVNI_SELECTED)>=0));
					if  ( (!((CallProtoService(proto->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_1, 0)&PF1_MODEMSGSEND)&~PF1_INDIVMODEMSG)) || (!(CallProtoService(proto->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_3, 0)&Proto_Status2Flag(actualStatus))) )
						EnableWindow(GetDlgItem(hwndDlg, IDC_SETSTSMSG), FALSE);
					else if ( (proto->status == ID_STATUS_LAST) || (proto->status == ID_STATUS_CURRENT) )
						EnableWindow(GetDlgItem(hwndDlg, IDC_SETSTSMSG), TRUE);
					else
						EnableWindow(GetDlgItem(hwndDlg, IDC_SETSTSMSG), (CallProtoService(proto->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_3, 0)&Proto_Status2Flag(actualStatus))?TRUE:FALSE);
				}
				break;
			}
			break;
		}
		break;
	
	case UM_STSMSGDLGCLOSED:
		SetStatusList(confirmSettings, hwndDlg);
		break;

	case UM_CLOSECONFIRMDLG:
		CallService(MS_CS_SETSTATUSEX, (WPARAM)&confirmSettings, 0);
		DestroyWindow(hwndDlg);
		break;

	case WM_DESTROY:
		{
			int i;
			for (i=0;i<protoCount;i++) {
				if (confirmSettings[i]->szMsg != NULL) free(confirmSettings[i]->szMsg);
				free(confirmSettings[i]);
			}
			free(confirmSettings);
		}
		break;
	}

	return 0;
}

static int SetStatusList(PROTOCOLSETTINGEX** protoSettings, HWND hwndDlg) {

	int i, actualStatus;
	LVITEM lvItem;
	HWND hList=GetDlgItem(hwndDlg,IDC_STARTUPLIST);
	char protocol[64];
	char last[80];
	char current[80];
	char *status;
	
	if (protoSettings == NULL)
		return -1;

	// create items
	memset(&lvItem,0,sizeof(lvItem));
	lvItem.mask=LVIF_TEXT|LVIF_PARAM;
	lvItem.cchTextMax = 256;
	lvItem.iItem=0;
	lvItem.iSubItem=0;
	for(i=0;i<protoCount;i++) {
		CallProtoService(protoSettings[i]->szName,PS_GETNAME,sizeof(protocol),(LPARAM)protocol);
		lvItem.pszText=protocol;
		if (ListView_GetItemCount(hList) < protoCount) 
			ListView_InsertItem(hList,&lvItem);
		if (protoSettings[i]->status == ID_STATUS_LAST)
			actualStatus = protoSettings[i]->lastStatus;
		else if (protoSettings[i]->status == ID_STATUS_CURRENT)
			actualStatus = CallProtoService(protoSettings[i]->szName,PS_GETSTATUS, 0, 0);
		else
			actualStatus = protoSettings[i]->status;
		status = (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, (WPARAM)actualStatus, (LPARAM)0);
		// last
		if (protoSettings[i]->status == ID_STATUS_LAST) {
			_snprintf(last, sizeof(last), "%s (%s)", Translate("<last>"), status);
			ListView_SetItemText(hList, lvItem.iItem, 1, last);
		} // current
		else if (protoSettings[i]->status == ID_STATUS_CURRENT) {
			_snprintf(current, sizeof(current), "%s (%s)", Translate("<current>"), status);
			ListView_SetItemText(hList, lvItem.iItem, 1, current);
		}
		else
			ListView_SetItemText(hList, lvItem.iItem, 1, status);

		// status message
		if ( !((!((CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_1, 0)&PF1_MODEMSGSEND)&~PF1_INDIVMODEMSG)) || (!(CallProtoService(protoSettings[i]->szName, PS_GETCAPS, (WPARAM)PFLAGNUM_3, 0)&Proto_Status2Flag(actualStatus)))) ) {
			char *fMsg, *msg;

			msg = GetDefaultStatusMessage(protoSettings[i], actualStatus);
			if (msg != NULL) {
				fMsg = variables_parsedup(msg, protoSettings[i]->szName, NULL);
				ListView_SetItemText(hList, lvItem.iItem, 2, fMsg);
				free(msg);
				free(fMsg);
			}
			else ListView_SetItemText(hList, lvItem.iItem, 2, Translate("<n/a>"));
		}
		else ListView_SetItemText(hList, lvItem.iItem, 2, Translate("<n/a>"));

		ListView_SetColumnWidth(hList, 0, LVSCW_AUTOSIZE);
		ListView_SetColumnWidth(hList, 2, LVSCW_AUTOSIZE);
		lvItem.lParam=(LPARAM)protoSettings[i];
		ListView_SetItem(hList,&lvItem);
		lvItem.iItem++;
	}

	// grey out status box
	EnableWindow(GetDlgItem(hwndDlg,IDC_STATUS), (ListView_GetNextItem(GetDlgItem(hwndDlg,IDC_STARTUPLIST),-1,LVNI_SELECTED)>=0));
	return 0;
}

int ShowConfirmDialogEx(WPARAM wParam, LPARAM lParam)
{
	int i, j, count, pCount;
	PROTOCOLSETTINGEX** protoSettings = *(PROTOCOLSETTINGEX***)wParam;
	PROTOCOLDESCRIPTOR **protos;
	
	CallService(MS_PROTO_ENUMPROTOCOLS,(WPARAM)&count,(LPARAM)&protos);
	protoCount = GetProtoCount();
	timeOut = lParam;
	if (timeOut < 0)
		timeOut = DEF_CLOSE_TIME;

	// copy settings
	if (protoSettings == NULL) 
		return -1;

	confirmSettings = (PROTOCOLSETTINGEX**)malloc(protoCount*sizeof(PROTOCOLSETTINGEX*));
	if (confirmSettings == NULL) MessageBox(NULL, "malloc failed", "ShowConfirmDialog", MB_OK);
	//CopyMemory(confirmSettings, protoSettings, protoCount*sizeof(PROTOCOLSETTING*));
	pCount = 0;
	for(i=0;i<count;i++) {
		if(protos[i]->type!=PROTOTYPE_PROTOCOL || CallProtoService(protos[i]->szName,PS_GETCAPS,PFLAGNUM_2,0)==0) continue;
		confirmSettings[pCount] = (PROTOCOLSETTINGEX*)malloc(sizeof(PROTOCOLSETTINGEX));
		if (confirmSettings[pCount] == NULL) MessageBox(NULL, "malloc failed", "ShowConfirmDialog", MB_OK);
		//CopyMemory(confirmSettings[i], protoSettings[i], sizeof(PROTOCOLSETTING));
		confirmSettings[pCount]->cbSize = sizeof(PROTOCOLSETTINGEX);
		confirmSettings[pCount]->szName = protos[i]->szName;
		confirmSettings[pCount]->status = confirmSettings[pCount]->lastStatus = CallProtoService(protos[i]->szName, PS_GETSTATUS, 0, 0);
		confirmSettings[pCount]->szMsg = NULL;
		for (j=0;j<protoCount;j++) {
			if (!strcmp(protoSettings[j]->szName, confirmSettings[pCount]->szName)) {
				confirmSettings[pCount]->lastStatus = protoSettings[j]->lastStatus;
				confirmSettings[pCount]->status = protoSettings[j]->status;
				if (protoSettings[j]->szMsg != NULL)
					confirmSettings[pCount]->szMsg = _strdup(protoSettings[j]->szMsg);
			}
		}
		pCount += 1;
	}
	if (GetWindow(win, 0) == NULL) {
		win = CreateDialogParam((HINSTANCE)hInst,(LPCTSTR)MAKEINTRESOURCE(IDD_CONFIRMDIALOG),(HWND)NULL,(DLGPROC)ConfirmDlgProc,(LPARAM)NULL);
		EnableWindow(win,TRUE);
	}
	
	return (int)win;
}

static BOOL CALLBACK StatusMessageDlgProc(HWND hwndDlg,UINT msg,WPARAM wParam,LPARAM lParam)
{
	static PROTOCOLSETTINGEX* protoSetting = NULL;
	switch(msg) {
	case WM_INITDIALOG:
		{
			char desc[512], protocol[64], *smsg;

			protoSetting = (PROTOCOLSETTINGEX *)lParam;
			TranslateDialogDefault(hwndDlg);
			if (protoSetting->szMsg == NULL) {
				smsg = GetDefaultStatusMessage(protoSetting, GetActualStatus(protoSetting));
				if	(smsg != NULL) {
					SetDlgItemText(hwndDlg, IDC_STSMSG, smsg);
					free(smsg);
				}
			}
			else SetDlgItemText(hwndDlg, IDC_STSMSG, protoSetting->szMsg);

			CallProtoService(protoSetting->szName,PS_GETNAME,sizeof(protocol),(LPARAM)protocol);
			_snprintf(desc, sizeof(desc)-1, Translate("Set %s message for %s."), (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, (WPARAM)GetActualStatus(protoSetting), (LPARAM)0), protocol);
			SetDlgItemText(hwndDlg, IDC_DESCRIPTION, desc);
		}
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDC_OK:
			{
				int len = SendMessage(GetDlgItem(hwndDlg, IDC_STSMSG), WM_GETTEXTLENGTH, 0, 0);
				if (len > 0) {
					protoSetting->szMsg = realloc(protoSetting->szMsg, len+1);
					if (protoSetting->szMsg != NULL)
						GetDlgItemText(hwndDlg, IDC_STSMSG, protoSetting->szMsg, len+1);
				}
				SendMessage(GetParent(hwndDlg), UM_STSMSGDLGCLOSED, (WPARAM)TRUE, 0);
				EndDialog(hwndDlg, IDC_OK);
			}
			break;

		case IDC_CANCEL:
			SendMessage(GetParent(hwndDlg), UM_STSMSGDLGCLOSED, (WPARAM)0, 0);
			EndDialog(hwndDlg, IDC_CANCEL);
			break;
		}
		break;
	}

	return FALSE;
}

/* no service, must be in plugins memory space */
static int ShowStatusMessageDialog(WPARAM wParam, LPARAM lParam)
{
	PROTOCOLSETTINGEX *protoSetting = (PROTOCOLSETTINGEX *)lParam;
	HWND hwndParent = (HWND)wParam;
	DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_SETSTSMSGDIALOG), hwndParent, StatusMessageDlgProc, (LPARAM)protoSetting);
	return 0;
}
