//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by facebook.rc
//
#define IDI_FACEBOOK                    101
#define IDI_MIND                        102
#define IDD_FACEBOOKACCOUNT             111
#define IDD_MIND                        112
#define IDD_OPTIONS                     113
#define IDD_OPTIONS_EVENTS              114
#define IDD_INFO                        115
#define IDC_UN                          1001
#define IDC_PW                          1002
#define IDC_NEWACCOUNTLINK              1003
#define IDC_NAME                        1011
#define IDC_MINDMSG                     1012
#define IDC_CHARACTERS                  1013
#define IDC_GROUP                       1021
#define IDC_AGENT                       1022
#define IDC_POLLRATE                    1023
#define IDC_SECURE                      1024
#define IDC_CLOSE_WINDOWS               1025
#define IDC_SET_STATUS                  1126
#define IDC_LOGGING                     1027
#define IDC_COOKIES                     1028
#define IDC_NOTIFICATIONS_ENABLE        1041
#define IDC_FEEDS_ENABLE                1042
#define IDC_OTHER_ENABLE                1043
#define IDC_CLIENT_ENABLE               1044
#define IDC_COLBACK                     1051
#define IDC_COLTEXT                     1052
#define IDC_COLBACK2                    1053
#define IDC_COLTEXT2                    1054
#define IDC_COLBACK3                    1055
#define IDC_COLTEXT3                    1056
#define IDC_COLBACK4                    1057
#define IDC_COLTEXT4                    1058
#define IDC_NOTIFICATIONS_DEFAULT       1071
#define IDC_FEEDS_DEFAULT               1072
#define IDC_OTHER_DEFAULT               1073
#define IDC_CLIENT_DEFAULT              1074
#define IDC_TIMEOUT                     1081
#define IDC_TIMEOUT_SPIN                1082
#define IDC_TIMEOUT2                    1083
#define IDC_TIMEOUT_SPIN2               1084
#define IDC_TIMEOUT3                    1085
#define IDC_TIMEOUT_SPIN3               1086
#define IDC_TIMEOUT4                    1087
#define IDC_TIMEOUT_SPIN4               1088
#define IDC_SYSTRAY_NOTIFY              1098
#define IDC_PREVIEW                     1099
#define IDC_DEBUGINFO                   1101

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        121
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1201
#define _APS_NEXT_SYMED_VALUE           131
#endif
#endif
