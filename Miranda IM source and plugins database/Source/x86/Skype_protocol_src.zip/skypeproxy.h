/* Commands for command mode of Skype proxy */

#define AUTHENTICATE		0x01
#define CAPABILITIES		0x02

/* Capabilities flags of Skypeproxy */
#define USE_AUTHENTICATION	0x01