//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Skript1.rc
//
#define IDI_CALL                        102
#define IDD_OPTIONS                     105
#define IDI_ICON1                       106
#define IDI_HUP                         108
#define IDD_DIAL                        109
#define IDB_CALL                        110
#define IDD_CALLSTAT                    111
#define IDI_HOLD                        112
#define IDI_RESUME                      113
#define IDI_INVITE                      114
#define IDD_INPUTBOX                    115
#define IDC_STARTSKYPE                  1000
#define IDC_NOTRAY                      1001
#define IDC_NOSPLASH                    1002
#define IDC_MINIMIZED                   1003
#define IDC_SHUTDOWN                    1004
#define IDC_ENABLEMENU                  1005
#define IDC_UNLOADOFFLINE               1006
#define IDC_USES2S                      1007
#define IDC_HOST                        1008
#define IDC_PORT                        1009
#define IDC_REQPASS                     1010
#define IDC_PASSWORD                    1011
#define IDC_USEPOPUP                    1012
#define IDC_GROUPCHAT                   1014
#define IDC_NOERRORS                    1015
#define IDC_CONNATTEMPTS                1016
#define IDC_SKYPEOUTSTAT                1018
#define IDC_NUMBER                      1019
#define IDDIAL                          1020
#define IDC_KEEPSTATE                   1021
#define IDC_CLEANUP                     1022
#define IDC_JOIN                        1023
#define IDC_HOLD                        1024
#define IDC_HANGUP                      1025
#define IDC_TEXT                        1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
