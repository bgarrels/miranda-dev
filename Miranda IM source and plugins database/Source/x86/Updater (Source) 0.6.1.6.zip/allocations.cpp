#include "common.h"
#include "allocations.h"

Allocations allocations;

