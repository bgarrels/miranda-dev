#ifndef _CONF_COMP_DIALOG_INC
#define _CONF_COMP_DIALOG_INC

#include "options.h"

INT_PTR CALLBACK DlgProcConfirmComponents(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

#endif
