


#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#pragma comment(linker,"/subsystem:Windows,5")
#pragma comment(linker,"/version:5")

#define WINVER       0x0500
#define _WIN32_WINNT 0x0500
#define UNICODE
#define _UNICODE


#include <windows.h>
#include <MemoryFind.h>
#include <StrToNum.h>
#include <NumToStr.h>
#include <DebugFunctions.h>



#ifdef NDEBUG
	#pragma comment(linker,"/MERGE:.rdata=.text")
	#pragma comment(linker,"/FILEALIGN:512 /SECTION:.text,EWRX /IGNORE:4078")
#endif //_DEBUG



DWORD GetData(LPVOID lpBuff,SIZE_T dwBuffSize,LPVOID *plpCurrentPos,DWORD *pdwID,DWORD *pdwCityID,DWORD *pdwCountryID,LPSTR *plpszCountry,SIZE_T *pdwCountrySize,LPSTR *plpszCity,SIZE_T *pdwCitySize,LPSTR *plpszPlace,SIZE_T *pdwPlaceSize);



int APIENTRY wWinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPWSTR lpCmdLine,int nCmdShow)
{
	DWORD dwRet=NO_ERROR;
	HANDLE hFileInput,hFileOutput;


	hFileInput=CreateFile(L"C:\\Documents and Settings\\Rozhuk_IM\\��� ���������\\Programmer\\VC\\Mra\\Docs\\region_m.txt",GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	hFileOutput=CreateFile(L"C:\\Documents and Settings\\Rozhuk_IM\\��� ���������\\Programmer\\VC\\Mra\\Docs\\MraPlaces.h",GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);

	if (hFileInput!=INVALID_HANDLE_VALUE && hFileOutput!=INVALID_HANDLE_VALUE)
	{
		HANDLE hFileMap=CreateFileMapping(hFileInput,NULL,PAGE_READONLY,0,0,NULL);
		if (hFileMap)
		{
			LPVOID lpInput=MapViewOfFile(hFileMap,FILE_MAP_READ,0,0,0);
			if (lpInput)
			{
				char szBuff[MAX_PATH],szWriteBuff[MAX_PATH],szU[2]={'"',0};
				BOOL bFounded;
				SIZE_T dwFileSize=GetFileSize(hFileInput,NULL);
				LPVOID lpCurrentPos=lpInput;
				DWORD dwPlaceID,dwCityID,dwCountryID,dwArr[16384],dwWriteBuffSize,dwNumberOfBytesWritten;
				LPSTR lpszCountry,lpszCity,lpszPlace;
				SIZE_T i,dwCountrySize,dwCitySize,dwPlaceSize,dwUsedCount;


				dwWriteBuffSize=wsprintfA(szWriteBuff,"#if !defined(AFX_MRA_PLACES_H__INCLUDED_)\r\n#define AFX_MRA_PLACES_H__INCLUDED_\r\n\r\n\r\n\r\ntypedef struct\r\n{\r\n	DWORD	dwCountryID;\r\n	DWORD	dwCityID;\r\n	DWORD	dwPlaceID;\r\n	LPWSTR	lpszData;\r\n} MRA_PLACE;\r\n\r\n\r\n\r\n");
				DebugPrintCRLFA(szWriteBuff);
				WriteFile(hFileOutput,szWriteBuff,dwWriteBuffSize,&dwNumberOfBytesWritten,NULL);

				dwWriteBuffSize=wsprintfA(szWriteBuff,"MRA_PLACE mrapPlaces[]=\r\n{\r\n");
				DebugPrintA(szWriteBuff);
				WriteFile(hFileOutput,szWriteBuff,dwWriteBuffSize,&dwNumberOfBytesWritten,NULL);


				lpCurrentPos=lpInput;
				dwUsedCount=0;
				ZeroMemory(&dwArr,sizeof(dwArr));
				while(GetData(lpInput,dwFileSize,&lpCurrentPos,&dwPlaceID,&dwCityID,&dwCountryID,&lpszCountry,&dwCountrySize,&lpszCity,&dwCitySize,&lpszPlace,&dwPlaceSize)==NO_ERROR)
				{
					if (dwCountrySize)
					{
						bFounded=FALSE;
						for(i=0;i<dwUsedCount;i++)
						{
							if (dwArr[i]==dwCountryID) {bFounded=TRUE;break;}
						}

						if (bFounded==FALSE)
						{
							dwArr[dwUsedCount]=dwCountryID;
							dwUsedCount++;

							CopyMemory(szBuff,lpszCountry,dwCountrySize);
							szBuff[dwCountrySize]=0;
							dwWriteBuffSize=wsprintfA(szWriteBuff,"	{%ld,	0,	0,	L%s%s%s},\r\n",dwCountryID,szU,szBuff,szU);
							DebugPrintA(szWriteBuff);
							WriteFile(hFileOutput,szWriteBuff,dwWriteBuffSize,&dwNumberOfBytesWritten,NULL);
						}
					}
				}// end while



				lpCurrentPos=lpInput;
				dwUsedCount=0;
				ZeroMemory(&dwArr,sizeof(dwArr));
				while(GetData(lpInput,dwFileSize,&lpCurrentPos,&dwPlaceID,&dwCityID,&dwCountryID,&lpszCountry,&dwCountrySize,&lpszCity,&dwCitySize,&lpszPlace,&dwPlaceSize)==NO_ERROR)
				{
					if (dwCitySize)
					{
						bFounded=FALSE;
						for(i=0;i<dwUsedCount;i++)
						{
							if (dwArr[i]==dwCityID) {bFounded=TRUE;break;}
						}

						if (bFounded==FALSE)
						{
							dwArr[dwUsedCount]=dwCityID;
							dwUsedCount++;

							CopyMemory(szBuff,lpszCity,dwCitySize);
							//CopyMemory(szBuff,lpszPlace,dwPlaceSize);
							szBuff[dwCitySize]=0;
							dwWriteBuffSize=wsprintfA(szWriteBuff,"	{%ld,	%ld,	0,	L%s%s%s},\r\n",dwCountryID,dwCityID,szU,szBuff,szU);
							DebugPrintA(szWriteBuff);
							WriteFile(hFileOutput,szWriteBuff,dwWriteBuffSize,&dwNumberOfBytesWritten,NULL);
						}
					}
				}// end while


				lpCurrentPos=lpInput;
				dwUsedCount=0;
				ZeroMemory(&dwArr,sizeof(dwArr));
				while(GetData(lpInput,dwFileSize,&lpCurrentPos,&dwPlaceID,&dwCityID,&dwCountryID,&lpszCountry,&dwCountrySize,&lpszCity,&dwCitySize,&lpszPlace,&dwPlaceSize)==NO_ERROR)
				{
					if (dwPlaceSize)
					{
						bFounded=FALSE;
						for(i=0;i<dwUsedCount;i++)
						{
							if (dwArr[i]==dwPlaceID) {bFounded=TRUE;break;}
						}

						if (bFounded==FALSE)
						{
							dwArr[dwUsedCount]=dwPlaceID;
							dwUsedCount++;

							CopyMemory(szBuff,lpszPlace,dwPlaceSize);
							szBuff[dwPlaceSize]=0;
							dwWriteBuffSize=wsprintfA(szWriteBuff,"	{%ld,	%ld,	%ld,	L%s%s%s},\r\n",dwCountryID,dwCityID,dwPlaceID,szU,szBuff,szU);
							DebugPrintA(szWriteBuff);
							WriteFile(hFileOutput,szWriteBuff,dwWriteBuffSize,&dwNumberOfBytesWritten,NULL);
						}
					}
				}// end while*/


				dwWriteBuffSize=wsprintfA(szWriteBuff,"	{0,	0,	0,	NULL}\r\n};\r\n");
				DebugPrintA(szWriteBuff);
				WriteFile(hFileOutput,szWriteBuff,dwWriteBuffSize,&dwNumberOfBytesWritten,NULL);

				dwWriteBuffSize=wsprintfA(szWriteBuff,"\r\n\r\n\r\n\r\n#endif // !defined(AFX_MRA_PLACES_H__INCLUDED_)");
				DebugPrintCRLFA(szWriteBuff);
				WriteFile(hFileOutput,szWriteBuff,dwWriteBuffSize,&dwNumberOfBytesWritten,NULL);

				UnmapViewOfFile(lpInput);
			}
			CloseHandle(hFileMap);
		}
	}
	CloseHandle(hFileInput);
	CloseHandle(hFileOutput);

return(dwRet);
}


DWORD GetData(LPVOID lpBuff,SIZE_T dwBuffSize,LPVOID *plpCurrentPos,DWORD *pdwID,DWORD *pdwCityID,DWORD *pdwCountryID,LPSTR *plpszCountry,SIZE_T *pdwCountrySize,LPSTR *plpszCity,SIZE_T *pdwCitySize,LPSTR *plpszPlace,SIZE_T *pdwPlaceSize)
{
	DWORD dwRet;
	DWORD dwID=0,dwCityID=0,dwCountryID=0;
	LPSTR lpszTemp,lpszEnd,lpszCurrentPos=(LPSTR)(*plpCurrentPos),lpszCountry=NULL,lpszCity=NULL,lpszPlace=NULL;
	SIZE_T dwCountrySize=0,dwCitySize=0,dwPlaceSize=0;
	BYTE btCRLF[2]={13,10};

	lpszEnd=(LPSTR)MemoryFind(((SIZE_T)lpszCurrentPos-(SIZE_T)lpBuff),lpBuff,dwBuffSize,&btCRLF,2);
	if (lpszEnd==NULL) lpszEnd=((LPSTR)lpBuff+dwBuffSize);

	lpszTemp=(LPSTR)MemoryFind(((SIZE_T)lpszCurrentPos-(SIZE_T)lpBuff),lpBuff,dwBuffSize,"	",1);
	if (lpszTemp)
	{
		dwID=StrToUNum32(lpszCurrentPos,(lpszTemp-lpszCurrentPos));
		lpszCurrentPos=(lpszTemp+1);

		lpszTemp=(LPSTR)MemoryFind(((SIZE_T)lpszCurrentPos-(SIZE_T)lpBuff),lpBuff,dwBuffSize,"	",1);
		if (lpszTemp)
		{
			dwCityID=StrToUNum32(lpszCurrentPos,(lpszTemp-lpszCurrentPos));
			lpszCurrentPos=(lpszTemp+1);

			lpszTemp=(LPSTR)MemoryFind(((SIZE_T)lpszCurrentPos-(SIZE_T)lpBuff),lpBuff,dwBuffSize,"	",1);
			if (lpszTemp)
			{
				dwCountryID=StrToUNum32(lpszCurrentPos,(lpszTemp-lpszCurrentPos));
				lpszCurrentPos=(lpszTemp+1);

				lpszTemp=(LPSTR)MemoryFind(((SIZE_T)lpszCurrentPos-(SIZE_T)lpBuff),lpBuff,dwBuffSize,",",1);
				if (lpszTemp && lpszTemp<=lpszEnd)
				{
					lpszCountry=lpszCurrentPos;
					dwCountrySize=(lpszTemp-lpszCurrentPos);
					lpszCurrentPos=(lpszTemp+1);

					lpszTemp=(LPSTR)MemoryFind(((SIZE_T)lpszCurrentPos-(SIZE_T)lpBuff),lpBuff,dwBuffSize,",",1);
					if (lpszTemp && lpszTemp<=lpszEnd)
					{
						lpszCity=lpszCurrentPos;
						dwCitySize=(lpszTemp-lpszCurrentPos);
						lpszCurrentPos=(lpszTemp+1);

						lpszTemp=(LPSTR)MemoryFind(((SIZE_T)lpszCurrentPos-(SIZE_T)lpBuff),lpBuff,dwBuffSize,szCRLF,2);
						if (lpszTemp && lpszTemp<=lpszEnd)
						{
							lpszPlace=lpszCurrentPos;
							dwPlaceSize=(lpszTemp-lpszCurrentPos);
							lpszCurrentPos=(lpszTemp+1);
						}else{
							lpszPlace=lpszCurrentPos;
							dwPlaceSize=(lpszEnd-lpszCurrentPos);
							lpszCurrentPos=(lpszEnd+1);
						}
					}else{
						lpszCity=lpszCurrentPos;
						dwCitySize=(lpszEnd-lpszCurrentPos);
						lpszCurrentPos=(lpszEnd+1);
					}
				}else{
					lpszCountry=lpszCurrentPos;
					dwCountrySize=(lpszEnd-lpszCurrentPos);
					lpszCurrentPos=(lpszEnd+1);
				}
			}
		}
	}

	if (((SIZE_T)lpszCurrentPos-(SIZE_T)lpBuff)<(dwBuffSize-1))
	{
		(*plpCurrentPos)=lpszCurrentPos;
		(*pdwID)=dwID;
		(*pdwCityID)=dwCityID;
		(*pdwCountryID)=dwCountryID;
		(*plpszCountry)=lpszCountry;
		(*pdwCountrySize)=dwCountrySize;
		(*plpszCity)=lpszCity;
		(*pdwCitySize)=dwCitySize;
		(*plpszPlace)=lpszPlace;
		(*pdwPlaceSize)=dwPlaceSize;
		dwRet=NO_ERROR;
	}else{
		dwRet=1;
	}

return(dwRet);
}
