
#include "mebeam.h"
#include "resource.h"

#define MEBEAM_SERVICE "Mebeam/Launch"

#if defined( _UNICODE )
	typedef WCHAR RPCCHAR;
#else
	typedef BYTE RPCCHAR;
#endif

#if defined( _UNICODE )
	// {9CE1EA25-0C48-4e29-8AF3-34B6DFAD265B}
	#define MIID_MEBEAM { 0x9ce1ea25, 0xc48, 0x4e29, { 0x8a, 0xf3, 0x34, 0xb6, 0xdf, 0xad, 0x26, 0x5b }}
#else
	#define MIID_MEBEAM { 0xfa191a81, 0x4e19, 0x4b2e, { 0xbf, 0xc8, 0x66, 0x74, 0xba, 0x4c, 0x92, 0xd6 } }
#endif

PLUGINLINK *pluginLink;
HINSTANCE hInst;

PLUGININFO pluginInfo = {
	sizeof(PLUGININFO),
	"Support for www.mebeam.com online video & audio",
	PLUGIN_MAKE_VERSION(0,2,0,0),
	"Allows people to support video & audio chats.",
	"George Hazan",
	"ghazan@miranda-im.org",
	"� 2008 George Hazan",
	"http://www.miranda-im.org",
	UNICODE_AWARE,
	0
};

PLUGININFOEX pluginInfoEx = {
	sizeof(PLUGININFOEX),
	"Support for www.mebeam.com online video & audio",
	PLUGIN_MAKE_VERSION(0,2,0,0),
	"Allows people to support video & audio chats.",
	"George Hazan",
	"ghazan@miranda-im.org",
	"� 2008 George Hazan",
	"http://www.miranda-im.org",
	UNICODE_AWARE,
	0,
	MIID_MEBEAM
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst = hinstDLL;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////////////
// MirandaPluginInfoEx - returns an information about a plugin

extern "C" __declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	if (mirandaVersion < PLUGIN_MAKE_VERSION(0, 6, 0, 0))
		return NULL;

	return &pluginInfoEx;
}

extern "C" __declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	if (mirandaVersion < PLUGIN_MAKE_VERSION(0, 5, 0, 0))
		return NULL;

	return &pluginInfo;
}

/////////////////////////////////////////////////////////////////////////////////////////
// MirandaPluginInterfaces - returns the protocol interface to the core

static const MUUID interfaces[] = { MIID_MEBEAM, MIID_LAST };

extern "C" __declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

/////////////////////////////////////////////////////////////////////////////////////////
// Performs a primary set of actions upon plugin loading

static int LaunchSession(WPARAM wParam, LPARAM lParam)
{
	UUID uuid;
	UuidCreate( &uuid );

	RPCCHAR* uuidStr;
	UuidToString( &uuid, &uuidStr );

	TCHAR msg[ 401 ];
	#if defined( _UNICODE )
		msg[ 0 ] = ' ';
		mir_sntprintf( msg+1, SIZEOF( msg )-1,
			TranslateT( "You are invited to video chat at http://www.mebeam.com/miranda.php?mir_%s" ), uuidStr );
	#else
		mir_sntprintf( msg, SIZEOF( msg ),
			TranslateT( "You are invited to video chat at http://www.mebeam.com/miranda.php?mir_%s" ), uuidStr );
	#endif
	CallContactService(( HANDLE )wParam, PSS_MESSAGE, PREF_TCHAR, (LPARAM)msg );

	mir_sntprintf( msg, SIZEOF( msg ), _T("http://www.mebeam.com/miranda.php?mir_%s"), uuidStr );
	ShellExecute( NULL, _T("open"), msg, NULL, NULL, SW_SHOW );

	RpcStringFree( &uuidStr );
	return 0;
}

extern "C" int __declspec(dllexport) Load(PLUGINLINK *link)
{
	pluginLink = link;

	CreateServiceFunction(MEBEAM_SERVICE, LaunchSession);
	{
		CLISTMENUITEM mi = { 0 };
		mi.cbSize = sizeof(mi);
		mi.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_MEBEAM));
		mi.pszName = LPGEN("Start MeBeam video chat");
		mi.position = 500050010;
		mi.flags = CMIF_NOTOFFLINE;
		mi.pszService = MEBEAM_SERVICE;
		CallService(MS_CLIST_ADDCONTACTMENUITEM, 0, (LPARAM)&mi);
	}

	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////
// Unload a plugin

extern "C" int __declspec(dllexport) Unload(void)
{
	return 0;
}
