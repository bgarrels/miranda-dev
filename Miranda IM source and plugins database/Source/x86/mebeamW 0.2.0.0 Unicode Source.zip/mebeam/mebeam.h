
#if !defined( _UNICODE ) && defined( UNICODE )
	#define _UNICODE
#endif

#include <tchar.h>

#include <windows.h>
#include <rpc.h>

#include <stdio.h>

#include <newpluginapi.h>
#include <m_langpack.h>
#include <m_system.h>
#include <m_database.h>
#include <m_protocols.h>
#include <m_protosvc.h>
#include <m_protomod.h>
#include <m_utils.h>
#include <m_findadd.h>
#include <m_clist.h>
#include <win2k.h>
