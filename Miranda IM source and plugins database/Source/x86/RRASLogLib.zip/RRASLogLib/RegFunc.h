#if !defined(AFX_REGFUNC__H__INCLUDED_)
#define AFX_REGFUNC__H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000




////////////////////Regestry functions//////////////////////////////////
__inline LONG RegGetSize(HKEY hKey,LPCTSTR lpszValueName,PDWORD pdwcbData)
{
return(RegQueryValueEx(hKey,lpszValueName,NULL,0,0,pdwcbData));
}


__inline LONG RegReadData(HKEY hKey,LPCTSTR lpszValueName,DWORD dwType,LPBYTE lpData,PDWORD pdwcbData)
{
return(RegQueryValueEx(hKey,lpszValueName,NULL,&dwType,lpData,pdwcbData));
}


__inline LONG RegWriteData(HKEY hKey,LPCTSTR lpszValueName,DWORD dwType,CONST BYTE *lpData,DWORD cbData)
{
return(RegSetValueEx(hKey,lpszValueName,0,dwType,lpData,cbData));
}


__inline LONG RegGetBinary(HKEY hKey,LPCTSTR lpszValueName,PBYTE pb,PDWORD pcbData)
{
return(RegReadData(hKey,lpszValueName,REG_BINARY,pb,pcbData));
}


__inline LONG RegSetBinary(HKEY hKey,LPCTSTR lpszValueName,CONST BYTE *pb,DWORD cbData)
{
return(RegWriteData(hKey,lpszValueName,REG_BINARY,pb,cbData));
}


__inline LONG RegGetDWORD(HKEY hKey,LPCTSTR lpszValueName,PDWORD pdwData)
{
	DWORD cbData=sizeof(DWORD);
return(RegReadData(hKey,lpszValueName,REG_DWORD,(PBYTE)pdwData,&cbData));
}


__inline LONG RegSetDWORD(HKEY hKey,LPCTSTR lpszValueName,DWORD dwData)
{
return(RegWriteData(hKey,lpszValueName,REG_DWORD,(PBYTE)&dwData,sizeof(DWORD)));
}


__inline LONG RegGetString(HKEY hKey,LPCTSTR lpszValueName,LPTSTR lpszData,PDWORD pdwData)
{
return(RegReadData(hKey,lpszValueName,REG_SZ,(PBYTE)lpszData,pdwData));
}


__inline LONG RegSetString(HKEY hKey,LPCTSTR lpszValueName,LPCTSTR lpcszData)
{
return(RegWriteData(hKey,lpszValueName,REG_SZ,(PBYTE)lpcszData,(sizeof(TCHAR)*(lstrlen(lpcszData)+1))));
}


__inline LONG RegSetStringEx(HKEY hKey,LPCTSTR lpszValueName,LPCTSTR lpcszData,DWORD cbData)
{
return(RegWriteData(hKey,lpszValueName,REG_SZ,(PBYTE)lpcszData,(sizeof(TCHAR)*(cbData+1))));
}


__inline LONG RegGetMultiString(HKEY hKey,LPCTSTR lpszValueName,LPTSTR lpszData,PDWORD pdwData)
{
return(RegReadData(hKey,lpszValueName,REG_MULTI_SZ,(PBYTE)lpszData,pdwData));
}


__inline LONG RegSetMultiString(HKEY hKey,LPCTSTR lpszValueName,LPCTSTR lpcszData)
{
	DWORD dwLen;
	for (dwLen=0;lpcszData[dwLen]!=0;dwLen+=(lstrlen(&lpcszData[dwLen])+1));
return(RegWriteData(hKey,lpszValueName,REG_MULTI_SZ,(PBYTE)lpcszData,(sizeof(TCHAR)*(dwLen+1))));
}
////////////////////////////////////////////////////////////////////////


#endif // !defined(AFX_REGFUNC__H__INCLUDED_)
