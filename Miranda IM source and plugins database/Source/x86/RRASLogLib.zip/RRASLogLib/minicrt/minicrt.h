#if !defined(AFX_MINI_CRT__H__INCLUDED_)
#define AFX_MINI_CRT__H__INCLUDED_

//!!!!!!!
// C/C++ -> Optimization -> Enable Instrinsic functions = NO
// C/C++ -> Optimization -> Whole Program Optimization = NO
// C/C++ -> Code Generation -> Runtime Library = Multi-threaded (/MT)


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>

//#include <..\minicrt\x86stub.h>
#include <..\minicrt\memfuncs.h>
#include <..\minicrt\timefuncs.h>









#endif // !defined(AFX_MINI_CRT__H__INCLUDED_)
