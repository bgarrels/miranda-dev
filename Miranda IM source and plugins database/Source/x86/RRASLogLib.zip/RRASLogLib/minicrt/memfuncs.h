#if !defined(AFX_MEM_FUNCS__H__INCLUDED_)
#define AFX_MEM_FUNCS__H__INCLUDED_



#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
//#include <intrin.h>


//#pragma function(memcmp)
//#pragma function(memcpy)
//#pragma function(memset)
//#pragma function(memchr)
//#pragma intrinsic(memcmp)
//#pragma intrinsic(memcpy)
//#pragma intrinsic(memset)


//#pragma intrinsic(__movsb)
//#pragma intrinsic(__stosb)

#define memcpy memmove
//#define _memcpy memcpy
//#define _memset memset



static  int memcmp(const void *pv1,const void *pv2,size_t count)
{
    if (!count) return(0);

	unsigned char *pbv1=(unsigned char*)pv1,*pbv2=(unsigned char*)pv2;

    while(--count && (*(pbv1++))==(*(pbv2++)));

return((*(pbv1))-(*(pbv2)));
}//*/



inline void *memset(void *pvDst,int val,size_t count)
{
#if defined (_M_IA64) || defined (_M_AMD64)
        {
        __declspec(dllimport) void RtlFillMemory( void *, size_t count, char );
        RtlFillMemory( pvDst, count, (char)val );
        }
#else // defined (_M_IA64) || defined (_M_AMD64) 
        unsigned char *pbDst=(unsigned char*)pvDst;
		unsigned char bVal=(unsigned char)val;

		//while(count--) (*(pbDst++))=bVal;
		__asm{//__stosb((unsigned char*)pvDst,(unsigned char)val,count);
			mov edi,pvDst
			mov al,bVal
			mov ecx,count
			rep stos
	  }
#endif  // defined (_M_IA64) || defined (_M_AMD64) 
return(pvDst);
}//*/

static void *memmove(void *pvDst,const void *pvSrc,size_t count)
{
#if defined (_M_IA64) || defined (_M_AMD64)
		{
			//__declspec(dllimport) void RtlMoveMemory(void*,const void*,size_t count);
			//RtlMoveMemory(dst,src,count);
		}
#else  // defined (_M_IA64) || defined (_M_AMD64) 
		unsigned char *pbDst=(unsigned char*)pvDst,*pbSrc=(unsigned char*)pvSrc;

		if (pvDst<=pvSrc || (char*)pvDst>=((char*)pvSrc+count)) 
		{// Non-Overlapping Buffers copy from lower addresses to higher addresses
			//while(count--) (*(pbDst++))=(*(pbSrc++));
			__asm{//__movsb((unsigned char*)pvDst,(const unsigned char*)pvSrc,count);
				mov edi,pvDst
				mov esi,pvSrc
				mov ecx,count
				rep movsb
		  }
		}else{// Overlapping Buffers copy from higher addresses to lower addresses
			pbDst+=(count-1);
			pbSrc+=(count-1);

			while(count--) (*(pbDst--))=(*(pbSrc--));
		}
#endif // defined (_M_IA64) || defined (_M_AMD64) 
return(pvDst);
}


static  const void *memchr(const void *buf,int chr,size_t count)
{
	unsigned char *pbBuff=(unsigned char*)buf;
	while(count-- && ((*++pbBuff)!=(unsigned char)chr));
return(count?(void*)pbBuff:NULL);
}//*/









#endif // !defined(AFX_MEM_FUNCS__H__INCLUDED_)
