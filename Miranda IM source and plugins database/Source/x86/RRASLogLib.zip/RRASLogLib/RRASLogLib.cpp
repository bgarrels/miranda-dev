////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
// By Rozhuk Ivan, 2007 year
// ����� ����, 2007 ���
// Nick: Ivan 83
// ICQ: 179365117
// e-mail: Rozhuk.IM@gmail.com
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

// if you remove all SEH sections, you can remove "RunTmChk.lib" from project


#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#define WINVER       0x0500
#define _WIN32_WINNT 0x0500
#define UNICODE
#define _UNICODE

#ifdef NDEBUG
	#pragma optimize("gsy",on)
	#pragma comment(linker,"/subsystem:Windows,5")
	#pragma comment(linker,"/version:5")

	#pragma comment(linker,"/nodefaultlib")
	//#pragma comment(linker,"/GS")
	//#pragma comment(linker,"/merge:.rdata=.text /merge:.data=.text")
	//#pragma comment(linker,"/verbose")
	#pragma comment(linker,"/ENTRY:DllMain")

#endif //_DEBUG*/



#include "resource.h"
#include <windows.h>
#include <Mprapi.h>
#include "RegFunc.h"
#include "CRCFileCheck.h"
#ifdef NDEBUG
	#include <..\minicrt\minicrt.h>

extern "C" __declspec(naked) void __cdecl _chkstk()
{
	#define _PAGESIZE_ 4096

			__asm
			{
			push    ecx

	; Calculate new TOS.

			lea     ecx, [esp] + 8 - 4      ; TOS before entering function + size for ret value
			sub     ecx, eax                ; new TOS

	; Handle allocation size that results in wraparound.
	; Wraparound will result in StackOverflow exception.

			sbb     eax, eax                ; 0 if CF==0, ~0 if CF==1
			not     eax                     ; ~0 if TOS did not wrapped around, 0 otherwise
			and     ecx, eax                ; set to 0 if wraparound

			mov     eax, esp                ; current TOS
			and     eax, not ( _PAGESIZE_ - 1) ; Round down to current page boundary

	cs10:
			cmp     ecx, eax                ; Is new TOS
			jb      short cs20              ; in probed page?
			mov     eax, ecx                ; yes.
			pop     ecx
			xchg    esp, eax                ; update esp
			mov     eax, dword ptr [eax]    ; get return address
			mov     dword ptr [esp], eax    ; and put it at new TOS
			ret

	; Find next lower page and probe
	cs20:
			sub     eax, _PAGESIZE_         ; decrease by PAGESIZE
			test    dword ptr [eax],eax     ; probe page.
			jmp     short cs10

			}
}//

#endif //_DEBUG*/




#define MAX_PATH_LEN		32768
#define CS_SPINCOUNT		1000
#define MAX_LOG_ENTRY_SIZE	2064
#define MIN_LOG_FILE_SIZE	(1024*1024) // 1 mb


#define LOG_ACTIONS_CONN_ACCEPT_NEW		0
#define LOG_ACTIONS_CONN_HANGUP			1
#define LOG_ACTIONS_LINK_ACCEPT_NEW		2
#define LOG_ACTIONS_LINK_HANGUP			3


#define LOG_FILE_NAME_ROTATE_NEWER		0
#define LOG_FILE_NAME_ROTATE_YEARLY		1
#define LOG_FILE_NAME_ROTATE_MONTHLY	2
#define LOG_FILE_NAME_ROTATE_DAILY		3
#define LOG_FILE_NAME_ROTATE_HOURLY		4



#define DEF_USE_GMT_TIME				FALSE
#define DEF_REJ_USERS_ON_LOG_FAILURE	FALSE
#define DEF_LOG_ACTIONS					0xffffffff
#define DEF_LOG_FILE_NAME_ROTATE		LOG_FILE_NAME_ROTATE_NEWER
#define DEF_MAX_LOG_FILE_SIZE			0
#define DEF_LOG_FILES_PATH				TEXT("\\LogFiles\\RRAS") // %system%\DEF_LOG_FILES_PATH


static LPCWSTR
#ifdef NDEBUG
	lpcszSettingsKey							=L"SOFTWARE\\Microsoft\\Ras\\AdminDll\\RRASLogLib",
#else
	lpcszSettingsKey							=L"SOFTWARE\\RRASLogLib",
#endif //_DEBUG*/
	lpcszUseGMTTimeValueName					=L"UseGMTTime",
	lpcszRejectUsersOnLogFailureValueName		=L"RejectUsersOnLogFailure",
	lpcszLogActionsValueName					=L"LogActions",
	lpcszLogRotateIntervalValueName				=L"LogRotateInterval",
	lpcszMaxLogFileSizeValueName				=L"MaxLogFileSize",
	lpcszLogFilesPathValueName					=L"LogFilesPath"
	;

#ifdef NDEBUG
#define HKEY_SETTINGS HKEY_LOCAL_MACHINE
#else
#define HKEY_SETTINGS HKEY_CURRENT_USER
#endif //_DEBUG*/



// ��������� ��� �������� ��������
struct PROCESS_SETTINGS
{
	BOOL				bIsInitialized;					// *
	HANDLE				hModule;						// *�������� ��������
	HANDLE				hMemAllocHandle;				// *heap for fast allocate memory
	
	CRITICAL_SECTION	cs;								// *
	HANDLE				hLogFile;						// *
	SIZE_T				dwEntryesCount;					// *
	SYSTEMTIME			stLogFileOpenTime;				// *
	LARGE_INTEGER		liLogFileSize;					// *

	BOOL				bUseGMTTime;					// ����� �� ��������, � �� �������
	BOOL				bRejectUsersOnLogFailure;		// �� ���������� �������������, ���� �� �������� �������� � ���
	DWORD				dwLogActions;					// ����� ������� ����������
	DWORD				dwLogRotateInterval;			// ����� ��������� ����� ���� ����
	DWORD				dwMaxLogFileSize;				// ���� ������ �����, 0 - �� �����������

	WCHAR				wszLogFilesPath[MAX_PATH_LEN];
	SIZE_T				dwLogFilesPathLen;
};

static PROCESS_SETTINGS			psProcessSettings;


DWORD LogFileOpen();
void LogFileClose();
BOOL LogFileIsCreateNew();
DWORD LogFileDataWrite(DWORD dwAction,HANDLE hPort,HANDLE hConnection,LPWSTR lpwszAddress,LPWSTR lpwszRemoteAddress,DWORD dwTotalNumberOfCalls,DWORD dwConnectDuration,LPWSTR lpwszPortName,LPWSTR lpwszMediaName,LPWSTR lpwszDeviceName,LPWSTR lpwszDeviceType,DWORD dwConnectionFlags,LPWSTR lpwszUserName,LPWSTR lpwszLogonDomain,LPWSTR lpwszRemoteComputer,DWORD dwLineSpeed,DWORD dwBytesXmited,DWORD dwBytesRcved,DWORD dwFramesXmited,DWORD dwFramesRcved,DWORD dwCrcErr,DWORD dwTimeoutErr,DWORD dwAlignmentErr,DWORD dwHardwareOverrunErr,DWORD dwFramingErr,DWORD dwBufferOverrunErr,DWORD dwCompressionRatioIn,DWORD dwCompressionRatioOut);


BOOL IsFileExist(LPCTSTR lpszFileName);
BOOL IsPathExist(LPCTSTR lpcszPath);
BOOL CreatePath(LPCTSTR lpcszPath);




BOOL WINAPI DllMain(HANDLE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
	BOOL bRet=FALSE;

    switch(ul_reason_for_call){
	case DLL_PROCESS_ATTACH:
		if (CRCFileCheck()==NO_ERROR)
		{// ����������� ����� ����� � �������
			ZeroMemory(&psProcessSettings,sizeof(psProcessSettings));
			psProcessSettings.hMemAllocHandle=GetProcessHeap();
			psProcessSettings.hModule=hModule;
			psProcessSettings.hLogFile=INVALID_HANDLE_VALUE;

			DisableThreadLibraryCalls((HMODULE)hModule);
			bRet=TRUE;
		}
		break;
	case DLL_PROCESS_DETACH:
		bRet=TRUE;
		break;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
    }
return(bRet);
}


DWORD APIENTRY MprAdminInitializeDll(void)
{
	DWORD dwRet;

	__try
	{// begin SEH frame
		if (psProcessSettings.bIsInitialized==FALSE)
		{
			HKEY hKey;

			// HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER
			RegCreateKeyEx(HKEY_SETTINGS,lpcszSettingsKey,0,NULL,REG_OPTION_NON_VOLATILE,KEY_QUERY_VALUE,NULL,&hKey,NULL);// ���� ���������� � �������
			if (ERROR_SUCCESS!=RegGetDWORD(hKey,lpcszUseGMTTimeValueName,(DWORD*)&psProcessSettings.bUseGMTTime))							psProcessSettings.bUseGMTTime=DEF_USE_GMT_TIME;
			if (ERROR_SUCCESS!=RegGetDWORD(hKey,lpcszRejectUsersOnLogFailureValueName,(DWORD*)&psProcessSettings.bRejectUsersOnLogFailure))	psProcessSettings.bRejectUsersOnLogFailure=DEF_REJ_USERS_ON_LOG_FAILURE;
			if (ERROR_SUCCESS!=RegGetDWORD(hKey,lpcszLogActionsValueName,&psProcessSettings.dwLogActions))									psProcessSettings.dwLogActions=DEF_LOG_ACTIONS;
			if (ERROR_SUCCESS!=RegGetDWORD(hKey,lpcszLogRotateIntervalValueName,&psProcessSettings.dwLogRotateInterval))					psProcessSettings.dwLogRotateInterval=DEF_LOG_FILE_NAME_ROTATE;
			if (ERROR_SUCCESS!=RegGetDWORD(hKey,lpcszMaxLogFileSizeValueName,&psProcessSettings.dwMaxLogFileSize))
			{
				psProcessSettings.dwMaxLogFileSize=DEF_MAX_LOG_FILE_SIZE;
			}else{
				if (psProcessSettings.dwMaxLogFileSize<MIN_LOG_FILE_SIZE) psProcessSettings.dwMaxLogFileSize=MIN_LOG_FILE_SIZE;
			}

			psProcessSettings.dwLogFilesPathLen=(MAX_PATH_LEN*sizeof(WCHAR));
			if (ERROR_SUCCESS==RegGetString(hKey,lpcszLogFilesPathValueName,psProcessSettings.wszLogFilesPath,&psProcessSettings.dwLogFilesPathLen))
			{// ��������� ���� �� �������
				psProcessSettings.dwLogFilesPathLen/=sizeof(WCHAR);
				psProcessSettings.dwLogFilesPathLen--;
				if (psProcessSettings.dwLogFilesPathLen)
				while(psProcessSettings.wszLogFilesPath[(psProcessSettings.dwLogFilesPathLen-1)]=='\\')
				{// ������� ��� \ � ����� ����
					psProcessSettings.dwLogFilesPathLen--;
					psProcessSettings.wszLogFilesPath[psProcessSettings.dwLogFilesPathLen]=0;
					if (psProcessSettings.dwLogFilesPathLen==0) break;
				}
			}else{// ���������� �� ���������: %system32%\LogFiles\RRAS
				psProcessSettings.dwLogFilesPathLen=GetSystemDirectory(psProcessSettings.wszLogFilesPath,MAX_PATH_LEN);
				if (psProcessSettings.dwLogFilesPathLen)
				{
					CopyMemory((psProcessSettings.wszLogFilesPath+psProcessSettings.dwLogFilesPathLen),DEF_LOG_FILES_PATH,sizeof(DEF_LOG_FILES_PATH));
					psProcessSettings.dwLogFilesPathLen+=((sizeof(DEF_LOG_FILES_PATH)/sizeof(WCHAR))-1);
				}
			}
			RegCloseKey(hKey);

			if (psProcessSettings.dwLogFilesPathLen)
			{
				if (InitializeCriticalSectionAndSpinCount(&psProcessSettings.cs,(CS_SPINCOUNT | 0x80000000)))
				{
					CreatePath(psProcessSettings.wszLogFilesPath);
					psProcessSettings.bIsInitialized=TRUE;
					if ((dwRet=LogFileOpen())!=NO_ERROR)
					{
						psProcessSettings.bIsInitialized=FALSE;
						DeleteCriticalSection(&psProcessSettings.cs);
					}
				}else{
					dwRet=GetLastError();
				}
			}else{
				if ((dwRet=GetLastError())==NO_ERROR) dwRet=ERROR_BAD_PATHNAME;
			}
		}else{
			dwRet=ERROR_ALREADY_INITIALIZED;
		}
	}__except(EXCEPTION_EXECUTE_HANDLER){
		dwRet=ERROR_NOACCESS;
	}
return(dwRet);
}

DWORD APIENTRY MprAdminTerminateDll(void)
{
	DWORD dwRet;

	__try
	{// begin SEH frame
		if (psProcessSettings.bIsInitialized)
		{
			LogFileClose();
			DeleteCriticalSection(&psProcessSettings.cs);
			ZeroMemory(&psProcessSettings,sizeof(psProcessSettings));
			dwRet=NO_ERROR;
		}else{
			dwRet=ERROR_INVALID_HANDLE_STATE;
		}
	}__except(EXCEPTION_EXECUTE_HANDLER){
		dwRet=ERROR_NOACCESS;
	}
return(dwRet);
}



BOOL CALLBACK MprAdminAcceptNewConnection2(RAS_CONNECTION_0* pRasConnection0,RAS_CONNECTION_1* pRasConnection1,RAS_CONNECTION_2* pRasConnection2)
{
	BOOL bRet=TRUE;

	__try
	{// begin SEH frame
		if (pRasConnection0 && pRasConnection1)
		if (LogFileDataWrite(LOG_ACTIONS_CONN_ACCEPT_NEW,0,pRasConnection0->hConnection,pRasConnection1->PppInfo.ip.wszAddress,pRasConnection1->PppInfo.ip.wszRemoteAddress,0,pRasConnection0->dwConnectDuration,TEXT("-"),TEXT("-"),TEXT("-"),TEXT("-"),pRasConnection0->dwConnectionFlags,pRasConnection0->wszUserName,pRasConnection0->wszLogonDomain,pRasConnection0->wszRemoteComputer,0,pRasConnection1->dwBytesXmited,pRasConnection1->dwBytesRcved,pRasConnection1->dwFramesXmited,pRasConnection1->dwFramesRcved,pRasConnection1->dwCrcErr,pRasConnection1->dwTimeoutErr,pRasConnection1->dwAlignmentErr,pRasConnection1->dwHardwareOverrunErr,pRasConnection1->dwFramingErr,pRasConnection1->dwBufferOverrunErr,pRasConnection1->dwCompressionRatioIn,pRasConnection1->dwCompressionRatioOut)!=NO_ERROR)
		{
			bRet=FALSE;
		}
	}__except(EXCEPTION_EXECUTE_HANDLER){
		bRet=FALSE;// ��� �� ������ ������, �� ����� ���������, �� ������ ��������
	}
return(bRet);
}

void CALLBACK MprAdminConnectionHangupNotification2(RAS_CONNECTION_0* pRasConnection0,RAS_CONNECTION_1* pRasConnection1,RAS_CONNECTION_2* pRasConnection2)
{
	__try
	{// begin SEH frame
		if (pRasConnection0 && pRasConnection1)
		{
			LogFileDataWrite(LOG_ACTIONS_CONN_HANGUP,0,pRasConnection0->hConnection,pRasConnection1->PppInfo.ip.wszAddress,pRasConnection1->PppInfo.ip.wszRemoteAddress,0,pRasConnection0->dwConnectDuration,TEXT("-"),TEXT("-"),TEXT("-"),TEXT("-"),pRasConnection0->dwConnectionFlags,pRasConnection0->wszUserName,pRasConnection0->wszLogonDomain,pRasConnection0->wszRemoteComputer,0,pRasConnection1->dwBytesXmited,pRasConnection1->dwBytesRcved,pRasConnection1->dwFramesXmited,pRasConnection1->dwFramesRcved,pRasConnection1->dwCrcErr,pRasConnection1->dwTimeoutErr,pRasConnection1->dwAlignmentErr,pRasConnection1->dwHardwareOverrunErr,pRasConnection1->dwFramingErr,pRasConnection1->dwBufferOverrunErr,pRasConnection1->dwCompressionRatioIn,pRasConnection1->dwCompressionRatioOut);
		}
	}__except(EXCEPTION_EXECUTE_HANDLER){
	}
}


BOOL CALLBACK MprAdminAcceptNewLink(RAS_PORT_0* pRasPort0,RAS_PORT_1* pRasPort1)
{
	BOOL bRet=TRUE;

	__try
	{// begin SEH frame
		if (pRasPort0 && pRasPort1)
		if (LogFileDataWrite(LOG_ACTIONS_LINK_ACCEPT_NEW,pRasPort0->hPort,pRasPort0->hConnection,TEXT("-"),TEXT("-"),pRasPort0->dwTotalNumberOfCalls,pRasPort0->dwConnectDuration,pRasPort0->wszPortName,pRasPort0->wszMediaName,pRasPort0->wszDeviceName,pRasPort0->wszDeviceType,0,TEXT("-"),TEXT("-"),TEXT("-"),pRasPort1->dwLineSpeed,pRasPort1->dwBytesXmited,pRasPort1->dwBytesRcved,pRasPort1->dwFramesXmited,pRasPort1->dwFramesRcved,pRasPort1->dwCrcErr,pRasPort1->dwTimeoutErr,pRasPort1->dwAlignmentErr,pRasPort1->dwHardwareOverrunErr,pRasPort1->dwFramingErr,pRasPort1->dwBufferOverrunErr,pRasPort1->dwCompressionRatioIn,pRasPort1->dwCompressionRatioOut)!=NO_ERROR)
		{
			bRet=FALSE;
		}
	}__except(EXCEPTION_EXECUTE_HANDLER){
		bRet=FALSE;// ��� �� ������ ������, �� ����� ���������, �� ������ ��������
	}
return(bRet);
}

void CALLBACK MprAdminLinkHangupNotification(RAS_PORT_0* pRasPort0,RAS_PORT_1* pRasPort1)
{
	__try
	{// begin SEH frame
		if (pRasPort0 && pRasPort1)
		{
			LogFileDataWrite(LOG_ACTIONS_LINK_HANGUP,pRasPort0->hPort,pRasPort0->hConnection,TEXT("-"),TEXT("-"),pRasPort0->dwTotalNumberOfCalls,pRasPort0->dwConnectDuration,pRasPort0->wszPortName,pRasPort0->wszMediaName,pRasPort0->wszDeviceName,pRasPort0->wszDeviceType,0,TEXT("-"),TEXT("-"),TEXT("-"),pRasPort1->dwLineSpeed,pRasPort1->dwBytesXmited,pRasPort1->dwBytesRcved,pRasPort1->dwFramesXmited,pRasPort1->dwFramesRcved,pRasPort1->dwCrcErr,pRasPort1->dwTimeoutErr,pRasPort1->dwAlignmentErr,pRasPort1->dwHardwareOverrunErr,pRasPort1->dwFramingErr,pRasPort1->dwBufferOverrunErr,pRasPort1->dwCompressionRatioIn,pRasPort1->dwCompressionRatioOut);
		}
	}__except(EXCEPTION_EXECUTE_HANDLER){
	}
}


DWORD CALLBACK MprAdminGetIpAddressForUser(WCHAR* lpwszUserName,WCHAR* lpwszPortName,DWORD* lpdwIpAddress,BOOL* pbNotifyRelease)
{// �������, IP ����� ����������� ����� ��������
	//if (pbNotifyRelease) (*pbNotifyRelease)=FALSE;
return(NO_ERROR);
}

void CALLBACK MprAdminReleaseIpAddress(WCHAR* lpwszUserName,WCHAR* lpwszPortName,DWORD* lpdwIpAddress)
{// �������, IP ����� ������������� ����� ��������
}
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
DWORD LogFileOpen()
{
	DWORD dwRet;

	if (psProcessSettings.bIsInitialized)
	{
		DWORD i;
		WCHAR szLogFileName[MAX_PATH_LEN];
		HANDLE hLogFile;
		SYSTEMTIME st;

		EnterCriticalSection(&psProcessSettings.cs);
		if (psProcessSettings.bUseGMTTime)
		{
			GetSystemTime(&st);
		}else{
			GetLocalTime(&st);
		}
		CopyMemory(szLogFileName,psProcessSettings.wszLogFilesPath,(psProcessSettings.dwLogFilesPathLen*sizeof(WCHAR)));
		LogFileClose();

		for(i=0;i<1000000;i++)
		{// ���������� �����, �� ����� ���� ��� ����� � ���������� ������� �� �������
			switch(psProcessSettings.dwLogRotateInterval){
			case LOG_FILE_NAME_ROTATE_HOURLY:
				wsprintf((szLogFileName+psProcessSettings.dwLogFilesPathLen),TEXT("\\RRASLOG_ex%04lu%02lu%02lu%02lu_%04lu.w3c"),st.wYear,st.wMonth,st.wDay,st.wHour,i);
				break;
			case LOG_FILE_NAME_ROTATE_DAILY:
				wsprintf((szLogFileName+psProcessSettings.dwLogFilesPathLen),TEXT("\\RRASLOG_ex%04lu%02lu%02lu_%04lu.w3c"),st.wYear,st.wMonth,st.wDay,i);
				break;
			case LOG_FILE_NAME_ROTATE_MONTHLY:
				wsprintf((szLogFileName+psProcessSettings.dwLogFilesPathLen),TEXT("\\RRASLOG_ex%04lu%02lu_%04lu.w3c"),st.wYear,st.wMonth,i);
				break;
			case LOG_FILE_NAME_ROTATE_YEARLY:
				wsprintf((szLogFileName+psProcessSettings.dwLogFilesPathLen),TEXT("\\RRASLOG_ex%04lu_%04lu.w3c"),st.wYear,i);
				break;
			case LOG_FILE_NAME_ROTATE_NEWER:
			default:
				wsprintf((szLogFileName+psProcessSettings.dwLogFilesPathLen),TEXT("\\RRASLOG_extend%04lu.w3c"),i);
				break;
			}

			hLogFile=CreateFile(szLogFileName,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
			if (hLogFile!=INVALID_HANDLE_VALUE)
			if (GetFileSizeEx(hLogFile,&psProcessSettings.liLogFileSize))
			{// ������ �������
				if ((psProcessSettings.dwMaxLogFileSize==0 || psProcessSettings.dwMaxLogFileSize>=(psProcessSettings.liLogFileSize.QuadPart+(MAX_LOG_ENTRY_SIZE*2))) && SetFilePointerEx(hLogFile,psProcessSettings.liLogFileSize,NULL,FILE_BEGIN))
				{// ������ ������ ������������� ������� ��� ���� ������ �� ����������, � ��������� � ����� ��������� �� ������ �������
					psProcessSettings.hLogFile=hLogFile;
					//psProcessSettings.dwEntryesCount=0;
					psProcessSettings.stLogFileOpenTime=st;
					break;
				}else{
					CloseHandle(hLogFile);
				}
			}else{
				CloseHandle(hLogFile);
			}
		}

		if (psProcessSettings.hLogFile==INVALID_HANDLE_VALUE)
		{
			if ((dwRet=GetLastError())==NO_ERROR) dwRet=ERROR_INVALID_HANDLE;
		}else{
			dwRet=NO_ERROR;
		}
		LeaveCriticalSection(&psProcessSettings.cs);
	}else{
		dwRet=ERROR_INVALID_HANDLE_STATE;
	}
return(dwRet);
}


void LogFileClose()
{
	if (psProcessSettings.bIsInitialized)
	if (psProcessSettings.hLogFile && psProcessSettings.hLogFile!=INVALID_HANDLE_VALUE)
	{// ���� ��� ������
		SYSTEMTIME st;

		EnterCriticalSection(&psProcessSettings.cs);
		if (psProcessSettings.bUseGMTTime)
		{
			GetSystemTime(&st);
		}else{
			GetLocalTime(&st);
		}

		if (psProcessSettings.dwEntryesCount)
		{// ������ ���� ����������, ������� ��� �������
			char szBuff[MAX_LOG_ENTRY_SIZE];
			DWORD dwBuffSize,dwWrited;

			dwBuffSize=wsprintfA(szBuff,"#Close Date: %04lu-%02lu-%02lu %02lu:%02lu:%02lu\r\n",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);
			WriteFile(psProcessSettings.hLogFile,(LPVOID)&szBuff,dwBuffSize,&dwWrited,NULL);
		}
		CloseHandle(psProcessSettings.hLogFile);
		psProcessSettings.hLogFile=INVALID_HANDLE_VALUE;
		psProcessSettings.dwEntryesCount=0;
		psProcessSettings.liLogFileSize.QuadPart=0;
		ZeroMemory(&psProcessSettings.stLogFileOpenTime,sizeof(SYSTEMTIME));

		LeaveCriticalSection(&psProcessSettings.cs);
	}
}


BOOL LogFileIsCreateNew()
{
	BOOL bOpenNewLogFile=FALSE;

	if (psProcessSettings.bIsInitialized)
	{
		SYSTEMTIME st;

		EnterCriticalSection(&psProcessSettings.cs);
		if (psProcessSettings.bUseGMTTime)
		{
			GetSystemTime(&st);
		}else{
			GetLocalTime(&st);
		}

		if (psProcessSettings.dwMaxLogFileSize==0 || psProcessSettings.dwMaxLogFileSize>=(psProcessSettings.liLogFileSize.QuadPart+MAX_LOG_ENTRY_SIZE))
		{// ������ ������ ������������� ������� ��� ���� ������ �� ����������
			switch(psProcessSettings.dwLogRotateInterval){
			case LOG_FILE_NAME_ROTATE_HOURLY:
				if (psProcessSettings.stLogFileOpenTime.wYear!=st.wYear || psProcessSettings.stLogFileOpenTime.wMonth!=st.wMonth || psProcessSettings.stLogFileOpenTime.wDay!=st.wDay || psProcessSettings.stLogFileOpenTime.wHour!=st.wHour) bOpenNewLogFile=TRUE;
				break;
			case LOG_FILE_NAME_ROTATE_DAILY:
				if (psProcessSettings.stLogFileOpenTime.wYear!=st.wYear || psProcessSettings.stLogFileOpenTime.wMonth!=st.wMonth || psProcessSettings.stLogFileOpenTime.wDay!=st.wDay) bOpenNewLogFile=TRUE;
				break;
			case LOG_FILE_NAME_ROTATE_MONTHLY:
				if (psProcessSettings.stLogFileOpenTime.wYear!=st.wYear || psProcessSettings.stLogFileOpenTime.wMonth!=st.wMonth) bOpenNewLogFile=TRUE;
				break;
			case LOG_FILE_NAME_ROTATE_YEARLY:
				if (psProcessSettings.stLogFileOpenTime.wYear!=st.wYear) bOpenNewLogFile=TRUE;
				break;
			case LOG_FILE_NAME_ROTATE_NEWER:
			default:
				bOpenNewLogFile=FALSE;
				break;
			}
		}else{
			bOpenNewLogFile=TRUE;
		}
		LeaveCriticalSection(&psProcessSettings.cs);
	}
return(bOpenNewLogFile);
}


DWORD LogFileDataWrite(DWORD dwAction,HANDLE hPort,HANDLE hConnection,LPWSTR lpwszAddress,LPWSTR lpwszRemoteAddress,DWORD dwTotalNumberOfCalls,DWORD dwConnectDuration,LPWSTR lpwszPortName,LPWSTR lpwszMediaName,LPWSTR lpwszDeviceName,LPWSTR lpwszDeviceType,DWORD dwConnectionFlags,LPWSTR lpwszUserName,LPWSTR lpwszLogonDomain,LPWSTR lpwszRemoteComputer,DWORD dwLineSpeed,DWORD dwBytesXmited,DWORD dwBytesRcved,DWORD dwFramesXmited,DWORD dwFramesRcved,DWORD dwCrcErr,DWORD dwTimeoutErr,DWORD dwAlignmentErr,DWORD dwHardwareOverrunErr,DWORD dwFramingErr,DWORD dwBufferOverrunErr,DWORD dwCompressionRatioIn,DWORD dwCompressionRatioOut)
{
	DWORD dwRet;

	if (psProcessSettings.bIsInitialized)
	{
		if (psProcessSettings.dwLogActions&(1<<dwAction))
		{
			EnterCriticalSection(&psProcessSettings.cs);

			// ���������, ����� �� ������� ������ ����, ���� ��, �� ������
			if (LogFileIsCreateNew()) dwRet=LogFileOpen();
			
			if (psProcessSettings.hLogFile && psProcessSettings.hLogFile!=INVALID_HANDLE_VALUE)
			{
				char szBuff[MAX_LOG_ENTRY_SIZE];
				DWORD dwBuffSize,dwWrited;
				LPSTR lpszAction;
				SYSTEMTIME st;

				switch(dwAction){
				case LOG_ACTIONS_CONN_ACCEPT_NEW:
					lpszAction="Accept New Connection";
					break;
				case LOG_ACTIONS_CONN_HANGUP:
					lpszAction="Connection Hangup";
					break;
				case LOG_ACTIONS_LINK_ACCEPT_NEW:
					lpszAction="Accept New Link";
					break;
				case LOG_ACTIONS_LINK_HANGUP:
					lpszAction="Link Hangup";
					break;
				default:
					lpszAction="Unknown";
					break;
				}

				if (psProcessSettings.bUseGMTTime)
				{
					GetSystemTime(&st);
				}else{
					GetLocalTime(&st);
				}

				if (psProcessSettings.dwEntryesCount==0)
				{// ��� ������ ������ � ����, � ������� �����, ����� ���������
					dwBuffSize=0;
					dwBuffSize+=wsprintfA((szBuff+dwBuffSize),"#Software: RRAS log lib\r\n#Version: 1.0\r\n#Date: %04lu-%02lu-%02lu %02lu:%02lu:%02lu\r\n",psProcessSettings.stLogFileOpenTime.wYear,psProcessSettings.stLogFileOpenTime.wMonth,psProcessSettings.stLogFileOpenTime.wDay,psProcessSettings.stLogFileOpenTime.wHour,psProcessSettings.stLogFileOpenTime.wMinute,psProcessSettings.stLogFileOpenTime.wSecond);
					dwBuffSize+=wsprintfA((szBuff+dwBuffSize),"#Fields: date	time	server IP	client IP	client	username	action	port	port name	media name	device name	device type	connection	total number of calls	connection time	connection flags	line speed	bytes sent	bytes received	frames sent	frames received	crc err	timeout err	alignment err	hardware overrun err	framing err	buffer overrun err	compression ratio in	compression ratio out\r\n");
					
					if (WriteFile(psProcessSettings.hLogFile,(LPVOID)&szBuff,dwBuffSize,&dwWrited,NULL))
					{// ��������� ��������
						psProcessSettings.liLogFileSize.QuadPart+=dwWrited;
					}
				}

				dwBuffSize=0;
				dwBuffSize+=wsprintfA((szBuff+dwBuffSize),"%04lu-%02lu-%02lu	%02lu:%02lu:%02lu	%S	%S	%S	%S\\%S",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond,lpwszAddress,lpwszRemoteAddress,lpwszRemoteComputer,lpwszLogonDomain,lpwszUserName);
				dwBuffSize+=wsprintfA((szBuff+dwBuffSize),"	%s	%lu	%S	%S	%S	%S	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu	%lu\r\n",lpszAction,hPort,lpwszPortName,lpwszMediaName,lpwszDeviceName,lpwszDeviceType,hConnection,dwTotalNumberOfCalls,dwConnectDuration,dwConnectionFlags,dwLineSpeed,dwBytesXmited,dwBytesRcved,dwFramesXmited,dwFramesRcved,dwCrcErr,dwTimeoutErr,dwAlignmentErr,dwHardwareOverrunErr,dwFramingErr,dwBufferOverrunErr,dwCompressionRatioIn,dwCompressionRatioOut);

				if (WriteFile(psProcessSettings.hLogFile,(LPVOID)&szBuff,dwBuffSize,&dwWrited,NULL))
				{// ����� ������
					psProcessSettings.dwEntryesCount++;
					psProcessSettings.liLogFileSize.QuadPart+=dwWrited;
					dwRet=NO_ERROR;
				}else{
					dwRet=GetLastError();
				}
			}else{
				dwRet=ERROR_INVALID_HANDLE;
			}
			LeaveCriticalSection(&psProcessSettings.cs);

			// �� ���������� ������, ���� ��������� ���������� ������
			if (psProcessSettings.bRejectUsersOnLogFailure==FALSE) dwRet=NO_ERROR;
		}else{// ���� ��� ������ �� ������������, �� ��.
			dwRet=NO_ERROR;
		}
	}else{// �� �����������������, ����� ����������� ������ - �������� ����.
		dwRet=ERROR_INVALID_HANDLE_STATE;
	}
return(dwRet);
}
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
BOOL IsFileExist(LPCTSTR lpszFileName)
{
	BOOL bRet=FALSE;
	WIN32_FILE_ATTRIBUTE_DATA wfad;

	if (GetFileAttributesEx(lpszFileName,GetFileExInfoStandard,(LPWIN32_FILE_ATTRIBUTE_DATA)&wfad))
	{
		bRet=!(wfad.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY);
	}
return(bRet);
}

BOOL IsPathExist(LPCTSTR lpcszPath)
{
	BOOL bRet=FALSE;
	WIN32_FILE_ATTRIBUTE_DATA wfad;

	if (GetFileAttributesEx(lpcszPath,GetFileExInfoStandard,(LPWIN32_FILE_ATTRIBUTE_DATA)&wfad))
	{
		bRet=(wfad.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY);
	}
return(bRet);
}

BOOL CreatePath(LPCTSTR lpcszPath)
{
	TCHAR szPath[MAX_PATH_LEN];
	SIZE_T dwPathLen=lstrlen(lpcszPath);

	CopyMemory(szPath,lpcszPath,((dwPathLen+1)*sizeof(TCHAR)));
	for (SIZE_T i=1;i<dwPathLen;i++)
	{
		if (szPath[i]=='\\')
		{
			szPath[i]=0;
			if (IsPathExist(szPath)==FALSE) CreateDirectory(szPath,NULL);
			szPath[i]='\\';
		}
	}
	if (IsPathExist(szPath)==FALSE) CreateDirectory(szPath,NULL);

return(IsPathExist(lpcszPath));
}