//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_ADDCONTACT                  101
#define IDI_ADDCONTACT                  102
#define IDC_MYHANDLE                    1000
#define IDC_GROUP                       1001
#define IDC_ADDED                       1002
#define IDC_AUTH                        1003
#define IDC_AUTHGB                      1004
#define IDC_AUTHREQ                     1005
#define IDC_USERID                      1006
#define IDC_PROTO                       1007
#define IDC_IDLABEL                     1008
#define IDC_HEADERBAR                   1009
#define IDC_ADDTEMP                     1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
