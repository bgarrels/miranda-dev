//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AvatarHistory.rc
//
#define IDD_OPTIONS_OLD                 101
#define IDC_POPUPBG                     102
#define IDD_AVATARDLG                   102
#define IDC_POPUPFG                     103
#define IDI_AVATARHIST                  104
#define IDI_NEWAVATAR                   105
#define IDI_AVATAROVERLAY               106
#define IDD_OPTIONS                     119
#define IDD_POPUPS                      120
#define IDC_CUSTOM1                     1000
#define IDC_AVATARPOPUPS                1001
#define IDC_DELAY                       1001
#define IDC_LOGTODISK                   1002
#define IDC_WINCOLORS                   1002
#define IDC_LOGTOHISTORY                1003
#define IDC_DEFAULTCOLORS               1003
#define IDC_BGCOLOR                     1004
#define IDC_DEFPOPUPS                   1005
#define IDC_TEXTCOLOR                   1005
#define IDC_PREV                        1006
#define IDC_AVATAR                      1007
#define IDC_DELAYFROMPU                 1007
#define IDC_AVATARLIST                  1008
#define IDC_DELAYCUSTOM                 1008
#define IDC_SAVE                        1009
#define IDC_DELAYPERMANENT              1009
#define IDC_DELETE                      1010
#define IDC_NEXT                        1011
#define IDC_BACK                        1012
#define IDC_LOGUSER                     1013
#define IDC_POPUPUSER                   1014
#define IDC_OPENFOLDER                  1015
#define IDC_PUFGTEXT                    1016
#define IDC_HISTORYUSER                 1016
#define IDC_PUBGTEXT                    1017
#define IDC_DELETE2                     1017
#define IDC_DELETE_FOREVER              1017
#define IDC_SHOWMENU                    1019
#define IDC_TRACK_CHANGE_NEW            1020
#define IDC_RIGHT_ACTION                1022
#define IDC_LEFT_ACTION                 1023
#define IDC_PROTOCOLS                   1041
#define IDC_CHANGED                     1058
#define IDC_REMOVED                     1059
#define IDC_POPUPS                      1060
#define IDC_REMOVED2                    1060
#define IDC_CHANGED_NEW                 1060
#define IDC_DELAY_SPIN                  1061
#define IDC_LOG_DISK                    1061
#define IDC_LOG_HISTORY                 1062
#define IDC_TRACK_G                     1063
#define IDC_CHANGED_L                   1064
#define IDC_REMOVED_L                   1065
#define IDC_PROTOCOLS_G                 1066
#define IDC_PROTOCOLS_L                 1067
#define IDC_TRACK_CHANGE                1068
#define IDC_COLOURS_G                   1068
#define IDC_TRACK_REMOVE                1069
#define IDC_BGCOLOR_L                   1069
#define IDC_TEXTCOLOR_L                 1070
#define IDC_DELAY_G                     1071
#define IDC_TRACK_CHANGE_NEW_L          1071
#define IDC_CHANGED_NEW_L               1071
#define IDC_ACTIONS_G                   1072
#define IDC_RIGHT_ACTION_L              1073
#define IDC_LEFT_ACTION_L               1074

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
