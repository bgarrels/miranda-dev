/*

Avatar History 'ALA Style' Mod Plugin
---------

 This modification uses AutoLoadAvatars folder system and
 stores hash on profile in order not to allow duplicates.
 Copyright (C) 2007  Felipe Brahm (souFrag) - http://www.felipebrahm.com

Avatar History Plugin
---------

 This plugin uses the event provided by Avatar Service to 
 automatically back up contacts' avatars when they change.
 Copyright (C) 2006  Matthew Wild - Email: mwild1@gmail.com

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

/*#include <windows.h>
#include <stdio.h>

#include "newpluginapi.h"
#include "m_database.h"
#include "m_protosvc.h"*/

#include "AvatarHistory.h"

void freeAvatarsHashList(NODE_AVATAR_HASH* node) {

	#ifdef AVH_FILEDEBUG
		writeToDebugFile("freeAvatarsHashList(NODE_AVATAR_HASH* node) called");
	#endif

	if(node->next == NULL)
		return; //condici�n de t�rmino de recursi�n

	freeAvatarsHashList(node->next); //llamar recursivamente

	//free memory
	free(node->hash);
	free(node);

}

/*
void nodeAvatarHash_displayList(NODE_AVATAR_HASH* node) {

	NODE_AVATAR_HASH* last = node;

	//find last node
	while(last != NULL) {
		MessageBox(NULL,last->hash,"Hash",MB_OK);
		last = last->next;
	}

}
*/

void nodeAvatarHash_addToList(NODE_AVATAR_HASH* node, char* hash, size_t hashSize) {

	#ifdef AVH_FILEDEBUG
		writeToDebugFile("nodeAvatarHash_addToList(NODE_AVATAR_HASH* node, char* hash) called");
	#endif

	NODE_AVATAR_HASH* last = node;
	NODE_AVATAR_HASH* newNode;

	//MessageBox(NULL,"while(last->next != NULL)","Info",MB_OK);
	//find last node
	while(last->next != NULL)
		last = last->next;
	//MessageBox(NULL,"fin while(last->next != NULL)","Info",MB_OK);
	//check if node is already in use (only false for the FIRST node)
	//if(strcmp(last->hash, "0") != 0) {
	if(last->hash != NULL) {
	
		newNode = (NODE_AVATAR_HASH *)malloc(sizeof(NODE_AVATAR_HASH)); //ask for malloc
			
		if(newNode == NULL) //check if malloc was Ok
			return; //ERROR -> EXIT.

		last->next = newNode;

		last = newNode;
		last->next = NULL;

	}

	//MessageBox(NULL,"Storing Hash","Info",MB_OK);
	//store hash
	//strcpy(last->hash, hash);

	#ifdef AVH_FILEDEBUG
		writeToDebugFile("last->hash = (char *)malloc(hashSize+1)");
		char avh_debugText[MAX_PATH+1];
		sprintf(avh_debugText, "hashSize+1: %i", hashSize+1);
		writeToDebugFile(avh_debugText);
		writeToDebugFile("last->hash = (char *)malloc(hashSize+1)");
	#endif
	last->hash = (char *)malloc(hashSize+1); //ask for malloc

	if(last->hash == NULL) //check if malloc was Ok
		return; //ERROR -> EXIT.
	#ifdef AVH_FILEDEBUG
		writeToDebugFile("strcpy(last->hash, hash)");
	#endif
	strcpy(last->hash, hash);
		#ifdef AVH_FILEDEBUG
		writeToDebugFile("strcpy(last->hash, hash) success");
	#endif

}

static int AvatarsEntriesEnumProc(const char *szSetting, LPARAM lParam)
{ 

	#ifdef AVH_FILEDEBUG
		writeToDebugFile("AvatarsEntriesEnumProc(const char *szSetting, LPARAM lParam) called");
	#endif

	DBVARIANT dbv;

	LPARAM_AVATARS_ENTRIES_ENUMPROC* lparamEnum = (LPARAM_AVATARS_ENTRIES_ENUMPROC*)lParam;

	//MessageBox(NULL,szSetting,"szSetting",MB_OK);
	//MessageBox(NULL,lparamEnum->node->hash,"lparamEnum->node->hash",MB_OK);

	if(szSetting)
	{

		//TCHAR settingValue[MAX_PATH + 1] = "\0";
		//MyDBGetContactSettingTString((HANDLE)lparamEnum->hContact, "AvatarsHistory", szSetting, settingValue, MAX_PATH + 1, "\0");
		
		//if (!strcmp("\0", settingValue))
		if (DBGetContactSetting((HANDLE)lparamEnum->hContact, "AvatarsHistory", szSetting, &dbv))
		{
		// error reading value
			return 0;
		}

		//MessageBox(NULL,dbv.pszVal,"Hash",MB_OK);

		char someValue[MAX_PATH+1];
		strcpy(someValue, dbv.pszVal);
		DBFreeVariant(&dbv); // let Miranda free the memory!
		
		#ifdef AVH_FILEDEBUG
			char avh_debugText[MAX_PATH+1];
			sprintf(avh_debugText, "someValue: '%s'", someValue);
			writeToDebugFile(avh_debugText);
			sprintf(avh_debugText, "strlen(someValue): '%i'", strlen(someValue));
			writeToDebugFile(avh_debugText);
		#endif
		nodeAvatarHash_addToList(lparamEnum->node, someValue, strlen(someValue));
		//nodeAvatarHash_addToList(lparamEnum->node, settingValue);

		//MessageBox(NULL,"Fin addToList","Info",MB_OK);

		/*if (!strcmp(stringToCompareWith, dbv.pszVal))
		{
		// they're the same
		}*/

	}

	return 0;

}

/*
creates a "lista ligada" with all hashes from hContact
*/
NODE_AVATAR_HASH* getAvatarsHashList(HANDLE hContact) {

	#ifdef AVH_FILEDEBUG
		writeToDebugFile("getAvatarsHashList(HANDLE hContact) called");
	#endif

	DBCONTACTENUMSETTINGS dbces;

	LPARAM_AVATARS_ENTRIES_ENUMPROC lparamEnum;

	char szModule[] = "AvatarsHistory";

	lparamEnum.hContact = hContact;
	
	lparamEnum.node = (NODE_AVATAR_HASH *)malloc(sizeof(NODE_AVATAR_HASH)); //ask for malloc
	if(lparamEnum.node == NULL) //check if malloc was Ok
		return 0; //ERROR -> EXIT.
	lparamEnum.node->next = NULL;
	lparamEnum.node->hash = NULL;

	/*
	lparamEnum.node->hash = (char *)malloc(sizeof("0")); //ask for malloc

	if(lparamEnum.node->hash == NULL) //check if malloc was Ok
		return 0; //ERROR -> EXIT.

	strcpy(lparamEnum.node->hash, "0");
	*/

	dbces.pfnEnumProc = &AvatarsEntriesEnumProc;
	dbces.szModule = szModule;
	dbces.lParam = (LPARAM)&lparamEnum;

	CallService(MS_DB_CONTACT_ENUMSETTINGS, (WPARAM)hContact, (LPARAM)&dbces);

	//MessageBox(NULL,"END getAvatarHashList()","Info",MB_OK);

	//MessageBox(NULL,"Display List.","Info",MB_OK);

	//nodeAvatarHash_displayList(lparamEnum.node);

	//MessageBox(NULL,"End List.","Info",MB_OK);

	return lparamEnum.node;

}

BOOL oldMethod_isNewHash(HANDLE hContact, char* hash) {

	#ifdef AVH_FILEDEBUG
		writeToDebugFile("isNewHash(HANDLE hContact, char* hash) called");
	#endif

	NODE_AVATAR_HASH* hashList = getAvatarsHashList(hContact);
	NODE_AVATAR_HASH* last = hashList;
	BOOL isNew = TRUE;

	//check if hash is in the list
	while(last != NULL) {
		
		if (!strcmp(last->hash, hash)) {

			/* DUPLICATED AVATAR! */
			isNew = FALSE;
			break; //exit while

		}

		last = last->next;

	}

	//MessageBox(NULL,"TRYING freeAvatarsHashList()","Info",MB_OK);

	freeAvatarsHashList(hashList);

	//MessageBox(NULL,"END freeAvatarsHashList()","Info",MB_OK);

	return isNew;

}

/* begin NEW METHOD */

static int NewAvatarsEntriesEnumProc(const char *szSetting, LPARAM lParam)
{ 

	#ifdef AVH_FILEDEBUG
		writeToDebugFile("AvatarsEntriesEnumProc(const char *szSetting, LPARAM lParam) called");
	#endif

	DBVARIANT dbv;

	NEW_LPARAM_AVATARS_ENTRIES_ENUMPROC* lparamEnum = (NEW_LPARAM_AVATARS_ENTRIES_ENUMPROC*)lParam;

	//MessageBox(NULL,szSetting,"szSetting",MB_OK);
	//MessageBox(NULL,lparamEnum->node->hash,"lparamEnum->node->hash",MB_OK);

	if(szSetting)
	{

		if (DBGetContactSetting((HANDLE)lparamEnum->hContact, "AvatarsHistory", szSetting, &dbv))
		{
			//error reading value
			DBFreeVariant(&dbv); // let Miranda free the memory!
			return 0;
		}

		//MessageBox(NULL,dbv.pszVal,"Hash",MB_OK);
		
		if (!strcmp(lparamEnum->hash, dbv.pszVal)) {

			/* DUPLICATED AVATAR! */
			lparamEnum->isNew = FALSE;

		}

		DBFreeVariant(&dbv); // let Miranda free the memory!

	}

	return 0;

}

BOOL isNewHash(HANDLE hContact, char* hash) {

	#ifdef AVH_FILEDEBUG
		writeToDebugFile("isNewHash(HANDLE hContact, char* hash) called");
	#endif

	DBCONTACTENUMSETTINGS dbces;

	NEW_LPARAM_AVATARS_ENTRIES_ENUMPROC lparamEnum;

	char szModule[] = "AvatarsHistory";

	lparamEnum.hContact = hContact;
	
	strcpy(lparamEnum.hash, hash);

	lparamEnum.isNew = TRUE;

	dbces.pfnEnumProc = &NewAvatarsEntriesEnumProc;
	dbces.szModule = szModule;
	dbces.lParam = (LPARAM)&lparamEnum;

	CallService(MS_DB_CONTACT_ENUMSETTINGS, (WPARAM)hContact, (LPARAM)&dbces);

	return lparamEnum.isNew;

}

/* end NEW METHOD */

void deleteAvatarHash(HANDLE hContact, char* filename) {

	DBDeleteContactSetting(hContact, "AvatarsHistory", filename);

}

#ifdef AVH_FILEDEBUG

	void writeToDebugFile(wchar_t* line) {

		char out[MAX_PATH+1];
		wcstombs(out, line, MAX_PATH+1);

		FILE *fp;
		fp = fopen("_AvatarHistoryDEBUG.txt", "a");
		fprintf(fp, "%s\r\n", out);
		fclose(fp);

	}

	void writeToDebugFile(char* line) {

		wchar_t out[MAX_PATH+1];
		mbstowcs(out, line, MAX_PATH+1);
		writeToDebugFile(out);

	}
#endif