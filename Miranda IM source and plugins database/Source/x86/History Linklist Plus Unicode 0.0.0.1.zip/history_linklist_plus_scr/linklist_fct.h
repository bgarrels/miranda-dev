#ifndef _LINKLIST_FCT_H
#define _LINKLIST_FCT_H
/*
Miranda Linklist plugin by Thomas Wendel.

http://www.miranda-im.org/

This file is placed in the public domain. Anybody is free to use or
modify it as they wish with no restriction.
There is no warranty.
*/
#include "linklist.h"

#define WIN32_LEAN_AND_MEAN


int ExtractURI(DBEVENTINFO*, HANDLE, LISTELEMENT*);
int RemoveList(LISTELEMENT*);
int ListCount(LISTELEMENT*);
void DrawLine(HWND, int);
char GetFlags(HMENU);
void GetFilterText(HMENU, char*);
void GetListInfo(char, LISTELEMENT*, char*, int*, int*, int*);
void GetListOptions(LISTOPTIONS*);
void SetListOptions(LISTOPTIONS*);
void ClearLinePos(LISTELEMENT*);
int GetLastLinePos(LISTELEMENT*);
int WriteLinkList(HWND, char, LISTELEMENT*, char*, int);
int WriteOptionExample(HWND, DWORD, DWORD, DWORD, DWORD, LISTOPTIONS*);
void WriteMessage(HWND, LISTELEMENT*, int);
int GetColour(MYCOLOURSET*);
int GetDBColour(MYCOLOURSET*);
int SetDBColour(MYCOLOURSET*);
int GetMirandaColour(MYCOLOURSET*);
char GetUpdateSetting(void);
int DBUpdate(WPARAM, LPARAM);
int LinklistResizer(HWND,LPARAM,UTILRESIZECONTROL*);
// RTF Save functions
BOOL SaveEditAsStream( HWND );
DWORD CALLBACK RTFSaveStreamCallback( DWORD, LPBYTE, LONG, LONG * );


#endif //_LINKLIST_FCT_H