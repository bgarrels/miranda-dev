#ifndef _LINKLIST_DLG_H
#define _LINKLIST_DLG_H
/*
Miranda Linklist plugin by Thomas Wendel.

http://www.miranda-im.org/

This file is placed in the public domain. Anybody is free to use or
modify it as they wish with no restriction.
There is no warranty.
*/

#define WIN32_LEAN_AND_MEAN

BOOL WINAPI MainDlgProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK ProgressBarDlg(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI AboutDlgProc( HWND, UINT, WPARAM, LPARAM );
BOOL WINAPI SearchDlgProc( HWND, UINT, WPARAM, LPARAM );
BOOL CALLBACK OptionsDlgProc(HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK SplitterProc(HWND, UINT, WPARAM, LPARAM);

#endif //_LINKLIST_DLG_H