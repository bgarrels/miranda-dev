//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by linklist.rc
//
#define IDC_MAIN                        100
#define IDR_MENU1                       101
#define IDM_SEARCH                      101
#define IDC_MESSAGE                     101
#define IDM_SAVE                        102
#define IDM_CLOSE                       103
#define IDM_ABOUT                       104
#define IDM_DIR_IN                      105
#define IDM_DIR_OUT                     106
#define IDM_TYPE_MAIL                   108
#define IDD_OPTIONS_DLG                 108
#define IDM_TYPE_WEB                    109
#define IDR_MENU2                       110
#define IDC_ABOUT                       200
#define IDI_LINKLISTICON                300
#define IDC_SEARCHSTRING                400
#define IDSEARCH                        401
#define IDC_DIR_IN                      402
#define IDC_DIR_OUT                     403
#define IDC_TYPE_MAIL                   404
#define IDC_TYPE_WEB                    405
#define IDC_DIR_ALL                     410
#define IDC_TYPE_ALL                    411
#define IDC_OPTIONS_ALT                 1023
#define IDC_DEFAULT_IN                  1024
#define IDC_TXTIN                       1026
#define IDC_TXTOUT                      1027
#define IDC_TXTBG                       1028
#define IDC_TXTTXT                      1029
#define IDC_DEFAULT_OUT                 1031
#define IDC_DEFAULT_BG                  1032
#define IDC_DEFAULT_TXT                 1033
#define IDC_CHECK1                      1034
#define IDC_BACKGROUND                  1039
#define IDC_OUTGOING                    1040
#define IDC_INCOMING                    1041
#define IDC_TXT                         1042
#define IDC_OPTIONS_RE                  1043
#define IDC_CHECK2                      1046
#define IDC_CHECK3                      1047
#define IDC_STATUS                      1047
#define IDC_CHECK4                      1048
#define IDC_WHOLE_MESSAGE               1049
#define IDC_CHECK5                      1049
#define IDC_SPLITTER                    1051
#define IDC_CHECK6                      1052
#define IDC_CHECK7                      1053
#define IDC_CHECK8                      1054
#define IDC_CHECK9                      1055
#define IDC_CHECK10                     1056
#define IDD_MAIN_DLG                    10000
#define IDD_ABOUT_DLG                   11000
#define IDD_SEARCH_DLG                  11001
#define IDM_CLEARSEARCH                 40009
#define IDM_LINK_OPEN                   40010
#define IDM_LINK_OPENNEW                40011
#define IDM_LINK_COPY                   40012
#define IDM_SHOWMESSAGE                 40013
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
