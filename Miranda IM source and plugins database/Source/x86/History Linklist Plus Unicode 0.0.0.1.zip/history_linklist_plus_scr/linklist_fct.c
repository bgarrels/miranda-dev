/*
Miranda Linklist plugin by Thomas Wendel.

http://www.miranda-im.org/

This file is placed in the public domain. Anybody is free to use or
modify it as they wish with no restriction.
There is no warranty.
*/
#pragma comment(lib,"Comctl32.lib")
#include <windows.h>
#include <stdio.h>
#include <richedit.h>
#include <mbstring.h>
#include "resource.h"
#include <commctrl.h>

// Miranda SDK Includes
#include "../SDK/headers_c/newpluginapi.h"
#include "../SDK/headers_c/m_clist.h"
#include "../SDK/headers_c/m_database.h"
#include "../SDK/headers_c/m_utils.h"
#include "../SDK/headers_c/m_langpack.h"

#include "linklist.h"
#include "linklist_fct.h"
#include "language.h"


extern HINSTANCE hInst;
extern HANDLE hWindowList;

/*
The hyperlink detection in this function is taken from the
Miranda core. It looks a bit sophisticated. I'd made a few 
changes but I didn't really understand what these guys did! 
Great job! It works! ;-)
*/
int ExtractURI(DBEVENTINFO *dbei, HANDLE hEvent, LISTELEMENT *listStart)
{
	int wordStart,i,iLastAlphaNum, linkFound=0;
	int charCount=0,cpLastAlphaNum=0,cpWordStart;
	char *msg,*word, *wordsearch, *date_ptr, *time_ptr;
	static const char *hyperlinkPrefixes[]={"http://","ftp://","https://","mailto:","www.","ftp.","icq#","gopher://","news://","file://","\\\\"};
	static const char *hyperlinkSubstrings[]={".com/",".net/",".org/",".co.uk"};
	DBTIMETOSTRING dbtimestring;
	LISTELEMENT *newElement, *actualElement;
	char templink[LINK_MAX];
	char dbdate[DATE_SIZE + TIME_SIZE];
	char direction[DIR_SIZE];
	char type[TYPE_SIZE];
	char date[DATE_SIZE];
	char time[TIME_SIZE];
	char link[LINK_MAX];

	msg=(char*)dbei->pBlob;
	ZeroMemory(link, LINK_MAX);
	ZeroMemory(direction, DIR_SIZE);
	ZeroMemory(type, TYPE_SIZE);
	ZeroMemory(date, DATE_SIZE);
	ZeroMemory(time, TIME_SIZE);
	
	if(listStart == NULL)
		return -1;

	for(i=0;msg[i];) 
	{
		//hyperlinks are delimited by: <non-alphanumeric>"hyperlink"<whitespace>
		//then all punctuation is stripped from the end of "hyperlink"
		while(msg[i] && (!isalnum((BYTE)msg[i]))) 
		{
			// support for files
			if((msg[i]=='\\') && (msg[i+1]=='\\') && (isalnum((BYTE)msg[i+2])))
			{ 
				break;
			}
			if(IsDBCSLeadByte(msg[i]) && msg[i+1]) i++;
			i++;
			if(msg[i]!='\n') charCount++;
		}
		if(msg[i]=='\0') break;

		cpWordStart=charCount;
		wordStart=i;
			
		while(msg[i] && (!isspace((BYTE)msg[i]))) 
		{
			if(IsDBCSLeadByte(msg[i]) && msg[i+1]) i++;
			else if(isalnum((BYTE)msg[i]) || msg[i]=='/') 
			{
				cpLastAlphaNum=charCount; 
				iLastAlphaNum=i;
			}
			charCount++;
			i++;
		}

		charCount=cpLastAlphaNum+1;
		i=iLastAlphaNum+1;

		if(i-wordStart>=7) 
		{
			int isLink=0,j;

			word=(char*)malloc(i-wordStart+1);
			wordsearch=(char*)malloc(i-wordStart+1);

			lstrcpyn(word,msg+wordStart,i-wordStart+1);
			lstrcpyn(wordsearch,msg+wordStart,i-wordStart+1);
			CharLower(wordsearch);
			for(j=0;j<sizeof(hyperlinkPrefixes)/sizeof(hyperlinkPrefixes[0]);j++)
			{
				if(!strncmp(wordsearch,hyperlinkPrefixes[j],lstrlen(hyperlinkPrefixes[j])))
				{
					isLink=1; 
					break;
				}
			}
			
			for(j=0;j<sizeof(hyperlinkSubstrings)/sizeof(hyperlinkSubstrings[0]);j++)
			{
				if(_mbsstr(wordsearch+1,hyperlinkSubstrings[j]))
				{
					isLink=1; 
					break;
				}
			}
		
			if(_mbschr(wordsearch,'@') && _mbschr(wordsearch,'.') && !_mbschr(wordsearch,':') && !_mbschr(wordsearch,'/'))
			{
				isLink=1;	//e-mail addresses
				strncpy(type, "mail\0", 5);
			}
			else
				strncpy(type, "URL \0", 4);
			

			if((isLink) && ( (i-wordStart+1) <= (int)(LINK_MAX - strlen("http://")))) 
			{

				if( ((unsigned char *)_mbsstr(wordsearch, "www.") != NULL) && ((unsigned char *)_mbsstr(wordsearch, "http://") == NULL))
				{
					strncpy(link, "http://", strlen("http://"));
					// Link longer than defined max -> cut link to max
					if((i-wordStart+1) > (int)(LINK_MAX-strlen("http://")))
						strncpy(link + strlen("http://"), word, LINK_MAX-strlen("http://"));
					else
						strncpy(link + strlen("http://"), word, i-wordStart+1);
				}
				else
				{
					if((i-wordStart+1) > LINK_MAX)
						strncpy(link, word, LINK_MAX);
					else
						strncpy(link, word, i-wordStart+1);
				}

				dbtimestring.szFormat = "d-t";
				dbtimestring.szDest = dbdate;
				dbtimestring.cbDest = sizeof(dbdate);
				CallService(MS_DB_TIME_TIMESTAMPTOSTRING,(WPARAM)dbei->timestamp, (LPARAM)&dbtimestring);
				date_ptr = strtok(dbdate, "-");
				time_ptr = strtok(NULL, "-");
				strncpy(date, date_ptr, DATE_SIZE);
				strncpy(time, time_ptr, TIME_SIZE);
				
				// Prevent overflow
				date[DATE_SIZE] = '\0';
				time[TIME_SIZE] = '\0';

				if (dbei->flags&DBEF_SENT)
					strncpy(direction, "[out]", strlen("[out]"));
				
				else
					strncpy(direction, "[in ]", strlen("[in ]"));
				
				if((_mbsstr(type, "mail") != NULL) && (_mbsstr(link, "mailto:") == NULL))
				{
					strcpy(templink, link);
					strcpy(link, "mailto:");
					strncpy(link + strlen("mailto:"), templink, LINK_MAX-strlen("mailto:"));
				}
				
				// Add new Element to list:
			 	newElement = malloc(sizeof(LISTELEMENT));
				if(newElement == NULL)
					return -1;

				ZeroMemory(newElement, sizeof(LISTELEMENT));
				newElement->nextElement = NULL;
				strncpy(newElement->direction, direction, strlen(direction));
				strncpy(newElement->type, type, strlen(type));
				strncpy(newElement->date, date, strlen(date));
				strncpy(newElement->time, time, strlen(time));
				strncpy(newElement->link, link, strlen(link));
				newElement->hEvent = hEvent;
				
				actualElement = listStart;
				while(actualElement->nextElement != NULL)
				{
					actualElement = actualElement->nextElement; 
				}
				
				actualElement->nextElement = newElement;
				linkFound++;
			}
			free((void *)word);
			free((void *)wordsearch);
		}
	}
	return linkFound;
}


/*
Remove the linked list an free memory
*/
int RemoveList(LISTELEMENT *listStart)
{
	LISTELEMENT *actualElement, *tempElement;

	if(listStart == NULL)
		return -1;

	actualElement = listStart->nextElement;
	while(actualElement != NULL)
	{
		tempElement = actualElement->nextElement;
		free(actualElement);
		actualElement = tempElement;
	}
	free(listStart);
	return 0;
}


/*
Count the elements of the list
*/
int ListCount(LISTELEMENT *listStart)
{
	LISTELEMENT *actualElement;
	int count = 0;

	if(listStart == NULL)
		return -1;
	
	if(listStart->nextElement == NULL)
		return 0;

	actualElement = listStart->nextElement;
	while(actualElement != NULL)
	{
		count++;
		actualElement = actualElement->nextElement;
	}
	return count;
}


/*
Fill the richedit field with informations ;-)

Special thanks to MatriX for his help with the cursor postion!
*/
int WriteLinkList( HWND hDlg, char param, LISTELEMENT *listStart, char *searchString, int append)
{
	CHARFORMAT2 cf;
	PARAFORMAT2 pf;
	HWND hwndProgress;
	RECT DesktopRect;
	MYCOLOURSET colourSet;
	char textLine[LINK_MAX + DIR_SIZE + TIME_SIZE + TYPE_SIZE + 6];
	char searchText[320];
	char lastDate[11] = {0};
	char filter1, filter2, filter3;
	int lineLen, listCount=0, realListCount=0, actCount=0, len, appCount = 0, linePos = -1;
	LISTELEMENT *actualElement;
	LISTOPTIONS options;
	CHARRANGE sel; 
	GETTEXTLENGTHEX gtl;
	DBEVENTINFO dbe;

	GetListInfo(param, listStart, searchString, &lineLen, &listCount, &realListCount);
	GetColour(&colourSet);
	GetListOptions(&options);
		
	if(append == 0)
		ShowWindow(GetDlgItem(hDlg, IDC_MAIN), SW_HIDE);
	
	if((append > 0) && (GetMenuState(GetMenu(hDlg), IDM_SEARCH, MF_BYCOMMAND) & MF_DISABLED))
	{
		return 0;
	}

	if((GetDlgItem(hDlg, IDC_MAIN)) && (GetDlgItem(hDlg, IDC_MESSAGE)))
	{
		
		SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETEVENTMASK, 0, (LPARAM)(ENM_LINK ) );
		SendDlgItemMessage( hDlg, IDC_MAIN, EM_AUTOURLDETECT, TRUE, 0 );
		SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETBKGNDCOLOR, FALSE, colourSet.background);
		
		memset( &cf, 0, sizeof cf );
		cf.cbSize = sizeof cf;
		cf.dwMask = CFM_COLOR;
		cf.crTextColor = colourSet.text;
		SendDlgItemMessage( hDlg, IDC_MESSAGE, EM_SETCHARFORMAT, SCF_SELECTION|SCF_WORD, (LPARAM) &cf);
		SendDlgItemMessage( hDlg, IDC_MESSAGE, EM_AUTOURLDETECT, TRUE, 0 );
		SendDlgItemMessage( hDlg, IDC_MESSAGE, EM_SETBKGNDCOLOR, FALSE, colourSet.background);

		if(append == 0)
		{
			ClearLinePos(listStart);
			
			// How to set RTF colour, font, etc.... found at
			// http://www.winehq.com/hypermail/wine-devel/2004/08/0608.html
			memset( &pf, 0, sizeof pf );
			pf.cbSize = sizeof pf;
			pf.dwMask = PFM_ALIGNMENT ;
			pf.wAlignment = PFA_LEFT;
			SendDlgItemMessage( hDlg, IDC_MAIN,  EM_SETPARAFORMAT, FALSE, (LPARAM) &pf);
		
			if(searchString != NULL)
			{
				memset( &cf, 0, sizeof cf );
				cf.cbSize = sizeof cf;
				cf.dwMask = CFM_ITALIC | CFM_BOLD | CFM_FACE | CFM_COLOR;
				cf.dwEffects = CFE_BOLD;
				cf.crTextColor = colourSet.text;
				strcpy(cf.szFaceName, "Arial");
				SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);
				
				ZeroMemory(searchText, 320);
				_snprintf(searchText, 320, "%s '%s': %d\n\n", Translate(txtmatches), searchString, listCount);
				SendDlgItemMessage(hDlg, IDC_MAIN, EM_REPLACESEL, FALSE, (LPARAM) searchText);
				linePos += 2;
			}
		
			memset( &cf, 0, sizeof cf );
			cf.cbSize = sizeof cf;
			cf.dwMask = CFM_FACE  | CFM_BOLD;
			strcpy(cf.szFaceName, "Courier");
			SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);
		}

		actualElement = listStart->nextElement;
		
		if(append > 0)
		{
			linePos = GetLastLinePos(listStart);

			if((realListCount - append) == 1)
				strcpy(lastDate, actualElement->date);

			for(appCount = 1; appCount <= (realListCount - append); appCount++)
			{
				actualElement = actualElement->nextElement;
				if(appCount == (realListCount - append - 1))
					strcpy(lastDate, actualElement->date);
			}
			gtl.flags = GTL_PRECISE; 
			gtl.codepage = CP_ACP ; 
			sel.cpMin = sel.cpMax = SendMessage(GetDlgItem(hDlg, IDC_MAIN), EM_GETTEXTLENGTHEX, (WPARAM)&gtl, 0); 
			SendMessage(GetDlgItem(hDlg, IDC_MAIN), EM_EXSETSEL, 0, (LPARAM) & sel); 
		}
		

		if(append == 0)
		{
			// Create Progressbar
			GetWindowRect(GetDesktopWindow(), &DesktopRect);
			hwndProgress = CreateWindow("Progressbar", Translate(txtprocessinglist), WS_OVERLAPPED, CW_USEDEFAULT, CW_USEDEFAULT, 350, 45, NULL, NULL, hInst, NULL);
			SetWindowPos(hwndProgress,HWND_TOP,(int)(DesktopRect.right*0.5)-175,(int)(DesktopRect.bottom*0.5)-22,0,0,SWP_NOSIZE);
		
			if(hwndProgress != NULL)
			{
				ShowWindow(hwndProgress, SW_SHOW);
				SetForegroundWindow(hwndProgress);
			}
		}

		while(actualElement != NULL)
		{
			filter1 = 0;
			filter2 = 0;
			filter3 = 0;
			
			if((param & WLL_IN) && (strcmp(actualElement->direction, "[in ]") == 0))
				filter1 = 1;
			else if((param & WLL_OUT) && (strcmp(actualElement->direction, "[out]") == 0))
				filter1 = 1;
			
			if((param & WLL_MAIL) && (strcmp(actualElement->type, "mail") == 0))
				filter2 = 1;
			else if((param & WLL_URL) && (strcmp(actualElement->type, "URL ") == 0))
				filter2 = 1;
			else if((param & WLL_FILE) && (strcmp(actualElement->type, "file") == 0))
				filter2 = 1;


			if(searchString != NULL)
			{
				if(param & SLL_DEEP)
				{	
					// Perform deep scan
					if(actualElement->hEvent != NULL)
					{
						dbe.cbSize=sizeof(dbe);
						dbe.pBlob=NULL;
						dbe.cbBlob=(int)CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)actualElement->hEvent,0);
						dbe.pBlob = (PBYTE)malloc(dbe.cbBlob+1);
						CallService(MS_DB_EVENT_GET,(WPARAM)actualElement->hEvent,(LPARAM)&dbe);
						dbe.pBlob[dbe.cbBlob] = 0;
						if(_mbsstr(dbe.pBlob, searchString))
							filter3 = 1;						
						
						free(dbe.pBlob);
					}
					else
						filter3 = 0;
				}
				else
				{
					if(_mbsstr(actualElement->link, searchString))
						filter3 = 1;
				}
			}
			else
				filter3 = 1;

			if((filter1 == 1) && (filter2 == 1) && (filter3 == 1))
			{
			
				if(strcmp(actualElement->date, lastDate) != 0)
				{
					memset( &cf, 0, sizeof cf );
					cf.cbSize = sizeof cf;
					cf.dwMask = CFM_COLOR;
					cf.crTextColor = colourSet.text;
					SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);
					if(options.showLine != 0)
						DrawLine(hDlg, lineLen);
					memset( &cf, 0, sizeof cf );
					cf.cbSize = sizeof cf;
					cf.dwMask = CFM_ITALIC | CFM_BOLD | CFM_FACE;
					cf.dwEffects = CFE_BOLD;
					strcpy(cf.szFaceName, "Arial");
					SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);
					if(options.showDate != 0)
					{
						SendDlgItemMessage( hDlg, IDC_MAIN, EM_REPLACESEL, FALSE, (LPARAM) actualElement->date);
						SendDlgItemMessage( hDlg, IDC_MAIN, EM_REPLACESEL, FALSE, (LPARAM) "\n\n");
						linePos += 3;
					}
					strcpy(lastDate, actualElement->date);
					memset( &cf, 0, sizeof cf );
					cf.cbSize = sizeof cf;
					cf.dwMask = CFM_ITALIC | CFM_BOLD | CFM_UNDERLINE | CFM_FACE;
					strcpy(cf.szFaceName, "Courier");
					SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);
				}
				memset( &cf, 0, sizeof cf );
				cf.cbSize = sizeof cf;
				cf.dwMask = CFM_COLOR;
				
				if(strcmp(actualElement->direction, "[out]") != 0)
				{
					cf.crTextColor = colourSet.incoming;
				}
				else
					cf.crTextColor = colourSet.outgoing;
				
				_snprintf(textLine, LINK_MAX+DIR_SIZE+TIME_SIZE+TYPE_SIZE+6, "%s%s%s%s%s%s%s\n", \
					(options.showDirection != 0)? actualElement->direction : "", (options.showDirection != 0)? " " : "",\
					(options.showType != 0)? actualElement->type : "", (options.showType != 0)? "  " : "", \
					(options.showTime != 0)? actualElement->time : "", (options.showTime != 0)? " " : "", actualElement->link);
				SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);
				SendDlgItemMessage(hDlg, IDC_MAIN, EM_REPLACESEL, FALSE,(LPARAM)textLine);
				linePos++;
				actualElement->linePos = linePos;
				actCount++;
				if(append == 0)
					if( ((int)(((float)actCount/listCount)*100.00)) % 10 == 0)
						SendMessage(hwndProgress, WM_COMMAND, 100,((int)(((float)actCount/listCount)*100.00)));

			}
			actualElement = actualElement->nextElement;
		}
		if(listCount > 0)
		{
			if((actCount < listCount) && (append == 0) && (options.showLine != 0))
				DrawLine(hDlg, lineLen);
		}
		else if(searchString == NULL)
		{	
			memset( &cf, 0, sizeof cf );
			cf.cbSize = sizeof cf;
			cf.dwMask = CFM_ITALIC | CFM_BOLD | CFM_FACE;
			cf.dwEffects = CFE_BOLD;
			strcpy(cf.szFaceName, "Arial");
			SendDlgItemMessage( hDlg, IDC_MAIN, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);
			SendDlgItemMessage( hDlg, IDC_MAIN, EM_REPLACESEL, FALSE, (LPARAM)Translate(txtnomessagesfound));
			SendDlgItemMessage( hDlg, IDC_MAIN, EM_REPLACESEL, FALSE, (LPARAM)"\n");
		}
			
	}
	if(append == 0)
	{
		SendMessage(hwndProgress, WM_CLOSE,0 , 0);
		ShowWindow(GetDlgItem(hDlg, IDC_MAIN), SW_SHOW);	
	}
	
	PostMessage(GetDlgItem(hDlg, IDC_MAIN), WM_VSCROLL, MAKEWPARAM(SB_BOTTOM, 0), 0);
	len = GetWindowTextLength(GetDlgItem(hDlg, IDC_MAIN));
	PostMessage(GetDlgItem(hDlg, IDC_MAIN), EM_SETSEL, len, len);
	return 0;
}


/*
Output some example text to the options dialog
*/
int WriteOptionExample(HWND hDlg, DWORD InColourSel, DWORD OutColourSel, DWORD BGColourSel, DWORD TxtColourSel, LISTOPTIONS *options)
{
	CHARFORMAT cf;
	PARAFORMAT pf;
	
	memset( &pf, 0, sizeof pf );
	pf.cbSize = sizeof pf;
	pf.dwMask = PFM_ALIGNMENT;
	pf.wAlignment = PFA_LEFT;
	SendDlgItemMessage( hDlg, IDC_OPTIONS_RE,  EM_SETPARAFORMAT, FALSE, (LPARAM) &pf);
	SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_SETEVENTMASK, 0, (LPARAM)(ENM_LINK ) );
	SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_AUTOURLDETECT, TRUE, 0 );
	SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_SETBKGNDCOLOR, FALSE, BGColourSel);
	SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, WM_SETTEXT , 0, (LPARAM)NULL);

	memset( &cf, 0, sizeof cf );
	cf.cbSize = sizeof cf;
	cf.dwMask = CFM_FACE  | CFM_BOLD | CFM_ITALIC | CFM_COLOR;
	strcpy(cf.szFaceName, "Courier");
	cf.crTextColor = TxtColourSel;
	SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);
	if(options->showLine == 1)
		SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"___________________________________________\n");
	else
		SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"\n");
	

	memset( &cf, 0, sizeof cf );
	cf.cbSize = sizeof cf;
	cf.dwMask = CFM_BOLD | CFM_FACE | CFM_COLOR;
	cf.dwEffects = CFE_BOLD;
	strcpy(cf.szFaceName, "Arial");
	cf.crTextColor = TxtColourSel;
	SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);

	if(options->showDate == 1)
		SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)Translate(txtdate));
	

	SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM) "\n");

	memset( &cf, 0, sizeof cf );
	cf.cbSize = sizeof cf;
	cf.dwMask = CFM_ITALIC | CFM_BOLD | CFM_UNDERLINE | CFM_FACE;
	strcpy(cf.szFaceName, "Courier");
	SendDlgItemMessage( hDlg, IDC_OPTIONS_RE, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM) &cf);

	// incoming
	memset( &cf, 0, sizeof(CHARFORMAT) );
	cf.cbSize = sizeof(CHARFORMAT);
	cf.dwMask = CFM_COLOR | CFM_FACE;
	cf.crTextColor = InColourSel;
	strcpy(cf.szFaceName, "Courier");
	SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM)&cf );
	
	if(options->showDirection == 1)
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"\n[in ] ");
	else
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"\n");
		
	if(options->showType == 1)
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"URL   ");
	else
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"");
	
	if(options->showTime == 1)
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"08:15 http://www.miranda-im.org\n");
	else
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"http://www.miranda-im.org\n");

	// outgoing
	memset( &cf, 0, sizeof(CHARFORMAT) );
	cf.cbSize = sizeof(CHARFORMAT);
	cf.dwMask = CFM_COLOR | CFM_FACE;
	cf.crTextColor = OutColourSel;
	strcpy(cf.szFaceName, "Courier");
	SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_SETCHARFORMAT, SCF_SELECTION | SCF_WORD, (LPARAM)&cf );

	
	if(options->showDirection == 1)
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"[out] ");
	else
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"");
		
	if(options->showType == 1)
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"URL   ");
	else
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"");
	
	if(options->showTime == 1)
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"08:16 http://www.miranda-im.org\n");
	else
		SendDlgItemMessage(hDlg, IDC_OPTIONS_RE, EM_REPLACESEL, FALSE, (LPARAM)"http://www.miranda-im.org\n");
	
	return 0;
}


/*
Write Message to window
*/
void WriteMessage(HWND hDlg, LISTELEMENT *listStart, int actLinePos)
{
	LISTELEMENT *actualElement;
	HANDLE hEvent;
	DBEVENTINFO dbe;
	
	actualElement = listStart->nextElement;
	while(actualElement != NULL)
	{
		if(actualElement->linePos == actLinePos)
		{
			hEvent = actualElement->hEvent;
			if(hEvent != NULL)
			{
				dbe.cbSize=sizeof(dbe);
				dbe.pBlob=NULL;
				dbe.cbBlob=(int)CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)hEvent,0);
				dbe.pBlob = (PBYTE)malloc(dbe.cbBlob+1);
				CallService(MS_DB_EVENT_GET,(WPARAM)hEvent,(LPARAM)&dbe);
				dbe.pBlob[dbe.cbBlob] = 0;
				SendDlgItemMessage(hDlg, IDC_MESSAGE, WM_SETTEXT , 0, (LPARAM)NULL);
				SendDlgItemMessage(hDlg, IDC_MESSAGE, EM_REPLACESEL, FALSE, (LPARAM)dbe.pBlob);
				free(dbe.pBlob);
			}
			break;
		}
		actualElement = actualElement->nextElement;
	}
	return;
}

/*
Little helper functions to get the actual state of
user options.
*/
char GetFlags(HMENU listMenu)
{
	char returnflags = 0x00;
	
	if(GetMenuState(listMenu, IDM_TYPE_WEB, MF_BYCOMMAND) == MF_UNCHECKED)
		returnflags = returnflags | WLL_MAIL;
	
	if(GetMenuState(listMenu, IDM_TYPE_MAIL, MF_BYCOMMAND) == MF_UNCHECKED)
		returnflags = returnflags | WLL_URL;
	
	if(GetMenuState(listMenu, IDM_DIR_IN, MF_BYCOMMAND) == MF_UNCHECKED)
		returnflags = returnflags | WLL_OUT;
	
	if(GetMenuState(listMenu, IDM_DIR_OUT, MF_BYCOMMAND) == MF_UNCHECKED)
		returnflags = returnflags | WLL_IN;
	
	return returnflags;
}

void GetFilterText(HMENU listMenu, char *filter)
{

	
	if(GetMenuState(listMenu, IDM_TYPE_WEB, MF_BYCOMMAND) == MF_CHECKED)
	{
		if(GetMenuState(listMenu, IDM_DIR_IN, MF_BYCOMMAND) == MF_CHECKED)
		{
			//incoming URLs
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), Translate(txtincoming), Translate(txturlsonly));
		}
		else if(GetMenuState(listMenu, IDM_DIR_OUT, MF_BYCOMMAND) == MF_CHECKED)
		{
			//outgoing URLs
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), Translate(txtoutgoing), Translate(txturlsonly));
		}
		else
		{
			// both directions (URL)
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), "", Translate(txturlsonly));
		}
	}
	else if(GetMenuState(listMenu, IDM_TYPE_MAIL, MF_BYCOMMAND) == MF_CHECKED)
	{
		if(GetMenuState(listMenu, IDM_DIR_IN, MF_BYCOMMAND) == MF_CHECKED)
		{
			//incoming mail
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), Translate(txtincoming), Translate(txtmailsonly));
		}
		else if(GetMenuState(listMenu, IDM_DIR_OUT, MF_BYCOMMAND) == MF_CHECKED)
		{
			//outgoing mail
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), Translate(txtoutgoing), Translate(txtmailsonly));
		}
		else
		{
			// both directions (mail)
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), "", Translate(txtmailsonly));
		}
	}
	else
	{
		if(GetMenuState(listMenu, IDM_DIR_IN, MF_BYCOMMAND) == MF_CHECKED)
		{
			//incoming (both)
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), Translate(txtincoming), "");
		}
		else if(GetMenuState(listMenu, IDM_DIR_OUT, MF_BYCOMMAND) == MF_CHECKED)
		{
			//outgoing (both)
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), Translate(txtoutgoing), "");
		}
		else
		{
			// no filter
			_snprintf(filter, FILTERTEXT, "%s: %s %s", Translate(txtfilter), Translate(txtnofilter), "");
		}
	}
	
	return;
}


/*
Little helper function to draw a horizontal line
*/
void DrawLine(HWND hDlg, int lineLen)
{
	char line[LINK_MAX + 18];
	int i;
	for(i=0; (i<lineLen+18)&&(i< LINK_MAX + 18); i++)
	{
		line[i] = '_';
	}
	line[lineLen+18] = '\0';
	SendDlgItemMessage( hDlg, IDC_MAIN, EM_REPLACESEL, FALSE, (LPARAM)line);
	SendDlgItemMessage( hDlg, IDC_MAIN, EM_REPLACESEL, FALSE, (LPARAM) "\n");
	return;
}


/*
Littel helper function to get informations about the linked list, such as number of links, etc
*/
void GetListInfo(char param, LISTELEMENT *listStart, char *searchString, int *maxLen, int *elementCount, int *realElementCount)
{
	int tempLen;		
	LISTELEMENT *actualElement;
	char filter1, filter2, filter3;
	int count = 0;
	DBEVENTINFO dbe;

	*maxLen=0;
	*elementCount=0;
	*realElementCount=0;
	actualElement = listStart->nextElement;
	
	while(actualElement != NULL)
	{
		(*realElementCount)++;

		filter1 = 0;
		filter2 = 0;
		filter3 = 0;
			
		if((param & WLL_IN) && (strcmp(actualElement->direction, "[in ]") == 0))
			filter1 = 1;
		else if((param & WLL_OUT) && (strcmp(actualElement->direction, "[out]") == 0))
			filter1 = 1;
			
		if((param & WLL_MAIL) && (strcmp(actualElement->type, "mail") == 0))
			filter2 = 1;
		else if((param & WLL_URL) && (strcmp(actualElement->type, "URL ") == 0))
			filter2 = 1;
		
		if(searchString != NULL)
		{
			if(param & SLL_DEEP)
			{	
				// Perform deep scan
				if(actualElement->hEvent != NULL)
				{
					dbe.cbSize=sizeof(dbe);
					dbe.pBlob=NULL;
					dbe.cbBlob=(int)CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)actualElement->hEvent,0);
					dbe.pBlob = (PBYTE)malloc(dbe.cbBlob+1);
					CallService(MS_DB_EVENT_GET,(WPARAM)actualElement->hEvent,(LPARAM)&dbe);
					dbe.pBlob[dbe.cbBlob] = 0;
					if(_mbsstr(dbe.pBlob, searchString))
						filter3 = 1;						
					
					free(dbe.pBlob);
				}
				else
					filter3 = 0;
			}
			else
			{
				if(_mbsstr(actualElement->link, searchString))
					filter3 = 1;
			}
		}
		else
			filter3 = 1;

		if((filter1 == 1) && (filter2 == 1) && (filter3 == 1))	
		{
			(*elementCount)++;

			tempLen = strlen(actualElement->link);
			if(*maxLen < tempLen)
				*maxLen = tempLen;
		}
		actualElement = actualElement->nextElement;
	}
	return;
}



void GetListOptions(LISTOPTIONS *options)
{

	options->openNewWindow = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_OPEN_WINDOW, 0xFF);
	if(options->openNewWindow == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_OPEN_WINDOW, 0x00);
		options->openNewWindow = 0x00;
	}

	
	options->updateWindow = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_UPDATE_WINDOW, 0xFF);
	if(options->updateWindow == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_UPDATE_WINDOW, 0x00);
		options->updateWindow = 0x00;
	}

	options->mouseEvent = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_MOUSE_EVENT, 0xFF);
	if(options->mouseEvent == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_MOUSE_EVENT, 0x00);
		options->mouseEvent = 0x00;
	}

	options->saveSpecial = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SAVESPECIAL, 0xFF);
	if(options->saveSpecial == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SAVESPECIAL, 0x00);
		options->saveSpecial = 0x00;
	}


	options->showDate = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_DATE, 0xFF);
	if(options->showDate == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_DATE, 0x01);
		options->showDate = 0x01;
	}

	options->showLine = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_LINE, 0xFF);
	if(options->showLine == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_LINE, 0x01);
		options->showLine = 0x01;
	}

	options->showTime = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_TIME, 0xFF);
	if(options->showTime == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_TIME, 0x01);
		options->showTime = 0x01;
	}

	options->showDirection = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_DIRECTION, 0xFF);
	if(options->showDirection == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_DIRECTION, 0x01);
		options->showDirection = 0x01;
	}

	options->showType = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_TYPE, 0xFF);
	if(options->showType == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_TYPE, 0x01);
		options->showType = 0x01;
	}

	return;
}

void SetListOptions(LISTOPTIONS *options)
{

	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_OPEN_WINDOW, options->openNewWindow);
	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_UPDATE_WINDOW, options->updateWindow);
	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_MOUSE_EVENT, options->mouseEvent);
	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SAVESPECIAL, options->saveSpecial);
	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_DATE, options->showDate);
	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_LINE, options->showLine);
	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_TIME, options->showTime);
	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_DIRECTION, options->showDirection);
	DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_SHOW_TYPE, options->showType);

	return;
}




/*
Clear temporary stored Linenumbers in List
*/
void ClearLinePos(LISTELEMENT *listStart)
{
	LISTELEMENT *actualElement;

	if(listStart == NULL)
		return;

	actualElement = listStart->nextElement;
	while(actualElement != NULL)
	{
		actualElement->linePos = -1;
		actualElement = actualElement->nextElement;
	}
	return;
}

int GetLastLinePos(LISTELEMENT *listStart)
{
	LISTELEMENT *actualElement;
	int maxPos = -1;


	if(listStart == NULL)
		return -1;

	actualElement = listStart->nextElement;
	while(actualElement != NULL)
	{
		if(actualElement->linePos > maxPos)
			maxPos = actualElement->linePos;

		actualElement = actualElement->nextElement;
	}
	return maxPos;
}


/*
Read current coloursettings from the database
*/
int GetColour(MYCOLOURSET *colourSet)
{
	DWORD colour;
	BYTE useDefault;

	useDefault = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_USE_DEF, 0xFF);
	if(useDefault == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_USE_DEF, 0x01);
		useDefault = 0x01;
	}

	if(useDefault == 0x01)
	{
		// Use Miranda-IM Default colours
		// CHANGED AT MIRANDA 0.4!!!!
		// Use SRMM... if it is not there try SRMsg (older Miranda Versions)
		colour = DBGetContactSettingDword(NULL, "SRMM", "SRMFont1Col", 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->incoming = colour;
		else
		{
			colour = DBGetContactSettingDword(NULL, "SRMsg", "Font3Col", 0xFF000000);
			if(colour != 0xFF000000)
				colourSet->incoming = colour;
			else
			{
				DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_USE_DEF, 0x00);
				useDefault = 0x00;
			}
		}
		
		// SRMM
		colour = DBGetContactSettingDword(NULL, "SRMM", "SRMFont0Col", 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->outgoing = colour;
		else
		{
			// SRMsg
			colour = DBGetContactSettingDword(NULL, "SRMsg", "Font0Col", 0xFF000000);
			if(colour != 0xFF000000)
				colourSet->outgoing = colour;
			else
			{
				DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_USE_DEF, 0x00);
				useDefault = 0x00;
			}
		}

		// SRMM
		colour = DBGetContactSettingDword(NULL, "SRMM", "BkgColour", 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->background = colour;
		else
		{	
			// SRMsg
			colour = DBGetContactSettingDword(NULL, "SRMsg", "BkgColour", 0xFF000000);
			if(colour != 0xFF000000)
				colourSet->background = colour;
			else
			{
				DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_USE_DEF, 0x00);
				useDefault = 0x00;
			}
		}
		colourSet->text = MAKE_TXT_COL(colourSet->background);
	}

	if(useDefault == 0x00)
	{
		// Use Plugin user defined or default colours
		colour = DBGetContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_IN_COL, 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->incoming = colour;
		else
			colourSet->incoming = IN_COL_DEF;
	
		colour = DBGetContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_OUT_COL, 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->outgoing = colour;
		else
			colourSet->outgoing = OUT_COL_DEF;
	
		colour = DBGetContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_BG_COL, 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->background = colour;
		else
			colourSet->background = BG_COL_DEF;

		colour = DBGetContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_TXT_COL, 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->text = colour;
		else
			colourSet->text = TXT_COL_DEF;
	}
	return 0;
}


/*
Read current coloursettings from the database and set default values
if entry does not exist.
*/
int GetDBColour(MYCOLOURSET *colourSet)
{
	DWORD colour;

	// Use Plugin user defined or default colours
	colour = DBGetContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_IN_COL, 0xFF000000);
	if(colour != 0xFF000000)
		colourSet->incoming = colour;
	else
	{
		DBWriteContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_IN_COL, IN_COL_DEF);
		colourSet->incoming = IN_COL_DEF;
	}

	colour = DBGetContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_OUT_COL, 0xFF000000);
	if(colour != 0xFF000000)
		colourSet->outgoing = colour;
	else
	{	
		DBWriteContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_OUT_COL, OUT_COL_DEF);
		colourSet->outgoing = OUT_COL_DEF;
	}

	colour = DBGetContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_BG_COL, 0xFF000000);
	if(colour != 0xFF000000)
		colourSet->background = colour;
	else
	{
		DBWriteContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_BG_COL, BG_COL_DEF);
		colourSet->background = BG_COL_DEF;
	}

	colour = DBGetContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_TXT_COL, 0xFF000000);
	if(colour != 0xFF000000)
		colourSet->text = colour;
	else
	{
		DBWriteContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_TXT_COL, TXT_COL_DEF);
		colourSet->text = TXT_COL_DEF;
	}

	return 0;
}


/*
Read current coloursettings from the database (Miranda settings)
*/
int GetMirandaColour(MYCOLOURSET *colourSet)
{
	DWORD colour;

	// Use Miranda-IM Default colours
	// Try SRMM (Miranda 0.4) .... or SRMsg... for older versions
	colour = DBGetContactSettingDword(NULL, "SRMM", "SRMFont1Col", 0xFF000000);
	if(colour != 0xFF000000)
		colourSet->incoming = colour;
	else
	{
		colour = DBGetContactSettingDword(NULL, "SRMsg", "Font3Col", 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->incoming = colour;
		else
			return 1;	
	}
		

	colour = DBGetContactSettingDword(NULL, "SRMM", "SRMFont0Col", 0xFF000000);
	if(colour != 0xFF000000)
		colourSet->outgoing = colour;
	else
	{
		colour = DBGetContactSettingDword(NULL, "SRMsg", "Font0Col", 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->outgoing = colour;
		else
			return 1;
	}

	colour = DBGetContactSettingDword(NULL, "SRMM", "BkgColour", 0xFF000000);
	if(colour != 0xFF000000)
		colourSet->background = colour;
	else
	{	
		colour = DBGetContactSettingDword(NULL, "SRMsg", "BkgColour", 0xFF000000);
		if(colour != 0xFF000000)
			colourSet->background = colour;
		else
			return 1;
	}

	colourSet->text = MAKE_TXT_COL(colourSet->background);
	return 0;
}


/*
Write user defined colours to the database
*/
int SetDBColour(MYCOLOURSET *colourSet)
{
	DBWriteContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_IN_COL, colourSet->incoming);
	DBWriteContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_OUT_COL, colourSet->outgoing);
	DBWriteContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_BG_COL, colourSet->background);
	DBWriteContactSettingDword(NULL, LINKLIST_MODULE, LINKLIST_TXT_COL, colourSet->text);
	
	return 0;
}


char GetUpdateSetting(void)
{
	BYTE updateWindow;
	
	updateWindow = DBGetContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_UPDATE_WINDOW, 0xFF);
	if(updateWindow == 0xFF)
	{
		// No DB entry for this Plugin
		DBWriteContactSettingByte(NULL, LINKLIST_MODULE, LINKLIST_UPDATE_WINDOW, 0x00);
		return 0;
	}
	if(updateWindow == 0x00)
		return 0;
	else
		return 1;

}

/*
Special thanks to Tobi H.!
This function is derived from his Wordlookup Plugin
*/
int DBUpdate(WPARAM wParam, LPARAM lParam)
{
	HANDLE hEvent=(HANDLE)lParam;
	HANDLE hDlg = WindowList_Find(hWindowList, (HANDLE)wParam);
	DBEVENTINFO dbe;
	DIALOGPARAM *DlgParam;
	HMENU listMenu = GetMenu(hDlg);
	int linkNum = 0;
	
	DlgParam = (DIALOGPARAM *)GetWindowLong(hDlg,GWL_USERDATA);

	if(GetUpdateSetting() != 1)
		return 0;

	if(hDlg)
	{
		ZeroMemory(&dbe,sizeof(dbe));
		dbe.cbSize=sizeof(dbe);
		dbe.pBlob=NULL;

		dbe.cbBlob=(int)CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)hEvent,0);
		dbe.pBlob = (PBYTE)malloc(dbe.cbBlob+1);
		CallService(MS_DB_EVENT_GET,(WPARAM)hEvent,(LPARAM)&dbe);
		
		if((dbe.eventType == EVENTTYPE_URL) || (dbe.eventType == EVENTTYPE_MESSAGE))
		{
			// Call function to find URIs
			linkNum = ExtractURI(&dbe, hEvent, DlgParam->listStart);
			if( linkNum > 0)
				WriteLinkList(hDlg, GetFlags(listMenu), DlgParam->listStart, NULL, linkNum); 
		}
		free(dbe.pBlob);
	}
	return 0;
}


/*
Little resize helper
*/
int LinklistResizer(HWND hDlg,LPARAM lParam,UTILRESIZECONTROL *urc) 
{
	DIALOGPARAM *DlgParam = (DIALOGPARAM*) lParam;
	
	switch(urc->wId) 
	{
		case IDC_MAIN:
	
			
			urc->rcItem.bottom -= DlgParam->splitterPosNew - DlgParam->splitterPosOld; 
			return RD_ANCHORX_WIDTH|RD_ANCHORY_HEIGHT;

		case IDC_MESSAGE:
			urc->rcItem.top -= DlgParam->splitterPosNew - DlgParam->splitterPosOld; 
			return RD_ANCHORX_WIDTH|RD_ANCHORY_BOTTOM;
	
		case IDC_STATUS:
			return RD_ANCHORX_WIDTH|RD_ANCHORY_BOTTOM;
		
		case IDC_SPLITTER:
            urc->rcItem.top -= DlgParam->splitterPosNew - DlgParam->splitterPosOld;
            urc->rcItem.bottom -= DlgParam->splitterPosNew - DlgParam->splitterPosOld;
            return RD_ANCHORX_WIDTH|RD_ANCHORY_BOTTOM;


	}
	return RD_ANCHORX_LEFT|RD_ANCHORY_TOP;
}


/*
Next both functions are taken from a example projekt, found at 
http://www.programmersheaven.com/zone15/cat236/2405.htm
The author is unknown, but this peace of code made my work much
easier!
*/
BOOL SaveEditAsStream( HWND hDlg )
{
	EDITSTREAM es;
	LONG lOut;
	OPENFILENAME ofn;
	HANDLE hFile;
	char szFilename[ 256 ];

	// Initialize structure
	memset( &ofn, 0, sizeof(OPENFILENAME) );            
	// Initialize filename field
	strcpy( szFilename, "*.rtf" );                 
	// Fill in OPENFILENAME struct
	ofn.lStructSize = sizeof(OPENFILENAME);      
	ofn.hwndOwner = hDlg;
	ofn.lpstrFilter = "RTF File\0*.rtf\0All Files\0*.*\0\0";
	ofn.lpstrFile = szFilename;
	ofn.nMaxFile = 256;
	ofn.lpstrTitle = "Save RTF File";
	ofn.Flags = OFN_OVERWRITEPROMPT;
	// Get a filename or quit
	if( ! GetSaveFileName( &ofn ) )                   
		return FALSE;
	//  Create the specified file
	hFile = CreateFile( szFilename, GENERIC_READ | GENERIC_WRITE, 0, NULL,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
	//  Quit if file creation fails
	if( hFile == INVALID_HANDLE_VALUE )
		return FALSE;
	//  Pass file handle to callback
	//  so the callback can do the file write
	es.dwCookie = (DWORD)hFile;                 
	es.dwError = 0;								
	es.pfnCallback = (EDITSTREAMCALLBACK)RTFSaveStreamCallback;
	// Start the callback proc
	lOut = SendDlgItemMessage( hDlg, IDC_MAIN, EM_STREAMOUT, SF_RTF, (LPARAM)&es );
	// Close file handle and exit
	CloseHandle(hFile);
	return TRUE;
}


DWORD CALLBACK RTFSaveStreamCallback( DWORD dwCookie, LPBYTE lpBuffer, LONG lSize, LONG *plRead )
{
	// Sanity check...exit if nothing passed
	if( ! lSize )                      
		return 1;
	// Initialize "amount read" variable for WriteFile()
	*plRead = 0;           
	// dwCookie is the file handle
	WriteFile( (HANDLE)dwCookie, lpBuffer, lSize, (unsigned long *)plRead, NULL );
	// Continue, if needed
	return 0;
}


