/*
Miranda Linklist plugin by Thomas Wendel.

http://www.miranda-im.org/

This file is placed in the public domain. Anybody is free to use or
modify it as they wish with no restriction.
There is no warranty.
*/
#include <windows.h>
#include "resource.h"

// Miranda SDK Includes
#include "../SDK/headers_c/newpluginapi.h"
#include "../SDK/headers_c/m_clist.h"
#include "../SDK/headers_c/m_database.h"
#include "../SDK/headers_c/m_utils.h"
#include "../SDK/headers_c/m_langpack.h"
#include "../SDK/headers_c/m_options.h"

#include "linklist_dlg.h"
#include "linklist_fct.h"
#include "linklist.h"
#include "language.h"

#define MIID_LINKLIST  { 0xc9c94733, 0xa054, 0x42b9, { 0x89, 0xcb, 0xb9, 0x71, 0x27, 0xa7, 0xa3, 0x43 } }



// Global variables
HINSTANCE hInst;                                    
HINSTANCE hRichEdit;                                
PLUGINLINK *pluginLink;
HANDLE hWindowList;
HCURSOR splitCursor;



PLUGININFOEX pluginInfo={
	sizeof(PLUGININFOEX),
		"History Linklist",
		PLUGIN_MAKE_VERSION(0,1,1,2),
		"Generates a list of extracted URIs from the history",
		"Thomas Wendel",
		"ThomasWendel@gmx.de",
		"� 2005-2008 Thomas Wendel",
		"http://www.miranda-im.org",
		0,		//not transient
		0,		//doesn't replace anything built-in
		#if defined( _UNICODE )
		{ 0x95dfa6d6, 0x80c3, 0x4166, { 0x8a, 0x6f, 0x93, 0xca, 0xf1, 0x9f, 0x79, 0x62 } }
		// {95DFA6D6-80C3-4166-8A6F-93CAF19F7962}
		#else
		{ 0x6700bf82, 0x4e1d, 0x4ff9, { 0x80, 0x7, 0xe5, 0x73, 0x3b, 0x11, 0x45, 0xc7 } }
		// {6700BF82-4E1D-4ff9-8007-E5733B1145C7}
		#endif
};

static const MUUID interfaces[] = {MIID_LINKLIST, MIID_LAST};



// Functions



__declspec(dllexport) const MUUID * MirandaPluginInterfaces(void)
{
	return interfaces;
}


BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst = hinstDLL;
	//  Load Rich Edit control
	if((fdwReason == DLL_PROCESS_ATTACH) || (fdwReason == DLL_THREAD_ATTACH))
	{
		hRichEdit = LoadLibrary("RICHED32.DLL");        
		if(!hRichEdit)
		{   
			//  If Rich Edit DLL load fails, exit
			MessageBox(NULL, Translate(txtunabletoload), Translate(txterror), MB_OK | MB_ICONEXCLAMATION );
			return FALSE;
		}
		DisableThreadLibraryCalls(hinstDLL);
	}
	if((fdwReason == DLL_PROCESS_DETACH) || (fdwReason == DLL_THREAD_DETACH))
		FreeLibrary( hRichEdit );

	return TRUE;
}


int __declspec(dllexport) Load(PLUGINLINK *link)
{
	CLISTMENUITEM linklistmenuitem;
	WNDCLASS wndclass;

	pluginLink = link;
	CreateServiceFunction("Linklist/MenuCommand",LinkList_Main);
	ZeroMemory(&linklistmenuitem,sizeof(linklistmenuitem));
	linklistmenuitem.cbSize=sizeof(linklistmenuitem);
	linklistmenuitem.position=0x00;
	linklistmenuitem.flags=0;
	linklistmenuitem.hIcon=LoadIconA(hInst, MAKEINTRESOURCE(IDI_LINKLISTICON));
	linklistmenuitem.pszName=Translate(txtcreate);
	linklistmenuitem.pszService="Linklist/MenuCommand";
	CallService(MS_CLIST_ADDCONTACTMENUITEM,0,(LPARAM)&linklistmenuitem);
	hWindowList=(HANDLE)CallService(MS_UTILS_ALLOCWINDOWLIST,0,0);

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = ProgressBarDlg;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInst;
	wndclass.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_LINKLISTICON));
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
	wndclass.lpszClassName = "Progressbar";
	wndclass.lpszMenuName = NULL;
	RegisterClass(&wndclass);

	HookEvent(ME_OPT_INITIALISE, InitOptionsDlg);
	HookEvent(ME_DB_EVENT_ADDED, DBUpdate);
	
	splitCursor = LoadCursor(NULL, IDC_SIZENS);
	return 0;
}




__declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	return &pluginInfo;
}
				 


int __declspec(dllexport) Unload(void)
{
	UnhookEvent(ME_DB_EVENT_ADDED);
	DestroyCursor(splitCursor);
	return 0;
}

int InitOptionsDlg(WPARAM wParam, LPARAM lParam)
{
	OPTIONSDIALOGPAGE optionsDialog;

	ZeroMemory(&optionsDialog, sizeof(OPTIONSDIALOGPAGE));
	optionsDialog.cbSize = sizeof(optionsDialog);
	optionsDialog.hInstance = hInst;
	optionsDialog.pszGroup = Translate(txtplugins);
	optionsDialog.pszTitle = Translate(txtpluginname);
	optionsDialog.pszTemplate = MAKEINTRESOURCE(IDD_OPTIONS_DLG);
	optionsDialog.pfnDlgProc = OptionsDlgProc;
	optionsDialog.expertOnlyControls = NULL;
	optionsDialog.nExpertOnlyControls = 0;
	optionsDialog.flags = ODPF_BOLDGROUPS;
	CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&optionsDialog);
	return 0;
}




static int LinkList_Main(WPARAM wParam,LPARAM lParam)
{
	HANDLE hEvent;
	HANDLE hContact = (HANDLE)wParam;
	DBEVENTINFO dbe;
    HWND hWnd;
	HWND hWndProgress;
	HWND hWndMain;

	int histCount = 0;
	int actCount = 0;
	
	RECT DesktopRect;
	DIALOGPARAM *DlgParam;
	LISTELEMENT *listStart;

	listStart = malloc(sizeof(LISTELEMENT));
	listStart->nextElement = NULL;

	if(hWnd = WindowList_Find(hWindowList,hContact)) 
	{
		int len;
		SetForegroundWindow(hWnd);
		SetFocus(hWnd);
		len = GetWindowTextLength(GetDlgItem(hWnd, IDC_MAIN));
		PostMessage(GetDlgItem(hWnd, IDC_MAIN), EM_SETSEL, len, len);
		return 0;
	}	
	
	hEvent = (HANDLE)CallService(MS_DB_EVENT_FINDFIRST, (WPARAM)hContact, 0);
	if (hEvent==NULL)
	{
		MessageBox(NULL, Translate(txthistoryempty), Translate(txtplugintitle), MB_OK | MB_ICONINFORMATION );
		return 0;
	}

	histCount = CallService(MS_DB_EVENT_GETCOUNT, (WPARAM)hContact, 0);
	ZeroMemory(&dbe,sizeof(dbe));
	dbe.cbSize=sizeof(dbe);
	dbe.pBlob=NULL;
	dbe.cbBlob=(int)CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)hEvent,0);
	dbe.pBlob = (PBYTE)malloc(dbe.cbBlob+1);
	CallService(MS_DB_EVENT_GET,(WPARAM)hEvent,(LPARAM)&dbe);
	dbe.pBlob[dbe.cbBlob] = 0;

	GetWindowRect(GetDesktopWindow(), &DesktopRect);
	if((hWndProgress = CreateWindow("Progressbar", Translate(txtprocessinghistory), WS_OVERLAPPED, CW_USEDEFAULT, CW_USEDEFAULT, 350, 45, NULL, NULL, hInst, NULL)) == 0)
	{
		free(dbe.pBlob);
		MessageBox(NULL, Translate(txtcouldnotcreate), Translate(txterror), MB_OK | MB_ICONEXCLAMATION );
		return -1;
	}
	SetWindowPos(hWndProgress,HWND_TOP,(int)(DesktopRect.right*0.5)-175,(int)(DesktopRect.bottom*0.5)-22,0,0,SWP_NOSIZE);
	ShowWindow(hWndProgress, SW_SHOW);
	SetForegroundWindow(hWndProgress);

	while(1)
	{
		if((dbe.eventType == EVENTTYPE_URL) || (dbe.eventType == EVENTTYPE_MESSAGE))
		{
			// Call function to find URIs
			if(ExtractURI(&dbe, hEvent, listStart) < 0)
			{
				free(dbe.pBlob);
				RemoveList(listStart);
				MessageBox(NULL, Translate(txtcouldnotallocate),Translate(txterror), MB_OK | MB_ICONEXCLAMATION);
				return -1;
			}
		}
		actCount++;
		if( ((int)(((float)actCount/histCount)*100.00)) % 10 == 0)
			SendMessage(hWndProgress, WM_COMMAND, 100,((int)(((float)actCount/histCount)*100.00)));
		
		if((hEvent = (HANDLE)CallService(MS_DB_EVENT_FINDNEXT, (WPARAM)hEvent, 0)) == NULL)
			break;

		dbe.cbBlob=(int)CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)hEvent,0);
		free(dbe.pBlob);
		dbe.pBlob = (PBYTE)malloc(dbe.cbBlob+1);
		CallService(MS_DB_EVENT_GET,(WPARAM)hEvent,(LPARAM)&dbe);
		dbe.pBlob[dbe.cbBlob] = 0;
	}
	free(dbe.pBlob);
	SendMessage(hWndProgress, WM_CLOSE,0 , 0);
	if(ListCount(listStart) <= 0)
	{	
		RemoveList(listStart);
		MessageBox(NULL, Translate(txtnolinksinhistory), Translate(txtplugintitle), MB_OK | MB_ICONINFORMATION);
		return 0;
	}
	DlgParam = malloc(sizeof(DIALOGPARAM));
	DlgParam->hContact = hContact;
	DlgParam->listStart = listStart;
	DlgParam->findMessage = 0;
	DlgParam->chrg.cpMax = -1;
	DlgParam->chrg.cpMin = -1;

	if((hWndMain = CreateDialogParam(hInst, MAKEINTRESOURCE(IDD_MAIN_DLG), NULL, MainDlgProc, (LPARAM)DlgParam)) == 0)
	{
		RemoveList(listStart);
		MessageBox(NULL, Translate(txtcouldnotcreate), Translate(txterror), MB_OK | MB_ICONEXCLAMATION );
		return -1;
	}
	ShowWindow(hWndMain, SW_SHOW);	
	return 0;
}
