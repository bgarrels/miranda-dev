#ifndef _LINKLIST_H
#define _LINKLIST_H
/*
Miranda Linklist plugin by Thomas Wendel.

http://www.miranda-im.org/

This file is placed in the public domain. Anybody is free to use or
modify it as they wish with no restriction.
There is no warranty.
*/
#define WIN32_LEAN_AND_MEAN
#include <richedit.h>

// Filter Flags
#define WLL_URL		0x01
#define WLL_MAIL	0x02
#define WLL_FILE	0x04
#define WLL_IN		0x08
#define WLL_OUT		0x10
#define WLL_ALL		0x1F
#define SLL_DEEP	0x20

// String length
#define LINK_MAX 1024
#define DIR_SIZE	6
#define TYPE_SIZE	5
#define DATE_SIZE	11
#define TIME_SIZE	9

#define FILTERTEXT	125

#define IN_COL_DEF	0x005050A0
#define	OUT_COL_DEF	0x00206020
#define BG_COL_DEF	0x00EAFFFF
#define TXT_COL_DEF	0x00000000

#define LINKLIST_MODULE			"HistoryLinklist"
#define LINKLIST_IN_COL			"InColour"
#define LINKLIST_OUT_COL		"OutColour"
#define LINKLIST_BG_COL			"BGColour"
#define LINKLIST_TXT_COL		"TxtColour"
#define LINKLIST_USE_DEF		"UseMirandaDefault"
#define LINKLIST_OPEN_WINDOW	"OpenNewWindow"
#define LINKLIST_UPDATE_WINDOW	"UpdateWindow"
#define LINKLIST_MOUSE_EVENT	"MessageView"
#define LINKLIST_LEFT			"WindowLeft"
#define LINKLIST_RIGHT			"WindowRight"
#define LINKLIST_BOTTOM			"WindowBottom"
#define LINKLIST_TOP			"WindowTop"
#define LINKLIST_SPLITPOS		"SplitterPos"
#define LINKLIST_SAVESPECIAL	"SavePosSpecial"
#define LINKLIST_FIRST			"FirstStartup"
#define LINKLIST_SHOW_DATE		"ShowDate"
#define LINKLIST_SHOW_LINE		"ShowLine"
#define LINKLIST_SHOW_TIME		"ShowTime"
#define LINKLIST_SHOW_DIRECTION	"ShowMessageDirection"
#define LINKLIST_SHOW_TYPE		"ShowMessageType"



#define MAKE_TXT_COL(BGCol) ((DWORD)~BGCol & 0x00FFFFFF)

#define DM_LINKSPLITTER			WM_USER+99

struct LISTELEMENT{
	char direction[DIR_SIZE];
	char type[TYPE_SIZE];
	char date[DATE_SIZE];
	char time[TIME_SIZE];
	char link[LINK_MAX];
	HANDLE hEvent;
	int	linePos;
	struct LISTELEMENT *nextElement;
};

typedef struct LISTELEMENT LISTELEMENT ;

// Dialogbox Parameter
typedef struct{
	HANDLE hContact;
	LISTELEMENT *listStart;
	UINT findMessage;
	CHARRANGE chrg;
	int splitterPosNew;
	int splitterPosOld;
	SIZE minSize;
}DIALOGPARAM;


typedef struct{
	DWORD incoming;
	DWORD outgoing;
	DWORD background;
	DWORD text;
}MYCOLOURSET;


typedef struct{
	BYTE openNewWindow;
	BYTE updateWindow;
	BYTE mouseEvent;
	BYTE saveSpecial;
	BYTE showDate;
	BYTE showLine;
	BYTE showTime;
	BYTE showDirection;
	BYTE showType;
}LISTOPTIONS;


BOOL WINAPI DllMain(HINSTANCE ,DWORD ,LPVOID );
int __declspec(dllexport) Load(PLUGINLINK*);
__declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD);
int __declspec(dllexport) Unload(void);
static int LinkList_Main(WPARAM, LPARAM);
int InitOptionsDlg(WPARAM, LPARAM);

#endif //_LINKLIST_H