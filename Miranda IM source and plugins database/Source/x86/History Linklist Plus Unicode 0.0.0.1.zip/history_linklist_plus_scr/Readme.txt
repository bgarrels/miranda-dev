History Linklist Plugin for Miranda-IM
--------------------------------------

Version 0.1.1.2
Date: 05/02/2008
Tested with Miranda 0.7.4 AND 0.8 ALPHA BUILD 9


--------------
This plugin searches the history of a contact for URLs and e-mailaddresses 
and shows them in a new window.
(The translation strings can be found in language.txt)


IMPORTANT:
If you want to build the binary yourself:
I've used the LibCTiny which can be found here:
http://msdn.microsoft.com/msdnmag/issues/01/01/hood/default.aspx
Copy this file to your LIB directory or remove this library from
the projects linker-options if you don't want to use it.



Features:
- It's possible to filter the messages after direction (incoming or outgoing)
and message type (mailaddress or URL)
- The list can be saved as RTF-File
- It's possible to search the list
- Colours can be changed in the options dialog
- The message where the link was found can be displayed and searched



Changelog:

Version 0.1.1.2:
----------------

Bugfix:
- Plugin supports UUID and can be used in Miranda 0.8.



Version 0.1.1.1:
----------------

Bugfix:
- Version 0.1.1.0 contained a bug which causes the plugin and miranda to crash!
This bug was caused by the newly introduced support for file-links in the style \\file.xyz.
I'm very sorry for that!



Version 0.1.1.0:
----------------

After some time of inactivity I added some new features and fixed some bugs.
I've decided to change the version number to 1.1.0.

New Features:
- The options dialogue allows you to chose if the date, parting line, timestamp,
message direction and message type should be displayed or not.
(Current selection is updated in the preview window)
- Added support for file-URLs like URLs prefixed with file:// or URLs in the 
style \\server\file.xyz. These URLs are treated like normal URLs regarding 
filter or search rules.

Bugfix:
- URLs are no longer shifted to lowercase! This was a bug and case sensitive webservers
reported a HTTP-Error 404 (File not found).



Version 0.1.0.4:
----------------

NO FUNCTIONAL CHANGE FROM VERSION 0.1.0.3 to 0.1.0.4
VERSION 0.1.0.4 WORKS WITH THE NEW MESSAGING PLUGIN SRMM!
The changes regards only colour settings as they are taken from the
database if the option "Use Miranda Settings" is used!
The plugin should now work with Miranda IM Version 0.4 AND 0.3.3.1
Colour Settings now work this way:
Use SRMM settings if present in the database.
If not, use SRMsg settings if present and finaly if both settings
are not found use the plugin default.



Version 0.1.0.3:
----------------

New Features:
- The window position and size is now stored in the database. It's possible to save global
or contact specific.
- The message window to view the message a link was found is now resizable!
If you don't like it, just drag it to the bottom.

Bugfix:
- Times with a AM or PM suffix caused double displayed (and sometimes not working) links.



Version 0.1.0.2:
----------------

New Features:
- The current filter settings are displayed in a statusbar
- A new text field displays the whole message where a link was found.
The message can be displayed by mouse over (disabled by default) or by right mouse button
menuoption "show message"
- The search option "deep search" allows you to search not only the links but also
the messages that contains the links.
 
Bugfix: 
- Wrong color settings for search results fixed
- Click on a mailaddress caused a new browser window when the option "open always in new window" was selected
- A new link in the history will not cause the whole list to be rewritten if "automatic update" is enabled
(this was not a real bug, but a problem)
- Added language support for the search dialog



Version 0.1.0.1:
----------------

New Features:
- You're now able to chose if links should alwas open a new browser window (on left click).
- Open linklistwindows will be updatet automatically if this option is enabled in the options dialog. (See description below)
 
Bugfix: 
- URLs containing '@' such as ftp or http URLs are no longer prefixed with "mailto:"




(c) 2005-2008 Thomas Wendel (ThomasWendel@gmx.de)