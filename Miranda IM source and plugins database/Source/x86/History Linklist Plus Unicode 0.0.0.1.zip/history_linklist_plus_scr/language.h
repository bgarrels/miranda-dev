#ifndef _LANGUAGE_H
#define _LANGUAGE_H
/*
Miranda Linklist plugin by Thomas Wendel.

http://www.miranda-im.org/

This file is placed in the public domain. Anybody is free to use or
modify it as they wish with no restriction.
There is no warranty.
*/

extern char *txterror;
extern char *txtunabletoload;
extern char *txtcreate;
extern char *txtplugins;
extern char *txtpluginname;
extern char *txtplugintitle;
extern char *txthistoryempty;
extern char *txtprocessinghistory;
extern char *txtprocessinglist;
extern char *txtcouldnotcreate;
extern char *txtcouldnotallocate;
extern char *txtnolinksinhistory;
extern char *txtmatches;
extern char *txtnomessagesfound;
extern char *txtdate;
extern char *txtmirandalinklist;
extern char *txtsearch;
extern char *txtnosettings;
extern char *txtfilter;
extern char *txtnofilter;
extern char *txtmailsonly;
extern char *txturlsonly;
extern char *txtincoming;
extern char *txtoutgoing;
extern char *txtsearchfilter;


#endif // _LANGUAGE_H