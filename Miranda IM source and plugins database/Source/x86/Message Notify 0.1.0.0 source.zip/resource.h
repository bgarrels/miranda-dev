//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDD_OPTIONS                     101
#define IDC_CHK_DISABLEPOPUPS           1000
#define IDC_RAD_CLOSED                  1001
#define IDC_RAD_NFORE                   1002
#define IDC_RAD_ALWAYS                  1003
#define IDC_CHK_SETTIMEOUT              1004
#define IDC_ED_TIMEOUT                  1005
#define IDC_CHK_SETCOLOURS              1006
#define IDC_CP_BK                       1007
#define IDC_CP_TXT                      1008
#define IDC_CHK_TABS                    1009
#define IDC_CHK_CLOSE                   1010
#define IDC_LIST1                       1012
#define IDC_LST_STATUS                  1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
