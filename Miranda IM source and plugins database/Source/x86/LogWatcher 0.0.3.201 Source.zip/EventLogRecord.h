#ifndef EventLogRecord_h
#define EventLogRecord_h

#include <windef.h>

#include <string>
#include <vector>
#include <sstream>

class EventLogRecord {
	const EVENTLOGRECORD *m_p;
	EventLogRecord()
		: m_p(NULL) {}
public:
	EventLogRecord(const EVENTLOGRECORD * p)
		: m_p(p) {}

	DWORD Length() { return m_p->Length; };
	DWORD RecordNumber() { return m_p->RecordNumber; };
	DWORD TimeGenerated() { return m_p->TimeGenerated; };
	DWORD TimeWritten() { return m_p->TimeWritten; };
	DWORD EventID() { return m_p->EventID; };
	WORD EventType() { return m_p->EventType; };
	WORD EventCategory() { return m_p->EventCategory; };

	std::wstring SourceName() { return (wchar_t*)((char*)m_p+56); };

	std::wstring ComputerName() 
		{ return ((wchar_t*)(m_p+1))+SourceName().length()+1; };

	BYTE *Data() { return (BYTE*)m_p+m_p->DataOffset; };

	DWORD DataLength() { return m_p->DataLength; };
};
 
#endif
