#include "plugin.h"
#include "nodes.h"

set_node::set_node()
{
}

void set_node::init(stringmap_t &defaults, const xml::welement &opt)
{
	getattr(opt, L"var", var, L"send", defaults);
	getattr(opt, L"value", value, L"send", defaults);

	if (opt.begin())
		lw_error(L"<set> must be empty");

	if (var.empty() || !opt.attr(L"value"))
		lw_error(L"Attributes var and value are required for <set>.");
}

int set_node::handle(action_data_t &fi)
{
	std::wstring v = replace_vars(value, fi);
	lw_log(L"   set: \"" + var + L"\"=\"" + v + L'\"', true);
	if (v.empty())
		fi.vars.erase(var);
	else
		fi.vars[var] = v;

	return 0;
}
