#include "plugin.h"
#include "nodes.h"

bool getdef(const stringmap_t &defaults, const std::wstring &id, std::wstring &value)
{
	stringmap_t::const_iterator i = defaults.find(id);
	if (i != defaults.end()) {
		value = i->second;
		return true;
	} else
		return false;
}

wnode::~wnode()
{
}

wnode *wnode::make_node(stringmap_t &defaults, const xml::welement &opt)
{
	std::wstring type = opt.tag();

	wnode *node = 0;
	if (type == L"send")
		node = new send_node;
	else if (type == L"match")
		node = new match_node;
	else if (type == L"set")
		node = new set_node;
	else if (type == L"block")
		node = new block_node;
	else if (type == L"switch")
		node = new switch_node;
	else if (type == L"break")
		node = new break_node;
	else if (type == L"loop")
		node = new loop_node;
	else
		lw_error(L"unknown node type: " + type);

	node->init(defaults, opt);
	return node;
}

std::wstring escape_regex(const std::wstring &str)
{
	std::wstring ret;
	for (int i=0; i!=str.size(); ++i) {
		wchar_t c = str[i];
		if (wcschr(L".|*?+(){}[]^$\\", c))
			ret += '\\';
		ret += c;
	}
	return ret;
}

std::wstring replace_vars(const std::wstring &str, const action_data_t &fi, bool regexp)
{
	const wchar_t *lstart = str.c_str();
	const wchar_t *lend = wcschr(lstart, L'%');

	if (!lend) return str;

	std::wstring res(lstart, lend);
	for (;;) {
		const wchar_t *vstart = lend+1;
		const wchar_t *vend = wcschr(vstart, L'%');
		if (!vend)
			lw_error(L"Unterminated variable reference");

		if (vstart == vend) // %%
			res += L'%';
		else {
			std::wstring var(vstart, vend);
			std::map<std::wstring, std::wstring>::const_iterator i=fi.vars.find(var);
			if (i != fi.vars.end()) {
				if (regexp) {
					res += L"(";
					res += escape_regex(i->second);
					res += L')';
				} else
					res += i->second;
			} else if (regexp)
				res += L"(?:)";
		}

		lstart = vend+1;
		lend = wcschr(lstart, L'%');

		if (lend)
			res.append(lstart, lend);
		else
			return res += lstart;
	}
}
