#define _WIN32_WINNT 0x0500

#include "plugin.h"

#include <windows.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/locking.h>
#include <stdio.h>
#include <share.h>
#include <fcntl.h>

#include <map>
#include <fstream>
#include <string>

#include "nodes.h"
#include "internal.h"

const int FW_FILE_ACTION_IDLE = 12345;

extern "C" {
__declspec(dllexport) void filewatch_ThreadFunc(const xml::welement &options);
}

std::size_t getsize(const std::wstring &name)
{
	struct _stat s;
	_wstat(name.c_str(), &s);
	return s.st_size;
}

struct file_info_t : action_data_t {
	std::wstring name;
	int last_size_;
	int next_line;
	__int64 last_modified;
};

void make_regex(boost::wregex &re, const std::wstring &str, bool match_case, anchor_t anchor)
{
	std::wstring t = str;

	if (anchor & anchor_left)
		t = L"\\A" + str;
	if (anchor & anchor_right)
		t += L"\\Z";

	typedef boost::regbase rb;
	rb::flag_type f = rb::extended | rb::use_except | (match_case ? 0 : rb::icase);
	const wchar_t *b = t.data(), *e = b + t.size();
	re.assign(b, e, f);
}

int findline(FILE *file, int cbytes, const std::wstring &filename)
{
	lw_log(L"scanning for last line of " + filename);
	fseek(file, 0, SEEK_END);
	int p = ftell(file);
	if (p == -1) lw_error(L"failed to find last line in file");
	int size = p;
	fseek(file, max(0, p-500*cbytes), SEEK_SET);
	p = ftell(file);
	if (p == -1) lw_error(L"failed to find last line in file");

	wint_t c;
	int prev = 0;
	while ((c = fgetwc(file)) != wint_t(EOF))
		if (c == '\n') {
			prev = p;
			p = ftell(file);
		}

	if (p == -1) lw_error(L"failed to find last line in file");

	clearerr(file);

	if (size - p < 2)
		return prev;
	return p;
}

; // workaround for parser bug

void handle_lines(wnode *root, file_info_t &fi, const std::wstring &dirname)
{
	int cbytes = 1;

	std::wstring filename = dirname + L'\\' + fi.name;

	int fileno = _wsopen(filename.c_str(), _O_RDONLY | _O_TEXT,
		_SH_DENYNO, 0);
	if (fileno == -1) {
		if (errno == ENOENT)
			fi.next_line = 0;
		return;
	}

	FILE *file = _wfdopen(fileno, L"r");
	if (!file) {
		_close(fileno);
		return;
	}

	init_file(file);

	if (fi.next_line < 0)
		fi.next_line = findline(file, cbytes, filename);

	fseek(file, fi.next_line, SEEK_SET);

	if (ferror(file)) {
		fi.next_line = -1; // old position was not valid, rescan
		fclose(file);
		return;
	}

	typedef std::vector<std::wstring> lines_t;
	lines_t lines;
	wchar_t buf[4096];
	while (fgetws(buf, sizeof buf/sizeof buf[0], file)) {

		wchar_t *p = wcschr(buf, L'\n');
		if (!p)
			break;

		*p = L'\0';
		if (p = wcschr(buf, L'\r'))
			*p = L'\0';

		lines.push_back(buf);
	}

	fi.next_line = ftell(file);
	fclose(file);

	for (lines_t::iterator i=lines.begin(), e=lines.end(); i!=e; ++i) {
		std::wstring line = *i;
		fi.vars[L"line"] = line;
		fi.vars[L"what"] = L"line";

		lw_log(L"event: line: " + fi.name + L": " + line);
		root->handle(fi);
	}

	fi.vars.erase(L"line");
}

bool handler(DWORD action, const std::wstring &name, file_info_t &filei, wnode *root,
	bool watch_lines, int idle_time, const std::wstring &dirname)
{
	switch (action) {
	case FILE_ACTION_MODIFIED:
		break;
	case FILE_ACTION_ADDED:
		// assume that an added file is initially empty, may not be true
		if (getsize(dirname + L'\\' + name) < 50)
			filei.next_line = 0;
		else
			filei.next_line = -1;
		lw_log(L"event: added: " + name);
		filei.vars[L"what"] = L"added"; break;
	case FILE_ACTION_REMOVED:
		filei.next_line = 0;
		lw_log(L"event: removed: " + name);
		filei.vars[L"what"] = L"removed"; break;
	case FILE_ACTION_RENAMED_NEW_NAME:
		filei.next_line = -1;
		lw_log(L"event: renamed_new: " + name);
		filei.vars[L"what"] = L"renamed_new"; break;
	case FILE_ACTION_RENAMED_OLD_NAME:
		filei.next_line = 0;
		lw_log(L"event: renamed_old: " + name);
		filei.vars[L"what"] = L"renamed_old"; break;
	case FW_FILE_ACTION_IDLE:
		lw_log(L"event: idle: " + name);
		filei.vars[L"what"] = L"idle"; break;
	default:
		return true;
	}

	__int64 now = timeGetTime();
	__int64 lasttime = filei.last_modified;
	if (idle_time > 0)
		filei.last_modified = now;

	if (action == FILE_ACTION_MODIFIED) {
		if (watch_lines)
			handle_lines(root, filei, dirname);

		if (idle_time <= 0)
			return true;

		if (lasttime < now - idle_time) {
			lw_log(L"event: resumed: " + name);
			filei.vars[L"what"] = L"resumed";
			root->handle(filei);
		}
	} else {
		root->handle(filei);

		if (action == FW_FILE_ACTION_IDLE)
			filei.last_modified = 0;
		else if (action == FILE_ACTION_REMOVED || action == FILE_ACTION_RENAMED_OLD_NAME)
			return false;
	}
	return true;
}

void filewatch_ThreadFunc(const xml::welement &opt)
try
{
	std::wstring dirname = opt.attr(L"directory").value();
	int idle_time = 0;
	bool watch_lines = false;

	getattr(opt, L"idle_time", idle_time);
	idle_time *= 1000;

	boost::wregex file_pattern;
	if (cattr_t a = opt.attr(L"files"))
		make_regex(file_pattern, a.value(), false, anchor_none);

	if (cattr_t a = opt.attr(L"watch_lines")) {
		std::wstring v = a.value();
		if (v == L"yes")
			watch_lines = true;
		else if (v == L"no")
			watch_lines = false;
		else if (!v.empty())
			lw_error(L"Invalid value for watch_lines attribute.");
	}

	if (watch_lines && file_pattern.empty())
		lw_error(L"The \"files\" attribute is required when tracking lines.");

	stringmap_t defaults;

	wnode *root = new block_node;
	root->init(defaults, opt);

	std::map<std::wstring, file_info_t> filedata;

	cattr_t subtree = opt.attr(L"subtree");
	bool tree = false;
	if (subtree) {
		std::wstring st = subtree.value();
		if (st == L"yes")
			tree = true;
		else if (st == L"no")
			tree = false;
		else if (!st.empty())
			lw_error(L"Invalid value in attribute \"subtree\".");
	}

	if (watch_lines) {
		// prescan

		WIN32_FIND_DATA finddata;
		HANDLE finder = FindFirstFile((dirname + L"/*").c_str(), &finddata);
		if (finder != INVALID_HANDLE_VALUE) {
			bool finished = false;
			while (!finished) {
				const std::wstring name = finddata.cFileName;

				if (file_pattern.empty() || boost::regex_match(name, file_pattern)) {
					file_info_t &filei = filedata[name];

					filei.name = name;
					filei.last_modified = 0;
					filei.next_line = getsize(dirname + L'/' + name);

					filei.vars[L"file"] = name;
					filei.vars[L"directory"] = dirname;
				}

				if (!FindNextFile(finder, &finddata))
					finished = true;
			}
		}
	}

	HANDLE dir = CreateFile(dirname.c_str(), FILE_LIST_DIRECTORY, 
		FILE_SHARE_READ|FILE_SHARE_DELETE|FILE_SHARE_WRITE,
		NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OVERLAPPED, NULL);
	if (dir == INVALID_HANDLE_VALUE)
		lw_winerror();

	HANDLE file_event = CreateEvent(NULL, TRUE, FALSE, L"file_event");

	OVERLAPPED file_overlapped;

	bool file_needs_init = true;


	char ibuf[4096];
	FILE_NOTIFY_INFORMATION * const info = (FILE_NOTIFY_INFORMATION *) ibuf;
	for (;;) {
		if (file_needs_init) {
			file_needs_init = false;
			DWORD nreturned;
			ZeroMemory(&file_overlapped, sizeof file_overlapped);
			file_overlapped.hEvent = file_event;
			if (!ReadDirectoryChangesW(dir, info, sizeof ibuf, tree,
				FILE_NOTIFY_CHANGE_SIZE|FILE_NOTIFY_CHANGE_FILE_NAME|FILE_NOTIFY_CHANGE_CREATION,
				&nreturned, &file_overlapped, NULL))
				lw_winerror();
		}

		__int64 wait_time = INFINITE;
		__int64 now = timeGetTime();
		if (idle_time)
			for (std::map<std::wstring, file_info_t>::iterator i=filedata.begin(), e=filedata.end(); 
				i!=e; ++i) {

				__int64 lm = i->second.last_modified;
				if (lm != 0) {
					__int64 t = lm + idle_time - now;
					if (wait_time == INFINITE || t < wait_time)
						wait_time = t;
				}
			}

		DWORD err;
		if (wait_time == INFINITE || wait_time >= 0) {
			err = WaitForSingleObject(file_event, wait_time);
			if (err == WAIT_FAILED)
				lw_winerror();
		} else
			err = WAIT_TIMEOUT;

		now = timeGetTime();
		__int64 limit = now - idle_time;

		for (std::map<std::wstring, file_info_t>::iterator i=filedata.begin(), e=filedata.end();
			i!=e; ++i) {

			file_info_t &filei = i->second;
			__int64 lm = filei.last_modified;

			if (lm != 0 && lm <= limit+50) {
				std::wstring name = filei.name;

				filei.vars[L"what"] = L"idle";
				filei.vars[L"file"] = name;
				filei.vars[L"directory"] = dirname;

				handler(FW_FILE_ACTION_IDLE, name, filei, root, watch_lines, 
					idle_time, dirname);
			}
		}

		if (err == WAIT_OBJECT_0) {
			file_needs_init = true;

			DWORD nreturned;
			if (!GetOverlappedResult(dir, &file_overlapped, &nreturned, TRUE))
				lw_winerror();

			if (nreturned == 0)
				// don't know why this can happen, but it can, so work around it
				continue;

			info[0].FileName[info[0].FileNameLength/2] = 0;

			std::wstring name = info[0].FileName;

			boost::wsmatch match;
			if (!file_pattern.empty())
				if (!boost::regex_match(name, match, file_pattern))
					continue;

			file_info_t &filei = filedata[name];
			if (filei.vars.empty()) { // first time
				filei.name = name;
				filei.last_modified = 0;
				filei.next_line = -1;
			}
			filei.vars[L"file"] = name;
			filei.vars[L"directory"] = dirname;

			if (!file_pattern.empty())
				for (int i=0; i!=match.size(); ++i) {
					char buf[10];
					itoa(i, buf, 10);
					filei.vars[mbtow(buf)] = match[i];
				}

			if (!handler(info[0].Action, name, filei, root, watch_lines, idle_time, dirname))
				filedata.erase(name);

		} else if (err != WAIT_TIMEOUT)
			lw_error(L"Unexpected return value.");
	}
}
catch (std::exception &e) {
	lw_error(mbtow(e.what()));
}
