#include "plugin.h"
#include "nodes.h"

void block_node::init(stringmap_t &defaults, const xml::welement &opt)
{
	for (xml::welement::const_iterator i = opt.begin(); i; ++i) {

		if (i->tag().empty() && !i->is_space())
			lw_error(L"Character data is not allowed.");
		else if (i->is_space())
			continue;

		if (i->tag() == L"property") {
			std::wstring id = i->attr(L"id").value();
			std::wstring value = i->attr(L"value").value();
			defaults[id] = value;
		} else
			children.push_back(make_node(defaults, *i));
	}
}

int block_node::handle(action_data_t &fi)
{
	for (std::vector<wnode *>::iterator i=children.begin(), e=children.end(); i!=e; ++i) {

		int ret = (*i)->handle(fi);
		if (ret == 0)
			continue;
		else
			return ret-1;
	}
	return 0;
}

