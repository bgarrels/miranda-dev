#include "plugin.h"
#include "nodes.h"

switch_node::switch_node()
	: defnode(0), match_case(false)
{
}

namespace {
	void tolower(std::wstring &str)
	{
		for (int i=0, e=str.size(); i!=e; ++i)
			str[i] = ::towlower(str[i]);
	}
}

void switch_node::init(stringmap_t &defaults, const xml::welement &opt)
{
	getattr(opt, L"input", input, L"send", defaults);

	cattr_t a = opt.attr(L"");
	std::wstring str;
	if ((a = opt.attr(L"match_case")) || getdef(defaults, L"switch:match_case", str)) {
		if (a)
			str = a.value();
		if (str == L"yes")
			match_case = true;
		else if (str == L"no")
			match_case = false;
		else if (!str.empty())
			lw_error(L"Invalid value for match_case attribute.");
	}

	if (input.empty())
		lw_error(L"<switch> attribute \"input\" is required");

	for (celit_t i=opt.begin(); i; ++i) {
		if (i->tag().empty() && !i->is_space())
			lw_error(L"Character data is not allowed.");
		else if (i->is_space())
			continue;

		if (i->tag() == L"case") {
			std::wstring val = i->attr(L"value").value();
			if (match_case)
				tolower(val);
			wnode *&n = nodemap[val];
			if (n)
				lw_error(L"Duplicate case value.");

			n = new block_node;
			n->init(defaults, *i);
		} else if (i->tag() == L"default") {
			if (defnode)
				lw_error(L"Multiple defaults");

			defnode = new block_node;
			defnode->init(defaults, *i);
		} else
			lw_error(L"Only <case> and <default> are allowed within <switch>");
	}
}

int switch_node::handle(action_data_t &fi)
{
	std::wstring v = replace_vars(input, fi);
	if (match_case)
		tolower(v);

	std::map<std::wstring, wnode *>::iterator i = nodemap.find(v);
	int ret;
	if (i != nodemap.end()) {
		lw_log(L"   switch: \"" + v + L"\" -> case \"" + i->first + L'\"', true);
		ret = i->second->handle(fi);
	} else if (defnode) {
		lw_log(L"   switch: \"" + v + L"\" -> default", true);
		ret = defnode->handle(fi);
	} else {
		lw_log(L"   switch: \"" + v + L"\" -> no match", true);
		return 0;
	}

	if (ret == 0)
		return 0;
	else
		return ret-1;
}
