#ifndef LW_WNODE_H
#define LW_WNODE_H

#include <vector>
#include <string>

#include <xml/element.h>

typedef xml::welement::const_attribute cattr_t;
typedef xml::welement::const_iterator celit_t;

typedef std::map<std::wstring, std::wstring> stringmap_t;

struct action_data_t {
	stringmap_t vars;
};

bool getdef(const stringmap_t &defaults, const std::wstring &id, std::wstring &);

template<class T> void getattr(const xml::welement &e, const std::wstring &a, T &v)
{
	cattr_t ca = e.attr(a);
	if (!ca) return;
	if (ca.value().empty()) return;
	xml::get0(ca, v);
}

inline void getattr(const xml::welement &e, const std::wstring &a, std::wstring &v,
	const wchar_t *node, const stringmap_t &defaults)
{
	if (cattr_t ca = e.attr(a))
		v = ca.value();
	else
		getdef(defaults, node + (L':' + a), v);
}

std::wstring replace_vars(const std::wstring &str, const action_data_t &, bool regexp = false);

class wnode {
public:
	virtual ~wnode();

	virtual void init(stringmap_t &defaults, const xml::welement &) = 0;

	// return break level
	virtual int handle(action_data_t &) = 0;

	static wnode *make_node(stringmap_t &defaults, const xml::welement &);
};

#endif
