#ifndef FormatEventLogRecord_h
#define FormatEventLogRecord_h

#include "EventLogRecord.h"

class FormatEventLogRecord {
	std::wstring m_eventlog;
public:
	struct TArray {
		wchar_t *m_ptr;
		explicit TArray(wchar_t *p) : m_ptr(p) {}
		~TArray() { delete [] m_ptr; }

		wchar_t *get() { return m_ptr; }
	};

	FormatEventLogRecord(const std::wstring &eventlog)
		{ m_eventlog = L"SYSTEM\\CurrentControlSet\\Services\\Eventlog\\" + eventlog; }

	std::wstring FormatRecord(const EVENTLOGRECORD *record)
	{
		std::wstringstream ss;
		EventLogRecord rec(record);
		ss << m_eventlog << L"\\" << rec.SourceName();
		HKEY hkey;
		LONG lerr;
		if ((lerr = ::RegOpenKey(HKEY_LOCAL_MACHINE, ss.str().c_str(), &hkey)) != ERROR_SUCCESS)
			return L"";
		TArray ta(new wchar_t[1024*1024]);
		unsigned tas = 1024*1024;
		DWORD dw = tas;
		if (::RegQueryValueEx(hkey, L"EventMessageFile", NULL, NULL, (BYTE*)ta.get(), &dw) != ERROR_SUCCESS) {
			::RegCloseKey(hkey);
			return L"";
		}
		::RegCloseKey(hkey);
		::ExpandEnvironmentStrings(std::wstring(ta.get()).c_str(), ta.get(), tas);

		HINSTANCE handle = ::LoadLibraryEx(ta.get(), NULL, LOAD_LIBRARY_AS_DATAFILE);
		if (handle == NULL)
			return L"";

		DWORD dwArgs[1024] = {0};
		DWORD offset = record->StringOffset;
		for (int i=0; i<record->NumStrings && i<1024; i++) {
			dwArgs[i] = ((DWORD)record)+offset;
			std::wstring str = (TCHAR *)dwArgs[i];
			offset += (str.length()+1)*2;
		}
		dw = ::FormatMessage(FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_ARGUMENT_ARRAY, 
			handle, rec.EventID(), 0, ta.get(), tas, (va_list*)dwArgs);
		if (dw == 0) {
			dw = ::GetLastError();
			ta.m_ptr[0] = L'\0';
		}
		::FreeLibrary(handle);
		return ta.get();
	}
};
 
#endif
