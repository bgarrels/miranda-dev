#define _WIN32_WINNT 0x0500

#include <sys/types.h>
#include <sys/timeb.h>
#include <time.h>
#include <io.h>
#include <sys/stat.h>
#include <sys/locking.h>
#include <stdio.h>
#include <share.h>
#include <fcntl.h>

#include <string>

#include <winsock2.h>

#include "plugin.h"
#include "internal.h"

__declspec(thread) const wchar_t *t_thread_name;
__declspec(thread) bool t_ignore_errors;

CRITICAL_SECTION g_support_cs;
int g_send_port = 12001;
int g_log_level = 1;
const wchar_t *g_current_error;

const wchar_t *lw_geterror()
{
	return g_current_error;
}

void lw_ignore_errors(bool a)
{
	t_ignore_errors = a;
}

void init_file(FILE *f)
{
	wint_t uchars[3];
	uchars[0] = fgetwc(f);
	uchars[1] = fgetwc(f);
	uchars[2] = fgetwc(f);

	if (uchars[0] == wint_t(0xffU) && uchars[1] == wint_t(0xfeU)) {
		_setmode(_fileno(f), _O_BINARY); // two-byte unicode
		fseek(f, 2, SEEK_SET);
	} else if (uchars[0] == wint_t(0xefU) && uchars[1] == wint_t(0xbbU) && uchars[2] == wint_t(0xbfU))
		; // utf-8 with signature
	else
		fseek(f, 0, SEEK_SET); // utf-8 or native
}

std::string wtomb(const std::wstring &wstr)
{
	char buf[500];
	wcstombs(buf, wstr.c_str(), sizeof buf);
	return buf;
}

std::wstring mbtow(const std::string &str)
{
	std::wstring wstr;
	const char *s = str.c_str();
	int nleft = str.size();
	while (nleft) {
		wchar_t wc;
		int n = mbtowc(&wc, s, nleft);
		wstr += wc;
		nleft -= n;
		s += n;
	}
	return wstr;
}

std::wstring errtos(int err)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM
		|FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL, err, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMsgBuf, 0, NULL);

	std::wstring s = (const wchar_t *) lpMsgBuf;

	LocalFree(lpMsgBuf);

	char buf[10];
	s += L" (";
	s += mbtow(itoa(err, buf, 10));
	s += L')';

	return s;
}

void lw_errsync()
{
	EnterCriticalSection(&g_support_cs);
	LeaveCriticalSection(&g_support_cs);
}

void restart_program()
{
	EnterCriticalSection(&g_support_cs);

	HMODULE m = GetModuleHandle(NULL);
	wchar_t buf[1024];
	int err = GetModuleFileName(m, buf, 1023);
	if (!err)
		lw_winerror();
	buf[err] = '\0';

	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	ZeroMemory(&si, sizeof si);
	ZeroMemory(&pi, sizeof pi);

	WSACleanup();

	if (!CreateProcess(buf, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
		lw_winerror();

	exit(0);

	LeaveCriticalSection(&g_support_cs);
}

void lw_log(const std::wstring &str, bool debug_log)
{
	if (debug_log && g_log_level < 2 || !g_log_level)
		return;

	if (!TryEnterCriticalSection(&g_support_cs))
		return;

	time_t t_;
	time(&t_);
	tm *t = localtime(&t_);
	FILE *f = _wfopen(L"LogWatcher.log", L"ab");
	if (f) {
		fseek(f, 0, SEEK_END);
		if (ftell(f) == 0) {
			fputc(0xffU, f);
			fputc(0xfeU, f);
		}
		if (fwprintf(f, L"[%04i-%02i-%02i %02i:%02i:%02i] %s\r\n",
			int(t->tm_year+1900), int(t->tm_mon)+1, int(t->tm_mday),
			int(t->tm_hour), int(t->tm_min), int(t->tm_sec), str.c_str())
				< 0 || fclose(f) == EOF)
			lw_sendlog(L"!LogWatcher#Failed to write to log file.", L"default");
	} else
		lw_sendlog(L"!LogWatcher#Failed to open log file.", L"default");

	LeaveCriticalSection(&g_support_cs);
}

void lw_error(const std::wstring &err)
{
	if (t_ignore_errors)
		return;

	struct multi_error_type {};

	static __declspec(thread) bool inerror = false;
	if (inerror)
		throw multi_error_type();
	inerror = true;

	EnterCriticalSection(&g_support_cs);

	g_current_error = wcsdup(err.c_str());

	try {
		lw_log(L"error: " + err);
		lw_sendlog(L"!LogWatcher#" + err, L"default");
	} catch (multi_error_type) {
	}

	std::wstring msg;
	if (t_thread_name) {
		msg += t_thread_name;
		msg += L": ";
	}
	msg += err;
	msg += L"\n\nSelect retry to restart, or cancel to end the program.";

	int ret = MessageBox(NULL, msg.c_str(), L"LogWatcher Error", MB_RETRYCANCEL|MB_ICONERROR|MB_DEFBUTTON2);
	if (ret == IDRETRY)
		restart_program();
	else
		exit(1);

	LeaveCriticalSection(&g_support_cs);
}

void lw_winerror()
{
	lw_numerror(GetLastError());
}

void lw_numerror(int errn)
{
	lw_error(errtos(errn));
}

typedef struct tagTHREADNAME_INFO
{
	DWORD dwType; // must be 0x1000
	LPCSTR szName; // pointer to name (in user addr space)
	DWORD dwThreadID; // thread ID (-1=caller thread)
	DWORD dwFlags; // reserved for future use, must be zero
} THREADNAME_INFO;

void SetThreadName(LPCTSTR szThreadName)
{
	t_thread_name = szThreadName;
}

void SetThreadName(DWORD dwThreadID, LPCSTR szThreadName)
{
	const char *name = strdup(szThreadName);

	THREADNAME_INFO info;
	info.dwType = 0x1000;
	info.szName = name;
	info.dwThreadID = dwThreadID;
	info.dwFlags = 0;

	__try {
		RaiseException(0x406D1388, 0, sizeof(info)/sizeof(DWORD), (DWORD*)&info);
	} __except(EXCEPTION_CONTINUE_EXECUTION) {
	}
}
