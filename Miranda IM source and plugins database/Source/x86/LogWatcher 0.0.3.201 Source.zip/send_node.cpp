#include "plugin.h"
#include "nodes.h"

send_node::send_node()
{
}

void send_node::init(stringmap_t &defaults, const xml::welement &opt)
{
	getattr(opt, L"raw", raw, L"send", defaults);
	getattr(opt, L"type", type, L"send", defaults);
	getattr(opt, L"from", from, L"send", defaults);
	getattr(opt, L"text", text, L"send", defaults);
	getattr(opt, L"fg", fg, L"send", defaults);
	getattr(opt, L"bg", bg, L"send", defaults);
	getattr(opt, L"icon", icon, L"send", defaults);
	getattr(opt, L"beep", beep, L"send", defaults);
	getattr(opt, L"id", id, L"send", defaults);
	getattr(opt, L"replace", replace, L"send", defaults);
	getattr(opt, L"target", target, L"send", defaults);

	if (target.empty())
		target = L"default";

	for (stringmap_t::iterator i=defaults.begin(), e=defaults.end(); i!=e; ++i) {
		if (!i->first.compare(0, 9, L"send:opt:")) {
			std::wstring name(i->first, 9);
			opts[name] = i->second;
		}
	}

	typedef std::map<std::wstring, std::wstring> attribute_map_t;
	const attribute_map_t &attr = opt.attributes();
	for (attribute_map_t::const_iterator i=attr.begin(), e=attr.end(); i!=e; ++i) {
		if (!i->first.compare(0, 4, L"opt:")) {
			std::wstring name(i->first, 4);
			opts[name] = i->second;
		}
	}

	if (opt.begin())
		lw_error(L"<send> must be empty");
	if (raw.empty() && text.empty())
		lw_error(L"Either of the attributes raw and text is required for <send>.");
	if (!raw.empty() && !text.empty())
		lw_error(L"Attributes raw and text cannot be used togehter in <send>.");
}

void addopt(std::wstring &msg, wchar_t &sep, const std::wstring &opt, const std::wstring &astr,
	const action_data_t &fi, bool lastsep = true)
{
	const wchar_t *sepchars = L"#;*+%&?=!@$/\\_\'\"-\01\02\03\04";
	std::wstring str = replace_vars(astr, fi);
	if (str.empty())
		return;

	if (str.find(sep) != str.npos) {
		const wchar_t *p = sepchars;
		while (*p && str.find(*p) != str.npos)
			++p;
		if (!*p)
			lw_error(L"Could not find a character to use as separator.");
		msg += L"sep:";
		msg += *p;
		msg += sep;
		sep = *p;
	}

	msg += opt;
	msg += L':';
	msg += str;
	if (lastsep)
		msg += sep;
}

int send_node::handle(action_data_t &fi)
{
	if (!raw.empty()) {
		std::wstring msg = replace_vars(raw, fi);
		lw_log(L"   send: raw: " + msg);
		lw_sendlog(msg, target);
	} else {
		std::wstring msg;
		std::wstring type_ = replace_vars(type, fi);
		if (type_ == L"error")
			msg += L'!';
		else if (type_ == L"message")
			msg += L'%';
		else if (!type.empty() && type_ != L"notification")
			lw_error(L"Invalid value for attribute \"type\".");

		wchar_t sep = L'#';
		msg += sep;
		addopt(msg, sep, L"from", from, fi);
		addopt(msg, sep, L"fg", fg, fi);
		addopt(msg, sep, L"bg", bg, fi);
		addopt(msg, sep, L"icon", icon, fi);
		addopt(msg, sep, L"id", id, fi);
		addopt(msg, sep, L"replace", replace, fi);

		for (opts_t::iterator i=opts.begin(), e=opts.end(); i!=e; ++i)
			addopt(msg, sep, i->first, i->second, fi);

		std::wstring beep_ = replace_vars(beep, fi);
		if (beep_ == L"yes") {
			msg += L"beep:1";
			msg += sep;
		} else if (beep_ == L"no") {
			msg += L"beep:0";
			msg += sep;
		} else if (!beep_.empty())
			lw_error(L"Invalid value for attribute \"beep\".");

		addopt(msg, sep, L"msg", text, fi, false);

		lw_log(L"   send: composed: " + msg);
		lw_sendlog(msg, target);
	}
	return 0;
}
