#include "plugin.h"
#include "nodes.h"

match_node::match_node()
{
	match_case = false;
	anchor = anchor_none;
}

void match_node::init(stringmap_t &defaults, const xml::welement &opt)
{
	block_node::init(defaults, opt);

	getattr(opt, L"input", input, L"match", defaults);
	getattr(opt, L"pattern", pattern, L"match", defaults);

	cattr_t a = opt.attr(L"");
	std::wstring str;

	if ((a = opt.attr(L"exact")) || getdef(defaults, L"match:exact", str)) {
		if (a)
			str = a.value();
		if (str == L"yes") {
			match_case = true;
			anchor = anchor_both;
		} else if (!str.empty())
			lw_error(L"Invalid value for <match> attribute \"exact\".");
	}

	if ((a = opt.attr(L"match_case")) || getdef(defaults, L"match:match_case", str)) {
		if (a)
			str = a.value();
		if (str == L"yes")
			match_case = true;
		else if (str == L"no")
			match_case = false;
		else if (!str.empty())
			lw_error(L"Invalid value for match_case attribute.");
	}

	if ((a = opt.attr(L"anchor")) || getdef(defaults, L"match:anchor", str)) {
		if (a)
			str = a.value();
		if (str == L"both")
			anchor = anchor_both;
		else if (str == L"left")
			anchor = anchor_left;
		else if (str == L"right")
			anchor = anchor_right;
		else if (str == L"no")
			anchor = anchor_none;
		else if (!str.empty())
			lw_error(L"Invalid value for anchor attribute.");
	}

	if (pattern.empty() || input.empty())
		lw_error(L"Attributes pattern and input are required for <match>.");
}

int match_node::handle(action_data_t &fi)
{
	lw_log(L"replace (input): " + input, true);
	std::wstring in = replace_vars(input, fi);
	lw_log(L"got (in): " + in, true);
	lw_log(L"replace (pattern): " + pattern, true);
	std::wstring regex_str = replace_vars(pattern, fi, true);
	lw_log(L"got (regex_str): " + regex_str, true);
	std::wstring logstr = L"   match: \"" + in + L"\" ~ \"" + regex_str + L"\": ";

	if (regex_str != last_regex_str) {
		lw_log(L"make_regex (regex_str): " + regex_str, true);
		make_regex(last_regex, regex_str, match_case, anchor == anchor_both ? anchor_none : anchor);
		lw_log(L"make_regex ok", true);
		last_regex_str = regex_str;
	}

	boost::wsmatch match;
	bool m;
	if (anchor == anchor_both) {
		lw_log(L"regex_match (in): " + in, true);
		m = boost::regex_match(in, match, last_regex);
		lw_log(L"regex_match ok", true);
	} else {
		lw_log(L"regex_search (in): " + in, true);
		m = boost::regex_search(in, match, last_regex);
		lw_log(L"regex_search ok", true);
	}

	if (m) {
		logstr += L"yes";
		for (int i=0; i!=match.size(); ++i) {
			char buf[10];
			itoa(i, buf, 10);
			std::wstring wbuf = mbtow(buf);
			fi.vars[wbuf] = match[i];
			logstr += L", ";
			logstr += wbuf;
			logstr += L"=\"";
			logstr += match[i];
			logstr += L'\"';
		}
		lw_log(logstr, true);
		return block_node::handle(fi);
	} else {
		lw_log(logstr + L"no", true);
		return 0;
	}
}
