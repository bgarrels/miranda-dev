
#include <windows.h>
#include <vector>
#include <string>
#include <map>

struct target_t {
	std::wstring host;
	int port;
	bool tcp;
	std::wstring aliased;
	std::string passwd;

	target_t() : port(0), tcp(false) {}
	void expand(std::vector<targetinfo> &, int depth) const;
};

void SetThreadName(DWORD dwThreadID, LPCSTR szThreadName);
void SetThreadName(LPCTSTR szThreadName);

extern CRITICAL_SECTION g_support_cs;
extern std::map<std::wstring, target_t> g_targets;
extern int g_log_level; // 0 = no, 1 = yes, 2 = debug

void restart_program();

void init_file(FILE *);
