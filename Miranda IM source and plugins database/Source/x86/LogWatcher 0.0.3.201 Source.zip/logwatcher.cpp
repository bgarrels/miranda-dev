#include "plugin.h"
#include "internal.h"

#include <tchar.h>
#include <stdio.h>
#include <conio.h>
#include <fcntl.h>
#include <io.h>

#include <fstream>
#include <exception>
#include <vector>
#include <iostream>
#include <string>
#include <set>

#include <xml/document.h>

std::map<std::wstring, target_t> g_targets;
int g_control_port;

typedef void (*thread_handler)(const xml::welement &options);

struct independent_thread_data {
	std::wstring name;
	xml::welement options;
	thread_handler func;
};

void start_control_thread();

void target_t::expand(std::vector<targetinfo> &targets, int depth) const
{
	if (depth > 10)
		return;

	if (port) {
		ADDRINFO hints;
		memset(&hints, 0, sizeof hints);
		hints.ai_socktype = SOCK_DGRAM;
		hints.ai_family = PF_INET;
		ADDRINFO *res;
		int err = getaddrinfo(wtomb(host).c_str(), wtomb(to_str(port)).c_str(), &hints, &res);

		if (!err && res) {
			targetinfo ti = { *(SOCKADDR_IN*)res->ai_addr, tcp, passwd };
			targets.push_back(ti);
		} else
			lw_log(L"Error resolving host '" + host + L"'", true);

		freeaddrinfo(res);		
	}

	lw_expand(aliased, targets, depth+1);
}

std::wstring readfile(const std::wstring filename)
{
	FILE *f = _wfopen(filename.c_str(), L"r");
	if (!f) {
		lw_error(L"Failed to open file: " + filename + L": " + _wcserror(errno));
	}

	init_file(f);

	wchar_t buf[4096];
	std::wstring ret;
	while (fgetws(buf, 4096, f))
		ret += buf;

	fclose(f);
	return ret;
}

void lw_expand_single(const std::wstring &target, std::vector<targetinfo> &targets, int depth)
{
	std::map<std::wstring, target_t>::iterator it = g_targets.find(target);
	if (it == g_targets.end())
		lw_log(L"Unknown target: " + target, true);
	else
		it->second.expand(targets, depth);
}

void lw_expand(const std::wstring &targetstr, std::vector<targetinfo> &targets, int depth)
{
	if (targetstr.empty())
		return;
	const wchar_t *p = targetstr.c_str();
	while (p) {
		const wchar_t *e = wcschr(p, ',');
		std::wstring current;
		if (e) {
			current.assign(p, e);
			p = e+1;
		} else {
			current = p;
			p = e;
		}
		lw_expand_single(current, targets, depth);
	}
}

void lw_sendlog(const std::wstring &text, const std::wstring &target)
{
	lw_log(L"sending(" + target + L"): " + text, true);

	std::vector<targetinfo> targets;
	lw_expand(target, targets);
	lw_sendlog(text, targets);
}

void lw_sendlog(const std::wstring &text, const std::vector<targetinfo> &targets)
{
	for (std::vector<targetinfo>::const_iterator i=targets.begin(), e=targets.end(); i!=e; ++i)
		lw_sendlog(text, *i);
}

void lw_sendlog(const std::wstring &text, const targetinfo &ti)
{
	SOCKET sock;

	sock = socket(AF_INET, ti.tcp ? SOCK_STREAM : SOCK_DGRAM, 0);
	if (sock == INVALID_SOCKET)
		lw_numerror(WSAGetLastError());

	SOCKADDR_IN self;
	ZeroMemory(&self, sizeof self);
	self.sin_family = AF_INET;

	if (bind(sock, (const SOCKADDR *) &self, sizeof self))
		lw_numerror(WSAGetLastError());

	if (connect(sock, (const SOCKADDR *) &ti.addr, sizeof ti.addr)) {
		std::wstring errs = errtos(WSAGetLastError());
		lw_log(L"connect: error: " + errs);
		closesocket(sock);
		return;
	}

	std::string mbtext = wtomb(text);

	if (!mbtext.empty() && !ti.passwd.empty()) {
		int pos = -1;
		if (mbtext[0] == '#')
			pos = 0;
		else if (mbtext.size() >= 2 && mbtext[1] == '#')
			pos = 1;
		mbtext.insert(0, "#passwd:" + ti.passwd);
	}

	if (send(sock, mbtext.data(), mbtext.size(), 0) == SOCKET_ERROR) {
		int err = WSAGetLastError();
		switch (err) {
		case WSAEINTR:
		case WSAENETRESET:
		case WSAESHUTDOWN:
		case WSAEMSGSIZE:
		case WSAECONNABORTED:
		case WSAECONNRESET:
		case WSAENETUNREACH:
		case WSAETIMEDOUT:
			{
				std::wstring errs = errtos(err);
				lw_log(L"sendto: error: " + errs);

				closesocket(sock);
				return;
			}
		default:
			lw_numerror(err);
		}
	}
	lw_log(L"message sent " + std::wstring(ti.tcp ? L"(tcp)" : L"(udp)"));
	shutdown(sock, 2);
	closesocket(sock);
}

DWORD independent_thread_func(LPVOID data)
{
	independent_thread_data *td = (independent_thread_data *) data;
	SetThreadName(td->name.c_str());
	xml::welement opt = td->options;

	td->func(opt);

	lw_error(L"Independent thread returend control to main program.");

	return 0;
}

void start_independent(const std::wstring &name, const xml::welement &opt, thread_handler func)
{
	independent_thread_data *td = new independent_thread_data;
	td->name = name;
	td->options = opt;
	td->func = func;
	DWORD id;
	HANDLE thread = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE) independent_thread_func, 
		td, CREATE_SUSPENDED, &id);
	if (!thread)
		lw_winerror();

	SetThreadName(id, wtomb(name).c_str());

	if (ResumeThread(thread) == -1)
		lw_winerror();
}

void load_settings(const xml::wdocument &doc)
{
	if (doc.root.tag() != L"settings")
		lw_error(L"expected <settings>");

	target_t &deftarget = g_targets[L"default"];
	deftarget.host = L"localhost";
	deftarget.port = 12001;

	g_control_port = 12002;
	g_log_level = 0;

	xml::get0(doc.root.attr(L"control_port"), g_control_port);

	if (doc.root.attr(L"log")) {
		std::wstring log = doc.root.attr(L"log").value();
		if (log == L"no")
			g_log_level = 0;
		else if (log == L"yes")
			g_log_level = 1;
		else if (log == L"debug")
			g_log_level = 2;
		else
			lw_error(L"invalid value for attribute `log', expected no|yes|debug");
	}

	start_control_thread();

	HMODULE this_module = GetModuleHandle(NULL);

	typedef std::set<xml::wdocument *> docset_t;
	docset_t imports;

	int nplugs = 0;
	typedef xml::welement::const_iterator cit;
	for (cit i = doc.root.begin(); i; ++i) {

		xml::welement watcher = *i;

		HMODULE module = this_module;

		std::wstring name = watcher.tag();
		if (name.empty()) {
			if (watcher.is_space())
				continue;
			else
				lw_error(L"Character data is not allowed.");
		}

		if (name == L"import") {

			std::wstring fname = watcher.attr(L"file").value();

			std::wstring wfbuf = readfile(fname);
			std::wistringstream f(wfbuf);
//			std::wifstream f(wtomb(name).c_str());
//			if (!f.is_open())
//				lw_error(L"Failed to open file: " + fname);

			xml::wdocument *idoc = new xml::wdocument(f);
			imports.insert(idoc);

			typedef std::map<std::wstring, std::wstring> attribute_map_t;
			attribute_map_t &attr = idoc->root.attributes();
			for (attribute_map_t::const_iterator i=watcher.attributes().begin(),
				e=watcher.attributes().end(); i!=e; ++i)
				if (i->first != L"file")
					idoc->root.attr(i->first) = i->second;

			watcher = idoc->root;
			name = watcher.tag();
		} else if (name == L"target") {
			std::wstring tname = watcher.attr(L"name").value();
			int port = 0;

			target_t &t = g_targets[tname];
			t = target_t();
			xml::get0(watcher.attr(L"alias"), t.aliased);
			xml::get0(watcher.attr(L"port"), t.port);
			xml::get0(watcher.attr(L"host"), t.host);
			std::wstring wpw, protocol;
			xml::get0(watcher.attr(L"password"), wpw);
			t.passwd = wtomb(wpw);
			xml::get0(watcher.attr(L"protocol"), protocol);
			if (protocol == L"udp")
				t.tcp = false;
			else if (protocol == L"tcp")
				t.tcp = true;
			else if (!protocol.empty())
				lw_error(L"Invalid value for attribute \"protocol\".");

			continue;
		}

		xml::welement::attribute dlla = watcher.attr(L"dll");
		if (dlla) {
			module = LoadLibrary(dlla.value().c_str());
			if (!module)
				lw_winerror();
		}

		FARPROC func = GetProcAddress(module, (wtomb(name) + "_ThreadFunc").c_str());
		if (func) {
			start_independent(name, watcher, (thread_handler) func);
			++nplugs;
		} else {
			std::wstring err = L'\"' + name + L"\" is not a valid plugin";
			lw_error(err);
		}
	}
	if (!nplugs)
		lw_error(L"No plugins loaded\n"
			L"Edit the file LogWatcher.xml to enable some watchers.");

	while (!imports.empty()) {
		delete *imports.begin();
		imports.erase(imports.begin());
	}
}

DWORD process_control_messages(LPVOID)
{
	SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0/*IPPROTO_UDP*/);
	if (sock == INVALID_SOCKET)
		lw_numerror(WSAGetLastError());

	SOCKADDR_IN addr;
	ZeroMemory(&addr, sizeof addr);
	addr.sin_family = AF_INET;
	addr.sin_port = htons(g_control_port);
	addr.sin_addr.S_un.S_un_b.s_b1 = 127;
	addr.sin_addr.S_un.S_un_b.s_b2 = 0;
	addr.sin_addr.S_un.S_un_b.s_b3 = 0;
	addr.sin_addr.S_un.S_un_b.s_b4 = 1;

	if (bind(sock, reinterpret_cast<sockaddr *>(&addr), sizeof addr))
		lw_numerror(WSAGetLastError());

	lw_ignore_errors(true);

	SOCKADDR_IN from;
	char buf[4096];

	while (true) {
		int fromSize = sizeof from;
		int err = recvfrom(sock, buf, sizeof buf - 1, 0, reinterpret_cast<sockaddr *>(&from), &fromSize);

		if (err == SOCKET_ERROR)
			lw_numerror(WSAGetLastError());

		buf[err] = '\0';

		if (char *p = strchr(buf, '\n')) {
			lw_log(L"stripped newline from control message");
			*p = '\0';
		}

		std::string sbuf = buf;

		lw_log(mbtow("control message: " + sbuf));

		if (sbuf == "restart") {
			lw_log(L"restarting");
			lw_sendlog(L"LogWatcher#Restarting", L"default");
			restart_program();
		} else if (sbuf == "stop") {
			lw_log(L"stopping");
			lw_sendlog(L"LogWatcher#Stopping", L"default");
			std::exit(0);
		} else if (sbuf == "ping") {
			lw_log(L"pong");
			if (const wchar_t *err = lw_geterror())
				lw_sendlog(L"LogWatcher#Pong. Current error: " + std::wstring(err), L"default");
			else
				lw_sendlog(L"LogWatcher#Pong", L"default");
		} else {
			lw_log(L"unknown commad: " + mbtow(sbuf));
			lw_sendlog(L"!LogWatcher#Unknown command: " + mbtow(sbuf), L"default");
		}
	}
}

void start_control_thread()
{
	lw_log(L"starting control thread", true);

	DWORD id;
	HANDLE thread = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE) process_control_messages, 
		0, CREATE_SUSPENDED, &id);
	if (!thread)
		lw_winerror();

	SetThreadName(id, "control thread");

	if (ResumeThread(thread) == -1)
		lw_winerror();
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
try
{
	InitializeCriticalSection(&g_support_cs);

	lw_log(L"starting");

	WSADATA wsaData;
	int err = WSAStartup(MAKEWORD(2, 0), &wsaData);
	if (err)
		lw_numerror(err);

	lw_log(L"reading configuration", true);

	std::wstring lwfc = readfile(L"LogWatcher.xml");
	std::wistringstream sfile(lwfc);

	xml::wdocument doc(sfile);
	load_settings(doc);

	lw_log(L"started");

	Sleep(INFINITE);

	return 0;
}
catch (std::exception &e) {
	lw_error(mbtow(e.what()));
	return 1;
}
