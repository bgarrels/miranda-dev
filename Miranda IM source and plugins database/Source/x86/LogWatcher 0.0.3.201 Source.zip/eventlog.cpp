#include "plugin.h"
#include "nodes.h"
#include "FormatEventLogRecord.h"

#include <xml/element.h>

extern "C" {
__declspec(dllexport) void eventlog_ThreadFunc(const xml::welement &options);
}

struct loginfo_t : action_data_t {
	std::wstring name;
	HANDLE log, event;
	DWORD position;
	FormatEventLogRecord format;
	wnode *root;

	loginfo_t(const std::wstring &n)
		: name(n), format(n), root(0) {}
};

void eventlog_ThreadFunc(const xml::welement &opt)
try
{
	int delay = 0, discard_time = 0;
	getattr(opt, L"delay_start", delay);
	delay *= 1000;
	if (delay < 0)
		lw_error(L"Invalid value for \"delay_start\" attribute.");
	getattr(opt, L"discard_time", discard_time);
	if (discard_time < 0)
		lw_error(L"Invalid value for \"discard_time\" attribute.");
	Sleep(delay);

	stringmap_t outer_defaults;

	std::vector<loginfo_t *> logs;
	std::vector<HANDLE> handles;
	for (xml::welement::const_iterator i=opt.begin(); i; ++i) {

		if (i->tag().empty()) continue;

		if (i->tag() == L"log")
			;
		else if (i->tag() == L"property") {
			std::wstring id = i->attr(L"id").value();
			std::wstring value = i->attr(L"value").value();
			outer_defaults[id] = value;
			continue;
		} else
			lw_error(L"Unknown option: " + i->tag());

		stringmap_t defaults = outer_defaults;

		loginfo_t *li = new loginfo_t(i->attr(L"name").value());
		li->root = new block_node;
		li->root->init(defaults, *i);

		li->log = OpenEventLog(NULL, li->name.c_str());
		if (!li->log)
			lw_winerror();

		// Get the record number of the oldest event log record.
		DWORD nrecords, firstrecord;
		GetOldestEventLogRecord(li->log, &firstrecord);
		GetNumberOfEventLogRecords(li->log, &nrecords);
		li->position = firstrecord + nrecords - 1;

		li->event = CreateEvent(NULL, FALSE, FALSE, NULL);
		if (!li->event)
			lw_winerror();

		if (!NotifyChangeEventLog(li->log, li->event))
			lw_winerror();

		logs.push_back(li);
		handles.push_back(li->event);
	}

	for (;;) {
		DWORD ret = WaitForMultipleObjects(handles.size(), &*handles.begin(), FALSE, INFINITE);
		if (ret == WAIT_FAILED)
			lw_winerror();

		int idx = ret - WAIT_OBJECT_0;
		if (idx < 0 || idx >= logs.size())
			lw_error(L"Unexpected return value.");

		loginfo_t *li = logs[idx];

		const int BUFFER_SIZE = 1024*64*2;
		BYTE bBuffer[BUFFER_SIZE];
		EVENTLOGRECORD *pevlr = (EVENTLOGRECORD *) &bBuffer;

		DWORD dwRead, dwNeeded;
		while (ReadEventLog(li->log, EVENTLOG_FORWARDS_READ|EVENTLOG_SEEK_READ,
			li->position, pevlr, BUFFER_SIZE, &dwRead, &dwNeeded)) {

			unsigned long now = time(NULL);
			unsigned long time_limit = now - discard_time;

			while (dwRead > 0) {
				EventLogRecord rec(pevlr);

				time_t time_ = rec.TimeGenerated();
				if (!discard_time || time_ >= time_limit) {

					tm *ltime = localtime(&time_);

					wchar_t buf[100];
					swprintf(buf, L"%04i-%02i-%02i",
						int(ltime->tm_year+1900), int(ltime->tm_mon), int(ltime->tm_mday));
					li->vars[L"date"] = buf;

					swprintf(buf, L"%02i:%02i:%02i",
						int(ltime->tm_hour), int(ltime->tm_min), int(ltime->tm_sec));

					li->vars[L"time"] = buf;

					const wchar_t *etype = 0;
					switch (rec.EventType()) {
					case EVENTLOG_ERROR_TYPE:
						etype = L"error"; break;
					case EVENTLOG_WARNING_TYPE:
						etype = L"warning"; break;
					case EVENTLOG_INFORMATION_TYPE:
						etype = L"information"; break;
					case EVENTLOG_AUDIT_SUCCESS:
						etype = L"audit success"; break;
					case EVENTLOG_AUDIT_FAILURE:
						etype = L"audit failure"; break;
					default:
						etype = L"<unknown type>";
					}
					li->vars[L"type"] = etype;

					li->vars[L"source"] = rec.SourceName();
					std::wstring message = li->format.FormatRecord(pevlr);
					while (!message.empty() && message[message.size()-1] == '\n')
						message.erase(message.size()-1);
					li->vars[L"message"] = message;
					li->vars[L"computer"] = rec.ComputerName();

					lw_log(L"event: " + rec.SourceName() + L": " + message);

					li->root->handle(*li);
				}

				dwRead -= pevlr->Length; 
				pevlr = (EVENTLOGRECORD *) ((LPBYTE) pevlr + pevlr->Length);
				++li->position;
			} 

			pevlr = (EVENTLOGRECORD *) &bBuffer; 
		} 
	}
}
catch (std::exception &e) {
	lw_error(mbtow(e.what()));
}
