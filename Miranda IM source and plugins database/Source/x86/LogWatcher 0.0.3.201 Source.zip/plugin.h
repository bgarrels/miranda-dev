#ifndef LW_PLUGIN_H
#define LW_PLUGIN_H

#define _WINSOCKAPI_ // don't include winsock 1.x
#include <windows.h>
#include <winioctl.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#include <string>
#include <sstream>
#include <vector>

template<class T> std::wstring to_str(const T &t) {
	std::wostringstream ss;
	ss << t;
	return ss.str();
}

struct targetinfo {
	SOCKADDR_IN addr;
	bool tcp;
	std::string passwd;
};

void lw_expand(const std::wstring &target, std::vector<targetinfo> &, int depth = 0);
void lw_expand_single(const std::wstring &target, std::vector<targetinfo> &, int depth = 0);

void lw_sendlog(const std::wstring &, const targetinfo &target);
void lw_sendlog(const std::wstring &, const std::vector<targetinfo> &target);
void lw_sendlog(const std::wstring &, const std::wstring &target);

void lw_log(const std::wstring &, bool debug_log = false);
void lw_error(const std::wstring &);
void lw_numerror(int error);
void lw_winerror();

void lw_errsync();
const wchar_t *lw_geterror();
void lw_ignore_errors(bool);

std::wstring errtos(int error);

std::string wtomb(const std::wstring &);
std::wstring mbtow(const std::string &);

/*

Symbols to define:

void [pluginname]_ThreadFunc(const xml::welement &options);

*/

#endif
