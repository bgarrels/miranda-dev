#include "plugin.h"
#include "nodes.h"

loop_node::loop_node()
	: maxiter(-1)
{
}

void loop_node::init(stringmap_t &defaults, const xml::welement &opt)
{
	block_node::init(defaults, opt);

	getattr(opt, L"count", maxiter);

	if (maxiter < 0)
		lw_error(L"Invalid value for <loop> attribute \"count\".");
}

int loop_node::handle(action_data_t &fi)
{
	for (int i=0; i<maxiter; ++i) {
		int t = block_node::handle(fi);
		if (t == 0 || t == 1)
			continue;
		else
			return t-2;
	}
	return 0;
}
