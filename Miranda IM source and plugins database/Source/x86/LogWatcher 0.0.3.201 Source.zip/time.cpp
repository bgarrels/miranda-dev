#include "plugin.h"
#include "nodes.h"

#include <sys/types.h>
#include <sys/timeb.h>
#include <time.h>

#include <sstream>

#include <xml/element.h>

extern "C" {
__declspec(dllexport) void time_ThreadFunc(const xml::welement &options);
}

namespace {
	template<class T> std::wstring ttostr(const T &t, int n) {
		std::wostringstream ss;
		ss.width(n);
		ss.fill('0');
		ss << t;
		return ss.str();
	}
}

void time_ThreadFunc(const xml::welement &opt)
try
{
	stringmap_t defaults;

	wnode *root = new block_node;
	root->init(defaults, opt);

	action_data_t fi;

	int lastminute = -1;
	for (;;) {
		time_t t_;
		time(&t_);
		tm t = *localtime(&t_);

		fi.vars[L"hour"] = ttostr(t.tm_hour, 2);
		fi.vars[L"minute"] = ttostr(t.tm_min, 2);
		fi.vars[L"weekday"] = ttostr(t.tm_wday, 1); // Sunday = 0
		fi.vars[L"monthday"] = ttostr(t.tm_mday, 2);
		fi.vars[L"yearday"] = ttostr(t.tm_yday, 3);
		fi.vars[L"month"] = ttostr(t.tm_mon, 2);
		fi.vars[L"year"] = ttostr(t.tm_year+1900, 4);

		lw_log(L"event: time: " + fi.vars[L"hour"] + L':' + fi.vars[L"minute"], true);

		root->handle(fi);

		Sleep((60-t.tm_sec)*1000);
		int minute = t.tm_hour*60 + t.tm_min;
		while (lastminute == minute) {
			lw_log(L"time: not synchronized, taking a nap", true);
			Sleep(1000);

			time(&t_);
			t = *localtime(&t_);

			int minute = t.tm_hour*60 + t.tm_min;
		}
	}
}
catch (std::exception &e) {
	lw_error(mbtow(e.what()));
}
