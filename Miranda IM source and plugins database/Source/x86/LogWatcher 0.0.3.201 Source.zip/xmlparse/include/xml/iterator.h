#ifndef XML_ITERATOR_H
#define XML_ITERATOR_H

#include <iterator>

#include <xml/element_source.h>

namespace xml {

template<class Value, class CharT>
class basic_iterator : public std::iterator<std::forward_iterator_tag, Value> {
public:
	mutable element_source<CharT> *source;
	mutable Value *current;

	basic_iterator() : source(0), current(0) {}
	explicit basic_iterator(element_source<CharT> *s)
		: source(s->acquire()), current(0) {}
	template<class T> basic_iterator(const basic_iterator<T, CharT> &i)
		: source(i.source->acquire()), current(0) {}
	~basic_iterator() { if (source) source->release(); }

	Value *get() const {
		if (current)
			return current;
		if (!source)
			return 0;
		return current = source->pubnext(source);
	}

	Value *operator->() const { return get(); }
	Value &operator*() const { return *get(); }

	basic_iterator &operator=(const basic_iterator &i) {
		element_source<CharT> *t = source;
		source = i.source;
		if (source) source->acquire();
		if (t) t->release();
		return *this;
	}

	basic_iterator &operator++() {
		if (!current)
			source->pubnext(source);
		current = source->pubnext(source);
		return *this;
	}
	basic_iterator operator++(int) {
		basic_iterator t = *this;
		++*this;
		return t;
	}

	bool operator!() const { return !get(); }
	operator void *() const
		{ return reinterpret_cast<void *>(int(!!*this)); }

	bool operator!=(const basic_iterator &i) const { return get() != i.get(); }
	bool operator==(const basic_iterator &i) const { return get() == i.get(); }
};

} // namespace xml

#endif
