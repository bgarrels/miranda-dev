#ifndef XML_PARSER_H
#define XML_PARSER_H

#include <string>
#include <stdexcept>

namespace xml {

class parse_error : public std::runtime_error {
public:
	parse_error(const std::string &);
	parse_error(const char *);
	~parse_error() throw ();
};

template<class CharT>
class basic_parser {
public:
	typedef std::basic_string<CharT> string;
	typedef std::basic_istream<CharT> istream;

	virtual ~basic_parser();

	virtual void parse(istream &);

	// notifications
	virtual void xml_declaration() = 0;
	virtual void processing_instruction() = 0;
	virtual void start_tag(const string &tag) = 0;
	virtual void end_tag() = 0;

	virtual void attribute(const string &name, const string &val) = 0;

	virtual void content(const string &data) = 0;
	virtual void comment(const string &data);

	// strict xml error notification
	virtual void pedantic_initial_space();
	virtual void pedantic_missing_xmldecl();
	virtual void pedantic_multiple_roots();
	virtual void pedantic_missing_root();

	/// parse contents of an element
	/** if \a accept_eof = \c true, then no error will be issued if end of file is reached during
	  * processing at the local root level. if \a accept_eof = \c false, then \a tag is expected
	  * to match an end tag. */
	virtual void parse_content(istream &, const string &tag, bool accept_eof = false);

	// abnormal parsing_behaviour
	virtual void unexpected_rootlevel(istream &);


	void parse_attributes(istream &);
	void parse_element(istream &);

	void acc_until(istream &, string &, char end, bool allow_line);
	string get_until(istream &, char end, bool allow_line);
	void acc_until(istream &, string &, const char *end, bool allow_l);
	string get_until(istream &, const char *end, bool allow_line);

	string get_name(istream &);

	void skipspace(istream &);

	void expect(istream &, char c, const char *expected_msg);
	void expect(istream &, const char *str, const char *expected_msg);

	/// \todo implement
	string decode(const string &);
	/// \todo implement hex decode?
	string decode_ref(const string &);
};

} // namespace xml

#endif
