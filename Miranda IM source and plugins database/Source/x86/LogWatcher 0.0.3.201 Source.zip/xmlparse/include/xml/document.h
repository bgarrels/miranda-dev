#ifndef XML_DOCUMENT_H
#define XML_DOCUMENT_H

#include <xml/element.h>

namespace xml {

template<class CharT>
class basic_document : public basic_element<CharT> {
public:
	basic_document();
	explicit basic_document(std::basic_istream<CharT> &);

	void load(std::basic_istream<CharT> &);

	basic_element<CharT> xmldecl, root;
};

typedef basic_document<char> document;
typedef basic_document<wchar_t> wdocument;

} // namespace xml

#endif
