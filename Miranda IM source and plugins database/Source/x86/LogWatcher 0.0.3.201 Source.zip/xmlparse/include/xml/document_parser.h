#ifndef XML_DOCUMENT_PARSER_H
#define XML_DOCUMENT_PARSER_H

#include <list>

#include <xml/parser.h>
#include <xml/element.h>

namespace xml {

template<class CharT> class basic_document;

template<class CharT>
class basic_document_parser : public basic_parser<CharT> {
public:
	typedef std::basic_string<CharT> string;

	basic_document_parser();

	void parse(std::basic_istream<CharT> &, basic_document<CharT> &);

protected:
	std::list<basic_element<CharT> > estack;
	basic_document<CharT> *doc;

	void xml_declaration();
	void processing_instruction();
	void start_tag(const string &tag);
	void end_tag();
	void attribute(const string &name, const string &val);
	void content(const string &data);
};

} // namespace xml

#endif
