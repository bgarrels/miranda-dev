#ifndef XML_ATTRIBUTE_H
#define XML_ATTRIBUTE_H

#include <map>
#include <string>

namespace xml {

typedef std::map<std::wstring, std::wstring> wsmap;

inline void copy_map(const wsmap &a, const wsmap &b)
{
	const_cast<wsmap &>(a) = b;
}

template<class Map, class Iter>
class basic_attribute {
public:
	typedef typename Map::key_type string;
	Map &m_map;
	Iter m_it;
	string m_name;

//	basic_attribute(const basic_attribute &);
	basic_attribute(Map &m, const string &n);

	const string &name() const { return m_name; }
	const string &value() const;

	bool valid() const { return m_it != m_map.end(); }

	basic_attribute &operator=(const string &);
	basic_attribute &operator=(const basic_attribute &a)
		{ copy_map(m_map, a.m_map); m_it = a.m_it; m_name = a.m_name; return *this; }

	const string &operator*() const { return value(); }

	bool operator!() const { return !valid(); }

	typedef bool (basic_attribute::*bool_type)() const;

	operator bool_type() const { return valid() ? &basic_attribute::valid : 0; }
};

template<class Map, class Iter, class T>
void get(const basic_attribute<Map, Iter> &a, T &val)
{
	typedef basic_attribute<Map, Iter> A;
	typedef typename A::string::value_type char_t;
	std::basic_istringstream<char_t> ss(a.value());
	ss >> val;
	if (!ss) throw std::runtime_error(
		"failed to read attribute `" + strutil::to_t<char>(a.m_name) + '\'');
	char_t c;
	ss.read(&c, 1);
	if (ss.gcount() != 0) throw std::runtime_error(
		"unexpected characters in attribute `" + strutil::to_t<char>(a.m_name) + '\'');
}

template<class Map, class Iter, class T>
bool get0(const basic_attribute<Map, Iter> &a, T &val)
{
	if (!a.valid()) return false;
	get(a, val);
	return true;
}


} // namespace xml

#include <xml/attribute.tpp>

#endif
