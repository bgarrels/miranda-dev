#ifndef XML_ELEMENT_H
#define XML_ELEMENT_H

#include <list>

#include <xml/iterator.h>
#include <xml/attribute.h>

namespace xml {

template<class CharT> class basic_document;
template<class CharT> struct rep_t;

template<class CharT>
class basic_element {
	typedef std::basic_string<CharT> string;
	typedef std::auto_ptr<element_source<CharT> > esptr;
	typedef std::map<string, string> attribute_map_t;

	void acquire() const;
	element_source<CharT> *find_es(element_source<CharT> *self,
		const std::basic_string<CharT> &, bool recursed) const;
public:
	typedef xml::rep_t<CharT> rep_t;
	mutable rep_t *rep;

	typedef std::basic_string<CharT> string;

	typedef xml::basic_iterator<basic_element, CharT> iterator;
	typedef xml::basic_iterator<const basic_element, CharT> const_iterator;

	typedef xml::basic_attribute<attribute_map_t, typename attribute_map_t::iterator> 
		attribute;
	typedef xml::basic_attribute<const attribute_map_t, 
		typename attribute_map_t::const_iterator> const_attribute;

	basic_element();
	explicit basic_element(const string &tag);
	basic_element(const basic_element &);
	~basic_element();

	basic_element &operator=(const basic_element &);

	const attribute_map_t &attributes() const {
		static attribute_map_t empty;
		if (!rep)
			return empty;
		return rep->attr;
	}
	attribute_map_t &attributes() {
		acquire();
		return rep->attr;
	}

	const string &tag() const;

	iterator begin();
	const_iterator begin() const;

	iterator end() { return iterator(); }
	const_iterator end() const { return const_iterator(); }

	unsigned size() const;

	iterator find(const string &xpath);
	const_iterator find(const string &xpath) const;

	string &wdata();
	const string &data() const;

	bool is_space() const;
	bool is_pc() const;
	bool is_data() const;
	bool is_node() const;

	void insert(const basic_element &e);
	void insert_data(const string &);

	attribute attr(const string &name);
	const_attribute attr(const string &name) const;

	/// \return the parent element or 0
	basic_element *parent() const;
	basic_element *root() const;

	/// replace contents with parsed results of \a str
	void inner_xml(const string &str);
	/// \return contents as an xml-snippet, using the original formatting
	string inner_xml() const;
};

typedef basic_element<char> element;
typedef basic_element<wchar_t> welement;

template<class CharT>
struct rep_t {
	typedef std::basic_string<CharT> string;
	typedef std::list<basic_element<CharT> > elist;
	typedef std::map<std::basic_string<CharT>, elist> emap;
	typedef std::auto_ptr<element_source<CharT> > esptr;
	typedef std::map<string, string> attribute_map_t;

	enum spaceinfo { si_yes, si_no, si_unknown };

	rep_t() : refs(1), parent(0), space(si_unknown) {}
	explicit rep_t(const string &t)
		: refs(1), tag(t), parent(0), space(si_unknown) {}

	int refs;
	const string tag;
	string data;
	attribute_map_t attr;
	elist children;
	emap childmap;
	basic_element<CharT> *parent;
	spaceinfo space;
private:
	rep_t(const rep_t &);
	rep_t &operator=(const rep_t &);
};

} // namespace xml

#endif
