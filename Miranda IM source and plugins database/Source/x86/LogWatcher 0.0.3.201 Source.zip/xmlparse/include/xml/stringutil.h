#ifndef XML_STRINGUTIL_H
#define XML_STRINGUTIL_H

#include <string>
#include <cstring>
#include <cwchar>

namespace xml {
namespace strutil {

using namespace std;

template<class CharT>
inline void stringconv(basic_string<CharT> &d, const basic_string<CharT> &s)
	{ d = s; }

void stringconv(basic_string<char> &d, const basic_string<wchar_t> &s);
void stringconv(basic_string<wchar_t> &d, const basic_string<char> &s);

template<class CharT, class FromT>
inline basic_string<CharT> to_t(const basic_string<FromT> &s) {
	basic_string<CharT> dest;
	stringconv(dest, s);
	return dest;
}
/*
template<class CharT>
inline basic_string<CharT> to_t(const basic_string<CharT> &s)
	{ return s; }
*/
template<class CharT, class FromT>
inline basic_string<CharT> to_t(const FromT *s)
	{ return to_t<CharT>(basic_string<FromT>(s)); }

inline bool is_equal(const char *a, const char *b) { return !strcmp(a, b); }
inline bool is_equal(const wchar_t *a, const wchar_t *b) { return !wcscmp(a, b); }

template<class A, class B>
bool is_equal(const A *a, const B *b)
{
	while (*a == *b) {
		if (!*a)
			return true;
		++a, ++b;
	}
	return false;
}

template<class A, class B>
inline bool is_equal(const basic_string<A> &a, const B *b)
	{ return is_equal(a.c_str(), b); }

template<class A, class B>
inline bool is_equal(const basic_string<A> &a, const basic_string<B> &b)
	{ return is_equal(a.c_str(), b.c_str()); }

template<class A, class B>
inline bool is_equal(const A *a, const basic_string<B> &b)
	{ return is_equal(a, b.c_str()); }

} // namespace strutil
} // namespace xml

#endif
