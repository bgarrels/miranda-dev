#ifndef XML_ELEMENT_SOURCE_H
#define XML_ELEMENT_SOURCE_H

namespace xml {

template<class CharT> class basic_element;

template<class CharT>
class element_source {
	int refs;
	element_source *token;
public:
	element_source() : refs(0), token(0) {}
	virtual ~element_source() {}

	basic_element<CharT> *pubnext(element_source *&tok) {
		if (token == tok)
			return next();
		else if (!token || refs == 1) {
			token = tok;
			return next();
		} else {
			tok = clone();
			return tok->next();
		}
	}

	element_source *acquire() { ++refs; return this; }
	void release() { if (!--refs) delete this; }

	virtual basic_element<CharT> *next() = 0;
	virtual element_source *clone() const = 0;
};

} // namespace xml

#endif
