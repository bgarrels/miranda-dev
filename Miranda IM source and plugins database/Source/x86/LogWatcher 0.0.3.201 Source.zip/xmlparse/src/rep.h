#ifndef XML_REP_H
#define XML_REP_H

#include <xml/element.h>

namespace xml {

} // namespace xml

#endif
