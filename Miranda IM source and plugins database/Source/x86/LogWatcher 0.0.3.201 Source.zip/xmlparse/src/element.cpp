#include "sources.h"

#include <iostream>

namespace xml {
namespace {

template<class CharT>
inline const std::basic_string<CharT> &empty_string() {
	static std::basic_string<CharT> str;
	return str;
}

} // anonymous namespace

template<class CharT>
inline void basic_element<CharT>::acquire() const {
	if (!rep)
		rep = new rep_t;
}

template<class CharT>
basic_element<CharT>::basic_element()
	: rep(0)
{
}

template<class CharT>
basic_element<CharT>::basic_element(const string &tag)
	: rep(new rep_t(tag))
{
}

template<class CharT>
basic_element<CharT>::basic_element(const basic_element &e) : rep(0) {
	e.acquire();
	rep = e.rep;
	++rep->refs;
}

template<class CharT>
basic_element<CharT>::~basic_element() {
	if (rep && !--rep->refs)
		delete rep;
}

template<class CharT>
const std::basic_string<CharT> &basic_element<CharT>::tag() const {
	if (!rep)
		return empty_string<CharT>();
	return rep->tag;
}

template<class CharT>
typename basic_element<CharT>::iterator basic_element<CharT>::begin()
{
	if (!rep) return iterator();
	return iterator(new child_source<CharT>(new self_source<CharT>(this)));
}

template<class CharT>
typename basic_element<CharT>::const_iterator basic_element<CharT>::begin() const
{
	if (!rep) return const_iterator();
	return const_iterator(new child_source<CharT>(
		new self_source<CharT>(const_cast<basic_element *>(this))));
}

template<class CharT>
basic_element<CharT> *basic_element<CharT>::parent() const
{
	return rep ? rep->parent : 0;
}

template<class CharT>
basic_element<CharT> *basic_element<CharT>::root() const
{
	basic_element *e = const_cast<basic_element *>(this), *r = 0;
	if (!e) throw std::runtime_error("cannot find root element");
	while (e) {
		if (!e->rep)
			throw std::runtime_error("cannot find root element");
		r = e;
		e = e->rep->parent;
	}
	return r;
}

template<class CharT>
element_source<CharT> *basic_element<CharT>::find_es(element_source<CharT> *self_,
	const string &path, bool recursed) const
{
	esptr self(self_);
	unsigned p;
	if (strutil::is_equal(path, "."))
		return self.release();
	else if (strutil::is_equal(path, ".."))
		return new parent_source<CharT>(self.release());
	else if (strutil::is_equal(path, "*"))
		return new child_source<CharT>(self.release());
	else if ((p = path.find('/')) != path.npos) {
		string first(path, 0, p), second(path, p+1);
		bool sibling = second[0] == '/';
		if (sibling)
			second.erase(second.begin());
		esptr firstp;
		if (first.empty()) {
			if (recursed) throw std::runtime_error("invalid xpath");
			if (sibling)
				firstp.reset(new sibling_source<CharT>(new self_source<CharT>(root())));
			else
				firstp.reset(new child_source<CharT>(new self_source<CharT>(root())));
		} else
			firstp.reset(find_es(self.release(), first, recursed));

		return find_es(firstp.release(), second, true);
/*	} else if (recursed) {
		return new typefilter_source(self.release(), path);
*/	} else { // !recursed
		return new childtype_source<CharT>(self.release(), path);
	}
/*	else
		throw std::runtime_error(
			"invaild element path `" + path + '\'');
*/
}

template<class CharT>
typename basic_element<CharT>::iterator basic_element<CharT>::find(const string &path)
{
	if (!rep) return iterator();
	return iterator(find_es(new self_source<CharT>(this), path, false));
}

template<class CharT>
typename basic_element<CharT>::const_iterator basic_element<CharT>::find(const string &path) const
{
	if (!rep) return const_iterator();
	return const_iterator(find_es(new self_source<CharT>(
		const_cast<basic_element *>(this)), path, false));
}

template<class CharT>
unsigned basic_element<CharT>::size() const
{
	if (!rep)
		return 0;
	return rep->children.size();
}

template<class CharT>
typename basic_element<CharT>::attribute basic_element<CharT>::attr(const string &name) {
	acquire();
	return attribute(rep->attr, name);
}

template<class CharT>
typename basic_element<CharT>::const_attribute basic_element<CharT>::attr(const string &name) const {
	acquire();
	return const_attribute(rep->attr, name);
}

template<class CharT>
basic_element<CharT> &basic_element<CharT>::operator=(const basic_element &e)
{
	e.acquire();
	rep_t *r = rep;
	++e.rep->refs;
	rep = e.rep;
	if (r && !--r->refs)
		delete r;
	return *this;
}

template<class CharT>
void basic_element<CharT>::insert(const basic_element &e)
{
	acquire();
	e.acquire();
	e.rep->parent = this;
	rep->children.push_back(e);
	rep->childmap[e.tag()].push_back(e);
}

template<class CharT>
void basic_element<CharT>::insert_data(const string &s)
{
	acquire();
	typename rep_t::elist &ch = rep->children;
	if (ch.empty() || ch.back().tag().empty())
		insert(basic_element<CharT>());
	ch.back().wdata() += s;
}

template<class CharT>
std::basic_string<CharT> &basic_element<CharT>::wdata()
{
	acquire();
	rep->space = rep_t::si_unknown;
	return rep->data;
}

template<class CharT>
const std::basic_string<CharT> &basic_element<CharT>::data() const
{
	if (!rep)
		return empty_string<CharT>();

	if (rep->tag.empty())
		return rep->data;

	const typename rep_t::elist &ch = rep->children;
	if (ch.size() == 1) {
		if (ch.back().tag().empty())
			return ch.back().data();
		else throw std::runtime_error("no data avaliable");
	} else if (ch.empty())
		return empty_string<CharT>();

	throw std::runtime_error("ambiguous data request");
}

template<class CharT>
bool basic_element<CharT>::is_pc() const
{
	if (!rep || rep->tag.empty())
		return false;
	return rep->tag[0] == '?';
}

template<class CharT>
bool basic_element<CharT>::is_node() const
{
	return !rep && !rep->tag.empty();
}

template<class CharT>
bool basic_element<CharT>::is_data() const
{
	return !rep || rep->tag.empty();
}

template<class CharT>
bool basic_element<CharT>::is_space() const
{
	if (!rep) return false;

	typename rep_t::spaceinfo si = rep->space;
	if (si == rep_t::si_yes) return true;
	if (si == rep_t::si_no) return false;

	typename string::const_iterator i=rep->data.begin(), e=rep->data.end();
	if (i==e || !rep->tag.empty()) {
		rep->space = rep_t::si_yes;
		return false;
	}

	using namespace std;

	for (; i!=e; ++i)
		if (!isspace(*i)) {
			rep->space = rep_t::si_no;
			return false;
		}

	rep->space = rep_t::si_yes;
	return true;
}

template class basic_element<char>;
template class basic_element<wchar_t>;

} // namespace xml
