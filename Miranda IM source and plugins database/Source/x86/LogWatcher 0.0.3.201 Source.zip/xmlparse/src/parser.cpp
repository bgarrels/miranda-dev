#include <xml/parser.h>

#include <iostream>
#include <stdexcept>
#include <sstream>
#include <cwchar>

#include <xml/stringutil.h>

namespace xml {
namespace {

inline const char *tstrchr(const char *s, char c) { return strchr(s, c); }
inline const wchar_t *tstrchr(const wchar_t *s, wchar_t c) { return wcschr(s, c); }

template<class A, class B>
inline bool tstrncmp(A *a, B *b, int n) {
	for (int i=0; i!=n; ++i)
		if (a[i] == b[i]) {
			if (!a[i])
				return false;
		} else
			return true;
	return false;
}

void unexpected(const char *e)
{
	throw parse_error(std::string("unexpected ") + e);
}

template<class CharT>
inline CharT get(std::basic_istream<CharT> &s)
{
	CharT c;
	if (!s.get(c)) {
		if (s.eof())
			unexpected("end of file");
		else
			throw parse_error("stream failure");
	}
	return c;
}

inline bool ischar(char c)
{
	return isalpha(c) || std::strchr("_:", c);
}

inline bool ischar(wchar_t c)
{
	return iswalpha(c) || wcschr(L"_:", c);
}

} // anonymous namespace

parse_error::parse_error(const char *e)
	: std::runtime_error(e)
{
}

parse_error::parse_error(const std::string &e)
	: std::runtime_error(e)
{
}

parse_error::~parse_error() throw ()
{
}

template<class CharT>
basic_parser<CharT>::~basic_parser()
{
}

template<class CharT>
void basic_parser<CharT>::acc_until(istream &s, string &r, char end, bool allow_line)
{
	for (;;) {
		CharT c = get(s);
		if (c == end)
			return;
		else if (c == '\n' && !allow_line)
			unexpected("end of line");
		r += c;
	}
}

template<class CharT>
std::basic_string<CharT> basic_parser<CharT>::get_until(istream &s, char end, bool allow_line)
{
	string r;
	acc_until(s, r, end, allow_line);
	return r;
}

template<class CharT>
void basic_parser<CharT>::acc_until(istream &s, string &r, const char *end, bool allow_l)
{
	int n = std::strlen(end);
	CharT buf[4];
	for (int i=0; i!=n; ++i)
		buf[i] = get(s);
	buf[n] = '\0';
	while (tstrncmp(end, buf, n)) {
		r += buf[0];
		for (int i=0; i<=n-1; ++i)
			buf[i] = buf[i+1];
		buf[n-1] = get(s);
		if (buf[n-1] == '\n' && !allow_l)
			unexpected("end of line");
	}
}

template<class CharT>
std::basic_string<CharT> basic_parser<CharT>::get_until(istream &s, const char *end, bool allow_line)
{
	string r;
	acc_until(s, r, end, allow_line);
	return r;
}

void basic_parser<char>::skipspace(istream &s)
{
	char c;
	while (s.get(c))
		if (!isspace(c)) {
			s.putback(c);
			break;
		}
}
void basic_parser<wchar_t>::skipspace(istream &s)
{
	wchar_t c;
	while (s.get(c))
		if (!iswspace(c)) {
			s.putback(c);
			break;
		}
}

template<class CharT>
void basic_parser<CharT>::expect(istream &s, char c, const char *e)
{
	if (get(s) != c)
		throw parse_error(std::string("expected ") + e);
}

template<class CharT>
void basic_parser<CharT>::expect(istream &s, const char *str, const char *e)
{
	for (; *str; ++str)
		if (get(s) != *str)
			throw parse_error(std::string("expected ") + e);
}

template<class CharT>
std::basic_string<CharT> basic_parser<CharT>::decode(const string &str)
{
	const CharT *lstart = str.c_str();
	const CharT *lend = tstrchr(lstart, '&');

	if (!lend) return str;

	string res(lstart, lend);
	for (;;) {
		const CharT *vstart = lend+1;
		const CharT *vend = tstrchr(vstart, ';');
		if (!vend)
			throw parse_error("unterminated reference");

		string var(vstart, vend);
		res += decode_ref(var);

		lstart = vend+1;
		lend = tstrchr(lstart, '&');

		if (lend)
			res.append(lstart, lend);
		else
			return res += lstart;
	}
}

template<class CharT>
std::basic_string<CharT> basic_parser<CharT>::decode_ref(const string &s)
{
	if (strutil::is_equal(s, "lt"))
		return strutil::to_t<CharT>("<");
	if (strutil::is_equal(s, "gt"))
		return strutil::to_t<CharT>(">");
	if (strutil::is_equal(s, "amp"))
		return strutil::to_t<CharT>("&");
	if (strutil::is_equal(s, "apos"))
		return strutil::to_t<CharT>("'");
	if (strutil::is_equal(s, "quot"))
		return strutil::to_t<CharT>("\"");
	if (s.size() > 1 && s[0] == '#') {
		unsigned cnum;
		std::basic_istringstream<CharT> ss(s);
		ss.get();
		if (s[1] == 'x') {
			ss.get();
			ss >> std::hex;
		}
		if (!ss)
			throw parse_error("invalid numerical character reference: `&"
				+ strutil::to_t<char>(s) + ";'");
		ss >> cnum;
		string t;
		t += CharT(cnum);
		return t;
	}
	throw parse_error("unknown character reference: `&"
		+ strutil::to_t<char>(s) + ";'");
}

template<class CharT>
std::basic_string<CharT> basic_parser<CharT>::get_name(istream &s)
{
	string r;
	CharT c = get(s);
	if (!ischar(c))
		throw parse_error("invalid character in name");

	while (isalnum(c) || std::strchr("_:-.", c)) {
		r += c;
		c = get(s);
	}
	s.putback(c);
	return r;
}

template<class CharT>
void basic_parser<CharT>::parse(istream &s)
{
	CharT c = get(s);
	if (isspace(c))
		pedantic_initial_space();
	s.putback(c);

	bool has_root = false, has_xmldecl = false;
	for (;;) {
		skipspace(s);
		if (!s) {
			if (!has_xmldecl)
				pedantic_missing_xmldecl();
			if (!has_root)
				pedantic_missing_root();
			return;
		}
		c = get(s);
		if (c != '<') {
			s.putback(c);
			unexpected_rootlevel(s);
			return;
		}
		c = get(s);
		if (c == '!') {
			if (!has_xmldecl)
				pedantic_missing_xmldecl();
			expect(s, "--", "`<!--'");
			comment(get_until(s, "-->", true));
		} else if (c == '?') {
			expect(s, "xml", "`<?xml'");
			has_xmldecl = true;
			xml_declaration();
			parse_attributes(s);
			expect(s, "?>", "?>");
			end_tag();
		} else if (ischar(c)) {
			s.putback(c);

			if (!has_xmldecl)
				pedantic_missing_xmldecl();
			if (has_root)
				pedantic_multiple_roots();
			has_root = true;

			parse_element(s);
		} else
			throw parse_error("expected comment or element declaration");
	}
}

template<class CharT>
void basic_parser<CharT>::parse_element(istream &s)
{
	string name = get_name(s);
	start_tag(name);

	parse_attributes(s);

	CharT c = get(s);
	if (c == '/') {
		expect(s, '>', ">");
		return end_tag();
	} else if (c != '>')
		throw parse_error("expected `/>' or `>'");

	parse_content(s, name);
}

template<class CharT>
void basic_parser<CharT>::parse_attributes(istream &s)
{
	for (;;) {
		skipspace(s);
		CharT c = get(s);
		s.putback(c);
		if (!ischar(c))
			return;

		string name = get_name(s);
		expect(s, '=', "=");
		c = get(s);
		if (c != '\'' && c != '"')
			throw parse_error("expected single or double "
				"quote (`'' or `\"')");
		string value = decode(get_until(s, c, false));
		attribute(name, value);
	}
}

template<class CharT>
void basic_parser<CharT>::parse_content(istream &s, const string &tag, bool accept_eof)
{
	for (;;) {
		CharT c;
		string chardata;
		while (s.get(c)) {
			if (c != '&' && c != '<')
				chardata += c;
			else
				break;
		}
		content(chardata);
		if (!s) {
			if (s.eof() && accept_eof)
				return;
			else if (s.eof())
				throw parse_error("unexpected end of file");
			else
				throw parse_error("stream error");
		}

		if (c == '&') {
			content(decode_ref(get_name(s)));
			expect(s, ';', ";");
			continue;
		} else if (c == '<') {
			c = get(s);
			if (c == '!') {
				c = get(s);
				if (c == '-') {
					expect(s, '-', "`<!--'");
					get_until(s, "-->", true);
				} else if (c == '[') {
					expect(s, "CDATA[", "`<![CDATA['");
					string t;
					acc_until(s, t, "]]>", true);
					content(t);
				} else
					throw parse_error("expected `<!--' "
						"or `<![CDATA['");
			} else if (c == '/') {
				string t = get_name(s);
				if (tag != t)
					throw parse_error("unmatched end tag `"
						+ strutil::to_t<char>(t) + "', in `"
						+ strutil::to_t<char>(tag) + '\'');
				skipspace(s);
				expect(s, '>', ">");
				end_tag();
				return;
			} else if (ischar(c)) {
				s.putback(c);
				parse_element(s);
			} else
				throw parse_error("expected element declaration");
		}
	}
}

template<class CharT> void basic_parser<CharT>::xml_declaration() {}
template<class CharT> void basic_parser<CharT>::processing_instruction() {}
template<class CharT> void basic_parser<CharT>::attribute(const string &, const string &) {}
template<class CharT> void basic_parser<CharT>::content(const string &) {}
template<class CharT> void basic_parser<CharT>::comment(const string &) {}

template<class CharT>
void basic_parser<CharT>::pedantic_initial_space()
{
	throw parse_error("unexpected whitespace in stream");
}

template<class CharT>
void basic_parser<CharT>::pedantic_missing_xmldecl()
{
	throw parse_error("missing xml-declaration");
}

template<class CharT>
void basic_parser<CharT>::pedantic_multiple_roots()
{
	throw parse_error("multiple root nodes found");
}

template<class CharT>
void basic_parser<CharT>::pedantic_missing_root()
{
	throw parse_error("missing root node");
}

template<class CharT>
void basic_parser<CharT>::unexpected_rootlevel(istream &s)
{
	string t;
	t += get(s);
	throw parse_error(std::string("unexpected character: `")
		+ strutil::to_t<char>(t) + '\'');
}

template class basic_parser<char>;
template class basic_parser<wchar_t>;

} // namespace xml
