#include <xml/document.h>

#include <xml/document_parser.h>

namespace xml {

template<class CharT>
basic_document<CharT>::basic_document()
{
}

template<class CharT>
basic_document<CharT>::basic_document(std::basic_istream<CharT> &s)
{
	basic_document_parser<CharT>().parse(s, *this);
}

template<class CharT>
void basic_document<CharT>::load(std::basic_istream<CharT> &s)
{
	*this = basic_document<CharT>();
	basic_document_parser<CharT>().parse(s, *this);
}

template class basic_document<char>;
template class basic_document<wchar_t>;

} // namespace xml
