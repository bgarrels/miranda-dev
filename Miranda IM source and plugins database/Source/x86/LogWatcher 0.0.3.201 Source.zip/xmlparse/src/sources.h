#ifndef XML_SOURCES_H
#define XML_SOURCES_H

#include <xml/element_source.h>

#include <vector>

#include "rep.h"

namespace xml {
/*
typedef elist::iterator elit;
typedef std::map<std::basic_string<CharT>, elist> emap;
typedef emap::iterator emit;
typedef std::auto_ptr<element_source> esptr;
*/

template<class CharT>
struct self_source : element_source<CharT> {
	basic_element<CharT> *el;

	self_source(basic_element<CharT> *e) : el(e) {}

	basic_element<CharT> *next() {
		basic_element<CharT> *t = el;
		el = 0;
		return t;
	}

	self_source *clone() const { return new self_source(*this); }
};

template<class CharT>
struct parent_source : element_source<CharT> {
	typedef std::auto_ptr<element_source<CharT> > esptr;

	const esptr src;

	parent_source(element_source<CharT> *es) : src(es) {}

	basic_element<CharT> *next() {
		basic_element<CharT> *t = src->next();
		return t ? t->parent() : 0;
	}

	parent_source *clone() const { return new parent_source(src->clone()); }
};

template<class CharT>
struct child_source : element_source<CharT> {
	typedef std::auto_ptr<element_source<CharT> > esptr;
	typedef std::list<basic_element<CharT> > elist;
	typedef typename elist::iterator elit;

	const esptr src;
	elit begin, end;

	child_source(element_source<CharT> *es) : src(es), end(begin) {}
	child_source(element_source<CharT> *es, elit b, elit e) : src(es), begin(b), end(e) {}

	basic_element<CharT> *next() {
		if (begin != end)
			return &*begin++;
		while (basic_element<CharT> *t = src->next()) {
			if (t->rep) {
				if (!t->rep->children.empty()) {
					begin = t->rep->children.begin();
					end = t->rep->children.end();
					return &*begin++;
				}
			}
		}
		begin = end;
		return 0;
	}

	child_source *clone() const { return new child_source(src->clone(), begin, end); }
};

template<class CharT>
struct typefilter_source : element_source<CharT> {
	typedef std::auto_ptr<element_source<CharT> > esptr;
	typedef std::basic_string<CharT> string;

	const esptr src;
	const string type;

	typefilter_source(element_source<CharT> *es, const string &t)
		: src(es), type(t) {}

	basic_element<CharT> *next() {
		while (basic_element<CharT> *t = src->next())
			if (t->tag() == type)
				return t;
		return 0;
	}

	typefilter_source *clone() const { return new typefilter_source(src->clone(), type); }
};

template<class CharT>
struct childtype_source : element_source<CharT> {
	typedef std::basic_string<CharT> string;
	typedef std::auto_ptr<element_source<CharT> > esptr;
	typedef std::list<basic_element<CharT> > elist;
	typedef std::map<std::basic_string<CharT>, elist> emap;
	typedef typename emap::iterator emit;
	typedef typename elist::iterator elit;

	const esptr src;
	elit begin, end;
	const string type;

	childtype_source(element_source<CharT> *es, const string &t)
		: src(es), end(begin), type(t) {}
	childtype_source(element_source<CharT> *es, elit b, elit e, const string &t)
		: src(es), begin(b), end(e), type(t) {}

	basic_element<CharT> *next() {
		if (begin != end)
			return &*begin++;
		while (basic_element<CharT> *t = src->next()) {
			if (t->rep) {
				emit i = t->rep->childmap.find(type);
				if (i != t->rep->childmap.end()) {
					begin = i->second.begin();
					end = i->second.end();
					return &*begin++;
				}
			}
		}
		begin = end;
		return 0;
	}

	childtype_source *clone() const { return new childtype_source(src->clone(), begin, end, type); }
};

template<class CharT>
struct sibling_source : element_source<CharT> {
	typedef std::auto_ptr<element_source<CharT> > esptr;
	typedef std::list<basic_element<CharT> > elist;
	typedef typename elist::iterator elit;

	const esptr src;
	typedef std::pair<elit, elit> ipair;
	std::vector<ipair> istack;

	sibling_source(element_source<CharT> *es) : src(es) {}
	sibling_source(element_source<CharT> *es, const std::vector<ipair> &is) : src(es), istack(is) {}

	basic_element<CharT> *next() {
		// TODO: implement
		throw std::logic_error("sibling_source::next() not implemented");
		return 0;
	}

	sibling_source *clone() const { return new sibling_source(src->clone(), istack); }
};

} // namespace xml

#endif
