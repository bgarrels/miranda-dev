#include <iostream>
#include <exception>
#include <fstream>

#include <xml/document.h>

//using namespace xml;

typedef xml::basic_element<char> element;
typedef xml::basic_document<char> document;

inline void indent(int l) { while (l--) std::cout.put('\t'); }

void print(const element &e, int level = 0)
{
	indent(level);
	std::cout << '<' << e.tag() << ">: ";

	try {
		std::string d = e.data();
		std::cout << '[' << d << "] " << e.size() << "\n";
	} catch (std::exception &e) {
		std::cout << '!' << e.what() << "!\n";
	}

	for (element::const_iterator i = e.begin(); i; ++i) {
		print(*i, level+1);
	}
}

int main(int argc, char **argv)
try
{
	std::istream *stream = &std::cin;
	if (argc == 2)
		stream = new std::ifstream(argv[1]);
	document doc(*stream);

	element::attribute version = doc.xmldecl.attr("version");
	if (version)
		std::cout << *version << std::endl;

	print(doc.root);
	print(doc);

	std::cout << "***" << std::endl;
	for (element::iterator i = doc.find("scene/light"); i; ++i)
		std::cout << '<' << i->tag() << '>' << std::endl;
	std::cout << "***" << std::endl;

	element trr;
	element tr("testroot");
	trr.insert(tr);
	element tr2;
	tr2 = tr;
	{
		element t;
		{
			element tc("testchild");
			t = tc;
		}
		tr2.insert(t);
	}
	print(tr);
	print(trr);
}
catch (std::exception &e) {
	std::cerr << "exception: " << e.what() << std::endl;
	return 1;
}
