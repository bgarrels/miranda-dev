#include <xml/document_parser.h>

#include <xml/document.h>
#include <xml/stringutil.h>

namespace xml {

template<class CharT>
basic_document_parser<CharT>::basic_document_parser()
	: doc(0)
{
}

template<class CharT>
void basic_document_parser<CharT>::parse(std::basic_istream<CharT> &s, basic_document<CharT> &d)
{
	doc = &d;

	doc->basic_element<CharT>::operator=(basic_element<CharT>());
	doc->root = basic_element<CharT>();

	estack.clear();
	estack.push_back(*doc);

	basic_parser<CharT>::parse(s);

	if (doc->size() == 1)
		doc->root = *doc->begin();
}

template<class CharT>
void basic_document_parser<CharT>::processing_instruction()
{
	estack.push_back(basic_element<CharT>(strutil::to_t<CharT>("?pi")));
}

template<class CharT>
void basic_document_parser<CharT>::xml_declaration()
{
	estack.push_back(doc->xmldecl);
}

template<class CharT>
void basic_document_parser<CharT>::start_tag(const string &tag)
{
	basic_element<CharT> e(tag);
	estack.back().insert(e);
	estack.push_back(e);
}

template<class CharT>
void basic_document_parser<CharT>::end_tag()
{
	estack.pop_back();
}

template<class CharT>
void basic_document_parser<CharT>::attribute(const string &name, const string &val)
{
	estack.back().attr(name) = val;
}

template<class CharT>
void basic_document_parser<CharT>::content(const string &data)
{
	estack.back().insert_data(data);
}

template class basic_document_parser<char>;
template class basic_document_parser<wchar_t>;

} // namespace xml
