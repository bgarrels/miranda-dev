#include <xml/stringutil.h>

#include <stdexcept>

namespace xml {
namespace strutil {

void stringconv(basic_string<char> &d, const basic_string<wchar_t> &s)
{
	d.erase();

	const wchar_t *p = s.c_str();
	mbstate_t ps;
	memset(&ps, 0, sizeof ps);
	for (;;) {
		char buf[100];
		std::size_t n = wcsrtombs(buf, &p, sizeof buf-1, &ps);
		if (n == std::size_t(-1))
			throw std::runtime_error("invalid wide character encountered");
		d.append(buf, buf+n);
		if (!p)
			return;
	}
}

void stringconv(basic_string<wchar_t> &d, const basic_string<char> &s)
{
	d.erase();

	const char *p = s.c_str();
	mbstate_t ps;
	memset(&ps, 0, sizeof ps);
	for (;;) {
		wchar_t buf[100];
		std::size_t n = mbsrtowcs(buf, &p, (sizeof buf/sizeof buf[0])-1, &ps);
		if (n == std::size_t(-1))
			throw std::runtime_error("invalid multibyte character encountered");
		d.append(buf, buf+n);
		if (!p)
			return;
	}
}

} // namespace strutil
} // namespace xml
