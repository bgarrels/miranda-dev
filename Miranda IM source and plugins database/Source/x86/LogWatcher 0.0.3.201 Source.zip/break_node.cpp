#include "plugin.h"
#include "nodes.h"

break_node::break_node()
	: break_lvl(1)
{
}

void break_node::init(stringmap_t &defaults, const xml::welement &opt)
{
	cattr_t a = opt.attr(L"levels");
	if (!a || a.value().empty())
		lw_error(L"Attribute \"levels\" is required for <break>.");

	if (a.value() == L"all")
		break_lvl = 10000;
	else  {
		getattr(opt, L"levels", break_lvl);
		if (break_lvl < 0)
			lw_error(L"Invalid value for <break> attribute \"levels\".");
	}

	if (opt.begin())
		lw_error(L"<break> must be empty");
}

int break_node::handle(action_data_t &fi)
{
	return break_lvl;
}
