#ifndef LW_NODES_H
#define LW_NODES_H

#include "wnode.h"

#include <vector>
#include <string>

#include <boost/regex.hpp>

#include <xml/element.h>

typedef xml::welement::const_attribute cattr_t;
typedef xml::welement::const_iterator celit_t;

enum anchor_t {
	anchor_none = 0,
	anchor_left = 1,
	anchor_right = 2,
	anchor_both = 3
};

void make_regex(boost::wregex &re, const std::wstring &str, bool match_case, anchor_t anchor);

class block_node : public wnode {
protected:
	std::vector<wnode *> children;
public:
	virtual void init(stringmap_t &defaults, const xml::welement &);
	virtual int handle(action_data_t &);
};

class break_node : public wnode {
	int break_lvl;
public:
	break_node();

	virtual void init(stringmap_t &defaults, const xml::welement &);
	virtual int handle(action_data_t &);
};

class send_node : public wnode {
	std::wstring raw, type, from, text, fg, bg, icon, beep, id, replace, target;
	typedef std::map<std::wstring, std::wstring> opts_t;
	opts_t opts;
public:
	send_node();

	virtual void init(stringmap_t &defaults, const xml::welement &);
	virtual int handle(action_data_t &);
};

class set_node : public wnode {
	std::wstring var, value;
public:
	set_node();

	virtual void init(stringmap_t &defaults, const xml::welement &);
	virtual int handle(action_data_t &);
};

class match_node : public block_node {
	std::wstring input, pattern;
	bool match_case;
	anchor_t anchor;

	std::wstring last_regex_str;
	boost::wregex last_regex;
public:
	match_node();

	virtual void init(stringmap_t &defaults, const xml::welement &);
	virtual int handle(action_data_t &);
};

class switch_node : public wnode {
	std::map<std::wstring, wnode *> nodemap;
	wnode *defnode;
	std::wstring input;
	bool match_case;
public:
	switch_node();

	virtual void init(stringmap_t &defaults, const xml::welement &);
	virtual int handle(action_data_t &);
};

class loop_node : public block_node {
	int maxiter;
public:
	loop_node();

	virtual void init(stringmap_t &defaults, const xml::welement &);
	virtual int handle(action_data_t &);
};

#endif
