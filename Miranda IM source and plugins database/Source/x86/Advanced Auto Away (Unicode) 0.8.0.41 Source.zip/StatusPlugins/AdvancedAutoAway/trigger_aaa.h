#define TRIGGERNAME		"Auto-Away: State change"

#define SETTING_ENTERFIRST		"trigger_EnterFirst"
#define SETTING_ENTERSECOND		"trigger_EnterSecond"
#define SETTING_LEAVEFIRST		"trigger_LeaveFirst"
#define SETTING_LEAVESECOND		"trigger_LeaveSecond"
#define SETTING_BECOMEACTIVE	"trigger_BecomeActive"