Miranda Scripting Plugin (MSP - mBot)

please read docs/license.txt
please read docs/build.txt