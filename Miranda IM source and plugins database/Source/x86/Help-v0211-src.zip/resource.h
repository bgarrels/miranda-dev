//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_HELP                        101
#define IDD_SHADOW                      102
#define IDD_OPT_ADV                     103
#define IDD_OPT_LANG                    104
#define IDD_UPDATENOTIFY                105
#define IDD_DOWNLOADLANG                106
#define IDC_CTLTEXT                     1001
#define IDC_TEXT                        1002
#define IDC_CTLTYPE                     1003
#define IDC_CTLID                       1004
#define IDC_MODULE                      1005
#define IDC_DLGID                       1006
#define IDC_CARETSUCKER                 1007
#define IDC_AUTOTIPSENABLED             1010
#define IDC_AUTOTIPDELAY                1011
#define IDC_AUTOTIPDELAYSPIN            1012
#define IDC_LANGLIST                    1013
#define IDC_LANGINFOFRAME               1014
#define IDC_LANGAUTHORSLABEL            1015
#define IDC_LANGAUTHORS                 1016
#define IDC_LANGEMAILLABEL              1017
#define IDC_LANGEMAIL                   1018
#define IDC_LANGMODUSINGLABEL           1019
#define IDC_LANGMODUSING                1020
#define IDC_LANGDATELABEL               1021
#define IDC_LANGDATE                    1022
#define IDC_LANGVERSIONLABEL            1023
#define IDC_LANGVERSION                 1024
#define IDC_LANGLOCALELABEL             1025
#define IDC_LANGLOCALE                  1026
#define IDC_LANGNOTINCLUDEDLABEL        1027
#define IDC_LANGNOTINCLUDED             1028
#define IDC_MORELANG                    1029
#define IDC_NOPACK                      1030
#define IDC_ENABLEHELPUPDATES           1031
#define IDC_DOWNLOADLANG                1032
#define IDC_LANGCOMBO                   1033
#define IDC_DOWNLOADALL                 1035
#define IDC_LOADING                     1036
#define IDC_LANGUAGELABEL               1037
#define IDC_LANGUAGE                    1038
#define IDC_CURRENTVERSION              1039
#define IDC_NEWVERSION                  1040
#define IDC_NEWVERSIONLABEL             1041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           2001
#endif
#endif
