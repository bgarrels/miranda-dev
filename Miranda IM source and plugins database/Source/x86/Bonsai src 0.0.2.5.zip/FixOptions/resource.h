//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Bonsai.rc
//
#define IDD_FIXOPTIONS                  101
#define IDD_OPT_FIXOPTIONS              101
#define IDB_MODIFIED                    104
#define IDB_UNMODIFIED                  105
#define IDB_NEWLYMODIFIED               106
#define IDB_BITMAP1                     107
#define IDB_HIDDEN                      107
#define IDC_LIST_PLUGINS                1003
#define IDC_GROUP                       1004
#define IDC_TITLE                       1006
#define IDC_SAVE                        1007
#define IDC_CANCEL                      1008
#define IDC_BUTTON1                     1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
