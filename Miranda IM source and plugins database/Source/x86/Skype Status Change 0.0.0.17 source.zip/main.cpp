/*
	SkypeStatusChg

	Just a piece of code hacked together on October 31st 2004 to sync Online-status
	of Miranda-IM with Skype VoIP Solution (http://www.skype.com)
	You need the most current version of Skype (1.0.0.97) in order to have the
	Skype-API available.

    Feel free to improve this piece of junk, I was surprised that it really worked
    on the first attempt :D

    leecher@dose.0wnz.at

*/

#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <atlconv.h>

#include "../../include/newpluginapi.h"
// #include "../../include/m_clist.h"
// #include "../../include/m_skin.h"
// #include "../../include/m_system.h"
#include "../../include/m_utils.h"

#include "sdk/m_updater.h"
#include "../../include/m_protocols.h"
#include "../../include/m_protosvc.h"

PLUGINLINK* pluginLink = NULL;

namespace
{
	PLUGININFO Global_pluginInfo =
	{
		sizeof(PLUGININFO),
		"Change Skype Status",
		PLUGIN_MAKE_VERSION(0,0,0,9),
		"Changes Skype Status according to miranda-Status",
		"Dioksin",
		"dioksin@ua.fm",
		"Don't worry!",
		"http://www.miranda-im.org",
		UNICODE_AWARE,		//not transient
		0		//doesn't replace anything built-in
	};

	UINT g_MsgIDSkypeControlAPIAttach = 0;
	UINT g_MsgIDSkypeControlAPIDiscover = 0;
	HINSTANCE g_hModule = NULL;
	HWND g_wndMainWindow = NULL;
	bool g_bStopThread = false;
	HANDLE g_hThread = NULL;

	enum
	{
		SKYPECONTROLAPI_ATTACH_SUCCESS = 0,								// Client is successfully attached and API window handle can be found in wParam parameter
		SKYPECONTROLAPI_ATTACH_PENDING_AUTHORIZATION = 1,	// Skype has acknowledged connection request and is waiting for confirmation from the user.
		// The client is not yet attached and should wait for SKYPECONTROLAPI_ATTACH_SUCCESS message
		SKYPECONTROLAPI_ATTACH_REFUSED = 2,								// User has explicitly denied access to client
		SKYPECONTROLAPI_ATTACH_NOT_AVAILABLE = 3,					// API is not available at the moment. For example, this happens when no user is currently logged in.
		// Client should wait for SKYPECONTROLAPI_ATTACH_API_AVAILABLE broadcast before making any further
		// connection attempts.
		SKYPECONTROLAPI_ATTACH_API_AVAILABLE = 0x8001
	};

	LPCTSTR g_pszSkypeWndClassName = _T("SkypeHelperWindow{155198f0-8749-47b7-ac53-58f2ac70844c}");

	struct CMirandaStatus2SkypeStatus
	{
		int m_nMirandaStatus;
		LPCSTR m_pszSkypeStatus;
	};

	const CMirandaStatus2SkypeStatus g_aStatusCode[] = 
	{
		{ID_STATUS_AWAY, "AWAY"},
		{ID_STATUS_NA, "NA"},
		{ID_STATUS_DND, "DND"},
		{ID_STATUS_ONLINE, "ONLINE"},
		{ID_STATUS_FREECHAT, "ONLINE"},	// SKYPEME status doesn't work in Skype 4!
		{ID_STATUS_OFFLINE, "OFFLINE"},
		{ID_STATUS_INVISIBLE, "INVISIBLE"},
		{ID_STATUS_CONNECTING, "CONNECTING"},
		{ID_STATUS_OCCUPIED,"DND"}
	};

	const size_t g_cStatusCode = sizeof(g_aStatusCode)/sizeof(g_aStatusCode[0]);
	enum{INVALID_INDEX = 0xFFFFFFFF,};
	volatile LONG m_nCurStatusIndex = INVALID_INDEX;
}

namespace
{
	int SSC_OnProtocolAck(WPARAM/* wParam*/,LPARAM lParam)
	{
		ACKDATA* pAckData = reinterpret_cast<ACKDATA*>(lParam);

		if(ACKTYPE_STATUS == pAckData->type && ACKRESULT_SUCCESS == pAckData->result && pAckData->szModule)
		{
			int nStatus = CallProtoService(pAckData->szModule,PS_GETSTATUS,0,0);
			for(size_t i = 0;i < g_cStatusCode;++i)
			{
				const CMirandaStatus2SkypeStatus& ms = g_aStatusCode[i];
				if(ms.m_nMirandaStatus == nStatus)
				{
					InterlockedExchange(&m_nCurStatusIndex,i);
					if(0 == ::PostMessage(HWND_BROADCAST,g_MsgIDSkypeControlAPIDiscover,(WPARAM)g_wndMainWindow,0))
					{
						InterlockedExchange(&m_nCurStatusIndex,INVALID_INDEX);
					}
					break;
				}
			}

		}

		return 0;
	}

	void __cdecl ThreadFunc(void*) 
	{ 
		while(false == g_bStopThread)
		{
			MSG msg;
			if(TRUE == ::PeekMessage(&msg,g_wndMainWindow,0,0,PM_NOREMOVE))
			{
				while(::GetMessage(&msg,g_wndMainWindow,0,0)) 
				{ 
					TranslateMessage(&msg); 
					DispatchMessage(&msg); 
				} 
			}
			else
			{
				::Sleep(1000);
			}
		}

		g_bStopThread = false;
		return ; 
	}   

	LRESULT APIENTRY SkypeAPI_WindowProc(HWND hWnd,
										 UINT msg,
										 WPARAM wp,
										 LPARAM lp)
	{
		LRESULT lReturnCode = 0;
		bool bIssueDefProc = false;

		switch(msg)
		{
		case WM_DESTROY:
			g_wndMainWindow = NULL;
			break;
		case WM_COPYDATA:
// 			if( hGlobal_SkypeAPIWindowHandle==(HWND)uiParam )
// 			{
// 				PCOPYDATASTRUCT poCopyData=(PCOPYDATASTRUCT)ulParam;
// 				printf( "Message from Skype(%u): %.*s\n", poCopyData->dwData, poCopyData->cbData, poCopyData->lpData);
// 				lReturnCode=1;
// 			}
			break;
		default:
			if(msg == g_MsgIDSkypeControlAPIAttach)
			{
				switch(lp)
				{
				case SKYPECONTROLAPI_ATTACH_SUCCESS:
					{
						size_t nStatus = InterlockedExchange(&m_nCurStatusIndex,INVALID_INDEX);
						if(INVALID_INDEX != nStatus && nStatus < g_cStatusCode)
						{
							const CMirandaStatus2SkypeStatus& ms = g_aStatusCode[nStatus];
							HWND wndSkypeAPIWindow = reinterpret_cast<HWND>(wp);
							if(TRUE == ::IsWindow(wndSkypeAPIWindow))
							{
								enum{BUFFER_SIZE = 50};
								char szSkypeCmd[BUFFER_SIZE];
								::strncpy_s(szSkypeCmd,"SET USERSTATUS ",BUFFER_SIZE);
								::strcat_s(szSkypeCmd,ms.m_pszSkypeStatus);
								size_t cLength = strlen(szSkypeCmd);

								COPYDATASTRUCT oCopyData;

								oCopyData.dwData=0;
								oCopyData.lpData = szSkypeCmd;
								oCopyData.cbData = cLength+1;
								SendMessage(wndSkypeAPIWindow,WM_COPYDATA,(WPARAM)hWnd,(LPARAM)&oCopyData);
							}
						}
					}
					break;
				case SKYPECONTROLAPI_ATTACH_PENDING_AUTHORIZATION:
// 					printf("!!! Pending authorization\n");
					break;
				case SKYPECONTROLAPI_ATTACH_REFUSED:
// 					printf("!!! Connection refused\n");
					break;
				case SKYPECONTROLAPI_ATTACH_NOT_AVAILABLE:
// 					printf("!!! Skype API not available\n");
					break;
				case SKYPECONTROLAPI_ATTACH_API_AVAILABLE:
// 					printf("!!! Try connect now (API available); issue #connect\n");
					break;
				}
				lReturnCode=1;
			}
			else
			{
				bIssueDefProc = true;
			}
			break;
		}
		
		if(true == bIssueDefProc)
		{
			lReturnCode = DefWindowProc(hWnd, msg, wp, lp);
		}

		return(lReturnCode);
	}

	bool Init()
	{
		g_MsgIDSkypeControlAPIAttach = ::RegisterWindowMessage(_T("SkypeControlAPIAttach"));
		g_MsgIDSkypeControlAPIDiscover = ::RegisterWindowMessage(_T("SkypeControlAPIDiscover"));
		if((0 == g_MsgIDSkypeControlAPIAttach)|| (0 == g_MsgIDSkypeControlAPIDiscover))
		{
			return false;
		}

		WNDCLASS oWindowClass;
		oWindowClass.style = CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS;
		oWindowClass.lpfnWndProc = (WNDPROC)&SkypeAPI_WindowProc;
		oWindowClass.cbClsExtra = 0;
		oWindowClass.cbWndExtra = 0;
		oWindowClass.hInstance = g_hModule;
		oWindowClass.hIcon = NULL;
		oWindowClass.hCursor = NULL;
		oWindowClass.hbrBackground = NULL;
		oWindowClass.lpszMenuName = NULL;
		oWindowClass.lpszClassName = g_pszSkypeWndClassName;

		if(0 == RegisterClass(&oWindowClass))
		{
			return false;
		}

		g_wndMainWindow = CreateWindowEx( WS_EX_APPWINDOW|WS_EX_WINDOWEDGE,
			g_pszSkypeWndClassName,_T(""),
			WS_BORDER|WS_SYSMENU|WS_MINIMIZEBOX,
			CW_USEDEFAULT, CW_USEDEFAULT, 128, 128, NULL, 0, g_hModule, 0);
		
		return(NULL != g_wndMainWindow);
	}

	void CloseDoor()
	{
		if(NULL != g_wndMainWindow)
		{
			DestroyWindow(g_wndMainWindow);
			g_wndMainWindow = NULL;
		}

		UnregisterClass(g_pszSkypeWndClassName,g_hModule);
	}
}

/******************************* INSTALLATION PROCEDURES *****************************/


// DLL stuff

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	if(DLL_PROCESS_ATTACH == fdwReason)
	{
		g_hModule = hinstDLL;
	}

	return TRUE;
}

extern "C" __declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	return &Global_pluginInfo;
}

namespace
{
	HANDLE g_hEventProtocolAck = NULL;
	HANDLE g_hEventModulesLoaded = NULL;
	HANDLE g_hEventPreShutdown = NULL;

	int SSC_OnModulesLoaded(WPARAM/* wParam*/, LPARAM/* lParam*/) 
	{
		if(ServiceExists(MS_UPDATE_REGISTER)) 
		{
			Update update = {0};
			char szVersion[16];

			update.szComponentName = Global_pluginInfo.shortName;
			update.szVersionURL = "http://addons.miranda-im.org/details.php?action=viewfile&id=4003";
			update.pbVersionPrefix = (BYTE *)"<span class=\"fileNameHeader\">Change Skype Status ";
			update.cpbVersionPrefix = strlen((char *)update.pbVersionPrefix);
			update.szUpdateURL = "http://addons.miranda-im.org/feed.php?dlfile=4003";

			update.szBetaVersionURL = NULL;
			update.pbBetaVersionPrefix = NULL;
			update.cpbBetaVersionPrefix = 0;
			update.szBetaUpdateURL = NULL;

			update.pbVersion = (BYTE*)CreateVersionStringPlugin(&Global_pluginInfo,szVersion);
			update.cpbVersion = strlen((char *)update.pbVersion);

			update.szBetaChangelogURL = NULL;

			CallService(MS_UPDATE_REGISTER,0,(WPARAM)&update);
		}

		return 0;
	}

	int SSC_OnPreShutdown(WPARAM/* wParam*/, LPARAM/* lParam*/)
	{
		g_bStopThread = true;

		CloseDoor();

		return 0;
	}
}

extern "C" int __declspec(dllexport) Load(PLUGINLINK *link)
{
	pluginLink = link;
	if(false == Init())
	{
		return 1;
	}

	g_hThread = reinterpret_cast<HANDLE>(mir_forkthread(ThreadFunc,0));
	g_hEventProtocolAck = HookEvent(ME_PROTO_ACK,SSC_OnProtocolAck);
	g_hEventModulesLoaded = HookEvent(ME_SYSTEM_MODULESLOADED,SSC_OnModulesLoaded);
	g_hEventPreShutdown = HookEvent(ME_SYSTEM_PRESHUTDOWN,SSC_OnPreShutdown);
    return 0;
}

extern "C" __declspec(dllexport) int Unload(void)		// Executed on DLL unload
{
	UnhookEvent(g_hEventProtocolAck);
	UnhookEvent(g_hEventModulesLoaded);
	UnhookEvent(g_hEventPreShutdown);

	::WaitForSingleObject(g_hThread,INFINITE);

	return 0;
}
