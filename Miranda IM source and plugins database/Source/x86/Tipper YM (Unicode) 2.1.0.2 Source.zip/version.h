#define __FILEVERSION_STRING        2,1,0,2
#define __VERSION_STRING            "2.1.0.2"
#define __VERSION_DWORD             PLUGIN_MAKE_VERSION(2, 1, 0, 2)

