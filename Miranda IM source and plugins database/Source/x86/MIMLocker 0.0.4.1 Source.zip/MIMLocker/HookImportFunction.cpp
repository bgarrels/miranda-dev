/*
Original code by PJ Naughter.  
http://www.codeproject.com/dll/hookimport.asp

Modified by Messir
*/

#include "stdafx.h"
#include "HookImportFunction.h"

BOOL HookImportFunctionsByName(HMODULE hModule, LPCSTR szImportMod, UINT uiCount, LPHOOKFUNCDESC paHookArray)
{

	if (!szImportMod || 
		!uiCount || 
		IsBadReadPtr(paHookArray, sizeof(HOOKFUNCDESC) * uiCount) ||
		IsBadWritePtr(paHookArray, sizeof(HOOKFUNCDESC) * uiCount))
	{
	  SetLastErrorEx(ERROR_INVALID_PARAMETER, SLE_ERROR);
	  return FALSE;
	}

	if (!IsNT() && ((DWORD)hModule >= 0x80000000))
	{
		SetLastErrorEx(ERROR_INVALID_HANDLE, SLE_ERROR);
		return FALSE;
	}

	PIMAGE_IMPORT_DESCRIPTOR pImportDesc = GetNamedImportDescriptor(hModule, szImportMod);
	if (!pImportDesc) 
	{
		SetLastErrorEx(ERROR_INVALID_PARAMETER, SLE_ERROR);
		return FALSE;
	}

	PIMAGE_THUNK_DATA pOrigThunk = MakePtr(PIMAGE_THUNK_DATA, hModule, pImportDesc->OriginalFirstThunk);
	PIMAGE_THUNK_DATA pRealThunk = MakePtr(PIMAGE_THUNK_DATA, hModule, pImportDesc->FirstThunk);

	while (pOrigThunk->u1.Function)
	{
	    if (!(pOrigThunk->u1.Ordinal & IMAGE_ORDINAL_FLAG))
		{
			PIMAGE_IMPORT_BY_NAME pByName = MakePtr(PIMAGE_IMPORT_BY_NAME, hModule, pOrigThunk->u1.AddressOfData);

			if (_T('\0') != pByName->Name[0])
			{
				BOOL bDoHook = FALSE;
				UINT i;
				for (i = 0; i < uiCount; i++)
					if (paHookArray[i].szFunc[0] == pByName->Name[0] &&
						!strcmpi(paHookArray[i].szFunc, (char*)pByName->Name))
					{
						if (paHookArray[i].pProc) 
							bDoHook = TRUE;
						break;
					}

				if (bDoHook)
				{
					MEMORY_BASIC_INFORMATION mbi_thunk;
					VirtualQuery(pRealThunk, &mbi_thunk, sizeof(MEMORY_BASIC_INFORMATION));
					if (VirtualProtect(mbi_thunk.BaseAddress, mbi_thunk.RegionSize, PAGE_READWRITE, &mbi_thunk.Protect))
					{
						*(paHookArray[i].pOriginal) = (PROC)pRealThunk->u1.Function;
						pRealThunk->u1.Function = (DWORD)paHookArray[i].pProc;

						DWORD dwOldProtect;
						VirtualProtect(mbi_thunk.BaseAddress, mbi_thunk.RegionSize, mbi_thunk.Protect, &dwOldProtect);
					}
				}
			}
		}
		pOrigThunk++;
		pRealThunk++;
	}

	SetLastError(ERROR_SUCCESS);
	return TRUE;
}

PIMAGE_IMPORT_DESCRIPTOR GetNamedImportDescriptor(HMODULE hModule, LPCSTR szImportMod)
{
	if (!szImportMod || 
		!hModule)
	{
		SetLastErrorEx(ERROR_INVALID_PARAMETER, SLE_ERROR);
		return NULL;
	}

	PIMAGE_DOS_HEADER pDOSHeader = (PIMAGE_DOS_HEADER) hModule;
	
	if (IsBadReadPtr(pDOSHeader, sizeof(IMAGE_DOS_HEADER)) || 
		pDOSHeader->e_magic != IMAGE_DOS_SIGNATURE)
	{
		SetLastErrorEx(ERROR_INVALID_PARAMETER, SLE_ERROR);
		return NULL;
	}

	PIMAGE_NT_HEADERS pNTHeader = MakePtr(PIMAGE_NT_HEADERS, pDOSHeader, pDOSHeader->e_lfanew);

	if (IsBadReadPtr(pNTHeader, sizeof(IMAGE_NT_HEADERS)) || 
		pNTHeader->Signature != IMAGE_NT_SIGNATURE)
	{
		SetLastErrorEx(ERROR_INVALID_PARAMETER, SLE_ERROR);
		return NULL;
	}

	if (!pNTHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress)
		return NULL;

	PIMAGE_IMPORT_DESCRIPTOR pImportDesc = MakePtr(PIMAGE_IMPORT_DESCRIPTOR, pDOSHeader,
        pNTHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);

	while (pImportDesc->Name)
	{
		PSTR szCurrMod = MakePtr(PSTR, pDOSHeader, pImportDesc->Name);
		if (!stricmp(szCurrMod, szImportMod))
			break;
		pImportDesc++;
	}

	return (pImportDesc->Name) ? pImportDesc : NULL;
}

BOOL IsNT()
{
	OSVERSIONINFO info;
	memset(&info, NULL, sizeof(OSVERSIONINFO));
	info.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	if (GetVersionEx(&info))
		return VER_PLATFORM_WIN32_NT == info.dwPlatformId;
  
    MessageBox(0, _T("GetVersionEx failed!"), _T("Error"), MB_ICONERROR);
    return FALSE;
}
