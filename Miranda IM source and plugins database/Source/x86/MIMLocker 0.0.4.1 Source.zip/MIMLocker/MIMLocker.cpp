// InterfaceLock.cpp : Defines the entry point for the DLL application.
//
#include "stdafx.h"
#include "resource.h"
#include "MIMLocker.h"
#include "HookImportFunction.h"
#include "WindowList.h"

#define EXPORTS extern "C" __declspec(dllexport) 

HINSTANCE hInst;
PLUGINLINK *pluginLink;

// pointer to old tray message processor
TIPMPROC oldTrayIconProcessMessage = NULL;

// pointers to old Shell_NotifyIcon for both ANSI and Unicode
PShellNotifyIconA old_clist_ShellNotifyIconA = NULL;
PShellNotifyIconW old_clist_ShellNotifyIconW = NULL;
PShellNotifyIconA old_core_ShellNotifyIconA = NULL;
PShellNotifyIconW old_core_ShellNotifyIconW = NULL;

// list of created windows
WindowList openWindows;
// critical section to sync 
CRITICAL_SECTION sync;
// WinEvent hook to maintain 
HWINEVENTHOOK hwHook = NULL;
// hWnd for session events;
HWND hSessionWnd = NULL;
PWTSRegisterSessionNotification wtsRegisterSessionNotification = NULL; 
PWTSUnRegisterSessionNotification wtsUnRegisterSessionNotification = NULL; 

// locked-mode tray popup menu and bitmap for it
HMENU lockPopup = NULL;
HBITMAP unlockBmp = NULL;

PLUGININFO pluginInfo = 
{
	sizeof(PLUGININFO),
	PLUGIN_NAME,
	PLUGIN_VERSION,
	"Locks Miranda IM interface until password is entered",
	"Messir",
	"pieceofsummer@gmail.com",
	"� 2007 Messir",
	"http://pieceofsummer.livejournal.com",
	0,		//not transient
	0		//doesn't replace anything built-in
};

#pragma region Plugin entry

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID lpReserved)
{
	hInst = hModule;
    return TRUE;
}

EXPORTS PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	if (mirandaVersion < PLUGIN_MAKE_VERSION(0,5,0,0)) return NULL;
	return &pluginInfo;
}

BOOL CanWatchSession()
{
	OSVERSIONINFO info;
	info.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if (GetVersionEx(&info))
	{
		if (info.dwPlatformId != VER_PLATFORM_WIN32_NT) return FALSE;
		if (info.dwMajorVersion > 5) return TRUE;
		if (info.dwMajorVersion == 5)
			return (info.dwMinorVersion >= 1);
		return FALSE;
	}
	return FALSE;
}

INT_PTR CALLBACK WatchSessionProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_WTSSESSION_CHANGE)
	{
		if (wParam == WTS_SESSION_LOCK &&
			DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_WITH_SYSTEM, 0))
		{
			CallService(MS_MIMLOCK_LOCK, TRUE, NULL);
		}
	}

	WNDPROC	old = (WNDPROC)GetWindowLong(hwnd, GWL_USERDATA);
	if (old)
		return CallWindowProc(old, hwnd, uMsg, wParam, lParam);
	else
		return NULL;
}

EXPORTS int Load(PLUGINLINK *link)
{
	pluginLink = link;

	lockPopup = CreatePopupMenu();
	unlockBmp = IconToBitmap(hInst, MAKEINTRESOURCE(IDI_PROTECTED), GetSysColorBrush(COLOR_MENU));

	AppendMenu(lockPopup, 0, 0x31337, TranslateT(UNLOCK_STRING));
	//AppendMenu(lockPopup, 0, 0x31338, TranslateT("Temporary back-door"));
	SetMenuDefaultItem(lockPopup, 0x31337, FALSE);
	SetMenuItemBitmaps(lockPopup, 0x31337, MF_BYCOMMAND, unlockBmp, unlockBmp);

	InitializeCriticalSection(&sync);

	if (NULL == (hwHook = SetWinEventHook(EVENT_OBJECT_CREATE, EVENT_OBJECT_REORDER, 
							 NULL, WinEventProc, GetCurrentProcessId(), 0, 0)))
	{
		MessageBox(0, TranslateT("Failed to set hook"), _T(PLUGIN_NAME), MB_ICONERROR);
		return 1;
	}

	if (CanWatchSession())
	{
		hSessionWnd = CreateWindowEx(0, _T("STATIC"), NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL);
		if (hSessionWnd)
		{
			SetWindowLongPtr(hSessionWnd, GWL_USERDATA, GetWindowLongPtr(hSessionWnd, GWL_WNDPROC));
			SetWindowLongPtr(hSessionWnd, GWL_WNDPROC, (LONG)WatchSessionProc);

			HMODULE hWTS = LoadLibrary(_T("wtsapi32.dll"));
			if (hWTS)
			{
				wtsRegisterSessionNotification = (PWTSRegisterSessionNotification)GetProcAddress(hWTS, "WTSRegisterSessionNotification");
				if (wtsRegisterSessionNotification)
				{
					wtsUnRegisterSessionNotification = (PWTSUnRegisterSessionNotification)GetProcAddress(hWTS, "WTSUnRegisterSessionNotification");
					if (!wtsRegisterSessionNotification(hSessionWnd, 0))
					{
						// failure
						DestroyWindow(hSessionWnd);
						hSessionWnd = NULL;
					}
				}
			}
		}
	}

	CreateServiceFunction(MS_MIMLOCK_LOCK, LockCommand);
	CreateServiceFunction(MS_MIMLOCK_UNLOCK, UnlockCommand);

	CLISTMENUITEM menu;
	memset(&menu, 0, sizeof(CLISTMENUITEM));
	menu.cbSize = sizeof(CLISTMENUITEM);
	menu.position = -1;
	menu.flags = 0;
	menu.pszName = Translate(LOCK_STRING);
	menu.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_LOCK));
	menu.pszService = MS_MIMLOCK_LOCK;
	CallService(MS_CLIST_ADDMAINMENUITEM, NULL, (LPARAM)&menu);

	InitializeSettings();

	InitializeTopToolbar();

	CLIST_INTERFACE *pcli = (CLIST_INTERFACE *)CallService(MS_CLIST_RETRIEVE_INTERFACE, 0, (LPARAM)hInst);
	if ((int)pcli == CALLSERVICE_NOTFOUND || pcli->version < 3) 
	{
		MessageBox(NULL, TranslateT("Failed to find any CList plugin"), _T(PLUGIN_NAME), MB_ICONERROR);
		return 1;
	}

	oldTrayIconProcessMessage = pcli->pfnTrayIconProcessMessage;
	pcli->pfnTrayIconProcessMessage = TrayIconProcessMessage;

	HOOKFUNCDESC hookClist[] = { { "Shell_NotifyIconA", (PROC)clist_ShellNotifyIconA, (PROC*)&old_clist_ShellNotifyIconA }, 
								 { "Shell_NotifyIconW", (PROC)clist_ShellNotifyIconW, (PROC*)&old_clist_ShellNotifyIconW } };
	HOOKFUNCDESC hookCore[]  = { { "Shell_NotifyIconA", (PROC)core_ShellNotifyIconA, (PROC*)&old_core_ShellNotifyIconA }, 
								 { "Shell_NotifyIconW", (PROC)core_ShellNotifyIconW, (PROC*)&old_core_ShellNotifyIconW } };

	if (!HookImportFunctionsByName(pcli->hInst, "shell32.dll", 2, &hookClist[0]))
	{
		//MessageBox(0, TranslateT("Failed to hook API. Some features shall be disabled."), _T(PLUGIN_NAME), MB_ICONEXCLAMATION);
	}

	if (!HookImportFunctionsByName(GetModuleHandle(NULL), "shell32.dll", 2, &hookCore[0]))
	{
		//MessageBox(0, TranslateT("Failed to hook API. Some features shall be disabled."), _T(PLUGIN_NAME), MB_ICONEXCLAMATION);
	}

	return 0;
}

EXPORTS int Unload()
{
	if (hwHook)
	{
		UnhookWinEvent(hwHook);
		hwHook = NULL;
	}

	CLIST_INTERFACE *pcli = (CLIST_INTERFACE *)CallService(MS_CLIST_RETRIEVE_INTERFACE, 0, (LPARAM)hInst);
	if ((int)pcli != CALLSERVICE_NOTFOUND && pcli->version >= 3) 
	{
		if (oldTrayIconProcessMessage)
			pcli->pfnTrayIconProcessMessage = oldTrayIconProcessMessage;
	}
	oldTrayIconProcessMessage = NULL;

	if (lockPopup)
	{
		DestroyMenu(lockPopup);
		lockPopup = NULL;
	}

	if (unlockBmp)
	{
		DeleteObject(unlockBmp);
		unlockBmp = NULL;
	}

	if (hSessionWnd && wtsUnRegisterSessionNotification)
	{
		wtsUnRegisterSessionNotification(hSessionWnd);
	}

	if (hSessionWnd)
	{
		DestroyWindow(hSessionWnd);
		hSessionWnd = NULL;
	}

	return 0;
}

#pragma endregion

#pragma region Lock and Unlock service functions

static int LockCommand(WPARAM wParam, LPARAM lParam)
{
	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCKED, 0))
		return 0;

	DBVARIANT dbv = {0};
	if (DBGetContactSettingTString(NULL, PLUGIN_NAME, SETTING_PASSWORD, &dbv))
	{
		if (!wParam)
			MessageBox(0, TranslateT("Password was not set"), _T(PLUGIN_NAME), MB_ICONEXCLAMATION);
		return 1;
	}
	DBFreeVariant(&dbv);

	CLIST_INTERFACE *pcli = (CLIST_INTERFACE *)CallService(MS_CLIST_RETRIEVE_INTERFACE, 0, (LPARAM)hInst);
	if ((int)pcli == CALLSERVICE_NOTFOUND || pcli->version < 3) 
	{
		if (!wParam)
			MessageBox(NULL, TranslateT("Failed to find any CList plugin"), _T(PLUGIN_NAME), MB_ICONERROR);
		return 1;
	}

	EnterCriticalSection(&sync);

	if (pcli->pfnTrayIconProcessMessage != TrayIconProcessMessage)
	{
		oldTrayIconProcessMessage = pcli->pfnTrayIconProcessMessage;
		pcli->pfnTrayIconProcessMessage = TrayIconProcessMessage;
	}

	DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCKED, 1);
	ShowWindow(pcli->hwndContactList, SW_HIDE);

	openWindows.HideAll();

	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_DISABLE_POPUPS, 1) &&
		ServiceExists(MS_POPUP_QUERY))
	{
		BOOL enabled = CallService(MS_POPUP_QUERY, PUQS_GETSTATUS, 0);
		DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_POPUPS, enabled);
		CallService(MS_POPUP_QUERY, PUQS_DISABLEPOPUPS, 0);
	}

	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_DISABLE_SOUNDS, 1))
	{
		BOOL sounds = DBGetContactSettingByte(NULL, "Skin", "UseSound", 1);
		DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_SOUNDS, sounds);
	}

	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_ICONS, 1))
		pcli->pfnTrayIconIconsChanged();

	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_CHANGE_STATUS, 0))
	{
		int statuses[] = {  ID_STATUS_OFFLINE, 
							ID_STATUS_ONLINE, 
							ID_STATUS_AWAY, 
							ID_STATUS_DND, 
							ID_STATUS_NA, 
							ID_STATUS_OCCUPIED, 
							ID_STATUS_FREECHAT, 
							ID_STATUS_INVISIBLE };

		int status = DBGetContactSettingDword(NULL, PLUGIN_NAME, SETTING_LOCKED_STATUS, -1);
		if (status >= 0 && status < sizeof(statuses) / sizeof(int))
		{
			int oldStatus = CallService(MS_CLIST_GETSTATUSMODE, NULL, NULL);
			DBWriteContactSettingDword(NULL, PLUGIN_NAME, SETTING_STATUS, oldStatus);
			CallService(MS_CLIST_SETSTATUSMODE, statuses[status], NULL);
			//MessageBox(0, _T("status changed"), NULL, NULL);
		}
	}

	LeaveCriticalSection(&sync);

	return 0;
}

static int UnlockCommand(WPARAM wParam, LPARAM lParam)
{
	if (!DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCKED, 0))
		return 0;

	if (!wParam)
	{
		if (!ShowUnlockDialog()) return 1;
	}

	EnterCriticalSection(&sync);

	DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCKED, 0);

	CLIST_INTERFACE *pcli = (CLIST_INTERFACE *)CallService(MS_CLIST_RETRIEVE_INTERFACE, 0, (LPARAM)hInst);
	if ((int)pcli == CALLSERVICE_NOTFOUND || pcli->version < 3) 
		pcli = NULL;

	if (pcli)
		ShowWindow(pcli->hwndContactList, SW_SHOW);

	openWindows.ShowAll();

	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_DISABLE_POPUPS, 1) && 
		ServiceExists(MS_POPUP_QUERY))
	{
		BOOL enabled = DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_POPUPS, TRUE);
		CallService(MS_POPUP_QUERY, (enabled) ? PUQS_ENABLEPOPUPS : PUQS_DISABLEPOPUPS, 0);
	}

	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_DISABLE_SOUNDS, 1))
	{
		BOOL sounds = DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_SOUNDS, 1);
		DBWriteContactSettingByte(NULL, "Skin", "UseSound", sounds);
	}

	if (pcli && DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_ICONS, 1))
		pcli->pfnTrayIconIconsChanged();

	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_CHANGE_STATUS, 0) &&
		DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_RESTORE_STATUS, 1))
	{
		int status = DBGetContactSettingDword(NULL, PLUGIN_NAME, SETTING_STATUS, 0);
		if (status)
			CallService(MS_CLIST_SETSTATUSMODE, status, NULL);
	}

	LeaveCriticalSection(&sync);

	return 0;
}

#pragma endregion

// Window validator
BOOL IsValidWindow(HWND hwnd)
{
	if (GetParent(hwnd)) return FALSE;

	DWORD pId;
	GetWindowThreadProcessId(hwnd, &pId);
	if (pId != GetCurrentProcessId()) return FALSE;

	// just a workaround for Unlock dialog ;)
	if (SendMessage(hwnd, WM_USER + 0x31337, 0, 0) == 0x31337) return FALSE;

	TCHAR cname[MAX_PATH + 1];
	if (GetClassName(hwnd, cname, MAX_PATH) && !_tcscmp(cname, _T(MIRANDACLASS))) return TRUE;

	DWORD style = GetWindowLong(hwnd, GWL_STYLE);
	if (!(style & WS_SYSMENU)) return FALSE;

	return (GetWindow(hwnd, GW_CHILD) != NULL);
}


// Window creation and deletion hook
VOID CALLBACK WinEventProc(HWINEVENTHOOK hwHook, DWORD evt, HWND hwnd, LONG idObject, LONG idChild, DWORD dwEventThread, DWORD dwmsEventTime)
{
	if (idObject == OBJID_WINDOW)
	{
		switch (evt)
		{
		case EVENT_OBJECT_CREATE:

			if (IsValidWindow(hwnd))
			{
				EnterCriticalSection(&sync);

				openWindows.Add(hwnd);

				LeaveCriticalSection(&sync);
			}

			break;
		case EVENT_OBJECT_DESTROY:

			EnterCriticalSection(&sync);

			openWindows.Remove(hwnd);

			LeaveCriticalSection(&sync);

			break;
		case EVENT_OBJECT_SHOW:

			if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCKED, 0))
			{
				EnterCriticalSection(&sync);
				
				openWindows.HideSpecifiedWindow(hwnd);

				LeaveCriticalSection(&sync);
			}

			break;
		}

	}
}

// Tray icons interceptor
static int TrayIconProcessMessage(WPARAM wParam, LPARAM lParam)
{
	MSG *msg = (MSG*)wParam;
	if (DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCKED, 0))
	{
		if (msg->message == TIM_CALLBACK)
		{
			if (msg->lParam == WM_LBUTTONDBLCLK)
			{
				CallService(MS_MIMLOCK_UNLOCK, 0, 0);
			}
			else if (msg->lParam == WM_RBUTTONDOWN || msg->lParam == WM_RBUTTONUP)
			{
				if (lockPopup)
				{
					POINT pt;
					GetCursorPos(&pt);
					int mnu = (int)TrackPopupMenu(lockPopup, 
						   TPM_NONOTIFY | TPM_RETURNCMD | TPM_BOTTOMALIGN | TPM_RIGHTALIGN | TPM_VERNEGANIMATION, 
						   pt.x, pt.y, 0, msg->hwnd, NULL);
				
					if (mnu == 0x31337)
					{
						CallService(MS_MIMLOCK_UNLOCK, 0, 0);
					}
					else if (mnu == 0x31338)
					{
						CallService(MS_MIMLOCK_UNLOCK, TRUE, 0);
					}
				}
			}
			else if (msg->lParam == WM_MOUSEMOVE)
			{
				if (ServiceExists("mToolTip/HideTip"))
					CallService("mToolTip/HideTip", 0, 0);
			}
			*((LRESULT *)lParam) = 0;
			return TRUE;
		}
	}
	return (oldTrayIconProcessMessage) ? oldTrayIconProcessMessage(wParam, lParam) : FALSE;
}

#pragma region Shell_NotifyIcon API hook

BOOL NeedToChangeIcon(DWORD dwMessage)
{
	return ((dwMessage == NIM_ADD || dwMessage == NIM_MODIFY) &&
			DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCKED, 0) &&
			DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_ICONS, 1));
}

BOOL ShellNotifyIconAImpl(DWORD dwMessage, PNOTIFYICONDATAA lpdata, PShellNotifyIconA oldProc)
{
	if (NeedToChangeIcon(dwMessage))
		lpdata->hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_LOCK));

	if (oldProc)
		return oldProc(dwMessage, lpdata);
	else
		return FALSE;
}

BOOL ShellNotifyIconWImpl(DWORD dwMessage, PNOTIFYICONDATAW lpdata, PShellNotifyIconW oldProc)
{
	if (NeedToChangeIcon(dwMessage))
		lpdata->hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_LOCK));

	if (oldProc)
		return oldProc(dwMessage, lpdata);
	else
		return FALSE;
}

BOOL WINAPI clist_ShellNotifyIconA(DWORD dwMessage, PNOTIFYICONDATAA lpdata)
{
	return ShellNotifyIconAImpl(dwMessage, lpdata, old_clist_ShellNotifyIconA);
}

BOOL WINAPI clist_ShellNotifyIconW(DWORD dwMessage, PNOTIFYICONDATAW lpdata)
{
	return ShellNotifyIconWImpl(dwMessage, lpdata, old_clist_ShellNotifyIconW);
}

BOOL WINAPI core_ShellNotifyIconA(DWORD dwMessage, PNOTIFYICONDATAA lpdata)
{
	return ShellNotifyIconAImpl(dwMessage, lpdata, old_core_ShellNotifyIconA);
}

BOOL WINAPI core_ShellNotifyIconW(DWORD dwMessage, PNOTIFYICONDATAW lpdata)
{
	return ShellNotifyIconWImpl(dwMessage, lpdata, old_core_ShellNotifyIconW);
}

#pragma endregion