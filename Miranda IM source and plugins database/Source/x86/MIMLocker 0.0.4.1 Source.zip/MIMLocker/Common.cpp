#include "stdafx.h"
#include "MIMLocker.h"

void EncodeTString(int cbSize, LPTSTR str)
{
#ifdef UNICODE
	HANDLE heap = GetProcessHeap();
	char *tbuff = (char *)HeapAlloc(heap, HEAP_ZERO_MEMORY, cbSize * 2);
	WideCharToMultiByte(CP_UTF8, 0, str, -1, tbuff, cbSize * 2, NULL, NULL);
	CallService(MS_DB_CRYPT_ENCODESTRING, cbSize * 2, (LPARAM)tbuff);
	MultiByteToWideChar(CP_UTF8, 0, tbuff, -1, str, cbSize);
	HeapFree(heap, 0, tbuff);
#else
	CallService(MS_DB_CRYPT_ENCODESTRING, cbSize, (LPARAM)str);
#endif
}

void DecodeTString(int cbSize, LPTSTR str)
{
#ifdef UNICODE
	HANDLE heap = GetProcessHeap();
	char *tbuff = (char *)HeapAlloc(heap, HEAP_ZERO_MEMORY, cbSize * 2);
	WideCharToMultiByte(CP_UTF8, 0, str, -1, tbuff, cbSize * 2, NULL, NULL);
	CallService(MS_DB_CRYPT_DECODESTRING, cbSize * 2, (LPARAM)tbuff);
	MultiByteToWideChar(CP_UTF8, 0, tbuff, -1, str, cbSize);
	HeapFree(heap, 0, tbuff);
#else
	CallService(MS_DB_CRYPT_ENCODESTRING, cbSize, (LPARAM)str);
#endif
}

void WriteDebug(LPCTSTR string)
{
#ifdef DEBUG
	OutputDebugString(string);
#endif
}

HBITMAP IconToBitmap(HINSTANCE hInst, LPCTSTR icon, HBRUSH bkgrnd)
{
	HDC hdc = CreateCompatibleDC(GetDC(0));
	HBITMAP bmp = CreateCompatibleBitmap(GetDC(0), 16, 16);
	SelectObject(hdc, bmp);
	if (bkgrnd)
	{
		RECT rc = {0, 0, 16, 16 };
		FillRect(hdc, &rc, bkgrnd);
	}
	HICON ico = (HICON)LoadImage(hInst, icon, IMAGE_ICON, 16, 16, NULL);
	DrawIconEx(hdc, 0, 0, ico, 16, 16, 0, NULL, DI_NORMAL);
	DestroyIcon(ico);
	DeleteDC(hdc);
	return bmp;
}