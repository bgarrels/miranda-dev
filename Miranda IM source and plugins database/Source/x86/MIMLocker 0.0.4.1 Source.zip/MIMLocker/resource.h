//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MIMLocker.rc
//
#define IDD_UNLOCK                      102
#define IDI_PROTECTED                   103
#define IDD_SETTINGS                    104
#define IDD_CHANGEPASS                  105
#define IDI_LOCK                        106
#define IDC_PASSWORD                    1001
#define IDC_PROMPT                      1002
#define IDC_OLDPASSWORD                 1002
#define IDC_CONFIRMPROMPT               1004
#define IDC_LANG                        1005
#define IDC_PASSWORDPROMPT              1005
#define IDC_DISABLE_SOUNDS              1006
#define IDC_OLDPASSWORDPROMPT           1006
#define IDC_FEATURES                    1007
#define IDC_DISABLE_POPUPS              1008
#define IDC_LOCK_ICONS                  1009
#define IDC_CONFIRM                     1010
#define IDC_CHANGE_STATUS               1010
#define IDC_SETPASSWORD                 1011
#define IDC_LOCKED_STATUS               1012
#define IDC_CHANGE_STATUS_BACK_ON_UNLOCK 1013
#define IDC_CHECK1                      1014
#define IDC_LOCK_WITH_SYSTEM            1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
