#include "stdafx.h"
#include "resource.h"
#include "MIMLocker.h"

#ifdef TOPTOOLBARBUTTON
#include "../include/m_toptoolbar.h"
#endif

extern HINSTANCE hInst;

int InitializeTopToolbar()
{
	HookEvent(ME_SYSTEM_MODULESLOADED, ModulesLoadedCallback);
	return 0;
}

static int ModulesLoadedCallback(WPARAM wParam, LPARAM lParam)
{
#ifdef TOPTOOLBARBUTTON
	HookEvent(ME_TTB_MODULELOADED, AddTopToolbarButtonCallback);
#endif
	return 0;
}

static int AddTopToolbarButtonCallback(WPARAM wParam, LPARAM lParam)
{
#ifdef TOPTOOLBARBUTTON
#ifdef TOPTOOLBARBUTTONV2
	TTBButtonV2 button;
#else
	TTBButton button;
#endif
	memset(&button, 0, sizeof(button));
	button.cbSize = sizeof(button);
	button.name = Translate(LOCK_STRING);
	button.pszServiceDown = button.pszServiceUp = MS_MIMLOCK_LOCK;
	button.dwFlags = TTBBF_VISIBLE | TTBBF_SHOWTOOLTIP;
#ifdef TOPTOOLBARBUTTONV2
	button.hIconDn = button.hIconUp = LoadIcon(hInst, MAKEINTRESOURCE(IDI_LOCK));
	button.tooltipDn = button.tooltipUp = button.name;
#else
	button.hbBitmapDown = button.hbBitmapUp = 
		IconToBitmap(hInst, MAKEINTRESOURCE(IDI_LOCK), GetSysColorBrush(COLOR_BTNFACE));
#endif
	CallService(MS_TTB_ADDBUTTON, (WPARAM)&button, NULL);
#endif
	return 0;
}