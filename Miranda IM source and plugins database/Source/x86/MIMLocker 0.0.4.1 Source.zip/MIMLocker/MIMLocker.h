#define PLUGIN_NAME "MIMLocker"
#define PLUGIN_VERSION PLUGIN_MAKE_VERSION(0,0,4,1)
#define MS_MIMLOCK_LOCK PLUGIN_NAME "/Lock"
#define MS_MIMLOCK_UNLOCK PLUGIN_NAME "/Unlock"

#define LOCK_STRING "Lock"
#define UNLOCK_STRING "Unlock"

#define SETTING_LOCKED "Locked"
#define SETTING_PASSWORD "Password"
#define SETTING_DISABLE_SOUNDS "DisableSounds"
#define SETTING_DISABLE_POPUPS "DisablePopups"
#define SETTING_LOCK_ICONS "LockIcons"
#define SETTING_CHANGE_STATUS "ChangeStatus"
#define SETTING_LOCKED_STATUS "LockedStatus"
#define SETTING_RESTORE_STATUS "RestoreStatus"
#define SETTING_LOCK_WITH_SYSTEM "LockWithSystem"

#define SETTING_POPUPS "savedPopups"
#define SETTING_SOUNDS "savedSounds"
#define SETTING_STATUS "savedStatus"

#define TOPTOOLBARBUTTON		// Enable TopToolBar support
#define TOPTOOLBARBUTTONV2		// use v2 buttons, valid only if TOPTOOLBARBUTTON is defined

#define TIM_CALLBACK   (WM_USER+1857)
#define PSN_APPLY	(-202)
#define PSM_CHANGED	(WM_USER+104)

/* Hook methods' prototypes */

typedef int (*TIPMPROC)(WPARAM wParam, LPARAM lParam);
typedef BOOL (WINAPI *PShellNotifyIconA)(DWORD dwMessage, PNOTIFYICONDATAA lpdata);
typedef BOOL (WINAPI *PShellNotifyIconW)(DWORD dwMessage, PNOTIFYICONDATAW lpdata);

/* WTS Notify prototypes */

typedef BOOL (WINAPI *PWTSRegisterSessionNotification)(HWND hWnd, DWORD dwFlags);
typedef BOOL (WINAPI *PWTSUnRegisterSessionNotification)(HWND hWnd);

/* InterfaceLock.cpp */

BOOL CanWatchSession();

// wParam - silent mode
// lParam - not used
static int LockCommand(WPARAM wParam, LPARAM lParam);

// wParam - silent mode with no password needed
// lParam - not used
static int UnlockCommand(WPARAM wParam, LPARAM lParam);

VOID CALLBACK WinEventProc(HWINEVENTHOOK hWinEventHook, DWORD evt, HWND hwnd, 
						   LONG idObject, LONG idChild, DWORD dwEventThread, DWORD dwmsEventTime);

static int TrayIconProcessMessage(WPARAM wParam, LPARAM lParam);

BOOL NeedToChangeIcon(DWORD dwMessage);
BOOL WINAPI clist_ShellNotifyIconA(DWORD dwMessage, PNOTIFYICONDATAA lpdata);
BOOL WINAPI clist_ShellNotifyIconW(DWORD dwMessage, PNOTIFYICONDATAW lpdata);
BOOL WINAPI core_ShellNotifyIconA(DWORD dwMessage, PNOTIFYICONDATAA lpdata);
BOOL WINAPI core_ShellNotifyIconW(DWORD dwMessage, PNOTIFYICONDATAW lpdata);

/* Common.cpp */
void WriteDebug(LPCTSTR string);
void EncodeTString(int cbSize, LPTSTR str);
void DecodeTString(int cbSize, LPTSTR str);
HBITMAP IconToBitmap(HINSTANCE hInst, LPCTSTR icon, HBRUSH bkgrnd);

/* UnlockDialog.cpp */
BOOL ShowUnlockDialog();
INT_PTR CALLBACK UnlockProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK PasswordProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void LanguageChanged(HWND hwndDlg, WPARAM wParam, LPARAM lParam);

/* SettingsDialog.cpp */

int InitializeSettings();
static int InitializeSettingsCallback(WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK SettingsProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK ChangePassProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

/* TopToolbar.cpp */

int InitializeTopToolbar();
static int ModulesLoadedCallback(WPARAM wParam, LPARAM lParam);
static int AddTopToolbarButtonCallback(WPARAM wParam, LPARAM lParam);
