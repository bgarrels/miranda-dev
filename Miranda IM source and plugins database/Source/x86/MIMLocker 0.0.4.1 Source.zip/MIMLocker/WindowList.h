//#include "stdafx.h"

#pragma once

typedef struct tag_WNDLISTITEM
{
	HWND hWnd;
	tag_WNDLISTITEM *next;
} WNDLISTITEM, *PWNDLISTITEM;

typedef BOOL (*FOREACHCALLBACK)(HWND hWnd, LPARAM param);

class WindowList
{
public:
	WindowList()
	{
		root = NULL;
	}

	void Add(HWND hWnd)
	{
		PWNDLISTITEM item = new WNDLISTITEM();
		item->hWnd = hWnd;
		item->next = root;
		root = item;
	}

	void Remove(HWND hWnd)
	{
		PWNDLISTITEM item = root;
		PWNDLISTITEM prev = NULL;
		while (item)
		{
			if (item->hWnd == hWnd)
			{
				if (prev)
					prev->next = item->next;
				else
					root = item->next;
				delete item;
				break;
			}
			prev = item;
			item = item->next;
		}
	}

	void ForEach(FOREACHCALLBACK callback, LPARAM param)
	{
		PWNDLISTITEM item = root;
		while (item)
		{
			if (!callback(item->hWnd, param)) break;
			item = item->next;
		}		
	}

	void HideAll()
	{
		ForEach(HideCallback, NULL);
	}

	void ShowAll()
	{
		ForEach(ShowCallback, NULL);
	}

	void HideSpecifiedWindow(HWND hWnd)
	{
		ForEach(HideSpecifiedCallback, (LPARAM)hWnd);
	}

	~WindowList()
	{
		PWNDLISTITEM item = root;
		PWNDLISTITEM next = NULL;
		while (item)
		{
			next = item->next;
			delete item;
			item = next;
		}
	}

private:
	PWNDLISTITEM root;

	static BOOL HideCallback(HWND hWnd, LPARAM param)
	{
		if (IsWindow(hWnd))
			ShowWindow(hWnd, SW_HIDE);
		return TRUE;
	}

	static BOOL ShowCallback(HWND hWnd, LPARAM param)
	{
		if (IsWindow(hWnd))
			ShowWindow(hWnd, SW_SHOW);
		return TRUE;
	}

	static BOOL HideSpecifiedCallback(HWND hWnd, LPARAM param)
	{
		if (hWnd == (HWND)param)
		{
			HideCallback(hWnd, NULL);
			return FALSE;
		}
		return TRUE;
	}

};