/*
Original code by PJ Naughter.  
http://www.codeproject.com/dll/hookimport.asp

Modified by Messir
*/

#pragma once

#define MakePtr(cast, ptr, AddValue) (cast)((DWORD)(ptr)+(DWORD)(AddValue))

typedef struct {
	LPCSTR szFunc;
	PROC pProc;
	PROC *pOriginal;
} HOOKFUNCDESC, *LPHOOKFUNCDESC;

PIMAGE_IMPORT_DESCRIPTOR GetNamedImportDescriptor(HMODULE hModule, LPCSTR szImportMod);
BOOL HookImportFunctionsByName(HMODULE hModule, LPCSTR szImportMod, UINT uiCount, LPHOOKFUNCDESC paHookArray);
BOOL IsNT();
