#include "stdafx.h"
#include "MIMLocker.h"
#include "resource.h"

extern HINSTANCE hInst;

BOOL ShowUnlockDialog()
{
	return (DialogBox(hInst, MAKEINTRESOURCE(IDD_UNLOCK), NULL, UnlockProc) == IDOK);
}

INT_PTR CALLBACK UnlockProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
			SetWindowText(hwndDlg, TranslateT("Unlock"));
			SetDlgItemText(hwndDlg, IDC_PROMPT, TranslateT("Miranda IM is locked. Please enter password to unlock it."));
			SetWindowLongPtr(hwndDlg, GWL_USERDATA, 3);

			HWND hwnd = GetDlgItem(hwndDlg, IDC_PASSWORD);
			SetWindowLongPtr(hwnd, GWL_USERDATA, SetWindowLongPtr(hwnd, GWL_WNDPROC, (LONG)PasswordProc));

			LanguageChanged(hwndDlg, 0, (LPARAM)GetKeyboardLayout(0));

			return TRUE;
		}
	case WM_COMMAND:
		{
			if (LOWORD(wParam) == IDOK)
			{
				TCHAR str[MAX_PATH + 1];

				if (!GetDlgItemText(hwndDlg, IDC_PASSWORD, str, MAX_PATH))
				{
					MessageBeep(MB_ICONASTERISK);
					return TRUE;
				}
				
				EncodeTString(MAX_PATH, str);

				DBVARIANT dbv = {0};

				if (!DBGetContactSettingTString(NULL, PLUGIN_NAME, SETTING_PASSWORD, &dbv))
				{
					bool match = (dbv.ptszVal && !_tcscmp(dbv.ptszVal, str));
					DBFreeVariant(&dbv);
					if (match)
						EndDialog(hwndDlg, IDOK);
					else
					{
						MessageBox(hwndDlg, TranslateT("Password is incorrect."), _T(PLUGIN_NAME), MB_ICONEXCLAMATION);
						HWND edit = GetDlgItem(hwndDlg, IDC_PASSWORD);
						SetFocus(edit);
						SendMessage(edit, EM_SETSEL, 0, -1);

						LONG left = GetWindowLongPtr(hwndDlg, GWL_USERDATA);
						if (--left)
							SetWindowLongPtr(hwndDlg, GWL_USERDATA, left);
						else
							EndDialog(hwndDlg, IDCANCEL);
					}
				}
				else
					EndDialog(hwndDlg, IDOK);
			}
			else if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hwndDlg, IDCANCEL);
			}
			return TRUE;
		}
	case WM_CTLCOLORSTATIC:
		{
			if ((HWND)lParam == GetDlgItem(hwndDlg, IDC_LANG))
			{
				SetTextColor((HDC)wParam, GetSysColor(COLOR_HIGHLIGHTTEXT));
				SetBkMode((HDC)wParam, TRANSPARENT);
				return (INT_PTR)GetSysColorBrush(COLOR_HIGHLIGHT);
			}
			return FALSE;
		}
	case WM_INPUTLANGCHANGE:
		{
			LanguageChanged(hwndDlg, wParam, lParam);
			break;
		}
	case (WM_USER + 0x31337):
		{
			return 0x31337;
		}
	}
	return FALSE;
}

INT_PTR CALLBACK PasswordProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WNDPROC proc = (WNDPROC)GetWindowLongPtr(hwnd, GWL_USERDATA);

	if (uMsg == WM_INPUTLANGCHANGE)
	{
		LanguageChanged(GetParent(hwnd), wParam, lParam);
	}

	if (proc)
		return CallWindowProc(proc, hwnd, uMsg, wParam, lParam);
	else
		return 0;
}

void LanguageChanged(HWND hwndDlg, WPARAM wParam, LPARAM lParam)
{
	TCHAR buff[3];
	WORD locale = LOWORD(lParam);

	switch(locale)
	{
	case 1025:
		_tcscpy(buff, _T("AR")); break; // may be wrong
	case 1026:
		_tcscpy(buff, _T("BG")); break;
	case 1027:
		_tcscpy(buff, _T("CA")); break;
	case 1028:
		_tcscpy(buff, _T("TW")); break; // may be wrong
	case 1029:
		_tcscpy(buff, _T("CS")); break;
	case 1030:
		_tcscpy(buff, _T("DA")); break;
	case 1031:
		_tcscpy(buff, _T("DE")); break;
	case 1032:
		_tcscpy(buff, _T("EL")); break;
	case 1033:
		_tcscpy(buff, _T("EN")); break;
	case 1034:
		_tcscpy(buff, _T("ES")); break;
	case 1035:
		_tcscpy(buff, _T("FI")); break;
	case 1036:
		_tcscpy(buff, _T("FR")); break;
	case 1037:
		_tcscpy(buff, _T("HE")); break;
	case 1038:
		_tcscpy(buff, _T("HU")); break;
	case 1039:
		_tcscpy(buff, _T("IS")); break;
	case 1040:
		_tcscpy(buff, _T("IT")); break;
	case 1041:
		_tcscpy(buff, _T("JA")); break;
	case 1042:
		_tcscpy(buff, _T("KO")); break;
	case 1043:
		_tcscpy(buff, _T("NL")); break;
	case 1044:
		_tcscpy(buff, _T("NB")); break;
	case 1045:
		_tcscpy(buff, _T("PL")); break;
	case 1046:
		_tcscpy(buff, _T("PT")); break;
	case 1048:
		_tcscpy(buff, _T("RO")); break;
	case 1049:
		_tcscpy(buff, _T("RU")); break;
	case 1050:
		_tcscpy(buff, _T("HR")); break;
	case 1051:
		_tcscpy(buff, _T("SK")); break;
	case 1052:
		_tcscpy(buff, _T("SQ")); break;
	case 1053:
		_tcscpy(buff, _T("SV")); break;
	case 1054:
		_tcscpy(buff, _T("TH")); break;
	case 1055:
		_tcscpy(buff, _T("TR")); break;
	case 1056:
		_tcscpy(buff, _T("UR")); break;
	case 1057:
		_tcscpy(buff, _T("ID")); break;
	case 1058:
		_tcscpy(buff, _T("UK")); break;
	case 1059:
		_tcscpy(buff, _T("BE")); break;
	case 1060:
		_tcscpy(buff, _T("SL")); break;
	case 1061:
		_tcscpy(buff, _T("ET")); break;
	case 1062:
		_tcscpy(buff, _T("LV")); break;
	case 1063:
		_tcscpy(buff, _T("LT")); break;
	case 1066:
		_tcscpy(buff, _T("VI")); break;
	case 1067:
		_tcscpy(buff, _T("HY")); break;
	case 1068:
		_tcscpy(buff, _T("AZ")); break;
	case 1069:
		_tcscpy(buff, _T("ES")); break;
	case 1071:
		_tcscpy(buff, _T("MK")); break;
	case 1078:
		_tcscpy(buff, _T("AF")); break;
	case 1079:
		_tcscpy(buff, _T("KA")); break;
	case 1080:
		_tcscpy(buff, _T("FO")); break;
	case 1081:
		_tcscpy(buff, _T("HI")); break;
	case 1086:
		_tcscpy(buff, _T("MY")); break; // may be wrong
	case 1087:
		_tcscpy(buff, _T("KK")); break;
	case 1088:
		_tcscpy(buff, _T("KY")); break;
	case 1089:
		_tcscpy(buff, _T("SW")); break;
	case 1091:
		_tcscpy(buff, _T("UZ")); break;
	case 1092:
		_tcscpy(buff, _T("TT")); break;
	case 1094:
	case 1095:
	case 1097:
	case 1098:
	case 1099:
	case 1102:
	case 1103:
		_tcscpy(buff, _T("ID")); break;
	case 1104:
		_tcscpy(buff, _T("MN")); break;
	case 1111:
		_tcscpy(buff, _T("ID")); break;
	case 1114:
		_tcscpy(buff, _T("SY")); break; // may be wrong
	case 1125:
		_tcscpy(buff, _T("DV")); break;
	case 2049:
		_tcscpy(buff, _T("AR")); break; // may be wrong
	case 2052:
		_tcscpy(buff, _T("ZH")); break;
	case 2055:
		_tcscpy(buff, _T("CE")); break;
	case 2060:
		_tcscpy(buff, _T("BE")); break;
	case 2064:
		_tcscpy(buff, _T("CE")); break;
	case 2067:
		_tcscpy(buff, _T("BE")); break;
	case 2068:
		_tcscpy(buff, _T("NB")); break;
	case 2070:
		_tcscpy(buff, _T("PT")); break;
	case 2074:
		_tcscpy(buff, _T("SR")); break;
	case 2077:
		_tcscpy(buff, _T("FI")); break;
	case 2092:
		_tcscpy(buff, _T("AZ")); break;
	case 2110:
		_tcscpy(buff, _T("MY")); break; // may be wrong
	case 2115:
		_tcscpy(buff, _T("UZ")); break;
	case 3073:
		_tcscpy(buff, _T("AR")); break; // may be wrong
	case 3076:
		_tcscpy(buff, _T("ZH")); break; // may be wrong
	case 3081:
		_tcscpy(buff, _T("EN")); break;
	case 3098:
		_tcscpy(buff, _T("SR")); break;
	case 4108:
		_tcscpy(buff, _T("CE")); break;
	case 4100:
	case 5124:
		_tcscpy(buff, _T("ZH")); break;
	case 3079:
	case 4103:
	case 5127:
		_tcscpy(buff, _T("DE")); break;
	case 11274:
		_tcscpy(buff, _T("AN")); break;
	case 2057:
	case 4105:
	case 5129:
	case 6153:
	case 7177:
	case 8201:
	case 9225:
	case 10249:
	case 11273:
	case 12297:
	case 13321:
		_tcscpy(buff, _T("EN")); break;
	case 3084:
	case 5132:
	case 6156:
	case 7180:
	case 9228:
	case 10252:
	case 11276:
	case 12300:
	case 13324:
		_tcscpy(buff, _T("FR")); break;
	case 4097:
	case 5121:
	case 6145:
	case 7169:
	case 8193:
	case 9217:
	case 10241:
	case 11265:
	case 13313:
	case 12289:
	case 14337:
		_tcscpy(buff, _T("AR")); break;
	case 1110:
	case 2058:
	case 3082:
	case 4106:
	case 5130:
	case 6154:
	case 7178:
	case 8202:
	case 9226:
	case 10250:
	case 12298:
	case 13322:
	case 14346:
	case 15370:
	case 16394:
	case 17418:
	case 18422:
	case 19466:
	case 20490:
		_tcscpy(buff, _T("ES")); break;
	default:
		_tcscpy(buff, _T("?")); break;
	}

	SetDlgItemText(hwndDlg, IDC_LANG, buff);
}