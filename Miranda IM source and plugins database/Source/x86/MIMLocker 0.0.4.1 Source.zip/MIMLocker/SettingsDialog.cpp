#include "stdafx.h"
#include "MIMLocker.h"
#include "resource.h"

extern HINSTANCE hInst;

static int InitializeSettingsCallback(WPARAM wParam, LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp = {0};

	odp.cbSize = sizeof(odp);
	odp.position = 910000000;
	odp.hInstance = hInst;
	odp.pszGroup = Translate("Plugins");
	odp.flags = ODPF_BOLDGROUPS | ODPF_EXPERTONLY;
	odp.pszTemplate = MAKEINTRESOURCEA(IDD_SETTINGS);
	odp.pszTitle = Translate(PLUGIN_NAME);
	odp.pfnDlgProc = SettingsProc;
	CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);

	return 0;
}

int InitializeSettings()
{
	HookEvent(ME_OPT_INITIALISE, InitializeSettingsCallback);
	return 0;
}

INT_PTR CALLBACK SettingsProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
			SetDlgItemText(hwndDlg, IDC_SETPASSWORD, TranslateT("Set password..."));
			SetDlgItemText(hwndDlg, IDC_FEATURES, TranslateT("When locked"));
			SetDlgItemText(hwndDlg, IDC_DISABLE_SOUNDS, TranslateT("Disable sounds"));
			SetDlgItemText(hwndDlg, IDC_DISABLE_POPUPS, TranslateT("Disable popups"));
			SetDlgItemText(hwndDlg, IDC_LOCK_ICONS, TranslateT("Lock tray icons"));
			SetDlgItemText(hwndDlg, IDC_CHANGE_STATUS, TranslateT("Change status to"));
			SetDlgItemText(hwndDlg, IDC_CHANGE_STATUS_BACK_ON_UNLOCK, TranslateT("Change it back on unlock"));
			SetDlgItemText(hwndDlg, IDC_LOCK_WITH_SYSTEM, TranslateT("Lock Miranda when system is locked (Win+L)"));

			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_ADDSTRING, 0, (LPARAM)TranslateT("Offline"));
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETITEMDATA, 0, ID_STATUS_OFFLINE);
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_ADDSTRING, 0, (LPARAM)TranslateT("Online"));
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETITEMDATA, 1, ID_STATUS_ONLINE);
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_ADDSTRING, 0, (LPARAM)TranslateT("Away"));
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETITEMDATA, 2, ID_STATUS_AWAY);
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_ADDSTRING, 0, (LPARAM)TranslateT("Do not distirb"));
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETITEMDATA, 3, ID_STATUS_DND);
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_ADDSTRING, 0, (LPARAM)TranslateT("N/A"));
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETITEMDATA, 4, ID_STATUS_NA);
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_ADDSTRING, 0, (LPARAM)TranslateT("Occupied"));
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETITEMDATA, 5, ID_STATUS_OCCUPIED);
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_ADDSTRING, 0, (LPARAM)TranslateT("Free for chat"));
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETITEMDATA, 6, ID_STATUS_FREECHAT);
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_ADDSTRING, 0, (LPARAM)TranslateT("Invisible"));
			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETITEMDATA, 7, ID_STATUS_INVISIBLE);

			CheckDlgButton(hwndDlg, IDC_DISABLE_SOUNDS, 
				DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_DISABLE_SOUNDS, 1));
			CheckDlgButton(hwndDlg, IDC_DISABLE_POPUPS, 
				DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_DISABLE_POPUPS, 1));
			CheckDlgButton(hwndDlg, IDC_LOCK_ICONS, 
				DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_ICONS, 1));

			BOOL enabled = DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_CHANGE_STATUS, 0);

			CheckDlgButton(hwndDlg, IDC_CHANGE_STATUS, enabled);
			
			EnableWindow(GetDlgItem(hwndDlg, IDC_LOCKED_STATUS), enabled);
			EnableWindow(GetDlgItem(hwndDlg, IDC_CHANGE_STATUS_BACK_ON_UNLOCK), enabled);

			SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_SETCURSEL, 
				DBGetContactSettingDword(NULL, PLUGIN_NAME, SETTING_LOCKED_STATUS, -1), NULL);
			CheckDlgButton(hwndDlg, IDC_CHANGE_STATUS_BACK_ON_UNLOCK, 
				DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_RESTORE_STATUS, 1));

			CheckDlgButton(hwndDlg, IDC_LOCK_WITH_SYSTEM, 
				DBGetContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_WITH_SYSTEM, 0));

			EnableWindow(GetDlgItem(hwndDlg, IDC_LOCK_WITH_SYSTEM), CanWatchSession());

			return FALSE;
		}
	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
			case IDC_SETPASSWORD:
				DialogBox(hInst, MAKEINTRESOURCE(IDD_CHANGEPASS), GetParent(hwndDlg), ChangePassProc);
				return TRUE;
			case IDC_DISABLE_SOUNDS:
			case IDC_DISABLE_POPUPS:
			case IDC_LOCK_ICONS:
			case IDC_CHANGE_STATUS:
			case IDC_CHANGE_STATUS_BACK_ON_UNLOCK:
			case IDC_LOCK_WITH_SYSTEM:
				if (HIWORD(wParam) != BN_CLICKED) return TRUE;

				if (LOWORD(wParam) == IDC_CHANGE_STATUS)
				{
					BOOL enabled = IsDlgButtonChecked(hwndDlg, IDC_CHANGE_STATUS);
					EnableWindow(GetDlgItem(hwndDlg, IDC_LOCKED_STATUS), enabled);
					EnableWindow(GetDlgItem(hwndDlg, IDC_CHANGE_STATUS_BACK_ON_UNLOCK), enabled);
				}

				break;
			}

			SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);
			break;
		}
	case WM_NOTIFY:
		if (((LPNMHDR)lParam)->idFrom == 0 && ((LPNMHDR)lParam)->code == PSN_APPLY)
		{
			DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_DISABLE_SOUNDS, 
				IsDlgButtonChecked(hwndDlg, IDC_DISABLE_SOUNDS));
			DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_DISABLE_POPUPS, 
				IsDlgButtonChecked(hwndDlg, IDC_DISABLE_POPUPS));
			DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_ICONS, 
				IsDlgButtonChecked(hwndDlg, IDC_LOCK_ICONS));
			DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_ICONS, 
				IsDlgButtonChecked(hwndDlg, IDC_LOCK_ICONS));
			DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_CHANGE_STATUS, 
				IsDlgButtonChecked(hwndDlg, IDC_CHANGE_STATUS));
			DBWriteContactSettingDword(NULL, PLUGIN_NAME, SETTING_LOCKED_STATUS, 
				SendDlgItemMessage(hwndDlg, IDC_LOCKED_STATUS, CB_GETCURSEL, 0, 0));
			DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_RESTORE_STATUS, 
				IsDlgButtonChecked(hwndDlg, IDC_CHANGE_STATUS_BACK_ON_UNLOCK));
			DBWriteContactSettingByte(NULL, PLUGIN_NAME, SETTING_LOCK_WITH_SYSTEM,
				IsDlgButtonChecked(hwndDlg, IDC_LOCK_WITH_SYSTEM));

			return TRUE;
		}
	}
	return FALSE;
}

INT_PTR CALLBACK ChangePassProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
			SetWindowText(hwndDlg, TranslateT("Set password"));
			SetDlgItemText(hwndDlg, IDC_OLDPASSWORDPROMPT, TranslateT("Old password:"));
			SetDlgItemText(hwndDlg, IDC_PASSWORDPROMPT, TranslateT("New password:"));
			SetDlgItemText(hwndDlg, IDC_CONFIRMPROMPT, TranslateT("Confirm:"));

			DBVARIANT dbv = {0};
			if (!DBGetContactSettingTString(NULL, PLUGIN_NAME, SETTING_PASSWORD, &dbv))
			{
				EnableWindow(GetDlgItem(hwndDlg, IDC_OLDPASSWORDPROMPT), TRUE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_OLDPASSWORD), TRUE);

				DBFreeVariant(&dbv);
			}

			return TRUE;
		}
	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
			case IDOK:
				{
					HWND hwndOldPass = GetDlgItem(hwndDlg, IDC_OLDPASSWORD);
					HWND hwndNewPass = GetDlgItem(hwndDlg, IDC_PASSWORD);
					HWND hwndConfirm = GetDlgItem(hwndDlg, IDC_CONFIRM);
					BOOL needOld = IsWindowEnabled(hwndOldPass);

					TCHAR oldPass[MAX_PATH + 1];
					TCHAR buff[MAX_PATH + 1];
					TCHAR newPass[MAX_PATH + 1];
					TCHAR confirm[MAX_PATH + 1];

					if (needOld && !GetWindowText(hwndOldPass, oldPass, MAX_PATH))
					{
						MessageBox(hwndDlg, TranslateT("You must enter your old password"), 
								   _T(PLUGIN_NAME), MB_ICONEXCLAMATION);
						SetFocus(hwndOldPass);
						return TRUE;
					}

					GetWindowText(hwndNewPass, newPass, MAX_PATH);
					GetWindowText(hwndConfirm, confirm, MAX_PATH);

					if (_tcscmp(newPass, confirm))
					{
						MessageBox(hwndDlg, TranslateT("New password and its confirmation are different.\nTry once more."), 
								   _T(PLUGIN_NAME), MB_ICONEXCLAMATION);
						SetWindowText(hwndNewPass, NULL);
						SetWindowText(hwndConfirm, NULL);
						SetFocus(hwndNewPass);
						return TRUE;
					}
					else if (!_tcslen(newPass))
					{
						if (MessageBox(hwndDlg, TranslateT("This will reset your password. Continue?"), 
									   _T(PLUGIN_NAME), MB_ICONQUESTION | MB_YESNO | MB_DEFBUTTON2) != IDYES)
						{
							SetFocus(hwndNewPass);
							return TRUE;
						}					
					}

					EncodeTString(MAX_PATH, oldPass);

					DBVARIANT dbv = {0};
					if (!DBGetContactSettingTString(NULL, PLUGIN_NAME, SETTING_PASSWORD, &dbv))
					{
						BOOL wrong = _tcscmp(oldPass, dbv.ptszVal);
						DBFreeVariant(&dbv);
						
						if (wrong)
						{
							MessageBox(hwndDlg, TranslateT("Invalid password"), _T(PLUGIN_NAME), MB_ICONEXCLAMATION);
							SetWindowText(hwndOldPass, NULL);
							SetFocus(hwndOldPass);
							return TRUE;
						}
					}

					if (_tcslen(newPass))
					{
						EncodeTString(MAX_PATH, newPass);
						DBWriteContactSettingTString(NULL, PLUGIN_NAME, SETTING_PASSWORD, newPass);
					}
					else
					{
						DBDeleteContactSetting(NULL, PLUGIN_NAME, SETTING_PASSWORD);
					}

					MessageBox(hwndDlg, TranslateT("Your password has been changed"), 
							   _T(PLUGIN_NAME), MB_ICONINFORMATION);

					EndDialog(hwndDlg, IDOK);
				}
				break;
			case IDCANCEL:
				EndDialog(hwndDlg, IDCANCEL);
				break;
			default:
				return FALSE;
			}
			return TRUE;
		}
	}
	return FALSE;
}
