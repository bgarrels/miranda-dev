/*
Miranda IM Help Plugin
Copyright (C) 2002 Richard Hughes, 2005-2007 H. Herkenrath

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (Help-License.txt); if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <tchar.h>
#include <stdio.h>
#define _WIN32_WINNT  0x0500
#define __RPCASYNC_H__  /* header shows warnings in VS6 */
#include <windows.h>
#pragma warning(disable:4201)  /* nonstandard extension used : nameless struct/union */
#include <commctrl.h>
#pragma warning(default:4201)  /* nonstandard extension used : nameless struct/union */
#define MIRANDA_VER  0x0600
#include <newpluginapi.h>
#include <win2k.h>
#include <m_system.h>
#include <m_database.h>
#include <m_utils.h>
#include <m_langpack.h>
#include "m_help.h"
#include "help.h"
#include "version.h"

HINSTANCE hInst;
PLUGINLINK *pluginLink;
struct MM_INTERFACE mmi;
struct UTF8_INTERFACE utfi;
extern HWND hwndHelpDlg;
static HANDLE hHookModulesLoaded;

static PLUGININFOEX pluginInfo={
	sizeof(PLUGININFOEX),
#ifdef EDITOR
	"Help Editor",
#else
	"Help",
#endif // defined EDITOR
	PLUGIN_VERSION,
#if defined(_DEBUG)
	"Development build not intended for release. ("__DATE__")", /* auto-translated */
#else
	"Provides context sensitive help in the Miranda IM dialog boxes.", /* auto-translated */
#endif
	"Richard Hughes, H. Herkenrath",
	PLUGIN_EMAIL,  /* @ will be set later */
	"� 2002 Richard Hughes, 2005-2007 H. Herkenrath",
	PLUGIN_WEBSITE,
	UNICODE_AWARE,
	0,
#if defined(_UNICODE)
	// {B16DF0B2-A08F-4bc6-8FA2-3D5FFFA2708D}
	{0xb16df0b2,0xa08f,0x4bc6,{0x8f,0xa2,0x3d,0x5f,0xff,0xa2,0x70,0x8d}}
#else
	// {B9BC3771-F690-4bcd-ACE8-8887E7D2DF93}
	{0xb9bc3771,0xf690,0x4bcd,{0xac,0xe8,0x88,0x87,0xe7,0xd2,0xdf,0x93}}
#endif
};
static const MUUID interfaces[]={MIID_HELP,MIID_LAST};

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,void *pReserved)
{
	UNREFERENCED_PARAMETER(pReserved);
	if(fdwReason==DLL_PROCESS_ATTACH)
		DisableThreadLibraryCalls(hInst=hinstDLL);
	return TRUE;
}

static void InstallFile(const TCHAR *pszFileName,const TCHAR *pszDestSubDir)
{
	TCHAR szFileFrom[MAX_PATH+1],szFileTo[MAX_PATH+1],*p;
	HANDLE hFile;

	if(!GetModuleFileName(hInst,szFileFrom,SIZEOF(szFileFrom)-lstrlen(pszFileName)))
		return;
	p=_tcsrchr(szFileFrom,_T('\\'));
	if(p!=NULL) *(++p)=0;
	lstrcat(szFileFrom,pszFileName); /* buffer safe */

	hFile=CreateFile(szFileFrom,0,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
	if(hFile==INVALID_HANDLE_VALUE) return;
	CloseHandle(hFile);

	if(!GetModuleFileName(NULL,szFileTo,SIZEOF(szFileTo)-lstrlen(pszDestSubDir)-lstrlen(pszFileName)))
		return;
	p=_tcsrchr(szFileTo,_T('\\'));
	if(p!=NULL) *(++p)=0;
	lstrcat(szFileTo,pszDestSubDir); /* buffer safe */
	CreateDirectory(szFileTo,NULL);
	lstrcat(szFileTo,pszFileName);  /* buffer safe */

	if(!MoveFile(szFileFrom,szFileTo) && GetLastError()==ERROR_ALREADY_EXISTS) {
		DeleteFile(szFileTo);
		MoveFile(szFileFrom,szFileTo);
	}
}

static int HelpModulesLoaded(WPARAM wParam,LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if(ServiceExists("DBEditorpp/RegisterSingleModule"))
		CallService("DBEditorpp/RegisterSingleModule",(WPARAM)"HelpPlugin",0);
	return 0;
}

#ifdef __cplusplus
extern "C" {
#endif 

__declspec(dllexport) const PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	if(mirandaVersion<PLUGIN_MAKE_VERSION(0,1,0,1)) return NULL;
	pluginInfo.cbSize=sizeof(PLUGININFO); /* needed as v0.6 does equality check */
	/* email obfuscated, made .rdata writable */
	pluginInfo.authorEmail[PLUGIN_EMAIL_ATT_POS-1]='@';
	return (PLUGININFO*)&pluginInfo; /* header is the same */
}

__declspec(dllexport) const PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	UNREFERENCED_PARAMETER(mirandaVersion);
	pluginInfo.cbSize=sizeof(PLUGININFOEX);
	/* email obfuscated, made .rdata writable */
	pluginInfo.authorEmail[PLUGIN_EMAIL_ATT_POS-1]='@';
	return &pluginInfo;
}

__declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

__declspec(dllexport) int Load(PLUGINLINK *link)
{
	INITCOMMONCONTROLSEX icc;
	pluginLink=link;

	/* existance of MS_SYSTEM_GETVERSION and MS_LANGPACK_TRANSLATESTRING
	 * is checked in MirandaPluginInfo().
	 * Not placed in MirandaPluginInfo() to avoid MessageBoxes on plugin options. 
	 * Using ANSI as LANG_UNICODE might not be supported. */
	if(CallService(MS_SYSTEM_GETVERSION,0,0)<NEEDED_MIRANDA_VERSION) {
		char szText[256];
		mir_snprintf(szText,sizeof(szText),Translate("The Help Plugin can not be loaded. It requires Miranda IM %hs or later."),NEEDED_MIRANDA_VERSION_STR);
		MessageBoxA(NULL,szText,Translate("Help Plugin"),MB_OK|MB_ICONINFORMATION|MB_SETFOREGROUND|MB_TOPMOST|MB_TASKMODAL);
		return 1;
	}

	if(mir_getMMI(&mmi)) return 1;
#if defined(_UNICODE)
	if(mir_getUTFI(&utfi)) return 1;
#endif
	icc.dwSize=sizeof(icc);
	icc.dwICC=ICC_UPDOWN_CLASS|ICC_TREEVIEW_CLASSES;
	if(!InitCommonControlsEx(&icc)) return 1;

	if(LoadLibraryA("RICHED20")==NULL) /* richedit v2.0 (Win98/NT4), v3.0 (WinXP/2000/Me+) */
		if(IDYES!=MessageBoxEx(NULL,
		   TranslateT("The Help Plugin can not be loaded, riched20.dll is missing. If you are using Windows 95 or WINE please make sure you have riched20.dll installed.\n\nPress 'Yes' to continue loading Miranda IM."),
		   TranslateT("Help Plugin"),MB_YESNO|MB_ICONWARNING|MB_SETFOREGROUND|MB_TOPMOST|MB_TASKMODAL,LANGIDFROMLCID((LCID)CallService(MS_LANGPACK_GETLOCALE,0,0))))
			return 1;

	if(InstallDialogBoxHook()) return 1;
	InitOptions();
	InitDialogCache();
	InitUpdate();
	hHookModulesLoaded=HookEvent(ME_SYSTEM_MODULESLOADED,HelpModulesLoaded);

	InstallFile(_T("Help-Readme.txt"),_T("Docs\\"));
	InstallFile(_T("Help-License.txt"),_T("Docs\\"));
	InstallFile(_T("Help-SDK.zip"),_T("Docs\\"));
	return 0;
}

__declspec(dllexport) int Unload(void)
{
	UninitOptions();
	UninitUpdate();
	RemoveDialogBoxHook();
	if(hwndHelpDlg!=NULL) DestroyWindow(hwndHelpDlg);
	FreeDialogCache();
	UnhookEvent(hHookModulesLoaded); /* does NULL check */
	return 0;
}

#ifdef __cplusplus
}
#endif 
