/*

Miranda IM: the free IM client for Microsoft* Windows*

Copyright 2000-2007 Miranda ICQ/IM project, 
all portions of this codebase are copyrighted to the people 
listed in contributors.txt.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef M_ICOLIB_H__
#define M_ICOLIB_H__

#if !defined(_TCHAR_DEFINED)
#include <tchar.h>
#endif

//Add an icon into options UI
//wParam=0
//lParam=(LPARAM)(SKINICONDESC*)sid;
//Returns a HANDLE to the registered item
#define MS_SKIN2_ADDICON  "Skin2/Icons/AddIcon"

#if defined(_MSC_VER)
#pragma warning(push)          /* save warning settings */
#pragma warning(disable:4201)  /* nonstandard extension used : nameless struct/union */
#endif

#define SKINICONDESC_SIZE_V1  24
#define SKINICONDESC_SIZE_V2  28  // v0.0.0.2+
#define SKINICONDESC_SIZE_V3  36  // v0.0.0.3+

typedef struct {
	int cbSize;
	union {
	   const char *pszSection;      // section name used to group icons
	   const TCHAR *ptszSection;
	   const WCHAR *pwszSection;
	};
	union {
	   const char *pszDescription;  // description for options dialog
	   const TCHAR *ptszDescription;
	   const WCHAR *pwszDescription;
	};
	const char *pszName;             // name to refer to the icon to retrieve and in db

	union {
	   /* default icon from external file.
 	    * to use these set SIDF_FROMFILE in flags */
	   struct {
	      union {
	         const char *pszDefaultFile;  // default file to use
	         const TCHAR *ptszDefaultFile;
             const WCHAR *pwszDefaultFile;
          };
	      int iDefaultIndex;              // index of icon in default file
	   };
	   /* default icon from loaded library.
 	    * to use these set SIDF_FROMRESOURCE in flags */
	   struct {
	      HINSTANCE hInst;                // handle to library, set to NULL for miranda core
	      union {
	         char *pszDefaultResource;    // resource id in library (use the MAKEINTRESOURCE macro)
 	         TCHAR *ptszDefaultResource;
	         WCHAR *pwszDefaultResource;
	      };
	   };
	};
	/* default icon specified directly.
	 * to use this set SIDF_FROMHICON in flags */
	HICON hDefaultIcon;  // handle to default icon, can be destroyed after the call

	int cx,cy;           // dimensions of the icon, ignored if SIDF_SMALL, SIDF_LARGE or SIDF_DEFAULTSIZE are set
	DWORD flags;         // combination of SIDF_*
} SKINICONDESC;

#define SIDF_SORTED         0x001  // icons get sorted in options
#define SIDF_FROMFILE       0x010  // default icon is retrieved from external file
#define SIDF_FROMRESOURCE   0x020  // default icon is retrieved from loaded library
#define SIDF_FROMHICON      0x040  // default icon is specified directly
#define SIDF_SMALL          0x002  // dimensions (cx,cy) are the default small icon metrics
                                   // (SM_CXSMICON,SM_CYSMICON) 
#define SIDF_LARGE          0x004  // dimensions (cx,cy) are the default large icon metrics
                                   // (SM_CXICON,SM_CYICON)
#define SIDF_DEFAULTSIZE    0x008  // dimensions (cx,cy) are the actual size of the default icon
                                   // (only possible for SIDF_FROMHICON and SIDF_FROMRESOURCE)

#define SIDF_UNICODE        0x100  // section and description are Unicode
#define SIDF_PATH_UNICODE   0x200  // default file is Unicode
#if defined(_UNICODE)
   #define SIDF_TCHAR       SIDF_UNICODE       // section and description are WCHAR*
   #define SIDF_PATH_TCHAR  SIDF_PATH_UNICODE  // default file is WCHAR*
#else
   #define SIDF_TCHAR       0     // section and description are char*, as usual
   #define SIDF_PATH_TCHAR  0     // default file is char*, as usual
#endif
#define SIDF_ALL_UNICODE    (SIDF_UNICODE|SIDF_PATH_UNICODE)
#define SIDF_ALL_TCHAR      (SIDF_TCHAR|SIDF_PATH_TCHAR)

__inline static HANDLE IcoLib_AddIconRes(const char *name,const char *section,const char *description,HINSTANCE hinst,char *resource)
{
	SKINICONDESC sid;
	sid.cbSize=sizeof(SKINICONDESC);
	sid.pszName=name;
	sid.pszSection=section;
	sid.pszDescription=description;
	sid.hInst=hinst;
	sid.pszDefaultResource=resource;
	sid.flags=SIDF_SORTED|SIDF_FROMRESOURCE|SIDF_DEFAULTSIZE;
	return (HANDLE)CallService(MS_SKIN2_ADDICON,0,(LPARAM)&sid);

}
__inline static HANDLE IcoLib_AddIconResW(const char *name,const WCHAR *section,const WCHAR *description,HINSTANCE hinst,WCHAR *resource)
{
	SKINICONDESC sid;
	sid.cbSize=sizeof(SKINICONDESC);
	sid.pszName=name;
	sid.pwszSection=section;
	sid.pwszDescription=description;
	sid.hInst=hinst;
	sid.pwszDefaultResource=resource;
	sid.flags=SIDF_SORTED|SIDF_FROMRESOURCE|SIDF_DEFAULTSIZE;
	return (HANDLE)CallService(MS_SKIN2_ADDICON,0,(LPARAM)&sid);
}
#if defined(_UNICODE)
   #define IcoLib_AddIconResT  IcoLib_AddIconResW
#else
   #define IcoLib_AddIconResT  IcoLib_AddIconRes
#endif

#if defined(_MSC_VER)
#pragma warning(pop)           /* restore warning settings */
#endif

//Remove an icon from options UI
//wParam=0
//lParam=(LPARAM)(char*)pszName
//Warning: This will invalidate all HICONs retrieved for specified pszName
//Returns 0 on success, nonzero otherwise.
#define MS_SKIN2_REMOVEICON  "Skin2/Icons/RemoveIcon"

//Retrieve an icon by it's HANDLE
//wParam=0
//lParam=(LPARAM)(HANDLE)hItem
//Note: The icon handle's reference count got increased. Remember to call MS_SKIN2_RELEASEICON after use.
//Returns a shared HICON on success, NULL otherwise.
#define MS_SKIN2_GETICONBYHANDLE  "Skin2/Icons/GetIconByHandle" 

//Retrieve an icon handle
//Returned hIcon *must not* be destroyed, it is managed by IcoLib.
//wParam=0
//lParam(LPARAM)(char*)pszName
//Note: The icon handle's reference count got increased. Remember to call MS_SKIN2_RELEASEICON after use.
//Returns a shared HICON on success, NULL otherwise.
#define MS_SKIN2_GETICON  "Skin2/Icons/GetIcon"
__inline static HICON IcoLib_GetIcon(const char *pszName) { return (HICON)CallService(MS_SKIN2_GETICON,0,(LPARAM)pszName); }

//Release a retrieved icon handle
//Call this if a retrieved hIcon is not needed anymore.
//The icon handles reference count is decremented by one. This helps to optimize GDI usage.
//wParam=(WPARAM)(HICON)hIcon (optional)
//lParam=(LPARAM)(char*)pszName (optional)   (at least one needs to be specified)
//Returns 0 on success, nonzero if the icon handle is not managed by IcoLib.
#define MS_SKIN2_RELEASEICON  "Skin2/Icons/ReleaseIcon"
__inline static int IcoLib_ReleaseIcon(HICON hIcon) { return CallService(MS_SKIN2_RELEASEICON,(WPARAM)hIcon,0); }

//Add reference to an icon handle
//Call this to increment the icon handles reference count by one.
//wParam=(WPARAM)(HICON)hIcon
//lParam=0
//Returns 0 on success, nonzero if the icon handle is not managed by IcoLib.
#define MS_SKIN2_ADDREFICON  "Skin2/Icons/AddRef"
__inline static int IcoLib_AddRef(HICON hIcon) { return CallService(MS_SKIN2_ADDREFICON,(WPARAM)hIcon,0); }

//Check whether an icon handle is managed by IcoLib
//wParam=(WPARAM)(HICON)hIcon
//lParam=0
//Returns nonzero if the icon is managedm 0 otherwise.
//Note: In almost all cases it is enough to check the return values of 
//MS_SKIN2_ADDREFICON and MS_SKIN2_RELEASEICON.
#define MS_SKIN2_ISMANAGEDICON  "Skin2/Icons/IsManaged"

//Icons change notification (event)
//Please refresh your icon handles at this point.
//wParam=lParam=0
//Return always 0 here.
#define ME_SKIN2_ICONSCHANGED  "Skin2/IconsChanged"

#endif // M_ICOLIB_H
