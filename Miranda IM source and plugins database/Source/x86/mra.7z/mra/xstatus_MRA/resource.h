//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by xstatus_MRA.rc
//
#define IDS_IDENTIFY                    102
#define IDI_XSTATUS1                    201
#define IDI_XSTATUS2                    202
#define IDI_XSTATUS3                    203
#define IDI_XSTATUS4                    204
#define IDI_XSTATUS5                    205
#define IDI_XSTATUS6                    206
#define IDI_XSTATUS7                    207
#define IDI_XSTATUS8                    208
#define IDI_XSTATUS9                    209
#define IDI_XSTATUS10                   210
#define IDI_XSTATUS11                   211
#define IDI_XSTATUS12                   212
#define IDI_XSTATUS13                   213
#define IDI_XSTATUS14                   214
#define IDI_XSTATUS15                   215
#define IDI_XSTATUS16                   216
#define IDI_XSTATUS17                   217
#define IDI_XSTATUS18                   218
#define IDI_XSTATUS19                   219
#define IDI_XSTATUS20                   220
#define IDI_XSTATUS21                   221
#define IDI_XSTATUS22                   222
#define IDI_XSTATUS23                   223
#define IDI_XSTATUS24                   224
#define IDI_XSTATUS25                   225
#define IDI_XSTATUS26                   226
#define IDI_XSTATUS27                   227
#define IDI_XSTATUS28                   228
#define IDI_XSTATUS29                   229
#define IDI_XSTATUS30                   230
#define IDI_XSTATUS31                   231
#define IDI_XSTATUS32                   232
#define IDI_XSTATUS33                   233
#define IDI_XSTATUS34                   234
#define IDI_XSTATUS35                   235
#define IDI_XSTATUS36                   236
#define IDI_XSTATUS37                   237
#define IDI_XSTATUS38                   238
#define IDI_XSTATUS39                   239
#define IDI_XSTATUS40                   240
#define IDI_XSTATUS41                   241
#define IDI_XSTATUS42                   242
#define IDI_XSTATUS43                   243
#define IDI_XSTATUS44                   244
#define IDI_XSTATUS45                   245
#define IDI_XSTATUS46                   246
#define IDI_XSTATUS47                   247
#define IDI_XSTATUS48                   248
#define IDI_XSTATUS49                   249
#define IDI_XSTATUS_UNKNOWN             250


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        253
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
