#include "Converter.h"

Converter::Converter() : maps()
{
	
}

bool Converter::addMapping(const tstring &from, const tstring &to)
{
	if (!from.length())
		return false;
	bool retVal = maps.count(from.length()) && maps[from.length()].count(from);
	maps[from.length()][from] = to;
	return retVal;
}

tstring &operator<< (tstring &dest, const Converter &converter)
{
	map<long, stdext::hash_map<tstring,tstring>>::const_reverse_iterator iter1;
	stdext::hash_map<tstring,tstring>::const_iterator iter2;

	//iterate through string sizes, starting from maximum
	for (iter1 = converter.maps.rbegin(); iter1 != converter.maps.rend(); iter1++)
		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
			dest += iter2->first + TEXT("\r") + iter2->second + TEXT("\r");
	dest += '\n';
	return dest;
}

tstring &operator>> (tstring &src, Converter &converter)
{
	long cutAt;
	converter.clear();
	while (src[0] != '\n' && (cutAt = src.find_first_of('\r')) != src.npos)
	{
		tstring from, to;
		if (cutAt == 0)
			break;
		from = src.substr(0,cutAt);
		src = src.substr(cutAt+1);
		if (src[0] == '\n' || (cutAt = src.find_first_of('\r')) == src.npos)
			break;
		to = src.substr(0,cutAt);
		converter.addMapping(from,to);
		src = src.substr(cutAt+1);
	}
	if (src[0] == '\n')
		src = src.substr(1);
	return src;
}

inline TCHAR to_lower(TCHAR ch) { return (TCHAR)CharLower((LPTSTR)ch); }

//TODO: optimize conversion
//TODO: check, if there is a bug with pos detection
tstring Converter::convert(const tstring &str, long &pos)
{
	Node strNode(str), *curStrNode = &strNode, *posNode = &strNode;
	map<long, stdext::hash_map<tstring,tstring>>::reverse_iterator iter;
	
	//iterate through string sizes, starting from maximum
	for (iter = maps.rbegin(); iter != maps.rend() && curStrNode; iter++)
		//iterate through substrings of the converting string
		do
		{
			for (long offset = 0; offset <= (long)(curStrNode->getData().length()-iter->first); offset++)
			{
				//look for selected substring
				tstring curSubstr = curStrNode->getData().substr(offset, iter->first), curSubstrLCase = curSubstr;

				transform(curSubstrLCase.begin(),curSubstrLCase.end(),curSubstrLCase.begin(),to_lower);

				if (iter->second.count(curSubstrLCase))
				{
					tstring convertedStr = iter->second[curSubstrLCase];
					if (IsCharUpper(curSubstr[0]))
						convertedStr[0] = (TCHAR)CharUpper((LPTSTR)convertedStr[0]);

					curStrNode->updatePart(offset, iter->first, convertedStr);

					if (curStrNode == posNode)
					{
						if (pos < offset)
							posNode = posNode->nearestPrev();
						else if (offset <= pos && pos < offset + iter->first)
							pos -= offset;
						else
						{
							posNode = posNode->nearestNext();
							pos -= offset + iter->first;
						}
					}

					if (Node *bufNode = curStrNode->forwardNext())
						curStrNode = bufNode;
					else
						break;

					offset = -1;
				}
			}
		} while(curStrNode->forwardNext() ? curStrNode = curStrNode->forwardNext() : (curStrNode = curStrNode->roundNext(), NULL));
	return strNode.accumulateString(posNode, pos);
}

/*tstring Converter::convert(tstring &str, HKL from, HKL to)
{
	tstring retVal;
	for (unsigned curChar = 0; curChar < str.length(); curChar++)
	{
		BYTE keybdState[256];
		GetKeyboardState(keybdState);
		SHORT keyState = VkKeyScanEx(str[curChar], from);
		keybdState[VK_SHIFT] = keyState & (1<<8) ? 1<<7 : 0;
		keybdState[VK_CONTROL] = keyState & (2<<8) ? 1<<7 : 0;
		keybdState[VK_MENU] = keyState & (4<<8) ? 1<<7 : 0;
		TCHAR buf[2];
		if (ToUnicodeEx(keyState & 0xFF, 0, keybdState, buf, 2, 0, to) >= 1)
			retVal += buf[0];
		else
			retVal += str[curChar];
	}
	return retVal;
}*/

Converter::Node::Node(const tstring &data)
{
	Converter::Node::data = data;
	updated = false;
	prev = next = prevUpd = nextUpd = NULL;
}

Converter::Node::~Node()
{
	Node *prevNode;
	for (Node *curNode = prevUpd ? prevUpd : prev; curNode; curNode = prevNode)
	{
		prevNode = curNode->prevUpd ? curNode->prevUpd : curNode->prev;
		curNode->prevUpd = curNode->prev = curNode->nextUpd = curNode->next = NULL;
		delete curNode;
	}
	Node *nextNode;
	for (Node *curNode = nextUpd ? nextUpd : next; curNode; curNode = nextNode)
	{
		nextNode = curNode->nextUpd ? curNode->nextUpd : curNode->next;
		curNode->prevUpd = curNode->prev = curNode->nextUpd = curNode->next = NULL;
		delete curNode;
	}
}

long Converter::Node::updatePart(long start, long len, tstring &newStr)
{
	if (start < 0 || len <= 0 || start + len > (long) data.length() || updated)
		return -1;

	long retVal = -1;
	//split node into parts if necessary
	Node *prevNode, *nextNode;
	if (start == 0)
		prevNode = prev;
	else
	{
		retVal++;
		prevNode = new Node(data.substr(0, start));
		prevNode->prev = prev;
		prevNode->next = this;
		if (prev)
			prev->next = prevNode;
		if (prevUpd)
			prevUpd->next = prevNode;
		prevNode->prevUpd = prevUpd; prevUpd = NULL;
		prev = prevNode;
	}
	if (start + len == data.length())
		nextNode = next;
	else
	{
		retVal++;
		nextNode = new Node(data.substr(start+len, data.length()-(start+len)));
		nextNode->prev = this;
		nextNode->next = next;
		if (next)
			next->prev = nextNode;
		if (nextUpd)
			nextUpd->prev = nextNode;
		nextNode->nextUpd = nextUpd; nextUpd = NULL;
		next = nextNode;
	}
	
	//do the actual update
	data = newStr;
	updated = true;
	if (prev)
	{
		if (!prev->nextUpd)
			prev->nextUpd = this;
		prev->next = next;
	}
	if (next)
	{
		if (!next->prevUpd)
			next->prevUpd = this;
		next->prev = prev;
	}
	if (prevUpd)
	{
		if (prev)
			prev = NULL;
		prevUpd->next = NULL;
		prevUpd->nextUpd = this;
	}
	if (nextUpd)
	{
		if (next)
			next = NULL;
		nextUpd->prev = NULL;
		nextUpd->prevUpd = this;
	}
	return retVal;
}

const tstring &Converter::Node::getData() const
{
	return data;
}

Converter::Node *Converter::Node::forwardNext()
{
	for (Node *curNode = this; curNode->next || curNode->nextUpd; curNode = curNode->nextUpd)
		if (curNode->next)
			return curNode->next;
	return NULL;
}

Converter::Node *Converter::Node::roundNext()
{
	Node *bufNode;
	if (bufNode = forwardNext())
		return bufNode;

	Node *leftmostOutdated = this->updated ? NULL : this;
	for (Node *curNode = this->prev; curNode; curNode = curNode->prev)
		leftmostOutdated = curNode;

	return leftmostOutdated;
}

inline Converter::Node *Converter::Node::nearestNext()
{
	return this->nextUpd ? this->nextUpd : this->next; 
}

inline Converter::Node *Converter::Node::nearestPrev()
{
	return this->prevUpd ? this->prevUpd : this->prev;
}

tstring Converter::Node::accumulateString(const Node *const posNode, long &pos) const
{
	const Node *leftmost;
	for (const Node *curNode = this; curNode;  curNode = curNode->prevUpd ? curNode->prevUpd : curNode->prev)
		leftmost = curNode;

	tstring accStr;
	for (const Node *curNode = leftmost; curNode; curNode = curNode->nextUpd ? curNode->nextUpd : curNode->next)
	{
		if (curNode == posNode)
			pos = (pos <= (long)curNode->getData().length() ? pos : curNode->getData().length()) + accStr.length();
		accStr += curNode->getData();
	}
	if (!posNode)
		pos = accStr.length();
	return accStr;
}