#include "msgconv.h"

Converter cyrLatConverter, latCyrConverter, custom1Converter, custom2Converter;
OPT_PACK cyrLatOptPack = {&cyrLatConverter}, latCyrOptPack = {&latCyrConverter},
		custom1OptPack = {&custom1Converter}, custom2OptPack = {&custom2Converter};

WNDPROC wpOrigLV, wpOrigMapTableEdit, wpOrigMapTableName, wpOrigDelimList;
HWND hwndDlg, hwndMapTable, hwndMapTableEdit, hwndMapTableName, hwndDelimList;
bool bAdjustingOptionsView;

#define SHADOW_DELIMS _T("\t\r\n")
#define SHADOW_DELIMSLEN (sizeof(SHADOW_DELIMS)/sizeof(TCHAR)-1)

const struct
{
	TCHAR *from;
	TCHAR *to;
}
	cyrLatMapping[] = {
					{_T("��"),_T("iy")},{_T("��"),_T("iye")},{_T("��"),_T("iyo")},
					{_T("��"),_T("iyu")},{_T("��"),_T("iya")},{_T("��"),_T("ye")},

					/*
					{_T("��"),_T("aye")},{_T("��"),_T("iye")},
					{_T("��"),_T("ayu")},{_T("��"),_T("uye")},
					{_T("��"),_T("iye")},{_T("��"),_T("eye")},

					{_T("�"),_T("ayo")},{_T("�"),_T("iyo")},
					{_T("�"),_T("oyo")},{_T("�"),_T("uyo")},
					{_T("��"),_T("iyo")},{_T("��"),_T("eyo")},

					{_T("��"),_T("ayu")},{_T("��"),_T("iyu")},
					{_T("��"),_T("oyu")},{_T("��"),_T("uyu")},
					{_T("��"),_T("iyu")},{_T("��"),_T("eyu")},

					{_T("��"),_T("aya")},{_T("��"),_T("iya")},
					{_T("��"),_T("oya")},{_T("��"),_T("uya")},
					{_T("��"),_T("iya")},{_T("��"),_T("eya")},

					{_T("��"),_T("ye")},{_T("��"),_T("yo")},
					{_T("��"),_T("yu")},{_T("��"),_T("ya")},
					*/

					{_T("�"),_T("b'o")},{_T("��"),_T("b'u")},{_T("��"),_T("b'a")},
					{_T("�"),_T("v'o")},{_T("��"),_T("v'u")},{_T("��"),_T("v'a")},
					{_T("�"),_T("g'o")},{_T("��"),_T("g'u")},{_T("��"),_T("g'a")},
					{_T("�"),_T("d'o")},{_T("��"),_T("d'u")},{_T("��"),_T("d'a")},
					{_T("�"),_T("j'o")},{_T("��"),_T("j'u")},{_T("��"),_T("j'a")},
					{_T("�"),_T("z'o")},{_T("��"),_T("z'u")},{_T("��"),_T("z'a")},
					{_T("�"),_T("k'o")},{_T("��"),_T("k'u")},{_T("��"),_T("k'a")},
					{_T("�"),_T("l'o")},{_T("��"),_T("l'u")},{_T("��"),_T("l'a")},
					{_T("�"),_T("m'o")},{_T("��"),_T("m'u")},{_T("��"),_T("m'a")},
					{_T("��"),_T("n'o")},{_T("��"),_T("n'u")},{_T("��"),_T("n'a")},
					{_T("�"),_T("p'o")},{_T("��"),_T("p'u")},{_T("��"),_T("p'a")},
					{_T("�"),_T("r'o")},{_T("��"),_T("r'u")},{_T("��"),_T("r'a")},
					{_T("�"),_T("s'o")},{_T("��"),_T("s'u")},{_T("��"),_T("s'a")},
					{_T("�"),_T("t'o")},{_T("��"),_T("t'u")},{_T("��"),_T("t'a")},
					{_T("��"),_T("f'o")},{_T("��"),_T("f'u")},{_T("��"),_T("f'a")},
					{_T("��"),_T("h'o")},{_T("��"),_T("h'u")},{_T("��"),_T("h'a")},
					{_T("��"),_T("c'o")},{_T("��"),_T("c'u")},{_T("��"),_T("c'a")},
					{_T("��"),_T("cho")},{_T("��"),_T("chu")},{_T("��"),_T("cha")},
					{_T("��"),_T("sho")},{_T("��"),_T("shu")},{_T("��"),_T("sha")},
					{_T("��"),_T("sh'o")},{_T("��"),_T("sh'u")},{_T("��"),_T("sh'a")},

					{_T("�"),_T("a")},{_T("�"),_T("b")},{_T("�"),_T("v")},
					{_T("�"),_T("g")},{_T("�"),_T("d")},{_T("�"),_T("e")},
					{_T("�"),_T("yo")},{_T("�"),_T("j")},{_T("�"),_T("z")},
					{_T("�"),_T("i")},{_T("�"),_T("y")},{_T("�"),_T("k")},
					{_T("�"),_T("l")},{_T("�"),_T("m")},{_T("�"),_T("n")},
					{_T("�"),_T("o")},{_T("�"),_T("p")},{_T("�"),_T("r")},
					{_T("�"),_T("s")},{_T("�"),_T("t")},{_T("�"),_T("u")},
					{_T("�"),_T("f")},{_T("�"),_T("h")},{_T("�"),_T("c")},
					{_T("�"),_T("ch")},{_T("�"),_T("sh")},{_T("�"),_T("sh'")},
					{_T("�"),_T("")},{_T("�"),_T("y")},{_T("�"),_T("'")},
					{_T("�"),_T("a'")},{_T("�"),_T("yu")},{_T("�"),_T("ya")}
				},
	/*latCyrMapping[] = {
					{_T("iye"),_T("��")},{_T("iyo"),_T("��")},{_T("iyu"),_T("��")},{_T("iya"),_T("��")},
					{_T("aye"),_T("��")},{_T("ayo"),_T("�")},{_T("ayu"),_T("��")},{_T("aya"),_T("��")},
					{_T("oye"),_T("��")},{_T("oyo"),_T("�")},{_T("oyu"),_T("��")},{_T("oya"),_T("��")},
					{_T("uye"),_T("��")},{_T("uyo"),_T("�")},{_T("uyu"),_T("��")},{_T("uya"),_T("��")},

					{_T("b'o"),_T("�")},{_T("b'u"),_T("��")},{_T("b'a"),_T("��")},{_T("b'i"),_T("��")},
					{_T("v'o"),_T("�")},{_T("v'u"),_T("��")},{_T("v'a"),_T("��")},{_T("v'i"),_T("��")},
					{_T("g'o"),_T("�")},{_T("g'u"),_T("��")},{_T("g'a"),_T("��")},{_T("g'i"),_T("��")},
					{_T("d'o"),_T("�")},{_T("d'u"),_T("��")},{_T("d'a"),_T("��")},{_T("d'i"),_T("��")},
					{_T("j'o"),_T("�")},{_T("j'u"),_T("��")},{_T("j'a"),_T("��")},{_T("ji"),_T("��")},
					{_T("z'o"),_T("�")},{_T("z'u"),_T("��")},{_T("z'a"),_T("��")},{_T("z'i"),_T("��")},
					{_T("k'o"),_T("�")},{_T("k'u"),_T("��")},{_T("k'a"),_T("��")},{_T("k'i"),_T("��")},
					{_T("l'o"),_T("�")},{_T("l'u"),_T("��")},{_T("l'a"),_T("��")},{_T("l'i"),_T("��")},
					{_T("m'o"),_T("�")},{_T("m'u"),_T("��")},{_T("m'a"),_T("��")},{_T("m'i"),_T("��")},
					{_T("n'o"),_T("��")},{_T("n'u"),_T("��")},{_T("n'a"),_T("��")},{_T("n'i"),_T("��")},
					{_T("p'o"),_T("�")},{_T("p'u"),_T("��")},{_T("p'a"),_T("��")},{_T("p'i"),_T("��")},
					{_T("r'o"),_T("�")},{_T("r'u"),_T("��")},{_T("r'a"),_T("��")},{_T("r'i"),_T("��")},
					{_T("s'o"),_T("�")},{_T("s'u"),_T("��")},{_T("s'a"),_T("��")},{_T("s'i"),_T("��")},
					{_T("t'o"),_T("�")},{_T("t'u"),_T("��")},{_T("t'a"),_T("��")},{_T("t'i"),_T("��")},
					{_T("f'o"),_T("��")},{_T("f'u"),_T("��")},{_T("f'a"),_T("��")},{_T("f'i"),_T("��")},
					{_T("h'o"),_T("��")},{_T("h'u"),_T("��")},{_T("h'a"),_T("��")},{_T("h'i"),_T("��")},
					{_T("c'o"),_T("��")},{_T("c'u"),_T("��")},{_T("c'a"),_T("��")},{_T("ci"),_T("��")},
					{_T("cho"),_T("��")},{_T("sho"),_T("��")},{_T("sh'o"),_T("��")},{_T("chi"),_T("��")},
					{_T("che"),_T("��")},{_T("she"),_T("��")},{_T("sh'e"),_T("��")},{_T("shi"),_T("��")},
					{_T("sh'i"),_T("��")},

					{_T("qu"),_T("��")},{_T("''"),_T("�")},
					{_T("ch"),_T("�")},{_T("sh"),_T("�")},{_T("sh'"),_T("�")},{_T("a'"),_T("�")},
					{_T("ye"),_T("�")},{_T("yo"),_T("�")},{_T("yu"),_T("�")},{_T("ya"),_T("�")},

					{_T("ay"),_T("��")},{_T("oy"),_T("��")},{_T("uy"),_T("��")},
					{_T("iy"),_T("��")},{_T("ey"),_T("��")},{_T("a'y"),_T("��")},

					{_T("a"),_T("�")},{_T("b"),_T("�")},{_T("c"),_T("�")},
					{_T("d"),_T("�")},{_T("e"),_T("�")},{_T("f"),_T("�")},
					{_T("g"),_T("�")},{_T("h"),_T("�")},{_T("i"),_T("�")},
					{_T("j"),_T("�")},{_T("k"),_T("�")},{_T("l"),_T("�")},
					{_T("m"),_T("�")},{_T("n"),_T("�")},{_T("o"),_T("�")},
					{_T("p"),_T("�")},{_T("q"),_T("�")},{_T("r"),_T("�")},
					{_T("s"),_T("�")},{_T("t"),_T("�")},{_T("u"),_T("�")},
					{_T("v"),_T("�")},{_T("w"),_T("�")},{_T("x"),_T("��")},
					{_T("y"),_T("�")},{_T("z"),_T("�")},{_T("'"),_T("�")}
				};*/
	latCyrMapping[] = {
					{_T("iye"),_T("��")},{_T("iyo"),_T("��")},{_T("iyu"),_T("��")},{_T("iya"),_T("��")},

					{_T("b'o"),_T("�")},{_T("b'u"),_T("��")},{_T("b'a"),_T("��")},{_T("by"),_T("��")},
					{_T("v'o"),_T("�")},{_T("v'u"),_T("��")},{_T("v'a"),_T("��")},{_T("vy"),_T("��")},
					{_T("g'o"),_T("�")},{_T("g'u"),_T("��")},{_T("g'a"),_T("��")},{_T("gy"),_T("��")},
					{_T("d'o"),_T("�")},{_T("d'u"),_T("��")},{_T("d'a"),_T("��")},{_T("dy"),_T("��")},
					{_T("j'o"),_T("�")},{_T("j'u"),_T("��")},{_T("j'a"),_T("��")},
					{_T("z'o"),_T("�")},{_T("z'u"),_T("��")},{_T("z'a"),_T("��")},{_T("zy"),_T("��")},
					{_T("k'o"),_T("�")},{_T("k'u"),_T("��")},{_T("k'a"),_T("��")},{_T("ky"),_T("��")},
					{_T("l'o"),_T("�")},{_T("l'u"),_T("��")},{_T("l'a"),_T("��")},{_T("ly"),_T("��")},
					{_T("m'o"),_T("�")},{_T("m'u"),_T("��")},{_T("m'a"),_T("��")},{_T("my"),_T("��")},
					{_T("n'o"),_T("��")},{_T("n'u"),_T("��")},{_T("n'a"),_T("��")},{_T("ny"),_T("��")},
					{_T("p'o"),_T("�")},{_T("p'u"),_T("��")},{_T("p'a"),_T("��")},{_T("py"),_T("��")},
					{_T("r'o"),_T("�")},{_T("r'u"),_T("��")},{_T("r'a"),_T("��")},{_T("ry"),_T("��")},
					{_T("s'o"),_T("�")},{_T("s'u"),_T("��")},{_T("s'a"),_T("��")},{_T("sy"),_T("��")},
					{_T("t'o"),_T("�")},{_T("t'u"),_T("��")},{_T("t'a"),_T("��")},{_T("ty"),_T("��")},
					{_T("f'o"),_T("��")},{_T("f'u"),_T("��")},{_T("f'a"),_T("��")},{_T("fy"),_T("��")},
					{_T("h'o"),_T("��")},{_T("h'u"),_T("��")},{_T("h'a"),_T("��")},{_T("hy"),_T("��")},
					{_T("c'o"),_T("��")},{_T("c'u"),_T("��")},{_T("c'a"),_T("��")},{_T("cy"),_T("��")},

					{_T("ci"),_T("��")},
					{_T("cho"),_T("��")},{_T("sho"),_T("��")},{_T("sh'o"),_T("��")},{_T("chi"),_T("��")},
					{_T("che"),_T("��")},{_T("she"),_T("��")},{_T("sh'e"),_T("��")},{_T("shi"),_T("��")},
					{_T("sh'i"),_T("��")},{_T("ji"),_T("��")},

					{_T("qu"),_T("��")},{_T("''"),_T("�")},
					{_T("ch"),_T("�")},{_T("sh"),_T("�")},{_T("sh'"),_T("�")},{_T("a'"),_T("�")},
					{_T("ye"),_T("�")},{_T("yo"),_T("�")},{_T("yu"),_T("�")},{_T("ya"),_T("�")},

					{_T("iy"),_T("��")},{_T("'iy"),_T("��")},

					{_T("a"),_T("�")},{_T("b"),_T("�")},{_T("c"),_T("�")},
					{_T("d"),_T("�")},{_T("e"),_T("�")},{_T("f"),_T("�")},
					{_T("g"),_T("�")},{_T("h"),_T("�")},{_T("i"),_T("�")},
					{_T("j"),_T("�")},{_T("k"),_T("�")},{_T("l"),_T("�")},
					{_T("m"),_T("�")},{_T("n"),_T("�")},{_T("o"),_T("�")},
					{_T("p"),_T("�")},{_T("q"),_T("�")},{_T("r"),_T("�")},
					{_T("s"),_T("�")},{_T("t"),_T("�")},{_T("u"),_T("�")},
					{_T("v"),_T("�")},{_T("w"),_T("�")},{_T("x"),_T("��")},
					{_T("y"),_T("�")},{_T("z"),_T("�")},{_T("'"),_T("�")}
				};

//������ ���
//���������������������
//��

OPT_PACK *loadDefaultsToPack(OPT_PACK &optPack, long i);
OPT_PACK *loadDBOptions(OPT_PACK &optPack, long i);

void initOptions()
{
	if (!loadDBOptions(cyrLatOptPack, 0))
		loadDefaultsToPack(cyrLatOptPack, 0);
	if (!loadDBOptions(latCyrOptPack, 1))
		loadDefaultsToPack(latCyrOptPack, 1);
	if (!loadDBOptions(custom1OptPack, 2))
		loadDefaultsToPack(custom1OptPack, 2);
	if (!loadDBOptions(custom2OptPack, 3))
		loadDefaultsToPack(custom2OptPack, 3);

	converters.push_back(&cyrLatOptPack);
	converters.push_back(&latCyrOptPack);
	converters.push_back(&custom1OptPack);
	converters.push_back(&custom2OptPack);
}

long ReadStringFromFile(HANDLE hFile, TCHAR *str, long iStrLen, TCHAR delim)
{
	DWORD bytesRead; long charsRead = 0;
	TCHAR data;
	if (iStrLen-- < 1)
		return 0;

	do 
	{
		ReadFile(hFile, &data, sizeof(data), &bytesRead, NULL);
		if (bytesRead == 2 && charsRead < iStrLen)
			str[charsRead++] = data;
		else
			break;
	} while (data != delim);
	str[charsRead] = 0;

	return charsRead;
}

DWORD FileOpen(const TCHAR *initDir, const TCHAR *title, TCHAR *FilePath, long maxFilePathLen)
{
	OPENFILENAME FOData;
	ZeroMemory(&FOData, sizeof(FOData));
	FOData.lpstrFilter = TranslateT("Option files (*.opt)\0*.opt\0\0"); FilePath[0]=0;
	FOData.lpstrFile = FilePath; FOData.nMaxFile = maxFilePathLen;
	FOData.lpstrTitle = title; FOData.lpstrInitialDir = initDir;
	FOData.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_DONTADDTORECENT | OFN_EXPLORER;
	FOData.lStructSize = sizeof(FOData);
	return GetOpenFileName(&FOData);
}

DWORD FileSave(const TCHAR *initDir, const TCHAR *title, TCHAR *FilePath, long maxFilePathLen)
{
	OPENFILENAME FOData;
	ZeroMemory(&FOData, sizeof(FOData));

	_tcscat(FilePath, _T(".opt"));
	FOData.lpstrFilter = TranslateT("Option files (*.opt)\0*.opt\0\0");
	FOData.lpstrFile = FilePath; FOData.nMaxFile = maxFilePathLen;
	FOData.lpstrTitle = title; FOData.lpstrInitialDir = initDir;
	FOData.Flags = OFN_PATHMUSTEXIST | OFN_DONTADDTORECENT | OFN_EXPLORER | OFN_OVERWRITEPROMPT;
	FOData.lStructSize = sizeof(FOData);
	return GetSaveFileName(&FOData);
}

//MapTableName and DelimList are processed here
LRESULT CALLBACK EditProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_GETDLGCODE:
		if (lParam && ((LPMSG)lParam)->message == WM_KEYDOWN) switch(((LPMSG)lParam)->wParam)
		{
		case VK_ESCAPE:
			{
				long i = SendDlgItemMessage(hwndDlg, IDC_MAPTABLESEL, CB_GETCURSEL, 0, NULL);
				if (hwnd == hwndMapTableName)
					SendMessage(hwnd,WM_SETTEXT,0,(LPARAM)(*converters[i]).name.c_str());
				else
					SendMessage(hwnd,WM_SETTEXT,0,(LPARAM)(*converters[i]).delimiters.c_str());
			}
		return DLGC_WANTMESSAGE;
		}
	break;
	case WM_CHAR:
		if (wParam == 27)
			return 0;
	break;
	}
	return CallWindowProc(hwnd == hwndMapTableName ? wpOrigMapTableName
													: wpOrigDelimList,
							hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK LVProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static long iLastItemHit = -1, iLastSubItemHit = -1;
	if (hwnd == hwndMapTableEdit)
	{
		switch (msg)
		{
		case WM_GETDLGCODE:
			if (lParam && ((LPMSG)lParam)->message == WM_KEYDOWN) switch(((LPMSG)lParam)->wParam)
			{
			case VK_RETURN:
				SendMessage(hwndMapTableEdit,WM_GETTEXT,MAX_MAPPINGLEN+1,(LPARAM)strBuf);
				if (_tcsnlen(strBuf,MAX_MAPPINGLEN+1) || iLastSubItemHit == 1)
					ListView_SetItemText(hwndMapTable,iLastItemHit,iLastSubItemHit,strBuf);
				if (iLastSubItemHit == 1)
				{
					ListView_GetItemText(hwndMapTable,iLastItemHit,0,strBuf,MAX_MAPPINGLEN+1);
					ListView_SetItemText(hwndMapTable,iLastItemHit,0,strBuf);
				}
			case VK_ESCAPE:
				SetWindowPos(hwndMapTableEdit,NULL,0,0,0,0,SWP_HIDEWINDOW);
			return DLGC_WANTMESSAGE;
			}
		break;
		case WM_CHAR:
			//Prevent processing Enter and Escape characters (hate this annoying beep)
			if (wParam == 13 || wParam == 27)
				return 0;
		break;
		}
		return CallWindowProc(wpOrigMapTableEdit, hwnd, msg, wParam, lParam);
	}
	else
	{
		switch (msg)
		{
		case WM_LBUTTONDBLCLK:
			{
				LVHITTESTINFO lvHitInfo;
				lvHitInfo.pt.x = LOWORD(lParam); lvHitInfo.pt.y = HIWORD(lParam);
				if (ListView_SubItemHitTest(hwnd,&lvHitInfo) != -1)
				{
					RECT rcSubItem;
					iLastItemHit = lvHitInfo.iItem; iLastSubItemHit = lvHitInfo.iSubItem;
					ListView_GetItemText(hwnd,lvHitInfo.iItem,lvHitInfo.iSubItem,strBuf,MAX_MAPPINGLEN+1);
					SendMessage(hwndMapTableEdit,WM_SETTEXT,0,(LPARAM)strBuf);
					ListView_GetSubItemRect(hwnd,lvHitInfo.iItem,lvHitInfo.iSubItem,LVIR_LABEL,&rcSubItem);
					SetWindowPos(hwndMapTableEdit,NULL,rcSubItem.left,rcSubItem.top,rcSubItem.right-rcSubItem.left,rcSubItem.bottom-rcSubItem.top,SWP_SHOWWINDOW);
					SetFocus(hwndMapTableEdit);
				}
				return 0;
			}
		case WM_COMMAND:
			if (LOWORD(wParam) != IDC_MAPTABLEEDIT || HIWORD(wParam) != EN_KILLFOCUS)
				break;
		case WM_MOUSEWHEEL:
		case WM_VSCROLL:
			SetWindowPos(hwndMapTableEdit,NULL,0,0,0,0,SWP_HIDEWINDOW);
		break;
		case WM_KEYDOWN:
			if (wParam == VK_DELETE)
			{
				long iSelItem = ListView_GetSelectionMark(hwndMapTable);
				if (iSelItem != -1 && iSelItem != ListView_GetItemCount(hwndMapTable) - 1)
					ListView_DeleteItem(hwndMapTable,iSelItem);
			}
		break;
		case WM_NOTIFY:
			if (((LPNMHDR)lParam)->code == HDN_ITEMCHANGING)
				if (((LPNMHEADER)lParam)->pitem->mask & HDI_WIDTH)
					return TRUE;
		break;
		}
		return CallWindowProc(wpOrigLV, hwnd, msg, wParam, lParam);
	}
	return 0;
}

int CALLBACK compareFunc(LPARAM i1, LPARAM i2, LPARAM lParamSort)
{
	ListView_GetItemText(hwndMapTable, i1, 0, strBuf, MAX_MAPPINGLEN+1);
	tstring str1(strBuf);
	ListView_GetItemText(hwndMapTable, i2, 0, strBuf, MAX_MAPPINGLEN+1);
	tstring str2(strBuf);

	if (str1.length() == str2.length())
		return str1.compare(str2);
	else
		return (int)str2.length()-(int)str1.length();
}

OPT_PACK *loadDefaultsToPack(OPT_PACK &optPack, long i)
{
	switch (i)
	{
	case 0:
		optPack.converter->clear();
		for (long curMap = 0; curMap < _countof(cyrLatMapping); curMap++)
			optPack.converter->addMapping(tstring(cyrLatMapping[curMap].from), tstring(cyrLatMapping[curMap].to));
		optPack.name = _T("Cyrillic to Latin");
		optPack.delimiters = _T(" .,:;?!\"\\/*-()�") SHADOW_DELIMS;
		optPack.hotkey = MAKEWORD('R', HOTKEYF_CONTROL);
		optPack.wbwMode = -1;
	return &optPack;
	case 1:
		optPack.converter->clear();
		for (long curMap = 0; curMap < _countof(latCyrMapping); curMap++)
			optPack.converter->addMapping(tstring(latCyrMapping[curMap].from), tstring(latCyrMapping[curMap].to));
		optPack.name = _T("Latin to Cyrillic");
		optPack.delimiters = _T(" .,:;?!\"\\/*-()�") SHADOW_DELIMS;
		optPack.hotkey = MAKEWORD('F', HOTKEYF_CONTROL);
		optPack.wbwMode = -1;
	return &optPack;
	case 2:
	case 3:
		optPack.converter->clear();
		if (i == 2)
			optPack.name = _T("Custom 1");
		else
			optPack.name = _T("Custom 2");
		optPack.delimiters = _T(" ") SHADOW_DELIMS;
		optPack.hotkey = NULL;
		optPack.wbwMode = 0;
	return &optPack;
	}
	return NULL;
}

void storeDBOptions(const OPT_PACK &optPack, long i)
{
	char convMap[15] = "ConvMap", convName[15] = "ConvName",
		convDelims[15] = "ConvDelims", convHotKey[15] = "ConvHKey",
		convWBWMode[15] = "ConvWBWM", strBuf[5];

	_itoa_s(i, strBuf, 10);
	strcat_s(convMap, strBuf);
	strcat_s(convName, strBuf);
	strcat_s(convDelims, strBuf);
	strcat_s(convHotKey, strBuf);
	strcat_s(convWBWMode, strBuf);

	tstring ts; ts << *(optPack.converter);
	DBWriteContactSettingWString(NULL, MODULENAME, convMap, ts.c_str());
	DBWriteContactSettingWString(NULL, MODULENAME, convName, optPack.name.c_str());
	tstring delimiters = optPack.delimiters.substr(0, optPack.delimiters.length()-SHADOW_DELIMSLEN);
	DBWriteContactSettingWString(NULL, MODULENAME, convDelims, delimiters.c_str());
	DBWriteContactSettingWord(NULL, MODULENAME, convHotKey, optPack.hotkey);
	DBWriteContactSettingByte(NULL, MODULENAME, convWBWMode, optPack.wbwMode);
}

OPT_PACK *loadDBOptions(OPT_PACK &optPack, long i)
{
	DBVARIANT dbv={0};
	
	char convMap[15] = "ConvMap", convName[15] = "ConvName",
		convDelims[15] = "ConvDelims", convHotKey[15] = "ConvHKey",
		convWBWMode[15] = "ConvWBWM", strBuf[5];

	_itoa_s(i, strBuf, 10);
	strcat_s(convMap, strBuf);
	strcat_s(convName, strBuf);
	strcat_s(convDelims, strBuf);
	strcat_s(convHotKey, strBuf);
	strcat_s(convWBWMode, strBuf);

	if (DBGetContactSettingWString(NULL,MODULENAME,convMap,&dbv))
		return NULL;
	tstring(dbv.pwszVal) >> *(optPack.converter);
	DBFreeVariant(&dbv);

	ZeroMemory(&dbv, sizeof(dbv));
	if (DBGetContactSettingWString(NULL,MODULENAME,convName,&dbv))
		return NULL;
	optPack.name = dbv.pwszVal;
	DBFreeVariant(&dbv);

	ZeroMemory(&dbv, sizeof(dbv));
	if (DBGetContactSettingWString(NULL,MODULENAME,convDelims,&dbv))
		return NULL;
	optPack.delimiters = dbv.pwszVal; optPack.delimiters += SHADOW_DELIMS;
	DBFreeVariant(&dbv);

	optPack.hotkey = DBGetContactSettingWord(NULL,MODULENAME,convHotKey,0);
	optPack.wbwMode = DBGetContactSettingByte(NULL,MODULENAME,convWBWMode,0);

	return &optPack;
}

bool storeFileOptions(const OPT_PACK &optPack)
{
	_tcscpy(strBuf, optPack.name.c_str());
	if (FileSave(NULL, TranslateT("Select destination"), strBuf, MAX_PATH))
	{
		HANDLE hFile = CreateFile(strBuf, GENERIC_WRITE, NULL, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			DWORD bytesWritten;
			WriteFile (hFile, optPack.name.c_str(), (optPack.name.length()+1)*sizeof(TCHAR), &bytesWritten, NULL);
			tstring ts(optPack.delimiters.substr(0, optPack.delimiters.length()-SHADOW_DELIMSLEN));
			WriteFile (hFile, ts.c_str(), (ts.length()+1)*sizeof(TCHAR), &bytesWritten, NULL);
			WriteFile (hFile, &optPack.hotkey,  sizeof(optPack.hotkey), &bytesWritten, NULL);
			WriteFile (hFile, &optPack.wbwMode, sizeof(optPack.wbwMode), &bytesWritten, NULL);
			ts.clear(); ts << *(optPack.converter);
			WriteFile (hFile, ts.c_str(), (ts.length()+1)*sizeof(TCHAR), &bytesWritten, NULL);
			CloseHandle(hFile);
			return true;
		}
	}
	return false;
}

OPT_PACK *loadFileOptions(OPT_PACK &optPack)
{
	if (FileOpen(NULL, TranslateT("Select source"), strBuf, MAX_PATH))
	{
		HANDLE hFile = CreateFile(strBuf, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			DWORD charsRead;
			charsRead = ReadStringFromFile(hFile, strBuf, MAX_MAPTBLNAMELEN+1, '\0');
			if (!charsRead || strBuf[charsRead-1] != '\0')
				goto loadFileOptions_CloseFileAndExit;
			optPack.name = strBuf;

			charsRead = ReadStringFromFile(hFile, strBuf, MAX_DELIMSLEN+1, '\0');
			if (!charsRead || strBuf[charsRead-1] != '\0')
				goto loadFileOptions_CloseFileAndExit;
			optPack.delimiters = strBuf; optPack.delimiters += SHADOW_DELIMS;

			ReadFile(hFile, &optPack.hotkey, sizeof(optPack.hotkey), &charsRead, NULL);
			if (charsRead != sizeof(optPack.hotkey))
				goto loadFileOptions_CloseFileAndExit;

			ReadFile(hFile, &optPack.wbwMode, sizeof(optPack.wbwMode), &charsRead, NULL);
			if (charsRead != sizeof(optPack.wbwMode))
				goto loadFileOptions_CloseFileAndExit;

			{
				tstring ts;
				do
				{
					charsRead = ReadStringFromFile(hFile, strBuf, STRBUFLEN, '\n');
					if (!charsRead)
						goto loadFileOptions_CloseFileAndExit;
					ts += strBuf;
				} while (strBuf[charsRead-1] != '\n');
				ts >> (*optPack.converter);
				CloseHandle(hFile);
				return &optPack;
			}
loadFileOptions_CloseFileAndExit:
			CloseHandle(hFile);
		}
	}
	return NULL;
}

void storeOptionsView(OPT_PACK &optPack)
{
	long iItemsCount = ListView_GetItemCount(hwndMapTable);
	optPack.converter->clear();
	for (long curItem = 0; curItem < iItemsCount-1; curItem++)
	{
		ListView_GetItemText(hwndMapTable, curItem, 0, strBuf, MAX_MAPPINGLEN+1);
		tstring from(strBuf);
		ListView_GetItemText(hwndMapTable, curItem, 1, strBuf, MAX_MAPPINGLEN+1);
		optPack.converter->addMapping(from, strBuf);
	}
	SendDlgItemMessage(hwndDlg, IDC_MAPTABLENAME, WM_GETTEXT, MAX_MAPTBLNAMELEN+1, (LPARAM)strBuf);
	optPack.name = strBuf;
	SendDlgItemMessage(hwndDlg, IDC_DELIMLIST, WM_GETTEXT, MAX_DELIMSLEN+1, (LPARAM)strBuf);
	optPack.delimiters = strBuf; optPack.delimiters += SHADOW_DELIMS;
	optPack.hotkey = SendDlgItemMessage(hwndDlg, IDC_HOTKEY, HKM_GETHOTKEY, NULL, NULL);
	optPack.wbwMode = IsDlgButtonChecked(hwndDlg, IDC_WBWCONV) == BST_CHECKED ? -1 : 0;
}

void loadOptionsView(const OPT_PACK &optPack)
{
	tstring mapping; mapping << *(optPack.converter); mapping.insert(mapping.length()-1, 2, '\r');
	bAdjustingOptionsView = true;
	ListView_DeleteAllItems(hwndMapTable);
	for (long cntr = 0, startPos = 0, len; mapping[startPos] != '\n'; startPos += len+1, cntr++)
	{
		len = mapping.find_first_of('\r', startPos) - startPos;
		LVITEM lvItem;
		lvItem.mask = LVIF_TEXT;
		lvItem.iItem = cntr >> 1;
		lvItem.iSubItem = cntr & 1;
		wstring substr = mapping.substr(startPos, len);
		lvItem.pszText = const_cast<TCHAR *>(substr.c_str());
		if (cntr & 1)
			ListView_SetItem(hwndMapTable,&lvItem);
		else
			ListView_InsertItem(hwndMapTable,&lvItem);
	}
	ListView_SortItemsEx(hwndMapTable, compareFunc, 0);
	SendDlgItemMessage(hwndDlg, IDC_MAPTABLENAME, WM_SETTEXT, NULL, (LPARAM)optPack.name.c_str());
	tstring delimiters = optPack.delimiters.substr(0, optPack.delimiters.length()-SHADOW_DELIMSLEN);
	SendDlgItemMessage(hwndDlg, IDC_DELIMLIST, WM_SETTEXT, NULL, (LPARAM)delimiters.c_str());
	SendDlgItemMessage(hwndDlg, IDC_HOTKEY, HKM_SETHOTKEY, optPack.hotkey, NULL);
	CheckDlgButton(hwndDlg, IDC_WBWCONV, optPack.wbwMode ? BST_CHECKED : BST_UNCHECKED);
	CheckDlgButton(hwndDlg, IDC_FPSCONV, optPack.wbwMode ? BST_UNCHECKED : BST_CHECKED);
	EnableWindow(GetDlgItem(hwndDlg, IDC_DELIMLIST), IsDlgButtonChecked(hwndDlg, IDC_WBWCONV) == BST_CHECKED);
	bAdjustingOptionsView = false;
}

void adjustListView()
{
	ListView_SetExtendedListViewStyleEx(hwndMapTable,
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT,
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	LVCOLUMN lvColumn;
	lvColumn.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	lvColumn.fmt = LVCFMT_LEFT;
	lvColumn.cx = 61;
	lvColumn.pszText = TranslateT("from");
	lvColumn.iSubItem = 0;
	ListView_InsertColumn(hwndMapTable, 0, &lvColumn);
	lvColumn.pszText = TranslateT("to");
	lvColumn.iSubItem = 1;
	ListView_InsertColumn(hwndMapTable, 1, &lvColumn);

	hwndMapTableEdit = CreateWindowEx(0,_T("EDIT"),NULL,WS_CHILD | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL | ES_LOWERCASE,0,0,0,0,hwndMapTable,(HMENU)IDC_MAPTABLEEDIT,hInst,NULL);
	SendMessage(hwndMapTableEdit,WM_SETFONT,SendMessage(hwndMapTable,WM_GETFONT,0,0),FALSE);
	SendMessage(hwndMapTableEdit,EM_SETLIMITTEXT,MAX_MAPPINGLEN,0);
	wpOrigLV = (WNDPROC) SetWindowLong(hwndMapTable, GWL_WNDPROC, (LONG)LVProc);
	wpOrigMapTableEdit = (WNDPROC) SetWindowLong(hwndMapTableEdit, GWL_WNDPROC, (LONG)LVProc);
}

INT_PTR CALLBACK OptDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{	
	switch(msg)
	{
	case WM_INITDIALOG:
		::hwndDlg = hwndDlg;
		TranslateDialogDefault(hwndDlg);
		hwndMapTable = GetDlgItem(hwndDlg, IDC_MAPTABLE);
		adjustListView();

		hwndMapTableName = GetDlgItem(hwndDlg, IDC_MAPTABLENAME);
		hwndDelimList = GetDlgItem(hwndDlg, IDC_DELIMLIST);
		SendMessage(hwndMapTableName, EM_SETLIMITTEXT, MAX_MAPTBLNAMELEN, 0);
		SendMessage(hwndDelimList, EM_SETLIMITTEXT, MAX_DELIMSLEN, 0);
		wpOrigMapTableName = (WNDPROC)SetWindowLong(hwndMapTableName, GWL_WNDPROC, (LONG)EditProc);
		wpOrigDelimList = (WNDPROC)SetWindowLong(hwndDelimList, GWL_WNDPROC, (LONG)EditProc);

		for (vector<OPT_PACK *>::const_iterator converter = converters.begin();
			converter != converters.end(); converter++)
			SendDlgItemMessage(hwndDlg, IDC_MAPTABLESEL, CB_INSERTSTRING, -1, (LPARAM)(*converter)->name.c_str());
		SendDlgItemMessage(hwndDlg, IDC_MAPTABLESEL, CB_SETCURSEL, 0, NULL);

		loadOptionsView(*converters[0]);
	break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_HOTKEY:
		case IDC_DELIMLIST:
		case IDC_MAPTABLENAME:
			if (HIWORD(wParam) == EN_CHANGE && !bAdjustingOptionsView)
				SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, NULL);
		break;
		case IDC_WBWCONV:
		case IDC_FPSCONV:
			if (HIWORD(wParam) == BN_CLICKED && !bAdjustingOptionsView)
				SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, NULL);
			EnableWindow(GetDlgItem(hwndDlg, IDC_DELIMLIST), IsDlgButtonChecked(hwndDlg, IDC_WBWCONV) == BST_CHECKED);
		break;
		case IDC_RESTOREBTN:
			if (HIWORD(wParam) == BN_CLICKED)
			{
				long i = SendDlgItemMessage(hwndDlg, IDC_MAPTABLESEL, CB_GETCURSEL, 0, NULL);
				Converter converter; OPT_PACK optPack = {&converter};
				if (loadDefaultsToPack(optPack, i))
				{
					loadOptionsView(optPack);
					SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, NULL);
				}
			}
		break;
		case IDC_IMPORTBTN:
			if (HIWORD(wParam) == BN_CLICKED)
			{
				Converter converter; OPT_PACK optPack = {&converter};
				if (loadFileOptions(optPack))
				{
					loadOptionsView(optPack);
					SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, NULL);
				}
				else
					MessageBox(hwndDlg, TranslateT("Reqeuest canceled or bad file format"), TranslateT("No data loaded"), MB_OK);
			}
		break;
		case IDC_EXPORTBTN:
			if (HIWORD(wParam) == BN_CLICKED)
			{
				Converter converter; OPT_PACK optPack = {&converter};
				storeOptionsView(optPack);
				if (!storeFileOptions(optPack))
					MessageBox(hwndDlg, TranslateT("Reqeuest canceled or file access denied"), TranslateT("No data saved"), MB_OK);
			}
		break;
		case IDC_MAPTABLESEL:
			if (HIWORD(wParam) == CBN_SELENDOK)
			{
				long i = SendMessage((HWND)lParam, CB_GETCURSEL, 0, NULL);
				loadOptionsView(*(converters[i]));
			}
		break;
		}
	break;
	case WM_NOTIFY:
		switch(((LPNMHDR)lParam)->idFrom)
		{
		case IDC_MAPTABLE:
			switch (((LPNMHDR)lParam)->code)
			{
			case LVN_ITEMCHANGED:
				if (!(((LPNMLISTVIEW)lParam)->uChanged & LVIF_TEXT))
					break;
				else if (((LPNMLISTVIEW)lParam)->iItem == ListView_GetItemCount(hwndMapTable) - 1)
				{
					long iItemCount = ListView_GetItemCount(hwndMapTable);
					ListView_GetItemText(hwndMapTable,iItemCount,0,strBuf,MAX_MAPPINGLEN+1);
					if (_tcsnlen(strBuf,MAX_MAPPINGLEN+1) != 0)
					{
						LVITEM lvItem;
						lvItem.mask = 0;
						lvItem.iItem = iItemCount;
						lvItem.iSubItem = 0;
						ListView_InsertItem(hwndMapTable,&lvItem);
					}
					else
						break;
				}
			case LVN_DELETEITEM:
				if (!bAdjustingOptionsView)
					SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, NULL);
			}
		break;
		default:
			if (((LPNMHDR)lParam)->idFrom == 0 && ((LPNMHDR)lParam)->code == PSN_APPLY)
			{
				//TODO: check, if delimiters correlate with mappings
				HWND hwndMapTableSel = GetDlgItem(hwndDlg, IDC_MAPTABLESEL);
				long i = SendMessage(hwndMapTableSel, CB_GETCURSEL, 0, NULL);

				SendMessage(hwndMapTableName, WM_GETTEXT, MAX_MAPTBLNAMELEN+1, (LPARAM)strBuf);

				WORD hotkey = SendDlgItemMessage(hwndDlg, IDC_HOTKEY, HKM_GETHOTKEY, NULL, NULL);
				for (long i2 = 0; i2 < (long)converters.size(); i2++)
					if (i != i2 && hotkey && converters[i2]->hotkey == hotkey)
					{
						MessageBox(hwndDlg, TranslateT("Same hotkey is already used"), TranslateT("Duplicated hotkey"), MB_OK | MB_ICONWARNING);
						SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, NULL);
						return PSNRET_INVALID;
					}

				if (_tcsnlen(strBuf,MAX_MAPTBLNAMELEN+1))
				{
					for (long i2 = 0; i2 < (long)converters.size(); i2++)
						if (i != i2 && !converters[i2]->name.compare(strBuf))
						{
							MessageBox(hwndDlg, TranslateT("Same mode name is already used"), TranslateT("Duplicated mode name"), MB_OK | MB_ICONWARNING);
							SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, NULL);
							return PSNRET_INVALID;
						}
					SendMessage(hwndMapTableSel, CB_DELETESTRING, (WPARAM)i, 0);
					SendMessage(hwndMapTableSel, CB_INSERTSTRING, (WPARAM)i, (LPARAM)strBuf);
					SendMessage(hwndMapTableSel, CB_SETCURSEL, (WPARAM)i, NULL);
				}
				else
				{
					bAdjustingOptionsView = true;
					SendMessage(hwndMapTableName,WM_SETTEXT,0,(LPARAM)(*converters[i]).name.c_str());
					bAdjustingOptionsView = false;
				}

				storeOptionsView(*(converters[i]));
				storeDBOptions(*(converters[i]), i);
			}
			return PSNRET_NOERROR;
		}
		break;
	}

	return 0;
}