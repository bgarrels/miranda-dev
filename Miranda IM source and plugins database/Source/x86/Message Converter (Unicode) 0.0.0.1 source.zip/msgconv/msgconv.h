#ifndef __MSGCONV_H__
#define __MSGCONV_H__

	#include <windows.h>
	#include <shlobj.h>
	#include <richedit.h>
	#include <vector>
	#include <string>

	#include "resource.h"
	
	#include "newpluginapi.h"
	#include "m_message.h"
	#include "m_database.h"
	#include "m_system.h"
	#include "m_options.h"
	#include "m_clist.h"
	#include "m_langpack.h"

	#include "Converter.h"
	#include "options.h"

	#define PLUGVERSION 0,0,0,1
	#define SPLUGVERSION #PLUGVERSION
	//#define MPLUGVERSION_INTERNAL(arg) PLUGIN_MAKE_VERSION(arg)
	//#define MPLUGVERSION MPLUGVERSION_INTERNAL(PLUGVERSION)
	#define MPLUGVERSION PLUGIN_MAKE_VERSION(0,0,0,1)
	#define MIID_MESSAGECONVERTER {0xbd95d966,0xc91e,0x4f02,{0xbb,0xf1,0x23,0x1a,0xeb,0xc3,0xd5,0x95}}

	#define MODULENAME "msgconv"

	#define MAX_DELIMSLEN			64
	#define MAX_MAPTBLNAMELEN		64
	#define MAX_MAPPINGLEN			64
	#define STRBUFLEN				16384

	typedef basic_string<TCHAR> tstring;
	
	extern HINSTANCE hInst;
	extern vector<OPT_PACK *> converters;
	extern TCHAR strBuf[STRBUFLEN];

#endif