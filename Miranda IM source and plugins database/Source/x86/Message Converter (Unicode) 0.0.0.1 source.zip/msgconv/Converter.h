#ifndef __CONVERTER_H__
#define __CONVERTER_H__
	
	#define WIN32_LEAN_AND_MEAN
	#include <windows.h>
	#include <shlobj.h>
	
	#include <string>
	#include <hash_map>
	#include <map>
	#include <algorithm>
	
	using namespace std;

	typedef basic_string<TCHAR> tstring;

	class Converter
	{
	//converts the whole mappings to a string
	friend tstring &operator<< (tstring &dest, const Converter &converter);
	//reads the string into the mappings of the converter
	friend tstring &operator>> (tstring &dest, Converter &converter);
	public:
		Converter();

		void clear() { maps.clear(); }
		//returns true, if new mapping created, or false, if old mapping modified
		bool addMapping(const tstring &from, const tstring &to);
		//converts given tstring to it's mapped equivalent using maps
		tstring convert(const tstring &str, long &pos);
		//converts given tstring to it's mapped equivalent using locales
		//tstring convert(tstring &str, HKL from, HKL to);
	private:
		typedef pair<tstring,tstring> Tstr_Pair;
		typedef pair<long, stdext::hash_map<tstring,tstring>> IntMap_Pair;
		
		map<long, stdext::hash_map<tstring,tstring>> maps;

		class Node
		{
		public:
			Node(const tstring &data);
			~Node();
			//returns an increment count of outdated nodes
			//(-1 if no new nodes created; 0 if one new node created; 1 if two new nodes created)
			long updatePart(long begin, long end, tstring &newStr);
			//returns a string, assigned to this node
			const tstring &getData() const;
			//returns NULL if all following nodes are updated or the next outdated node otherwise
			Node *forwardNext();
			//returns NULL if all nodes are updated or the next outdated node otherwise
			Node *roundNext();
			//returns the nearest preceding node (no matter updated or not)
			Node *nearestPrev();
			//returns the nearest following node (no matter updated or not)
			Node *nearestNext();
			//returns the whole string, represented by the nodes chain
			tstring accumulateString(const Node *const posNode, long &pos) const;
		private:
			tstring data;
			bool updated;
			Node *prev;
			Node *next;
			Node *prevUpd;
			Node *nextUpd;
		};
	};

#endif