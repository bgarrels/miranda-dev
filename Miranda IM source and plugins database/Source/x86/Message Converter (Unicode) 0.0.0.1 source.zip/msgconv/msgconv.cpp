#include "msgconv.h"
#include <map>

PLUGINLINK *pluginLink;
HANDLE hMsgWndOpenHook, hMirModulesLoadedHook, hOptInitHook, hMsgIconPressedHook, hMenuPrebuildHook;
HANDLE hRootMenuItem, *hRootMenuSubItems;

struct WND_STATE
{
	WNDPROC wpOrig;
	HANDLE hContact;
	HWND hwndInput;
};

std::map<HWND, WND_STATE> wndState;

TCHAR strBuf[STRBUFLEN];

vector<OPT_PACK *> converters;

void adjustPosDown(const tstring &to, const tstring &from, long &pos1, long &pos2)
{
	long offset1 = 0, offset2 = 0;
	for (unsigned long fromPos = 0, toPos = 0; fromPos < from.length() && toPos < to.length(); fromPos++, toPos++)
		if (from[fromPos] != to[toPos])
		{
			fromPos++, toPos++;
			if (pos1 < (long)fromPos && pos2 < (long)fromPos)
				break;
			do
			{
				if (pos1 >= (long)fromPos)
					offset1++;
				if (pos2 >= (long)fromPos)
					offset2++;
				fromPos++;
			} while (fromPos < from.length() && toPos < to.length() && from[fromPos] != to[toPos]);
		}
	pos1 -= offset1;
	pos2 -= offset2;
}

void adjustPosUp(const tstring &from, const tstring &to, long &pos1)
{
	long offset = 0;
	for (unsigned long fromPos = 0, toPos = 0; fromPos < from.length() && toPos < to.length(); fromPos++, toPos++)
		if (from[fromPos] != to[toPos])
		{
			fromPos++, toPos++;
			if (pos1 < (long)fromPos)
				break;
			do
			{
				offset++;
				toPos++;
			} while (fromPos < from.length() && toPos < to.length() && from[fromPos] != to[toPos]);
		}
	pos1 += offset;
}

//returns word number starting from -1 (for previous non-existent word)
//up to word count plus one (if cursorPos == source.length) or
//-2 if cursorPos is outside of the source
//word.length is 0 if cursorPos belongs to no word
long extractWordByPos (long cursorPos, const tstring &source, const tstring &delimiters, tstring &front, tstring &word, tstring &rear)
{
	front.clear(); word.clear(); rear.clear();
	if (cursorPos < 0 || cursorPos > (long)source.length())
		return -1;
	long curPos = source.find_first_not_of(delimiters, 0);
	if (curPos == source.npos)
	{
		front = source;
		return 0;
	}

	long wordNum = 0, wordStart = curPos, wordEnd = -1;
	while(curPos < cursorPos)
	{
		curPos = source.find_first_of(delimiters, curPos);
		wordEnd = curPos == source.npos ? source.length() : curPos;
		if (curPos == source.npos || curPos >= cursorPos)
			break;

		wordNum++;

		curPos = source.find_first_not_of(delimiters, curPos);
		wordStart = curPos == source.npos ? source.length() : curPos;
		if (curPos == source.npos)
			break;
	}

	if (wordStart < wordEnd) //cursorPos can equal only to wordEnd
	{
		front = source.substr(0, wordStart);
		word = source.substr(wordStart, wordEnd-wordStart);
		rear = source.substr(wordEnd);
	}
	else	//wordEnd < wordStart; cursorPos can equal only to wordStart
	{
		if (cursorPos == wordStart)
		{
			wordEnd = source.find_first_of(delimiters, wordStart);
			if (wordEnd == source.npos)
				wordEnd = source.length();

			front = source.substr(0, wordStart);
			word = source.substr(wordStart, wordEnd-wordStart);
			rear = source.substr(wordEnd);
		}
		else
		{
			front = source.substr(0, wordStart);
			rear = source.substr(wordStart);
			wordNum--;
		}
	}
	return wordNum;
}

DWORD CALLBACK EditStreamInCallback(DWORD_PTR dwCookie, LPBYTE pbBuff, LONG cb, LONG *pcb)
{
	struct BUF_STATE
	{
		long sizeInBytes;
		const TCHAR *src;
	} *lpBufState = (BUF_STATE *)dwCookie;

	if (cb > lpBufState->sizeInBytes)
		cb = lpBufState->sizeInBytes;

	memcpy (pbBuff, lpBufState->src, cb);

	lpBufState->sizeInBytes -= cb;
	lpBufState->src += cb/sizeof(TCHAR);
	*pcb = cb;
	return 0;
}

void SetRichEditText(HWND hwnd, const TCHAR *src, long sizeInBytes, bool selection = false)
{
	EDITSTREAM editStream;
	struct BUF_STATE
	{
		long sizeInBytes;
		const TCHAR *src;
	} bufState = {sizeInBytes, src};

	editStream.dwCookie = (DWORD_PTR)&bufState;
	editStream.dwError = 0;
	editStream.pfnCallback = EditStreamInCallback;
	SendMessage(hwnd, EM_STREAMIN, selection ? SF_TEXT | SF_UNICODE | SFF_SELECTION : SF_TEXT | SF_UNICODE, (LPARAM) &editStream);
}

DWORD CALLBACK EditStreamOutCallback(DWORD_PTR dwCookie, LPBYTE pbBuff, LONG cb, LONG *pcb)
{
	struct BUF_STATE
	{
		long sizeInBytes;
		TCHAR *dest;
	} *lpBufState = (BUF_STATE *)dwCookie;

	if (cb > lpBufState->sizeInBytes - (long)sizeof(TCHAR))
		cb = lpBufState->sizeInBytes - (long)sizeof(TCHAR);

	memcpy (lpBufState->dest, pbBuff, cb);

	lpBufState->sizeInBytes -= cb;
	lpBufState->dest += cb/sizeof(TCHAR);
	lpBufState->dest[0] = 0;
	*pcb = cb;
	return 0;
}

TCHAR *GetRichEditText(HWND hwnd, TCHAR *dest, long sizeInBytes, bool selection = false)
{
	struct BUF_STATE
	{
		long sizeInBytes;
		TCHAR *dest;
	} bufState = {sizeInBytes, dest};

	EDITSTREAM editStream;
	editStream.dwCookie = (DWORD_PTR)&bufState;
	editStream.dwError = 0;
	editStream.pfnCallback = EditStreamOutCallback;
	SendMessage(hwnd, EM_STREAMOUT, selection ? SF_TEXT | SF_UNICODE | SFF_SELECTION : SF_TEXT | SF_UNICODE, (LPARAM) &editStream);
	return dest;
}

BYTE GetShiftState()
{
	return
		(GetKeyState(VK_SHIFT)<0 ? HOTKEYF_SHIFT : 0) |
		(GetKeyState(VK_CONTROL)<0 ? HOTKEYF_CONTROL : 0) |
		(GetKeyState(VK_MENU)<0 ? HOTKEYF_ALT : 0);
}

void ConvertEditText(HWND hwnd, Converter *converter)
{
	CHARRANGE selection; LONG newMax = -1;
	SendMessage(hwnd, EM_EXGETSEL, 0, (LPARAM)&selection);

	if (selection.cpMin == selection.cpMax)
	{
		newMax = selection.cpMax;

		GETTEXTEX gte = {STRBUFLEN*sizeof(TCHAR), GT_DEFAULT, 1200, NULL, NULL};
		SendMessage (hwnd, EM_GETTEXTEX, (WPARAM)&gte, (LPARAM)strBuf);
		tstring tsShort(strBuf);
		GetRichEditText(hwnd, strBuf, STRBUFLEN*sizeof(TCHAR));
		SendMessage(hwnd, EM_SETSEL, (WPARAM)0, (LPARAM)-1);

		adjustPosUp(tsShort, strBuf, newMax);
	}
	else
		GetRichEditText(hwnd, strBuf, STRBUFLEN*sizeof(TCHAR), true);

	tstring ts = converter->convert(strBuf, newMax);

	if (selection.cpMin == selection.cpMax)
	{
		selection.cpMax = selection.cpMin = newMax;

		SETTEXTEX ste = {ST_KEEPUNDO | ST_SELECTION, 1200};
		SendMessage(hwnd, EM_SETTEXTEX, (WPARAM)&ste, (LPARAM)ts.c_str());

		GETTEXTEX gte = {STRBUFLEN*sizeof(TCHAR), GT_DEFAULT, 1200, NULL, NULL};
		SendMessage (hwnd, EM_GETTEXTEX, (WPARAM)&gte, (LPARAM)strBuf);
		adjustPosDown(strBuf, ts, selection.cpMin, selection.cpMax);
	}
	else
	{
		SetRichEditText(hwnd, ts.c_str(), ts.length()*sizeof(TCHAR), true);
		selection.cpMax = selection.cpMin + newMax;
	}

	SendMessage(hwnd, EM_EXSETSEL, 0, (LPARAM)&selection);
}

//returns true if the WM_CHAR message should be suppressed
bool ConvertEditCurWord(HWND hwnd, OPT_PACK *optPack, TCHAR ch)
{
	bool suppress = false;
	CHARRANGE selection;
	SendMessage(hwnd, EM_EXGETSEL, 0, (LPARAM)&selection);
	GETTEXTEX gte = {STRBUFLEN*sizeof(TCHAR), GT_DEFAULT, 1200, NULL, NULL};
	SendMessage (hwnd, EM_GETTEXTEX, (WPARAM)&gte, (LPARAM)strBuf);

	if (selection.cpMin == selection.cpMax)
	{
		tstring tsShort(strBuf), tsLong(GetRichEditText(hwnd, strBuf, STRBUFLEN*sizeof(TCHAR))), front, word, rear;

		if (ch == '\r')
			selection.cpMin--, selection.cpMax--;

		long adjustedSelPos = selection.cpMin, oldSelPos = selection.cpMin;
		adjustPosUp(tsShort, tsLong, adjustedSelPos);
		extractWordByPos(adjustedSelPos, tsLong, optPack->delimiters, front, word, rear);
		if (word.length() > 0)
		{
			selection.cpMin = front.length(); selection.cpMax = front.length() + word.length();
			adjustPosDown(tsShort, tsLong, selection.cpMin, selection.cpMax);
			SendMessage(hwnd, EM_EXSETSEL, 0, (LPARAM)&selection);

			long newWordLen = word.length();
			tsLong = optPack->converter->convert(word, newWordLen);

			SetRichEditText(hwnd, tsLong.c_str(), tsLong.length()*sizeof(TCHAR), true);

			selection.cpMax = selection.cpMin = oldSelPos + newWordLen - word.length();
			if (ch == '\r')
				selection.cpMin++, selection.cpMax++, suppress = true;
			SendMessage(hwnd, EM_EXSETSEL, 0, (LPARAM)&selection);
		}
	}
	return suppress;
}

LRESULT CALLBACK InputWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	WNDPROC wpOrig = wndState[hwnd].wpOrig;
	switch (msg)
	{
	case WM_DESTROY:
		SetWindowLong(hwnd, GWL_WNDPROC, (LONG)wpOrig);
		wndState.erase(hwnd);
	break;
	case WM_KEYDOWN:
		for (vector<OPT_PACK *>::const_iterator optPack = converters.begin();
			optPack != converters.end(); optPack++)
			if (MAKEWORD(wParam, GetShiftState()) == (*optPack)->hotkey)
			{
				ConvertEditText(hwnd, (*optPack)->converter);
				return 0;
			}
	break;
	case WM_CHAR:
		if (DBGetContactSettingByte(wndState[hwnd].hContact, MODULENAME, "ConvMode", 0))
		{
			BYTE convNum = DBGetContactSettingByte(wndState[hwnd].hContact, MODULENAME, "ConvNum", 0);
			OPT_PACK *optPack = converters[convNum];
			if (optPack->wbwMode &&	optPack->delimiters.find_first_of((TCHAR)wParam) != tstring::npos)
				if (ConvertEditCurWord(hwnd, optPack, (TCHAR)wParam))
					return 0;
		}
	break;
	}
	
	return CallWindowProc(wpOrig, hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK OwnerWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	WNDPROC wpOrig = wndState[hwnd].wpOrig;
	switch (msg)
	{
	case WM_DESTROY:
		SetWindowLong(hwnd, GWL_WNDPROC, (LONG)wpOrig);
		wndState.erase(hwnd);
	break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
		case 1624:
			if (DBGetContactSettingByte(wndState[hwnd].hContact, MODULENAME, "ConvMode", 0))
			{
				BYTE convNum = DBGetContactSettingByte(wndState[hwnd].hContact, MODULENAME, "ConvNum", 0);
				HWND hwndInput = wndState[hwnd].hwndInput;
				OPT_PACK *optPack = converters[convNum];
				if (optPack->wbwMode)
					ConvertEditCurWord(hwndInput, optPack, 0);
				else
					ConvertEditText(hwndInput, optPack->converter);
			}
		break;
		}
	break;
	}
	return CallWindowProc(wpOrig, hwnd, msg, wParam, lParam);
}

void ModifyIcon(HANDLE hContact, BYTE convModeAuto)
{
	if (!ServiceExists(MS_MSG_ADDICON))
		return;

	StatusIconData sid = {0};
	sid.cbSize = sizeof(sid);
	sid.szModule = LPGEN(MODULENAME);

	sid.dwId = 0;
	sid.flags = convModeAuto ? MBF_HIDDEN : 0;
	CallService(MS_MSG_MODIFYICON, (WPARAM)hContact, (LPARAM)&sid);

	sid.dwId = 1;
	sid.flags = convModeAuto ? 0 : MBF_HIDDEN;
	CallService(MS_MSG_MODIFYICON, (WPARAM)hContact, (LPARAM)&sid);
}

int IconClickProc(WPARAM wParam, LPARAM lParam)
{
	HANDLE hContact = (HANDLE)wParam;
	StatusIconClickData *sicd = (StatusIconClickData *)lParam;
	
	if (!strcmp(sicd->szModule, MODULENAME))
	{
		BYTE convModeAuto = DBGetContactSettingByte(hContact, MODULENAME, "ConvMode", 0);

		if (sicd->flags & MBCF_RIGHTBUTTON)
		{
			BYTE convNum = DBGetContactSettingByte(hContact, MODULENAME, "ConvNum", 0);

			HMENU hMenu = CreatePopupMenu();
			for (unsigned i = 0; i < converters.size(); i++)
				AppendMenu(hMenu, i == convNum && convModeAuto ? MF_STRING | MF_CHECKED : MF_STRING, i+1, converters[i]->name.c_str());
			AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
			AppendMenu(hMenu, convModeAuto ? MF_STRING : MF_STRING | MF_CHECKED, converters.size()+1, TranslateT("None"));
			convNum = TrackPopupMenu(hMenu, TPM_RETURNCMD | TPM_NONOTIFY, sicd->clickLocation.x, sicd->clickLocation.y, 0, GetForegroundWindow(), NULL);
			DestroyMenu(hMenu);

			if (convNum)
			{
				if (convNum <= converters.size())
				{
					DBWriteContactSettingByte(hContact, MODULENAME, "ConvNum", convNum-1);
					convModeAuto = -1;
				}
				else
					convModeAuto = 0;
			}
		}
		else
			convModeAuto = ~convModeAuto;

		DBWriteContactSettingByte(hContact, MODULENAME, "ConvMode", convModeAuto);
		ModifyIcon(hContact, convModeAuto);
	}
	return 0;
}

void fillCListMenuItem(CLISTMENUITEM &clmi, const TCHAR *name, DWORD flags, int pos, HGENMENU hParent, int popupPos)
{
	ZeroMemory(&clmi, sizeof(clmi));
	clmi.cbSize = sizeof(clmi);
	clmi.ptszName = const_cast<TCHAR *>(name);
	clmi.flags = flags;
	clmi.position = pos;
	clmi.pszService = MODULENAME"/ContactMenu";
	clmi.hParentMenu = hParent;
	clmi.popupPosition = popupPos;
}

int MenuClickProc(WPARAM wParam, LPARAM lParam)
{
	HANDLE hContact = (HANDLE)wParam;
	if (hContact)
	{
		BYTE convNum = (BYTE)lParam, convModeAuto;
		if (convNum < converters.size())
		{
			DBWriteContactSettingByte(hContact, MODULENAME, "ConvNum", convNum);
			convModeAuto = -1;
		}
		else
			convModeAuto = 0;
		DBWriteContactSettingByte(hContact, MODULENAME, "ConvMode", convModeAuto);
		ModifyIcon(hContact, convModeAuto);
	}
	return 0;
}

int MenuPrebuildProc(WPARAM wParam, LPARAM lParam)
{
	CLISTMENUITEM clmi;
	HANDLE hContact = (HANDLE)wParam;

	if (hContact)
	{
		BYTE convModeAuto = DBGetContactSettingByte(hContact, MODULENAME, "ConvMode", 0);
		BYTE convNum = DBGetContactSettingByte(hContact, MODULENAME, "ConvNum", 0);

		fillCListMenuItem(clmi, NULL, CMIM_ICON, 0x80000000, NULL, 0);
		clmi.hIcon = LoadIcon(hInst, convModeAuto ? MAKEINTRESOURCE(IDI_ON) : MAKEINTRESOURCE(IDI_OFF));
		CallService(MS_CLIST_MODIFYMENUITEM, (WPARAM)hRootMenuItem, (LPARAM)&clmi);

		for (unsigned i = 0; i < converters.size(); i++)
		{
			fillCListMenuItem(clmi, converters[i]->name.c_str(), convNum == i && convModeAuto ? 
				CMIM_FLAGS | CMIM_NAME | CMIF_TCHAR | CMIF_ROOTHANDLE | CMIF_CHILDPOPUP | CMIF_CHECKED :
			CMIM_FLAGS | CMIM_NAME | CMIF_TCHAR | CMIF_ROOTHANDLE | CMIF_CHILDPOPUP,
				i, (HGENMENU)hRootMenuItem, i);
			CallService(MS_CLIST_MODIFYMENUITEM, (WPARAM)hRootMenuSubItems[i], (LPARAM)&clmi);
		}

		fillCListMenuItem(clmi, NULL, convModeAuto ? 
			CMIM_FLAGS | CMIF_TCHAR | CMIF_ROOTHANDLE | CMIF_CHILDPOPUP :
		CMIM_FLAGS | CMIF_TCHAR | CMIF_ROOTHANDLE | CMIF_CHILDPOPUP | CMIF_CHECKED,
			100000, (HGENMENU)hRootMenuItem, converters.size());
		CallService(MS_CLIST_MODIFYMENUITEM, (WPARAM)hRootMenuSubItems[converters.size()], (LPARAM)&clmi);
	}
	return 0;
}

int MsgWndOpenProc(WPARAM wParam, LPARAM lParam)
{
	MessageWindowEventData *mwed = (MessageWindowEventData *)lParam;
	if (mwed->uType == MSG_WINDOW_EVT_OPEN)
	{
		HWND hwndInput = mwed->hwndInput, hwndOwner = mwed->hwndWindow;
		
		wndState[hwndInput].wpOrig = (WNDPROC) SetWindowLong(hwndInput, GWL_WNDPROC, (LONG)InputWndProc);
		wndState[hwndInput].hContact = mwed->hContact;
		wndState[hwndInput].hwndInput = hwndInput;

		wndState[hwndOwner].wpOrig = (WNDPROC) SetWindowLong(hwndOwner, GWL_WNDPROC, (LONG)OwnerWndProc);
		wndState[hwndOwner].hContact = mwed->hContact;
		wndState[hwndOwner].hwndInput = hwndInput;

		ModifyIcon(mwed->hContact, DBGetContactSettingByte(mwed->hContact, MODULENAME, "ConvMode", 0));
	}

	return 0;
}

int OptInitProc(WPARAM wParam, LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp = { 0 };
	odp.cbSize    = sizeof(odp);
	odp.hInstance = hInst;
	odp.ptszGroup  = LPGENT("Message Sessions");
	odp.ptszTitle  = LPGENT("Message Converter");
	odp.flags = ODPF_BOLDGROUPS | ODPF_TCHAR;

	odp.pszTemplate	= MAKEINTRESOURCEA(IDD_OPT_MAIN);
	odp.pfnDlgProc	= OptDlgProc;
	CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);

	return 0;
}

int MirModulesLoadedProc(WPARAM wParam, LPARAM lParam)
{
	initOptions();

	hMsgWndOpenHook = HookEvent(ME_MSG_WINDOWEVENT, MsgWndOpenProc);

	hOptInitHook = HookEvent(ME_OPT_INITIALISE, OptInitProc);

	if (ServiceExists(MS_MSG_ADDICON))
	{
		StatusIconData sid = {0};
		sid.cbSize = sizeof(sid);
		sid.szModule = LPGEN(MODULENAME);
		sid.flags = 0;

		sid.dwId = 0;
		sid.szTooltip = Translate("msgconv mode: manual");
		sid.hIcon = sid.hIconDisabled = LoadIcon(hInst, MAKEINTRESOURCE(IDI_OFF));
		CallService(MS_MSG_ADDICON, 0, (LPARAM)&sid);

		sid.dwId = 1;
		sid.szTooltip = Translate("msgconv mode: auto");
		sid.hIcon = sid.hIconDisabled = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ON));
		CallService(MS_MSG_ADDICON, 0, (LPARAM)&sid);

		hMsgIconPressedHook = HookEvent(ME_MSG_ICONPRESSED, IconClickProc);
	}

	CreateServiceFunction(MODULENAME"/ContactMenu", MenuClickProc);
	CLISTMENUITEM clmi;
	fillCListMenuItem(clmi, TranslateT("msg&conv mode"), CMIF_TCHAR | CMIF_ROOTHANDLE | CMIF_ROOTPOPUP, 0x80000000, NULL, 0);
	hRootMenuItem = (HANDLE)CallService(MS_CLIST_ADDCONTACTMENUITEM, 0, (LPARAM)&clmi);
	hRootMenuSubItems = new HANDLE[converters.size()+1];
	for (unsigned i = 0; i < converters.size(); i++)
	{
		fillCListMenuItem(clmi, _T(""), CMIF_TCHAR | CMIF_ROOTHANDLE | CMIF_CHILDPOPUP, i, (HGENMENU)hRootMenuItem, i);
		hRootMenuSubItems[i] = (HANDLE)CallService(MS_CLIST_ADDCONTACTMENUITEM, 0, (LPARAM)&clmi);
	}
	fillCListMenuItem(clmi, TranslateT("None"), CMIF_TCHAR | CMIF_ROOTHANDLE | CMIF_CHILDPOPUP, 100000, (HGENMENU)hRootMenuItem, converters.size());
	hRootMenuSubItems[converters.size()] = (HANDLE)CallService(MS_CLIST_ADDCONTACTMENUITEM, 0, (LPARAM)&clmi);
	hMenuPrebuildHook = HookEvent(ME_CLIST_PREBUILDCONTACTMENU, MenuPrebuildProc);

	return 0;
}

extern "C" __declspec(dllexport) int Load(PLUGINLINK *link)
{
	pluginLink = link;
	hMirModulesLoadedHook = HookEvent(ME_SYSTEM_MODULESLOADED, MirModulesLoadedProc);
	return 0;
}

extern "C" __declspec(dllexport) int Unload(void)
{
	UnhookEvent(hOptInitHook);
	UnhookEvent(hMsgWndOpenHook);
	UnhookEvent(hMirModulesLoadedHook);
	if (ServiceExists(ME_MSG_ICONPRESSED))
		UnhookEvent(hMsgIconPressedHook);
	UnhookEvent(hMenuPrebuildHook);

	return 0;
}

const MUUID interfaces[] = {MIID_MESSAGECONVERTER, MIID_LAST};
extern "C" __declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

PLUGININFOEX pluginInfo =
{
	sizeof(PLUGININFOEX),
	"Message Converter Unicode",
	MPLUGVERSION,
	"Allows to convert message text using user-defined mappings.",
	"l.inc",
	"",
	"everyone",
	"",
	UNICODE_AWARE,
	0,
	MIID_MESSAGECONVERTER
};
extern "C" __declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	return &pluginInfo;
}