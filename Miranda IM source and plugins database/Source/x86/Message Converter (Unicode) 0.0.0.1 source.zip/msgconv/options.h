#ifndef __OPTIONS_H__
#define __OPTIONS_H__

	#include "msgconv.h"

	struct OPT_PACK
	{
		Converter *converter;
		tstring name;
		tstring delimiters;
		WORD hotkey;
		WORD wbwMode; //word-by-word mode
	};

	INT_PTR CALLBACK OptDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
	void initOptions();
#endif