/* Module:  imoproxy.c
   Purpose: Proxy-DLL for Miranda IM to load imo2sproxy as plugin
   Author:  leecher
   Date:    26.10.2009
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <prsht.h>
#include <commdlg.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#pragma comment (lib, "Ws2_32.lib")
#include <stdio.h>
#include "imo2sproxy.h"
#include "headers_c/newpluginapi.h"
#include "headers_c/m_langpack.h"
#include "headers_c/m_options.h"
#include "headers_c/m_database.h"
#include "headers_c/m_system.h"
#include "resource.h"

// Crash dumper
#ifdef _DEBUG
void CrashLog (const char *pszFormat, ...)
{
	static FILE *fpLog = NULL;
	char szLine[1024];
	va_list ap;

	if (!fpLog) fpLog=fopen("imoproxy.log", "a");
	va_start(ap, pszFormat);
	_vsnprintf(szLine, sizeof(szLine), pszFormat, ap); 
	va_end(ap); 

	if (fpLog)
	{
		fprintf (fpLog, "%s", szLine);
		fflush (fpLog);
	}
}
#define LOG(_args_) CrashLog _args_ 
#include "crash.c"
#endif


PLUGINLINK *pluginLink;
HINSTANCE m_hInst;
HANDLE m_hOptHook=NULL, m_hThread=NULL;
PLUGINLINK *pluginLink;
IMO2SPROXY m_proxy={0};
BOOL m_bHasConsole=FALSE;

#define ANY_SIZE 1

typedef struct _MIB_IPADDRROW {
  DWORD          dwAddr;
  DWORD          dwIndex;
  DWORD          dwMask;
  DWORD          dwBCastAddr;
  DWORD          dwReasmSize;
  unsigned short unused1;
  unsigned short wType;
}MIB_IPADDRROW, *PMIB_IPADDRROW;

typedef struct _MIB_IPADDRTABLE {
  DWORD         dwNumEntries;
  MIB_IPADDRROW table[ANY_SIZE];
}MIB_IPADDRTABLE, *PMIB_IPADDRTABLE;


// Plugin Info
#define PINFO \
	"imo2sproxy-Plugin", \
	PLUGIN_MAKE_VERSION(1,0,0,12), \
	"Tunnelling Skype traffic via imo.im Web service", \
	"leecher", \
	"leecher@dose.0wnz.at", \
	"� 2010 leecher", \
	"http://dose.0wnz.at", \
	0,	\
	0		//doesn't replace anything built-in


PLUGININFO pluginInfo = {
	sizeof(PLUGININFO),
	PINFO
};

// New plugininfo 
PLUGININFOEX pluginInfoEx = {
	sizeof (pluginInfoEx),
	PINFO,
	{ 0x3005c2b1, 0x4278, 0x470c, { 0x94, 0x98, 0x5, 0x95, 0x3d, 0xfa, 0x4d, 0x88 } } // // {3005C2B1-4278-470c-9498-05953DFA4D88}
};

// Whatever this is...
// {95061E8D-B18C-4c1c-8E14-686DE967D851}
#define MIID_IMOPROXY { 0x95061e8d, 0xb18c, 0x4c1c, { 0x8e, 0x14, 0x68, 0x6d, 0xe9, 0x67, 0xd8, 0x51 } }
static const MUUID interfaces[] = { MIID_IMOPROXY, MIID_LAST };

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

int ShowError( FILE *stream, const char *format, ...)
{
	char szBuf[1024];
	va_list ap;
	int iRet;

	va_start(ap, format);
	iRet = _vsnprintf (szBuf, sizeof(szBuf), format, ap);
	va_end(ap);

	MessageBox (NULL, szBuf, Translate("IMOPROXY Error"), MB_ICONSTOP | MB_OK);
	return iRet;
}

// -----------------------------------------------------------------------------

static void LoadSettings(IMO2SPROXY *pProxy)
{
	DBVARIANT dbv; 

	pProxy->sPort = DBGetContactSettingWord(NULL, "IMOPROXY", "Port", 1401);
	if (DBGetContactSetting(NULL, "IMOPROXY", "Host", &dbv)==0)
	{
		pProxy->lAddr = inet_addr(dbv.pszVal);
		DBFreeVariant(&dbv); 
	}
	if (DBGetContactSetting(NULL, "IMOPROXY", "Logfile", &dbv)==0)
	{
		if ((pProxy->bVerbose = DBGetContactSettingByte(NULL, "IMOPROXY", "Verbose", 0)) &&
			*dbv.pszVal)
		{
			if (!(pProxy->fpLog = fopen(dbv.pszVal, "a")))
			{
				char szMsg[MAX_PATH+64];

				sprintf (szMsg, Translate("Cannot open Logfile %s for writing."), dbv.pszVal);
				MessageBox(NULL,szMsg,"IMOPROXY", MB_OK | MB_ICONWARNING);
				pProxy->bVerbose = FALSE;
			}
		}
		DBFreeVariant(&dbv); 
	}
	pProxy->iFlags = DBGetContactSettingDword(NULL, "IMOPROXY", "Flags", 0);
	if (DBGetContactSetting(NULL, "IMOPROXY", "User", &dbv)==0)
	{
		if (pProxy->pszUser) free(pProxy->pszUser);
		pProxy->pszUser = strdup(dbv.pszVal);
		DBFreeVariant(&dbv); 
	}
	if (DBGetContactSetting(NULL, "IMOPROXY", "Password", &dbv)==0)
	{
		if (pProxy->pszPass) free(pProxy->pszPass);
		pProxy->pszPass = strdup(dbv.pszVal);
		DBFreeVariant(&dbv); 
	}
}

// -----------------------------------------------------------------------------

static BOOL CheckSettings(IMO2SPROXY *pProxy)
{
	DBVARIANT dbv; 

	if (DBGetContactSetting(NULL, "SKYPE", "Host", &dbv)==0)
	{
		if (DBGetContactSettingByte(NULL, "SKYPE", "UseSkype2Socket", 0) &&
			(lstrcmp (dbv.pszVal, "127.0.0.1")==0 || 
			lstrcmp (dbv.pszVal, "localhost")==0) &&
			DBGetContactSettingWord(NULL, "SKYPE", "Port", 0) ==
			DBGetContactSettingWord(NULL, "IMOPROXY", "Port", 1401))
		{
			DBFreeVariant(&dbv);
			return TRUE;
		}
		DBFreeVariant(&dbv);
	}
	if (DBGetContactSettingByte(NULL, "SKYPE", "FirstRun", 9) == 9)
	{
		MessageBox (NULL, Translate("SKYPE plugin may not be installed, this plugin only works together with "
			"the SKYPE-plugin. Please check if you installed and enabled it."), "IMOPROXY", 
			MB_OK | MB_ICONWARNING);
	}
	else
	{
		if (MessageBox (NULL, Translate("Your Skype plugin currently doesn't seem to be setup to use imo2proxy, "
			"do you want me to change its settings so that it uses this plugins?"), "IMOPROXY", 
			MB_YESNO | MB_ICONQUESTION) == IDYES)
		{
			DBWriteContactSettingByte (NULL, "SKYPE", "UseSkype2Socket", 1);
			DBWriteContactSettingWord (NULL, "SKYPE", "Port", pProxy->sPort);
			DBWriteContactSettingString (NULL, "SKYPE", "Host", "127.0.0.1");
			return TRUE;
		}
	}
	return FALSE;
}

// -----------------------------------------------------------------------------

static BOOL EnumNetInterfaces (HWND hwndControl)
{
	HINSTANCE hLib;
	BOOL bRet = FALSE;

	if (hLib = LoadLibrary("Iphlpapi.dll"))
	{
		PMIB_IPADDRTABLE pTable;
		ULONG uSize=1;
		DWORD i;
		FARPROC GetIpAddrTable;

		if (GetIpAddrTable = (FARPROC)GetProcAddress (hLib, "GetIpAddrTable"))
		{
			if ((GetIpAddrTable (&pTable, &uSize, TRUE) == ERROR_INSUFFICIENT_BUFFER) &&
				(pTable = HeapAlloc (GetProcessHeap(), 0, uSize)))
			{
				if (GetIpAddrTable (pTable, &uSize, TRUE) == NO_ERROR)
				{
					struct in_addr addr;

					for (i=0; i<pTable->dwNumEntries; i++)
					{
						addr.S_un.S_addr = pTable->table[i].dwAddr;
						SendMessage (hwndControl, CB_ADDSTRING, 0, (LPARAM)inet_ntoa(addr));
					}
					bRet = pTable->dwNumEntries > 0;
				}
				HeapFree (GetProcessHeap(), 0, pTable);
			}
		}
		FreeLibrary (hLib);
	}
	return bRet;
}

// -----------------------------------------------------------------------------

static DWORD WINAPI ProxyThread(IMO2SPROXY *pProxy)
{
	Imo2sproxy_Loop(pProxy);
	return 0;
}

// -----------------------------------------------------------------------------

static BOOL StartProxy (IMO2SPROXY *pProxy)
{
	DWORD dwThreadId;

	if (!pProxy->pszUser || !*pProxy->pszUser || 
		!pProxy->pszPass || !*pProxy->pszPass) return FALSE;
	if (Imo2sproxy_Open(pProxy)<0)
	{
		MessageBox (NULL, "IMOPROXY Cannot bind socket", "IMOPROXY", MB_OK | MB_ICONSTOP);
		return FALSE;
	}
	if (!(m_hThread = CreateThread (NULL, 0, ProxyThread, pProxy, 0, &dwThreadId)))
	{
		MessageBox (NULL, Translate("IMOPROXY Cannot start dispatch thread"), "IMOPROXY", MB_OK | MB_ICONSTOP);
		return FALSE;
	}
	return TRUE;
}

// -----------------------------------------------------------------------------

static void StopProxy (IMO2SPROXY *pProxy)
{
	if (m_hThread)
	{
		Imo2sproxy_Exit(pProxy);
		if (WaitForSingleObject (m_hThread, 3000) != WAIT_OBJECT_0)
			TerminateThread (m_hThread, -1);
		m_hThread = NULL;
	}
}

// -----------------------------------------------------------------------------

static int CALLBACK OptionsDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static char szOldHost[64]={0}, szOldLog[MAX_PATH]={0}, szOldUser[64], szOldPass[64];
	static short sOldPort=0;
	static BOOL bOldVerbose=FALSE;
	static int iOldFlags = 0;

	switch (uMsg)
	{
		case WM_INITDIALOG:	
		{
			DBVARIANT dbv; 

			TranslateDialogDefault(hWnd);
			EnumNetInterfaces (GetDlgItem (hWnd, IDC_BINDIP));
			if (DBGetContactSetting(NULL, "IMOPROXY", "Host", &dbv)==0)
			{
				lstrcpyn (szOldHost, dbv.pszVal, sizeof(szOldHost));
				DBFreeVariant(&dbv); 
			} else lstrcpy (szOldHost, "127.0.0.1");
			SetDlgItemText (hWnd, IDC_BINDIP,szOldHost);
			SetDlgItemInt (hWnd, IDC_BINDPORT, sOldPort = DBGetContactSettingWord(NULL, "IMOPROXY", "Port", 1401), FALSE);
			iOldFlags = DBGetContactSettingDword(NULL, "IMOPROXY", "Flags", 0);
			if (iOldFlags & IMO2S_FLAG_ALLOWINTERACT) CheckDlgButton (hWnd, IDC_INTERACT, BST_CHECKED);
			if (iOldFlags & IMO2S_FLAG_CURRTIMESTAMP) CheckDlgButton (hWnd, IDC_CURRTIMESTAMP, BST_CHECKED);
			if (DBGetContactSetting(NULL, "IMOPROXY", "Logfile", &dbv)==0)
			{
				lstrcpyn (szOldLog, dbv.pszVal, sizeof(szOldLog));
				DBFreeVariant(&dbv); 
			}
			SetDlgItemText (hWnd, IDC_LOGFILE, szOldLog);
			if (bOldVerbose = DBGetContactSettingByte(NULL, "IMOPROXY", "Verbose", 0))
				CheckDlgButton (hWnd, IDC_LOG, BST_CHECKED);
			else
			{
				EnableWindow (GetDlgItem (hWnd, IDC_LOGFILE), FALSE);
				EnableWindow (GetDlgItem (hWnd, IDC_OPEN), FALSE);
			}
			if (DBGetContactSetting(NULL, "IMOPROXY", "User", &dbv)==0)
			{
				lstrcpyn (szOldUser, dbv.pszVal, sizeof(szOldUser));
				DBFreeVariant(&dbv); 
			}
			SetDlgItemText (hWnd, IDC_USERNAME, szOldUser);
			if (DBGetContactSetting(NULL, "IMOPROXY", "Password", &dbv)==0)
			{
				lstrcpyn (szOldPass, dbv.pszVal, sizeof(szOldPass));
				DBFreeVariant(&dbv); 
			}
			SetDlgItemText (hWnd, IDC_PASSWORD, szOldPass);
			SetDlgItemText (hWnd, IDC_STATUS, m_hThread?Translate("Running"):Translate("Stopped"));
#ifdef _DEBUG
			EnableWindow (GetDlgItem(hWnd, IDC_CONSOLE), TRUE);
#endif
			return TRUE;
		}
		case WM_NOTIFY:
		{
			NMHDR* nmhdr = (NMHDR*)lParam;

			switch (nmhdr->code)
			{
				case PSN_APPLY:
				case PSN_KILLACTIVE:
				{
					int iFlags=0;
					short sPort;
					char szHost[64], szLog[MAX_PATH], szUser[64], szPass[64];
					BOOL bVerbose;

					GetDlgItemText (hWnd, IDC_BINDIP, szHost, sizeof(szHost));
					DBWriteContactSettingString (NULL, "IMOPROXY", "Host", szHost);
					DBWriteContactSettingWord (NULL, "IMOPROXY", "Port", 
						(sPort = GetDlgItemInt (hWnd, IDC_BINDPORT, NULL, FALSE)));
					if (IsDlgButtonChecked (hWnd, IDC_INTERACT)==BST_CHECKED)
						iFlags|=IMO2S_FLAG_ALLOWINTERACT;
					if (IsDlgButtonChecked (hWnd, IDC_CURRTIMESTAMP)==BST_CHECKED)
						iFlags|=IMO2S_FLAG_CURRTIMESTAMP;
					GetDlgItemText (hWnd, IDC_USERNAME, szUser, sizeof(szUser));
					DBWriteContactSettingString (NULL, "IMOPROXY", "User", szUser);
					GetDlgItemText (hWnd, IDC_PASSWORD, szPass, sizeof(szPass));
					DBWriteContactSettingString (NULL, "IMOPROXY", "Password", szPass);
					DBWriteContactSettingDword (NULL, "IMOPROXY", "Flags", iFlags);
					DBWriteContactSettingByte(NULL, "IMOPROXY", "Verbose", 
						(char)(bVerbose = (IsDlgButtonChecked (hWnd, IDC_LOG)==BST_CHECKED)));
					GetDlgItemText (hWnd, IDC_LOGFILE, szLog, sizeof(szLog));
					DBWriteContactSettingString (NULL, "IMOPROXY", "Logfile", szLog);
					if (sPort != sOldPort || lstrcmp (szOldHost, szHost) ||
						lstrcmp (szOldLog, szLog) || bOldVerbose != bVerbose ||
						lstrcmp (szOldUser, szUser) || lstrcmp(szOldPass, szPass) ||
						iFlags != iOldFlags)
					{
						StopProxy(&m_proxy);
						LoadSettings (&m_proxy);
						CheckSettings(&m_proxy);
						StartProxy(&m_proxy);
					}
					return TRUE;
				}
			}
			break;
		}
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDC_LOG:
				{
					BOOL bEnable = (SendMessage ((HWND)lParam, BM_GETCHECK, 0, 0)==BST_CHECKED);

					EnableWindow (GetDlgItem (hWnd, IDC_LOGFILE), bEnable);
					EnableWindow (GetDlgItem (hWnd, IDC_OPEN), bEnable);
					break;
				}
				case IDC_OPEN:
				{
					char szFilename[MAX_PATH];
					OPENFILENAME ofn={0};

					GetDlgItemText (hWnd, IDC_LOGFILE, szFilename, sizeof(szFilename));
					ofn.lStructSize=sizeof(OPENFILENAME);
					ofn.hwndOwner=hWnd;
					ofn.Flags=OFN_HIDEREADONLY;
					ofn.lpstrTitle=Translate("Select where log file will be created");
					ofn.lpstrFilter=Translate("All files (*.*)\0*.*\0");
					ofn.lpstrFile=szFilename;
					ofn.nMaxFile=sizeof(szFilename)-2;
					ofn.nMaxFileTitle=sizeof(szFilename);
					if(GetSaveFileName(&ofn))
						SetDlgItemText(hWnd, IDC_LOGFILE, szFilename);
					break;
				}
				case IDC_RESTART:
				{
					EnableWindow ((HWND)lParam, FALSE);
					StopProxy(&m_proxy);
					SetDlgItemText (hWnd, IDC_STATUS, Translate("Stopped"));
					LoadSettings (&m_proxy);
					CheckSettings(&m_proxy);
					StartProxy(&m_proxy);
					SetDlgItemText (hWnd, IDC_STATUS, m_hThread?Translate("Running"):Translate("Stopped"));
					EnableWindow ((HWND)lParam, TRUE);
					break;
				}
				case IDC_CONSOLE:
				{
					CONSOLE_SCREEN_BUFFER_INFO coninfo;
					HANDLE hStdHandle;
					int hConHandle;
					HMENU hMenu;
					FILE *fp;
					HMODULE hKernel32;
					HWND (WINAPI *_GetConsoleWindow)(void), hWndCon;

					/* Some dirty hack for a simple console. I know this isn't really
					   proper and that I should use my own console, but it's enough for
					   debugging purposes ;-)
					 */
					if (m_bHasConsole)
					{
						if (m_proxy.fpLog) fclose(m_proxy.fpLog);
						m_proxy.fpLog = NULL;
						LoadSettings (&m_proxy);
						FreeConsole();
						m_bHasConsole = FALSE;
						m_proxy.bVerbose = bOldVerbose;
						break;
					}
					m_bHasConsole = AllocConsole();
					hStdHandle = GetStdHandle(STD_OUTPUT_HANDLE);
					GetConsoleScreenBufferInfo(hStdHandle, &coninfo);
					coninfo.dwSize.Y = 500;
					SetConsoleScreenBufferSize(hStdHandle, coninfo.dwSize);
					hConHandle = _open_osfhandle((long)hStdHandle, _O_TEXT);
					fp = _fdopen(hConHandle, "w"); 
					if (!fp)
					{
						FreeConsole();
						m_bHasConsole = FALSE;
						break;
					}
					// Only available in Win2k or above
					// Protect Console form closing, otherwise closing the console
					// would Shutdown Miranda
					if ((hKernel32 = GetModuleHandle ("kernel32.dll")) &&
						(*(FARPROC *)&_GetConsoleWindow = 
							GetProcAddress(hKernel32, "GetConsoleWindow")) &&
						(hWndCon = _GetConsoleWindow()))
					{
						hMenu = GetSystemMenu (hWndCon, FALSE);
						DeleteMenu (hMenu, SC_CLOSE, MF_BYCOMMAND);
					}
					else
					{
						fprintf (fp, Translate("WARNING: Only close this console by pushing the Console button "
							"in the settings dialog, otherwise you sould shutdown Miranda by closing "
							"the Window!\n"));
					}
					setvbuf(fp, NULL, _IONBF, 0 ); 
					if (m_proxy.fpLog && m_proxy.fpLog != stdout && m_proxy.fpLog != stderr) fclose(m_proxy.fpLog);
					bOldVerbose = m_proxy.bVerbose;
					m_proxy.bVerbose = 1;
					m_proxy.fpLog = fp;
					
					
					break;
				}
			}
			break;
	}
	return FALSE;
}

// -----------------------------------------------------------------------------

static int RegisterOptions(WPARAM wParam, LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp={0};
   
	odp.cbSize = sizeof(odp);
	odp.hInstance = m_hInst;
	odp.pszTemplate = MAKEINTRESOURCE(IDD_OPTIONS);
	odp.pszGroup = Translate("Network");
	odp.pszTitle = "Skype Imoproxy";
	odp.pfnDlgProc = OptionsDlgProc;
	odp.flags = ODPF_BOLDGROUPS;
	CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);
	return 0;
}

// -----------------------------------------------------------------------------

int PreShutdown(WPARAM wParam, LPARAM lParam)
{
	OutputDebugString ("IMOPROXY: PreShutdown");
	StopProxy (&m_proxy);
	FreeConsole();
	return 0;
}

// -----------------------------------------------------------------------------

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	m_hInst=hinstDLL;
	return TRUE;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

__declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	return &pluginInfo;
}

// -----------------------------------------------------------------------------

// New plugin API
__declspec(dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion)
{
	return &pluginInfoEx;
}

// -----------------------------------------------------------------------------

__declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

// -----------------------------------------------------------------------------

int __declspec(dllexport) Load(PLUGINLINK *link)
{
	BYTE CheckSkype;

#ifdef _DEBUG
	Crash_Init();
#endif
	pluginLink = link;
	Imo2sproxy_Init(&m_proxy);
	m_proxy.logerror = ShowError;
	LoadSettings(&m_proxy);

	CheckSkype = DBGetContactSettingByte (NULL, "IMOPROXY", "CheckSkype", 2);
	if (CheckSkype) CheckSettings(&m_proxy);
	if (CheckSkype == 2) DBWriteContactSettingByte (NULL, "IMOPROXY", "CheckSkype", 0);

	m_hOptHook = HookEvent(ME_OPT_INITIALISE, RegisterOptions);
	HookEvent(ME_SYSTEM_PRESHUTDOWN, PreShutdown);
	StartProxy(&m_proxy);
	OutputDebugString ("IMOPROXY: Loaded");
	return 0;
}

// -----------------------------------------------------------------------------

int __declspec(dllexport) Unload(void)
{
	OutputDebugString ("IMOPROXY: Unload");
	if (m_hOptHook) UnhookEvent(m_hOptHook);
	return 0;
}
