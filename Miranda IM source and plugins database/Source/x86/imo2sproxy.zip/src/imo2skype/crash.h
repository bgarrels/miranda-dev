void Crash_Init(void);
