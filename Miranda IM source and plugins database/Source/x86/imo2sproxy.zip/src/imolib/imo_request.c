/* Module:  imo_request.c
   Purpose: Posts XMLHHTP-Requests to imo.im server
   Author:  leecher
   Date:    30.08.2009
*/
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include "fifo.h"
#include "imo_request.h"
#include "io_layer.h"

#define SSID_LENGTH 16

struct _tagIMORQ
{
	IOLAYER *hIO;
	char szSessId[SSID_LENGTH+2];
};

// Forward declaration of private functions
static size_t add_data(char *data, size_t size, size_t nmemb, void *ctx);

// -----------------------------------------------------------------------------
// Interface
// -----------------------------------------------------------------------------

IMORQ *ImoRq_Init(void)
{
	IMORQ *hRq = calloc(1, sizeof(IMORQ));

	/* Setup CURL */
	if (!hRq) return NULL;
	if (!(hRq->hIO = IoLayer_Init()))
	{
		ImoRq_Exit(hRq);
		return NULL;
	}

	/* Create session ID */
	ImoRq_CreateID (hRq->szSessId, SSID_LENGTH+1);

	/* Fetch start page to get cookies */
	IoLayer_Get (hRq->hIO, "https://www.imo.im/surf.html?client_ver=1.0.0");

	return hRq;
}

// -----------------------------------------------------------------------------

IMORQ *ImoRq_Clone (IMORQ *hRq)
{
	IMORQ *hDup;

	if (!(hDup = ImoRq_Init())) return NULL;
	strcpy (hDup->szSessId, hRq->szSessId);
	return hDup;
}

// -----------------------------------------------------------------------------

void ImoRq_Exit (IMORQ *hRq)
{
	if (hRq->hIO) IoLayer_Exit(hRq->hIO);
	free (hRq);
}

// -----------------------------------------------------------------------------

char *ImoRq_PostAmy(IMORQ *hRq, char *pszMethod, cJSON *data)
{
	TYP_FIFO *hPostString;
	char *pszData, *pszEscData;
	unsigned int uiCount = -1;

	if (!(pszData = cJSON_Print(data))) return NULL;
	pszEscData = IoLayer_EscapeString(hRq->hIO, pszData);
	free (pszData);
	if (!pszEscData || !(hPostString = Fifo_Init(strlen(pszEscData)+32)))
	{
		if (pszEscData) IoLayer_FreeEscapeString (pszEscData);
		return NULL;
	}
	Fifo_AddString (hPostString, "id=");
	Fifo_AddString (hPostString, hRq->szSessId);
	Fifo_AddString (hPostString, "&method=");
	Fifo_AddString (hPostString, pszMethod);
	Fifo_AddString (hPostString, "&data=");
	Fifo_AddString (hPostString, pszEscData);
	IoLayer_FreeEscapeString (pszEscData);
	pszEscData =  Fifo_Get(hPostString, &uiCount);
	pszData = IoLayer_Post (hRq->hIO, "https://s.imo.im/amy", pszEscData,
		uiCount-1);
	Fifo_Exit(hPostString);
	return pszData;
}

// -----------------------------------------------------------------------------

char *ImoRq_SessId(IMORQ *hRq)
{
	return hRq->szSessId;
}

// -----------------------------------------------------------------------------

char *ImoRq_GetLastError(IMORQ *hRq)
{
	return IoLayer_GetLastError (hRq->hIO);
}

// -----------------------------------------------------------------------------

void ImoRq_CreateID(char *pszID, int cbID)
{
	int i, r;
	time_t curtime;

	srand(time(&curtime));
	for (i=0; i<cbID; i++)
	{
		r = rand()%62;
		if (r<26) pszID[i]='A'+r; else
		if (r<52) pszID[i]='a'+(r-26); else
		pszID[i]='0'+(r-52);
	}
	pszID[i]=0;
	return;
}
