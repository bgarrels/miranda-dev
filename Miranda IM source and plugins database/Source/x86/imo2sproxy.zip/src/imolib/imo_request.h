#ifndef _IMO_REQUEST_H_
#define _IMO_REQUEST_H_

#include "cJSON.h"

struct _tagIMORQ;
typedef struct _tagIMORQ IMORQ;

IMORQ *ImoRq_Init(void);
IMORQ *ImoRq_Clone (IMORQ *hRq);
void ImoRq_Exit (IMORQ *hRq);

char *ImoRq_SessId(IMORQ *hRq);
char *ImoRq_GetLastError(IMORQ *hRq);
char *ImoRq_PostAmy(IMORQ *hRq, char *pszMethod, cJSON *data);
void ImoRq_CreateID(char *pszID, int cbID);

#endif
