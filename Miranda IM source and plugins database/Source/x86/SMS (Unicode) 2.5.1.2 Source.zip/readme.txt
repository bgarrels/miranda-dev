#SMS Plugin readme file#
!!!VERY IMPORTANT!!! - This new version work proparly only with latest nightly builds or Miranda-IM.

As it's been suggested by paul, tadam -readme file- :)

1. Installation

1.a Files needed
First of all you'll need Miranda-IM (Go grab your copy from miranda-icq.sf.net/rich/)
Second  you should have ICQ protocol plugin
Third sms.dll

1.b Loading SMS plugin
After you saw you have all files needed, copy the sms.dll to the Plugins directory of miranda.
Next load Miranda-IM, the plugin should be loaded automaticly, but go and check it anyway on the Miranda-IM options page.

2. Using SMS plugin

2.a Settings
First go to the option page of Miranda-IM and look at Events->SMS Plugin, there you'll have some options to change.

2.b Sending a SMS message
There are two options sending a SMS message:
i) From the Miranda-IM main menu - You should use this option when you want to send a message to an Unknown contact.
ii) From the Right click menu on contact list - Sending a message to a specific contact on your list.

2.c Adding number to database
Again, you have two options:
i) Open the User Deatils page of a contact, go to the Contact tab and add a phone to the list MARKED AS SMSABLE NUMBER.
ii) Open a SMS Send dialog, write a number on the combo box and use Save Number button to add it to the user database.

2.d Multiple sending
This is very simple procedure, open a SMS Send dialog, push the Multiple >> button, check all the numbers you want to send them, and Send.

3. FAQ

Q: The plugin doesn't load, Why?
A: Please check the installation part again, if it still doesn't work, contact me cause I really don't know why it happends :)

Q: I never managed to send a message to any cellular number!!! HELP ME!!!
A: Well, what can I say, MY PLUGIN CAN'T SEND A MESSAGE TO ALL THE CELLULAR NUMBERS IN THE WORLD!!! (Sorry, but I get this message all the time)
and I'm sorry, but I guess it never will either.
You need to understand that the message are sent by the ICQ SMS gateway, and it supports just some of networks, not all of them.
So if you can't send your network doesn't supported, and I can't do anything about it 
(network supported could be found at , but even if you can find your network there it could be not working, because the page is not refreshed)

Q: I managed to send a message, but it stoped working me, Why?
A: It could be you sent too much messages, and you got a RATE LIMIT, or maybe a problem on the ICQ server/Your cellular network, or just ICQ stopped working with your network...

Q: Why there isn't an option to do "THAT" on your plugin?
A: Suggest your opinion/idea, and I'll be glad to add it to my code if pepole will want it!

4. About

4.a ME - Ariel
OK, this is my plugin, I hope you enjoy it, for any comment, problem, or any other thing, contact me at the:
i) Miranda-IM forums.
ii) ICQ: 90001000
iii) E-Mail: nuke007@nuke007.tk

4.b THANKS
First, thanks to all the Miranda DEV team who brang us the Miranda-IM!!!
Second, special thanks to the pepole who helped me a lot - bid, paul, hrk (Sorry if I forgot someone).
Third, thanks to all the users that uses this plugin, well you are my beta testers:)

5. THE END