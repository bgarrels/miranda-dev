/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at http://flashmagicd.com/projects/smsplugin/
Enjoy the code and use it smartly!
*/

#include "senddlg.h"

static WNDPROC OldEditWndProc;

//Defnition needed to the SMS window list

static SMSWindow *SMSWindowList=NULL;
static int SMSWindowNum=0;

//END of defenitions

static LRESULT CALLBACK MessageSubclassProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message) {
		case WM_CHAR:
			if(wParam==_T('\n') && GetKeyState(VK_CONTROL)&0x8000) {
				PostMessage(GetParent(hwnd),WM_COMMAND,IDOK,0);
				return 0;
			}
			break;
	}
	return CallWindowProc(OldEditWndProc,hwnd,message,wParam,lParam);
}

BOOL CALLBACK SendSmsDlgProc(HWND hwndDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	static HFONT hFont;
	switch(message) {
		case WM_INITDIALOG:
			TranslateDialogDefault(hwndDlg); //Translate intially - bid
			AddWinHandle(GetDlgItem(hwndDlg,IDC_MESSAGE));
			EnableWindow(GetDlgItem(hwndDlg,IDC_ADDNUMBER),0);
			EnableWindow(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),0);
			{
				int x,y,cx,cy;
				HANDLE hContact;
				if(DBGetContactSettingByte(NULL,SMSPLUGIN,"SavePerContact",0))
					hContact=(HANDLE)lParam;
				else 
					hContact=NULL;
				x = DBGetContactSettingDword(hContact,SMSPLUGIN,"sendx",0);
				y = DBGetContactSettingDword(hContact,SMSPLUGIN,"sendy",0);
				cx = DBGetContactSettingDword(hContact,SMSPLUGIN,"sendwidth",0);
				cy = DBGetContactSettingDword(hContact,SMSPLUGIN,"sendheight",0);
				if((x==0) && (y==0) && (cx==0) && (cy==0))
					SetWindowPos(hwndDlg,0,200,200,400,350,SWP_NOZORDER);	
				else
					SetWindowPos(hwndDlg,0,x,y,cx,cy,SWP_NOZORDER);
			}
			SendMessage(hwndDlg,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS)));
			SendDlgItemMessage(hwndDlg,IDC_HISTORY,BM_SETIMAGE,IMAGE_ICON,(LPARAM)LoadImage(GetPluginhInst(),MAKEINTRESOURCE(IDI_HISTORY),IMAGE_ICON,GetSystemMetrics(SM_CXSMICON),GetSystemMetrics(SM_CYSMICON),0));
			TreeView_SetImageList(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),ImageList_Create(16,16,ILC_COLOR32|ILC_MASK,0,30),TVSIL_NORMAL);	
			{
				HICON hIcon;
				HIMAGELIST hIml;
				hIml=TreeView_GetImageList(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),TVSIL_NORMAL);
				hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_NOTICK));
				ImageList_AddIcon(hIml,hIcon);
				hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_TICK));
				ImageList_AddIcon(hIml,hIcon);
				hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_HALFTICK));
				ImageList_AddIcon(hIml,hIcon);
				hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));
				ImageList_AddIcon(hIml,hIcon);
				hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT));
				ImageList_AddIcon(hIml,hIcon);
				hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT));
				ImageList_AddIcon(hIml,hIcon);
			}
			InvalidateRect(GetDlgItem(hwndDlg,IDC_MESSAGE),NULL,FALSE);
			{	
				LOGFONT lf;
				hFont=(HFONT)SendDlgItemMessage(hwndDlg,IDC_MESSAGE,WM_GETFONT,0,0);
				if(hFont!=NULL && hFont!=(HFONT)SendDlgItemMessage(hwndDlg,IDOK,WM_GETFONT,0,0)) DeleteObject(hFont);
				LoadMsgDlgFont(MSGFONTID_MYMSG,&lf,NULL);
				hFont=CreateFontIndirect(&lf);
				SendDlgItemMessage(hwndDlg,IDC_MESSAGE,WM_SETFONT,(WPARAM)hFont,MAKELPARAM(TRUE,0));
				//DeleteObject(hFont); //Test if it works
			}
			OldEditWndProc=(WNDPROC)SetWindowLong(GetDlgItem(hwndDlg,IDC_MESSAGE),GWL_WNDPROC,(LONG)MessageSubclassProc);
			{
				TOOLINFO ti;
				HWND hwndToolTips;
				hwndToolTips=CreateWindowEx(WS_EX_TOPMOST,TOOLTIPS_CLASS,_T(""),WS_POPUP,0,0,0,0,NULL,NULL,GetModuleHandle(NULL),NULL);
				ZeroMemory(&ti,sizeof(ti));
				ti.cbSize=sizeof(ti);
				ti.uFlags=TTF_IDISHWND|TTF_SUBCLASS;
				ti.uId=(UINT)GetDlgItem(hwndDlg,IDC_HISTORY);
				ti.lpszText=TranslateT("View User's History");
				SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
				ti.uId=(UINT)GetDlgItem(hwndDlg,IDC_ADDNUMBER);
				ti.lpszText=TranslateT("Add Number To The Multiple List");
				SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
				ti.uId=(UINT)GetDlgItem(hwndDlg,IDC_SAVENUMBER);
				ti.lpszText=TranslateT("Save Number To The User's Details Phonebook");
				SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
				ti.uId=(UINT)GetDlgItem(hwndDlg,IDC_MULTIPLE);
				ti.lpszText=TranslateT("Show/Hide Multiple List");
				SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
				ti.uId=(UINT)GetDlgItem(hwndDlg,IDC_COUNT);
				ti.lpszText=TranslateT("Shows How Much Chars You've Typed");
				SendMessage(hwndToolTips,TTM_ADDTOOL,0,(LPARAM)&ti);
			}
			{	
				TCHAR cSign[1024];		
				TCHAR cUseSign[2];
				TCHAR str[20];
				GetStringOption(OPTION_SIGNATURE,cSign,sizeof(cSign));
				GetStringOption(OPTION_USESIGNATURE,cUseSign,sizeof(cUseSign));
				if((*cSign!=_T('\0')) && (cUseSign[0]!=_T('0')))
				{
					TCHAR *cTmp;
					TCHAR cBegin[2];
					int count;
					GetStringOption(OPTION_SIGNATUREPOS,cBegin,sizeof(cBegin));
					count=lstrlen(cSign);
					SetDlgItemText(hwndDlg,IDC_MESSAGE,cSign);
					cTmp = CHAR2TCHAR(mir_utf8encodeT(cSign));
					wsprintf(str,_T("%d/%d"),count,lstrcmp(cTmp,cSign)?70:160);
					SetDlgItemText(hwndDlg,IDC_COUNT,str);
					if(!(cBegin[0] == _T('0')))
						SendDlgItemMessage(hwndDlg,IDC_MESSAGE,EM_SETSEL,lstrlen(cSign),lstrlen(cSign));
					EnableWindow(GetDlgItem(hwndDlg,IDOK),count);
					mir_free(cTmp);
				}
				else
				{
					wsprintf(str,_T("%d/%d"),0,160);
					SetDlgItemText(hwndDlg,IDC_COUNT,str);
				}
			}
			UpdateSendSMSWindowAccountList(hwndDlg);
			return TRUE;
		case WM_GETMINMAXINFO:
			if(GetSendSMSWindowMultiple(hwndDlg) <= 0)
			{
				((MINMAXINFO*)lParam)->ptMinTrackSize.x=330; 
				((MINMAXINFO*)lParam)->ptMinTrackSize.y=230;
			}
			else
			{
				((MINMAXINFO*)lParam)->ptMinTrackSize.x=530; 
				((MINMAXINFO*)lParam)->ptMinTrackSize.y=230;
			}

			break;
		case WM_SIZE:
			{
				RECT rcWin;
				int cx,cy;			
				GetWindowRect(hwndDlg,&rcWin);
				if(GetSendSMSWindowMultiple(hwndDlg) <= 0)
				{
					EnableWindow(GetDlgItem(hwndDlg,IDC_ADDNUMBER),0);
					EnableWindow(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),0);
					cx = rcWin.right - rcWin.left;
					cy = rcWin.bottom - rcWin.top;
				}
				else
				{
					EnableWindow(GetDlgItem(hwndDlg,IDC_ADDNUMBER),1);
					EnableWindow(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),1);
					cx = rcWin.right - rcWin.left - 181;
					cy = rcWin.bottom - rcWin.top;
				}
				SetWindowPos(GetDlgItem(hwndDlg,IDC_NAME),0,0,0,(cx*35)/100,20,SWP_NOZORDER|SWP_NOMOVE);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_ST_ADDRESS),0,cx - (cx*35)/100 - 68,5,0,0,SWP_NOZORDER|SWP_NOSIZE);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_ADDRESS),0,cx - (cx*35)/100 - 11,5,(cx*35)/100,20,SWP_NOZORDER);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_ACCOUNT),0,0,0,(cx*35)/100,20,SWP_NOZORDER|SWP_NOMOVE);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_SAVENUMBER),0,cx - (cx*35)/100 - 68,30,((cx*35)/100 + 35)/2,20,SWP_NOZORDER);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_MULTIPLE),0,cx - ((cx*35)/100 + 35)/2 - 11,30,((cx*35)/100 + 35)/2,20,SWP_NOZORDER);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_HISTORY),0,cx - (cx*35)/100 - 68,52,0,0,SWP_NOZORDER|SWP_NOSIZE);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_ST_CHARS),0,cx - 110,52,0,0,SWP_NOZORDER|SWP_NOSIZE);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_COUNT),0, cx - 57,52,45,15,SWP_NOZORDER);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_MESSAGE),0,0,0,cx - 14,cy - 140,SWP_NOZORDER|SWP_NOMOVE);
				SetWindowPos(GetDlgItem(hwndDlg,IDOK),0,cx/2 - 87,cy - 60,0,0,SWP_NOZORDER|SWP_NOSIZE);
				SetWindowPos(GetDlgItem(hwndDlg,IDCANCEL),0,cx/2 + 7,cy - 60,0,0,SWP_NOZORDER|SWP_NOSIZE);

				SetWindowPos(GetDlgItem(hwndDlg,IDC_ADDNUMBER),0,cx,5,0,0,SWP_NOZORDER|SWP_NOSIZE);
				SetWindowPos(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),0,cx,31,160,cy - 96,SWP_NOZORDER);
								
				RedrawWindow(hwndDlg,NULL,NULL,RDW_FRAME|RDW_INVALIDATE);
			}
			break;
		case WM_TIMER:
			if(wParam==TIMERID_MSGSEND) {
				HWND hwndTimeOut;
				TCHAR cMessage[512];
				TCHAR number[161];
				if(GetSendSMSWindowMultiple(hwndDlg) == 1)
				{
					TVITEM tvi;
					tvi.mask=TVIF_TEXT;
					tvi.hItem=GetSendSMSWindowHItemSend(hwndDlg);
					tvi.pszText=number;
					tvi.cchTextMax=sizeof(number);
					TreeView_GetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvi);
				}
				else
					GetDlgItemText(hwndDlg,IDC_ADDRESS,number,sizeof(number));
				wsprintf(cMessage,TranslateT("The SMS message send to %s timed out."),number);				
				KillTimer(hwndDlg,wParam);
				ShowWindow(hwndDlg,SW_SHOWNORMAL);
				EnableWindow(hwndDlg,FALSE);
				hwndTimeOut=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSTIMEDOUT),hwndDlg,SMSTimedOutDlgProc);
				SetDlgItemText(hwndTimeOut,IDC_STATUS,cMessage);
			}
			break;
		case WM_CTLCOLOREDIT:
			{	
				COLORREF colour;
				HBRUSH hBkgBrush;
				if((HWND)lParam!=GetDlgItem(hwndDlg,IDC_MESSAGE)) break;
				LoadMsgDlgFont(MSGFONTID_MYMSG,NULL,&colour);
				SetTextColor((HDC)wParam,colour);
				SetBkColor((HDC)wParam,DBGetContactSettingDword(NULL,SMSPLUGIN,"BkgColour",SRMSGDEFSET_BKGCOLOUR));
				hBkgBrush=CreateSolidBrush(DBGetContactSettingDword(NULL,SMSPLUGIN,"BkgColour",SRMSGDEFSET_BKGCOLOUR));
				return (BOOL)hBkgBrush;
			}
			break;
		case DM_TIMEOUTDECIDED:
			EnableWindow(hwndDlg,TRUE);
			switch(wParam) 
			{
				case TIMEDOUT_CANCEL:
					{
						if(GetSendSMSWindowMultiple(hwndDlg)<=0)
						{
							TCHAR caption[200];
							EnableWindow(GetDlgItem(hwndDlg,IDOK),TRUE);
							SendDlgItemMessage(hwndDlg,IDC_MESSAGE,EM_SETREADONLY,FALSE,0);
							EnableWindow(GetDlgItem(hwndDlg,IDC_ADDRESS),TRUE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_ACCOUNT),TRUE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_SAVENUMBER),TRUE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_MULTIPLE),TRUE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),TRUE);
							if(GetSendSMSWindowHContact(hwndDlg) == NULL)
								EnableWindow(GetDlgItem(hwndDlg,IDC_NAME),TRUE);
							SetFocus(GetDlgItem(hwndDlg,IDC_MESSAGE));
							GetDlgItemText(hwndDlg,IDC_MULTIPLE,caption,sizeof(caption));
							SetSendSMSWindowHItemSend(hwndDlg, NULL);
						}
						else
						{	
							if(GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg))==NULL)
							{
								RemoveSendSMSWindow(hwndDlg);
								return 0;
							}
							SetSendSMSWindowHItemSend(hwndDlg,GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg)));
							SendSMSWindowNext(hwndDlg);
						}
					}
					break;
				case TIMEDOUT_RETRY:
					{
						TCHAR number[161];
						TCHAR text[161];					
						if(GetSendSMSWindowMultiple(hwndDlg) == 1)
						{
							TVITEM tvi;
							tvi.mask=TVIF_TEXT;
							tvi.hItem=GetSendSMSWindowHItemSend(hwndDlg);
							tvi.pszText=number;
							tvi.cchTextMax=sizeof(number);
							TreeView_GetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvi);
						}
						else
							GetDlgItemText(hwndDlg,IDC_ADDRESS,number,sizeof(number));
						GetDlgItemText(hwndDlg,IDC_MESSAGE,text,sizeof(text));
						StartSmsSend(hwndDlg,number,text);
						SetSendSMSWindowNumber(hwndDlg,number);
					}
					SetTimer(hwndDlg,TIMERID_MSGSEND,TIMEOUT_MSGSEND,NULL);
					break;
			}
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam)) 
			{
				case IDC_MULTIPLE:
					if(GetSendSMSWindowMultiple(hwndDlg) <= 0)
					{
						WINDOWPLACEMENT wp;
						HANDLE hContact=NULL;
						RECT rcWin,rcList;
						int j=0;
						SetSendSMSWindowMultiple(hwndDlg,1);
						//SetWindowLong(GetDlgItem(hwndDlg,IDC_ADDNUMBER),GWL_STYLE,WS_TABSTOP);
						//SetWindowLong(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),GWL_STYLE,WS_TABSTOP);
						SetDlgItemText(hwndDlg,IDC_MULTIPLE,TranslateT("<< Single"));
						GetWindowRect(hwndDlg,&rcWin);
						GetWindowRect(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&rcList);
						wp.length = sizeof(WINDOWPLACEMENT);
						GetWindowPlacement(hwndDlg,&wp);
						if (wp.showCmd==SW_MAXIMIZE)
							SetWindowPos(hwndDlg,0,0,0,rcWin.right - rcWin.left - (rcList.right - rcList.left + 11) ,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
						SetWindowPos(hwndDlg,0,rcWin.left,rcWin.top,rcWin.right - rcWin.left + (rcList.right-rcList.left) + 11,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
						EnableWindow(GetDlgItem(hwndDlg,IDC_SAVENUMBER),0);
						TreeView_DeleteAllItems(GetDlgItem(hwndDlg,IDC_NUMBERSLIST));
						hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
						while (hContact!=NULL) 
						{	
							int i,iHasSms=0;
							TVINSERTSTRUCT tvis;
							HTREEITEM hParent;
							char idstr[256];
							tvis.item.mask=TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE;
							tvis.hInsertAfter=TVI_SORT;
							tvis.item.iImage=tvis.item.iSelectedImage=0;
							{	
								DBVARIANT dbv;
								char *szProto;
								szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
								if(!DBGetContactSettingTString(hContact,szProto,"Cellular",&dbv)) 
								{
									if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 				
									{
										TCHAR *cTmp;
										dbv.ptszVal[lstrlen(dbv.ptszVal)-4]=_T('\0');
										cTmp=mir_alloc((lstrlen(dbv.ptszVal)+2)*sizeof(TCHAR));
										lstrcpy(cTmp,_T("+"));
										lstrcat(cTmp,strCellular(dbv.ptszVal));
										if(iHasSms==0)
										{
											tvis.hParent=NULL;
											tvis.item.pszText=(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,(LPARAM)GCDNF_TCHAR);
											hParent=TreeView_InsertItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvis);
											tvis.item.pszText=cTmp;
											tvis.hParent=hParent;
											TreeView_InsertItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvis);
											iHasSms=1;											
										}	
										else
										{
											tvis.hParent=hParent;
											tvis.item.pszText=cTmp;
											TreeView_InsertItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvis);											
										}
										mir_free(cTmp);
									}
									DBFreeVariant(&dbv);
								}
								for(i=0;;i++) 
								{
									wsprintfA(idstr,"MyPhone%d",i);
									if(DBGetContactSettingTString(hContact,"UserInfo",idstr,&dbv))
										break;
									wsprintfA(idstr,Translate("Custom %d"),i+1);
									if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 	
									{
										TCHAR *cTmp;
										dbv.ptszVal[lstrlen(dbv.ptszVal)-4]=_T('\0');
										cTmp=mir_alloc((lstrlen(dbv.ptszVal)+2)*sizeof(TCHAR));
										lstrcpy(cTmp,_T("+"));
										lstrcat(cTmp,strCellular(dbv.ptszVal));
										if(iHasSms==0)
										{
											tvis.hParent=NULL;
											tvis.item.pszText=(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,(LPARAM)GCDNF_TCHAR);
											hParent=TreeView_InsertItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvis);
											tvis.item.pszText=cTmp;
											tvis.hParent=hParent;
											TreeView_InsertItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvis);
											iHasSms=1;	
										}	
										else
										{
											tvis.hParent=hParent;
											tvis.item.pszText=cTmp;
											TreeView_InsertItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvis);											
										}
										mir_free(cTmp);
									}
									DBFreeVariant(&dbv);
								}
							}						
							hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0);		
						}
					}			
					else
					{
						RECT rcWin,rcList;
						WINDOWPLACEMENT wp;
						SetSendSMSWindowMultiple(hwndDlg,0);
						SetDlgItemText(hwndDlg,IDC_MULTIPLE,TranslateT("Multiple >>"));
						GetWindowRect(hwndDlg,&rcWin);
						GetWindowRect(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&rcList);
						wp.length = sizeof(WINDOWPLACEMENT);
						GetWindowPlacement(hwndDlg,&wp);
						SetWindowPos(hwndDlg,0,rcWin.left,rcWin.top,rcWin.right-rcWin.left - (rcList.right-rcList.left) - 11,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
						if (wp.showCmd==SW_MAXIMIZE)
							SetWindowPos(hwndDlg,0,0,0,rcWin.right - rcWin.left + (rcList.right - rcList.left + 11) ,rcWin.bottom - rcWin.top,SWP_NOZORDER|SWP_NOMOVE);
						if(GetSendSMSWindowHContact(hwndDlg) != NULL)
						{
							TCHAR number[161];
							GetDlgItemText(hwndDlg,IDC_ADDRESS,number,sizeof(number));
							SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_RESETCONTENT,0,0);
							{
								int i;
								char idstr[256];
								TCHAR *cTmp;
								HANDLE hContact;
								DBVARIANT dbv;
								char *szProto;
								hContact=GetSendSMSWindowHContact(hwndDlg);
								SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_RESETCONTENT,0,0);
								szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
								if(!DBGetContactSettingTString(hContact,szProto,"Cellular",&dbv)) 
								{
									if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 
									{
										dbv.ptszVal[lstrlen(dbv.ptszVal)-4]=_T('\0');
										cTmp=(TCHAR*)mir_alloc((lstrlen(dbv.ptszVal)+2)*sizeof(TCHAR));
										lstrcpy(cTmp,_T("+"));
										lstrcat(cTmp,strCellular(dbv.ptszVal));
										SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)cTmp);
										mir_free(cTmp);
									}
									DBFreeVariant(&dbv);
								}
								for(i=0;;i++) 
								{
									wsprintfA(idstr,"MyPhone%d",i);
									if(DBGetContactSettingTString(hContact,"UserInfo",idstr,&dbv))
										break;
									wsprintfA(idstr,Translate("Custom %d"),i+1);
									if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 
									{
										dbv.ptszVal[lstrlen(dbv.ptszVal)-4]=_T('\0');
										cTmp=(TCHAR*)mir_alloc((lstrlen(dbv.ptszVal)+2)*sizeof(TCHAR));
										lstrcpy(cTmp,_T("+"));
										lstrcat(cTmp,strCellular(dbv.ptszVal));
										SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)cTmp);
										mir_free(cTmp);
									}
									DBFreeVariant(&dbv);
								}
							}
							EnableWindow(GetDlgItem(hwndDlg,IDC_SAVENUMBER),1);
							SetDlgItemText(hwndDlg,IDC_ADDRESS,number);								
						}
						//SetWindowLong(GetDlgItem(hwndDlg,IDC_ADDNUMBER),GWL_STYLE,WS_TABSTOP);
						//SetWindowLong(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),GWL_STYLE,WS_TABSTOP);
					}	
					break;
				case IDC_ADDNUMBER:
					{	
						TVINSERTSTRUCT tvis;
						TCHAR number[161];
						int isValid=1;
						tvis.item.mask=TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE;
						tvis.hInsertAfter=TVI_SORT;
						tvis.hParent=NULL;
						tvis.item.iImage=tvis.item.iSelectedImage=0;
						GetDlgItemText(hwndDlg,IDC_ADDRESS,number,sizeof(number));
						if(lstrlen(number)<7 || number[0]!=_T('+')) isValid=0;
						if(isValid) isValid=(lstrlen(number+1)==(int)_tcsspn(number+1,_T("0123456789 ()-")));
						if(!isValid) {
							MessageBox(hwndDlg,TranslateT("The phone number should start with a + and consist of numbers, spaces, brackets and hyphens only."),TranslateT("Invalid Phone Number"),MB_OK);
							break;
						}
						tvis.item.pszText=number;
						TreeView_InsertItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvis);
					}	
					break;
				case IDC_HISTORY:
					CallService(MS_HISTORY_SHOWCONTACTHISTORY,(WPARAM)GetSendSMSWindowHContact(hwndDlg),0);
					break;
				case IDOK:
					{
						TCHAR number[161];
						TCHAR text[161];
						if (GetNumAccountList()==0)
						{
							MessageBox(NULL,TranslateT("Can't send SMS. There isn't loaded account which support SMS sending."),TranslateT("SMS Plugin Error"),MB_OK|MB_ICONERROR);
							return 0;
						}
						UpadteSendSMSWindowAccount(hwndDlg);
						GetDlgItemText(hwndDlg,IDC_MESSAGE,text,sizeof(text));
						{
							int length;
							TCHAR *cTmp;
							//cTmp=(TCHAR *)mir_alloc(256*sizeof(TCHAR));
							//encode_utf8(text,cTmp);
							cTmp = (TCHAR*)mir_utf8encodeT(text);
							if(!lstrcmp(cTmp,text))
								length=160;
							else
								length=70;
							mir_free(cTmp);
							if(GetWindowTextLength(GetDlgItem(hwndDlg,IDC_MESSAGE)) > length)
							{
								MessageBox(hwndDlg,TranslateT("Message is too long, press OK to continue."),TranslateT("Error - Message too long"),MB_OK);
								break;
							}
						}
						if(GetSendSMSWindowMultiple(hwndDlg) <= 0)
						{
							GetDlgItemText(hwndDlg,IDC_ADDRESS,number,sizeof(number));
							if(number[0]!=_T('+') || number[1]<_T('1') || number[1]>_T('9') || number[2]==_T('\0')) {
								MessageBox(hwndDlg,TranslateT("Valid phone numbers are of the form '+(country code)(phone number)'. The contents of the phone number portion is dependent on the national layout of phone numbers, but often omits the leading zero."),TranslateT("Invalid phone number"),MB_OK);
								SetFocus(GetDlgItem(hwndDlg,IDC_ADDRESS));
								SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_SETEDITSEL,0,MAKELPARAM(0,-1));
								break;
							}
							StartSmsSend(hwndDlg,number,text);
							SetSendSMSWindowNumber(hwndDlg,number);
							EnableWindow(GetDlgItem(hwndDlg,IDOK),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_SAVENUMBER),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_NAME),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_MULTIPLE),FALSE);
							SendDlgItemMessage(hwndDlg,IDC_MESSAGE,EM_SETREADONLY,TRUE,0);
							EnableWindow(GetDlgItem(hwndDlg,IDC_ADDRESS),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_ACCOUNT),FALSE);
							SetTimer(hwndDlg,TIMERID_MSGSEND,TIMEOUT_MSGSEND,NULL);
						}
						else
						{
							TVITEM tvi;
							int iImage=0;
							if(GetSendSMSWindowNextHItem(hwndDlg,TreeView_GetRoot(GetDlgItem(hwndDlg,IDC_NUMBERSLIST)))==NULL)
							{
								MessageBox(hwndDlg,TranslateT("There must be numbers in the list first."),TranslateT("No Numbers"),MB_OK);
								break;
							}
							SetSendSMSWindowHItemSend(hwndDlg,GetSendSMSWindowNextHItem(hwndDlg,TreeView_GetRoot(GetDlgItem(hwndDlg,IDC_NUMBERSLIST))));
							tvi.mask=TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE;
							tvi.hItem=GetSendSMSWindowHItemSend(hwndDlg);
							tvi.pszText=number;
							tvi.cchTextMax=sizeof(number);
							tvi.iImage=tvi.iSelectedImage=iImage;
							TreeView_GetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvi);
							SendSMSWindowNext(hwndDlg);
							EnableWindow(GetDlgItem(hwndDlg,IDOK),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_SAVENUMBER),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_NAME),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_MULTIPLE),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_ADDNUMBER),FALSE);
							//EnableWindow(GetDlgItem(hwndDlg,IDC_REMOVENUMBER),FALSE);
							SendDlgItemMessage(hwndDlg,IDC_MESSAGE,EM_SETREADONLY,TRUE,0);
							EnableWindow(GetDlgItem(hwndDlg,IDC_ADDRESS),FALSE);
							EnableWindow(GetDlgItem(hwndDlg,IDC_ACCOUNT),FALSE);
							SetTimer(hwndDlg,TIMERID_MSGSEND,TIMEOUT_MSGSEND,NULL);						
						}
					}
					break;
				case IDCANCEL:
					KillTimer(GetParent(hwndDlg),TIMERID_MSGSEND);
					RemoveSendSMSWindow(hwndDlg);
					DeleteObject(hFont);
					break;
				case IDC_MESSAGE:
					if(HIWORD(wParam)==EN_CHANGE) {
						TCHAR str[80],text[161];
						TCHAR *cTmp;
						int length;
						int count=GetWindowTextLength(GetDlgItem(hwndDlg,IDC_MESSAGE));
						//cTmp=(TCHAR *)mir_alloc(256*sizeof(TCHAR));
						GetDlgItemText(hwndDlg,IDC_MESSAGE,text,sizeof(text));
						//TODO: CHECK
						//encode_utf8(text,cTmp);
						cTmp = (TCHAR*)mir_utf8encodeT(text);
						if(!lstrcmp(cTmp,text))
							length=160;
						else
							length=70;
						mir_free(cTmp);
						wsprintf(str,_T("%d/%d"),count,length);
						SetDlgItemText(hwndDlg,IDC_COUNT,str);
						EnableWindow(GetDlgItem(hwndDlg,IDOK),count);
					}
					break;
				case IDC_SAVENUMBER:
					{
						char *szIdTemplate="MyPhone%d";
						char idstr[33];
						TCHAR szText[128];
						int isValid=1;
						int i;
						DBVARIANT dbv;
						GetDlgItemText(hwndDlg,IDC_ADDRESS,szText,sizeof(szText));
						if(lstrlen(szText)<7 || szText[0]!=_T('+')) isValid=0;
						if(isValid) isValid=(lstrlen(szText+1)==(int)_tcsspn(szText+1,_T("0123456789 ()-")));
						if(!isValid) {
							MessageBox(hwndDlg,TranslateT("The phone number should start with a + and consist of numbers, spaces, brackets and hyphens only."),TranslateT("Invalid Phone Number"),MB_OK);
							break;
						}
						lstrcat(szText,_T(" SMS"));
						for(i=0;;i++) {
							wsprintfA(idstr,szIdTemplate,i);
							if(DBGetContactSettingTString(GetSendSMSWindowHContact(hwndDlg),"UserInfo",idstr,&dbv)) break;
							DBFreeVariant(&dbv);
						}
						DBWriteContactSettingTString(GetSendSMSWindowHContact(hwndDlg),"UserInfo",idstr,szText);
					}
					break;
				case IDC_NAME:
					if(HIWORD(wParam)==CBN_SELCHANGE) 
					{
						int i;
						char idstr[256];
						HANDLE hContact=NULL;
						SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_RESETCONTENT,0,0);
						if(SendMessage(GetDlgItem(hwndDlg,IDC_NAME), CB_GETCURSEL, 0, 0) == 0)
							break;
						hContact=GetSMSContactHandle(hwndDlg,SendMessage(GetDlgItem(hwndDlg,IDC_NAME), CB_GETCURSEL, 0, 0) - 1);
						if(hContact!=NULL)
						{	
							TCHAR *cTmp;
							DBVARIANT dbv;
							char *szProto;
							szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
							SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_RESETCONTENT,0,0);
							if(!DBGetContactSettingTString(hContact,szProto,"Cellular",&dbv)) 
							{
								if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 
								{
									dbv.ptszVal[lstrlen(dbv.ptszVal)-4]=_T('\0');
									cTmp=(TCHAR*)mir_alloc((lstrlen(dbv.ptszVal)+2)*sizeof(TCHAR));
									lstrcpy(cTmp,_T("+"));
									lstrcat(cTmp,strCellular(dbv.ptszVal));
									SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)cTmp);
									SetDlgItemText(hwndDlg,IDC_ADDRESS,cTmp);
									mir_free(cTmp);
								}
								DBFreeVariant(&dbv);
							}
							for(i=0;;i++) 
							{
								wsprintfA(idstr,"MyPhone%d",i);
								if(DBGetContactSettingTString(hContact,"UserInfo",idstr,&dbv))
									break;
								wsprintfA(idstr,Translate("Custom %d"),i+1);
								if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 							
								{
									dbv.ptszVal[lstrlen(dbv.ptszVal)-4]=_T('\0');
									cTmp=(TCHAR*)mir_alloc((lstrlen(dbv.ptszVal)+2)*sizeof(TCHAR));
									lstrcpy(cTmp,_T("+"));
									lstrcat(cTmp,strCellular(dbv.ptszVal));
									SendDlgItemMessage(hwndDlg,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)cTmp);
									SetDlgItemText(hwndDlg,IDC_ADDRESS,cTmp);
									mir_free(cTmp);
								}
								DBFreeVariant(&dbv);
							}
						}													
					}
					break;
			}
			break;
		case WM_NOTIFY:
			switch(((NMHDR*)lParam)->idFrom) {
				case IDC_NUMBERSLIST:
					switch(((NMHDR*)lParam)->code) {
						case NM_CLICK:
						{	
							TVHITTESTINFO hti;
							hti.pt.x=(short)LOWORD(GetMessagePos());
							hti.pt.y=(short)HIWORD(GetMessagePos());
							ScreenToClient(((LPNMHDR)lParam)->hwndFrom,&hti.pt);
							if(TreeView_HitTest(((LPNMHDR)lParam)->hwndFrom,&hti)) {
								if(hti.flags&TVHT_ONITEMICON) 
								{
									TVITEM tvi;
									tvi.mask=TVIF_IMAGE|TVIF_SELECTEDIMAGE;
									tvi.hItem=hti.hItem;
									TreeView_GetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
									tvi.iImage=tvi.iSelectedImage=!tvi.iImage;
									TreeView_SetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
									if(TreeView_GetParent(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),hti.hItem)==NULL)
									{
										int iImage;
										iImage=tvi.iImage;
										tvi.hItem=TreeView_GetChild(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),hti.hItem);
										while(tvi.hItem!=NULL)
										{
											TreeView_GetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
											tvi.iImage=tvi.iSelectedImage=iImage;
											TreeView_SetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
											tvi.hItem=TreeView_GetNextSibling(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),tvi.hItem);
										}
									}
									else
									{
										int iImage;
										int iSame=1;
										HTREEITEM hParent;
										iImage=tvi.iImage;
										hParent=TreeView_GetParent(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),hti.hItem);
										tvi.hItem=TreeView_GetChild(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),hParent);
										while(tvi.hItem!=NULL)
										{
											TreeView_GetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
											if(tvi.iImage!=iImage)
											{
												iSame=0;
												break;
											}								
											tvi.hItem=TreeView_GetNextSibling(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),tvi.hItem);
										}
										if(iSame==1)
										{
											tvi.hItem=hParent;
											tvi.iImage=tvi.iSelectedImage=iImage;
											TreeView_SetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
										}
										else
										{
											tvi.hItem=hParent;
											tvi.iImage=tvi.iSelectedImage=2;
											TreeView_SetItem(((LPNMHDR)lParam)->hwndFrom,&tvi);
										}
									}
								}
							}
							break;
						}
					}
				}
			break;			
		case WM_CLOSE:
			RemWinHandle(GetDlgItem(hwndDlg,IDC_MESSAGE));
			KillTimer(GetParent(hwndDlg),TIMERID_MSGSEND);
			RemoveSendSMSWindow(hwndDlg);
			ImageList_Destroy(TreeView_GetImageList(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),TVSIL_NORMAL));
			break;
	}
	return FALSE;
}

BOOL CALLBACK SMSTimedOutDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg) {
		case WM_INITDIALOG:
			{
				RECT rc,rcParent;
				TranslateDialogDefault(hwndDlg); 
				GetWindowRect(hwndDlg,&rc);
				GetWindowRect(GetParent(hwndDlg),&rcParent);
				SetWindowPos(hwndDlg,0,(rcParent.left+rcParent.right-(rc.right-rc.left))/2,(rcParent.top+rcParent.bottom-(rc.bottom-rc.top))/2,0,0,SWP_NOZORDER|SWP_NOSIZE);
				KillTimer(GetParent(hwndDlg),TIMERID_MSGSEND);
			}
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam)) {
		case IDOK:
			SendMessage(GetParent(hwndDlg),DM_TIMEOUTDECIDED,TIMEDOUT_RETRY,0);
			DestroyWindow(hwndDlg);
			break;
		case IDCANCEL:
			SendMessage(GetParent(hwndDlg),DM_TIMEOUTDECIDED,TIMEDOUT_CANCEL,0);
			DestroyWindow(hwndDlg);
			break;
			}
			break;
	}
	return FALSE;
} 

BOOL CALLBACK SMSAcceptedDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg) {
		case WM_INITDIALOG:
			{
				RECT rc,rcParent;
				TranslateDialogDefault(hwndDlg); 
				GetWindowRect(hwndDlg,&rc);
				GetWindowRect(GetParent(hwndDlg),&rcParent);
				SetWindowPos(hwndDlg,0,(rcParent.left+rcParent.right-(rc.right-rc.left))/2,(rcParent.top+rcParent.bottom-(rc.bottom-rc.top))/2,0,0,SWP_NOZORDER|SWP_NOSIZE);
			}
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam)) 
			{
				case IDOK:
					RemoveSendSMSWindow(GetParent(hwndDlg));
					DestroyWindow(hwndDlg);
					break;
			}
			break;
	}
	return FALSE;
}

//SMS Send window list functions

//This function create a new SMS send window, and insert it to the list.
//The function gets void and return the window HWND
/*
HWND AddSendSMSWindow()
{
DBEVENTINFO dbeiTmp={0};
SMSWindow SMSWindowTmp;
SMSWindowTmp.hwndSMS = CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMS),NULL,SendSmsDlgProc);
SMSWindowTmp.hProcess = NULL;
SMSWindowTmp.hContact = NULL;
SMSWindowTmp.hMyContact=NULL;
SMSWindowTmp.SMSContactsList=NULL;
SMSWindowTmp.SMSContactsListNum=0;
SMSWindowTmp.iMultiple=0;
SMSWindowTmp.HItemSend=NULL;
SMSWindowTmp.dbei = dbeiTmp;
SMSWindowNum++;
SMSWindowList=(SMSWindow*)mir_realloc(SMSWindowList,sizeof(SMSWindow) * SMSWindowNum);
*(SMSWindowList + SMSWindowNum - 1) = SMSWindowTmp;
return SMSWindowTmp.hwndSMS;
}*/

//
HWND AddSendSMSWindow(HANDLE hContact)
{
	DBEVENTINFO dbeiTmp={0};
	SMSWindowNum++;
	SMSWindowList=(SMSWindow*)mir_realloc(SMSWindowList,sizeof(SMSWindow) * SMSWindowNum);
	(SMSWindowList + SMSWindowNum - 1)->hProcess = NULL;
	(SMSWindowList + SMSWindowNum - 1)->hContact = NULL;
	(SMSWindowList + SMSWindowNum - 1)->hMyContact = hContact;
	(SMSWindowList + SMSWindowNum - 1)->SMSContactsList=NULL;
	(SMSWindowList + SMSWindowNum - 1)->SMSContactsListNum=0;
	(SMSWindowList + SMSWindowNum - 1)->iMultiple=0;
	(SMSWindowList + SMSWindowNum - 1)->HItemSend=NULL;
	(SMSWindowList + SMSWindowNum - 1)->dbei = dbeiTmp;
	(SMSWindowList + SMSWindowNum - 1)->tAccount = NULL;
	(SMSWindowList + SMSWindowNum - 1)->hwndSMS = CreateDialogParam(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMS),NULL,SendSmsDlgProc,(LPARAM)hContact);
	return (SMSWindowList + SMSWindowNum - 1)->hwndSMS;
}

//This function close the SMS send window that given, and remove it from the list.
//The function gets the HWND of the window that should be removed and return void
void RemoveSendSMSWindow(HWND hwndRemove)
{
	int i,iDel;
	SMSWindow SMSWindowTmp;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndRemove)
			break;
	iDel=i;
	{
		WINDOWPLACEMENT wp={0};
		HANDLE hContact;
		if(DBGetContactSettingByte(NULL,SMSPLUGIN,"SavePerContact",0))
			hContact=GetSendSMSWindowHContact(hwndRemove);
		else hContact=NULL;
		wp.length=sizeof(wp);
		GetWindowPlacement(hwndRemove,&wp);
		DBWriteContactSettingDword(hContact,SMSPLUGIN,"sendx",wp.rcNormalPosition.left);
		DBWriteContactSettingDword(hContact,SMSPLUGIN,"sendy",wp.rcNormalPosition.top);
		DBWriteContactSettingDword(hContact,SMSPLUGIN,"sendwidth",wp.rcNormalPosition.right-wp.rcNormalPosition.left-(GetSendSMSWindowMultiple(hwndRemove)?181:0));
		DBWriteContactSettingDword(hContact,SMSPLUGIN,"sendheight",wp.rcNormalPosition.bottom-wp.rcNormalPosition.top);
	}
	DestroyWindow((SMSWindowList + iDel)->hwndSMS);
	mir_free((SMSWindowList + iDel)->tAccount);
	RemoveSMSContacts((SMSWindowList + iDel)->hwndSMS);
	SMSWindowNum--;
	SMSWindowTmp = *(SMSWindowList + SMSWindowNum);
	if(SMSWindowNum != 0)
		SMSWindowList=(SMSWindow*)mir_realloc(SMSWindowList,sizeof(SMSWindow)*SMSWindowNum);
	else
		SMSWindowList=NULL;
	if(iDel < SMSWindowNum)
		*(SMSWindowList + iDel) = SMSWindowTmp;
}

//This function destroy all SMS receive windows
void RemoveAllSendSMSWindow()
{
	int i;
	for(i=0;i < SMSWindowNum - 1;i++)
	{
		RemoveSMSContacts((SMSWindowList + i)->hwndSMS);
		DestroyWindow((SMSWindowList + i)->hwndSMS);
		mir_free((SMSWindowList + i)->tAccount);
	}
	SMSWindowNum=0;
	mir_free(SMSWindowList);
	SMSWindowList=NULL;
}

//This function set the contact info of the person we send him the in the given to the SMS send window.
//The function gets the HWND of the window and the HANDLE of the contact and return void
void SetSendSMSWindowHContact(HWND hwndDlg, HANDLE hContact)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			(SMSWindowList + i)->hMyContact = hContact;
			return;
		}
}

//This function set the process info of the send procedure we sent with the given SMS send window.
//The function gets the HWND of the window and the HANDLE of the process and return void
void SetSendSMSWindowHProcess(HWND hwndDlg, HANDLE hProcess)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			(SMSWindowList + i)->hProcess = hProcess;
			return;
		}
}

//This function set the databsae info of the sent message we sent with the SMS send window.
//The function gets the HWND of the window and the DBEI of the database information of the message
//and return void
void SetSendSMSWindowDbei(HWND hwndDlg, DBEVENTINFO dbei)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			(SMSWindowList + i)->dbei = dbei;
			return;
		}
}

//
void SetSendSMSWindowMultiple(HWND hwndDlg, int iMultiple)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			(SMSWindowList + i)->iMultiple = iMultiple;
			return;
		}
}

//
void SetSendSMSWindowNumber(HWND hwndDlg, TCHAR *number)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			if(GetSendSMSWindowMultiple(hwndDlg) <= 0)
				(SMSWindowList + i)->hContact = (SMSWindowList + i)->hMyContact;
			else
				(SMSWindowList + i)->hContact = CellularToHandle(number);
			return;
		}
}

//
void SetSendSMSWindowAsSent(HWND hwndDlg)
{
	//	LVITEM lvi;
	//	char number[161];
	//	lvi.mask=LVIF_TEXT|LVIF_IMAGE;
	//	lvi.iItem=GetSendSMSWindowSMSSend(hwndDlg) - 1;
	//	lvi.iSubItem=0;
	//	ListView_GetItemText(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),GetSendSMSWindowSMSSend(hwndDlg) - 1,0,number,sizeof(number));
	//	lvi.pszText=number;
	//	lvi.iImage=2;
	//	ListView_SetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&lvi);
	//	ListView_RedrawItems(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),0,ListView_GetItemCount(GetDlgItem(hwndDlg,IDC_NUMBERSLIST)) - 1);							
}

//
void SetSendSMSWindowHItemSend(HWND hwndDlg, HTREEITEM HItemSend)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			(SMSWindowList + i)->HItemSend=HItemSend;
			return;
		}
}

//This function get a HWND of SMS send window and add its database information into Miranda-IM database
//The function gets the HWND of the window and return void
//and return void
void AddSendSMSWindowDB(HWND hwndDlg)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			CallService(MS_DB_EVENT_ADD, (WPARAM)(SMSWindowList + i)->hContact, (LPARAM)&(SMSWindowList + i)->dbei);
			return;
		}

}

//This function return the HWND of a SMS send window that have the same process as given.
//The function gets the HANDLE of a process and return the HWND of the SMS send window that has
//the same process
HWND GetHwndByHProcess(HANDLE hProcess)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hProcess == hProcess)
			return (SMSWindowList + i)->hwndSMS;
	return NULL;		
}

//This function return the contact HANDLE for the given to the SMS send window.
//The function gets the HWND of the window and return the HANDLE of the contact.
HANDLE GetSendSMSWindowHContact(HWND hwndDlg)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			return (SMSWindowList + i)->hMyContact;
		}
		return NULL;
}

//This function get the HANDLE of an user. if there is already a SMS send window for this contact
//it return its HWND else the function return NULL.
//The function gets the HANDLE of a contact and return HWND
HWND IsOtherInstanceHContact(HANDLE hContact)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hMyContact == hContact)
			return (SMSWindowList + i)->hwndSMS;
	return NULL;
}

//
int GetSendSMSWindowMultiple(HWND hwndDlg)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			return (SMSWindowList + i)->iMultiple;
		}
		return -1;
}

//
HTREEITEM GetSendSMSWindowHItemSend(HWND hwndDlg)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			return (SMSWindowList + i)->HItemSend;
		}
		return NULL;
}

//
void SendSMSWindowNext(HWND hwndDlg)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
		{
			TCHAR number[161];
			TCHAR text[161];
			TVITEM tvi;
			GetDlgItemText(hwndDlg,IDC_MESSAGE,text,sizeof(text));
			//			if(GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg))==NULL)
			//				SetSendSMSWindowMultiple(hwndDlg,0);	
			tvi.mask=TVIF_TEXT;
			tvi.hItem=GetSendSMSWindowHItemSend(hwndDlg);
			tvi.pszText=number;
			tvi.cchTextMax=sizeof(number);
			TreeView_GetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvi);
			TreeView_SelectItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),tvi.hItem);
			StartSmsSend(hwndDlg,number,text);
			SetTimer(hwndDlg,TIMERID_MSGSEND,TIMEOUT_MSGSEND,NULL);
			SetSendSMSWindowNumber(hwndDlg,number);
		}
}

//
HTREEITEM GetSendSMSWindowNextHItem(HWND hwndDlg, HTREEITEM hItem)
{
	int isFound=0;
	int iImage=0;
	TCHAR number[161];
	HTREEITEM hItemNext;
	if (hItem == TreeView_GetRoot(GetDlgItem(hwndDlg,IDC_NUMBERSLIST)))
		isFound=1;
	for (hItemNext = TreeView_GetRoot(GetDlgItem(hwndDlg,IDC_NUMBERSLIST)); hItemNext!=NULL; hItemNext = TreeView_GetNextSibling(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),hItemNext))
	{
		TVITEM tvi;
		tvi.mask=TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE;
		tvi.hItem=hItemNext;
		tvi.pszText=number;
		tvi.cchTextMax=sizeof(number);
		tvi.iImage=tvi.iSelectedImage=iImage;
		TreeView_GetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvi);
		if ((hItem == hItemNext) && (hItem != TreeView_GetRoot(GetDlgItem(hwndDlg,IDC_NUMBERSLIST))))
		{
			isFound=1;
			continue;
		}
		if ((tvi.iImage != 0) || (tvi.iSelectedImage != 0))
			if (TreeView_GetChild(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),hItemNext) == NULL)
			{
				if (isFound == 0)
					continue;
				else
					return hItemNext;
			}
			else
			{
				HTREEITEM hItemChild;
				for (hItemChild = TreeView_GetChild(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),hItemNext); hItemChild!=NULL; hItemChild = TreeView_GetNextSibling(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),hItemChild))
				{
					TVITEM tvi;
					tvi.mask=TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE;
					tvi.hItem=hItemChild;
					tvi.pszText=number;
					tvi.cchTextMax=sizeof(number);
					tvi.iImage=tvi.iSelectedImage=iImage;
					TreeView_GetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvi);
					if (hItem == hItemChild)
					{
						isFound=1;
						continue;
					}
					if ((tvi.iImage != 0) || (tvi.iSelectedImage != 0))
					{
						if (isFound == 0)
						{
							continue;
						}
						else
						{
							return hItemChild;				
						}
					}
				}
			}
	}
	return NULL;
}
//This function gets a HANDLE of a contact and add it to a list.
void AddSMSContact(HWND hwndDlg, HANDLE hContact)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
			break;
	(SMSWindowList + i)->SMSContactsListNum = (SMSWindowList + i)->SMSContactsListNum + 1;
	(SMSWindowList + i)->SMSContactsList=(HANDLE*)mir_realloc((SMSWindowList + i)->SMSContactsList,sizeof(HANDLE)*(SMSWindowList + i)->SMSContactsListNum);
	*((SMSWindowList + i)->SMSContactsList + (SMSWindowList + i)->SMSContactsListNum - 1) = hContact;
}

//This function gets the number of the given contact in the combo list and return its contact.
HANDLE GetSMSContactHandle(HWND hwndDlg, int iNum)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
			return *(((SMSWindowList + i)->SMSContactsList) + iNum);
	return NULL;
}
void UpdateSendSMSWindowAccountList(HWND hwndDlg)
{
	int i,iCount;
	TCHAR **tAccList=NULL;
	TCHAR *tDefAccount=(TCHAR*)mir_alloc(sizeof(TCHAR)*512);
	GetStringOption(OPTION_DEFACCOUNT,tDefAccount,512);
	GetAccountList(&iCount,&tAccList);
	SendDlgItemMessage(hwndDlg,IDC_ACCOUNT,CB_RESETCONTENT,0,0);
	for(i=0;i<iCount;i++)
	{
		SendDlgItemMessage(hwndDlg,IDC_ACCOUNT,CB_ADDSTRING,0,(LPARAM)tAccList[i]);
		if(i==0)	
			SendDlgItemMessage(hwndDlg, IDC_ACCOUNT, CB_SETCURSEL, 0, 0);		
		else if (!lstrcmp(tAccList[i],tDefAccount))
			SendDlgItemMessage(hwndDlg, IDC_ACCOUNT, CB_SETCURSEL, (WPARAM)i, 0);
	}
	for(i=0;i<iCount;i++)
		mir_free(tAccList[i]);
	mir_free(tAccList);
	mir_free(tDefAccount);
}
void UpdateAllSendSMSWindowsAccountLists()
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		UpdateSendSMSWindowAccountList((SMSWindowList + i)->hwndSMS);
}
void UpadteSendSMSWindowAccount(HWND hwndDlg)
{
	int i;
	TCHAR tSelAccount[512];
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
			break;
	GetDlgItemText(hwndDlg,IDC_ACCOUNT,tSelAccount,sizeof(tSelAccount));
	(SMSWindowList + i)->tAccount=(TCHAR*)mir_alloc(sizeof(TCHAR)*(lstrlen(tSelAccount)+1));
	lstrcpy((SMSWindowList + i)->tAccount,tSelAccount);
}
TCHAR* GetSendSMSWindowAccount(HWND hwndDlg)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
			break;
	return (SMSWindowList + i)->tAccount;
}
void RemoveSMSContacts(HWND hwndDlg)
{
	int i;
	for(i=0;i < SMSWindowNum;i++)
		if((SMSWindowList + i)->hwndSMS == hwndDlg)
			break;
	mir_free((SMSWindowList + i)->SMSContactsList);
	(SMSWindowList + i)->SMSContactsList=NULL;
	(SMSWindowList + i)->SMSContactsListNum=0;
}