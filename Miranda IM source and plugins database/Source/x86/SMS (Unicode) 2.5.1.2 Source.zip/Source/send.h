#ifndef _SMS_SEND_H
#define _SMS_SEND_H

/*#include "utf8.h"
#include <windows.h>
#include "crt\stdarg.h"
#include "main.h"
#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_database.h"
#include "..\..\..\include\m_protosvc.h"
#include "..\..\..\include\m_icq.h"
#include "commonHeaders.h"*/

//System includes
#include <windows.h>
#include "string.h"
#include "tchar.h"
#include "time.h"

//Miranda includes
#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_protosvc.h"
//#include "..\..\..\include\m_protocols.h"
#include "..\..\..\include\m_utils.h"
#include "..\..\..\include\m_langpack.h" //check if needed for warnings
#include "..\..\..\include\m_database.h"
#include "..\..\..\include\m_clist.h"
#include "..\..\..\include\m_icq.h"

//Other Miranda plugins

//SMSPlugin includes
//#include "commonHeaders.h"
#include "utils.h"
//#include "utf8.h"
#include "globalVariables.h"
#include "senddlg.h"
#include "..\Resource\resource.h"

void StartSmsSend(HWND hwndDlg,const TCHAR *number,const TCHAR *text);

//Decleration of Initialation\Uninitialation functions
void InitSmsSend(void);
void UninitSmsSend(void);

//Decleration of Menu SMS send click function
int SMSMenuCommand(WPARAM wParam,LPARAM lParam);
int SendSMSMenuCommand(WPARAM wParam,LPARAM lParam);


#endif