/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at http://flashmagicd.com/projects/smsplugin/
Enjoy the code and use it smartly!
*/

#include "send.h"

//This function gets HWND of the window, the number, and the message.
void StartSmsSend(HWND hwndDlg,const TCHAR *number,const TCHAR *text)
{
	TCHAR tService[512];
	TCHAR *tmpText;
	TCHAR *cNumber;
	TCHAR *tmpEncodedXML=NULL;
	HANDLE hProcess;
//	tmpText=(TCHAR *)mir_alloc(256*sizeof(TCHAR));
	tmpEncodedXML=EncodeXML(text);
	//CHECK
	//encode_utf8(tmpEncodedXML,tmpText);
	tmpText = (TCHAR*)mir_utf8encodeT(tmpEncodedXML);
	//encode_utf8(number,cNumber);
	cNumber = (TCHAR*)mir_utf8encodeT(number);
	lstrcpy(tService,GetSendSMSWindowAccount(hwndDlg));
	lstrcat(tService,TEXT(MS_SENDSMS));
#ifdef UNICODE
	//hProcess=(HANDLE)CallService(TCHAR2CHAR(tService),(WPARAM)make_utf8_string(number),(LPARAM)make_utf8_string(tmpEncodedXML));
	hProcess=(HANDLE)CallService(TCHAR2CHAR(tService),(WPARAM)mir_utf8encodeW(number),(LPARAM)mir_utf8encodeW(tmpEncodedXML));
#else
	hProcess=(HANDLE)CallService(TCHAR2CHAR(tService),(WPARAM)cNumber,(LPARAM)tmpText);
#endif
	SetSendSMSWindowHProcess(hwndDlg, hProcess);
	{
		DBEVENTINFO dbei={0}; 
		HANDLE hContactTmp;
		hContactTmp=CellularToHandle(number);
		dbei.cbSize = sizeof(dbei);
		dbei.szModule = (char*)mir_alloc(sizeof(char)*(lstrlen(GetSendSMSWindowAccount(hwndDlg))+1));
		lstrcpyA(dbei.szModule,TCHAR2CHAR(GetSendSMSWindowAccount(hwndDlg)));
		dbei.timestamp = (DWORD)time(NULL); //Casting from QWORD to DWORD 
		dbei.flags = DBEF_SENT | DBEF_TCHAR;
		dbei.eventType = ICQEVENTTYPE_SMS;
		dbei.cbBlob = (lstrlenA(Utf8IfUnicode(text))+lstrlenA(Utf8IfUnicode(number))+lstrlenA(Utf8IfUnicode(_T("SMS To: ")))+5);
		dbei.pBlob=(PBYTE)mir_alloc(dbei.cbBlob);
		lstrcpyA((char*)dbei.pBlob,Utf8IfUnicode(_T("SMS To: ")));
		lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("+")));
		lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(strCellular(number)));
		lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("\r\n")));
		lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(text));
		SetSendSMSWindowDbei(hwndDlg,dbei);
	}
	mir_free(cNumber);
	mir_free(tmpEncodedXML);
	mir_free(tmpText);
}


void InitSmsSend(void)
{
	CLISTMENUITEM mmi,umi;

	ZeroMemory(&mmi,sizeof(mmi));
	mmi.cbSize=sizeof(mmi);
	mmi.position=300050000;
	mmi.flags=CMIF_TCHAR;
	mmi.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));
	mmi.ptszName=TranslateT("Send &SMS...");
	mmi.pszService="SMS/SendSMS";
	CallService(MS_CLIST_ADDMAINMENUITEM,0,(LPARAM)&mmi);

	ZeroMemory(&umi,sizeof(umi));
	umi.cbSize=sizeof(umi);
	umi.position=-2000070000;
	umi.flags=CMIF_TCHAR;
	umi.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));
	umi.ptszName=TranslateT("&SMS Message");
	umi.pszService="SendSMS/MenuCommand";
	CallService(MS_CLIST_ADDCONTACTMENUITEM,0,(LPARAM)&umi);
	
}

void UninitSmsSend(void)
{
	RemoveAllSendSMSWindow();
}

//This function called when user clicked on the "SMS Message" on one of the users.
int SMSMenuCommand(WPARAM wParam,LPARAM lParam)
{
	TCHAR newtitle[256];
	HWND hwndSendSms;
	if (GetNumAccountList()==0)
	{
		MessageBox(NULL,TranslateT("Can't load SMS Plugin. There are no protocols loaded which support SMS sending."),TranslateT("SMS Plugin Error"),MB_OK|MB_ICONERROR);
		return 0;
	}
	hwndSendSms=IsOtherInstanceHContact((HANDLE)wParam);
	if(IsOtherInstanceHContact((HANDLE)wParam) != NULL)
	{
		SetFocus(hwndSendSms);
		return 0;
	}
	hwndSendSms=AddSendSMSWindow((HANDLE)wParam);
	{
		int i;
		char idstr[256];
		TCHAR *tcTmp;
		HANDLE hContact=NULL;
		DBVARIANT dbv;
		char *szProto;
		hContact=(HANDLE)wParam;
		SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_RESETCONTENT,0,0);
		szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
		if(!DBGetContactSettingTString(hContact,szProto,"Cellular",&dbv)) 
		{
			if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 
			{
				dbv.ptszVal[lstrlen(dbv.ptszVal)-4]=_T('\0');
				tcTmp=(TCHAR*)mir_alloc(sizeof(TCHAR)*(lstrlen(dbv.ptszVal)+2));
				lstrcpy(tcTmp,_T("+"));
				lstrcat(tcTmp,strCellular(dbv.ptszVal));
				SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)tcTmp);
				SetDlgItemText(hwndSendSms,IDC_ADDRESS,tcTmp);
				mir_free(tcTmp);
			}
			DBFreeVariant(&dbv);
		}
		for(i=0;;i++) 
		{
			wsprintfA(idstr,"MyPhone%d",i);
			if(DBGetContactSettingTString(hContact,"UserInfo",idstr,&dbv))
				break;
			wsprintfA(idstr,Translate("Custom %d"),i+1);
			if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 
			{
				dbv.pszVal[lstrlen(dbv.ptszVal)-4]=_T('\0');
				tcTmp=(TCHAR*)mir_alloc(sizeof(TCHAR)*(lstrlen(dbv.ptszVal)+2));
				lstrcpy(tcTmp,_T("+"));
				lstrcat(tcTmp,strCellular(dbv.ptszVal));
				SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_ADDSTRING,0,(LPARAM)tcTmp);
				SetDlgItemText(hwndSendSms,IDC_ADDRESS,tcTmp);
				mir_free(tcTmp);
			}
			DBFreeVariant(&dbv);
		}
	}
	SendMessage(GetDlgItem(hwndSendSms, IDC_NAME), CB_ADDSTRING, 0, (LPARAM)(char*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wParam,(LPARAM)GCDNF_TCHAR));
	SendDlgItemMessage(hwndSendSms, IDC_NAME, CB_SETCURSEL, 0, 0);
	lstrcpy(newtitle,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wParam,(LPARAM)GCDNF_TCHAR));
	lstrcat(newtitle,_T(" - "));
	lstrcat(newtitle,TranslateT("Send SMS"));
	SetWindowText(hwndSendSms,newtitle);
	SetFocus(GetDlgItem(hwndSendSms,IDC_MESSAGE));
	SetSendSMSWindowHContact(hwndSendSms,(HANDLE)wParam);
	return 0;
}

//This function called when user clicked on the "SMS Send" in the Main Menu.
int SendSMSMenuCommand(WPARAM wParam,LPARAM lParam)
{
	TCHAR newtitle[256];
	HWND hwndSendSms;
	HANDLE hContact=NULL;
	if (GetNumAccountList()==0)
	{
		MessageBox(NULL,TranslateT("Can't load SMS Plugin. There are no protocols loaded which support SMS sending."),TranslateT("SMS Plugin Error"),MB_OK|MB_ICONERROR);
		return 0;
	}
	hwndSendSms=AddSendSMSWindow(NULL);
	EnableWindow(GetDlgItem(hwndSendSms,IDC_NAME),1);
	EnableWindow(GetDlgItem(hwndSendSms,IDC_SAVENUMBER),0);
	SendDlgItemMessage(hwndSendSms,IDC_ADDRESS,CB_RESETCONTENT,0,0);
	SendDlgItemMessage(hwndSendSms,IDC_NAME,CB_ADDSTRING,0,(LPARAM)TranslateT("Unknown"));
	hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
	while (hContact!=NULL) 
	{
		int i,iHasSms=0;
		char idstr[256];
		DBVARIANT dbv;
		char *szProto;
		szProto = (char *) CallService(MS_PROTO_GETCONTACTBASEPROTO, (WPARAM) hContact, 0);
		if(!DBGetContactSettingTString(hContact,szProto,"Cellular",&dbv)) 
		{
			if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 				
				iHasSms=1;
			DBFreeVariant(&dbv);
		}
		for(i=0;;i++) 
		{
			wsprintfA(idstr,"MyPhone%d",i);
			if(DBGetContactSettingTString(hContact,"UserInfo",idstr,&dbv))
				break;
			wsprintfA(idstr,Translate("Custom %d"),i+1);
			if(lstrlen(dbv.ptszVal)>4 && !lstrcmp(dbv.ptszVal+lstrlen(dbv.ptszVal)-4,_T(" SMS"))) 	
				iHasSms=1;
			DBFreeVariant(&dbv);
		}
		if(iHasSms==1)
		{
			SendMessage(GetDlgItem(hwndSendSms, IDC_NAME), CB_ADDSTRING, 0, (LPARAM)(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,(LPARAM)GCDNF_TCHAR));
			AddSMSContact(hwndSendSms,hContact);
		}
		hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0);
	}
	SendDlgItemMessage(hwndSendSms, IDC_NAME, CB_SETCURSEL, 0, 0);
	lstrcpy(newtitle,TranslateT("Unknown"));
	lstrcat(newtitle,_T(" - "));
	lstrcat(newtitle,TranslateT("Send SMS"));
	SetWindowText(hwndSendSms,newtitle);
	SetFocus(GetDlgItem(hwndSendSms,IDC_MESSAGE));
	return 0;
}