#ifndef _SMS_UTILS_H
#define _SMS_UTILS_H

//System includes
#include <windows.h>
#include "tchar.h"
#include "string.h"

//Miranda includes
#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_database.h"
#include "..\..\..\include\m_protocols.h"
#include "..\..\..\include\m_langpack.h"
#include "..\..\..\include\m_system.h"

//Other Miranda plugins

//SMSPlugin includes
#include "globalVariables.h"
#include "options.h"
#include "send.h"

#ifdef _UNICODE
	#define Utf8IfUnicode(s) mir_utf8encodeW(s)
	#define CHAR2TCHAR(s) Char2WChar(s)
	#define TCHAR2CHAR(s) WChar2Char(s)
#else
	#define Utf8IfUnicode(s) s
	#define CHAR2TCHAR(s) s
	#define	TCHAR2CHAR(s) s
#endif

//Decleration of function that gets a XML string and return the asked tag.
char *GetXMLField(const char *xml,const char *tag1,...);

//Decleration of function that returns received string with only numbers
TCHAR *strCellular(const TCHAR* str);

//Decleration of function that returns HANDLE of contact by his cellular number
HANDLE CellularToHandle(const TCHAR *cNumber);

//int __cdecl MYstrncmp(const TCHAR *cStr1,const TCHAR *cStr2,int n);
TCHAR* DecodeXML(const TCHAR* cXml);
TCHAR* EncodeXML(const TCHAR* cXml);

//converting from char and to char
LPWSTR Char2WChar (const char* pCstring);
LPSTR WChar2Char(LPCWSTR s);

HINSTANCE GetPluginhInst();

void InitUtils();
void UninitUtils();

//Account list managing
int RefreshAccountList(WPARAM eventCode,LPARAM lParam);
void GetAccountList(int *iNumAcc,TCHAR*** tAccList);
int GetNumAccountList();
int IsInAccountList(char* sModule);

#endif