#ifndef _SENDDLG_H
#define _SENDDLG_H

//System includes
#include <windows.h>
#include "tchar.h"
#include "string.h"
#include "stdio.h"
#include "commctrl.h"

//Miranda includes
#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_database.h"
#include "..\..\..\include\m_protocols.h"
#include "..\..\..\include\m_langpack.h"
#include "..\..\..\include\m_clist.h"
#include "..\..\..\include\m_history.h"

//Other Miranda plugins
#include "m_autoreplacer.h"

//SMSPlugin includes
#include "..\Resource\resource.h"
//#include "utf8.h"
#include "send.h"
#include "options.h"

#define TIMEDOUT_CANCEL	    0
#define TIMEDOUT_RETRY	    1

#define TIMERID_MSGSEND      0
#define TIMEOUT_MSGSEND      30000

#define DM_TIMEOUTDECIDED    (WM_USER+18)

//Decleration of SMS sendmu  window list

typedef struct {
	HANDLE *SMSContactsList;
	int SMSContactsListNum;
	HWND hwndSMS;
	HANDLE hProcess;
	HANDLE hContact;
	HANDLE hMyContact;
	TCHAR* tAccount;
	DBEVENTINFO dbei;
	int iMultiple;
	HTREEITEM HItemSend;
} SMSWindow;

BOOL CALLBACK SMSAcceptedDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
//HWND AddSendSMSWindow();
HWND AddSendSMSWindow(HANDLE hContact);
void RemoveSendSMSWindow(HWND hwndRemove);
void RemoveAllSendSMSWindow();
void SetSendSMSWindowHContact(HWND hwndDlg, HANDLE hContact);
void SetSendSMSWindowHProcess(HWND hwndDlg, HANDLE hProcess);
void SetSendSMSWindowMultiple(HWND hwndDlg, int iMultiple);
void SetSendSMSWindowNumber(HWND hwndDlg, TCHAR *number);
void SetSendSMSWindowHItemSend(HWND hwndDlg, HTREEITEM HItemSend);
void SetSendSMSWindowAsSent(HWND hwndDlg);
void AddSendSMSWindowDB(HWND hwndDlg);
HTREEITEM GetSendSMSWindowHItemSend(HWND hwndDlg);
int GetSendSMSWindowMultiple(HWND hwndDlg);
HWND GetHwndByHProcess(HANDLE hProcess);
HANDLE GetSendSMSWindowHContact(HWND hwndDlg);
HTREEITEM GetSendSMSWindowNextHItem(HWND hwndDlg, HTREEITEM hItem);
HWND IsOtherInstanceHContact(HANDLE hContact);
void AddSMSContact(HWND hwndDlg, HANDLE hContact);
HANDLE GetSMSContactHandle(HWND hwndDlg, int iNum);
void RemoveSMSContacts(HWND hwndDlg);
void SendSMSWindowNext(HWND hwndDlg);
void UpdateSendSMSWindowAccountList(HWND hwndDlg);
void UpdateAllSendSMSWindowsAccountLists();
void UpadteSendSMSWindowAccount(HWND hwndDlg);
TCHAR* GetSendSMSWindowAccount(HWND hwndDlg);
void SetSendSMSWindowDbei(HWND hwndDlg, DBEVENTINFO dbei);
BOOL CALLBACK SMSTimedOutDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
HTREEITEM GetSendSMSWindowHItemSend(HWND hwndDlg);

#endif