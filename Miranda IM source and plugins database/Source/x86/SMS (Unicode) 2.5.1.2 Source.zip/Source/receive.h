#ifndef _SMS_RECEIVE_H
#define _SMS_RECEIVE_H

//System includes
#include <windows.h>
#include "tchar.h"
#include "commctrl.h"
#include "time.h"
#include "string.h"

//Miranda includes

#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_protosvc.h"
#include "..\..\..\include\m_database.h"
#include "..\..\..\include\m_clist.h"
#include "..\..\..\include\m_langpack.h"
#include "..\..\..\include\m_icq.h"
#include "..\..\..\include\m_skin.h"
//#include "..\..\..\include\m_protocols.h"

//Other Miranda plugins

//SMSPlugin includes
#include "utils.h"
//#include "utf8.h"
#include "globalVariables.h"
#include "senddlg.h"
#include "options.h"
#include "recvdlg.h"

//SMSPlugin Resources
#include "..\Resource\resource.h"

int handleNewMessage(WPARAM wparam,LPARAM lparam);
void RestoreUnreadMessageAlerts(void);

//Decleration of Initialation\Uninitialation functions
void InitSmsRecv(void);
void UninitSmsRecv(void);

//Decleration of functions that used when user hit miranda for new message/confirmation
int ReadAckSMS(WPARAM wparam,LPARAM lparam);
int ReadMsgSMS(WPARAM wparam,LPARAM lparam);

#endif