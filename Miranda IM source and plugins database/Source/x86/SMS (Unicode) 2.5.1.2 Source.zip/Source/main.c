/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at http://flashmagicd.com/projects/smsplugin/
Enjoy the code and use it smartly!
*/

#include "main.h"

///////////////////////////  Global variables  ////////////////////////////////
HANDLE hModuleLoad=NULL;
HINSTANCE hInst;
PLUGINLINK *pluginLink;

PLUGININFOEX pluginInfo = {
	sizeof(PLUGININFOEX),
#ifdef _UNICODE
	"SMS (Unicode)",
#else
	"SMS",
#endif
	PLUGIN_MAKE_VERSION(2,5,1,1),
	"Send SMS text messages to mobile phones through the ICQ network\n based on Original SMS plugin by Richard Hughes",
	"Ariel Shulman and Ohad Gov",
	"miranda.smsplugin@gmail.com",
	"� 2001-2 Richard Hughes, 2003-9 Ariel Shulman and Ohad Gov",
	"http://www.flashmagicd.com/projects/smsplugin/",
	UNICODE_AWARE,		//not transient
	0,		//doesn't replace anything built-in
#ifdef _UNICODE
	{ 0x3099ccd1, 0xa419, 0x4de6, { 0x84, 0x15, 0xa0, 0x59, 0x50, 0xcb, 0x5c, 0x6d } } //{3099CCD1-A419-4de6-8415-A05950CB5C6D}
#else
	{ 0x46fdc1a2, 0xd7f7, 0x4361, { 0xb4, 0xb4, 0xb6, 0xb0, 0x7d, 0x21, 0x9d, 0x37 } } //{46FDC1A2-D7F7-4361-B4B4-B6B07D219D37}
#endif
};

PLUGININFO pluginInfo4Updater = {
	sizeof(PLUGININFOEX),
#ifdef _UNICODE
	"SMS (Unicode)",
#else
	"SMS",
#endif
	PLUGIN_MAKE_VERSION(2,5,1,1),
	"Send SMS text messages to mobile phones through the ICQ network\n based on Original SMS plugin by Richard Hughes",
	"Ariel Shulman and Ohad Gov",
	"miranda.smsplugin@gmail.com",
	"� 2001-2 Richard Hughes, 2003-9 Ariel Shulman and Ohad Gov",
	"http://www.flashmagicd.com/projects/smsplugin/",
	UNICODE_AWARE,		//not transient
	0
};

////////////////////////  Main DLL function  //////////////////////////////////
BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst=hinstDLL;
	return TRUE;
}

///////  ModulesLoaded - finalizes plugin's configuration on load  ////////////
static int ModulesLoaded(WPARAM wParam, LPARAM lParam)
{
	InitUtils();
	InitSmsSend();
	InitSmsRecv();
	InitOptions();

#ifdef _UNICODE
	CallService(MS_UPDATE_REGISTERFL, 3751, (WPARAM)&pluginInfo4Updater);
#else
	CallService(MS_UPDATE_REGISTERFL, 589, (WPARAM)&pluginInfo4Updater);
#endif

	return 0;
}

////////////////Performs a primary set of actions upon plugin loading//////////
int __declspec(dllexport) Load(PLUGINLINK *link)
{
	pluginLink = link;

	CreateServiceFunction("SMS/SendSMS",SendSMSMenuCommand);
	CreateServiceFunction("SRSMS/ReadSms",ReadMsgSMS);
	CreateServiceFunction("SRSMS/ReadSmsAck",ReadAckSMS);
	CreateServiceFunction("SendSMS/MenuCommand",SMSMenuCommand);
		
	hModuleLoad=HookEvent(ME_SYSTEM_MODULESLOADED, ModulesLoaded);

	return 0;
}

/////////////////////////  Unload a plugin  ///////////////////////////////////
int __declspec(dllexport) Unload(void)
{
	UninitSmsSend();
	UninitSmsRecv();
	UninitOptions();
	UninitUtils();
	UnhookEvent(hModuleLoad);
	return 0;
}

////////  MirandaPluginInfoEx - returns an information about a plugin  ////////
__declspec(dllexport) PLUGININFOEX *MirandaPluginInfoEx(DWORD mirandaVersion)
{
	if (mirandaVersion < PLUGIN_MAKE_VERSION(0, 8, 0, 0))
	{
		MessageBox( NULL, _T("SMS plugin cannot be loaded. It requires Miranda IM 0.8.0.0 or later."), _T("SMS Plugin"), MB_OK|MB_ICONWARNING|MB_SETFOREGROUND|MB_TOPMOST );
		return NULL;
	}
	return &pluginInfo;
}

//// MirandaPluginInterfaces - returns the protocol interface to the core /////
//MIID_SMS { 0x7fdcd6, 0xb7ff, 0x4b2d, { 0xbc, 0x5b, 0xca, 0x58, 0x15, 0x6e, 0x1b, 0x8f } }
static const MUUID interfaces[] = {MIID_SMS, MIID_LAST};
__declspec(dllexport)
     const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}