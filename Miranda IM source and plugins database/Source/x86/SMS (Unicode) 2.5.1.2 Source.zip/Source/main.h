#ifndef _SMS_MAIN_H
#define _SMS_MAIN_H

//System includes
#include <windows.h>
#include "string.h"
#include "stdio.h"

//Miranda includes
#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_system.h"

//Other Miranda plugins
#include "m_updater.h"

//SMSPlugin includes
#include "send.h"
#include "receive.h"
#include "options.h"

//#include <vld.h>

#define MIID_SMS { 0x7fdcd6, 0xb7ff, 0x4b2d, { 0xbc, 0x5b, 0xca, 0x58, 0x15, 0x6e, 0x1b, 0x8f } }

//Decleration of function that returns plugin instance
HINSTANCE GetPluginhInst();

#endif