/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at http://flashmagicd.com/projects/smsplugin/
Enjoy the code and use it smartly!
*/

#include "options.h"
struct FontOptionsList
{
	TCHAR *szDescr;
	COLORREF defColour;
	TCHAR *szDefFace;
	BYTE defStyle;
	char defSize;
	COLORREF colour;
} static fontOptionsList[] = {
	{LPGENT("Outgoing messages"), RGB(106, 106, 106), _T("Arial"), 0, -12},
	{LPGENT("Incoming messages"), RGB(0, 0, 0), _T("Arial"), 0, -12},
};

HANDLE hHookOPT;
HWND hwndOpt=NULL;

static BOOL CALLBACK DlgProcEditorOptions(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg) 
	{
		case WM_INITDIALOG:
			TranslateDialogDefault(hwndDlg);
			hwndOpt=hwndDlg;
			{	
				TCHAR cSign[1024];
				TCHAR cBegin[2];
				TCHAR cShowACK[2];
				TCHAR cUseSign[2];
				GetStringOption(OPTION_SIGNATURE,cSign,sizeof(cSign));
				SetDlgItemText(hwndDlg,IDC_SIGNATURE,cSign);
				GetStringOption(OPTION_SIGNATUREPOS,cBegin,sizeof(cBegin));
				if(cBegin[0] == _T('0'))
				{
					CheckDlgButton(hwndDlg,IDC_BEGIN,0);
					CheckDlgButton(hwndDlg,IDC_END,1);
				}
				else
				{
					CheckDlgButton(hwndDlg,IDC_BEGIN,1);
					CheckDlgButton(hwndDlg,IDC_END,0);
				}
				GetStringOption(OPTION_SHOWACK,cShowACK,sizeof(cShowACK));
				if(cShowACK[0] == _T('0'))
				{
					CheckDlgButton(hwndDlg,IDC_SHOWACK,0);
					CheckDlgButton(hwndDlg,IDC_NOSHOWACK,1);
				}
				else
				{
					CheckDlgButton(hwndDlg,IDC_NOSHOWACK,0);
					CheckDlgButton(hwndDlg,IDC_SHOWACK,1);
				}
				GetStringOption(OPTION_USESIGNATURE,cUseSign,sizeof(cUseSign));
				if(cUseSign[0] == _T('0'))
				{
					CheckDlgButton(hwndDlg,IDC_USESIGNATURE,0);
					EnableWindow(GetDlgItem(hwndDlg,IDC_BEGIN),0);
					EnableWindow(GetDlgItem(hwndDlg,IDC_END),0);
					EnableWindow(GetDlgItem(hwndDlg,IDC_SIGNATURE),0);
					EnableWindow(GetDlgItem(hwndDlg,IDC_SIGNGROUP),0);
				}
				else
				{
					CheckDlgButton(hwndDlg,IDC_USESIGNATURE,1);
					EnableWindow(GetDlgItem(hwndDlg,IDC_BEGIN),1);
					EnableWindow(GetDlgItem(hwndDlg,IDC_END),1);
					EnableWindow(GetDlgItem(hwndDlg,IDC_SIGNATURE),1);
					EnableWindow(GetDlgItem(hwndDlg,IDC_SIGNGROUP),1);
				}
				if(DBGetContactSettingByte(NULL,SMSPLUGIN,"SavePerContact",0))
				{
					CheckDlgButton(hwndDlg,IDC_SAVEWINPOS,1);
					CheckDlgButton(hwndDlg,IDC_NOSAVEWINPOS,0);
				}
				else
				{
					CheckDlgButton(hwndDlg,IDC_SAVEWINPOS,0);
					CheckDlgButton(hwndDlg,IDC_NOSAVEWINPOS,1);
				}
				if(DBGetContactSettingByte(NULL,SMSPLUGIN,"AutoPopup",0))
				{
					CheckDlgButton(hwndDlg,IDC_AUTOPOP,1);
					CheckDlgButton(hwndDlg,IDC_NOAUTOPOP,0);
				}
				else
				{
					CheckDlgButton(hwndDlg,IDC_AUTOPOP,0);
					CheckDlgButton(hwndDlg,IDC_NOAUTOPOP,1);
				}
			}
			UpdateSMSOptionsAccounts();
			return TRUE;
		case WM_COMMAND:
			SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);
			switch(LOWORD(wParam)) {
				case IDC_USESIGNATURE:
					if(!IsDlgButtonChecked(hwndDlg,IDC_USESIGNATURE))
					{
						CheckDlgButton(hwndDlg,IDC_USESIGNATURE,0);
						EnableWindow(GetDlgItem(hwndDlg,IDC_BEGIN),0);
						EnableWindow(GetDlgItem(hwndDlg,IDC_END),0);
						EnableWindow(GetDlgItem(hwndDlg,IDC_SIGNATURE),0);
						EnableWindow(GetDlgItem(hwndDlg,IDC_SIGNGROUP),0);
					}
					else
					{
						CheckDlgButton(hwndDlg,IDC_USESIGNATURE,1);
						EnableWindow(GetDlgItem(hwndDlg,IDC_BEGIN),1);
						EnableWindow(GetDlgItem(hwndDlg,IDC_END),1);
						EnableWindow(GetDlgItem(hwndDlg,IDC_SIGNATURE),1);
						EnableWindow(GetDlgItem(hwndDlg,IDC_SIGNGROUP),1);
					}
				}
			break;
		case WM_NOTIFY:
			switch(((LPNMHDR)lParam)->idFrom) 
			{
				case 0:
					switch (((LPNMHDR)lParam)->code)
					{
						case PSN_APPLY:
						{
							TCHAR tSign[1024];
							TCHAR tDefAccount[512];
							GetDlgItemText(hwndDlg,IDC_SIGNATURE,tSign,sizeof(tSign));
							GetDlgItemText(hwndDlg,IDC_DEFACCOUNT,tDefAccount,sizeof(tDefAccount));
							DBWriteContactSettingTString(NULL,SMSPLUGIN,"Signature",(TCHAR*)tSign);
							DBWriteContactSettingTString(NULL,SMSPLUGIN,"DefaultAccount",(TCHAR*)tDefAccount);
							if(!IsDlgButtonChecked(hwndDlg,IDC_BEGIN))
								DBWriteContactSettingTString(NULL,SMSPLUGIN,"SignaturePos",_T("0"));
							else
								DBWriteContactSettingTString(NULL,SMSPLUGIN,"SignaturePos",_T("1"));
							if(!IsDlgButtonChecked(hwndDlg,IDC_SHOWACK))
								DBWriteContactSettingTString(NULL,SMSPLUGIN,"ShowACK",_T("0"));
							else
								DBWriteContactSettingTString(NULL,SMSPLUGIN,"ShowACK",_T("1"));
							if(!IsDlgButtonChecked(hwndDlg,IDC_USESIGNATURE))
								DBWriteContactSettingTString(NULL,SMSPLUGIN,"UseSignature",_T("0"));
							else
								DBWriteContactSettingTString(NULL,SMSPLUGIN,"UseSignature",_T("1"));
							if(!IsDlgButtonChecked(hwndDlg,IDC_AUTOPOP))
								DBWriteContactSettingByte(NULL,SMSPLUGIN,"AutoPopup",0);
							else
								DBWriteContactSettingByte(NULL,SMSPLUGIN,"AutoPopup",1);
							if(!IsDlgButtonChecked(hwndDlg,IDC_SAVEWINPOS))
								DBWriteContactSettingByte(NULL,SMSPLUGIN,"SavePerContact",0);
							else
								DBWriteContactSettingByte(NULL,SMSPLUGIN,"SavePerContact",1);
						}
						return TRUE;
					}
					break;
			}
			break;
		case WM_DESTROY: 
			hwndOpt=NULL;
			break;
	}
	return FALSE;
}

static int OptInitialise(WPARAM wParam,LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp={0};

	odp.cbSize=sizeof(odp);
	odp.position=910000000;
	odp.hInstance=GetPluginhInst();
	odp.ptszGroup=(TCHAR*)TranslateT("Events");
	odp.flags=ODPF_BOLDGROUPS|ODPF_TCHAR;
	odp.pszTemplate=MAKEINTRESOURCEA(IDD_OPT_SMSPLUGIN);
	odp.ptszTitle=(TCHAR*)TranslateT("SMS Plugin");
	odp.pfnDlgProc=DlgProcEditorOptions;
	CallService(MS_OPT_ADDPAGE,wParam,(LPARAM)&odp);
	return 0;
}

void UpdateSMSOptionsAccounts()
{
	if (hwndOpt!=NULL)
	{
		int i,iCount;
		TCHAR **tAccList=NULL;
		TCHAR *tDefAccount=(TCHAR*)mir_alloc(sizeof(TCHAR)*512);
		GetStringOption(OPTION_DEFACCOUNT,tDefAccount,512);
		GetAccountList(&iCount,&tAccList);
		SendDlgItemMessage(hwndOpt,IDC_DEFACCOUNT,CB_RESETCONTENT,0,0);
		for(i=0;i<iCount;i++)
		{
			SendDlgItemMessage(hwndOpt,IDC_DEFACCOUNT,CB_ADDSTRING,0,(LPARAM)tAccList[i]);
			if(i==0)	
				SendDlgItemMessage(hwndOpt, IDC_DEFACCOUNT, CB_SETCURSEL, 0, 0);		
			else if (!lstrcmp(tAccList[i],tDefAccount))
				SendDlgItemMessage(hwndOpt, IDC_DEFACCOUNT, CB_SETCURSEL, (WPARAM)i, 0);
		}
		for(i=0;i<iCount;i++)
			mir_free(tAccList[i]);
		mir_free(tAccList);
		mir_free(tDefAccount);
	}
}
static void RegisterSMSPlugFonts( void )
{
	const int msgDlgFontCount = sizeof(fontOptionsList)/sizeof(fontOptionsList[0]);

	FontIDT fontid = {0};
	ColourIDT colourid = {0};
	char idstr[10];
	int i, index = 0;

	fontid.cbSize = sizeof(FontID);
	fontid.flags = FIDF_ALLOWREREGISTER | FIDF_DEFAULTVALID;
	for ( i = 0; i < msgDlgFontCount; i++, index++ ) {
		strncpy(fontid.dbSettingsGroup, SMSPLUGIN, sizeof(fontid.dbSettingsGroup));//Changed
		_tcsncpy(fontid.group, TranslateT("SMS Messages"), sizeof(fontid.group)/sizeof(fontid.group[0]));//Changed
		_tcsncpy(fontid.name, TranslateTS(fontOptionsList[i].szDescr), sizeof(fontid.name)/sizeof(fontid.name[0]));//Changed
		wsprintfA(idstr, "SRMFont%d", index);
		strncpy(fontid.prefix, idstr, sizeof(fontid.prefix)/sizeof(fontid.prefix[0]));//Changed
		fontid.order = index;

		fontid.deffontsettings.colour = fontOptionsList[i].defColour;
		fontid.deffontsettings.size = fontOptionsList[i].defSize;
		fontid.deffontsettings.style = fontOptionsList[i].defStyle;
		_tcsncpy(fontid.deffontsettings.szFace, fontOptionsList[i].szDefFace, sizeof(fontid.deffontsettings.szFace)/sizeof(fontid.deffontsettings.szFace[0]));//Changed
		fontid.deffontsettings.charset = DEFAULT_CHARSET;
		CallService(MS_FONT_REGISTERT, (WPARAM)&fontid, 0);
	}

	colourid.cbSize = sizeof(ColourID);
	strncpy(colourid.dbSettingsGroup, SMSPLUGIN, sizeof(colourid.dbSettingsGroup));//Changed
	strncpy(colourid.setting, SRMSGSET_BKGCOLOUR, sizeof(colourid.setting));//Changed
	colourid.defcolour = SRMSGDEFSET_BKGCOLOUR;
	_tcsncpy(colourid.name, TranslateT("Background"), sizeof(colourid.name)/sizeof(colourid.name[0]));//Changed
	_tcsncpy(colourid.group, TranslateT("SMS Messages"), sizeof(colourid.group)/sizeof(colourid.group[0]));//Changed
	CallService(MS_COLOUR_REGISTERT, (WPARAM)&colourid, 0);
}
int GetStringOption(int id,TCHAR *pStr,int cbStr)
{
	char *pszSetting;
	TCHAR *pszDefault=NULL;
	DBVARIANT dbv;

	switch(id) {
		case OPTION_USESIGNATURE:
			pszSetting="UseSignature";
			{
				TCHAR* str=(TCHAR*)mir_alloc(sizeof(TCHAR)*2);
				str[0]=_T('1');
				str[1]=_T('\0');
				pszDefault=str;
			}
			break;
		case OPTION_SIGNATURE:
			pszSetting="Signature";
			{
				TCHAR *str = (TCHAR*)mir_alloc(256*sizeof(TCHAR));
				TCHAR *contactName;
				int len;
				contactName=(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)(HANDLE)NULL,(LPARAM)GCDNF_TCHAR);
				len=wsprintf(str,TranslateT("From %s:\r\n\r\n"),contactName);
				pszDefault=str;
			}
			break;
		case OPTION_SIGNATUREPOS:
			pszSetting="SignaturePos";
			{
				TCHAR* str=(TCHAR*)mir_alloc(sizeof(TCHAR)*2);
				str[0]=_T('0');
				str[1]=_T('\0');
				pszDefault=str;
			}
			break;
		case OPTION_SHOWACK:
			pszSetting="ShowACK";
			{
				TCHAR* str=(TCHAR*)mir_alloc(sizeof(TCHAR)*2);
				str[0]=_T('0');
				str[1]=_T('\0');
				pszDefault=str;
			}
			break;
		case OPTION_DEFACCOUNT:
			pszSetting="DefaultAccount";
			{
				TCHAR* str=(TCHAR*)mir_alloc(sizeof(TCHAR)*1);
				str[0]=_T('\0');
				pszDefault=str;
			}
			break;
		default:
			return 1;
	}
	if(DBGetContactSettingTString(NULL,SMSPLUGIN,pszSetting,&dbv))
		lstrcpyn(pStr,pszDefault,cbStr);
	else 
	{
		lstrcpyn(pStr,dbv.ptszVal,cbStr);
		DBFreeVariant(&dbv);
	}
	mir_free(pszDefault);
	return 0;
}



//(Taken from Miranda-IM source code and modified:)
void LoadMsgDlgFont(int i, LOGFONT* lf, COLORREF * colour)
{
	char str[32];
	int style;
	DBVARIANT dbv;

	if ( colour ) {
		wsprintfA(str, "SRMFont%dCol", i);
		*colour = DBGetContactSettingDword(NULL, SMSPLUGIN, str, fontOptionsList[i].defColour);
	}
	if ( lf ) {
		wsprintfA(str, "SRMFont%dSize", i);
		lf->lfHeight = (char) DBGetContactSettingByte(NULL, SMSPLUGIN, str, fontOptionsList[i].defSize);
		lf->lfWidth = 0;
		lf->lfEscapement = 0;
		lf->lfOrientation = 0;
		wsprintfA(str, "SRMFont%dSty", i);
		style = DBGetContactSettingByte(NULL, SMSPLUGIN, str, fontOptionsList[i].defStyle);
		lf->lfWeight = style & FONTF_BOLD ? FW_BOLD : FW_NORMAL;
		lf->lfItalic = style & FONTF_ITALIC ? 1 : 0;
		lf->lfUnderline = 0;
		lf->lfStrikeOut = 0;
		lf->lfOutPrecision = OUT_DEFAULT_PRECIS;
		lf->lfClipPrecision = CLIP_DEFAULT_PRECIS;
		lf->lfQuality = DEFAULT_QUALITY;
		lf->lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
		wsprintfA(str, "SRMFont%d", i);
		if (DBGetContactSettingTString(NULL, SMSPLUGIN, str, &dbv))
			lstrcpy(lf->lfFaceName, fontOptionsList[i].szDefFace);
		else {
			lstrcpyn(lf->lfFaceName, dbv.ptszVal, sizeof(lf->lfFaceName));
			DBFreeVariant(&dbv);
		}
		wsprintfA(str, "SRMFont%dSet", i);
		lf->lfCharSet = DBGetContactSettingByte(NULL, SMSPLUGIN, str, DEFAULT_CHARSET);
	}
}

void InitOptions(void)
{
	hHookOPT=HookEvent(ME_OPT_INITIALISE,OptInitialise);
	RegisterSMSPlugFonts();
}
void UninitOptions(void)
{
	UnhookEvent(hHookOPT);
}