#ifndef _GLOBALVARIABLES_H
#define _GLOBALVARIABLES_H

/*#include "commonHeaders.h"
#include "commonGlobalHeaders.h"
#include "commonFunctions.h"
#include "crt\tchar.h"*/

//#define MS_SENDSMS "SMSPlug/SendSMS"

#define SMSPLUGIN "SMSPlugin"
#define MS_SENDSMS "/SendSMS"

//#define _CRT_SECURE_NO_DEPRECATE

#define ICQEVENTTYPE_SMSCONFIRMATION 3001

#ifdef _UNICODE
	#define DBEF_TCHAR DBEF_UTF 
#else
	#define DBEF_TCHAR 0
#endif

#endif _GLOBALVARIABLES_H