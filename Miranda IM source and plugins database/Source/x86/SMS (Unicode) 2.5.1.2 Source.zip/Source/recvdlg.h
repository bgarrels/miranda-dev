#ifndef _RECVDLG_H
#define _RECVDLG_H

//System includes
#include <windows.h>
#include "tchar.h"
#include "string.h"
#include "stdio.h"
#include "commctrl.h"

//Miranda includes
#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_database.h"
#include "..\..\..\include\m_protocols.h"
#include "..\..\..\include\m_langpack.h"
#include "..\..\..\include\m_clist.h"
//#include "..\..\..\include\m_history.h"

//Other Miranda plugins
//#include "m_autoreplacer.h"

//SMSPlugin includes
#include "..\Resource\resource.h"
//#include "utf8.h"
#include "receive.h"
#include "options.h"
#include "senddlg.h"

//Decleration of SMS send window list

typedef struct {
	HWND hwndSMS;
	TCHAR *tMsg;
	HANDLE hContact;
} SMSWindowRecv;

HWND AddRecvSMSWindow();
HANDLE GetRecvSMSWindowHContact(HWND hwndDlg);
void SetRecvSMSWindowHContact(HWND hwndDlg, HANDLE hContact);
void RemoveRecvSMSWindow(HWND hwndRemove);
void RemoveAllRecvSMSWindow();

BOOL CALLBACK RecvSmsDlgProc(HWND hwndDlg,UINT message,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK SMSTimedOutDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

#endif