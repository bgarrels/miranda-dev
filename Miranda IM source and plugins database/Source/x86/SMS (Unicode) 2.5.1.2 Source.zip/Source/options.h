#ifndef _SMS_OPTIONS_H
#define _SMS_OPTIONS_H

//System includes
#include <windows.h>
#include "tchar.h"

//Miranda includes
#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_options.h"
#include "..\..\..\include\m_database.h"
#include "..\..\..\include\m_langpack.h"
#include "..\..\..\include\m_fontservice.h"
#include "..\..\..\include\m_clist.h"

//SMSPlugin includes
#include "..\Resource\resource.h"
#include "globalVariables.h"
#include "utils.h"
#include "send.h"
//Other Miranda plugins
/*


#include "crt\stdio.h"
#include "main.h"

#include "..\..\..\include\newpluginapi.h"
#include "..\..\..\include\m_database.h"
#include "..\..\..\include\m_options.h"
#include "..\..\..\include\m_langpack.h"
#include "..\..\..\include\m_clist.h"*/

#define OPTION_SIGNATURE		1
#define OPTION_SIGNATUREPOS		2
#define OPTION_SHOWACK			3
#define OPTION_USESIGNATURE		4
#define OPTION_DEFACCOUNT		5

//Fonts defenitions
#define MSGFONTID_MYMSG			0
#define MSGFONTID_YOURMSG		1
#define SRMSGSET_BKGCOLOUR      "BkgColour"
#define SRMSGDEFSET_BKGCOLOUR	GetSysColor(COLOR_WINDOW)
#define FONTF_BOLD				1
#define FONTF_ITALIC			2

int GetStringOption(int id,TCHAR *pStr,int cbStr);

void UpdateSMSOptionsAccounts();
//Decleration of Initialation\Uninitialation functions
void InitOptions(void);
void UninitOptions(void);

//Fonts Stuff
void LoadMsgDlgFont(int i, LOGFONT *lf, COLORREF *colour);

//HFONT hFont; //get rid of it

#endif