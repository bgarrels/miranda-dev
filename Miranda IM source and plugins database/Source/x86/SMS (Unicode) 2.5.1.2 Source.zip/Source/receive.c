/*
Miranda-IM SMS Plugin
Copyright (C) 2001-2  Richard Hughes

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
---------------------------------------------------------------------------

This was the original words.
This plugin was modified by Ariel Shulman (NuKe007).
For any comments, problems, etc. contact me at Miranda-IM forums or E-Mail or ICQ.
All the information needed you can find at http://flashmagicd.com/projects/smsplugin/
Enjoy the code and use it smartly!
*/

#include "receive.h"
#include "..\..\..\include\m_system.h"

HANDLE hHookDbAdd;
HANDLE hHookAck;

//This function handles the ACK received from that hooked.
static int handleAckSMS(WPARAM wParam,LPARAM lParam)
{
	ACKDATA *ack=(ACKDATA*)lParam;
	TCHAR *cResult;
	//UTF8_INTERFACE *utf8;

	//TCHAR cResult[512];
	if(ack->type!=ICQACKTYPE_SMS) return 0;
	if(!IsInAccountList((char*)ack->szModule)) return 0;
	//This common used for debugging:
	//	if(ack->result==ACKRESULT_SENTREQUEST)
	//		MessageBox(NULL,"ACKRESULT_SENTREQUEST","DEBUG - SMS ACK",MB_OK);
	//	if(ack->result==ACKRESULT_FAILED) 
	//	{
	//		MessageBox(NULL,_strdup((char*)ack->lParam),"DEBUG - SMS ACK",MB_OK);
	//		return 0;
	//	}
	//	MessageBox(NULL,_strdup((char*)ack->lParam),"DEBUG - SMS ACK",MB_OK);
	//END OF DEBUG
	cResult=(TCHAR*)mir_alloc(512*sizeof(TCHAR));
	//MessageBox(NULL,_strdup((char*)ack->lParam),"DEBUG 0a",MB_OK);
	if(GetXMLField(_strdup((char*)ack->lParam),"sms_message","text",NULL) != NULL)	
	{
		TCHAR *cUTF8Decoded=NULL;
		TCHAR *cXMLDecoded=NULL;
		//CHECK		
		//decode_utf8(GetXMLField(_strdup((char*)ack->lParam),"sms_message","text",NULL),cUTF8Decoded);
		//utf8 = (UTF8_INTERFACE*)mir_alloc(sizeof(UTF8_INTERFACE));
		//utf8->utf8_decode(GetXMLField(_strdup((char*)ack->lParam),"sms_message","text",NULL),cUTF8Decoded);
		cUTF8Decoded = mir_utf8decodeT(GetXMLField(_strdup((char*)ack->lParam),"sms_message","text",NULL));
		cXMLDecoded=DecodeXML(cUTF8Decoded);
		mir_free(cResult);
		cResult=cXMLDecoded;//ReplaceNwithRN(cXMLDecoded);
		{
			HANDLE hContactTmp;
			hContactTmp=CellularToHandle(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL)));
			{
				DBEVENTINFO dbei={0};
				dbei.cbSize = sizeof(dbei);
				dbei.szModule = (char*)mir_alloc((lstrlenA(ack->szModule)+1)*sizeof(char));
				lstrcpyA(dbei.szModule,ack->szModule);
				dbei.timestamp = (DWORD)time(NULL);
				dbei.flags = DBEF_TCHAR;
				if(hContactTmp == NULL)
					dbei.flags|=DBEF_READ;
				dbei.eventType = ICQEVENTTYPE_SMS;
				dbei.cbBlob = (lstrlenA(Utf8IfUnicode(cResult))
					+lstrlenA(Utf8IfUnicode(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL))))
					+lstrlenA(Utf8IfUnicode(_T("SMS From: ")))
					+4*sizeof(CHAR));
				dbei.pBlob=(PBYTE)mir_alloc(dbei.cbBlob);
				lstrcpyA((char*)dbei.pBlob,Utf8IfUnicode(_T("SMS From: ")));
				if(*(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL))) != _T('+'))
					lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("+")));
				lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL))));
				lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("\r\n")));
				lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(cResult));
				CallService(MS_DB_EVENT_ADD, (WPARAM)hContactTmp, (LPARAM)&dbei);
				if(hContactTmp == NULL)
				{	

					HWND hwndRecvSms;
					TCHAR newtitle[256];
					TCHAR *cNumber;
					TCHAR *tMessage;
#ifdef _UNICODE
					tMessage = mir_utf8decodeT((char*)dbei.pBlob);
#else
					tMessage=dbei.pBlob;
#endif
					cNumber = (TCHAR *)mir_alloc((lstrlen(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL)))+2)*sizeof(TCHAR));
					if(*(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL))) != _T('+'))
					{
						lstrcpy(cNumber,_T("+"));
						lstrcat(cNumber,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL)));
					}
					else
					{
						lstrcpy(cNumber,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_message","sender",NULL)));
					}
					lstrcat(cNumber,_T("\0"));
					SkinPlaySound("RecvSMSMsg");
					hwndRecvSms=AddRecvSMSWindow();
					lstrcpy(newtitle,TranslateT("Unknown"));
					lstrcat(newtitle,_T(" - "));
					lstrcat(newtitle,TranslateT("Received SMS"));
					SetWindowText(hwndRecvSms,newtitle);
					SetRecvSMSWindowHContact(hwndRecvSms,NULL);
					SetDlgItemText(hwndRecvSms,IDC_NAME,TranslateT("Unknown"));
					SetDlgItemText(hwndRecvSms,IDC_NUMBER,cNumber);
					SetDlgItemText(hwndRecvSms,IDC_MESSAGE,tMessage);
					mir_free(cNumber);
					mir_free(tMessage);
					mir_free(cUTF8Decoded);
					mir_free(cResult);
					return 0;
				}
			}
			mir_free(cUTF8Decoded);
			mir_free(cResult);
			return 0;
		}

	}
	else if(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","delivered",NULL) != NULL)	
	{
		cResult=(TCHAR *)mir_alloc((lstrlen(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","delivered",NULL)))+1)*sizeof(TCHAR));
		lstrcpy(cResult,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","delivered",NULL)));
		{
			HANDLE hContactTmp;
			hContactTmp=CellularToHandle(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL)));
			{
				DBEVENTINFO dbei={0};
				dbei.cbSize = sizeof(dbei);
				dbei.szModule = (char*)mir_alloc((lstrlenA(ack->szModule)+1)*sizeof(char));
				lstrcpyA(dbei.szModule,ack->szModule);
				dbei.timestamp = (DWORD)time(NULL);
				dbei.flags = DBEF_TCHAR;
				dbei.eventType = ICQEVENTTYPE_SMSCONFIRMATION;
				if(!lstrcmp(cResult,_T("Yes")))
				{
					dbei.cbBlob = (lstrlenA(Utf8IfUnicode(_T("SMS was sent succesfully")))+lstrlenA(Utf8IfUnicode(_T("SMS Confirmation From: ")))+lstrlenA(Utf8IfUnicode(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))))+5);
					dbei.pBlob=(PBYTE)mir_alloc(dbei.cbBlob);
					lstrcpyA((char*)dbei.pBlob,Utf8IfUnicode(_T("SMS Confirmation From: ")));
					if(*(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))) != _T('+'))
						lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("+")));
					lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))));
					lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("\r\n")));
					lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("SMS was sent succesfully")));
				}
				else
				{
					dbei.cbBlob = (lstrlenA(Utf8IfUnicode(_T("SMS was not sent succesfully")))+lstrlenA(Utf8IfUnicode(_T("SMS Confirmation From: ")))+lstrlenA(Utf8IfUnicode(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))))+5);
					dbei.pBlob=(PBYTE)mir_alloc(dbei.cbBlob);
					lstrcpyA((char*)dbei.pBlob,Utf8IfUnicode(_T("SMS Confirmation From: ")));
					if(*(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))) != _T('+'))
						lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("+")));
					lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))));
					lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("\r\n")));
					lstrcatA((char*)dbei.pBlob,Utf8IfUnicode(_T("SMS was not sent succesfully")));
				}			
				if((HANDLE)hContactTmp == NULL)
				{
					HWND hwndRecvSms;
					TCHAR *cNumber;
					TCHAR newtitle[256];
					TCHAR *tMessage;
#ifdef _UNICODE
					tMessage = mir_utf8decodeT((char*)dbei.pBlob);
#else
					tMessage=dbei.pBlob;
#endif
					cNumber=mir_alloc((lstrlen(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL)))+2)*sizeof(TCHAR));
					if(*(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL))) != _T('+'))
					{
						lstrcpy(cNumber,_T("+"));
						lstrcat(cNumber,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL)));
					}
					else
					{
						lstrcpy(cNumber,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_delivery_receipt","destination",NULL)));
					}
					lstrcat(cNumber,_T('\0'));
					hwndRecvSms=AddRecvSMSWindow();
					if(!lstrcmp(cResult,_T("Yes")))
						SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT)));
					else
						SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT)));
					lstrcpy(newtitle,TranslateT("Unknown"));
					lstrcat(newtitle,_T(" - "));
					lstrcat(newtitle,TranslateT("Received SMS Confirmation"));
					SetWindowText(hwndRecvSms,newtitle);
					SetRecvSMSWindowHContact(hwndRecvSms,NULL);
					SetDlgItemText(hwndRecvSms,IDC_NAME,_T("Unknown"));
					SetDlgItemText(hwndRecvSms,IDC_NUMBER,cNumber);
					SetDlgItemText(hwndRecvSms,IDC_MESSAGE,tMessage);
					mir_free(cNumber);
					mir_free(tMessage);
					mir_free(cResult);
					return 0;
				}
				CallService(MS_DB_EVENT_ADD, (WPARAM)hContactTmp, (LPARAM)&dbei);
				mir_free(cResult);
				return 0;
			}
		}
	}
	else if((ack->result==ACKRESULT_FAILED) || ((GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL) != NULL) && (!lstrcmp(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL)),_T("No")))))
	{
		HWND hwndDlg;
		hwndDlg=GetHwndByHProcess(ack->hProcess);
		if(hwndDlg != NULL)
		{	
			HWND hwndTimeOut;
			TCHAR cMessage[512];
			TCHAR number[161];
			if(GetSendSMSWindowMultiple(hwndDlg) == 1)
			{
				TVITEM tvi;
				tvi.mask=TVIF_TEXT;
				tvi.hItem=GetSendSMSWindowHItemSend(hwndDlg);
				tvi.pszText=number;
				tvi.cchTextMax=sizeof(number);
				TreeView_GetItem(GetDlgItem(hwndDlg,IDC_NUMBERSLIST),&tvi);
			}
			else
				GetDlgItemText(hwndDlg,IDC_ADDRESS,number,sizeof(number));
			wsprintf(cMessage,TranslateT("SMS message didn't send by ICQ to %s because :\r\n"),number);
			if(ack->result==ACKRESULT_FAILED)
				lstrcat(cMessage,CHAR2TCHAR(_strdup((char*)ack->lParam)));
			else
				lstrcat(cMessage,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","error","params","param",NULL)));
			KillTimer(hwndDlg,wParam);
			ShowWindow(hwndDlg,SW_SHOWNORMAL);
			EnableWindow(hwndDlg,FALSE);
			hwndTimeOut=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSTIMEDOUT),hwndDlg,SMSTimedOutDlgProc);
			SetDlgItemText(hwndTimeOut,IDC_STATUS,cMessage);
		}
	}
	else if((GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL) != NULL) && (!lstrcmp(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL)),_T("Yes"))))
	{
		HWND hwndDlg;
		hwndDlg=GetHwndByHProcess(ack->hProcess);
		if(hwndDlg != NULL)
		{
			HWND hwndAccepted;
			KillTimer(hwndDlg,wParam);
			AddSendSMSWindowDB(hwndDlg);
			if(!GetSendSMSWindowMultiple(hwndDlg))
			{
				TCHAR cShowACK[2];
				GetStringOption(3,cShowACK,sizeof(cShowACK));
				if(cShowACK[0] == _T('1'))
				{	
					hwndAccepted=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSACCEPT),hwndDlg,SMSAcceptedDlgProc);
					SetDlgItemText(hwndAccepted,IDC_SOURCE,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","source",NULL)));
					SetDlgItemText(hwndAccepted,IDC_MESSAGEID,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","message_id",NULL)));
					SetDlgItemText(hwndAccepted,IDC_NETWORK,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","network",NULL)));
					return 0;
				}
				RemoveSendSMSWindow(hwndDlg);
			}
			else
			{
				if(GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg))==NULL)
				{
					RemoveSendSMSWindow(hwndDlg);
					return 0;
				}
				SetSendSMSWindowAsSent(hwndDlg);
				SetSendSMSWindowHItemSend(hwndDlg,GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg)));
				SendSMSWindowNext(hwndDlg);
			}
		}
	}
	else if((GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL) != NULL) && (!lstrcmp(CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","deliverable",NULL)),_T("SMTP"))))
	{
		HWND hwndDlg;
		hwndDlg=GetHwndByHProcess(ack->hProcess);
		if(hwndDlg != NULL)
		{
			HWND hwndAccepted;
			KillTimer(hwndDlg,wParam);
			AddSendSMSWindowDB(hwndDlg);
			if(!GetSendSMSWindowMultiple(hwndDlg))
			{
				TCHAR cShowACK[2];
				GetStringOption(3,cShowACK,sizeof(cShowACK));
				if(cShowACK[0] == _T('1'))
				{	
					hwndAccepted=CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_SENDSMSACCEPT),hwndDlg,SMSAcceptedDlgProc);
					SetDlgItemText(hwndAccepted,IDC_ST_SOURCE,_T("From:"));
					SetDlgItemText(hwndAccepted,IDC_ST_MESSAGEID,_T("To:"));
					SetDlgItemText(hwndAccepted,IDC_SOURCE,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","from",NULL)));
					SetDlgItemText(hwndAccepted,IDC_MESSAGEID,CHAR2TCHAR(GetXMLField(_strdup((char*)ack->lParam),"sms_response","to",NULL)));
					SetDlgItemText(hwndAccepted,IDC_NETWORK,CHAR2TCHAR(ack->szModule));
					return 0;
				}
				RemoveSendSMSWindow(hwndDlg);
			}
			else
			{
				if(GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg))==NULL)
				{
					RemoveSendSMSWindow(hwndDlg);
					return 0;
				}
				SetSendSMSWindowAsSent(hwndDlg);
				SetSendSMSWindowHItemSend(hwndDlg,GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg)));
				SendSMSWindowNext(hwndDlg);
			}
		}
	}
	else
	{
		HWND hwndDlg;
		hwndDlg=GetHwndByHProcess(ack->hProcess);
		if(hwndDlg != NULL)
		{

			KillTimer(hwndDlg,wParam);
			AddSendSMSWindowDB(hwndDlg);		
			if(!GetSendSMSWindowMultiple(hwndDlg))
				RemoveSendSMSWindow(hwndDlg);
			else
			{
				if(GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg))==NULL)
				{
					RemoveSendSMSWindow(hwndDlg);
					return 0;
				}
				SetSendSMSWindowAsSent(hwndDlg);
				SetSendSMSWindowHItemSend(hwndDlg,GetSendSMSWindowNextHItem(hwndDlg,GetSendSMSWindowHItemSend(hwndDlg)));
				SendSMSWindowNext(hwndDlg);
			}
		}
	}
	return 0;
}

//Handles new SMS messages added to the database
int handleNewMessage(WPARAM wparam,LPARAM lparam)
{
	CLISTEVENT cle;
	TCHAR *contactName;
	TCHAR toolTip[256];
	HANDLE hContact = (HANDLE)wparam;
	DBEVENTINFO dbei={0};
	dbei.cbSize=sizeof(dbei);
	dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)lparam,0);
	dbei.pBlob=(PBYTE)mir_alloc(dbei.cbBlob);
	CallService(MS_DB_EVENT_GET,lparam,(LPARAM)&dbei);
	if((dbei.eventType != ICQEVENTTYPE_SMS) && (dbei.eventType!=ICQEVENTTYPE_SMSCONFIRMATION)) return 0;
	if(dbei.flags&(DBEF_READ|DBEF_SENT)) return 0;
	{
		TCHAR *cTmp;
		cTmp=DbGetEventTextT( &dbei, CP_ACP );
		if(!lstrcmp(_T("SMS To:"),cTmp)) 
		{
			mir_free(cTmp);
			return 0;
		}
		mir_free(cTmp);
	}
	if((HANDLE)wparam == NULL)
	{
		CallService(MS_DB_EVENT_MARKREAD,wparam, (LPARAM)&dbei);
		return 0;
	}
	{
		TCHAR *cTmp;
		cTmp=DbGetEventTextT( &dbei, CP_ACP );
		if(!lstrcmp(_T("SMS Confirmation From:"),cTmp)) 
		{
			int i;
			TCHAR *cStatus;
			cStatus=cTmp;
			for(i=0;i<(signed)lstrlen(cStatus);i++)
				if(*(cStatus+i) == _T('\n'))
					break;
			cStatus=cStatus + i + 1;
			SkinPlaySound("RecvSMSConfirmation");
			if(DBGetContactSettingByte(NULL,SMSPLUGIN,"AutoPopup",0)) 
			{
				HWND hwndRecvSms;
				int i;
				TCHAR *msg;
				TCHAR cTmpNum[256];
				TCHAR newtitle[256];
				hwndRecvSms=AddRecvSMSWindow();
				if((HANDLE)wparam != NULL)
					lstrcpy(newtitle,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)(HANDLE)wparam,(LPARAM)GCDNF_TCHAR));
				else
					lstrcpy(newtitle,TranslateT("Unknown"));
				lstrcat(newtitle,_T(" - "));
				lstrcat(newtitle,TranslateT("Received SMS Confirmation"));
				SetWindowText(hwndRecvSms,newtitle);
				SetRecvSMSWindowHContact(hwndRecvSms,(HANDLE)wparam);
				SetDlgItemText(hwndRecvSms,IDC_NAME,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wparam,(LPARAM)GCDNF_TCHAR));
				msg = DbGetEventTextT( &dbei, CP_ACP );
				for(i=23;*(msg + i)!=_T('\r');i++)
					cTmpNum[i-23]=*(msg + i);
				cTmpNum[i-23]=_T('\0');
				if(!lstrcmp(_T("SMS was sent succesfully"),(msg + i + 2)))
					SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT)));
				else
					SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT)));
				SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
				SetDlgItemText(hwndRecvSms,IDC_MESSAGE,msg);		
				CallService(MS_DB_EVENT_DELETE,wparam,(LPARAM)&dbei);
				mir_free(cTmp);
				mir_free(msg);
				return 0;
			}
			ZeroMemory(&cle,sizeof(cle));
			cle.cbSize=sizeof(cle);
			cle.hContact=(HANDLE)wparam;
			cle.hDbEvent=(HANDLE)lparam;
			if(!lstrcmp(cStatus,_T("SMS was not sent succesfully")))
				cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT));
			else
				cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT));
			cle.pszService="SRSMS/ReadSmsAck";
			contactName=(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wparam,(LPARAM)GCDNF_TCHAR);
			wsprintf(toolTip,TranslateT("SMS Confirmation from %s"),contactName);
			cle.ptszTooltip=toolTip;
			cle.flags=CLEF_TCHAR;
			CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
			mir_free(cTmp);
			return 0;
		}
		mir_free(cTmp);
	}
	SkinPlaySound("RecvSMSMsg");
	if(DBGetContactSettingByte(NULL,SMSPLUGIN,"AutoPopup",0)) 
	{
		HWND hwndRecvSms;
		int i;
		TCHAR *msg;
		TCHAR cTmpNum[256];
		TCHAR newtitle[256];
		hwndRecvSms=AddRecvSMSWindow();
		if((HANDLE)wparam != NULL)
			lstrcpy(newtitle,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)(HANDLE)wparam,(LPARAM)GCDNF_TCHAR));
		else
			lstrcpy(newtitle,TranslateT("Unknown"));
		lstrcat(newtitle,_T(" - "));
		lstrcat(newtitle,TranslateT("Received SMS"));
		SetWindowText(hwndRecvSms,newtitle);
		SetRecvSMSWindowHContact(hwndRecvSms,(HANDLE)wparam);
		SetDlgItemText(hwndRecvSms,IDC_NAME,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wparam,(LPARAM)GCDNF_TCHAR));
		msg = DbGetEventTextT( &dbei, CP_ACP );
		for(i=10;*(msg + i)!=_T('\r');i++)
			cTmpNum[i-10]=*(msg + i);
		cTmpNum[i-10]=_T('\0');
		SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
		SetDlgItemText(hwndRecvSms,IDC_MESSAGE,msg);
		CallService(MS_DB_EVENT_MARKREAD,wparam,(LPARAM)&dbei);
		mir_free(msg);
		return 0;
	}
	ZeroMemory(&cle,sizeof(cle));
	cle.cbSize=sizeof(cle);
	cle.hContact=(HANDLE)wparam;
	cle.hDbEvent=(HANDLE)lparam;
	cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));
	cle.pszService="SRSMS/ReadSms";
	contactName=(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,wparam,(LPARAM)GCDNF_TCHAR);
	wsprintf(toolTip,TranslateT("SMS Message from %s"),contactName);
	cle.ptszTooltip=toolTip;
	cle.flags=CLEF_TCHAR;
	CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
	return 0;
}


//Decleration of Initialation\Uninitialation functions
void InitSmsRecv(void)
{
	hHookAck = HookEvent(ME_PROTO_ACK,handleAckSMS);
	hHookDbAdd = HookEvent(ME_DB_EVENT_ADDED,handleNewMessage);
	SkinAddNewSound("RecvSMSMsg",Translate("Incoming SMS Message"),"message.wav");
	SkinAddNewSound("RecvSMSConfirmation",Translate("Incoming SMS Confirmation"),"message.wav");
	RestoreUnreadMessageAlerts();
}

void UninitSmsRecv(void)
{
	UnhookEvent(hHookAck);
	UnhookEvent(hHookDbAdd);
	RemoveAllRecvSMSWindow();
}

void RestoreUnreadMessageAlerts(void)
{
	TCHAR toolTip[256];
	CLISTEVENT cle={0};
	DBEVENTINFO dbei={0};
	HANDLE hDbEvent,hContact;
	TCHAR *contactName;

	dbei.cbSize=sizeof(dbei);

	hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDFIRST,0,0);
	while(hContact) {
		hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDFIRSTUNREAD,(WPARAM)hContact,0);
		while(hDbEvent) {
			dbei.cbBlob=0;
			CallService(MS_DB_EVENT_GET,(WPARAM)hDbEvent,(LPARAM)&dbei);
			if(!(dbei.flags&(DBEF_SENT|DBEF_READ)) && ((dbei.eventType==ICQEVENTTYPE_SMS) || (dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION))) {
				handleNewMessage((WPARAM)hContact,(LPARAM)hDbEvent);
			}
			hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDNEXT,(WPARAM)hDbEvent,0);
		}
		hContact=(HANDLE)CallService(MS_DB_CONTACT_FINDNEXT,(WPARAM)hContact,0);
	}
	hContact=NULL;
	hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDFIRSTUNREAD,(WPARAM)hContact,0);
	while(hDbEvent) {
		dbei.cbBlob=0;
		CallService(MS_DB_EVENT_GET,(WPARAM)hDbEvent,(LPARAM)&dbei);
		if(!(dbei.flags&(DBEF_SENT|DBEF_READ)) && (dbei.eventType==ICQEVENTTYPE_SMS)) {
			if(DBGetContactSettingByte(NULL,SMSPLUGIN,"AutoPopup",0)) {
				HWND hwndRecvSms;
				int i;
				TCHAR cTmpNum[256];
				TCHAR newtitle[256];
				TCHAR *msg;
				hwndRecvSms=AddRecvSMSWindow();
				lstrcpy(newtitle,TranslateT("Unknown"));
				lstrcat(newtitle,_T(" - "));
				lstrcat(newtitle,TranslateT("Received SMS"));
				SetWindowText(hwndRecvSms,newtitle);
				SetRecvSMSWindowHContact(hwndRecvSms,(HANDLE)hContact);
				SetDlgItemText(hwndRecvSms,IDC_NAME,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,(LPARAM)GCDNF_TCHAR));
				msg = DbGetEventTextT( &dbei, CP_ACP );
				for(i=10;*(msg + i)!=_T('\r');i++)
					cTmpNum[i-10]=*(msg + i);
				cTmpNum[i-10]=_T('\0');
				SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
				SetDlgItemText(hwndRecvSms,IDC_MESSAGE,msg);
				CallService(MS_DB_EVENT_MARKREAD,(WPARAM)hContact,(LPARAM)&dbei);
				mir_free(msg);
			}
			else
			{
				ZeroMemory(&cle,sizeof(cle));
				cle.cbSize=sizeof(cle);
				cle.hContact=(HANDLE)hContact;
				cle.hDbEvent=(HANDLE)hDbEvent;
				cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMS));
				cle.pszService="SRSMS/ReadSms";
				cle.flags=CLEF_TCHAR;
				contactName=(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,(LPARAM)GCDNF_TCHAR);
				wsprintf(toolTip,TranslateT("SMS Message from %s"),contactName);
				cle.ptszTooltip=toolTip;
				CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
			}
		}
		if(!(dbei.flags&(DBEF_SENT|DBEF_READ)) && (dbei.eventType==ICQEVENTTYPE_SMSCONFIRMATION)) {
			TCHAR *msg;
			int i;
			TCHAR *cStatus,*cOrigStatus;
			msg = DbGetEventTextT( &dbei, CP_ACP );
			cStatus=(TCHAR*)mir_alloc((lstrlen(msg)+1)*sizeof(TCHAR));
			cOrigStatus=cStatus;
			lstrcpy(cStatus,msg);
			for(i=0;i<(signed)lstrlen(msg);i++)
				if(*(cStatus+i) == _T('\n'))
					break;
			mir_free(msg);
			cStatus=cStatus + i + 1;
			SkinPlaySound("RecvSMSConfirmation");
			if(DBGetContactSettingByte(NULL,SMSPLUGIN,"AutoPopup",0)) 
			{
				HWND hwndRecvSms;
				int	i;
				TCHAR cTmpNum[256];
				TCHAR newtitle[256];
				TCHAR *msg;
				hwndRecvSms=AddRecvSMSWindow();
				lstrcpy(newtitle,TranslateT("Unknown"));
				lstrcat(newtitle,_T(" - "));
				lstrcat(newtitle,TranslateT("Received SMS Confirmation"));
				SetWindowText(hwndRecvSms,newtitle);
				SetRecvSMSWindowHContact(hwndRecvSms,(HANDLE)hContact);
				SetDlgItemText(hwndRecvSms,IDC_NAME,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,(LPARAM)GCDNF_TCHAR));
				msg = DbGetEventTextT( &dbei, CP_ACP );
				for(i=23;*(msg + i)!=_T('\r');i++)
					cTmpNum[i-23]=*(msg + i);
				cTmpNum[i-23]=_T('\0');
				if(!lstrcmp(_T("SMS was sent succesfully"),(msg + i + 2)))
					SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT)));
				else
					SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT)));
				SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
				SetDlgItemText(hwndRecvSms,IDC_MESSAGE,msg);		
				CallService(MS_DB_EVENT_DELETE,(WPARAM)hContact,(LPARAM)&dbei);					
				mir_free(msg);
			}
			else
			{
				ZeroMemory(&cle,sizeof(cle));
				cle.cbSize=sizeof(cle);
				cle.hContact=(HANDLE)hContact;
				cle.hDbEvent=(HANDLE)hDbEvent;
				if(!lstrcmp(cStatus,_T("SMS was not sent succesfully")))
					cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT));
				else
					cle.hIcon=LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT));
				cle.pszService="SRSMS/ReadSmsAck";
				contactName=(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)hContact,(LPARAM)GCDNF_TCHAR);
				wsprintf(toolTip,TranslateT("SMS Confirmation from %s"),contactName);
				cle.ptszTooltip=toolTip;
				cle.flags=CLEF_TCHAR;
				CallService(MS_CLIST_ADDEVENT,0,(LPARAM)&cle);
			}
			mir_free(cOrigStatus);
		}
		hDbEvent=(HANDLE)CallService(MS_DB_EVENT_FINDNEXT,(WPARAM)hDbEvent,0);
	}


}

//This function used to popup a read SMS window after the user clicked on the received SMS confirmation.
int ReadAckSMS(WPARAM wparam,LPARAM lparam)
{
	TCHAR newtitle[256];
	HWND hwndRecvSms;
	DBEVENTINFO dbei={0};
	int i;
	TCHAR cTmpNum[256];
	TCHAR* msg;
	dbei.cbSize=sizeof(dbei);
	dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)((CLISTEVENT*)lparam)->hDbEvent,0);
	dbei.pBlob=(PBYTE)mir_alloc(dbei.cbBlob);
	CallService(MS_DB_EVENT_GET,(WPARAM)((CLISTEVENT*)lparam)->hDbEvent,(LPARAM)&dbei);
	if((dbei.eventType != ICQEVENTTYPE_SMS) && (dbei.eventType!=ICQEVENTTYPE_SMSCONFIRMATION)) return 0;
	hwndRecvSms=AddRecvSMSWindow();//CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_RECVSMS),NULL,RecvSmsDlgProc);
	if(((CLISTEVENT*)lparam)->hContact != NULL)
		lstrcpy(newtitle,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)((CLISTEVENT*)lparam)->hContact,(LPARAM)GCDNF_TCHAR));
	else
		lstrcpy(newtitle,TranslateT("Unknown"));
	lstrcat(newtitle,_T(" - "));
	lstrcat(newtitle,TranslateT("Received SMS Confirmation"));
	SetWindowText(hwndRecvSms,newtitle);
	SetRecvSMSWindowHContact(hwndRecvSms,((CLISTEVENT*)lparam)->hContact);
	SetDlgItemText(hwndRecvSms,IDC_NAME,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)((CLISTEVENT*)lparam)->hContact,(LPARAM)GCDNF_TCHAR));

	msg = DbGetEventTextT( &dbei, CP_ACP );
	for(i=23;*(msg + i)!=_T('\r');i++)
		cTmpNum[i-23]=*(msg + i);
	cTmpNum[i-23]=_T('\0');
	if(!lstrcmp(_T("SMS was sent succesfully"),(msg + i + 2)))
		SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSSENT)));
	else
		SendMessage(hwndRecvSms,WM_SETICON,ICON_BIG,(LPARAM)LoadIcon(GetPluginhInst(),MAKEINTRESOURCE(IDI_SMSNOTSENT)));
	SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
	SetDlgItemText(hwndRecvSms,IDC_MESSAGE,msg);
	CallService(MS_DB_EVENT_DELETE,(WPARAM)((CLISTEVENT*)lparam)->hContact,(LPARAM)((CLISTEVENT*)lparam)->hDbEvent);
	mir_free(msg);
	return 0;
}

//This function used to popup a read SMS window after the user clicked on the received SMS message.
int ReadMsgSMS(WPARAM wparam,LPARAM lparam)
{
	TCHAR newtitle[256];
	HWND hwndRecvSms;
	DBEVENTINFO dbei={0};
	int i;
	TCHAR cTmpNum[256];
	TCHAR* msg;
	dbei.cbSize=sizeof(dbei);
	dbei.cbBlob=CallService(MS_DB_EVENT_GETBLOBSIZE,(WPARAM)((CLISTEVENT*)lparam)->hDbEvent,0);
	dbei.pBlob=(PBYTE)mir_alloc(dbei.cbBlob);
	CallService(MS_DB_EVENT_GET,(WPARAM)((CLISTEVENT*)lparam)->hDbEvent,(LPARAM)&dbei);
	if((dbei.eventType != ICQEVENTTYPE_SMS) && (dbei.eventType!=ICQEVENTTYPE_SMSCONFIRMATION)) return 0;
	hwndRecvSms=AddRecvSMSWindow();//CreateDialog(GetPluginhInst(),MAKEINTRESOURCE(IDD_RECVSMS),NULL,RecvSmsDlgProc);
	if(((CLISTEVENT*)lparam)->hContact != NULL)
		lstrcpy(newtitle,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)((CLISTEVENT*)lparam)->hContact,(LPARAM)GCDNF_TCHAR));
	else
		lstrcpy(newtitle,TranslateT("Unknown"));
	lstrcat(newtitle,_T(" - "));
	lstrcat(newtitle,TranslateT("Received SMS"));
	SetWindowText(hwndRecvSms,newtitle);
	SetRecvSMSWindowHContact(hwndRecvSms,((CLISTEVENT*)lparam)->hContact);
	SetDlgItemText(hwndRecvSms,IDC_NAME,(TCHAR*)CallService(MS_CLIST_GETCONTACTDISPLAYNAME,(WPARAM)((CLISTEVENT*)lparam)->hContact,(LPARAM)GCDNF_TCHAR));
	msg = DbGetEventTextT( &dbei, CP_ACP );
	for(i=10;*(msg + i)!=_T('\r') && lstrlen(msg)>i-10;i++)
		cTmpNum[i-10]=*(msg + i);
	cTmpNum[i-10]=_T('\0');
	SetDlgItemText(hwndRecvSms,IDC_NUMBER,cTmpNum);
	SetDlgItemText(hwndRecvSms,IDC_MESSAGE,msg);
	CallService(MS_DB_EVENT_MARKREAD,(WPARAM)((CLISTEVENT*)lparam)->hContact,(LPARAM)((CLISTEVENT*)lparam)->hDbEvent);
	mir_free(msg);
	return 0;

}