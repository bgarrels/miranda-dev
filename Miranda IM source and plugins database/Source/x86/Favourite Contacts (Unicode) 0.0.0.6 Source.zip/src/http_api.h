#ifndef http_api_h__
#define http_api_h__

void LoadHttpApi();
void UnloadHttpApi();

#endif // http_api_h__
