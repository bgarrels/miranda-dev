//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDI_FAVOURITE                   101
#define IDI_ICON1                       102
#define IDI_REGULAR                     102
#define IDD_DIALOG1                     103
#define IDD_LIST                        103
#define IDD_PROPPAGE_LARGE              107
#define IDD_OPTIONS                     107
#define IDC_CLIST                       1001
#define IDC_CHK_SECONDLINE              1003
#define IDC_CHK_AVATARS                 1004
#define IDC_CHK_AVATARBORDER            1005
#define IDC_TXT_RADIUS                  1007
#define IDC_CHK_NOTRANSPARENTBORDER     1008
#define IDC_CHK_CENTERHOTKEY            1009
#define IDC_CHK_SYSCOLORS               1010
#define IDC_CANVAS                      1011
#define IDC_CHK_DIMIDLE                 1012
#define IDC_CHK_GROUPS                  1013
#define IDC_CHK_GROUPCOLUMS             1014
#define IDC_BTN_FONTS                   1015
#define IDC_TXT_RADIUS2                 1016
#define IDC_TXT_MAXRECENT               1016
#define IDC_BTN_HOTKEYS                 1018
#define IDC_CHK_RIGHTAVATARS            1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
