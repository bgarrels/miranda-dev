                   Floating Contacts plugin for Miranda
                   ---------------------------------------
                   

1. Installation Instructions
----------------------------
Copy fltcontacts.dll to Miranda plugins folder and restart Miranda.


2. How to use
----------------
To create a floating contact, drag a contact outside Miranda main window. To remove a contact, drag it back onto Miranda main window.

All contact's options that are normally accessible through the main contact list are accessible though the floating contact as well.


3. License and Copyright
------------------------
Source code is available at: http://www.miranda-im.org/download/

Floating Contacts plugin is released under the terms of the GNU General Public License.

Floating Contacts plugin is copyright 2000-2011 by Iavor Vajarov

