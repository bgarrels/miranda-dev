//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Script.rc
//
#define IDD_OPT_FLTCONT                 101
#define IDD_OPT_THUMB                   102
#define IDI_ICON1                       103
#define IDI_HIDE                        103
#define IDI_SHOW                        105
#define IDD_TABVIEW                     106
#define IDC_SLIDER_OPACITY              1001
#define IDC_OPACITY                     1002
#define IDC_CHK_HIDE_OFFLINE            1003
#define IDC_CHK_STICK                   1004
#define IDC_CHK_WIDTH                   1005
#define IDC_LBL_WIDTH                   1006
#define IDC_TXT_WIDTH                   1007
#define IDC_WIDTHSPIN                   1008
#define IDC_CHECK1                      1012
#define IDC_CHK_HIDE_ALL                1012
#define IDC_CHK_DEF_BACKGROUND          1013
#define IDC_CHK_HIDE_WHEN_FULSCREEN     1014
#define IDC_TAB1                        1014
#define IDC_TABVIEW                     1014
#define IDC_GROUP_OPACITY               1015
#define IDC_FONTID                      1100
#define IDC_SAMEAS                      1101
#define IDC_SAMETYPE                    1102
#define IDC_SAMESIZE                    1103
#define IDC_SAMESTYLE                   1104
#define IDC_SAMECOLOUR                  1105
#define IDC_TYPEFACE                    1106
#define IDC_SCRIPT                      1107
#define IDC_FONTSIZE                    1108
#define IDC_BOLD                        1109
#define IDC_ITALIC                      1110
#define IDC_UNDERLINE                   1111
#define IDC_COLOUR                      1112
#define IDC_SAMPLE                      1113
#define IDC_STSAMETEXT                  1114
#define IDC_STASTEXT                    1115
#define IDC_STHORZBAR                   1116
#define IDC_BKGCOLOUR                   1200
#define IDC_BITMAP                      1201
#define IDC_FILENAME                    1202
#define IDC_BROWSE                      1203
#define IDC_STRETCHH                    1204
#define IDC_STRETCHV                    1205
#define IDC_TILEH                       1206
#define IDC_TILEV                       1207
#define IDC_PROPORTIONAL                1208
#define IDC_DRAWBORDER                  1209
#define IDC_LTEDGESCOLOR                1210
#define IDC_RBEDGESCOLOR                1211

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
