/*

Miranda IM: the free IM client for Microsoft* Windows*

Copyright 2000-2004 Miranda ICQ/IM project, 
all portions of this codebase are copyrighted to the people 
listed in contributors.txt.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "..\..\core\commonheaders.h"
#include "m_sessions.h"

struct SION_PIPE_ENTITY {
	char *szEntity;
	DWORD dwHash;
	DWORD dwSdr;
	MIRANDASERVICE pfnService;
} static *sionPipeEntity=NULL;
static int sionPipeEntityCount=0;

struct SION_ENTITY_HANDLE {
	void *opaque[3];
	struct SION_PIPE_ENTITY *entityUI,*entityProto;
	struct SION_ENTITY_HANDLE *prev,*next;
	DWORD dwRefCount;
};
struct {
	struct SION_ENTITY_HANDLE *first,*last;
} static sionEntityHandles;

static CRITICAL_SECTION csSion;
static DWORD mainThreadId;
static HANDLE hMainThread;
extern DWORD NameHashFunction(const char *szStr);
struct PIPE_APC_DATA {
	struct PIPE_DATA *pd;
	int result;
	HANDLE hEvent;
};

void CALLBACK SionPipeAPC(DWORD dwParam)
{
	struct PIPE_APC_DATA *pad=(struct PIPE_APC_DATA*)dwParam;
	struct PIPE_DATA *pd=pad->pd;
	/* are they sending by handle? */
	if (pd->hSession && !pd->szEntity) {
		switch (pd->dwTo) {
			case SDR_UI: 
			{
				pd->szEntity=((struct SION_ENTITY_HANDLE*)pd->hSession)->entityUI->szEntity;
				break;
			}
			case SDR_PROTO:
			{
				pd->szEntity=((struct SION_ENTITY_HANDLE*)pd->hSession)->entityProto->szEntity;
				break;
			}
		} //switch
	} //if
	EnterCriticalSection(&csSion);
	/* pipe data can either be directed to entity by name or by SDR_* type or everyone! */
	if (pd->szEntity) 
	{
		DWORD dwHash=NameHashFunction(pd->szEntity);
		/* locate the entity */
		int j;
		pad->result=1; pd->reserved[0]=-1;
		for (j=0;j<sionPipeEntityCount;j++) {
			if (dwHash==sionPipeEntity[j].dwHash && !strcmp(pd->szEntity,sionPipeEntity[j].szEntity))
			{
				pad->result=sionPipeEntity[j].pfnService(0,(LPARAM)pd); 
				pd->reserved[0]=j;
				break;
			} //if
		} //for
	} 
	else {
		int j;
		if (pd->dwTo==SDR_ALL) {
			for(j=0;j<sionPipeEntityCount;j++) {
				if (pad->result=sionPipeEntity[j].pfnService(0,(LPARAM)pd)) break;
			} //for
        } else {
	        for(j=0;j<sionPipeEntityCount;j++) {
		        if (sionPipeEntity[j].dwSdr==pd->dwTo) {
			        if (pad->result=sionPipeEntity[j].pfnService(0,(LPARAM)pd)) break;
		        } //if
	        } //for
        } //if
	    
	} //if
	LeaveCriticalSection(&csSion);
	if (pad->hEvent) SetEvent(pad->hEvent);
	return;
}

int SionPipe(WPARAM wParam, LPARAM lParam)
{
	struct PIPE_DATA *pd=(struct PIPE_DATA*)lParam;
	if (pd && pd->cbSize==sizeof(struct PIPE_DATA)) {
		struct PIPE_APC_DATA pad={pd,0,NULL};
		if (mainThreadId==GetCurrentThreadId()) {
			SionPipeAPC((DWORD)&pad);
		} else {
			pad.hEvent=CreateEvent(NULL,FALSE,FALSE,NULL);
			QueueUserAPC(SionPipeAPC,hMainThread,(DWORD)&pad);
			WaitForSingleObject(pad.hEvent,INFINITE);
			CloseHandle(pad.hEvent);
		} //if
		return pad.result;
	} //if
	return 1;
}

int SionPipeHook(WPARAM wParam,LPARAM lParam)
{
	struct PIPE_DATA *pd=(struct PIPE_DATA*)lParam;
	if (pd && pd->cbSize==sizeof(struct PIPE_DATA) && pd->szEntity && pd->lParam) {
		EnterCriticalSection(&csSion);
		sionPipeEntity=realloc(sionPipeEntity,sizeof(struct SION_PIPE_ENTITY)*(sionPipeEntityCount+1));
		sionPipeEntity[sionPipeEntityCount].szEntity=_strdup(pd->szEntity);
		sionPipeEntity[sionPipeEntityCount].dwHash=NameHashFunction(pd->szEntity);		
		sionPipeEntity[sionPipeEntityCount].dwSdr=pd->dwTo;
		sionPipeEntity[sionPipeEntityCount].pfnService=(MIRANDASERVICE)pd->lParam;
		sionPipeEntityCount++;
		LeaveCriticalSection(&csSion);
		return 0;
	}
	return 1;
}

int SionManagerPipe(WPARAM wParam, LPARAM lParam)
{
	return 0;
}

// EntityList_* functions assume ownership of CRITICAL_SECTION

__inline void EntityList_Add(struct SION_ENTITY_HANDLE *seh)
{
	seh->next=NULL;
	seh->prev=sionEntityHandles.last;
	if (sionEntityHandles.first==NULL) sionEntityHandles.first=seh;
	if (sionEntityHandles.last) sionEntityHandles.last->next=seh;
	sionEntityHandles.last=seh;
}

__inline void EntityList_Remove(struct SION_ENTITY_HANDLE *seh)
{
	if (seh->prev && seh->next) {
		seh->prev->next = seh->next;
		seh->next->prev = seh->prev;
	} else {
		if (seh==sionEntityHandles.first) {
			sionEntityHandles.first=seh->next;
			if (seh->next) seh->next->prev=NULL;
		}
		if (seh==sionEntityHandles.last) {
			sionEntityHandles.last=seh->prev;
			if (seh->prev) seh->prev->next=NULL;
		}
	}
	seh->prev=seh->next=NULL;
}

int SionEntityCreate(WPARAM wParam,LPARAM lParam)
{
	struct SION_ENTITY_DESCRIPTOR *sed=(struct SION_ENTITY_DESCRIPTOR*)lParam;
	if (sed && sed->cbSize==sizeof(struct SION_ENTITY_DESCRIPTOR) && sed->szUI && sed->szProto && !sed->hSession) {
		struct SION_ENTITY_HANDLE *seh;
		struct PIPE_DATA pd;
		seh=calloc(sizeof(struct SION_ENTITY_HANDLE),1);
		memset(&pd,0,sizeof(pd));
		
		pd.cbSize=sizeof(pd);
		pd.hSession=seh;
		pd.dwMsg=ENTITY_CREATE;
		pd.dwFrom=SDR_SION;
		pd.dwTo=SDR_PROTO;
		/* tell the protocol */
		pd.szEntity=sed->szProto;
		if (!CallService(MS_SION_PIPE,0,(LPARAM)&pd)) {
			/* the first reserved DWORD has the lookup index of the found entity
			so we don't need to research or rehash */
			int indexEntity=pd.reserved[0];
			/* store what protocol is going to be used in the fake handle, so that the UI
			can query the handle for protocol information, sadly the protocol can't query
			for UI information, why should it need to? (unfamous last words) */
			seh->entityProto=&sionPipeEntity[indexEntity];						
			/* now tell the UI */
			pd.szEntity=sed->szUI;
			pd.hSession=seh;
			pd.dwTo=SDR_UI;
			if (!CallService(MS_SION_PIPE,0,(LPARAM)&pd)) {
				seh->dwRefCount++;
				seh->entityUI=&sionPipeEntity[pd.reserved[0]];
				seh->entityProto=&sionPipeEntity[indexEntity];
				/* lock the list and add the entity handle */
				EnterCriticalSection(&csSion);
				EntityList_Add(seh);
				LeaveCriticalSection(&csSion);
				/* return it to the caller, refCount=1 */
				sed->hSession=seh;
				return 0;
			} //if
		} //if
		return 2;
	} //if
	return 1;
}

int SionEntityRelease(WPARAM wParam,LPARAM lParam)
{
	struct SION_ENTITY_HANDLE *seh=(struct SION_ENTITY_HANDLE*)lParam;
	if (seh) {
		EnterCriticalSection(&csSion);
		if (--seh->dwRefCount) {
			seh=NULL;
		} else {
			EntityList_Remove(seh);
		}
		LeaveCriticalSection(&csSion);
		if (seh) {
			struct PIPE_DATA pd;
			pd.cbSize=sizeof(pd);
			pd.dwMsg=ENTITY_DESTROY;
			pd.hSession=seh;
			pd.wParam=0;
			pd.lParam=0;
			pd.dwFrom=SDR_SION;
			pd.dwTo=SDR_PROTO;
			pd.szEntity=seh->entityProto->szEntity;
			/* tell the protocol */
			CallService(MS_SION_PIPE,0,(LPARAM)&pd);			
			/* tell the UI */
			pd.szEntity=seh->entityUI->szEntity;
			pd.dwTo=SDR_UI;			
			CallService(MS_SION_PIPE,0,(LPARAM)&pd);
			/* free the handle */
			free(seh);
		} //if
		return 0;
	}
	return 1;
}

int SionEntityClone(WPARAM wParam,LPARAM lParam)
{
	struct SION_ENTITY_HANDLE *seh=(struct SION_ENTITY_HANDLE*)lParam;
	if (seh) {
		EnterCriticalSection(&csSion);
		seh->dwRefCount++;
		LeaveCriticalSection(&csSion);
		return 0;
	} //if
	return 1;
}

int SionEntityCookieSet(WPARAM wParam,LPARAM lParam)
{
	struct SION_ENTITY_COOKIE *cookie=(struct SION_ENTITY_COOKIE*)lParam;
	if (cookie && cookie->cbSize==sizeof(struct SION_ENTITY_COOKIE) && cookie->hSession) {
		struct SION_ENTITY_HANDLE *seh=(struct SION_ENTITY_HANDLE*)cookie->hSession;
		void **cookieData;
		switch (cookie->dwSdr) {
			case SDR_UI: 
			{
				cookieData=&seh->opaque[0];
				break;
			}
			case SDR_PROTO: 
			{
				cookieData=&seh->opaque[1];
			}			
			default:
			{
				return 2;
			}
		} //switch
		EnterCriticalSection(&csSion);
		if (cookie->data) {
			(*cookieData)=cookie->data;
		} else {
			cookie->data=(*cookieData); 
			if (!cookie->persist) { 
				(*cookieData)=NULL; 
			} //if
		} //if
		LeaveCriticalSection(&csSion);
		return 0;
	} //if
	return 1;
}
int SionEntityCookieFind(WPARAM wParam,LPARAM lParam)
{
	struct SION_ENTITY_COOKIE *cookie=(struct SION_ENTITY_COOKIE*)lParam;
	if (cookie && cookie->cbSize==sizeof(struct SION_ENTITY_COOKIE) && cookie->data && !cookie->hSession) {
		int rc=1;
		struct SION_ENTITY_HANDLE *p;
		EnterCriticalSection(&csSion);
		p=sionEntityHandles.first;
		while (p) {
			void **cookieData=NULL;
			switch (cookie->dwSdr) {
				case SDR_UI:
				{
					cookieData=&p->opaque[0];
					break;
				}
				case SDR_PROTO:
				{
					cookieData=&p->opaque[1];
					break;
				}
			} //switch
			if (cookieData && (*cookieData==cookie->data)) {
				p->dwRefCount++;
				cookie->hSession=p;
				rc=0;
				break;
			} //if
			p=p->next;
		} //while
		LeaveCriticalSection(&csSion);
		return rc;
	}
	return 1;
}

int SionControl(WPARAM wParam, LPARAM lParam)
{
	HANDLE hSession;
	hSession=Sion_EntityCreate("Kno","DGUI");
	if (hSession) {
		return 1;
	}
	return 0;
}

int UnloadSionManager(WPARAM wParam, LPARAM lParam)
{
	int j;
	struct SION_ENTITY_HANDLE *p,*q;	
	p=sionEntityHandles.first;
	while (p) {
		q=p->next;
		p->dwRefCount=1;
		Sion_EntityRelease(p);
		p=q;
	} //while
	for(j=0;j<sionPipeEntityCount;j++) {
		if (sionPipeEntity[j].szEntity) free(sionPipeEntity[j].szEntity);
	}
	if (sionPipeEntity) free(sionPipeEntity);
	DeleteCriticalSection(&csSion);
	CloseHandle(hMainThread);
	return 0;
}

int LoadSionManager(void)
{
	memset(&sionEntityHandles,0,sizeof(sionEntityHandles));
	mainThreadId=GetCurrentThreadId();
	DuplicateHandle(GetCurrentProcess(),GetCurrentThread(),GetCurrentProcess(),&hMainThread,THREAD_SET_CONTEXT,FALSE,0);
	InitializeCriticalSection(&csSion);
	HookEvent(ME_SYSTEM_SHUTDOWN,UnloadSionManager);
	HookEvent(ME_CLIST_DOUBLECLICKED,SionControl);	
	/* pipe related */
	CreateServiceFunction(MS_SION_PIPE,SionPipe);
	CreateServiceFunction(MS_SION_PIPEHOOK,SionPipeHook);
	/* entity related */
	CreateServiceFunction(MS_SION_ENTITY_CREATE,SionEntityCreate);
	CreateServiceFunction(MS_SION_ENTITY_RELEASE,SionEntityRelease);
	CreateServiceFunction(MS_SION_ENTITY_CLONE,SionEntityClone);
	/* cookies */
	CreateServiceFunction(MS_SION_ENTITY_SETCOOKIE,SionEntityCookieSet);	
	CreateServiceFunction(MS_SION_ENTITY_FINDCOOKIE,SionEntityCookieFind);
	/* register as the SION manager */
	Sion_PipeRegister(SDR_SION,NULL,SionManagerPipe);
	return 0;
}