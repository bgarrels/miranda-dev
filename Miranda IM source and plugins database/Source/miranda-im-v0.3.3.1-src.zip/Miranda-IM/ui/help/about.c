/*

Miranda IM: the free IM client for Microsoft* Windows*

Copyright 2000-2004 Miranda ICQ/IM project, 
all portions of this codebase are copyrighted to the people 
listed in contributors.txt.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "../../core/commonheaders.h"

BOOL CALLBACK DlgProcCredits(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

BOOL CALLBACK DlgProcAbout(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
			TranslateDialogDefault(hwndDlg);
			{	HFONT hFont;
				LOGFONT lf;
				hFont=(HFONT)SendDlgItemMessage(hwndDlg,IDC_MIRANDA,WM_GETFONT,0,0);
				GetObject(hFont,sizeof(lf),&lf);
				lf.lfHeight=(int)(lf.lfHeight*1.2);
				lf.lfWeight=FW_BOLD;
				hFont=CreateFontIndirect(&lf);
				SendDlgItemMessage(hwndDlg,IDC_MIRANDA,WM_SETFONT,(WPARAM)hFont,0);
			}
			{	char productVersion[56],str[64];
				CallService(MS_SYSTEM_GETVERSIONTEXT,sizeof(productVersion),(LPARAM)productVersion);
				_snprintf(str,sizeof(str),"%s %s", Translate("Miranda IM"), productVersion);
				SetDlgItemText(hwndDlg,IDC_MIRANDA,str);
				_snprintf(str,sizeof(str),Translate("Built %s %s"),__DATE__,__TIME__);
				SetDlgItemText(hwndDlg,IDC_BUILDTIME,str);
			}
			SendDlgItemMessage(hwndDlg,IDC_CONTRIBLINK,HLK_SETENABLECOLOUR,(WPARAM)RGB(0,0,255),0);
			SendDlgItemMessage(hwndDlg,IDC_HOMELINK,HLK_SETENABLECOLOUR,(WPARAM)RGB(0,0,255),0);
			SendDlgItemMessage(hwndDlg,IDC_SUPPORTLINK,HLK_SETENABLECOLOUR,(WPARAM)RGB(0,0,255),0);
			SendDlgItemMessage(hwndDlg,IDC_GPL,HLK_SETENABLECOLOUR,(WPARAM)RGB(0,0,255),0);
			SendMessage(hwndDlg, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MIRANDA)));
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK:
				case IDCANCEL:
					DestroyWindow(hwndDlg);
					return TRUE;
				case IDC_HOMELINK:
					CallService(MS_UTILS_OPENURL,1,(LPARAM)"http://www.miranda-im.org");
					break;
				case IDC_SUPPORTLINK:
					CallService(MS_UTILS_OPENURL,1,(LPARAM)"http://www.miranda-im.org/help/");
					break;
				case IDC_CONTRIBLINK:
				{
					DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_CREDITS), hwndDlg, DlgProcCredits);
					break;
				}
				case IDC_GPL:
				{	char szExec[MAX_PATH],*str;

					GetModuleFileName(GetModuleHandle(NULL),szExec,sizeof(szExec));
					str=strrchr(szExec,'\\');
					if(str!=NULL) *str=0;
					lstrcat(szExec,"\\License.txt");
					ShellExecute(hwndDlg,"open",szExec,NULL,NULL,SW_SHOW);
					break;
				}
			}
			break;
		case WM_CTLCOLOREDIT:
		case WM_CTLCOLORSTATIC:
			if((HWND)lParam==GetDlgItem(hwndDlg,IDC_WHITERECT)
					|| (HWND)lParam==GetDlgItem(hwndDlg,IDC_MIRANDA)
					|| (HWND)lParam==GetDlgItem(hwndDlg,IDC_COPYRIGHT)
					|| (HWND)lParam==GetDlgItem(hwndDlg,IDC_LOGO)
					|| (HWND)lParam==GetDlgItem(hwndDlg,IDC_DEVS)) {
				SetTextColor((HDC)wParam,RGB(0,0,0));
				SetBkColor((HDC)wParam,RGB(255,255,255));
				return (BOOL)GetStockObject(WHITE_BRUSH);
			}
			break;
		case WM_DESTROY:
			{	HFONT hFont;
				hFont=(HFONT)SendDlgItemMessage(hwndDlg,IDC_MIRANDA,WM_GETFONT,0,0);
				SendDlgItemMessage(hwndDlg,IDC_MIRANDA,WM_SETFONT,SendDlgItemMessage(hwndDlg,IDOK,WM_GETFONT,0,0),0);
				DeleteObject(hFont);				
			}
			break;
	}
	return FALSE;
}


BOOL CALLBACK DlgProcCredits(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
			SetDlgItemText(hwndDlg,IDC_CREDITSTEXT, LockResource(LoadResource(GetModuleHandle(NULL),FindResource(GetModuleHandle(NULL),MAKEINTRESOURCE(IDR_CREDITS),"TEXT"))));
			TranslateDialogDefault(hwndDlg);
			return TRUE;			
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK:
				case IDCANCEL:
					EndDialog(hwndDlg, 0);
					return TRUE;
			}
			break;
		case WM_DESTROY:
			break;
	}
	return FALSE;
}