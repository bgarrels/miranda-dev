/*

Miranda IM: the free IM client for Microsoft* Windows*

Copyright 2000-2004 Miranda ICQ/IM project, 
all portions of this codebase are copyrighted to the people 
listed in contributors.txt.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "../core/commonheaders.h"
#include "database.h"

static char *szDbPathDest;
static int cbDbPathDest;

int GetCommandLineDbName(char *szName,int cbName);



static BOOL CALLBACK NewProfileDlgProc(HWND hdlg,UINT message,WPARAM wParam,LPARAM lParam)
{

	switch(message) {
		case WM_INITDIALOG:
			TranslateDialogDefault(hdlg);
			{	char szDbName[MAX_PATH];

				if(!GetCommandLineDbName(szDbName,sizeof(szDbName))) {
					SetDlgItemText(hdlg,IDC_NEWPROFILENAME,szDbName);
					SendDlgItemMessage(hdlg,IDC_NEWPROFILENAME,EM_SETSEL,0,(LPARAM)(-1));
				}
			}
			return TRUE;
			
		case WM_COMMAND:
			switch(LOWORD(wParam)) {
				case IDOK:
					{
						
						HANDLE hFile;
						char szMirandaPath[MAX_PATH];
						char szNewDbName[MAX_PATH];
						char szNewProfileName[MAX_PATH];

						GetDlgItemText(hdlg,IDC_NEWPROFILENAME,szNewProfileName,sizeof(szNewProfileName));

						if(szNewProfileName[0]==0)
						{

						  MessageBox(hdlg,"Please enter a profile name in the edit box", "Create New Profile", MB_OK);
						  break;

						}

						GetProfileDirectory(szMirandaPath, sizeof(szMirandaPath));
						wsprintf(szNewDbName, "%s\\%s.dat", szMirandaPath, szNewProfileName);

						hFile = CreateFile(szNewDbName, 0, FILE_SHARE_READ, NULL, CREATE_NEW, 0, NULL);

						if (hFile == INVALID_HANDLE_VALUE)
						{
							DWORD dwError;
							
							dwError = GetLastError();
							if (dwError == ERROR_ALREADY_EXISTS ||
								dwError == ERROR_FILE_EXISTS)
							{
								MessageBox(hdlg, 
									"A profile with that name already exists.\nPlease choose another name or cancel this operation and select that profile from the profile manager",
									"Create New Profile", MB_OK);
							}
							else
							{

								LPVOID lpMsgBuf = NULL;
								char* pszDialogMessage;

								if (FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
									NULL,
									dwError,
									MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
									(LPTSTR) &lpMsgBuf,
									0,
									NULL ))
								{

									pszDialogMessage = calloc(strlen("Failed to create profile.\n") + strlen(lpMsgBuf) + 1, 1);
									sprintf(pszDialogMessage, "Failed to create profile.\n%s", lpMsgBuf);
									LocalFree(lpMsgBuf);
								}
								else
								{
									pszDialogMessage = calloc(strlen("Failed to create profile.\nUnknown error." + 1), 1);
									sprintf(pszDialogMessage, "Failed to create profile.\nUnknown error.");
								}
								
								// Display the string.
								MessageBox(NULL, (LPCTSTR)pszDialogMessage, "Error", MB_OK | MB_ICONERROR);
								
								// Free the buffer.
								free(pszDialogMessage);
							
							}
							break;
						}

						CloseHandle(hFile);

					}
					//fall through
				case IDCANCEL:
					EndDialog(hdlg,LOWORD(wParam)==IDCANCEL);
					break;
			}
			break;
	}
	return FALSE;
}



#define WM_RECREATEPROFILELIST   (WM_USER+1)
#define WM_SHOWNORMAL   (WM_USER+2)
static BOOL CALLBACK ProfileManagerDlgProc(HWND hdlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message) {
		case WM_INITDIALOG:
			TranslateDialogDefault(hdlg);
			{	LVCOLUMN lvc;
				lvc.mask=LVCF_WIDTH;
				lvc.cx=100;
				ListView_InsertColumn(GetDlgItem(hdlg,IDC_PROFILELIST),0,&lvc);
			}
			SendMessage(hdlg,WM_RECREATEPROFILELIST,0,0);
			PostMessage(hdlg,WM_SHOWNORMAL,0,0);
			return TRUE;
		case WM_SHOWNORMAL:
			ShowWindow(hdlg,SW_SHOWNORMAL);
			break;
		case WM_RECREATEPROFILELIST:
			{	HANDLE hFind;
				WIN32_FIND_DATA fd;
				char szMirandaPath[MAX_PATH],szSearchPath[MAX_PATH],szDefaultProfilePath[MAX_PATH],szThisProfilePath[MAX_PATH];
				LVITEM lvi;

				EnableWindow(GetDlgItem(hdlg,IDOK),FALSE);
				ListView_DeleteAllItems(GetDlgItem(hdlg,IDC_PROFILELIST));
				GetProfileDirectory(szMirandaPath,sizeof(szMirandaPath));
				GetDefaultProfilePath(szDefaultProfilePath,sizeof(szDefaultProfilePath),NULL);
				lstrcpy(szSearchPath,szMirandaPath);
				lstrcat(szSearchPath,"\\*.dat");
				hFind=FindFirstFile(szSearchPath,&fd);
				lvi.iItem=0;
				if(hFind!=INVALID_HANDLE_VALUE) {
					do {
						lvi.mask=LVIF_TEXT;
						lvi.iSubItem=0;
						lvi.state=lvi.stateMask=LVIS_SELECTED;
						lstrcpy(szThisProfilePath,szMirandaPath);
						lstrcat(szThisProfilePath,"\\");
						lstrcat(szThisProfilePath,fd.cFileName);
						if(!lstrcmpi(szThisProfilePath,szDefaultProfilePath)) {
							lvi.mask|=LVIF_STATE;
							EnableWindow(GetDlgItem(hdlg,IDOK),TRUE);
						}
						lvi.pszText=fd.cFileName;
						{	char *str2;
							str2=strrchr(fd.cFileName,'.');
							if(str2!=NULL) *str2=0;
						}
						ListView_InsertItem(GetDlgItem(hdlg,IDC_PROFILELIST),&lvi);
						lvi.iItem++;
					} while(FindNextFile(hFind,&fd));
					FindClose(hFind);
				}
			}
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam)) {
				case IDOK:
					{	LVITEM lvi;
						char szProfileName[MAX_PATH],szMirandaPath[MAX_PATH];
						if(ListView_GetSelectedCount(GetDlgItem(hdlg,IDC_PROFILELIST))!=1) {
							MessageBox(hdlg,"Please select a profile from the list to run Miranda","Profile Manager",MB_OK);
							break;
						}
						lvi.mask=LVIF_TEXT;
						lvi.iItem=ListView_GetNextItem(GetDlgItem(hdlg,IDC_PROFILELIST),-1,LVNI_ALL|LVNI_SELECTED);
						lvi.iSubItem=0;
						lvi.cchTextMax=sizeof(szProfileName);
						lvi.pszText=szProfileName;
						ListView_GetItem(GetDlgItem(hdlg,IDC_PROFILELIST),&lvi);
						GetProfileDirectory(szMirandaPath,sizeof(szMirandaPath));
						_snprintf(szDbPathDest,cbDbPathDest,"%s\\%s.dat",szMirandaPath,szProfileName);
					}
					//fall through
				case IDCANCEL:
					EndDialog(hdlg,LOWORD(wParam)==IDCANCEL);
					break;
				case IDC_NEWPROFILE:
					if (!DialogBox(GetModuleHandle(NULL),MAKEINTRESOURCE(IDD_NEWPROFILE),hdlg,NewProfileDlgProc))
						SendMessage(hdlg,WM_RECREATEPROFILELIST,0,0);
					break;
			}
			break;
		case WM_NOTIFY:
			switch(((NMHDR*)lParam)->idFrom) {
				case IDC_PROFILELIST:
					switch(((NMHDR*)lParam)->code) {
						case NM_DBLCLK:
							if (ListView_GetSelectedCount(GetDlgItem(hdlg,IDC_PROFILELIST))==1) {
								SendMessage(hdlg,WM_COMMAND,MAKEWPARAM(IDOK,BN_CLICKED),0);
							}
							break;
						case LVN_ITEMCHANGED:
							EnableWindow(GetDlgItem(hdlg,IDOK),ListView_GetSelectedCount(GetDlgItem(hdlg,IDC_PROFILELIST))==1);
							break;
					}
					break;
			}
			break;
	}
	return FALSE;
}

int ProfileManager(char *szDbDest,int cbDbDest)
{
	szDbPathDest=szDbDest;
	cbDbPathDest=cbDbDest;
	return DialogBox(GetModuleHandle(NULL),MAKEINTRESOURCE(IDD_PROFILEMANAGER),NULL,ProfileManagerDlgProc);
}