/*

Miranda IM: the free IM client for Microsoft* Windows*

Copyright 2000-2004 Miranda ICQ/IM project, 
all portions of this codebase are copyrighted to the people 
listed in contributors.txt.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "../../core/commonheaders.h"

struct SoundItem {
	char *name,*description,*defaultFile;
};
static struct SoundItem *soundList=NULL;
static int soundCount;

static int ServiceSkinAddNewSound(WPARAM wParam,LPARAM lParam)
{
	SKINSOUNDDESC *ssd=(SKINSOUNDDESC*)lParam;
	soundList=(struct SoundItem*)realloc(soundList,sizeof(struct SoundItem)*(soundCount+1));
	soundList[soundCount].name=_strdup(ssd->pszName);
	soundList[soundCount].defaultFile=NULL;
	if (ssd->pszDefaultFile) soundList[soundCount].defaultFile=_strdup(ssd->pszDefaultFile);
	soundList[soundCount].description=_strdup(ssd->pszDescription);
	soundCount++;
	return 0;
}

static int ServiceSkinPlaySound(WPARAM wParam,LPARAM lParam)
{
	int i;
	if(!DBGetContactSettingByte(NULL,"Skin","UseSound",0)) return 0;
	for(i=0;i<soundCount;i++) {
		if(!strcmp(soundList[i].name,(char*)lParam)) {
			DBVARIANT dbv;
			if(DBGetContactSettingByte(NULL,"SkinSoundsOff",(char*)lParam,0)) break;
			if(!DBGetContactSetting(NULL,"SkinSounds",(char*)lParam,&dbv)) {
				PlaySound(dbv.pszVal, NULL, SND_ASYNC | SND_FILENAME | SND_NOWAIT);
				free(dbv.pszVal);
			}
			else {
				if (soundList[i].defaultFile) PlaySound(soundList[i].defaultFile,NULL,SND_ASYNC|SND_FILENAME);
			}
			break;
		}
	}
	//if(i>=soundCount) PlaySound("",NULL,SND_ASYNC|SND_FILENAME);	  //do a default
	return 0;
}

BOOL CALLBACK DlgProcSoundOpts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{	LV_COLUMN lvc;
			LV_ITEM lvi;
			DBVARIANT dbv;
			int newItem;
			RECT rcList;

			TranslateDialogDefault(hwndDlg);
			CheckDlgButton(hwndDlg, IDC_USESOUND, DBGetContactSettingByte(NULL,"Skin","UseSound",0) ? BST_CHECKED : BST_UNCHECKED);
			EnableWindow(GetDlgItem(hwndDlg,IDC_SOUNDLIST),IsDlgButtonChecked(hwndDlg,IDC_USESOUND));
			{	HIMAGELIST hIml;
				hIml=ImageList_Create(GetSystemMetrics(SM_CXSMICON),GetSystemMetrics(SM_CYSMICON),ILC_COLOR4|ILC_MASK,2,2);
				ImageList_AddIcon(hIml,LoadIcon(GetModuleHandle(NULL),MAKEINTRESOURCE(IDI_NOTICK)));
				ImageList_AddIcon(hIml,LoadIcon(GetModuleHandle(NULL),MAKEINTRESOURCE(IDI_TICK)));
				ListView_SetImageList(GetDlgItem(hwndDlg,IDC_SOUNDLIST),hIml,LVSIL_SMALL);
			}
			GetClientRect(GetDlgItem(hwndDlg,IDC_SOUNDLIST),&rcList);
			ListView_SetExtendedListViewStyleEx(GetDlgItem(hwndDlg,IDC_SOUNDLIST),LVS_EX_FULLROWSELECT,LVS_EX_FULLROWSELECT);
			lvc.mask=LVCF_WIDTH|LVCF_TEXT;
			lvc.cx=rcList.right/3;
			lvc.pszText=Translate("Description");
			ListView_InsertColumn(GetDlgItem(hwndDlg,IDC_SOUNDLIST),0,&lvc);
			lvc.cx=rcList.right-rcList.right/3-GetSystemMetrics(SM_CXVSCROLL);
			lvc.pszText=Translate("Filename");
			ListView_InsertColumn(GetDlgItem(hwndDlg,IDC_SOUNDLIST),1,&lvc);
			lvi.mask=LVIF_TEXT|LVIF_PARAM|LVIF_IMAGE;
			lvi.iSubItem=0;
			for(lvi.iItem=0;lvi.iItem<soundCount;lvi.iItem++) {
				lvi.lParam=lvi.iItem;
				lvi.pszText=soundList[lvi.iItem].description;
				lvi.iImage=!DBGetContactSettingByte(NULL,"SkinSoundsOff",soundList[lvi.iItem].name,0);
				newItem=ListView_InsertItem(GetDlgItem(hwndDlg,IDC_SOUNDLIST),&lvi);
				if(!DBGetContactSetting(NULL,"SkinSounds",soundList[lvi.iItem].name,&dbv)) {
					ListView_SetItemText(GetDlgItem(hwndDlg,IDC_SOUNDLIST),newItem,1,dbv.pszVal);
					free(dbv.pszVal);
				}
				else { 
					if (soundList[lvi.iItem].defaultFile) ListView_SetItemText(GetDlgItem(hwndDlg,IDC_SOUNDLIST),newItem,1,soundList[lvi.iItem].defaultFile);
				}
			}
			ListView_SetItemState(GetDlgItem(hwndDlg,IDC_SOUNDLIST),0,LVIS_SELECTED,LVIS_SELECTED);
			return TRUE;
		}
		case WM_COMMAND:
			if(LOWORD(wParam)==IDC_USESOUND) {
				EnableWindow(GetDlgItem(hwndDlg,IDC_SOUNDLIST),IsDlgButtonChecked(hwndDlg,IDC_USESOUND));
			}
			if(LOWORD(wParam)==IDC_PREVIEW) {
				char str[MAX_PATH];
				ListView_GetItemText(GetDlgItem(hwndDlg,IDC_SOUNDLIST),ListView_GetNextItem(GetDlgItem(hwndDlg,IDC_SOUNDLIST),-1,LVNI_SELECTED),1,str,sizeof(str));
				PlaySound(str,NULL,SND_ASYNC|SND_FILENAME);
				break;
			}
			if(LOWORD(wParam)==IDC_CHANGE) {
				char str[MAX_PATH];
				OPENFILENAME ofn;

				ListView_GetItemText(GetDlgItem(hwndDlg,IDC_SOUNDLIST),ListView_GetNextItem(GetDlgItem(hwndDlg,IDC_SOUNDLIST),-1,LVNI_SELECTED),1,str,sizeof(str));
				ZeroMemory(&ofn, sizeof(ofn));
				ofn.lStructSize = OPENFILENAME_SIZE_VERSION_400;
				ofn.hwndOwner = GetParent(hwndDlg);
				ofn.hInstance = NULL;
				ofn.lpstrFilter = "Wave Files (*.wav)\0*.WAV\0All Files (*)\0*\0";
				ofn.lpstrFile = str;
				ofn.Flags = OFN_FILEMUSTEXIST|OFN_HIDEREADONLY;
				ofn.nMaxFile = sizeof(str);
				ofn.nMaxFileTitle = MAX_PATH;
				ofn.lpstrDefExt = "wav";
				if(!GetOpenFileName(&ofn)) break;
				ListView_SetItemText(GetDlgItem(hwndDlg,IDC_SOUNDLIST),ListView_GetNextItem(GetDlgItem(hwndDlg,IDC_SOUNDLIST),-1,LVNI_SELECTED),1,str);
			}
			if(LOWORD(wParam)==IDC_GETMORE) {
				char szVer[64],szUrl[256];
				CallService(MS_SYSTEM_GETVERSIONTEXT,sizeof(szVer),(LPARAM)szVer);
				while(strchr(szVer,' ')) *strchr(szVer,' ')='_';
				wsprintf(szUrl,"http://www.miranda-im.org/download/index.php",szVer);
				CallService(MS_UTILS_OPENURL,1,(LPARAM)szUrl);
				break;
			}
			SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);
			break;
		case WM_NOTIFY:
			switch(((NMHDR*)lParam)->idFrom) {
				case IDC_SOUNDLIST:
					switch(((NMHDR*)lParam)->code) {
						case NM_CLICK:
						{	LVHITTESTINFO hti;
							LVITEM lvi;
							hti.pt=((NMLISTVIEW*)lParam)->ptAction;
							ListView_SubItemHitTest(GetDlgItem(hwndDlg,IDC_SOUNDLIST),&hti);
							if(hti.flags!=LVHT_ONITEMICON) break;
							lvi.mask=LVIF_IMAGE;
							lvi.iItem=hti.iItem;
							lvi.iSubItem=0;
							ListView_GetItem(GetDlgItem(hwndDlg,IDC_SOUNDLIST),&lvi);
							lvi.iImage^=1;
							ListView_SetItem(GetDlgItem(hwndDlg,IDC_SOUNDLIST),&lvi);
							SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);
							break;
						}
					}
					break;
				case 0:
					switch (((LPNMHDR)lParam)->code)
					{
						case PSN_APPLY:
						{	int i;
							char str[MAX_PATH];
							LVITEM lvi;
							DBWriteContactSettingByte(NULL,"Skin","UseSound",(BYTE)IsDlgButtonChecked(hwndDlg,IDC_USESOUND));
							for(i=0;i<soundCount;i++) {
								lvi.iItem=i;
								lvi.iSubItem=0;
								lvi.mask=LVIF_PARAM|LVIF_IMAGE;
								ListView_GetItem(GetDlgItem(hwndDlg,IDC_SOUNDLIST),&lvi);
								ListView_GetItemText(GetDlgItem(hwndDlg,IDC_SOUNDLIST),i,1,str,sizeof(str));
								if(soundList[lvi.lParam].defaultFile && strcmp(str,soundList[lvi.lParam].defaultFile))
									DBWriteContactSettingString(NULL,"SkinSounds",soundList[lvi.lParam].name,str);
								if(lvi.iImage) {
									DBCONTACTGETSETTING cgs;
									cgs.szModule="SkinSoundsOff";
									cgs.szSetting=soundList[lvi.lParam].name;
									CallService(MS_DB_CONTACT_DELETESETTING,(WPARAM)(HANDLE)NULL,(LPARAM)&cgs);
								}
								else DBWriteContactSettingByte(NULL,"SkinSoundsOff",soundList[lvi.lParam].name,1);
							}
							return TRUE;
						}
					}
					break;
			}
			break;
	}
	return FALSE;
}

int InitSkinSounds(void)
{
	soundList=NULL;
	soundCount=0;
	CreateServiceFunction(MS_SKIN_ADDNEWSOUND,ServiceSkinAddNewSound);
	CreateServiceFunction(MS_SKIN_PLAYSOUND,ServiceSkinPlaySound);
	return 0;
}

void UninitSkinSounds(void)
{
	int i;
	for(i=0;i<soundCount;i++) {
		free(soundList[i].name);
		if (soundList[i].defaultFile) free(soundList[i].defaultFile);
		free(soundList[i].description);
	}
	if(soundCount) free(soundList);
}
