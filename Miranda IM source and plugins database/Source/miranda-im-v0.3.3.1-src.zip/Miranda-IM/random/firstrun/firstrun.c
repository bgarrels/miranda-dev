/*

Miranda IM: the free IM client for Microsoft* Windows*

Copyright 2000-2004 Miranda ICQ/IM project, 
all portions of this codebase are copyrighted to the people 
listed in contributors.txt.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "../../core/commonheaders.h"

BOOL CALLBACK DlgProcGPL(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgProcPassword(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

int LoadFirstRunModule(void)
{
	if(DBGetContactSettingByte(NULL,"FirstRun","Done",0)) return 0;
	if (DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_GNUPL), NULL, DlgProcGPL) != IDOK)
		return 1;
	DBWriteContactSettingByte(NULL,"FirstRun","Done",1);
	return 0;
}

BOOL CALLBACK DlgProcGPL(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	FILE *fp;

	char *buf;

	switch (msg)
	{
        // not needed really
        case WM_DRAWITEM:
        {
            // Please read and accept the GPL license Miranda is released under
            LPDRAWITEMSTRUCT dwi = (LPDRAWITEMSTRUCT) lParam;
            HFONT hBoldFont = 0;
            HFONT hFont = GetCurrentObject(dwi->hDC, OBJ_FONT);
            LOGFONT lf;
            SIZE sz;

            // create a bold copy
            GetObject(hFont, sizeof(lf), &lf);
            lf.lfWeight = FW_BOLD;
            hBoldFont = CreateFontIndirect(&lf);
            GetTextExtentPoint32(dwi->hDC, "_W", 2, &sz);
            SetTextAlign(dwi->hDC, TA_UPDATECP);
            TextOut(dwi->hDC, 0, 0, Translate("Please"), strlen(Translate("Please")));
            TextOut(dwi->hDC, 0, 0, " ", 1);
            SelectObject(dwi->hDC, hBoldFont);
            TextOut(dwi->hDC, 0, 0, Translate("read and accept"), strlen(Translate("read and accept")));
            TextOut(dwi->hDC, 0, 0, " ", 1);
            SelectObject(dwi->hDC, hFont);
            TextOut(dwi->hDC, 0, 0, Translate("the Miranda IM license agreement:"), strlen(Translate("the Miranda IM license agreement:")));
            // clean up
            DeleteObject(hBoldFont);
            break;
        }
		case WM_INITDIALOG:
			TranslateDialogDefault(hwndDlg);
			{
				char fn[MAX_PATH];
				SendMessage(hwndDlg, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MIRANDA)));

				GetModuleFileName(GetModuleHandle(NULL), fn, sizeof(fn));
				strcpy(strrchr(fn, '\\'), "\\License.txt");

				fp = fopen(fn, "rb");
				if (fp)
				{
					buf = calloc(32 * 1024, 1);

					fread(buf, 1, 32 * 1024, fp);

					SendDlgItemMessage(hwndDlg, IDC_TEXT, WM_SETTEXT, 0, (LPARAM)buf);
					free(buf);
					fclose(fp);
				}
			}
			return TRUE;
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
				case IDCANCEL:
					EndDialog(hwndDlg, LOWORD(wParam));
					return TRUE;
			}
	}
	return 0;
}
