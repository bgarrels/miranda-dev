/*

Miranda IM: the free IM client for Microsoft* Windows*

Copyright 2000-2004 Miranda ICQ/IM project, 
all portions of this codebase are copyrighted to the people 
listed in contributors.txt.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "../../core/commonheaders.h"
#include "../../sendrecv/awaymsg/m_awaymsg.h"

#define SETTING_AWAYTIME_DEFAULT	5
#define SETTING_NATIME_DEFAULT		20
#define SETTING_AWAYCHECKTIMEINSECS	5

static BOOL (WINAPI * MyGetLastInputInfo)(PLASTINPUTINFO);

static BOOL CALLBACK DlgProcAutoAwayOpts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
			TranslateDialogDefault(hwndDlg);
			CheckDlgButton(hwndDlg, IDC_SCREENSAVE, DBGetContactSettingByte(NULL,"AutoAway","OnSaver",0) ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hwndDlg, IDC_WSLOCK, DBGetContactSettingByte(NULL,"AutoAway","OnWLock",0) ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hwndDlg, IDC_TIMED, DBGetContactSettingByte(NULL,"AutoAway","OnMouse",0) ? BST_CHECKED : BST_UNCHECKED);
			SetDlgItemInt(hwndDlg,IDC_AWAYTIME,DBGetContactSettingWord(NULL,"AutoAway","AwayTime",SETTING_AWAYTIME_DEFAULT),FALSE);
			CheckDlgButton(hwndDlg, IDC_SETNA, DBGetContactSettingByte(NULL,"AutoAway","SetNA",0) ? BST_CHECKED : BST_UNCHECKED);
			SetDlgItemInt(hwndDlg,IDC_NATIME,DBGetContactSettingWord(NULL,"AutoAway","NATime",SETTING_NATIME_DEFAULT),FALSE);
			if(MyGetLastInputInfo!=NULL) {
				SetDlgItemText(hwndDlg,IDC_STAWAYTYPE,Translate("minutes of inactivity"));
				SetDlgItemText(hwndDlg,IDC_SETNASTR,Translate("minutes of inactivity"));
			}
			EnableWindow(GetDlgItem(hwndDlg,IDC_AWAYTIME),IsDlgButtonChecked(hwndDlg,IDC_TIMED));
			EnableWindow(GetDlgItem(hwndDlg,IDC_STAWAYTYPE),IsDlgButtonChecked(hwndDlg,IDC_TIMED));				
			EnableWindow(GetDlgItem(hwndDlg,IDC_NATIME),IsDlgButtonChecked(hwndDlg,IDC_SETNA));
			EnableWindow(GetDlgItem(hwndDlg,IDC_SETNASTR),IsDlgButtonChecked(hwndDlg,IDC_SETNA));
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam)) {
				case IDC_TIMED:
					EnableWindow(GetDlgItem(hwndDlg,IDC_AWAYTIME),IsDlgButtonChecked(hwndDlg,IDC_TIMED));					
					EnableWindow(GetDlgItem(hwndDlg,IDC_STAWAYTYPE),IsDlgButtonChecked(hwndDlg,IDC_TIMED));				
					break;
				case IDC_SETNA:
					EnableWindow(GetDlgItem(hwndDlg,IDC_NATIME),IsDlgButtonChecked(hwndDlg,IDC_SETNA));
					EnableWindow(GetDlgItem(hwndDlg,IDC_SETNASTR),IsDlgButtonChecked(hwndDlg,IDC_SETNA));
					break;
				case IDC_AWAYTIME:
				case IDC_NATIME:
					if(HIWORD(wParam)!=EN_CHANGE) return 0;
					if((HWND)lParam!=GetFocus()) return 0;
					break;
			}
			SendMessage(GetParent(hwndDlg), PSM_CHANGED, 0, 0);
			break;
		case WM_NOTIFY:
			switch (((LPNMHDR)lParam)->code)
			{
				case PSN_APPLY:
					DBWriteContactSettingByte(NULL,"AutoAway","OnSaver",(BYTE)IsDlgButtonChecked(hwndDlg,IDC_SCREENSAVE));
					DBWriteContactSettingByte(NULL,"AutoAway","OnWLock",(BYTE)IsDlgButtonChecked(hwndDlg,IDC_WSLOCK));
					DBWriteContactSettingByte(NULL,"AutoAway","OnMouse",(BYTE)IsDlgButtonChecked(hwndDlg,IDC_TIMED));
					DBWriteContactSettingWord(NULL,"AutoAway","AwayTime",(WORD)GetDlgItemInt(hwndDlg,IDC_AWAYTIME,NULL,FALSE));
					DBWriteContactSettingByte(NULL,"AutoAway","SetNA",(BYTE)IsDlgButtonChecked(hwndDlg,IDC_SETNA));
					DBWriteContactSettingWord(NULL,"AutoAway","NATime",(WORD)GetDlgItemInt(hwndDlg,IDC_NATIME,NULL,FALSE));
					return TRUE;
			}
			break;
	}
	return FALSE;
}

static int AutoAwayOptInitialise(WPARAM wParam,LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp;

	ZeroMemory(&odp,sizeof(odp));
	odp.cbSize=sizeof(odp);
	odp.position=1000000000;
	odp.hInstance=GetModuleHandle(NULL);
	odp.pszTemplate=MAKEINTRESOURCE(IDD_OPT_AUTOAWAY);
	odp.pszTitle=Translate("Auto Away");
	odp.pszGroup=Translate("Status");
	odp.pfnDlgProc=DlgProcAutoAwayOpts;
	odp.flags=ODPF_BOLDGROUPS;
	CallService(MS_OPT_ADDPAGE,wParam,(LPARAM)&odp);
	return 0;
}

static int mouseStationaryTimer;
static POINT lastMousePos;
static int awaySet,naSet;
static int originalStatusMode;

BOOL IsWorkstationLocked(void)
{
	HDESK hd;
	char buf[MAX_PATH];
	hd = OpenInputDesktop(0,FALSE,MAXIMUM_ALLOWED); /* if it fails then the workstation is prolly locked anyway */
	if (hd==NULL) return TRUE;
	GetUserObjectInformation(hd,UOI_NAME,buf,sizeof(buf),NULL); /* if we got it (hmm,) get a name */
	CloseDesktop(hd);
	return strcmp(buf,"Winlogon")==0;
} 

static void setAutoStatus(int newstatus, int oldstatus) {
	PROTOCOLDESCRIPTOR **protos;
	int count,i,status,statusKnown;
	char *msg = (char*)CallService(MS_AWAYMSG_GETSTATUSMSG, (WPARAM)newstatus, 0);
	
	CallService(MS_PROTO_ENUMPROTOCOLS,(WPARAM)&count,(LPARAM)&protos);
	for(i=0;i<count;i++) {
		if(protos[i]->type!=PROTOTYPE_PROTOCOL) continue;
		statusKnown=CallProtoService(protos[i]->szName,PS_GETCAPS,PFLAGNUM_2,0);
		status = CallProtoService(protos[i]->szName,PS_GETSTATUS,0,0);
		if ((statusKnown&PF2_SHORTAWAY || statusKnown&PF2_LONGAWAY) && status>=ID_STATUS_ONLINE && status!=ID_STATUS_INVISIBLE) {
			CallProtoService(protos[i]->szName, PS_SETSTATUS, (WPARAM)newstatus, 0);
			CallProtoService(protos[i]->szName, PS_SETAWAYMSG, (WPARAM)newstatus, (LPARAM)msg);
		}
	}
	if (msg) free(msg);
}

static VOID CALLBACK AutoAwayTimer(HWND hwnd,UINT message,UINT idEvent,DWORD dwTime)
{
	BOOL shouldBeAway=0,shouldBeNA=0;
	int currentMode;

	if(DBGetContactSettingByte(NULL,"AutoAway","OnSaver",0)) {
		SystemParametersInfo(SPI_GETSCREENSAVERRUNNING,0,&shouldBeAway,FALSE);
		if (shouldBeAway) goto TestSetAway;
	}
	if(DBGetContactSettingByte(NULL,"AutoAway","OnWLock",0) && IsWorkstationLocked()) { 
		shouldBeAway=1; goto TestSetAway; 
	}
	{
		if(MyGetLastInputInfo!=NULL) {
			LASTINPUTINFO lii;
			ZeroMemory(&lii,sizeof(lii));
			lii.cbSize=sizeof(lii);
			MyGetLastInputInfo(&lii);
			mouseStationaryTimer=(GetTickCount()-lii.dwTime)/1000;
		}
		else {
			POINT pt;
			GetCursorPos(&pt);
			if(pt.x!=lastMousePos.x || pt.y!=lastMousePos.y) {
				lastMousePos=pt;
				mouseStationaryTimer=0;
			}
			else mouseStationaryTimer+=5;
		}
		shouldBeAway=!DBGetContactSettingByte(NULL,"AutoAway","OnMouse",0)?0:mouseStationaryTimer>=60*DBGetContactSettingWord(NULL,"AutoAway","AwayTime",SETTING_AWAYTIME_DEFAULT);
		shouldBeNA=!DBGetContactSettingByte(NULL,"AutoAway","SetNA",0)?0:mouseStationaryTimer>=60*DBGetContactSettingWord(NULL,"AutoAway","NATime",SETTING_NATIME_DEFAULT);
		if (shouldBeNA) shouldBeAway=0;
	}
TestSetAway:
	currentMode=CallService(MS_CLIST_GETSTATUSMODE,0,0);
	if(!awaySet && shouldBeAway && (currentMode==ID_STATUS_ONLINE || currentMode==ID_STATUS_FREECHAT)) {
		setAutoStatus(ID_STATUS_AWAY, currentMode);
		awaySet=1;
		originalStatusMode=currentMode;
	}
	else if(!shouldBeAway && awaySet && !shouldBeNA) {
		setAutoStatus(originalStatusMode, currentMode);
		awaySet=0;
	}
	else if(!naSet && shouldBeNA && (currentMode==ID_STATUS_ONLINE || currentMode==ID_STATUS_FREECHAT || awaySet)) {
		setAutoStatus(ID_STATUS_NA, currentMode);
		naSet=1;
		if (!awaySet) originalStatusMode=currentMode;
	}
	else if(!shouldBeNA && naSet) {
		setAutoStatus(originalStatusMode, currentMode);
		naSet=0;
	}
}

static UINT hAutoAwayTimer;

static int AutoAwayShutdown(WPARAM wParam,LPARAM lParam)
{
	if(awaySet||naSet)
		DBWriteContactSettingWord(NULL,"CList","Status",(WORD)originalStatusMode);
	KillTimer(NULL,hAutoAwayTimer);
	return 0;
}

int LoadAutoAwayModule(void)
{
	HookEvent(ME_OPT_INITIALISE,AutoAwayOptInitialise);
	HookEvent(ME_SYSTEM_SHUTDOWN,AutoAwayShutdown);
	awaySet=0;
	naSet=0;
	mouseStationaryTimer=0;
	originalStatusMode=ID_STATUS_OFFLINE;
	if(IsWinVer2000Plus())
		MyGetLastInputInfo=(BOOL (WINAPI *)(PLASTINPUTINFO))GetProcAddress(GetModuleHandle("user32"),"GetLastInputInfo");
	else MyGetLastInputInfo=NULL;
	hAutoAwayTimer=SetTimer(NULL,0,SETTING_AWAYCHECKTIMEINSECS*1000,AutoAwayTimer);
	return 0;
}
