/*

Miranda IM: the free IM client for Microsoft* Windows*

Copyright 2000-2004 Miranda ICQ/IM project, 
all portions of this codebase are copyrighted to the people 
listed in contributors.txt.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "../../core/commonheaders.h"
#include "newpluginapi.h"

typedef PLUGININFO* (*PLUGIN_APIENTRY_INFO)(DWORD);
typedef int (*PLUGIN_APIENTRY_LOAD)(PLUGINLINK*);
typedef int (*PLUGIN_APIENTRY_UNLOAD)(void);

struct PluginInfo {
	char *filename;
	HINSTANCE hPlugin;
	PLUGININFO *info;
	PLUGIN_APIENTRY_LOAD Load;
	PLUGIN_APIENTRY_UNLOAD Unload;
};

static const char *defaultModuleName[DEFMOD_HIGHEST+1]={
	"",
	"ICQ protocol support",
	"MSN protocol support",
	"Find/Add Contacts functionality",
	"User Info context menu item and dialog",
	"Send/Receive Instant Messages functionality",
	"Send/Receive URLs functionality",
	"Send e-mail functionality",
	"Authorization send and receive functionality",
	"Send/Receive Files functionality",
	"Help menu items",
	"History functionality",
	"Check for Updates menu item",
	"Database importing functionality",
	"Auto-Away capability",
	"User online notifications functionality",
	"Encryption functionality",
	"Sending and receiving of away messages",
	"Ignore options and functionality",
	"Visible/invisible list options page",
	"Contact list window",
	"Plugin options page",
	"Network access routines"};

static struct PluginInfo *plugin;
static int pluginCount;
static PLUGINLINK pluglink;
static int disableDefaultModule[DEFMOD_HIGHEST+1];

static int GetDisableDefaultArray(WPARAM wParam,LPARAM lParam)
{
	return (int)disableDefaultModule;
}

void __inline FreePlugin(struct PluginInfo* pi)
{
    if (pi->hPlugin != NULL) {
        if(pi->hPlugin) FreeLibrary(pi->hPlugin);
        free(pi->filename);
        pi->hPlugin = NULL;
        pi->filename = NULL;
        pi->info = NULL;
    }
}

static BOOL CALLBACK PluginConflictDlgProc(HWND hdlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	static int module;

	switch(message) {
		case WM_INITDIALOG:
		{	char str[128],str2[128];
			LVCOLUMN lvc;
			LVITEM lvi;
			int i;
			int newItem;

			TranslateDialogDefault(hdlg);
			module=lParam;
			GetDlgItemText(hdlg,IDC_FEATURENAME,str,sizeof(str));
			wsprintf(str2,str,Translate(defaultModuleName[module]));
			SetDlgItemText(hdlg,IDC_FEATURENAME,str2);

			ListView_SetExtendedListViewStyleEx(GetDlgItem(hdlg,IDC_PLUGINLIST),LVS_EX_FULLROWSELECT,LVS_EX_FULLROWSELECT);
			lvc.mask=LVCF_WIDTH;
			lvc.cx=100;
			ListView_InsertColumn(GetDlgItem(hdlg,IDC_PLUGINLIST),0,&lvc);
			lvc.cx=150;
			ListView_InsertColumn(GetDlgItem(hdlg,IDC_PLUGINLIST),1,&lvc);
			lvc.cx=150;
			ListView_InsertColumn(GetDlgItem(hdlg,IDC_PLUGINLIST),2,&lvc);

			lvi.iItem=0;
			lvi.mask=LVIF_TEXT;
			lvi.iSubItem=0;
			for(i=0;i<pluginCount;i++) {
				if(plugin[i].hPlugin==NULL) continue;
				if(plugin[i].info->replacesDefaultModule!=module) continue;
				lvi.pszText=plugin[i].filename;
				newItem = ListView_InsertItem(GetDlgItem(hdlg,IDC_PLUGINLIST),&lvi);
				ListView_SetItemText(GetDlgItem(hdlg,IDC_PLUGINLIST),newItem,1,plugin[i].info->shortName);
				ListView_SetItemText(GetDlgItem(hdlg,IDC_PLUGINLIST),newItem,2,plugin[i].info->description);
			}
			ListView_SetItemState(GetDlgItem(hdlg,IDC_PLUGINLIST),0,LVIS_SELECTED,LVIS_SELECTED);
			return TRUE;
		}
		case WM_COMMAND:
			switch(LOWORD(wParam)) {
				LVITEM lvi;
				char filename[MAX_PATH];
				int i;
				
				case IDOK:
					lvi.iItem=ListView_GetNextItem(GetDlgItem(hdlg,IDC_PLUGINLIST),-1,LVNI_SELECTED);
					lvi.mask=LVIF_TEXT;
					lvi.iSubItem=0;
					lvi.pszText=filename;
					lvi.cchTextMax=sizeof(filename);
					ListView_GetItem(GetDlgItem(hdlg,IDC_PLUGINLIST),&lvi);
					//strange fall-through contraption
				case IDCANCEL:
					for(i=0;i<pluginCount;i++) {
						if(plugin[i].hPlugin==NULL) continue;
						if(plugin[i].info->replacesDefaultModule!=module) continue;
						if(LOWORD(wParam)==IDOK && !strcmpi(plugin[i].filename,filename)) continue;
						DBWriteContactSettingByte(NULL,"PluginDisable",plugin[i].filename,1);
                        FreePlugin(&plugin[i]);
                        // caller better not reference element in anyway from now on!
					}
					EndDialog(hdlg,wParam);
					break;
			}
			break;
	}
	return FALSE;
}

struct DISABLE_INFO {
	char **dp;
	int dpCount;
};

int EnumDisabledPlugins(const char *szSetting,LPARAM lParam)
{
	struct DISABLE_INFO *di=(struct DISABLE_INFO*)lParam;

	if (DBGetContactSettingByte(NULL,"PluginDisable",szSetting,0)==0) return 0; /* ignore this if the setting is for enable */

	di->dp=realloc(di->dp,sizeof(char*)*(di->dpCount+1));
	di->dp[di->dpCount++]=_strdup(szSetting);
	return 0;
}

__inline int IsPluginDisabled(struct DISABLE_INFO *di, char *szFileName)
{
	int i;
	for (i=0;i<di->dpCount;i++) {
		if (!strcmpi(szFileName,di->dp[i])) return 1;
	} //for
	return 0;
}

int LoadNewPluginsModuleInfos(void)
{
    #define PLUGIN_SEARCH_STRING  "\\Plugins\\*.dll"
    #define PLUGIN_PATTERN_STRING "%s\\Plugins\\%s"
    #define thisSlot plugin[pluginCount]

    // Windows may only be able to use MAX_PATH, but the string functions expect
    // big enough buffers for worst cases 
	
    int i;
    char szMirandaPath[MAX_PATH], szSearchPath[MAX_PATH+sizeof(PLUGIN_SEARCH_STRING)];
    char szPluginPath[(MAX_PATH*2)+sizeof(PLUGIN_PATTERN_STRING)];
    DWORD mirandaVersion;
    HANDLE hFind; WIN32_FIND_DATA fd;
	DBCONTACTENUMSETTINGS cns;
	struct DISABLE_INFO dpInfo;	

    plugin = NULL;
    pluginCount = 0;

	memset(&dpInfo,0,sizeof(dpInfo));
	cns.pfnEnumProc=EnumDisabledPlugins;
	cns.lParam=(LPARAM)&dpInfo;
	cns.szModule="PluginDisable";
	cns.ofsSettings=0;
	CallService(MS_DB_CONTACT_ENUMSETTINGS,0,(LPARAM)&cns);
	
    mirandaVersion = CallService(MS_SYSTEM_GETVERSION, 0, 0);
    ZeroMemory(disableDefaultModule,sizeof(disableDefaultModule));
    CreateServiceFunction(MS_PLUGINS_GETDISABLEDEFAULTARRAY,GetDisableDefaultArray);

    // get Miranda's full path and strip out anything before the last slash
    {
        char *str2;
        GetModuleFileName(GetModuleHandle(NULL), szMirandaPath, sizeof(szMirandaPath));
        str2=strrchr(szMirandaPath, '\\');
        if (str2 != NULL) *str2 = 0;
    }
    // szSearchPath now has enough space for the strcat() even at the worst case MAX_PATH use
    lstrcpy(szSearchPath, szMirandaPath);
    lstrcat(szSearchPath, PLUGIN_SEARCH_STRING);
    // see what's around, don't create a slot unless it's needed
    if ((hFind = FindFirstFile(szSearchPath, &fd)) != INVALID_HANDLE_VALUE) {
        do {
            HINSTANCE hDll;
            PLUGIN_APIENTRY_INFO MirandaPluginInfo;
            PLUGIN_APIENTRY_LOAD Load;
            PLUGIN_APIENTRY_UNLOAD Unload;
            PLUGININFO *pi;
            // disabled?
			if (IsPluginDisabled(&dpInfo,fd.cFileName)) continue;
            // build path string
            wsprintf(szPluginPath, PLUGIN_PATTERN_STRING, szMirandaPath, fd.cFileName);
            // see if it can be loaded/has the plugin structure
            if ((hDll = LoadLibrary(szPluginPath)) == NULL) continue;
            // MirandaPluginInfo, Load, Unload have to be present
            (void*)MirandaPluginInfo = GetProcAddress(hDll, "MirandaPluginInfo");
            (void*)Load = GetProcAddress(hDll, "Load");
            (void*)Unload = GetProcAddress(hDll, "Unload");
            // superfical check
            if (MirandaPluginInfo==NULL || Load==NULL || Unload==NULL)
            {
                FreeLibrary(hDll); continue;
            }
            pi = MirandaPluginInfo(mirandaVersion);
            // check pi
            if (pi == NULL || pi->cbSize != sizeof(PLUGININFO)) {
                FreeLibrary(hDll); continue;
            }
            // still need to check for pi->replacesDefaultModule range
            // it sort of passed, store it.
            plugin = (struct PluginInfo*) realloc(plugin, (pluginCount+1) * sizeof(struct PluginInfo));
            thisSlot.hPlugin = hDll;
            thisSlot.filename = _strdup(fd.cFileName);
            thisSlot.info = pi;
            thisSlot.Load = Load;
            thisSlot.Unload = Unload;
            pluginCount++;
        } while (FindNextFile(hFind, &fd));
        FindClose(hFind);
    }
    // weed out any conflicts between plugins.
    for (i=0; i<pluginCount; i++)
    {
        int cacheIndex;
        if (plugin[i].hPlugin == NULL || plugin[i].info->replacesDefaultModule == 0) continue;
        // cache the module index, the PLUGININFO pointer will be dead
        // if the plugin is killed, fixes "cancel GPF" bug
        cacheIndex = plugin[i].info->replacesDefaultModule;
        // the conflict dialog may unload all conflicting dlls or keep one loaded
        if (disableDefaultModule[cacheIndex]) 
        {
            if (IDCANCEL == DialogBoxParam(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_PLUGINCONFLICT), NULL, PluginConflictDlgProc, cacheIndex))
            {
                disableDefaultModule[cacheIndex] = 0;
            }
            if (plugin[i].hPlugin == NULL) continue; // may get unloaded
        }
        // mark the module as replaced
        disableDefaultModule[plugin[i].info->replacesDefaultModule] = 1;
    }
	/* free the disable info */		
	for (i=0;i<dpInfo.dpCount;i++) {
		free(dpInfo.dp[i]);
	} //for
	if (dpInfo.dpCount) free(dpInfo.dp);
    return 0;
}

static int NewPluginsShutdown(WPARAM wParam,LPARAM lParam)
{
	int i;
    for (i=0; i<pluginCount; i++)
    {
        if (plugin[i].hPlugin == NULL) continue;
        if (plugin[i].Unload()) plugin[i].hPlugin=NULL;	// this plugin doesn't want to shut down and is expected to have hooked ME_SYSTEM_SHUTDOWN
        FreePlugin(&plugin[i]);
    }
    if (pluginCount) free(plugin);
    return 0;
}

int LoadNewPluginsModule(void)
{
	int i;

	// now just calls Load() for each valid plugin currently loaded
	// the plugin loader has been split into two passes to allow query before run stuff
	// this could also mean the plugins are loaded after all non-overriden internal modules
	// but this would mean plugins would not have access to the internal array
	// to toggle internal module loading at Load() and not returned via PLUGININFO

    HookEvent(ME_SYSTEM_SHUTDOWN, NewPluginsShutdown);

    // copy of the global version
	pluglink.CallService=CallService;
	pluglink.CreateHookableEvent=CreateHookableEvent;
	pluglink.CreateServiceFunction=CreateServiceFunction;
	pluglink.CreateTransientServiceFunction=CreateServiceFunction;	  //fixme
	pluglink.DestroyHookableEvent=DestroyHookableEvent;
	pluglink.DestroyServiceFunction=DestroyServiceFunction;
	pluglink.HookEvent=HookEvent;
	pluglink.HookEventMessage=HookEventMessage;
	pluglink.NotifyEventHooks=NotifyEventHooks;
	pluglink.UnhookEvent=UnhookEvent;
	pluglink.ServiceExists=ServiceExists;
	pluglink.CallServiceSync=CallServiceSync;
    
    for (i=0; i<pluginCount; i++)
    {   
        if (plugin[i].hPlugin == NULL) continue;
		if (plugin[i].Load(&pluglink))
        {
            FreePlugin(&plugin[i]);
        }
    }   
    return 0;
}