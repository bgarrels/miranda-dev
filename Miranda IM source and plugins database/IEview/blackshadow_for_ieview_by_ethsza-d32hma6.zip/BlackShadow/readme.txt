BlackShadow IEView skin is made by szekelya
and is a mod of Mirage by Shadow-13
(see: http://addons.miranda-im.org/details.php?action=viewfile&id=3745)

The skin is for IEView, for the windowframe and the transparency settings please use a TABSRMM skin of your choice. The screenshot on the download page shows a slightly modded (darkened) BlackBox skin.