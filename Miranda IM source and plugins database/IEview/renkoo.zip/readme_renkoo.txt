/--------------------------------------------------------------
|
| Renkoo 'Naked' (Port) by bonebox
|
|    - jeremy@bonebox.org (E-Mail)
|
| Original Renkoo theme for AdiumX by Torrey Rice - http://itorrey.com/
|   
|  - Available for download here - http://www.adiumxtras.com/index.php?a=xtras&xtra_id=2160
|
|
|       NOTE: WHEN UPDATING, replace all files with ones included in archive
|	
|	IN YOUR IEVIEW SETTINGS BE SURE AND CHECK: "Show nicknames", "Show time" (leave "Show seconds" unchecked), and "Show date"
|
\--------------------------------------------------------------
 |
 | Install instructions borrowed and modified from Russellc
 |
 |  How do I install this? (assuming you have IEView set up properly)
 |    1) Extract the files using 7zip, Winrar, or XP's built in ZIP support
 |       (anything that can extract .ZIPs properly will do) to any folder
 |        > It is -recommended- to extract in the Miranda folder.
 |    2) Go to the IEView options and go to the Templates tab.
 |    3) Browse (...) for the folder Renkoo\ that you should have remembered
 |       and double click one of the *.ivt files (in Renkoo\ folder).
 |    4) Hit Apply and start chatting!
 |
 |  Variations? A lot!
 |    - renkoo_Color1Color2.ivt            - The basic setup
 |    - renkoo_Color1Color2_topbar.ivt     - Same as basic but with a topbar
 |    - renkoo_Color1Color2_alt.ivt        - Alternating chat bubbles, no topbar
 |    - renkoo_Color1Color2_topbar_alt.ivt - Alternating chat bubbles with a topbar
 |
 |    * Color1 is the color of the incoming chat bubble, and Color2 is the color of the outgoing chat bubble.
 |
 |  Stuff you'll want to know:
 |    -  What colour schemes of Renkoo are available to me?
 |        > Blue+Red, Blue+Steel, Green+Red, Green+Steel, Green+Yellow, Red+Steel, Red+Yellow, and reverse, where first color
 |          represents incoming chat bubble, and 2nd color represents outgoing chat bubble
 |        > All variations will be under the Renkoo\ folder and have filenames that begin with "renkoo_".
 |
 |
 |    -  Why isn't my buddy's avatar showing up?
 |        > You need the latest version of IEView and
 |          TabSRMM (http://tabsrmm.sf.net)
 |
 |
 |    -  Does message grouping work?
 |        > Yup! Just enable it in Miranda IM Options -> IEView plugin -> Templates tab
 |    
 |    -  Thanks to:
 |        > russellc for providing his javascript code when attempting to implement the fade in capability,
 |          which I didn't end up including due to it not working properly from limitations with IEView
 |
 | 
 |
 |   June 26, 2006 (v1.0)
 |   -  First release done
 |   -  Permission granted from Torrey Rice (thanks!)
 |
 | 
 |  Wishlist:
 |   -  True png transparency for custom background support
 |   -  Fade in capability 
 |     (these won't be possible until IEView is updated to support them)
 |
 |
 |
 \-------------------------------------------------------------