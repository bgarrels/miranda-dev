// ------
// Message Grouping Script
// Thanks to cpm for this Javascript!
// ------

// Appends text via a hidden <div></div>
function appendGroupMsg() {
   theMsg=document.getElementById("message_current");
   newMsg=document.getElementById("msg_new_grouped");

   if (theMsg && newMsg) {
      theMsg.innerHTML+=newMsg.innerHTML;
      // no need to have the info in the log twice (it`s hell on copy and paste)
      newMsg.innerHTML="";
      // we don't want to confuse this w/ the next message.
      newMsg.id="";
   }
}
// this groupped message is done, we don't want to confuse it w/ the next group
function endGroupMsg() {
   theMsg=document.getElementById("message_current");

   if (theMsg) {
      theMsg.id="message_history";
   }
}

function getavatar(avatar){
	if( avatar.indexOf('.swf',0)!=-1)
	{
		document.write('<object width="48" height="60" style="border:1px solid #B5B5B5;" name="movie" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"  class="headeravaflash">'
		+ '<param name=movie value=' + avatar + '>'
		+ '<param name=quality value=high>'
		+ '<embed src=' + avatar + ' quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" class="headeravaflash">'
		+ '</embed></object>');

	}
	else
	{
		document.write('<img src="' + avatar + '" style="border:1px solid #B5B5B5;" height="64" />');
	}
}

function getavatarsmall(avatar){
	if( avatar.indexOf('.swf',0)!=-1)
	{
		document.write('<object width="38" height="48" style="border:1px solid #B5B5B5;" name="movie" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"  class="headeravaflash">'
		+ '<param name=movie value=' + avatar + '>'
		+ '<param name=quality value=high>'
		+ '<embed src=' + avatar + ' quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" class="headeravaflash">'
		+ '</embed></object>');

	}
	else
	{
		document.write('<img src="' + avatar + '" style="border:1px solid #B5B5B5;" height="48" />');
	}
}