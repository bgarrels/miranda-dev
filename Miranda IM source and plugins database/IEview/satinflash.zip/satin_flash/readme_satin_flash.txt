Satin Mod by Mantis (icq 138583700)

This is a mod of Satin Port by russellc with support for Flash Avatars with IEView v.1.0.9.5.
Also I changed avatars handling to fixed or original size. 
NOTE! This Mod is adjusted for large screen resolutions because I care about my eyesight and use large fonts :)

Frequently Asked Questions:
-  How do I install this? (assuming you have IEView set up properly)
     1) Extract the files (anything that can extract .ZIPs properly will do) to any folder 
     		(It is -recommended- to extract in the Miranda folder.)
     2) Go to the IEView options and go to the Templates tab.
     3) Browse (...) for the folder Satin_flash\ that you should have remembered
        and double click the satin*.ivt file (in Satin\ folder).
     4) Hit Apply and start chatting!

-  What variations of Satin are available to me?
        > satin.ivt - This is the original one. Only shows time for new
                      grouped messages, the word "Me" for your messages and your contact's Protocol name in
                      the creation of a new message group. Avatars are of fixed height = 48px.
        > satin_avatarsright.ivt - Same as original, except the avatar position
                                   is moved to the right side of all messages.
        > satin_bigavatars.ivt - Same as original, but shows avatars with
                                 their original dimensions. (Also I recommend not using 
                                 large contact pictures more then 64 in any dimension.
        > satin_bigavatarsright.ivt - Same as satin_bigavatars.ivt except shows avatars to the right.
        > satin_noavatars.ivt - Same as original, but does not display an 
                                avatar box, so it will allow more room for
                                the message to expand into.
        > satin_cid.ivt - Same as original, but shows the word "Me" for your messages and your contact's ID
        									in the creation of a new message group.
        > satin_timedate.ivt - Same as original, but shows time and date
        											in the creation of a new message group.
        > satin_timedate.ivt - NEW! Same as original, but shows the date only
        											in the creation of a new message group.

-  Why isn't my avatar showing up?
         > You need to set your avatar in ICQ protocol. Original Satin used a "myavatar.jpg" picture in \Satin\ folder,
 						but I think it is urgly, so I changed it to %avatarOut% variable.
 						Msn avatars are not supported. Other protocols are not tested.
 
-  Why isn't my buddy's avatar showing up?
        > I stronly recommend updating your IEView and
          TabSRMM or Scriver to the latest version. Also please read the instructions for flash avatars below.
 
-  Is this the only colour scheme?
         > Nope! There are 3 other colour schemes. The default
           template is Green-Blue-Orange. There are the following scheme:
             = Green-Blue-Purple   (greenbluepurple.css)
             = Red-Blue-Purple     (redbluepurple.css)
             = Green-Blue-Orange   (greenblueorange.css)
             = Green-Red-Orange (greenredorange.css) (c) Mike Stalker
 
         > To change schemes:
             1) Open the file satin.ivt in Notepad
             2) Pick the scheme you want to change to
                 ex. Red-Blue-Purple (redbluepurple.css)
             3) Return to satin.ivt in Notepad and take the text in
                parenthesis (brackets) and paste it into the line
                near the top that, by default, says greenblueorange.css
                 ex. <link rel="stylesheet" type="text/css" href="greenblueorange.css" />
                                      - BECOMES -
                     <link rel="stylesheet" type="text/css" href="redbluepurple.css" /> 
             4) Save satin.ivt and close Notepad
             5) Open Miranda IM Options and navigate:
                 Message Sessions -> IEView plugin -> Templates
             6) Click on the Browse (...) button and rechoose satin.ivt
             7) Hit Apply
             8) Close all conversation windows and reopen them
             9) The scheme should now be changed =)

- How do I enable Flash avatars?
 			1) Required Plugins:
 			FlashAvatars.dll (Flash avatars service) - http://addons.miranda-im.org/details.php?action=viewfile&id=2743
 			IEView >= 1.0.9.5 - http://developer.berlios.de/project/showfiles.php?group_id=3292&release_id=11098
 			TabSRMM or Scriver.
			2)Put flash.ocx (Macromedia Flash 7) ��� flash9.ocx (Macromedia Flash 9) into  %windir%\system32\Macromed\Flash\ and 						register it (Start -> Run -> regsvr32 %windir%\system32\Macromed\Flash\file_name.ocx) or just install latest Macromedia 				Flash Player. (p.s. Macromedia Flash Player 8 is not recommended). Some flash avatars require Macromedia Shockwave Player 			installed.
			2) Plugins Settings (optional):
			for tabSRMsg: in Options - Message Sessions - Message Window - General turn "Show contact avatars" to "Globally On". Avatar 			will be displayed in right lower or upper (if info panel is turned on) corner.

- The fonts are too large!
		 Copy main.css file from small_fonts folder to the main one (overwrite main.css in it). Done!



Below is a part of Readme from original Satin

/--------------------------------------------------------------
|
| Satin (Port) by Russellc (http://chunk.3rror.com)
|    - thechunkster2k3 (AOLIM)
|    - i_use@email.com (MSN)
|    - thechunk@gmail.com (E-Mail)
|
| Original Satin by Yojimbo (AIM - yojimbo311) - http://www.adiumxtras.com/index.php?a=users&do=profile&user_id=230
|    - Original template URL - http://www.adiumxtras.com/index.php?a=xtras&xtra_id=305
|
|
|       -Thanks to Yojimbo for a great original template!-
|
|       NOTE: WHEN UPDATING, replace all files with ones included in archive
|
|
\--------------------------------------------------------------
