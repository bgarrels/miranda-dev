#ifndef _FILTER_INC
#define _FILTER_INC

void RegisterFilter();
void AddFilterToContacts();
void CreateFilterServices();
void DeinitFilter();

#endif
