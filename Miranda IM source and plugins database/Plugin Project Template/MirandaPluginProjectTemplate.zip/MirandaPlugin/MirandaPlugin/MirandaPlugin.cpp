/* Replace "dll.h" with the name of your header */
#include "common.h"
#include "version.h"
#include "resource.h"
#include "options.h"
#include "filter.h"
#include "net.h"
#include "menu.h"

///////////////////////////////////////////////
// Common Plugin Stuff
///////////////////////////////////////////////
HINSTANCE hInst;
PLUGINLINK *pluginLink;

PLUGININFOEX pluginInfo={
	sizeof(PLUGININFOEX),
	__PLUGIN_NAME,
	PLUGIN_MAKE_VERSION(__MAJOR_VERSION, __MINOR_VERSION, __RELEASE_NUM, __BUILD_NUM),
	__DESC,
	__AUTHOR,
	__AUTHOREMAIL,
	__COPYRIGHT,
	__AUTHORWEB,
	0,
	0,
	{ 0x524C0ABB, 0x18B5, 0x48D6, { 0xA4, 0xC1, 0xF6, 0x38, 0x25, 0x1A, 0x5F, 0x43 } }	
};


extern "C" BOOL APIENTRY DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved) {
	hInst=hinstDLL;
	return TRUE;
}

extern "C" __declspec (dllexport) PLUGININFOEX* MirandaPluginInfoEx(DWORD mirandaVersion) {
	return &pluginInfo;
}


/*
// uncomment this for pre 0.7 compatibility
extern "C" __declspec (dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion) {
	pluginInfo.cbSize = sizeof(PLUGININFO);
	return (PLUGININFO*)&pluginInfo;
}
*/

// TODO: add any interfaces you implement to this list
static const MUUID interfaces[] = {MIID_MIRANDAPLUGIN, MIID_LAST};
extern "C" __declspec(dllexport) const MUUID* MirandaPluginInterfaces(void)
{
	return interfaces;
}

int ModulesLoaded(WPARAM wParam, LPARAM lParam) {
	InitNetlib();
	InitMenu();

	return 0;
}

HANDLE hModulesLoaded;
extern "C" __declspec (dllexport) int Load(PLUGINLINK *link) {
	pluginLink=link;

	InitOptions();

	/////////////
	////// init filter
	RegisterFilter();
	CreateFilterServices();
	AddFilterToContacts();	

	// hook modules loaded
	hModulesLoaded = HookEvent(ME_SYSTEM_MODULESLOADED, ModulesLoaded);
	return 0;
}

extern "C" __declspec (dllexport) int Unload(void) {
	UnhookEvent(hModulesLoaded);
	DeinitMenu();
	DeinitNetlib();
	DeinitFilter();
	DeinitOptions();

	return 0;
}
