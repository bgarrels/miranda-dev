#ifndef _NET_INC
#define _NET_INC

// uncomment this if you need access elsewhere
//extern HANDLE hNetlibUser;

void InitNetlib();
void DeinitNetlib();

#endif