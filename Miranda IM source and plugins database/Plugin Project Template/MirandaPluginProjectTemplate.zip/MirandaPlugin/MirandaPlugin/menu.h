#ifndef _MENU_INC
#define _MENU_INC

void InitMenu();
void DeinitMenu();

#endif
