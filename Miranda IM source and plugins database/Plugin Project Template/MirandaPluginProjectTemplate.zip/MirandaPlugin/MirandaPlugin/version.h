// Set the version number here - it will affect the version resource and the version field of the pluginInfo structure
// (Be careful that you don't have the resource file open when you change this and rebuild, otherwise the changes may not 
// take effect within the version resource)

#define __MAJOR_VERSION				0
#define __MINOR_VERSION				0
#define __RELEASE_NUM				0
#define __BUILD_NUM					1

#define __FILEVERSION_STRING        __MAJOR_VERSION,__MINOR_VERSION,__RELEASE_NUM,__BUILD_NUM
#define __FILEVERSION_STRING_DOTS	__MAJOR_VERSION.__MINOR_VERSION.__RELEASE_NUM.__BUILD_NUM
#define __STRINGIFY(x)				#x
#define __VERSION_STRING			__STRINGIFY(__FILEVERSION_STRING_DOTS)

#ifdef _UNICODE
#define __PLUGIN_NAME				"MirandaPlugin (Unicode)"
#else
#define __PLUGIN_NAME				"MirandaPlugin"
#endif
#define __FILENAME					"MirandaPlugin.dll"

#define __DESC						"Opis twojej wtyczki"
#define __AUTHOR					"Nick"
#define __AUTHOREMAIL				"tw�j@email.pl"
#define __AUTHORWEB					"http://www.TwojaStrona.pl"
#define __COPYRIGHT					"� 2011-2011 Tw�jNick"
