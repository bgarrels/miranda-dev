#include "common.h"
#include "options.h"
#include "resource.h"

Options options;

void LoadOptions() {
	//options.dummy = DBGetContactSettingDword(0, MODULE, "Dummy", 0);
}

void SaveOptions() {
	//DBWriteContactSettingDword(0, MODULE, "Dummy", options.dummy);
}

BOOL CALLBACK DlgProcOpts(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam) {
	static HANDLE hItemAll;

	switch ( msg ) {
	case WM_INITDIALOG:
		TranslateDialogDefault( hwndDlg );
		return FALSE;		
	case WM_COMMAND:
		break;
	case WM_NOTIFY:
		switch(((LPNMHDR)lParam)->idFrom) {
			case 0:
				switch (((LPNMHDR)lParam)->code)
				{
					case PSN_APPLY:
						SaveOptions();
				}
				break;
		}
		break;
	}

	return 0;
}

int OptInit(WPARAM wParam, LPARAM lParam) {
	OPTIONSDIALOGPAGE odp = { 0 };
	odp.cbSize						= sizeof(odp);
	odp.flags						= ODPF_BOLDGROUPS;
	odp.flags |= ODPF_TCHAR;
	odp.position					= -790000000;
	odp.hInstance					= hInst;

	odp.pszTemplate					= MAKEINTRESOURCEA(IDD_OPT1);
	odp.ptszTitle					= TranslateT(MODULE);
	odp.ptszGroup					= TranslateT("Services");
	odp.nIDBottomSimpleControl		= 0;
	odp.pfnDlgProc					= DlgProcOpts;
	CallService( MS_OPT_ADDPAGE, wParam,( LPARAM )&odp );

	return 0;
}

HANDLE hEventOptInit;
void InitOptions() {
	hEventOptInit = HookEvent(ME_OPT_INITIALISE, OptInit);
	LoadOptions();
}

void DeinitOptions() {
	UnhookEvent(hEventOptInit);
}
