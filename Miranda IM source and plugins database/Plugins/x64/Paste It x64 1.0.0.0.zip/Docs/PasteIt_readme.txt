********
Paste It
********

Description
===========
Plugin uploads the text to web page and sends the URL to your friend.

Main features
=============
- pastebin.com and wklej.to support
- paste text from clipboard
- paste file from clipboard
- choosing file using file dialog
- ability to set correct file encoding

!!! Requirements !!!
====================
Microsoft Visual C++ 2010 Redistributable Package

Author
======
Krzysztof Kral

email:  programista@poczta.of.pl
www:    http://programista.free.of.pl/miranda/
svn:    http://svn3.xp-dev.com/svn/PasteIt/
