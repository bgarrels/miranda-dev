Status Message Retriever plugin
-------------------------------

This is a plugin that retrieves status messages based on timer and on status change. It is made for protocols that store the status message at the client, like ICQ does.

Please, do not enable this for MSN nor Jabber, because it can cause bad side effects (these protocols handle status message internally and smr can break things).

To report bugs/make suggestions, go to the forum thread: http://forums.miranda-im.org/showthread.php?t=7560
