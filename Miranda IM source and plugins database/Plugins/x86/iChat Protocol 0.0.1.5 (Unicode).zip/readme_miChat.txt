iChat Protocol Plugin for Miranda IM
=====================================

Installation:
  Copy ichat.dll to Miranda's plugins directory.
  
  You need to have Rendezvous installed as well, funnily enough.
  
  http://developer.apple.com/macosx/rendezvous/RendezvousSetup.exe


More information:
  Web: http://xurble.org/projects/miranda-ichat
  E-mail: g@xurble.org

Copyright (c) 2005 Gareth Simpson (g@xurble.org)

This plugin is based on the marvelous jabber plugin:

Copyright (c) 2005 George Hazan (ghazan@postman.ru)
Copyright (c) 2002-2004 Santithorn Bunchua (keh@au.edu)


================================================================

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

================================================================
