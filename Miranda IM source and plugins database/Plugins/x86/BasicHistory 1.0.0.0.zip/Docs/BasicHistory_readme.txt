********
Basic History
********

Description
===========
History viewer for Miranda IM.

Main features
=============
- display history in RichEdit
- grouping events
- searching

!!! Requirements !!!
====================
Microsoft Visual C++ 2010 Redistributable Package

Changelog
=========

--- 1.0.0.0 ---
+ initial release

Author
======
Krzysztof Kral

email:  programista@poczta.of.pl
www:    http://programista.free.of.pl/miranda/
svn:    http://xp-dev.com/svn/BasicHistory/
