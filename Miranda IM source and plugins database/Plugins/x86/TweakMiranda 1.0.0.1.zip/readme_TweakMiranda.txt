TweakMiranda plugin, v.1.0.0.1
   by Luca "Hrk" Santarelli
   hrk@users.sf.net

- LATEST CHANGE -

1.0.0.1 Fix: message timeout was saved wrongly.
	New: option to check if system tray notification is enabled. (new
	langpack string)


- REQUIREMENTS -
Miranda 0.3
(optional) Path plugin v.1.0.0.0+


- KNOWN BUGs -

There are NO known bugs. So if you experience one, o a good bug report.
Go here and read what is a good bug report and what is a bad bug report. :)
http://www.chiark.greenend.org.uk/~sgtatham/bugs.html


- INFORMATIONS (you can skip this, but you can read it too!) -

Hi :-)

This plugin lets you customize some internal settings in Miranda.
It is for experts only... but messing with the settings should not cause you any harm.
See the Plugins\tweak.txt for a detailed explaination of every setting.


- ROADMAP - (or: gee, what's next?)

Nothing, only bugfixes (there shouldn't be bug, but you never can tell...)


- TRANSLATION -

The strings you can translate are in a separate file.


- CHANGES -

1.0.0.1 Fix: message timeout was saved wrongly.
	New: option to check if system tray notification is enabled.

1.0.0.0 First release.


- DISCLAIMER -

This plugin works just fine on my machine, it should work just fine on yours
withouth conflicting with other plugins. Should you have any trouble, write me
at hrk@users.sf.net
Anyway, if you are a smart programmer, give a look at the code and tell me
the changes you'd make. If I like them, I'll put them inside giving you the
right credit! :-)

This plugin is released under the GPL license, you can find it in Miranda IM.
Being GPLed you are free to modify or change the source code (which I usually
upload to the file listing), you are free to sell it too, but you must provide
the same freedom to other people.

As I already wrote: if you do modify it, notify me, I don't see a good reason
not to share the improvements with the Miranda community. :-)