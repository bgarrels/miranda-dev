ShowUIN is a small plugin for Miranda Instant Messenger.

It does almost nothing - just adds one item to the contact right-click menu.
This item contains contact's UIN and click on this item will copy UIN to
clipboard.
Since version 2.1.0.0 plugin is configureable, so you can change format of
menu item caption and copy-to-clipboard text using some macroses - such as
%uin% or %nick%.
Since version 3 plugin works for any protocol (MSN, Jabber, etc).

Actually that's all.
Have fun!

Copyright (c) 2005-2006 Dead Adriano
