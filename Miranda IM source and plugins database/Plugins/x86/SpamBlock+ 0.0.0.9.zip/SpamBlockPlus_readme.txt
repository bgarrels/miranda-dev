About
-----

SpamBlock+ Plugin
Version 0.0.0.9
by Felipe Santos Andrade
     from a modified version of Daniel Walter
     original SpamBlock plugin by Roland Rabien

for Miranda IM 0.3.0+
written with Microsoft Visual C++ 6.0


Description
-----------

Blocks Spam


Features
--------

+ Blocks incomming spam messages and URLS
+ List of bad word is extendable by textfile
+ Changes of list possible without restart of Miranda
+ Options to select behavior of plugin

License
-------

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


For more information, e-mail lipe@brturbo.com


Changes
-------

0.0.0.9
Fixed some strange crashs in options (i think..)
Code optiomization. Now plugin dont try to reload the filter in all messages.

0.0.0.8
Updated to use with new headers, and few new options too

0.0.0.7
Memory freed on unload

0.0.0.6
Possible overflow fixed
Constants introduced

0.0.0.5
Bug when words are removed has been fixed

0.0.0.4
Is now in options under the plugins branch

0.0.0.3
Code cleanup

0.0.0.2
Fixed memory usage

0.0.0.1
Initial Version