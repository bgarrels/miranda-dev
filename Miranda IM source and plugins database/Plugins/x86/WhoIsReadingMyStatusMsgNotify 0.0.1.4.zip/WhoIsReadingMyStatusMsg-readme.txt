WhoIsReadingMyStatusMsgNotify plugin
by Angelo Luiz Tartari

===========
NO WARRANTY
===========

This plugin is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. Should the program prove defective, you assume the cost of all necessary servicing, repair or correction.

===========
DESCRIPTION
===========

This plugin notifies you when someone is reading your ICQ status message.

========
FEATURES
========

- Show an alert (popup) when someone is reading your status message. 
- Log to a file who read your status message.
- Play a sound when someone is reading your status message.
- XStatus (Xtraz) supported.

====================
MINIMUM REQUIREMENTS
====================

This plugin requires:

- Miranda IM version 0.3 alpha nightly build Feb 19 2003 or above.

- PopUp plugin or similar, if you want to be notified via popups.

- ICQ protocol plugin.

Download them at http://miranda-im.org/

==============
HOW TO INSTALL
==============

1) Close Miranda IM.
2) Find Miranda's main folder (search for miranda32.exe).
3) Put WhoIsReadingMyStatusMsg.dll into plugin's folder.
4) Start Miranda IM.

See also: http://help.miranda-im.org/Installing_a_plugin

================
HOW TO UNINSTALL
================

Remove WhoIsReadingMyStatusMsg.dll from plugin's folder.

================
HOW TO CONFIGURE
================

- Go to Options/Events/Sounds to configure WhoIsReading sound.
- Go to Options/Plugins/WhoisReading to configure log options and other stuff.
- Go to Options/Popups/WhoisReading to configure popups.

==========
HOW TO USE
==========

- When someone tries to read your status message, a popup appears on your screen.

=======
SUPPORT
=======

You understand that you use the WhoIsReadingMyStatusMsgNotify plugin at your own risk and that any assistance or support for your use of the WhoIsReadingMyStatusMsgNotify plugin is provided to you only as a convenience.

===================
ALPHA/BETA VERSIONS
===================

Alpha and beta versions are for testing purposes.
They are NOT recommended for daily usage.

You will find them at http://www.volumna.com.br/pessoal/angelo/

======
AUTHOR
======

Name: Angelo Luiz Tartari

Email : corsario-br@users.sourceforge.net

You can send me messages in portuguese, english or italian.
Please read the faq file.

======
THANKS
======

- micron-x