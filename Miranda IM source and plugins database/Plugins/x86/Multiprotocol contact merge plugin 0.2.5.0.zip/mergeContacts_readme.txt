Multiprotocol contact merge plugin
----------------------------------
Lets you bundle multiple contacts from different protocols under one
main contact.
- No new protocol
- Contacts, contact list and history stay unmodified
- Easy to use
- Small, fast and powerfull
- Drag and drop your contacts into a clearly arranged contact
hierarchy
- Support for the "IcoLib.dll" plugin (icon skining)
- Option to dynamically switch the main contact
- Option to forward all received messages to the main contact
- Sub contacts can be priorized by manual ordering or by online
status
- Access your sub contacts easily using the contact menu and a
special sub contact dialog which behaves like the contactlist
- Your contact list stays intact if you deactivate the plugin (no
changes are made)
- Easily identify your merged contacts by using different icons or a
postfix for them
- Support for ICQ, MSN, AIM, Yahoo, Jabber, Tlen, GG, IRC and much
more (should support every protocol available, if not contact me)
- Set one contact as a main contact and add sub contacts to it
- Swap main/sub contacts with one click
- Optionally set the main contacts message window to open by default
after a doubleclick on it
- Merge contacts of different protocols
- Sub contacts are hidden from the list
- View sub contact status by selecting the appropriate the menu entry
of the main contact
- All events are redirected to the main contact
- The main contact displays the best (e.g. Online is better than
Away) status of the contacts it represents
- Selecting a pending event automatically pops up the appropriate sub
contact
- You can select which sub/main contact of a merged contact group you
want to conversate with
- The status of all the sub contacts as well as the main contacts
real status are easily seen by double clicking on the main contact
- Uses skinned protocol icons
- Translate langpack support

Installation
------------
Copy the "mergeContacts.dll" into your miranda\plugins directory. You
can then merge your contacts using the "Merge Contacts"->"Hierarchy"
entry in the Miranda options.

Merge two or more contacts
--------------------------
Open the Miranda options and look for the section "Merge Contacts"-
>"Hierarchy". There you can drag & drop a contact from the contact
list. If you want this contact to be a main contact drop it into the
empty area and if you want it to be a sub contact drop it on the
appropriate existing contacts in the hierarchy. To remove a contact
either select it and press the delete key or use the "Remove contact"
button.

ATTENTION
---------
I'm not responsible for any damage caused by this plugin, use it at
your own risk! If you encounter a crash or a false behavior please
send me a detailed report on how I can reproduce the bug and I'll try
to fix it.

Changelog
---------

0.2.5.0
-------
- Fixed "Prefer main contact" option

0.2.4.0
-------
- Fixed bug where contacts couldn't go offline
- Reverted a 0.2.3.0 change

0.2.3.0
-------
- Changed contact hide behaviour (experimental)

0.2.2.0
-------
- Added main contact preference option by popular request
- Fixed crash bug (results in wrong status display when changing main
contact sometimes)
- Fixed icon changing
- MergeContacts should now be supported by Updater

0.2.1.2
-------
- Fixed a hierarchy bug

0.2.1.1
-------
- Fixed a crash bug in hierarchy initialisation

0.2.1
-----
- Fixed a bug where message notifications had to be clicked multiple
times to disappear
- Fixed receiving filetransfers and other events from sub contacts
- Calculating the best status now takes the contact order in account 
(this only applies to the "Dynamically change main contact" option)
- Fixed the display of the postfix option in the options dialog

0.2.0
-----
- Added option to forward all received messages to the main contact
- Added new postfix option
- Removed "Sub contacts:" menu item

0.1.8
-----
- Added option to dynamically switch the main contact
- Fixed status display bug
- Fixed event notify not working for some users
- Implemented sorting of sub contacts for the autopopup of next best
contact
- Added new icons for merged contacts (thanks to d1gg3r for this)

0.1.7
-----
- Fixed the context menus in the "Merged Contact" dialog
- Fixed possible crashbug on exit

0.1.6
-----
- Reverted some changes to avoid the requirement for msvcrt dlls

0.1.5
-----
- Fixed status display bug when receiving messages from a sub contact
while the main contact is offline

0.1.4
-----
- Changing protocol icon skins now apply immediately
- Main contact now updates status when adding/removing sub contacts
- Fixed support for WinPopup protocol
- Fixed wrong status display for main contact after swapping with a
sub contact and then removing it
- Improved performance
- Increased maximum contact name length
- Fixed another drag&drop bug
- Fixed some unfreed memory on exit

0.1.2
-----
- Different icon and postfix settings will apply immediately
- Fixed a bug in the hierarchy where a contact draged into the
options window will be changed to the topmost groud of the contact
list
- Added a delay option to the different icon setting. If you have a
slow computer or many plugins a short delay can cause the different
icon setting to fail.
- Contacts can now be deleted from the hierarchy using the delete
button
- Refactored the code

0.1.1
-----
- Fixed drag'n'drop
- Fixed crash in "Merged Contact" dialog
- Fixed alternative icons
- Fixed status display bug
- Added support for IcoLib.dll icon skining

0.1.0
-----
- Named the contact menu items so mw clist users can reorder them
- Added file dropping support for the subcontacts dialog (contact
menu->"Show all sub contacts")
- Added contact menus to subcontacts dialog
- The "Show all sub contacts" menu item should now be displayed for
all merged contacts
- Fixed alternative icons for mw clist
- Fixed drag&drop problem for mw clist (see the new checkbox under
"Merge Contacts"->"Hierarchy"
- Fixed subcontacts disappearing when sorting by hierarchy order
- Whitespaces after the name will now be removed on exit
- Reloading icons on skin change

0.0.8
-----
- Improved contact menu
- Implemented contact ordering
  -> User can now chose if the contacts in the contact menu should be
     sorted by status or by custom order
- Drag & Drop now works inside the hierarchy as well
- Simplified option tabs
- Split preferences dialogs into contact merging and settings
- Added new options for better identification of merged contacts
  -> Add the number of sub contacts in square brackets as postfix
  -> Use a different icon for merged contacts (experimental)
- Minor fixes

0.0.6
-----
- Improved user interface/ease of use
- Improved drag & drop support for the options dialog (drop contacts
directly into the hierarchy)
- Added best two subcontacts to the contact menu
- Fixed a bug where hidden contacts were shown
- Delayed protocol information fetching to wait for all protocols to
load
  -> Fixes the bug where some protocols weren't supported properly

0.0.4
-----
- Implemeted a more general protocol support
- Added option to automatically open the window of the next online
sub contact
- Newly added contacts get selected and the contact tree expanded
- Main/sub contact can now be swaped
  -> the default contact can be changed)
  -> filetransfers can now be initiated to all contacts

0.0.2
-----
- Added auto popup option
- Added "Show sub contacts" to contact menu
- Added support for Jabber, Tlen and GG protocols

0.0.1
-----
- Initial public release