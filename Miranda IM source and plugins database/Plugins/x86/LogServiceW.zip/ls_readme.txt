LogService plugin for Miranda IM.
(c) Chervov Dmitry aka Deathdemon.

This is a service plugin that allows other plugins to log to files easily. It takes care of "unicodeness" of log files, allows to limit log size, change log file name and also it supports Folders plugin.

Additional features include support of Variables plugin. With its help it's possible to customize log format according to your preferences, and also it's possible to log to different files and even folders depending on some conditions (for example, different files for each date or for each protocol). If the specified folder doesn't exist yet, LogService creates it automatically.

As an example, New Away System plugin uses the following log file name by default:
  NewAwaySys?puts(p,?dbsetting(%subject%,Protocol,p))?if2(_?dbsetting(,?get(p),?pinfo(?get(p),uidsetting)),).log
When Variables plugin is not installed, LogService will simply remove all variables from the path, so the resulting file name is "NewAwaySys.log". When Variables plugin is installed, the variables in this string will return your ID on current protocol, so, if you use several UINs, you'll get several "NewAwaySys_<Your UIN>.log" files in your Logs folder. Of course, even with Variables plugin installed, you can simply write "NewAwaySys.log" into the path field of NAS' log options, if you want to remove UIN from the log file name.


Changelog
=========

v0.1.0.1 (build 108; Nov 14, 2007)
--------
 - fix for a bug with 10 MB log size limit (this could also cause high CPU usage when logging intensively to a large log file)

v0.1.0.0 (build 107; Sep 18, 2007)
--------
 - First public release.