About
-----
New "Notes & Reminders" Plugin
Version 0.0.4.5
by Joe @ Whale (Joe Kucera) jokusoftware@gmail.com
Originally by d00mEr (Lubomir Ivanov) d00mEr@dir.bg
for Miranda ICQ 0.1.2.1+
written with Visual C++ 6.0

Description
-----------
This plugin allows user to create Sticky Notes, to
store some important data in a well visible place :)
New features allow to create reminders. This is a
note that will show up on specified date and time.
The notes are completely customizable.

Features
--------
+ Sticky Notes (each Note is limited to 16000 chars)
+ Reminders (each Reminder Text is limited to 16000 chars)
+ Allow change of fonts and colors
+ Allow seting default size for Notes
+ Notes stay always at the top of all windows (or free)
  specified by option
+ Show and Hide all notes
+ Show or Hide notes at startup.
+ Hot Keys for New Note, New Reminder, and Show/Hide notes
+ Manage Reminder list.
+ Quick delete all notes and/or reminders
+ Transparent Notes
+ Language translations (see langpack_N&R.txt for details)
+ Custom Sound to play On Reminder
+ Font Colors
+ Reminder notification via E-mail or SMS.

To Do:
------
- Icons for : Fix/Move the note
- Set font/color for each note individually (or even of any word - so that I could
  highlight something from the note)
- changing caption of each note (date & time is not at all good)
- "best fit" feature - by pressing one button I would adjust the size of the note automatically
- double clicking a note's title-bar scrolls up the note (to be just the title bar).
- Edit Reminders
- import/exort of all notes/alarms
- Reminder (daily, weekly or monthly) without a specified time? i.e. when you start miranda...
- Trigger on event (remind me when is user online)
- Unicode support (Use Japanese texts was garbled)
- Easier way to delete notes (like Ctrl-D or ctrl-shift-d)
- "Quick Reminding" - Something like an extra box in the reminder window
  so we can choose to be reminded "30 minutes" later

Installation
------------
Just copy the dll into Miranda's plugin subdirectory.

Translation
-----------
see N&R-langpack.txt for details

License
-------
Copyright (C) 2002 Lubomir Ivanov
Copyright (C) 2005 Joe Kucera

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.

For more information, e-mail jokusoftware@gmail.com
                             d00mEr@dir.bg

Changes
-------
0.0.4.5
-------
* New Developer: Joe @ Whale, jokusoftware@gmail.com, I took over the development
   of this great plug-in, got sources of 0.0.4.0 from original author (newer were
   lost), hopfully managed to add features of succeeding versions.
! BugFix: Hopefully fixed all crash issues & memory leaks
! BugFix: Fixed random reminder issue
+ Optimisation: minimised use of memory alloc/free (much faster loading)
+ Feature: reminder sound now configurable thru default Skin/Sounds module (EVents/Sounds)

-------
0.0.4.2
-------
! BugFix: Reminder -> SMS Notify now works.
+ Option: Show vertical scrollbar in Notes.
+ Feature: Create Note from content of Reminder Notify.
+ Feature: Icons for Delete Note, Hide Note

-------
0.0.4.1
-------
! BugFix: URL in Note problem fixed
! Bugfix: Closing Reminder dialog will now mean "Remind me again"
          You must press "Dismiss" to remove reminder
! BugFix: Strange behaviour to add reminders + 1 hour.. (Now uses Localtime)
! BugFix: Missing Langpack strings

-------
0.0.4.0
-------
+ Totaly revriten everything!!! Moved to Microsoft (R) Visual C ++ 6.0
+ Added TopToolbar buttons for "New Reminder" and "New Note"
+ Notify via SMS to E-mail gateway (Only for Reminders)

-------
0.0.3.1
-------
+ Sorry, i've forgot to remove debug :( That's why the plugin crashes
  Now i've removed it :) Also i've relocated plugin to new base addres, so
  there must not be a crash on start or exit (btw if you use any other
  Delphi plugins, please contact autor to relocate them to a different
  base addres than standart $4000000, or there will be a crash !!

0.0.3.0
-------
+ Reocurrence of Reminders (Daily, Weekly, Monthly)
+ Fixed bug with crash :(

0.0.2.8
-------
+ Changed DB structure again (fixed bug with Notes & Reminders size greater
  than 4096 bytes). Now every Note & Reminder are stored into separate DB
  setting, but every Note or Reminder is still limited to 4000 bytes :( sorry
  for that. It is recomended you to clear all notes & Reminders to avoid errors :)
+ Implemented Purge function to free unused Notes & Reminders data from DB :)
+ Removed 'Empty' sign when a Note or Reminder have no text :)
+ Is the "Reminder On Top" bug still there? It works fine for me ?!? :)
  (I've tested on Win ME, 2K Pro & XP)

0.0.2.7
-------
+ Fixed bug with Reminders not showing on top of all windows

0.0.2.6
-------
+ "Remind me again in:" now includes any date and(or) time in the future,
  not just (5,10,15...etc min.).
+ Changed Name in Options dialog.

0.0.2.5
-------
+ Togle On-Top with the pin icon (Icon reflects status)
+ Change Font effects & colors (For Caption & Note body)
+ A "View Reminders" button in the "Add Reminder" box.
+ Rearanged TAB order :)

0.0.2.4
-------
+ Custom Sound to play On Reminder

0.0.2.3
-------
[Warning!!! New Format of DB data! Incompatible with old versions]
[It is recomended to delete all Notes and Reminders              ]

+ Fixed bug - not showing corectly "Remind Again In :" Combo Box
+ Fixed bug - Trying to delete from empty list of reminders causes
  error message.
+ Fixed bug - Problem when using Unicode characters
+ Other minor bug (or not bug) fixes :)

0.0.2.2
-------
+ Switched to Delphi 6 (smaller code)
+ There where so many feature requests for language translations :)
  So i decided to implement this feature :)
+ I think finally fixed the on-top bug ?!?

0.0.2.1
-------
+ Fixed bug on 9X platforms (Didn't draw notes correct) :) Sorry, i forgot
  to initialize length of an structure :)
+ Changed Name :)
+ Added transparency of Notes (Win 2K & XP)

0.0.2.0
-------
+ Reminder function implemented :)
+ Changed version to 2.0 :)

0.0.1.6
-------
+ Fixed structure in DB to store new features (Visible,On Top).
  (Now DB Settings of plugin are incompatible with old versions,
  so if you update , you will loose all notes).
+ Added Popup menu items for new features (Visible, On Top).
+ Minor changes in code to improve preformance. Smaller code :)

0.0.1.5
-------
+ Replaced Hot Keys with global Hot Keys.
+ Added option to change these Hot Keys.
+ Added Popup menu to Notes (Cut,Copy,Paste).
+ Added option to set default size of notes on create new.
+ Basic Implementation of reminders.

0.0.1.4
-------
+ Now saving Notes data on every change to avoid loosing notes if crash.
+ Fixed some bugs with window placement.
+ Added options for staying Always On Top.
+ Added Hot Keys to menu.

0.0.1.3
-------
+ Fixed bug with notes that have no text.
+ Added functions to Show/Hide Notes.
+ Added some icons :)

0.0.1.2
-------
+ Added Options dialog, to alow change of color and fonts for notes.

0.0.1.1
-------
+ Changed to save Notes data into Miranda database insted
  of Windows registry.

0.0.1.0
-------
+ First release of this plugin.