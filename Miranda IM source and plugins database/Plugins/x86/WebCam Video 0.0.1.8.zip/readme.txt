WebCam Video plugin for Miranda 3.3.0 or later.

WebCam Video consists of two parts:
(1) Web Camera system routines, which are documented, and could be freely used by any developer. Both BITMAP and JPEG formats are supported. Check out m_webcam.h file for details.
(2) Video Chat - this will allow to establish video-chat. Frames are converted to text and sent to remote contact as regular text messages. Normally, people will not see these messages, they will see picture instead. So, video chat will work even behind the firewall.

Video Chat features:
+  Video-chats can be automatically saved as regular .AVI files.
+  Delay and block size may be changed.

Web Camera system features:
+  User may select any video-source (web-camera, TV tuner etc).
+  User may select JPEG image quality (0...100%)
+  Developers can get webcam image in two possible formats:
+  .BMP - windows bitmap, 24 bits per pixel.
+  .JPG - regular JPEG image.

How to use WebCam Video:
+  Right-click on contact name in Miranda main window
+  Select Video Chat menu item
+  If remote party has WebCam Video plugin installed, it will start video chat immediately.
+  If remote party does not have WebCam Video plugin installed, he/she will receive small text message saying you want to start video chat. The download link will be provided, as well.

Version History:
0.0.1.8
   MS_WEBCAM_OPEN improved.
   MS_WEBCAM_ISREADY added.
0.0.1.7
   ME_WEBCAM_SNAPSHOTRECEIVED event added.
   MS_WEBCAM_OPEN fixed.
0.0.1.6
   MS_WEBCAM_SCREENSHOT service function added.
0.0.1.5
   webcam_langpack.txt file added to archive
0.0.1.4
   All text messages and window items are now translatable.
0.0.1.3
   Access violation fixed (when no web camera is installed).
0.0.1.2
   Recorder avi/jpg files are stored in different folders for different contacts
   MS_WEBCAM_OPEN system call is now synchrous. Web camera is now ready for use after opening immediately.

Known problems:
  Problem:  Sometimes, after running Video Chat, Miranda stucks, and does not send any messages to any remote contacts.
  Solution: Decrease block size and/or increase delay of block sending. Default settings are small enough to cause such a problems though.

Developer:
   Sergei Polishchuk  ( pserge@softcab.com )
   SoftCab Inc  ( http://www.softcab.com )
