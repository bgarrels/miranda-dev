About
-----
Received Files Folders Plugin
by Luigi Rizzo  msn: bartsimp at caramail.com
		UIN: 64064392
for Miranda IM
written with Microsoft Visual C++ 6.0

Description
-----------
This plugin add a menu to open the received files folders.
 

Installation
------------
Just copy the file dll into Miranda plugin subdirectory.


Source
------
The source code for this plugin can be downloaded from Miranda
website http://www.miranda-im.org.


Development
-----------
My radix 		35d,0x23
My base 		0x23000000
Incoming Folders base	0x23010000


Known bugs
----------
There are NO known bugs. So if you experience one email me!


Translation
-----------
This plugin can be translated via the Miranda language files.
The required strings are provided in langpack txt-file.


Changes
-------
20 may 2004 v.0.1.1.0
  -integrate with toptoolbar plugin

18 may 2004 v.0.1.0.0
  -recoded contect menu function with MS_FILE_GETRECEIVEDFILESFOLDER
  -integration with miranda DB
  -add plugin option

11 may 2004 v0.0.0.2
  -plugin name changed to Received Files Folders
  -integrate in context menu

28 apr 2004 v0.0.0.1
  -First public version as plugin.


DISCLAIMER
----------
This plugin works just fine on my machine, it should work just fine on yours
withouth conflicting with other plugins. Should you have any trouble, write me.
Anyway, if you are a smart programmer, give a look at the code and tell
me the changes you'd make. If I like them, I'll put them inside giving you
the right credit!

This plugin is released under the GPL license, I'm too lazy to copy it, though.
Anyway, if you do have Miranda (and you should, otherwise this plugin is
pretty useless) you already have a file called GPL.txt with this license.
Being GPLed you are free to modify or change the source code but you cannot sell it.
As I already wrote: if you do modify it, notify me, I don't see a good reason
not to share the improvements with the Miranda community.
