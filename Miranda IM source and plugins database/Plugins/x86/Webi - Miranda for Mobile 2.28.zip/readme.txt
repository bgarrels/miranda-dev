Webi - Mrianda for Mobile
http://legoking.le.funpic.de/webi/
http://forums.miranda-im.org/showthread.php?t=20060
By MPK
Version 2.028

***Description***
This script offers the possibility to use Miranda from a mobile phone and any other browser.
It does not need Javascript and can be easily used on tiny screens.

Basic freatures:
-Clist with status and displayname
-chat with history
-change your status

optional freature:
-groups
-Xstatus (set and read)
-Filesupport
-notifications (sound/javascript)
-Tooltips
-birthday notification
-quickreply buttons
-skinnable design
...

***Requirement***
MBot/MSP (Miranda Scripting Plugin) http://addons.miranda-im.org/details.php?action=viewfile&id=1584
MBot extensions http://legoking.le.funpic.de/webi/extensions.rar
running Computer with Miranda

***installation***
unpack the .rar file to your Miranda folder
start/restart Miranda
Open the Main menu and click on Webi Setting.
Set your username and password (when enabeling login). Click ok.
Click Yes to open Webi and log in.
go to settings, and customize your Webi
Now you can acces Webi from every browser by opening http://COMPUTER_IP:8081/webi/

for more comfort I suggest to open a free dns account on dyndns.org by this you will not have to know the COMPUTER_IP but use MY_ACCOUNT.dnydns.org

***Changelog + Further Information***
http://legoking.le.funpic.de/webi/
http://forums.miranda-im.org/showthread.php?t=20060