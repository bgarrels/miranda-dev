<?
if(!isset($secure) || $secure!==true){
	die();
}if(isset($_POST['proto'])){
	if(!is_array($_POST['proto'])){
		echo 'Error occured';
		exit;
	}
	$hand = fopen('inc/settings/ignoredprotos.txt', 'w');
	foreach($_POST['proto'] as $protoigno){
		fwrite($hand, $protoigno.'
');
	}
	echo translateString('Modification saved').'.<br/>';
}

echo '<br>'.translateString('Mark all protocols you want to hide in Clist and my Status').':<br/><form method="post" action=""><table><tr>';
$allprotos = mb_SysEnumProtocols();
if($allprotos==null){
	echo 'Error occured';
	exit;
}
if(isset($_POST['proto'])){
	$ignored = $_POST['proto'];
}else{
	$ignored = unserialize(IGNORED_PROTO);
}
foreach($allprotos as $proto){
	$chk='';
	if(in_array(trim(strtolower($proto)),$ignored))
		$chk = ' checked="checked"';
	echo '<td><label><input type="checkbox" name="proto[]" value="'.strtolower($proto).'" '.$chk.'/> '.$proto.' </label></td></tr><tr>';
}
echo '<td><input type="submit" name="proto[]" value="'.translateString('Save').'" /></td></tr></table></form>';

?>