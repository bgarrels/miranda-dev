<?
$groupsort = null;
$tmp = null;
if(SORT_GROUPS_BY=='clist'){
	$count = 0;
	if(mb_CSettingGet(0, 'CListGroups', $count)!=0)
		echo 'hmm';
	while(mb_CSettingGet(0, 'CListGroups', $count)!=false && mb_CSettingGet(0, 'CListGroups', $count)!=''){
		$tmp = substr(mb_CSettingGet(0, 'CListGroups', $count), 1);
		$groupsort[] = '-'.trim($tmp);
		$count++;
	}
	$groupsort[] = '-';
}elseif(SORT_GROUPS_BY == 'last'){
	$count = 0;
	while(isset($groups[$count][0])){
		$tmpGroup = $groups[$count][0];
		$tmp[$tmpGroup]=0;
		foreach($groups[$tmpGroup] as $key => $cid){
			if($key!='total' && $key!='online' && $key!=0){
				$hid = mb_EventFindLast($cid);
				if($hid == null || $hid == false){
					$time = 0;
				}else{
					$message = mb_EventGetData($hid, 0);
					if($message == false)
						$time = 0;
					else
						$time = $message[2];
				}
				if($time>$tmp[$tmpGroup])
					$tmp[$tmpGroup]=$time;
			}
		}
		$count++;
	}
	arsort($tmp, SORT_NUMERIC);
	foreach($tmp as $key => $value){
		$groupsort[] = $key;
	}
}elseif(SORT_GROUPS_BY == 'name'){
	$count = 0;
	while(isset($groups[$count][0])){
		$groupsort[] = $groups[$count][0];
		$count++;
	}
	sort($groupsort);
}else{
	$count = 0;
	while(isset($groups[$count][0])){
		$groupsort[] = $groups[$count][0];
		$count++;
	}
}