<?
if(!isset($secure) || $secure!==true){
	die();
}
if(isset($_POST['search']) && isset($_POST['replace']) && $_POST['todo']=='check' && isset($_POST['proto'])){
	$pos = 0;
	$line = 0;
	$search = trim($_POST['search']).'
';
	while(!strpos($search, '
', $pos+1)===false){
		$pos2 = strpos($search, '
', $pos+1);
		$searchorg[$line] = substr($search, $pos, $pos2-$pos);
		$pos = $pos2;
		$line++;
	}
	$pos = 0;
	$line = 0;
	$replace = trim($_POST['replace']).'
';
	while(!strpos($replace, '
', $pos+1)===false ){
		$pos2 = strpos($replace, '
', $pos+1);
		$replaceorg[$line] = substr($replace, $pos, $pos2-$pos);
		$pos = $pos2;
		$line++;
	}
	$line = 0;
	while(isset($searchorg[$line])){
		$searchtmp = trim($searchorg[$line]);
		if(strpos($searchtmp, ' ')===false){
			$finalsearch[] = trim(str_replace('%%__%%', ' ', $searchtmp));
			$finalreplace[] = trim($replaceorg[$line]);
		}else{
			$pos = 0;
			while(!strpos($searchtmp, ' ', $pos+1)===false){
				$pos2 = strpos($searchtmp, ' ', $pos+1);
				$finalsearch[] = trim(str_replace('%%__%%', ' ',substr($searchtmp, $pos, $pos2-$pos)));
				$finalreplace[] = trim($replaceorg[$line]);
				$pos = $pos2;
			}
		}
		$line++;
	}
	$proto = $_POST['proto'];
	$line = 0;
	echo '<form method="post" action=""><table width="50">';
	while( isset($finalsearch[$line])){
		if( strpos($finalreplace[$line], '_____________')===false ){
			if( !(strpos($finalreplace[$line], 'http://')===false)){
				$image = $finalreplace[$line];
			}else{
				$image = 'inc/smileys/'.$proto.'/'.$finalreplace[$line];
			}
			echo '<tr><td>'.$finalsearch[$line].'</td><td>=&gt;</td><td><img alt="" src="'.$image.'"/></td></tr>';
		}
		$line++;
	}
?>
<tr><td colspan="3">
<div align="center">
<input type="hidden" name="proto" value="<? echo $_POST['proto'];?>"/>
<input type="hidden" name="search" value="<? echo $_POST['search'];?>"/>
<input type="hidden" name="replace" value="<? echo $_POST['replace'];?>"/>
<input type="submit" name="todo" value="change"/>
<input type="submit" name="todo" value="save"/>
</div></td></tr></table></form>
<?
	
	
	
	
}elseif(isset($_POST['search']) && isset($_POST['replace']) && $_POST['todo']=='save' && isset($_POST['proto'])){
	if(!file_exists('inc/smileys/'.$_POST['proto']))
		mkdir('inc/smileys/'.$_POST['proto']);
	$pos = 0;
	$search = trim($_POST['search']).'
';
	while(strpos($search, '
', $pos)){
		$to = strpos($search, '
', $pos);
		if(strpos(substr($search, $pos, $to-$pos), '___________')===false)
			$smileysearch[] = trim(str_replace('%%__%%', ' ',substr($search, $pos, $to-$pos)));
		$pos = $to+1;
	}
	$pos = 0;
	$proto = $_POST['proto'];
	$replace = trim($_POST['replace']).'
';
	while(strpos($replace, '
', $pos)){
		$to = strpos($replace, '
', $pos);
		if(strpos(substr($replace, $pos, $to-$pos), '___________')===false)
			$smileyreplace[] = trim(substr($replace, $pos, $to-$pos));
		$pos = $to+1;
	}
	$line = 0;
	$handle = fopen('inc/smileys/'.$_POST['proto'].'/replace.txt', 'w');
	while(isset($smileyreplace[$line]) && isset($smileysearch[$line]) ){
		fwrite($handle, $smileyreplace[$line].'
');
		$line++;
	}
	fclose($handle);
	$line = 0;
	$handle = fopen('inc/smileys/'.$_POST['proto'].'/search.txt', 'w');
	while(isset($smileyreplace[$line]) && isset($smileysearch[$line]) ){
		fwrite($handle, $smileysearch[$line].'
');
		$line++;
	}
	fclose($handle);
	echo translateString('Modification saved');
	
}elseif(isset($_POST['search']) && isset($_POST['replace']) && $_POST['todo']=='change' && isset($_POST['proto'])){
	$pos = 0;
	$search = trim($_POST['search']).'
';
	while(strpos($search, '
', $pos)){
		$to = strpos($search, '
', $pos);
		if(strpos(substr($search, $pos, $to-$pos), '___________')===false)
			$smileysearch[] = substr($search, $pos, $to-$pos);
		$pos = $to+1;
	}
	$pos = 0;
	$proto = $_POST['proto'];
	$replace = trim($_POST['replace']).'
';
	while(strpos($replace, '
', $pos)){
		$to = strpos($replace, '
', $pos);
		if(strpos(substr($replace, $pos, $to-$pos), '___________')===false)
			$smileyreplace[] = trim(substr($replace, $pos, $to-$pos));
		$pos = $to+1;
	}
	$line = 0;
	$searchvalue = "";
	$replacevalue = "";
	while( isset($smileyreplace[$line]) && isset($smileysearch[$line]) ){
		$searchvalue .= html_entity_decode($smileysearch[$line], ENT_NOQUOTES, 'UTF-8');
		$replacevalue .= $smileyreplace[$line].'
';
		if($line%20 == 19){
			$searchvalue .= '
'.$line.'______________
';
			$replacevalue .= $line.'______________
';
		}
		$line++;
	}
?>
<form method="post" action="">
<table width="50">
  <tr>
    <td class=top><div align="left"><? echo translateString('Searche for');?>:</div></td>
    <td class=top><div align="left">
      <? echo translateString('Replace with image');?><br />
          <font size="1">image.jpg <? echo translateString('located in').' inc/smileys/'.$_POST['proto'];?></font>
      </div></td>
  </tr>
  <tr>
    <td>
        <div align="center"><label>
          <textarea name="search" cols="19" rows="<? if($line>30){ echo 30; }else{ echo $line; }?>"><? echo fixforhtml($searchvalue);?></textarea>
        </label></div>
        </td>
    <td><div align="center">
      <textarea name="replace" cols="19" rows="<? if($line>30){ echo 30; }else{ echo $line; }?>"><? echo fixforhtml($replacevalue);?></textarea>
    </div></td>
  </tr>
  <tr>
    <td colspan="2">
      <div align="center"><label>
        <input type="hidden" name="proto" value="<? echo $_POST['proto'];?>"/>
        <input type="hidden" name="todo" value="check"/>
        <input type="submit" value="<? echo translateString('check');?>"/>
        </label>
    </div></td>
  </tr>
</table>
</form>
<?

}elseif(USE_SPECIFIC_SMILEYS && !isset($_POST['proto'])){
?>
	<p><? echo translateString('Which Portocoll Smileypack do you want to modify?');?></p>
    <form method="post" action="">
	<table border="0">
      <tr>
       <td><label><input name="proto" type="radio" value="default" checked="checked"/>
       default</label></td>
	<?
		$protocols = mb_SysEnumProtocols();
		$count = 1;
		foreach($protocols as $protocol) {
        	echo '<td><label><input type="radio" name="proto" value="'.$protocol.'" />'.$protocol.'</label></td>';
			$count++;
		}
	?>
      </tr>
      <tr>
        <td colspan="<? echo $count;?>">
          <div align="center"><label>
            <input type="submit" value="<? echo translateString('continue');?>"/>
            </label></div>
        </td>
      </tr>
    </table>
</form>
<?
}else{
	if(isset($_POST['proto']) && $_POST['proto']!=""){
		$proto = $_POST['proto'];
	}else{
		$proto = 'default';
	}
	if(file_exists('inc/smileys/'.$proto.'/replace.txt')){
		$smileyreplace = file('inc/smileys/'.$proto.'/replace.txt');
	}else{
		$smileyreplace[] = "";
	}
	if(file_exists('inc/smileys/'.$proto.'/search.txt')){
		$smileysearch = file('inc/smileys/'.$proto.'/search.txt');
	}else{
		$smileysearch[] = "";
	}
	$line = 0;
	$searchvalue = "";
	$replacevalue = "";
	while( isset($smileyreplace[$line]) && isset($smileysearch[$line]) ){
		$searchvalue .= $smileysearch[$line];
		$replacevalue .= $smileyreplace[$line];
		if($line%20 == 19){
			$searchvalue .= $line.'______________
';
			$replacevalue .= $line.'______________
';
		}
		$line++;
	}
?>
<form method="post" action="">
<table width="50">
  <tr>
    <td class=top><div align="left"><? echo translateString('Searche for');?>:</div></td>
    <td class=top><div align="left">
      <? echo translateString('Replace with image');?><br />
          <font size="1">image.jpg <? echo translateString('located in').' inc/smileys/'.$_POST['proto'];?></font>
      </div></td>
  </tr>
  <tr>
    <td>
        <div align="center">
          <textarea name="search" cols="19" rows="<? if($line>30){ echo 30; }else{ echo $line; }?>"><? echo fixforHTML($searchvalue);?></textarea>
        </div>
        </td>
    <td><div align="center">
      <textarea name="replace" cols="19" rows="<? if($line>30){ echo 30; }else{ echo $line; }?>"><? echo fixforHTML($replacevalue);?></textarea>
    </div></td>
  </tr>
  <tr>
    <td colspan="2">
      <div align="center"><label>
        <input type="hidden" name="proto" value="<? echo $_POST['proto'];?>"/>
        <input type="hidden" name="todo" value="check"/>
        <input type="submit" value="<? echo translateString('check');?>"/>
        </label>
    </div></td>
  </tr>
</table>
</form>
<?
}
?>