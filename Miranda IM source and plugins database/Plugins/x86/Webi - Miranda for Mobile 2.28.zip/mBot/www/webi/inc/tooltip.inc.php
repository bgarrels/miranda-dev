<?
if(IE_TOOLTIP){

?>

<style type="text/css">
<!--

	a.info{
		position:relative;
		z-index:24;}

	a.info:hover{z-index:25;
		text-decoration:none;}
	
	a.info span{display: none;}
	
	a.info td{background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}

	a.info:hover span{
		-moz-border-radius:10;
		-khtml-border-radius:10;
		-webkit-border-radius:10;
		display:block;
		position:absolute;
		padding: 4px 5px;
		width:<? echo TT_WIDTH;?>;
		border:1px dotted <? echo TT_BORDER;?>;
		background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}
	
<?//--------------------------------------------?>
	a.infotab{
		position:relative;
		z-index:24;}

	a.infotab:hover{z-index:25;
		text-decoration:none;}
	
	a.infotab span{display: none}
	
	a.infotab td{background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}

	a.infotab:hover span{
		-moz-border-radius:10;
		-khtml-border-radius:10;
		-webkit-border-radius:10;
		display:block;
		position:absolute;
		padding: 4px 5px;
		top:10; left:7; width:<? echo TT_WIDTH;?>;
		border:1px dotted <? echo TT_BORDER;?>;
		background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}
	
<?//--------------------------------------------?>
	a.info2{
		position:relative;
		z-index:24;}

	a.info2:hover{z-index:25;
		text-decoration:none;}
	
	a.info2 span{display: none}
	
	a.info2 td{background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}

	a.info2:hover span{
		-moz-border-radius:10;
		-khtml-border-radius:10;
		-webkit-border-radius:10;
		display:block;
		position:absolute;
		padding: 4px 5px;
		top:12; width:<? echo TT_WIDTH;?>;
		border:1px dotted <? echo TT_BORDER;?>;
		background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}
-->
	</style>
<?

/*
*	tooltip for link
*/
	function ToolTipLnk($str, $popup, $link){
		return '<a class="infotab" href="'.$link.'"><span>'.$popup.'</span>'.$str.'</a>';
	}
/*
*	tooltip for text
*/
	function ToolTip($str, $popup){
		return '<a class="infotab"><span>'.$popup.'</span>'.$str.'</a>';
	}
/*
*	last message tooltip
*/
	function MessageToolTip($cid){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if($nick=='')
			$nick = mb_CGetInfo($cid, 3);
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = substr($nick,0,SHORTEN_NICK-3).'...';
		else
			$echonick = $nick;
		$return = '<img border="0" src="fotos/other/message.png" /> <a class="infotab" href="contact.php?cid='.$cid.'"><span>';
		$newmess = newmessages($cid);
		$newtxt = $newmess['txt'];
		$newtime = $newmess['time'];
		foreach($newtxt as $key => $txt){
			$return = $return.'<font style="font-size:10px;font-style:italic;">'.$newtime[$key].'</font><br/>'.$txt.'<br/>';
		}
		$return = $return.'</span><nobr>'.$echonick.'</nobr></a>';
		return $return;
	}
/*
*	clist tooltip
*/
	function ClistToolTip($cid, $collum, $over){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = substr($nick,0,SHORTEN_NICK-3).'...';
		else
			$echonick = $nick;
		$left = 125 - $collum * 50;
		if($over==true)
			$top = -200;
		else
			$top = 40;
		if(file_exists('inc/tooltips/clist.txt')){
			$file = file_get_contents('inc/tooltips/clist.txt');
			$file = replace($file, $cid);
			$bd = '';
			if(SHOW_BDAY)
				$bd = bdayicon($cid, mb_CGetProto($cid));
			return '<a class="info" href="contact.php?cid='.$cid.'"><span style="left:'.$left.'; top:'.$top.';">'.$file.'</span><nobr>'.icon($cid).$bd.$echonick.'</nobr></a>';
		}else{
			return '<a class="info" href="contact.php?cid='.$cid.'"><span style="left:'.$left.'; top:'.$top.';">No ToolTip Definition</span><nobr>'.icon($cid).$bd.$echonick.'</nobr></a>';
		}
	}
/*
*	Chat tooltip
*/
	function ContactToolTip($cid){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if(file_exists('inc/tooltips/contact.txt')){
			$file = file_get_contents('inc/tooltips/contact.txt');
			$file = replace($file, $cid);
			$left = 280 + strlen($nick) * - 7;
			return '<a class="info2"><nobr><b>'.$nick.'</b></nobr><span style="left:-'.$left.';">'.$file.'</span></a>';
		}else{
			return '<a class="info2"><nobr><b>'.$nick.'</b></nobr><span style="left:-'.$left.';">No ToolTip Definition</span></a>';
		}
	}
/*
*	Tab tooltip
*/
	function TabToolTip($cid){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = substr($nick,0,SHORTEN_NICK-3).'...';
		else
			$echonick = $nick;
		if(file_exists('inc/tooltips/tab.txt')){
			$file = file_get_contents('inc/tooltips/tab.txt');
			$file = replace($file, $cid);
			return '<a class="infotab" href="contact.php?cid='.$cid.'"><span>'.$file.'</span><nobr>'.icon($cid).$echonick.'</nobr></a>';
		}else{
			return '<a class="infotab" href="contact.php?cid='.$cid.'"><span>No ToolTip Definition</span><nobr>'.icon($cid).$echonick.'</nobr></a>';
		}
	}
	
	
}else{
/*
Here Beginns the NON-IE Version -------------------------------------------------------------------------------------------------------	
 --------------------------------------------------------------------------------------------------------------------------------------
 --------------------------------------------------------------------------------------------------------------------------------------
 --------------------------------------------------------------------------------------------------------------------------------------
 --------------------------------------------------------------------------------------------------------------------------------------
*/
?>
	
	<style type="text/css">
<!--

	span.info{
		position:relative;
		z-index:24;}

	span.info:hover{z-index:25;
		text-decoration:none;}
	
	span.info p{display: none;}
	
	span.info td{background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}

	span.info:hover p{
		-moz-border-radius:10;
		-khtml-border-radius:10;
		-webkit-border-radius:10;
		display:block;
		position:absolute;
		padding: 4px 5px;
		top:-40; width:<? echo TT_WIDTH;?>;
		border:1px dotted <? echo TT_BORDER;?>;
		background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}
	
<?//--------------------------------------------?>
	span.infotab{
		position:relative;
		z-index:24;}

	span.infotab:hover{z-index:25;
		text-decoration:none;}
	
	span.infotab p{display: none;}
	
	span.infotab td{background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}

	span.infotab:hover p{
		-moz-border-radius:10;
		-khtml-border-radius:10;
		-webkit-border-radius:10;
		display:block;
		position:absolute;
		padding: 4px 5px;
		top:10; left:7; width:<? echo TT_WIDTH;?>;
		border:1px dotted <? echo TT_BORDER;?>;
		background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}
	
<?//--------------------------------------------?>
	span.info2{
		position:relative;
		z-index:24;}

	span.info2:hover{z-index:25;
		text-decoration:none;}
	
	span.info2 p{display: none;}
	
	span.info2 td{background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}

	span.info2:hover p{
		-moz-border-radius:10;
		-khtml-border-radius:10;
		-webkit-border-radius:10;
		display:block;
		position:absolute;
		padding: 4px 5px;
		top:12; width:<? echo TT_WIDTH;?>;
		border:1px dotted <? echo TT_BORDER;?>;
		background-color:<? echo TT_BG;?>; color:<? echo TT_COLOR;?>;}
-->
	</style>

<?
/*
*	tooltip for link
*/
	function ToolTipLnk($str, $popup, $link){
		return '<span class="infotab"><p>'.$popup.'</p><a href="'.$link.'">'.$str.'</a></span>';
	}
/*
*	tooltip for text
*/
	function ToolTip($str, $popup){
		return '<span class="infotab"><p>'.$popup.'</p>'.$str.'</span>';
	}
/*
*	last message tooltip
*/
	function MessageToolTip($cid){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if($nick=='')
			$nick = mb_CGetInfo($cid, 3);
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = substr($nick,0,SHORTEN_NICK-3).'...';
		else
			$echonick = $nick;
		$return = '<img border="0" src="fotos/other/message.png" /> <span class="infotab"><p>';
		$newmess = newmessages($cid);
		$newtxt = $newmess['txt'];
		$newtime = $newmess['time'];
		foreach($newtxt as $key => $txt){
			$return = $return.'<font style="font-size:10px;font-style:italic;">'.$newtime[$key].'</font><br/>'.$txt.'<br/>';
		}
		$return = $return.'</p><a href="contact.php?cid='.$cid.'"><nobr>'.$echonick.'</nobr></a></span>';
		return $return;
	}
/*
*	clist tooltip
*/
	function ClistToolTip($cid, $collum, $over){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = substr($nick,0,SHORTEN_NICK-3).'...';
		else
			$echonick = $nick;
		$left = 125 - $collum * 50;
		if($over==true)
			$top = -200;
		else
			$top = 40;
		if(file_exists('inc/tooltips/clist.txt')){
			$file = file_get_contents('inc/tooltips/clist.txt');
			$file = replace($file, $cid);
			$bd = '';
			if(SHOW_BDAY)
				$bd = bdayicon($cid, mb_CGetProto($cid));
			return '<span class="info"><p style="left:'.$left.'; top:'.$top.';">'.$file.'</p><nobr>'.icon($cid).$bd.'<a href="contact.php?cid='.$cid.'">'.$echonick.'</nobr></a></span>';
		}else{
			return '<span class="info"><p style="left:'.$left.'; top:'.$top.';">No ToolTip Definition</p><nobr>'.icon($cid).$bd.'<a href="contact.php?cid='.$cid.'">'.$echonick.'</nobr></a></span>';
		}
	}
/*
*	Chat tooltip
*/
	function ContactToolTip($cid){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if(file_exists('inc/tooltips/contact.txt')){
			$file = file_get_contents('inc/tooltips/contact.txt');
			$file = replace($file, $cid);
			$left = 280 + strlen($nick) * - 7;
			return '<span class="info2"><nobr><b>'.$nick.'</b></nobr><p style="left:-'.$left.';">'.$file.'</p></span>';
		}else{
			return '<span class="info2"><nobr><b>'.$nick.'</b></nobr><p style="left:-'.$left.';">No ToolTip Definition</p></span>';
		}
	}
/*
*	Tab tooltip
*/
	function TabToolTip($cid){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = substr($nick,0,SHORTEN_NICK-3).'...';
		else
			$echonick = $nick;
		if(file_exists('inc/tooltips/tab.txt')){
			$file = file_get_contents('inc/tooltips/tab.txt');
			$file = replace($file, $cid);
			return '<span class="infotab"><p>'.$file.'</p><nobr>'.icon($cid).'<a href="contact.php?cid='.$cid.'">'.$echonick.'</a></nobr></span>';
		}else{
			return '<span class="infotab"><p>No ToolTip Definition</p><nobr>'.icon($cid).'<a href="contact.php?cid='.$cid.'">'.$echonick.'</a></nobr></span>';
		}
	}
	
}