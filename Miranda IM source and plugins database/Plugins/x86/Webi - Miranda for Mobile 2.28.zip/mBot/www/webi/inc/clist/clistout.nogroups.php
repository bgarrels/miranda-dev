<?
include('clistsort.nogroups.php');

$stat = 'news';
$row = 0;
$rownum = 1;
$count = 0;
echo '<tr><td class="contact"><table border="0">';
while(isset($sorted[$count])){
	$cid = $sorted[$count];
	$status = $contact['status'][$cid];
	$proto = $contact['proto'][$cid];
	$count++;

	if($status == ID_STATUS_OFFLINE && !$all)
		continue;
	if(isset($ignore[$cid]))
		continue;
	if(SHORTEN_NICK > 4 && strlen($contact['nick'][$cid])>SHORTEN_NICK)
		$echonick = substr($contact['nick'][$cid],0,SHORTEN_NICK-3).'...';
	else
		$echonick = $contact['nick'][$cid];
	$row++;
	if($maxperrow/2 > $row)
		$over = false;
	else
		$over = true;
	echo '<tr><td class="contact">'.clistToolTip($cid,$rownum,$over).'</font></td></tr>';
	if($contact['proto'][$cid]=='MetaContacts' && SHOW_SUBCONTACTS){
		$meta = 0;
		while( mb_CSettingGet($cid, 'MetaContacts', 'Handle'.$meta)!=""){
			$metacid = mb_CSettingGet($cid, 'MetaContacts', 'Handle'.$meta);
			if($contact['status'][$metacid]!=ID_STATUS_OFFLINE || $all){
					if($maxperrow/2 > $row)
						$over = false;
					else
						$over = true;
				echo '<tr><td class="contact"><img src="fotos/other/blank.gif" width="13">'.clistToolTip($metacid,$rownum,$over).'</font></td></tr>';
				$row++;
			}
			$meta++;
		}
	}
	if($row>=$maxperrow && $rownum < $maxrows){
		$row = 0;
		$rownum++;
		echo '</table></td></tr></table></td><td align="center" valign="top"><table class=clist><tr><td class="contact"><table border="0">';
	}elseif($row>=$maxperrow){
		$row = 0;
		$rownum++;
	}
}

		echo '</table></td></tr>';