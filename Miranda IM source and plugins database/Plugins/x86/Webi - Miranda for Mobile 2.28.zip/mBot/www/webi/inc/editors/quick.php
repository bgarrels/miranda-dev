<?
if(!isset($secure) || $secure!==true){
	die();
}
if(isset($_POST['save']) && isset($_POST['txt'])){
	$fh = fopen('inc/settings/quickreply.txt', 'w');
	fwrite($fh, str_replace('"', '\'', trim($_POST['txt'])));
	fclose($fh);
	$inc = 1;
	$ignorecon = true;
	echo '<br />'.translateString('Modification saved').'. '.translateString('Now it looks the following').':';
	echo '<br /><a href="editor.php?edit=quick">'.translateString('Modify'),'</a><br /><br />';
	
	if(!file_exists('inc/settings/quickreply.txt')){
		echo 'quickreply.txt '.translateString('is missing').'. '.translateString('Create a new one under quickreply settings').'.';
		exit;
	}
	echo '<div align="left">';
	echo '<table><tr><td class=top><div align="left">';
	$file = file('inc/settings/quickreply.txt');
	$count = 0;
	$breakline = false;
	foreach($file as $reply){
		if($breakline==true){
			$breakline = false;
			echo '</div></td></tr><tr><td><div align="left">';
		}
		$reply = trim($reply);
		if($reply==''){
		}elseif($reply=='!!!breakline!!!'){
			$breakline=true;
		}else{
			echo ' <input type="submit" name="body" style="background:'.QUICK_BG.';" value="'.$reply.'"/> ';
		}
		$count++;
	}
	echo '</div></td></tr></table></div>';
}else{
	echo '<br />'.translateString('Every line is one Quickreply button').'.<br />!!!breakline!!! '.translateString('will end a line, no matter how many bottens it has').'.';
	echo '<form method="post" action=""><textarea name="txt" cols="30" rows="20">';
	if(!file_exists('inc/settings/quickreply.txt')){
		$file = "";
	}else{
		$file = file('inc/settings/quickreply.txt');
		foreach($file as $reply){
			echo $reply;
		}
	}
	echo '</textarea><br /><input type="submit" name="save" value="'.translateString('Save').'"/></form>';
}
?>