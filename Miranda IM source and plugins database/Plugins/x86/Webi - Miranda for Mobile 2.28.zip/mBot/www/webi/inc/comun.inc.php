<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
* originally based on Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*
*/

if(!isset($_GET['logout']))
	@session_start();
include("config.inc.php");

$allowedAvatarExtensions = array('jpg','jpeg', 'png', 'gif', 'bmp');

define('SESSION_NAME', 'mobile_user');

function printHTML($string) {

		echo $string . "\n";

}

function fixForHTML($str) {

	//i tried using htmlentities() but it messed up unicode strings..
	//maybe here I could just replace "<" and ">"..
	//return $str;
	
	return htmlentities($str, ENT_QUOTES, 'UTF-8');

}

function translateStringAdv($str, $replace) {
	return str_replace('%s', $replace,translateString($str));
}
function translateString($str) {

	return fixforhtml(ssm_encoding(mb_SysTranslate($str)));

}

//define("SENT", "0x02");
//define("READ", "0x04");
define("SENT", 2);
define("READ", 4);
define("READ_UNICODE_UNREAD", 16);
define("SENT_UNICODE", 18);
define("READ_UNICODE", 20);

$statusArray = array(
	ID_STATUS_OFFLINE => translateString("Offline"),
	ID_STATUS_ONLINE => translateString("Online"),
	ID_STATUS_AWAY => translateString("Away"),
	ID_STATUS_DND => translateString("DND"),
	ID_STATUS_NA => translateString("NA"),
	ID_STATUS_OCCUPIED => translateString("Occupied"),
	ID_STATUS_FREECHAT => translateString("Free for chat"),
	ID_STATUS_INVISIBLE => translateString("Invisible"),
	ID_STATUS_ONTHEPHONE => translateString("On the phone"),
	ID_STATUS_OUTTOLUNCH => translateString("Out to lunch"),
	ID_STATUS_IDLE => translateString("Idle")
);
//convert international characters to "simple" ones
//this is used so that "a" is read as "�" when comparing strings
function icString($string) {

	$a = array("�","�","�","�","�","�");
	$e = array("�","�","�","�");
	$i = array("�","�","�","�");
	$o = array("�","�","�","�","�");
	$u = array("�","�","�","�");
	$n = array("�");

	$string = str_replace($a, 'a', $string);
	$string = str_replace($e, 'e', $string);
	$string = str_replace($i, 'i', $string);
	$string = str_replace($o, 'o', $string);
	$string = str_replace($u, 'u', $string);
	$string = str_replace($n, 'n', $string);
		
	return $string;

}

//encode in UTF8
function ssm_encoding($string) {
	return mb_convert_encoding($string, "UTF-8", CHARSET_REPLY);
}

function redirectToLocal($file) {

	//$host = file("http://legoking.le.funpic.de/webi/getip.php");
	$host  = $_SERVER['HTTP_HOST'];
	$extra = $file;
	//$ulr =  'http://'.$host[0].':'.$_SERVER["REMOTE_PORT"].'/'.INSTALLATION_DIRECTORY.'/'.$extra;
	$ulr =  'http://'.$host.'/'.INSTALLATION_DIRECTORY.'/'.$extra;

	if(headers_sent()) {
	
		printHTML(translateString('ERROR: Could not redirect because headers were already sent').'.<br/>');
		printHTML('<a href="'.$ulr.'">Continue</a>');
		exit;
	
	}
	
	header("Location: ".$ulr);
	exit;

}

function requestPost($campo, $applyThisFunction = array()) {

	if(!isset($_POST[$campo]))

		$x = null;

	else {
	
		$x = trim($_POST[$campo]);
		
		if((is_string($x) && strlen($x) == 0) || $x == '')
			$x = null;
			
	}
	
	if(!is_array($applyThisFunction))
		$applyThisFunction = array($applyThisFunction);

	foreach($applyThisFunction as $function)
		$x = $function($x);

	return $x;

}

function requestGet($campo, $applyThisFunction = array()) {

	if(!isset($_GET[$campo]))

		$x = null;

	else {
	
		$x = trim($_GET[$campo]);

		if((is_string($x) && strlen($x) == 0) || $x == '')
			$x = null;
			
	}
	
	if(!is_array($applyThisFunction))
		$applyThisFunction = array($applyThisFunction);

	foreach($applyThisFunction as $function)
		$x = $function($x);

	return $x;

}


$sorthelp = array(
	9 => ID_STATUS_OFFLINE,
	1 => ID_STATUS_ONLINE,
	3 => ID_STATUS_AWAY,
	8 => ID_STATUS_DND,
	7 => ID_STATUS_NA,
	6 => ID_STATUS_OCCUPIED,
	0 => ID_STATUS_FREECHAT,
	2 => ID_STATUS_INVISIBLE,
	4 => ID_STATUS_ONTHEPHONE,
	5 => ID_STATUS_OUTTOLUNCH,
	10 => ID_STATUS_IDLE,
	'news' => 'news'
);

$shortStatus = array(
	ID_STATUS_OFFLINE => "Off",
	ID_STATUS_ONLINE => "On",
	ID_STATUS_AWAY => "Away",
	ID_STATUS_DND => "DND",
	ID_STATUS_NA => "N/A",
	ID_STATUS_OCCUPIED => "Occup",
	ID_STATUS_FREECHAT => "Free",
	ID_STATUS_INVISIBLE => "Invi",
	ID_STATUS_ONTHEPHONE => "phoning",
	ID_STATUS_OUTTOLUNCH => "Lunch",
	ID_STATUS_IDLE => "Idle",
	'news' => "news"
);
?>