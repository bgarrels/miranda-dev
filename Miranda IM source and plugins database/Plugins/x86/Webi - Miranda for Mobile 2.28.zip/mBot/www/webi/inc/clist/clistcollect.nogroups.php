<?
$cid = mb_CFindFirst();
$amounttoshow = 0;
do{
	if( mb_CGetProto($cid)=="")
		continue;
	if(in_array(strtolower(mb_CGetProto($cid)),unserialize(IGNORED_PROTO)))
		continue;
	if(isset($ignoredgroups['--'.mb_CSettingGet($cid, 'CList', 'Group')]))
		continue;
	if(mb_CSettingGet($cid, 'CList', 'Hidden')!=false)
		continue;
	$contact['cid'][] = $cid;
	$contact['nick'][$cid] = mb_CGetDisplayName($cid);
	$contact['proto'][$cid] = mb_CGetProto($cid);
	
	if( mb_EventFindFirstUnread($cid)!=""){
		$contact['status'][$cid] = 'news';
		$status = 'news';
	}elseif( mb_CGetStatus($cid)!= "" && mb_CGetStatus($cid)!= "0"){
		$status = mb_CGetStatus($cid);
		$contact['status'][$cid] = $status;
		if(!isset($statusArray[$status]))
			$status = ID_STATUS_ONLINE;
	}else{
		$contact['status'][$cid] = ID_STATUS_OFFLINE;
		$status = ID_STATUS_OFFLINE;
	}
	
	//for Metacintacts
	if($contact['proto'][$cid] == 'MetaContacts'){
		$meta = 0;
		while( mb_CSettingGet($cid, 'MetaContacts', 'Handle'.$meta)!=""){
			$metacid = mb_CSettingGet($cid, 'MetaContacts', 'Handle'.$meta);
			$ignore[$metacid] = true;
			if(mb_CGetStatus($metacid) != '' && mb_CGetStatus($metacid) != '0' && ((mb_CGetStatus($metacid) != ID_STATUS_OFFLINE && !$all) || !SHOW_SUBCONTACTS))
				$amounttoshow--;
			$meta++;
		}
	}
	
	//amount
	if($contact['status'][$cid] != ID_STATUS_OFFLINE || $all)
		$amounttoshow++;
		
	//prepare for sort
	if(SORT_BY == 'status')
		$contact['sorted'.$status][] = $cid;
} while($cid = mb_CFindNext($cid));