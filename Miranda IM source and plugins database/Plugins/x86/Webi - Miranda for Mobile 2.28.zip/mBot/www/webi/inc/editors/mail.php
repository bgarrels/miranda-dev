<?
if(!isset($secure) || $secure!==true){
	die();
}

//general settings save
if(isset($_POST['smtp-host'])){
	if(isset($_POST['meta']) && $_POST['meta']==1){
		mb_CSettingAdd(null, 'Webi-mail', DBVT_BYTE, 'sendForMeta', 1);
	}else{
		mb_CSettingAdd(null, 'Webi-mail', DBVT_BYTE, 'sendForMeta', 0);
	}
	mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'min', (int)$_POST['min']);
	mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'sec', (int)$_POST['sec']);
	mt_setvar('webmailtime', (int)$_POST['min'] * 60 + (int)$_POST['sec'] , 1, 0);
	mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'to', $_POST['to']);
	mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'header', $_POST['head']);
	mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'body', $_POST['body']);

	mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'smtp-host', $_POST['smtp-host']);
	mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'from', $_POST['from']);
	mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'smtp-port', (int)$_POST['port']);
	if(isset($_POST['auth'])){
		mb_CSettingAdd(null, 'Webi-mail', DBVT_BYTE, 'smtp-auth', 1);
		mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'smtp-user', $_POST['user']);
		if($_POST['pass']!='***')
			mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'smtp-pass', $_POST['pass']);
	}else{
		mb_CSettingAdd(null, 'Webi-mail', DBVT_BYTE, 'smtp-auth', 0);
		mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'smtp-user', '');
		mb_CSettingAdd(null, 'Webi-mail', DBVT_ASCIIZ, 'smtp-pass', '');
	}
	
	if(isset($_POST['acti']) && $_POST['acti']==1){
		require('file://'.mb_CSettingGet(NULL,'MBot','WWWRoot').'/webi/inc/mail/class.phpmailer.php');
		echo '<font color="#FFFFFF" size="1">';
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->Host = mb_CSettingGet(NULL,'Webi-mail','smtp-host');
		$mail->Port = mb_CSettingGet(NULL,'Webi-mail','smtp-port');
		$mail->From = mb_CSettingGet(NULL,'Webi-mail','from');
		$mail->FromName = 'Webi';
		if(mb_CSettingGet(NULL,'Webi-mail','smtp-auth')==1){
			$mail->SMTPAuth = true;
			$mail->Username = mb_CSettingGet(NULL,'Webi-mail','smtp-user');
			$mail->Password = mb_CSettingGet(NULL,'Webi-mail','smtp-pass');
		}else{
			$mail->SMTPAuth = false;
		}
		$mail->AddAddress(mb_CSettingGet(NULL,'Webi-mail','to'));
		$mail->Subject = 'SMTP Server test';
		$mail->Body = 'This could have been a notification from webi';
		if($mail->Send()){
			mb_MenuModify(mt_getvar('webmailmenu'), 'Mail notification '.mt_getvar('webmail'), null, 0x00, 'sendMail');
			mb_CSettingAdd(null, 'Webi-mail', DBVT_BYTE, 'support', 1);
			$echo ='Setting saved &amp; testmail send<br>';
		}else{
			mt_setvar('webmail', 'off', 1, 0);
			mb_CSettingAdd(null, 'Webi-mail', DBVT_BYTE, 'support', 0);
			mb_MenuModify(mt_getvar('webmailmenu'), 'Mail notification off', null, 0x04, 'sendMail');
			$echo = '<br><b>Notification not activated!!!</b> (error sending test message)<br>Setting saved<br><br>';
		}
		echo '</font>'.$echo;
	}else{
		mt_setvar('webmail', 'off', 1, 0);
		mb_CSettingAdd(null, 'Webi-mail', DBVT_BYTE, 'support', 0);
		mb_MenuModify(mt_getvar('webmailmenu'), 'Mail notification off', null, 0x04, 'sendMail');
		echo 'Setting saved<br>';
	}
}
?>
<b>General mail settings:</b>
<form method="post" action="">
  <table border="1">
  <tr>
    <td colspan="2"><input type="checkbox" name="acti" value="1" <? if(mb_CSettingGet(null, 'Webi-mail', 'support')==1){ echo 'checked="checked"';}?>/>
      Aktivate mail support</td>
  </tr>
  <tr>
    <td colspan="2"><input type="checkbox" name="meta" value="1" <? if(mb_CSettingGet(null, 'Webi-mail', 'sendForMeta')==1){ echo 'checked="checked"';}?>/>
      also send for Metacontacts</td>
  </tr>
  <tr>
    <td colspan="2">Only send mails when earlier message is more than <input type="text" name="min" size="4" value="<? echo (int)mb_CSettingGet(NULL,'Webi-mail','min');?>"/> minutes and <input type="text" name="sec" size="4" value="<? echo (int)mb_CSettingGet(NULL,'Webi-mail','sec');?>"/> seconds old.</td>
  </tr>
  <tr>
    <td>Recipient:</td>
    <td><input type="text" name="to" value="<? echo mb_CSettingGet(NULL,'Webi-mail','to');?>"/></td>
  </tr>
  <tr>
    <td>Header:</td>
<?
$head = mb_CSettingGet(NULL,'Webi-mail','header');
if($head == false){
	$head = '1 new message from %nick% (%proto%)';
}
?>
    <td><input type="text" name="head" value="<? echo $head;?>"/></td>
  </tr>
  <tr>
    <td>Body:</td>
<?
$txt = mb_CSettingGet(NULL,'Webi-mail','body');
if($txt == false){
	$txt = '%text%';
}
?>
    <td><textarea name="body"><? echo $txt;?></textarea></td>
  </tr>
  <tr>
    <td colspan="2"><font size="-1"><nobr>%nick%, %text% and %proto% will be replaced</nobr></font></td>
    </tr>
</table>
<hr />
<b>Server settings:</b><br />
It is recomended to enter the smtp server provided by your E-mail providder (often found under help &gt; how to set up outlook)<br />
  TLS and SSL are not supported. Ask for <a href="http://forums.miranda-im.org/showthread.php?t=20060" target="_blank">HELP</a>.
  <table border="1">
  <tr>
    <td colspan="2"><nobr>Your mail:</nobr></td>
    <td><input name="from" type="text" value="<? echo mb_CSettingGet(null, 'Webi-mail', 'from');?>"/></td>
  </tr>
  <tr>
    <td colspan="2"><nobr>SMTP-Server:</nobr></td>
    <td><input name="smtp-host" type="text" value="<? echo mb_CSettingGet(null, 'Webi-mail', 'smtp-host');?>"/></td>
  </tr>
  <tr>
    <td colspan="2">Server port:</td>
    <td><input name="port" type="text" value="<? echo mb_CSettingGet(null, 'Webi-mail', 'smtp-port');?>"/></td>
  </tr>
  <tr>
    <td colspan="3"><input type="checkbox" name="auth" value="1" <? if(mb_CSettingGet(null, 'Webi-mail', 'smtp-auth')==1){ echo 'checked="checked"';}?>/>
      use authentification</td>
  </tr>
  <tr>
    <td width="10">&nbsp;</td>
    <td width="77">username:</td>
    <td><input name="user" type="text" value="<? echo mb_CSettingGet(null, 'Webi-mail', 'smtp-user');?>"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>password:</td>
    <td><input name="pass" type="password" <? if(mb_CSettingGet(null, 'Webi-mail', 'smtp-user')!=false){ echo 'value="***"';}?>/></td>
  </tr>
</table>
  <input type="submit" value="Save" />
</form>
<?
//callback for menue
function sendMail($param,$cid,$hmenu)
{
	if(mb_CSettingGet(NULL,'Webi','b38')!=1){
		mt_setvar('webmail', 'off', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification off', null, 0x04, 'sendMail');
	}elseif(mt_getvar('webmail')==='off'){
		mt_setvar('webmail', 'on', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification on', null, 0x00, 'sendMail');
	}else{
		mt_setvar('webmail', 'off', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification off', null, 0x00, 'sendMail');
	}
}
?>