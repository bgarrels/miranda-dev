<?php
$FILE = strtolower(__FILE__);
$pos = strpos( $FILE, 'mbot\\www\\' );
$instdir = substr( $FILE, $pos+9);
$pos = strpos( $instdir, '\\' );
$instdir = substr( $instdir, 0, $pos);

if(mb_CSettingGet(NULL,'Webi','login')===false){
	echo translateString('You first have to set the protected settings over Mirnad -> Mainmenu -> Webi settings');
	exit;
}

if(isset($_SESSION['mobile']) && $_SESSION['mobile']){
	$addition = 'm';
}else{
	$addition = '';
}

$id = 0;
$readSTR[] = 0;
while( $id<40 ){
	if( mb_CSettingGet(NULL,'Webi','s'.$addition.$id)!==false ){
		$readSTR[$id] = mb_CSettingGet(NULL,'Webi','s'.$addition.$id);
	}else{
		$readSTR[$id] = " ";
	}
	$id++;
}

$id = 0;
$readBOOL[] = 0;
while($id<40){
	if( mb_CSettingGet(NULL,'Webi','b'.$addition.$id)===1 ){
		$readBOOL[$id] = 1;
	}else{
		$readBOOL[$id] = 0;
	}
	$id++;
}

settype($readSTR[1], "integer");
if($readSTR[1]<1)
	$readSTR[1] = -1;
define('AUTOREFRESH_CONTACTLIST', $readSTR[1]);
settype($readSTR[2], "integer");
if($readSTR[2]<1)
	$readSTR[2] = -1;
define('AUTOREFRESH_MESSAGES', $readSTR[2]);
if($readSTR[3]<1)
	$readSTR[3] = 10;
define('MESSAGES_PER_PAGE', $readSTR[3]);
define('OUT_PREFIX', $readSTR[4]);
define('IN_PREFIX', $readSTR[5]);
define('DATE_FORMAT', $readSTR[7]);
if($readSTR[9]<1)
	$readSTR[9] = 30;
define('AVATAR_MAX_SIZE', $readSTR[9]);
if($readSTR[10]<1)
	$readSTR[10] = 80;
define('AVATAR_QUALIY', $readSTR[10]);
define('NO_AVATAR_FILE', $readSTR[11]);
if($readSTR[12]<1)
	$readSTR[12] = 10;
define('SMILEY_MAX_SIZE', $readSTR[12]);
define('QUICK_BG', $readSTR[14]);
settype($readSTR[15], "integer");
define('SHORTEN_GROUP', $readSTR[15]);
settype($readSTR[16], "integer");
define('SHORTEN_NICK', $readSTR[16]);
if($readSTR[17]<1)
	$readSTR[17] = 1;
define('MAX_ROWS', $readSTR[17]);
if($readSTR[18]<1)
	$readSTR[18] = 1;
define('MAX_PER_ROW', $readSTR[18]);
define('SORT_BY', $readSTR[19]);
define('SORT_GROUPS_BY', $readSTR[20]);
settype($readSTR[21], "integer");
define('SOUND_TYPE', $readSTR[21]);
settype($readSTR[22], "integer");
define('SHOW_OLD_CONTACTS', $readSTR[22]);
settype($readSTR[23], "integer");
define('AUTOLOGOUT_AFTER', $readSTR[23]);
settype($readSTR[24], "integer");
if($readSTR[24]>365)
	$readSTR[24] = 10;
define('DAYS_LEFT', $readSTR[24]);
settype($readSTR[25], "integer");
define('JAVASCRIPT_NOTIFY', $readSTR[25]);
define('TT_BORDER', $readSTR[26]);
define('TT_BG', $readSTR[27]);
define('TT_COLOR', $readSTR[28]);
settype($readSTR[29], "integer");
define('TT_WIDTH', $readSTR[29]);


define('SHOW_SUBCONTACTS', $readBOOL[0]);
define('MARK_MESSAGES_AS_READ', $readBOOL[2]);
define('CHECK_FOR_UPDATE', $readBOOL[3]);
define('AUTO_UPDATE', $readBOOL[4]);
define('CAPTCHA_ENABLED', $readBOOL[6]);
define('AVATARS_ENABLED', $readBOOL[7]);
define('SHOW_NEWS', $readBOOL[8]);
define('USE_SMILEYS', $readBOOL[9]);
define('USE_SPECIFIC_SMILEYS', $readBOOL[10]);
define('SMILEYS_WITH_WHITESPACE_ONLY', $readBOOL[11]);
define('REPLY_ON_TOP', $readBOOL[12]);
define('FILES_ENABELED', $readBOOL[13]);
define('QUICK_REPLY_INCLUDE', $readBOOL[14]);
define('SINGLE_LINE_REPLY', $readBOOL[15]);
define('QUICK_ON_TOP', $readBOOL[16]);
define('SHOW_AWAY', $readBOOL[17]);
define('SHOW_XSTAT', $readBOOL[18]);
define('ENABLE_X_STATUS_SET', $readBOOL[19]);
define('OWN_NICK_SET', $readBOOL[20]);
define('SPLIT_BY_USERS', $readBOOL[21]);
define('GROUPS', $readBOOL[22]);
define('XSTAT_ICONS', $readBOOL[23]);
define('NEWS_TABS', $readBOOL[24]);
define('TABS', $readBOOL[25]);
define('CLOSE_TABS', $readBOOL[26]);
define('SOUND_ON', $readBOOL[27]);
define('LOCK_ON_LOGIN', $readBOOL[28]);
define('LOCK_ON_LOGIN_LOCAL', $readBOOL[29]);
define('DONOT_DESTROY', !$readBOOL[30]);
define('SHOW_BDAY', $readBOOL[31]);
define('ONE_ICON', $readBOOL[32]);
define('QUICK_REPLY_ON', $readBOOL[33]);
define('REFRESH_AVATAR', $readBOOL[34]);
define('TOOLTIP_ON', $readBOOL[35]);
define('IE_TOOLTIP', $readBOOL[36]);
define('OTR', $readBOOL[37]);
define('MOBILE_ON', !$readBOOL[38]);
define('LOG', $readBOOL[39]);

//define user/password
if(mb_CSettingGet(NULL,'Webi','login')===1)
	$val = true;
else
	$val = false;
define('LOGIN_ENABLED', mb_CSettingGet(NULL,'Webi','login'));
define('USER', mb_CSettingGet(NULL,'Webi','user'));
define('PASSWORD', mb_CSettingGet(NULL,'Webi','pass'));

if(mb_CSettingGet(NULL,'Webi','autoaccept')===1)
	$val = false;
else
	$val = true;
define('DISABLE_AUTO_ACCEPT_FILES_SETTING', $val);
if(mb_CSettingGet(NULL,'Webi','remote')===1)
	$val = false;
else
	$val = true;
define('DISABLE_REMOTE_SEND_FILES', $val);

if(file_exists('inc/settings/ignoredprotos.txt')){
	$allprotos = mb_SysEnumProtocols();
	$proigno[]='';
	if($allprotos!=null){
		$found = 0;
		for($i=0;$found<count($allprotos);$i++){
			if(isset($allprotos[$i])){
				$allprotos[$i]=strtolower($allprotos[$i]);
				$found++;
			}
		}
		$text = file('settings/ignoredprotos.txt', FILE_USE_INCLUDE_PATH);
		foreach($text as $line){
			if(in_array(strtolower(trim($line)), $allprotos)){
				$proigno[] = strtolower(trim($line));
			}
		}
	}
}else{
	$proigno[]='';
}
define('IGNORED_PROTO', serialize($proigno));

//do not end with slash
define('INSTALLATION_DIRECTORY', $instdir);

$encodable = mb_list_encodings();
$valid = false;
foreach($encodable as $codepack){
	if(strtolower($codepack)==strtolower($readSTR[0])){
		$valid = true;
		break;
	}
}
if(!$valid){
	define('CHARSET_REPLY', 'iso-8859-1');
	$readSTR[0] = 'iso-8859-1';
	$page = substr($_SERVER['PHP_SELF'],0,strpos($_SERVER['PHP_SELF'], '.'));
	if($page!='index' && $page!='login' && $page!='setup' && $page!='settings')
		redirectToLocal('setup.php');
}else
	define('CHARSET_REPLY', $readSTR[0]);
?>