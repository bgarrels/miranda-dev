<?
function icon($cid){
	if( mb_CGetStatus($cid)!= "" && mb_CGetStatus($cid)!= "0" ){
		$status = mb_CGetStatus($cid);
	}else{
		$status = ID_STATUS_OFFLINE;
	}
	$border = border($cid);
	$proto = mb_CGetProto($cid);
	$xid = mb_CSettingGet($cid,'ICQ', 'XStatusId');
	if(mb_EventFindFirstUnread($cid)!=""){
		$ico = 'fotos/other/message.png';
		if(!defined('NEW_MESSAGE_ARRIVED'))
			define('NEW_MESSAGE_ARRIVED', true);
	}elseif(ONE_ICON && XSTAT_ICONS && strtolower($proto)=='icq' && $xid!=0 && $xid!=false && file_exists('fotos\\status\\icq\\xstatus\\Icon_'.$xid.'.ico')){
		$ico = 'fotos/status/icq/xstatus/Icon_'.$xid.'.ico';
		if($border=='style="border-color:#FF00FF;" border="1"')
			$border='border="0"';
	}elseif(file_exists('fotos\\status\\'.$proto.'\\'.$status.'.png')){
		$ico = 'fotos/status/'.$proto.'/'.$status.'.png';
	}else{
		if(file_exists('fotos\\status\\default\\'.$status.'.png'))
			$ico = 'fotos/status/default/'.$status.'.png';
		else
			$ico = 'fotos/status/default/unknown.png';
	}
	$ico2='';
	if(!ONE_ICON && XSTAT_ICONS && strtolower($proto)=='icq' && $xid!=0 && $xid!=false && file_exists('fotos\\status\\icq\\xstatus\\Icon_'.$xid.'.ico')){
		$ico2 = '<img alt="" border="0" src="fotos/status/icq/xstatus/Icon_'.$xid.'.ico"/>';
		if(!ONE_ICON && $border=='style="border-color:#FF00FF;" border="1"')
			$border='border="0"';
	}
	$ico = '<img alt="" src="'.$ico.'" '.$border.'/> '.$ico2.' ';
	return $ico;
}

function border($cid){
	$border = 'border="0"';
	$proto = strtolower(mb_CGetProto($cid));
	$xid = mb_CSettingGet($cid,'ICQ', 'XStatusId');
	if($proto=='icq'){
		if(mb_CSettingGet($cid,'ICQ', 'SrvPermitId') && mb_CSettingGet($cid,'ICQ', 'SrvPermitId')!=0){
			$border = 'style="border-color:#00FF00;" border="1"';
		}elseif(mb_CSettingGet($cid,'ICQ', 'SrvDenyId') && mb_CSettingGet($cid,'ICQ', 'SrvDenyId')!=0){
			$border = 'style="border-color:#FF0000;" border="1"';
		}elseif(mb_CSettingGet($cid,'ICQ', 'TemporaryVisible')==1){
			$border = 'style="border-color:#FFFF00;" border="1"';
		}elseif($xid!=0){
			$border = 'style="border-color:#FF00FF;" border="1"';
		}
	}elseif($proto=='msn'){
		if(mb_CSettingGet($cid,'MSN', 'ApparentMode'))
			$border = 'style="border-color:#FF0000;" border="1"';
	}
	return $border;
}