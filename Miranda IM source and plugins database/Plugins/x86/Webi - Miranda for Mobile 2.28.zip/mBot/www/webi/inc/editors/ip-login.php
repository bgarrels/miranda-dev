<?
if(!isset($secure) || $secure!==true){
	die();
}
if(isset($_POST['way1']) &&  isset($_POST['user']) && isset($_POST['pass']) && $_POST['user'] == USER && crypt($_POST['pass'], PASSWORD) == PASSWORD){
	$out = '';
	for($x=1; $x<6; $x++){
		if(isset($_POST['akt'.$x])){
			mb_CSettingAdd(null, 'Webi', DBVT_ASCIIZ, 'acco1'.$x, $_POST['way'.$x]);
			if($_POST['way'.$x]=='ip')
				$out .= '<tr><td>IP:</td><td>'.$_POST['ip'.$x].'</td></tr>';
			elseif($_POST['way'.$x]=='dns')
				$out .= '<tr><td>Domain:</td><td>'.$_POST['ip'.$x].'</td></tr>';
		}else{
			mb_CSettingAdd(null, 'Webi', DBVT_ASCIIZ, 'acco1'.$x, $_POST['way'.$x].'-');
		}
		mb_CSettingAdd(null, 'Webi', DBVT_ASCIIZ, 'acco2'.$x, trim($_POST['ip'.$x]));
	}
	if($out!=''){
		echo 'The following IPs will be logged in without password:<br><table border="1">'.$out.'</table>';
	}else
		echo 'No auto-login-IPs selected';
	
}elseif(isset($_POST['user']) && isset($_POST['pass']) && $_POST['user'] == USER && crypt($_POST['pass'], PASSWORD) == PASSWORD){
function select($what, $x){
	$way = mb_CSettingGet(NULL,'Webi','acco1'.$x);
	if($what==$way)
    	echo ' selected="selected"';
	elseif($what==substr($way, 0, -1))
    	echo ' selected="selected"';
}
function check($x){
	if('ip'==mb_CSettingGet(NULL,'Webi','acco1'.$x) || 'dns'==mb_CSettingGet(NULL,'Webi','acco1'.$x))
    	echo ' checked="checked"';
}
?>
<form method="post" action="">
Please enter the IPs/Domains to log in automatically:<br/>
<font size="2">current ip: <? echo $_SERVER['REMOTE_ADDR'];?></font>
<table border="1">
<input type="hidden" name="user" value="<? echo $_POST['user'];?>"/>
<input type="hidden" name="pass" value="<? echo $_POST['pass'];?>"/>
  <tr>
    <td width="20"><input name="akt1" type="checkbox" value="1" <? check(1);?>/></td>
    <td width="82"><select name="way1">
      <option value="ip"<? select('ip', 1);?>>IP</option>
      <option value="dns"<? select('dns', 1);?>>Domain</option>
      </select></td>
    <td><input name="ip1" type="text" value="<? echo mb_CSettingGet(NULL,'Webi','acco21');?>"/></td>
  </tr>
  <tr>
    <td><input type="checkbox" name="akt2" value="1" <? check(2);?>/></td>
    <td><select name="way2">
      <option value="ip"<? select('ip', 2);?>>IP</option>
      <option value="dns"<? select('dns', 2);?>>Domain</option>
    </select></td>
    <td><input name="ip2" type="text" value="<? echo mb_CSettingGet(NULL,'Webi','acco22');?>"/></td>
  </tr>
  <tr>
    <td><input type="checkbox" name="akt3" value="1"<? check(3);?>/></td>
    <td><select name="way3">
      <option value="ip"<? select('ip', 3);?>>IP</option>
      <option value="dns"<? select('dns', 3);?>>Domain</option>
    </select></td>
    <td><input name="ip3" type="text" value="<? echo mb_CSettingGet(NULL,'Webi','acco23');?>"/></td>
  </tr>
  <tr>
    <td><input type="checkbox" name="akt4" value="1" <? check(4);?>/></td>
    <td><select name="way4">
      <option value="ip"<? select('ip', 4);?>>IP</option>
      <option value="dns"<? select('dns', 4);?>>Domain</option>
    </select></td>
    <td><input name="ip4" type="text" value="<? echo mb_CSettingGet(NULL,'Webi','acco24');?>"/></td>
  </tr>
  <tr>
    <td><input type="checkbox" name="akt5" value="1" <? check(5);?>/></td>
    <td><select name="way5">
      <option value="ip"<? select('ip', 5);?>>IP</option>
      <option value="dns"<? select('dns', 5);?>>Domain</option>
    </select></td>
    <td><input name="ip5" type="text" value="<? echo mb_CSettingGet(NULL,'Webi','acco25');?>"/></td>
  </tr>

  <tr>
    <td colspan="3"><input type="submit" value="Save" /></td>
  </tr>
</table>
</form>
	<?
}else{
	?>
	<form action="" method="post">
	<table width="390" border="0">

		<tr>
			<td style="font-weight:bold"><?php echo translateString('User'); ?>:</td>
			<td><input type="text" id="user" name="user" maxlength="20" size="30" /></td>
		</tr>
		<tr>
			<td style="font-weight:bold"><?php echo translateString('Password'); ?>:</td>
			<td><input type="password" name="pass" maxlength="255" size="30" /></td>
		</tr>
		<tr>
			<td colspan="2" style="text-align:center">
				<input type="submit" value="<?php echo translateString('send'); ?>" />
			</td>
		</tr>
	</table>
	<?
}
?>