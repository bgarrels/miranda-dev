<?
function bdayicon($cid, $proto){
	$days = daysleft($cid, $proto);
	if($days !== false && $days <= DAYS_LEFT){
		if(file_exists('fotos/bday/'.$days.'.png'))
			return '<font><img border="0" alt="'.$days.'" src="fotos/bday/'.$days.'.png"/>';
		elseif($days<10)
			return '<nobr><img border="0" alt="" src="fotos/bday/other.png"/><font style="position: relative; top: -3px; left: -12px;"><b>'.$days.' </b></font></nobr><font style="position: relative; top: 0px; left: -12px;">';
		else
			return '<nobr><img border="0" alt="" src="fotos/bday/other.png"/><font style="position: relative; top: -3px; left: -16px;"><b>'.$days.' </b></font></nobr><font style="position: relative; top: 0px; left: -16px;">';
	}else{
		return '<font>';
	}
}

function daysleft($cid, $proto){
	$by = mb_CSettingGet($cid, $proto, 'BirthYear');
	if($by > date('Y'))
		return false;
	$bd = mb_CSettingGet($cid, $proto, 'BirthDay');
	$bm = mb_CSettingGet($cid, $proto, 'BirthMonth');
	if($bd!==false && $bm!==false){
		$bdstamp = strtotime($bm.'/'.$bd.'/'.date('Y'));
		$current = time();
		if($bdstamp + 86400 < $current)
			$bdstamp = strtotime($bm.'/'.$bd.'/'.date('Y', $current + 30758400));
		$tmp = $bdstamp + 86400 - $current;
		$days = ($tmp - fmod($tmp, 86400)) / 86400;
		return $days;
	}else{
		return false;
	}
}

function bday($cid, $proto){
	$by = mb_CSettingGet($cid, $proto, 'BirthYear');
	if($by > date('Y'))
		return false;
	$bd = mb_CSettingGet($cid, $proto, 'BirthDay');
	$bm = mb_CSettingGet($cid, $proto, 'BirthMonth');
	if($bd!==false && $bm!==false && $by!==false)
		return $bd.'.'.$bm.'.'.$by;
}

function age($cid, $proto){
	$by = mb_CSettingGet($cid, $proto, 'BirthYear');
	if($by > date('Y'))
		return false;
	$bd = mb_CSettingGet($cid, $proto, 'BirthDay');
	$bm = mb_CSettingGet($cid, $proto, 'BirthMonth');
	if($bd!==false && $bm!==false && $by!==false){
		$age = date('Y')-$by;
		$bdstamp = strtotime($bm.'/'.$bd.'/'.date('Y'));
		$current = time();
		$tmp = $bdstamp + 86400 - $current;
		$days = ($tmp - fmod($tmp, 86400)) / 86400;
		if($days>0)
			$age--;
		return $age;
	}
}
?>