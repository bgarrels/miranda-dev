<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Webi - Miranda Mobile</title>
<?
if(file_exists('inc/user.css')){
	echo '<link rel="stylesheet" type="text/css" media="screen" href="inc/user.css">';
}else{
//td.contact, td.group, a.group, div.stattxt, span.out, span.in, span.date, table.clist, td.top, table.top
	?>
	<style type="text/css">
	<!--
	a {color: #0000FF;}
	table.top{ border-width:0px; border-bottom: 1px solid #000000; width:100%;}
<? if(strpos($_SERVER['PHP_SELF'], "clist.php") !== FALSE){?>
	td.group { background:#E0E0E0; border-width:2px; border-style: ridge; border-collapse: collapse; font-size:14px;}
	table.clist { border-width:2px; border-style: ridge; border-collapse: collapse;}
	td.contact { text-align: left;}
<? }elseif(strpos($_SERVER['PHP_SELF'], "contact.php") !== FALSE){?>
	div.stattxt {font-size:12px;font-style:italic;}
	span.out {color:#990000;font-weight:bold;}
	span.in {color:#000000;font-weight:bold;}
	span.date {font-size:10px;font-style:italic;}
<? } ?>
	-->
	</style>
	<?
}
if(strpos($_SERVER['PHP_SELF'], "clist.php") !== FALSE && AUTOREFRESH_CONTACTLIST >= 0)
	printHTML('<meta http-equiv="refresh" content="'.AUTOREFRESH_CONTACTLIST.'" />');
else if(strpos($_SERVER['PHP_SELF'], "contact.php") !== FALSE && !isset($_GET["search"]) && AUTOREFRESH_MESSAGES >= 0)
	printHTML('<meta http-equiv="refresh" content="'.AUTOREFRESH_MESSAGES.'" />');
else if(strpos($_SERVER['PHP_SELF'], "otr.php") !== FALSE && !isset($_GET["search"]) && AUTOREFRESH_MESSAGES >= 0)
	printHTML('<meta http-equiv="refresh" content="5" />');
?>