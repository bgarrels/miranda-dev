<?
$sorted = null;
$tmp = null;
if(!$hidden){
	if(SORT_BY == 'nick'){
		foreach($groups[$currentGroup] as $key => $cid){
			if($key!='total' && $key!='online' && $key!=0)
				$tmp[$cid] = strtolower($contact['nick'][$cid]);
		}
		asort($tmp);
		foreach($tmp as $key => $value){
			$sorted[0][] = $key;
		}
	}elseif(SORT_BY == 'proto'){
		foreach($groups[$currentGroup] as $key => $cid){
			if($key!='total' && $key!='online' && $key!=0)
				$tmp[$cid] = $contact['proto'][$cid];
		}
		asort($tmp);
		foreach($tmp as $key => $value){
			$sorted[0][] = $key;
		}
	}elseif(SORT_BY == 'status'){
		foreach($groups[$currentGroup] as $key => $cid){
			if($key!='total' && $key!='online' && $key!=0)
				$tmp[$contact['status'][$cid]][] = $cid;
		}

		$stat = 'news';
		while(isset($sorthelp[$stat])){
			if(isset($tmp[$sorthelp[$stat]][0])){
				foreach($tmp[$sorthelp[$stat]] as $cid){
					$sorted[0][] = $cid;
				}
			}
			if($stat == 'news')
				$stat = 1;
			else
				$stat++;
		}
	}elseif(SORT_BY == 'last'){
		foreach($groups[$currentGroup] as $key => $cid){
			if($key!='total' && $key!='online' && $key!=0){
				$hid = mb_EventFindLast($cid);
				if($hid == null || $hid == false || $hid == '' || $hid == '0'){
					$time = 0;
				}else{
					$message = mb_EventGetData($hid, 0);
					if($message === false)
						$time = 0;
					else
						$time = $message[2];
				}
				$tmp[$cid] = $time;
			}
		}
		arsort($tmp, SORT_NUMERIC);
		foreach($tmp as $key => $value){
			$sorted[0][] = $key;
		}
	}else{
		foreach($groups[$currentGroup] as $key => $cid){
			if($key!='total' && $key!='online' && $key!=0)
				$sorted[0][] = $cid;
		}
	}
}else{
	foreach($groups[$currentGroup] as $key => $cid){
		if($key!='total' && $key!='online' && $key!=0){
			if(mb_EventFindFirstUnread($cid)!="")
				$sorted['news'][] = $cid;
		}
	}
}