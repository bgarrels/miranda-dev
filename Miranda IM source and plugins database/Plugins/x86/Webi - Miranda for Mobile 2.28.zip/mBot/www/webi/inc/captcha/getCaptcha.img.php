<?php
/*
(CC)2006-2007 Felipe Brahm
http://www.felipebrahm.com
*/

session_start();

$campoCaptcha = htmlentities($_GET["campoCaptcha"]);

if(strlen($campoCaptcha) == 0)
	$error = true; //Error: No seteaste la variable $campoCaptcha.
else
	$error = false;

$_SESSION[$campoCaptcha] = mt_rand(100, 499);

if(!$error)
	$filePath = 'imagenes/' . $_SESSION[$campoCaptcha] . '.jpg';
else
	$filePath = 'imagenes/error.jpg';

header('Content-type: image/jpg');
header('Content-Disposition: filename=' . mt_rand(0, 9999) . '.jpg');

readfile($filePath);
?>