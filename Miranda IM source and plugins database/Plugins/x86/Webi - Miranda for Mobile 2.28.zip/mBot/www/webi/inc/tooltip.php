<?
if(TOOLTIP_ON){

/*
*	finds additional info integer for variable
*/
	function getInteger($file, $variablename, $maxleng){
		$pos = strpos($file,$variablename);
		if($pos!==false){
			$lang = strlen($variablename);
			$pos2 = strpos($file,'%', $pos+$lang);
			if($pos2-$pos-$lang <= $maxleng){
				$max = trim(substr($file, $pos+$lang, $pos2-$pos-$lang));
				$maxtmp = $max;
				settype($max, 'Integer');
				if($maxtmp == $max && $max > 0 && $max!='')
					return $max;
				else
					return false;
			}else
				return false;
		}else
			return false;
	}
	
/*
*	raplaces if statemnts
*/
	function cleanupIF($file){
		
		$file = str_replace('( )', '()', $file);
		$pos = strpos($file,'if@()@{');
		while($pos!==false){
			$lang = strlen('if@()@{');
			$pos2 = strpos($file,'}@', $pos+$lang);
			if($pos2!==false)
				$file = substr($file,0,$pos).substr($file,$pos2+2);
			else
				break;
			$pos = strpos($file,'if@()@{');
		}
		$pos = strpos($file,'if@(');
		while($pos!==false){
			$lang = 3;
			$pos1 = strpos($file,')@{', $pos);
			$pos2 = strpos($file,'}@', $pos);
			if($pos1!==false && $pos2 !== false)
				$file = substr($file,0,$pos).substr($file,$pos1+3,$pos2-($pos1+3)).substr($file,$pos2+2);
			else
				break;
			$pos = strpos($file,'if@(');
		}
		return $file;
	}
/*
*	replaces variables for tooltips
*/
	function replace($str, $cid){
	$statusArray = array(
		ID_STATUS_OFFLINE => translateString("Offline"),
		0 => translateString("Offline"),
		false => translateString("Offline"),
		ID_STATUS_ONLINE => translateString("Online"),
		ID_STATUS_AWAY => translateString("Away"),
		ID_STATUS_DND => translateString("DND"),
		ID_STATUS_NA => translateString("NA"),
		ID_STATUS_OCCUPIED => translateString("Occupied"),
		ID_STATUS_FREECHAT => translateString("Free for chat"),
		ID_STATUS_INVISIBLE => translateString("Invisible"),
		ID_STATUS_ONTHEPHONE => translateString("On the phone"),
		ID_STATUS_OUTTOLUNCH => translateString("Out to lunch"),
		ID_STATUS_IDLE => translateString("Idle")
		
	);
	//proto
		$proto = mb_CGetProto($cid);
		$file = str_replace('%proto%', $proto , $str);
	//display name
		$nick = mb_CGetDisplayName($cid);
		$file = str_replace('%displayname%', ssm_encoding($nick) , $file);
	//nickname
		$file = str_replace('%nick%', ssm_encoding(mb_CGetInfo($cid, 3)), $file);
	//first+last name
		$file = str_replace('%name%', ssm_encoding(mb_CGetInfo($cid, 14)) , $file);
	//UIN
		$file = str_replace('%UIN%', ssm_encoding(mb_CGetInfo($cid, 15)), $file);
	//Status
		$file = str_replace('%status%', $statusArray[mb_CGetStatus($cid)] , $file);
	//bday
		$file = str_replace('%bday%', ssm_encoding(bday($cid, $proto)), $file);
		$file = str_replace('%bdayico%', bdayicon($cid, $proto).'</font>', $file);
		$file = str_replace('%age%', ssm_encoding(age($cid, $proto)), $file);
		$file = str_replace('%daysleft%', ssm_encoding(daysleft($cid, $proto)), $file);
	//icon
		$icon = icon($cid);
		$file = str_replace('%ico%', $icon, $file);
		$icon = str_replace('> <img alt=', '><font style="font-size: 1pt;"><br/><br/></font><img alt=', $icon);
		$file = str_replace('%icover%', $icon, $file);
	//lastmessage
		$max = getInteger($file,'%lastmessage%',2);
		$message = lastMessage($cid);
		if($message===false)
			$message = '';
		if($max!==false){
			if(strlen($message)>$max)
				$message = substr($message, 0, $max).'...';
			$file = str_replace('%lastmessage%'.$max.'%', $message, $file);
		}
		$file = str_replace('%lastmessage%', $message, $file);
	//lastmessagetime
		$file = str_replace('%lastmessagetime%', lastMessagetime($cid), $file);
	//statusmessage
		$max = getInteger($file,'%statusmessage%',2);
		$message = ssm_encoding(mb_CSettingGet($cid, 'CList', 'StatusMsg'));
		if($message===false)
			$message = '';
		if($max!==false){
			if(strlen($message)>$max)
				$message = substr($message, 0, $max).'...';
			$file = str_replace('%statusmessage%'.$max.'%', $message, $file);
		}
		$file = str_replace('%statusmessage%', $message, $file);
	//Xstatus
		if(strtolower($proto)=='icq'){
			$xstatus = ssm_encoding(mb_CSettingGet($cid,'ICQ', 'XStatusName'));
			$xstatusmess = ssm_encoding(mb_CSettingGet($cid,'ICQ', 'XStatusMsg'));
			if($xstatusmess===false)
				$xstatusmess = '';
			if($xstatus===false)
				$xstatus = '';
			$max = getInteger($file,'%xstatusmessage%',2);
			if($max!==false){
				if(strlen($xstatusmess)>$max)
					$xstatusmess = substr($xstatusmess, 0, $max).'...';
				$file = str_replace('%xstatusmessage%'.$max.'%', $xstatusmess, $file);
			}
		}else{
			$max = getInteger($file,'%xstatusmessage%',2);
			if($max!==false)
				$file = str_replace('%xstatusmessage%'.$max.'%', '', $file);
			$xstatus = '';
			$xstatusmess = '';
		}
		$file = str_replace('%xstatus%', $xstatus, $file);
		$file = str_replace('%xstatusmessage%', $xstatusmess, $file);
	//Version
		$version = ssm_encoding(mb_CSettingGet($cid, $proto, 'MirVer'));
		$pos1 = strpos($version,'(');
		$pos2 = strpos($version,'build');
		if($pos1!==false && $pos1<$pos2)
			$version = substr($version, 0, $pos1);
		elseif($pos2!==false && $pos2<$pos1)
			$version = substr($version, 0, $pos2);
		else
			$version = substr($version, 0, 20);
		$file = str_replace('%fingerprint%', $version, $file);
	//Style
		$file = str_replace('%tt-width%', TT_WIDTH, $file);
	//Group
		$file = str_replace('%group%', ssm_encoding(mb_CSettingGet($cid, 'CList', 'Group')), $file);
	//Avatar
		$pos = substr(__FILE__,0, strlen(__FILE__)-16);
		$pos = str_replace('\\','/',$pos);
		if(!REFRESH_AVATAR && file_exists($pos.'/fotos/avatars/'.$cid.'.jpg'))
			$pic = 'fotos/avatars/'.$cid.'.jpg';
		else
			$pic = 'getAvatar.img.php?cid='.$cid;
		$max = getInteger($file,'%avatarh%',3);
		if($max!==false)
			$file = str_replace('%avatarh%'.$max.'%', '<img alt="" height="'.$max.'" src="'.$pic.'" style="border: #000000 solid thin;" />' , $file);
		$max = getInteger($file,'%avatarw%',3);
		if($max!==false)
			$file = str_replace('%avatarw%'.$max.'%', '<img alt="" width="'.$max.'" src="'.$pic.'" style="border: #000000 solid thin;" />' , $file);
		$file = str_replace('%avatar%', '<img alt="" src="'.$pic.'" style="border: #000000 solid thin;" />' , $file);
		$file = cleanupIF($file);
		return $file;
	}
/*
*	returns last message
*/
	function lastmessage($cid){
		$hid = mb_EventFindLast($cid);
		do{
			if($hid === false || $hid === '' || $hid === 0){
				return translateString("No Message");
				break;
			}
			$msg = mb_EventGetData($hid, 0);
			list($module, $type, $timestamp, $flags, $body) = $msg;
			if($flags==READ || $flags==READ_UNICODE){
				if($flags != SENT_UNICODE && $flags != READ_UNICODE && $flags != READ_UNICODE_UNREAD)
					$body = ssm_encoding($body);				
				$body = nl2br(fixForHTML($body));
				return $body;
			}
		}while($hid = mb_EventFindPrev($hid));
	}

/*
*	returns date of last message
*/
	function lastmessagetime($cid){
		$hid = mb_EventFindFirstUnread($cid);
		if($hid!=""){
			$message = mb_EventGetData($hid, 0);
			$date = date(DATE_FORMAT,$message[2]);
			return fixForHTML(date(DATE_FORMAT,$message[2]));
		}
		$hid = mb_EventFindLast($cid);
		do{
			if($hid === false || $hid === '' || $hid === 0){
				return ssm_encoding("---");
				break;
			}
			$message = mb_EventGetData($hid, 0);
			if($message[3]==READ || $message[3]==READ_UNICODE){
				return fixForHTML(date(DATE_FORMAT,$message[2]));
			}
		}while($hid = mb_EventFindPrev($hid));
	}
	
/*
*	returns all new messages
*/
	function newmessages($cid){
		$hid = mb_EventFindFirstUnread($cid);
		$return['time'][0]='';
		$return['txt'][0]='';
		if($hid === false || $hid === '' || $hid === 0){
			return $return;
		}
		$msg = mb_EventGetData($hid, 0);
		list($module, $type, $timestamp, $flags, $body) = $msg;
		if($flags != SENT_UNICODE && $flags != READ_UNICODE && $flags != READ_UNICODE_UNREAD)
			$body = ssm_encoding($body);
		$return['txt'][0] = nl2br(fixForHTML($body));
		$return['time'][0]=fixForHTML(date(DATE_FORMAT,$timestamp));
		
		while($hid = mb_EventFindNext($hid)){
			$msg = mb_EventGetData($hid, 0);
			list($module, $type, $timestamp, $flags, $body) = $msg;
			if($flags != SENT_UNICODE && $flags != READ_UNICODE && $flags != READ_UNICODE_UNREAD)
				$body = ssm_encoding($body);
			$return['txt'][] = nl2br(fixForHTML($body));
			$return['time'][]=fixForHTML(date(DATE_FORMAT,$timestamp));
		}
		return $return;
	}

	include('tooltip.inc.php');
	
}else{
	function ToolTipLnk($str, $popup, $link){
		return '<a href="'.$link.'">'.$str.'</a>';
	}
	
	function ToolTip($str, $popup){
		return $str;
	}
	
	function MessageToolTip($cid){
		return '<img src="fotos/other/message.png" /> <a href="contact.php?cid='.$cid.'"><nobr>'.ssm_encoding(mb_CGetDisplayName($cid)).'</nobr></a>';
	}

	function ContactToolTip($cid){
		return '<b><nobr>'.ssm_encoding(mb_CGetDisplayName($cid)).'</nobr></b>';
	}
	
	function ClistToolTip($cid){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = substr($nick,0,SHORTEN_NICK-3).'...';
		else
			$echonick = $nick;
		$bd = '';
		if(SHOW_BDAY)
			$bd = bdayicon($cid, mb_CGetProto($cid));
		return '<nobr>'.icon($cid).$bd.'<a href="contact.php?cid='.$cid.'">'.$echonick.'</a></nobr>';
	}

	function TabToolTip($cid){
		$nick = ssm_encoding(mb_CGetDisplayName($cid));
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = substr($nick,0,SHORTEN_NICK-3).'...';
		else
			$echonick = $nick;
		return '<nobr>'.icon($cid).'<a href="contact.php?cid='.$cid.'">'.$echonick.'</a></nobr>';
	}
}
?>