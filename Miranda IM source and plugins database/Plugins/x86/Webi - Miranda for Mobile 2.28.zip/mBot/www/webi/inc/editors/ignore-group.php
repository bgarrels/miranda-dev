<?
if(!isset($secure) || $secure!==true){
	die();
}
if(isset($_POST['action'])){
	$fh = fopen('inc/settings/ignoredgroups.txt', 'w');
	$count=0;
	while(isset($_POST[$count])){
		
		if(isset($_POST[$_POST[$count]]))
			fwrite($fh, str_replace('%%__%%', ' ',$_POST[$count]).'
');
		$count++;
	}
	fclose($fh);
	echo translateString('Modification saved').'.<br/>';
}

if(file_exists('inc/settings/ignoredgroups.txt')){
	$tmp = file('inc/settings/ignoredgroups.txt');
	foreach($tmp as $line){
		$ignoredgroups[trim($line)] = true;
	}
	$tmp = '';
}
$cid = mb_CFindFirst();
echo '<br/>'.translateString('Mark all groups you want to hide in Clist').':<br/><form method="post" action=""><table><tr>';
$count=0;
do{
	$group = mb_CSettingGet($cid, 'CList', 'Group');
	if(isset($groups[$group]))
		continue;
	$groups[$group] = 1;
	$chk = "";
	if(isset($ignoredgroups['-'.$group]))
		$chk = ' checked="checked"';
	echo '<td><label><input type="checkbox" name="-'.str_replace(' ', '%%__%%',$group).'" value="1" '.$chk.'/> '.$group.' </label><input name="'.$count.'" type="hidden" value="-'.str_replace(' ', '%%__%%',$group).'" /></td>';
	echo '</tr><tr>';
	$count++;
} while($cid = mb_CFindNext($cid));
echo '<td><input type="submit" name="action" value="'.translateString('Save').'" /></td></tr></table></form>';
?>