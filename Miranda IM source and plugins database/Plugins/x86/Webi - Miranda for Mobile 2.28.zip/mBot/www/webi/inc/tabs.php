<?
$firsttime = true;
if(TABS && file_exists('inc/settings/opentabs.txt')){
	$opentabs = file('inc/settings/opentabs.txt');
	foreach($opentabs as $tabid){
		$tabid = trim($tabid);
		$ignoredcid[$tabid] = true;
	}
	$opentabs = null;
	if(isset($ignoredcid)){
		foreach($ignoredcid as $tabid => $value){
			$opentabs[] = $tabid;
		}
	}
}

if(NEWS_TABS){
	$tmpid = mb_CFindFirst();
	do{
		if($tmpid!=$cid && mb_EventFindFirstUnread($tmpid)!="" && !isset($ignoredcid[$tmpid])){
			$thisgroup = trim(mb_CSettingGet($tmpid, 'CList', 'Group'));
			if(GROUPS && !SHOW_NEWS &&(isset($_SESSION['hide-'.$thisgroup]) && $_SESSION['hide-'.$thisgroup]))
				continue;
			if($firsttime){
				echo '<table border="0"><tr>';
				$firsttime = false;
			}
			if(!defined('NEW_MESSAGE_ARRIVED'))
				define('NEW_MESSAGE_ARRIVED', true);
			echo '<td>'.MessageToolTip($tmpid).'</td>';
		}
	}while($tmpid = mb_CFindNext($tmpid));
}

if(TABS && isset($opentabs[0]) ){
	foreach($opentabs as $tabid){
		if($tabid == $cid || $tabid=='' || $tabid == 0)
			continue;
		if($firsttime){
			echo '<table border="0"><tr>';
			$firsttime = false;
		}
		$nick = mb_CGetDisplayName($tabid);
		if(SHORTEN_NICK > 4 && strlen($nick)>SHORTEN_NICK)
			$echonick = fixForHTML(ssm_encoding(substr($nick,0,SHORTEN_NICK-3).'...'));
		else
			$echonick = fixForHTML(ssm_encoding($nick));
		if(mb_EventFindFirstUnread($tabid)!="")
			echo '<td>'.MessageToolTip($tabid).' <a href="contact.php?close='.$tabid.'">X</a></td>';
		else
			echo '<td>'.TabToolTip($tabid).' <a href="contact.php?close='.$tabid.'">X</a></td>';
	}
}

if(!$firsttime)
	echo '</tr></table><hr/>';