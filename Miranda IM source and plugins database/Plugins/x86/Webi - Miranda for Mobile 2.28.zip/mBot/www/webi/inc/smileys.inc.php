<?
if( file_exists('inc/smileys/default/search.txt') && file_exists('inc/smileys/default/replace.txt') ){
	if( file_exists('inc/smileys/'.mb_CGetProto($cid).'/search.txt') && file_exists('inc/smileys/'.mb_CGetProto($cid).'/replace.txt') && USE_SPECIFIC_SMILEYS)
		$smileypack = mb_CGetProto($cid);
	else
		$smileypack = 'default';
	$smileyreplace = file('inc/smileys/'.$smileypack.'/replace.txt');
	$smileysearch = file('inc/smileys/'.$smileypack.'/search.txt');
	$line = 0;
	$smileynum = 0;
	while( isset($smileyreplace[$line]) && isset($smileysearch[$line]) ){
		$smiley = trim($smileysearch[$line]);
		$replace = trim($smileyreplace[$line]);
		if( $smiley != "" && $replace != "" ){
			$smileyarray['search'][$smileynum] = $smiley;
			if( file_exists('inc/smileys/'.$smileypack.'/'.$replace)){
				$imagesize = getimagesize('inc/smileys/'.$smileypack.'/'.$replace);
				if( $imagesize[0]>=$imagesize[1] && $imagesize[0]>=SMILEY_MAX_SIZE )
					$smileyarray['replace'][$smileynum] = '<img src="inc/smileys/'.$smileypack.'/'.$replace.'" width="'.SMILEY_MAX_SIZE.'" alt="'.$smiley.'"/>';
				elseif( $imagesize[1]>=$imagesize[0] && $imagesize[1]>=SMILEY_MAX_SIZE )
					$smileyarray['replace'][$smileynum] = '<img src="inc/smileys/'.$smileypack.'/'.$replace.'" height="'.SMILEY_MAX_SIZE.'" alt="'.$smiley.'"/>';
				else
					$smileyarray['replace'][$smileynum] = '<img src="inc/smileys/'.$smileypack.'/'.$replace.'" alt="'.$smiley.'"/>';
			}else{
				$smileyarray['replace'][$smileynum] = '!!!!could not find: inc/smileys/'.$smileypack.'/'.$replace.'!!! originally: '.$smiley;
			}
			$smileynum++;
		}
		$line++;
	}
}else
	echo "smileypack NOT found.";