<?php

if(file_exists('tmp') && $_SERVER['PHP_SELF']!='echofile.php'){
	$dirhand = dir('tmp');
	while($file = $dirhand->read()){
		if($file != '.' && $file != '..'){
			unlink('tmp/'.$file);
		}
	}
	$dirhand ->close();
	rmdir('tmp');
}	
if(mb_CSettingGet(NULL,'Webi','login')===false){
	echo "You first have to set the secure settings over Mirnad -> Mainmenue -> Webi settings";
	exit;
}
@session_start();

if(LOGIN_ENABLED && (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME]!=USER)) {
	redirectToLocal('index.php');
	exit;
}

if(mt_getvar('disable-Webi')) {
	redirectToLocal('login.php?log=out');
	exit;
}

if(LOGIN_ENABLED && AUTOLOGOUT_AFTER > 0 && $_SESSION['lastactiontime'] + AUTOLOGOUT_AFTER * 60 < time()) {
	redirectToLocal('login.php?log=out');
	exit;
}

if(LOGIN_ENABLED && isset($_SESSION['logouttime']) && $_SESSION['logouttime'] < time()) {
	redirectToLocal('login.php?log=out');
	exit;
}
if(LOGIN_ENABLED && (!isset($_SESSION['ipcode']) || $_SESSION['ipcode'] != mt_getvar('webicode'))){
	redirectToLocal('login.php?log=out');
	exit;
}

$_SESSION['lastactiontime'] = time();
?>