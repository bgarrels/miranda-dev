<?
include('clistsortgroups.php');

$count = 0;
$row = 0;
$rownum = 1;
while( isset($groupsort[$count])){
	$currentGroup = $groupsort[$count];
	if(!isset($groups[$currentGroup]['total']) || isset($ignoredgroups['-'.$currentGroup]) || $groups[$currentGroup]['total']==0){
		$count++;
		continue;
	}
  if(!($groups[$currentGroup]['online']==0 && !$all)){
  	$hidden = false;
  	if( isset($_SESSION['hide'.$currentGroup]) && $_SESSION['hide'.$currentGroup] )
		$hidden = true;
	include('clistsort.groups.php');
	if(SHORTEN_GROUP > 4 && strlen($currentGroup)>SHORTEN_GROUP)
		$echocurrentGroup = substr($currentGroup,0,SHORTEN_GROUP-3).'...';
	else
		$echocurrentGroup = $currentGroup;
	$row++;
	echo '<tr><td align="left" class=group><b><nobr><a class=group href="clist.php?hide='.$currentGroup.'&amp;activ='.$hidden.'">'.fixForHTML(ssm_encoding($echocurrentGroup)).' ('.$groups[$currentGroup]['online'].'/'.$groups[$currentGroup]['total'].')</a></nobr></b></td></tr>';
	$statusnum = 0;
	if($row>=$maxperrow && $rownum < $maxrows){
		$row = 0;
		$rownum++;
		echo '</table></td><td align="center" class="contact" valign="top"><table class=clist><tr><td align="left"><table border="0">';
	}elseif($row>=$maxperrow){
		$row = 0;
		$rownum++;
	}else{
		echo '<tr><td class="contact"><table border="0">';
	}
	$stat = 0;
	if( $hidden && SHOW_NEWS)
		$stat = 'news';
	if(isset($sorted[$stat][0])){
		foreach($sorted[$stat] as $cid){
			if( ($contact['status'][$cid] != ID_STATUS_OFFLINE || $all) && !isset($ignore[$cid])){
				if($maxperrow/2 > $row)
					$over = false;
				else
					$over = true;
				echo '<tr><td width="3" class="contact">&nbsp;</td><td class=contact>'.clistToolTip($cid, $rownum, $over).'</font></td></tr>';
				$row++;
				if($contact['proto'][$cid]=='MetaContacts' && SHOW_SUBCONTACTS){
					$meta = 0;
					while( mb_CSettingGet($cid, 'MetaContacts', 'Handle'.$meta)!=""){
						$metacid = mb_CSettingGet($cid, 'MetaContacts', 'Handle'.$meta);
						if($maxperrow/2 > $row)
							$over = false;
						else
							$over = true;
						if($contact['status'][$metacid]!=ID_STATUS_OFFLINE || $all){
							echo '<tr><td width="3" class="contact">&nbsp;</td><td class="contact"><img src="fotos/other/blank.gif" width="13">'.clistToolTip($metacid,$rownum,$over).'</font></td></tr>';
							$row++;
						}
						$meta++;
					}
				}
				if($row>=$maxperrow && $rownum < $maxrows){
					$row = 0;
					$rownum++;
					echo '</table></td></tr></table></td><td align="center" valign="top"><table class=clist><tr><td class=contact><table border="0">';
				}elseif($row>=$maxperrow){
					$row = 0;
					$rownum++;
				}
			}
		}
	}
	$count++;
	echo '</table></td></tr>';
  }else{
  	$count++;
  }
}