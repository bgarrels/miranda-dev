<?
if(isset($include)){
	if(JAVASCRIPT_NOTIFY==1 && defined('NEW_MESSAGE_ARRIVED')){
		echo '<script type="text/javascript">
		notify();
		function notify (){
			if(typeof focused == "undefined"){
				this.focus();
			}
		}</script>';
	}elseif(JAVASCRIPT_NOTIFY==2 && defined('NEW_MESSAGE_ARRIVED')){
		echo '<script type="text/javascript">
		notify();
		function notify (){
			if(typeof focused == "undefined"){
				fenster=window.open("inc/notify.php", "notify", "width=200,height=200");
			}
		}</script>';
	}elseif(JAVASCRIPT_NOTIFY==3 && defined('NEW_MESSAGE_ARRIVED')){
		echo '<script type="text/javascript">
		notify();
		function notify (){
			if(typeof focused == "undefined"){
				alert("You have a message!!!");
			}
		}</script>';
	}
}else{
	echo '<a href="#" onclick="window.opener.focus();self.close();">You have a new message!!!</a>';
	echo '<script type="text/javascript">this.focus();</script>';
}
?>