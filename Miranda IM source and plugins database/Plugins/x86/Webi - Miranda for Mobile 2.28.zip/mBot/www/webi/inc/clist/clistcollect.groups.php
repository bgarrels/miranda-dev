<?
//$contact stores cid([$cid][++]), nick /protocoll/status (['nick/proto/status'][$cid])
//$groups stores name of groups( [++][0]), total/online contact ([$groupname]['total/online']
//$groupsort stores user per group and status ([$groupname][$status][++])
//$ignore stores the cid of metacontact subcontacts ([$cid])
$cid = mb_CFindFirst();
$metaamounton = 0;
$metaamounttot = 0;
do{
	if(mb_CSettingGet($cid, 'CList', 'Hidden')!=false)
		continue;
	if( mb_CGetProto($cid)!="" && !in_array(strtolower(mb_CGetProto($cid)),unserialize(IGNORED_PROTO))){
		$contact['cid'][] = $cid;
		$contact['nick'][$cid] = mb_CGetDisplayName($cid);
		$contact['proto'][$cid] = mb_CGetProto($cid);
		
		if( mb_EventFindFirstUnread($cid)!=""){
			$contact['status'][$cid]='news';
		}elseif( mb_CGetStatus($cid)!= "" && mb_CGetStatus($cid)!= "0" ){
			$contact['status'][$cid] = mb_CGetStatus($cid);
		}else{
			$contact['status'][$cid] = ID_STATUS_OFFLINE;
		}
		
		
		if($contact['proto'][$cid] == 'MetaContacts'){
			$meta = 0;
			while( mb_CSettingGet($cid, 'MetaContacts', 'Handle'.$meta)!=""){
				$metacid = mb_CSettingGet($cid, 'MetaContacts', 'Handle'.$meta);
				if(mb_CSettingGet($metacid, 'CList', 'Hidden')!=false)
					continue;
				$usergroup = '-'.mb_CSettingGet($metacid, 'CList', 'Group');
				if( !isset($groups[$usergroup]) ){
					$groups[][] = $usergroup;
					$groups[$usergroup][0] = 0;
					$groups[$usergroup]['total'] = 0;
					$groups[$usergroup]['online'] = 0;
				}
				$groups[$usergroup]['total']--;
				$metaamounttot++;
				if( mb_CGetStatus($metacid) != ID_STATUS_OFFLINE && mb_CGetStatus($metacid)!=0 && mb_CGetStatus($metacid)!=''){
					$metaamounton++;
					$groups[$usergroup]['online']--;
				}
				$ignore[$metacid] = true;
				$meta++;
			}
		}
		
		$usergroup = '-'.mb_CSettingGet($cid, 'CList', 'Group');
		if( !isset($groups[$usergroup]) ){
			$groups[][] = $usergroup;
			$groups[$usergroup][0] = 0;
			$groups[$usergroup]['total'] = 0;
			$groups[$usergroup]['online'] = 0;
		}
		$groups[$usergroup][] = $cid;
		
		$groups[$usergroup]['total']++;
		if( $contact['status'][$cid] != ID_STATUS_OFFLINE ){
			$groups[$usergroup]['online']++;
		}
	}
} while($cid = mb_CFindNext($cid));

$count = 0;
$amounttoshow = 0;
while( isset($groups[$count][0])){
	if(!isset($ignoredgroups['-'.$groups[$count][0]])){
		if($all){
			if($groups[$groups[$count][0]]['total']>0)
				$amounttoshow += $groups[$groups[$count][0]]['total']+1;
		}else{
			if($groups[$groups[$count][0]]['online']>0)
				$amounttoshow += $groups[$groups[$count][0]]['online']+1;
		}
	}
	$count++;
}
if(SHOW_SUBCONTACTS && $all)
	$amounttoshow += $metaamounttot;
elseif(SHOW_SUBCONTACTS)
	$amounttoshow += $metaamounton;