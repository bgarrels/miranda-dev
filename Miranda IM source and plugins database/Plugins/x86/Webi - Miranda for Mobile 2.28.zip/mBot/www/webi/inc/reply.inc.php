<?php
if( !isset($_GET['what']) || $_GET['what']=='chat'){
	printHTML('<div align="left">'.translateString('Writing').':');
	
	printHTML('<form name="send" method="post" action="contact.php?cid='.$cid.'">');

	printHTML('<input type="hidden" name="action" value="sendMessage"/>');

	printHTML('<input type="hidden" name="cid" value="'.$cid.'"/>');
	if(!SINGLE_LINE_REPLY)
		printHTML('<textarea id="body" name="body" cols="55" rows="5"></textarea>');
	else
		printHTML('<input id="body" name="body" type="text" size="55"/>');
	printHTML('<br /><br />');
	printHTML('<input name="send" value="'.translateString('Send').'" type="submit"/></form>');
	printHTML('<br />');

	printHTML('</div>');

}elseif( $_GET['what']=='quick' ){
	if(!file_exists('inc/settings/quickreply.txt')){
		echo 'inc/settings/quickreply.txt '.trandlateString('is missing. Create a new one under quickreply settings.').'<br /><a href="contact.php?cid='.$cid.'" target="_TOP">'.translateString('back').'</a>';
		exit;
	}
	echo '<div align="left">';
	echo '<form method="post" action="contact.php?cid='.$cid.'" target="_TOP">';
	echo '<input type="hidden" name="cid" value="'.$cid.'"/><input type="hidden" name="action" value="sendMessage"/>';

	echo '<table><tr><td><div align="left">';
	$file = file('inc/settings/quickreply.txt');
	$count = 0;
	$breakline = false;
	foreach($file as $reply){
		if($breakline==true){
			$breakline = false;
			echo '</div></td></tr><tr><td><div align="left">';
		}
		$reply = trim($reply);
		if($reply==''){
		}elseif($reply=='!!!breakline!!!'){
			$breakline=true;
		}else{
			echo ' <input type="submit" name="body" style="background:'.QUICK_BG.';" value="'.$reply.'"/> ';
		}
		$count++;
	}
	echo '</div></td></tr></table></form></div>';
}elseif( $_GET['what']=='file' ){
	if(!empty($_FILES["uploaded_file"]) && $_FILES['uploaded_file']['error'] == 0){
		if(file_exists('../uploaded') && !is_dir('../uploaded')){
			echo 'there is a problem';
		}elseif(!file_exists('../uploaded')){
			mkdir('../uploaded');
		}
		$uploaded = str_replace(' ', '',$_FILES['uploaded_file']['name']);
		$uploaded = str_replace('=', '',str_replace('#', '',$uploaded));
		$uploaded = str_replace('&', '',$uploaded);
		
		copy($_FILES['uploaded_file']['tmp_name'],'../uploaded/'.str_replace(' ', '',$uploaded));
		if(!file_exists('../uploaded/'.ssm_encoding($uploaded))){
			$uploaded = $_FILES['uploaded_file']['name'];
			$type = substr($uploaded, strrpos($uploaded,'.'));
			$uploaded = 'sendfile'.$type;
			copy($_FILES['uploaded_file']['tmp_name'],'uploaded/'.$uploaded);
		}
		$host = file("http://legoking.le.funpic.de/webi/getip.php");
		echo translateString('File is redy to be send');
		echo '<form method="post" target="_TOP" action="contact.php?cid='.$cid.'">';
		echo '<input type="hidden" name="cid" value="'.$cid.'"/>';
		echo '<input type="hidden" name="action" value="sendMessage"/>';
		echo '<input type="hidden" name="body" value="http://'.$host[0].':'.$_SERVER["REMOTE_PORT"].'/uploaded/'.$uploaded.'"/>';
		echo '<input type="submit" value="'.translateString('Send File').'"/></form>';
	}elseif(isset($_FILES['uploaded_file']['error'])){
		echo translateString('Error: No file uploaded');
	}else{
		echo '<form enctype="multipart/form-data" method="post" action="">'.translateString('Choose a file you want to send').':<br /><input name="uploaded_file" type="file"/><br /><input type="submit" value="Upload"/>';
		if(!DISABLE_REMOTE_SEND_FILES)
			echo ' <a href="remotesend.php?cid='.$cid.'">'.translateString('Send files located on the Webi Host').'</a>';
		echo '</form><br/>';
	}
}elseif( $_GET['what']=='search' ){
	printHTML('<div align="left">'.translateString('Search').':');
	
	printHTML('<form name="send" method="get" action="contact.php" />');

	printHTML('<input type="hidden" name="cid" value="'.$cid.'" />');
	printHTML('<input type="hidden" name="what" value="search" />');
	if(!SINGLE_LINE_REPLY)
		printHTML('<textarea id="body" name="search" cols="55" rows="5"></textarea>');
	else
		printHTML('<input id="body" name="search" type="text" size="55"/>');

	printHTML('<br /><br />');

	printHTML('<input value="'.translateString('Search').'" type="submit" />');

	printHTML('</div>');
}else{
	echo 'undefined page';
}
?>