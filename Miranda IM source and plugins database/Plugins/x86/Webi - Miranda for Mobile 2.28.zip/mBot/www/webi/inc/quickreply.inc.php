<?
if(!file_exists('inc/settings/quickreply.txt')){
	echo trandlateStringAdv('%s is missing. Create a new one under quickreply settings.','inc/settings/quickreply.txt').'<br /><a href="contact.php?cid='.$cid.'" target="_TOP">'.translateString('back').'</a>';
	exit;
}
echo '<div align="left">';
echo '<form method="post" action="contact.php?cid='.$cid.'">';
echo '<input type="hidden" name="cid" value="'.$cid.'"/><input type="hidden" name="action" value="sendMessage"/>';
echo '<table><tr><td><div align="left">';
$file = file('inc/settings/quickreply.txt');
$breakline = false;
foreach($file as $reply){
	if($breakline==true){
		$breakline = false;
		echo '</div></td></tr><tr><td><div align="left">';
	}
	$reply = trim($reply);
	if($reply==''){
	}elseif($reply=='!!!breakline!!!'){
		$breakline=true;
	}else{
		echo ' <input type="submit" name="body" style="background:'.QUICK_BG.';" value="'.$reply.'"/> ';
	}
}
echo '</div></td></tr></table></form></div>';
?>