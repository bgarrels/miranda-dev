<?php
/*******************************************************************************
 *
 * souFrag Site Manager
 * (CC)2006-2007 Felipe Brahm
 *
 * http://www.felipebrahm.com
 *
 *******************************************************************************
 */
@session_start();

if(isset($_POST['mobilesetting']) && mb_CSettingGet(NULL,'Webi','m39')!=1)
	$_SESSION['mobile'] = true;
else
	$_SESSION['mobile'] = false;

require('inc/comun.inc.php');

/*
*	deleting avatar cach
*/
if(file_exists('fotos/avatars/')){
	$dirhand = dir('fotos/avatars/');
	while($file = $dirhand->read()){
		if($file != '.' && $file != '..'){
			unlink('fotos/avatars/'.$file);
		}
	}
	$dirhand ->close();
}

/*
*	Logout
*/
if(isset($_GET['log']) && $_GET['log'] == 'out') {
	if(DONOT_DESTROY)
		unset($_SESSION[SESSION_NAME]);
	else{	
		if (isset($_COOKIE[session_name()]))
			setcookie(session_name(), '', time()-42000, '/');
		session_destroy();
	}
	writeLog('logout');
	redirectToLocal('index.php?logout=1');
	exit;
}

if(mt_getvar('disable-Webi')) {
	redirectToLocal('login.php?log=out');
	exit;
}

/*
*	Login entered
*/
if(isset($_POST['user']) && isset($_POST['pass'])) {

	if(CAPTCHA_ENABLED) {
		require('inc/captcha/verificarCaptcha.inc.php');
		if($blnCaptcha != true)
			redirectToLocal('index.php');
	}
	
	if(LOCK_ON_LOGIN && (!LOCK_ON_LOGIN_LOCAL || $_SERVER['REMOTE_ADDR']!='127.0.0.1')){
		$addr = mb_SysGetProcAddr('user32.dll','LockWorkStation');
		mb_SysCallProc($addr,'','','','','','');
	}
	
	if($_POST['user'] == USER && crypt($_POST['pass'], PASSWORD) == PASSWORD) {
		$_SESSION[SESSION_NAME] = USER;
		$ran = rand(100000, 999999);
		mt_setvar('webicode', $ran.$_SERVER['REMOTE_ADDR'], 1, 0);
		$_SESSION['ipcode'] = $ran.$_SERVER['REMOTE_ADDR'];
		$_SESSION['lastactiontime'] = time();
		if(isset($_POST['logintimer'])){
			$time = time() + 60 * $_POST['minutes'] + 3600 * $_POST['hours'];
			$_SESSION['logouttime'] = $time;
			writeLog('login for '.$_POST['hours'].':'.$_POST['minutes']);
		}else{
			writeLog('login');
		}
		if(isset($_GET['redir']) && $_GET['redir']!="")
			redirectToLocal($_GET['redir']);
		else
			redirectToLocal('clist.php');
		exit;	
	}
	
	writeLog('login failed with user "'.$_POST['user'].'" and password length '.strlen($_POST['pass']));
	
/*
*	change mobile settings
*/
}elseif(isset($_SESSION[SESSION_NAME]) && $_SESSION[SESSION_NAME] == USER){
	if(isset($_GET['mobilesetting']) && $_GET['mobilesetting']=='on' && MOBILE_ON)
		$_SESSION['mobile'] = true;
	else
		$_SESSION['mobile'] = false;
	redirectToLocal('clist.php');
	exit;

/*
*	login over ip
*/
}elseif(isset($_GET['iplogin'])){
	$sucessful = false;
	for($x=1; $x<6; $x++){
		$way = mb_CSettingGet(NULL,'Webi','acco1'.$x);
		$ip = mb_CSettingGet(NULL,'Webi','acco2'.$x);
		if($way=="ip" && $ip==$_SERVER['REMOTE_ADDR']){
			$sucessful=true;
			break;
		}elseif($way=="dns" && gethostbyname($ip)==$_SERVER['REMOTE_ADDR'] && $ip!=$_SERVER['REMOTE_ADDR']){
			$sucessful=true;
			break;
		}
	}
	if($sucessful==true){
		writeLog('login over '.$way.' with user '.$ip);
		$_SESSION[SESSION_NAME] = USER;
		$ran = rand(100000, 999999);
		mt_setvar('webicode', $ran.$_SERVER['REMOTE_ADDR'], 1, 0);
		$_SESSION['ipcode'] = $ran.$_SERVER['REMOTE_ADDR'];
		$_SESSION['lastactiontime'] = time();
		if(isset($_POST['logintimer'])){
			$time = time() + 60 * $_POST['minutes'] + 3600 * $_POST['hours'];
			$_SESSION['logouttime'] = $time;
		}
		if(isset($_GET['redir']) && $_GET['redir']!="")
			redirectToLocal($_GET['redir']);
		else
			redirectToLocal('clist.php');
		exit;
	}
	writeLog('login failed over ip');
}

mb_MsgBox('On '.date("l, d. M Y").' at '.date("H:i:s").' user with IP '.$_SERVER['REMOTE_ADDR'].' (mBot may have read ip wrong), used invalid login fow webi.','Warning: Invalid login for webi', 0);
redirectToLocal('index.php');


function writeLog($text){
	if(LOG){
		$hand = fopen(mb_SysGetMirandaDir().'/mbot/webilog.txt','a');
		$time = date('d.M.y - H:i:s ');
		if(!fwrite($hand, '
'.$time.$text)){
			mb_ConsoleShow(1);
			mb_Echo('
webi could not write to log ('.$text.')', 0);
		}
		fclose($hand);
	}
}
?>