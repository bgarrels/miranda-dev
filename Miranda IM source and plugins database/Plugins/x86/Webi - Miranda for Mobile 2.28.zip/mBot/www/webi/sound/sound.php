<?
if(SOUND_TYPE=='1')
	echo '<embed src="sound/message.mid" autostart="true" loop="false" volume="100" hidden="true" />';
elseif(SOUND_TYPE=='2')
	echo '<embed src="sound/message.wav" autostart="true" loop="false" volume="100" hidden="true" />';
elseif(SOUND_TYPE=='3')
	echo '<embed src="sound/message.mp3" type="audio/x-mpeg" width="0" height="0" />';
else
	echo '<object width="0" height="0" data="sound/playsound.swf?soundFile=sound/message.mp3" type="application/x-shockwave-flash"><param name="movie" value="sound/playsound.swf?soundFile=sound/message.mp3"></object>';