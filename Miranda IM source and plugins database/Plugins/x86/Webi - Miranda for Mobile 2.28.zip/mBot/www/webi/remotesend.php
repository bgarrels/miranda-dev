<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
* originally based on Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*
*/
include("inc/comun.inc.php");
include('inc/security.inc.php');

if(isset($_GET['folderadd']) && isset($_GET['foldername']) && $_GET['folderadd'] != ""){
	$handle = fopen('inc/settings/shortcuts.txt', 'a');
	fwrite($handle, trim(urldecode($_GET['folderadd'])).'
'.trim(urldecode($_GET['foldername'])).'
');
	fclose($handle);
	redirectToLocal('remotesend.php?cid='.$_GET['cid']);
}

include('inc/header.inc.php');
if(isset($_GET['file']))
	echo '<script type="text/javascript">function send(){ document.file.submit(); }</script></head><body onload="send()">';
else
	echo '</head><body>';
	
if(!isset($_GET['cid']) || mb_CGetDisplayName($_GET['cid'])===false || mb_CGetDisplayName($_GET['cid'])==translateString('(Unknown Contact)')){
	echo translateString('No or invalid Contact specified.');
	exit;
}
$status = mb_CGetStatus($cid);
$proto = mb_CGetProto($cid);

if(file_exists('fotos\\status\\'.$proto.'\\'.$status.'.png'))
	$ico = 'fotos/status/'.$proto.'/'.$status.'.png';
else {
	if(file_exists('fotos\\status\\default\\'.$status.'.png'))
		$ico = 'fotos/status/default/'.$status.'.png';
	else
		$ico = 'fotos/status/default/'.$status.'.png';
}
if( mb_EventFindFirstUnread($cid)!=""){
	$ico = 'fotos/other/message.png';
}
$border = "";
if(strtolower($proto)=='icq'){
	if(mb_CSettingGet($cid,'ICQ', 'SrvPermitId') && mb_CSettingGet($cid,'ICQ', 'SrvPermitId')!=0){
		$border = 'style="border-color:#00FF00;" border="1"';
	}elseif(mb_CSettingGet($cid,'ICQ', 'SrvDenyId') && mb_CSettingGet($cid,'ICQ', 'SrvDenyId')!=0){
		$border = 'style="border-color:#FF0000;" border="1"';
	}elseif(mb_CSettingGet($cid,'ICQ', 'TemporaryVisible')==1){
		$border = 'style="border-color:#FFFF00;" border="1"';
	}
}
$icon = '<img alt="" src="'.$ico.'" '.$border.'/>';

$nick = mb_CGetDisplayName($cid);

printHTML('<table class=top>');
printHTML('<tr>');
printHTML('<td class=top><div align="left"><a href="clist.php">'.translateString('CList').'</a> |');
printHTML(' <a href="contact.php?cid='.$cid.'">'.translateString('Reload').'</a> |');
printHTML(' <a href="contact.php?cid='.$cid.'&amp;what=chat">'.translateString('Reply').'</a> |');
if(!QUICK_REPLY_INCLUDE)
	printHTML(' <a href="contact.php?cid='.$cid.'&amp;what=quick">'.translateString('Quick Reply').'</a> |');
if(FILES_ENABELED)
	printHTML(' <a href="contact.php?cid='.$cid.'&amp;what=file">'.translateString('Send').' '.translateString('File').'</a> |');
printHTML(' <a href="contact.php?cid='.$cid.'&amp;what=search">'.translateString('Search').'</a></div></td>');
printHTML('<td class=top><div align="right"><b>'. fixForHTML(ssm_encoding($nick)) .'</b> '.$icon.'</div></td>');
printHTML('</tr>');
printHTML('</table><br/>');

if(DISABLE_REMOTE_SEND_FILES){
	echo translateString('This function has been disabeled.').'<br/>'.translateString('To enable it, change the settings in Miranda -> Mainmenu -> Webi Settings');
	exit;
}

$cid = ($_GET['cid']);
if(isset($_GET['file'])){
	$path = urldecode($_GET['file']);
	if(!file_exists($path) || is_dir($path) || !is_readable($path)){
		echo translateString('This file could not be send.');
		exit;
	}
	$file = substr($path, strrpos('/'.$path,'/'));
	$file = str_replace(' ', '',$file);
	$file = str_replace('=', '',str_replace('#', '',$file));
	$file = str_replace('&', '',$file);
	$type = substr($file, strrpos($file,'.'));
	
	if(file_exists('../uploaded') && !is_dir('../uploaded')){
		echo translateString('there is a problem');
		exit;
	}elseif(!file_exists('../uploaded')){
		mkdir('../uploaded');
	}
	
	copy($path,'../uploaded/'.$file);
	if(!file_exists('../uploaded/'.ssm_encoding($file))){
		$file = 'sendfile'.$type;
		copy($path,'uploaded/'.$file);
	}
	$host = file("http://legoking.le.funpic.de/webi/getip.php");
	echo translateString('File is redy to be send');
	echo '<form method="post" name="file" target="_TOP" action="contact.php?cid='.$cid.'">';
	echo '<input type="hidden" name="cid" value="'.$cid.'"/>';
	echo '<input type="hidden" name="action" value="sendMessage"/>';
	echo '<input type="hidden" name="body" value="http://'.$host[0].':'.$_SERVER["REMOTE_PORT"].'/uploaded/'.$file.'"/>';
	echo '<input type="submit" value="'.translateString('Send File').'"/></form>';
	
}elseif(isset($_GET['dir']) && $_GET['dir']!=""){
	$dir = strtolower(mb_convert_encoding(urldecode($_GET['dir']),CHARSET_REPLY,"UTF-8"));
	$dir = str_replace('\\', '/', $dir);
	if(strrpos($dir,'/')+1<strlen($dir))
		$dir = $dir.'/';
	if(isset($_GET['add'])){
		echo '<table border="0"><tr><td>'.translateString('Select a name for this folder').':</td><td><form method="get" action=""><lable><input name="cid" type="hidden" value="'.$cid.'" /><input name="folderadd" type="hidden" value="'.$dir.'" /><input name="foldername" type="text" size="20" /> <input type="submit" value="save" /></label></form></td></tr><tr><td>';
		echo translateString('Current location').':</td><td><b>'.mb_convert_encoding($dir,"UTF-8",CHARSET_REPLY).'</b></td></tr></table>';
	}else
		echo '<form method="get" action=""><input name="cid" type="hidden" value="'.$cid.'" /><label>'.translateString('Current location').': <input name="dir" type="text" value="'.mb_convert_encoding($dir,"UTF-8",CHARSET_REPLY).'" size="55" /> <input type="submit" value="Go" /> <a href="remotesend.php?cid='.$cid.'&amp;add=1&amp;dir='.urlencode($dir).'">'.translateString('Save as Shortcut').'</a></label></form>';
	if(strlen($dir)>3){
		$lowerdir = substr($_GET['dir'], 0,strrpos('/'.$_GET['dir'],'/',-2));
		echo '<img alt="up" src="fotos/files/up.gif"/><a href="remotesend.php?dir='.$lowerdir.'&amp;cid='.$cid.'">'.translateString('Upper direcory').'</a><br />';
	}else{
		echo '<img alt="up" src="fotos/files/up.gif"/><a href="remotesend.php?cid='.$cid.'">'.translateString('change drive').'</a><br />';
	}
	if(!is_dir($dir) || !is_readable($dir)){
	echo translateString('Sorry, the given folder does not exist or acces was denied').'.<br/><a href="remotesend.php?cid='.$cid.'">'.translateString('select drive').'</a>';
	exit;
	}
	$dirhand = dir($dir);
	while($file = $dirhand->read()){
		if($file != '.' && $file != '' && $file != '..' && strtolower($file) != '$recycle.bin' && strtolower($file) != 'recycler' && strtolower($file) != 'system volume information' && strtolower($file) != 'pagefile.sys'  && strtolower($file) != 'system volume information'){
			if(is_dir($dir.$file)){
				echo '<img alt="dir" src="fotos/files/dir.gif"/> <a href="remotesend.php?dir='.urlencode(mb_convert_encoding($dir.$file,"UTF-8",CHARSET_REPLY)).'&amp;cid='.$cid.'">'.fixForHTML(ssm_encoding($file)).'</a><br />';
			}else{
				echo '<img alt="file" src="fotos/files/file.gif"/> <a href="remotesend.php?file='.urlencode(mb_convert_encoding($dir.$file,"UTF-8",CHARSET_REPLY)).'&amp;cid='.$cid.'">'.fixForHTML(ssm_encoding($file)).'</a><br />';
			}
		}
	}
	$dirhand ->close();
}else{
	echo '<form method="get" action=""><input name="cid" type="hidden" value="'.$cid.'" /><label>'.translateString('Current location').': <input name="dir" type="text" size="55" /> <input type="submit" value="Go" /></label></form>';

	if(file_exists('inc/settings/shortcuts.txt')){
		$file = file('inc/settings/shortcuts.txt');
		$count = 0;
		$ignoredrive[] = '';
		while(isset($file[$count])){
			$shortcut = trim($file[$count]);
			if(strlen($shortcut)<4){
				$ignoredrive[strtolower(substr($shortcut,0,1))] = true;
				$shortcut = substr($shortcut,0,1).':';
			}
			if(isset($file[$count+1]) && trim($file[$count+1])!="" && strlen($shortcut)<4)
				$name = trim($file[$count+1]).' ('.strtoupper($shortcut).')';
			elseif(isset($file[$count+1]) && trim($file[$count+1])!="")
				$name = trim($file[$count+1]);
			else
				$name = $shortcut;
			if($shortcut!='')
				echo '<img alt="dir" src="fotos/files/dir.gif"/> <a href="remotesend.php?dir='.$shortcut.'&amp;cid='.$cid.'">'.$name.'</a><br />';
			$count += 2;
		}
	}
	$letters =array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
	foreach($letters as $letter){
		if(is_dir($letter.':/') && !isset($ignoredrive[$letter]))
			echo '<img alt="dir" src="fotos/files/dir.gif"/> <a href="remotesend.php?dir='.$letter.':&amp;cid='.$cid.'">'.$letter.':</a><br />';
	}
}
include('inc/end.inc.php');
?>