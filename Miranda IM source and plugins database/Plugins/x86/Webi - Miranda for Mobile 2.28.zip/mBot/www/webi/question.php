<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');
if(mb_CSettingGet(null, 'Webi', 'question')>=2026){
	redirectToLocal('clist.php');
}elseif(isset($_POST['final'])){
	//collect legal data and send
	$data['amount']=$_POST['usageAmount'];
	$data['tool']=$_POST['usageTool'];
	$data['x']=$_POST['resolutionX'];
	$data['y']=$_POST['resolutionY'];
	$data['mobile']=$_POST['mobile'];
	
	$boolean[]='';
	$str[]='';
	if(isset($_POST['agree'])){
		for($i=0; $i<=37; $i++){
			$boolean[$i] = $readBOOL[$i];
		}
		for($i=17; $i<=25; $i++){
			$str[$i] = $readSTR[$i];
		}
	}
	$file = file('http://legoking.le.funpic.de/webi/answer.php?ver=2026&data='.serialize($data).'&bool='.serialize($boolean).'&str='.serialize($str).'&com='.$_POST['comments']);
	if(trim($file[0])=='sucess'){
		mb_CSettingAdd(null, 'Webi', DBVT_WORD, 'question', 2026);
		redirectToLocal('clist.php');
	}else{
		echo 'Sorry, an error occured. We will try next time. <a href="clist.php">Continue</a>';
	}
	
}elseif(isset($_POST['answer']) && $_POST['answer']=='later'){
	redirectToLocal('clist.php');
}elseif(isset($_POST['answer']) && $_POST['answer']=='now'){
	include("inc/header.inc.php");
?>
<form method="post" action="">
Thank you for choosing to help.<br>
leave blank what ever you are unsure or don't want to answer.<br>
<table width="70%" border="1">
  <tr>
    <td>I use Webi 
      <input name="usageAmount" type="text" size="4" maxlength="3">
      times a month</td>
  </tr>
  <tr>
    <td>I am mainly using Webi from 
      
      <select name="usageTool">
        <option value=""selected>-----</option>
        <option value="1">a personal PC</option>
        <option value="2">a public PC</option>
        <option value="3">a mobile</option>
        <option value="4">other</option>
      </select>
      <br>
      with resolution 
      <input name="resolutionX" type="text" size="6" maxlength="4" > 
      X
      <input name="resolutionY" type="text" size="6" maxlength="4" >      </td>
    </tr>
  <tr>
    <td><label>
      <input name="mobile" type="checkbox" />
      I sometimes use the Mobile Settings</label></td>
  </tr>
  <tr>
    <td><label>
      <input name="agree" type="checkbox" checked="checked" />
      I agree to send information about basic Webi settings</label></td>
  </tr>
  <tr>
    <td>Further comments/ ideas/ problems:<br>
      <label>
        <textarea name="comments" cols="40" rows="5"></textarea>
      </label></td>
    </tr>
  <tr>
    <td><label>
      <input type="submit" name="final" value="Submit">
      <a href="clist.php">cancel      </a></label></td>
    </tr>
</table>

</form>
  <?
	echo '</body></html>';
}else{
	include("inc/header.inc.php");
?>
  Dear Webi user. To make further development more effective, I am asking you to fill out a short questionary about your usage of Webi. <br>
NO SENSITIVE DATA will be transfered.<br>
Data will be stored ANONYMOUSLY and only for analysis.
<form method="post" action="">
<p>Choose when you want to fill out the questionary: <br>
  <input type="submit" name="answer" value="now">
  <input type="submit" name="answer" value="later">
</p>
</form>
<?
	echo '</body></html>';
}
?>
