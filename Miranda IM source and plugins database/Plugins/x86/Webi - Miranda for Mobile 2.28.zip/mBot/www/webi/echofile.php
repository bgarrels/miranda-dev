<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
* originally based on Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*
*/
include("inc/comun.inc.php");
include('inc/security.inc.php');

$dir = mb_CSettingGet(0, 'SRFile', 'RecvFilesDirAdv');
if($dir === false){
	echo translateString("No destination for incomed files specified in Miranda DB");
	exit;
}
$dir = strtolower($dir);
$dir = str_replace('%miranda_path%', mb_SysGetMirandaDir(), $dir);
$dir = str_replace('%userprofile%', substr(mb_SysGetProfileName(), 0,strrpos(mb_SysGetProfileName(),'.')), $dir);
if(strpos($dir, '%proto%')!==false){
	$pos = strpos($dir, '%proto%');
	$dir = substr($dir, 0 , $pos);
}
if(strpos($dir, '%nick%')!==false){
	$pos = strpos($dir, '%nick%');
	$dir = substr($dir, 0 , $pos);
}
if(strpos($dir, '%userid%')!==false){
	$pos = strpos($dir, '%userid%');
	$dir = substr($dir, 0 , $pos);
}
$dir = str_replace('\\', '/', $dir);
if(strrpos($dir,'/')+1<strlen($dir))
	$dir = $dir.'/';

$path = strtolower(mb_convert_encoding($_GET['file'],CHARSET_REPLY,"UTF-8"));
$file = substr($path, strrpos('/'.$path,'/'));
$type = substr($file, strrpos($file,'.'));

if(!file_exists($dir.$path)){
	echo translateString("This file does not exist!!!");
	exit;
}
mkdir('tmp');
if($type=='.php')
	$type = '.txt';
copy($dir.$path,'tmp/tmp'.$type);
redirecttolocal('tmp/tmp'.$type);
include('inc/end.inc.php');