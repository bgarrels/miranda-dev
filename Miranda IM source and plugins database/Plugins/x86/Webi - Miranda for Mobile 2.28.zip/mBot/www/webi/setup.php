<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');

echo translateString('Please aprove the choices made by Webi').':';
?>
<form method="post" action="settings.php">
<table border="0">
  <tr>
    <td><? echo translateString('Charset to be used:');?></td>
    <td><input name="str0" type="text" value="iso-8859-1" /></td>
  </tr>
  <tr>
    <td><? echo translateString('notify on new updates');?></td>
    <td><input name="bool3" type="checkbox" value="1" checked="checked"/>
    <input type="hidden" name="existbool3" value="1"/></td>
  </tr>
  <tr>
    <td colspan="2"><input name="change" type="submit" value="<? echo translateString('save');?>"/></td>
  </tr>
</table>
</form>
<?
include("inc/end.inc.php");
?>