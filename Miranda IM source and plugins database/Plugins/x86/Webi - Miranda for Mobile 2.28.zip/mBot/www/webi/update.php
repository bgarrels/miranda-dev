<?
include("inc/comun.inc.php");
include('inc/security.inc.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update</title>
<script type="text/javascript">
function reload()
{
  document.reload.submit();
}
</script>
</head>
<body onload="reload()">
<?
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/

if( file_exists('version.txt')){
	$version = file('version.txt');
	if(isset($version[1]))
		$version = trim($version[1]);
	else
		$version = trim($version[0]);
}else{
	$version = 0;
}
$listFile = "http://legoking.le.funpic.de/webi/webiupdate27.php?ver=".$version;
$listh = fopen($listFile, 'r');
$amount = fgets($listh);
if($amount=='X'){
	echo translateString('You need to visit the').' <a href="http://legoking.le.funpic.de/webi/index.php">updatepage</a> '.translateString('for updates').'.';
	exit;
}	

$amount = trim($amount);
settype($amount, 'int');
$startat = 0;
if( isset($_GET['reload'])){
	$startat = trim($_GET['reload']);
	settype($startat, 'int');
	for($i=0;$i<$startat;$i++){
		$file = fgets($listh);
	}
}
$amount -= $startat;
if($amount<0)
	$amount = 0;
$count = 0;
$error = 0;
echo $amount.' '.translateString('actions will be executed').'.<br />';
while($count<$amount){
	$file = fgets($listh);
	if(substr($file, 0, 5)=='mkdir'){
		if(file_exists(trim(substr($file, 6)))){
			echo 'Folder '.substr($file, 6).' '.translateString('already existed').'.<br />';
		}else{
			if( !mkdir(trim(substr($file, 6))) ){
				echo translateString('ERROR creating Foler').' '.substr($file, 6).'<br />';
				$error = 1;
			}else{
				echo 'Folder '.substr($file, 6).' '.translateString('created').'<br />';
			}
		}
	}elseif(substr($file, 0, 5)=='break'){
		if($error == 1){
			echo '<b>'.translateString('An error occured. It will not be continued to keep webi working.').'<br /></b>';
			$amount = 0;
		}
	}elseif(substr($file, 0, 6)=='script'){
		$dest = trim(mb_SysGetMirandaDir().'/mbot/scripts/autoload'.substr($file, strrpos($file, '/')));
		$file = str_replace(' ', '%20',trim(substr($file, 7)));
		if( !copy($file, $dest) ){
			echo translateString('failed to update').' '.$dest.'<br />';
			$error = 1;
		}else{
			echo $dest.' '.translateString('was updated').'<br />';
		}
	}elseif(substr($file, 0, 6)=='reload'){
		if($error == 1){
			echo '<b>'.translateString('An error occured. It will not be continued to keep webi working.').'<br /></b>';
			$amount = 0;
		}else{
			$count++;
			$count += $startat;
			echo translateString('Update engin was updatet').'. <a href="update.php?reload='.$count.'">'.translateString('continue').'</a><form id="reload" name="reload" method="get" action=""><input type="hidden" name="reload" id="hiddenField" value="'.$count.'"/></form>';
			exit;
		}
	}elseif(substr($file, 0, 7)=='nextver'){
		$count++;
		$count += $startat;
		echo translateString('Next Version reached. Reload needed to ensure working').'. <a href="update.php?reload='.$count.'">'.translateString('continue').'</a><form id="reload" name="reload" method="get" action=""><input type="hidden" name="reload" id="hiddenField" value="'.$count.'"/></form>';
		exit;
	}elseif(substr($file, 0, 5)=='check'){
		$file = trim(substr($file, 5));
		$pos = strrpos($file, 'webi/') +5;
		$pos = strpos($file, '/', $pos) +1;
		$dest = substr($file, $pos);
		if(file_exists($dest)){
			echo translateString('no action necessary').'<br/>';
		}else{
			if( !copy($file, $dest) ){
				echo translateString('failed to update').' '.$dest.'<br />';
				$error = 1;
			}else{
				echo $dest.' '.translateString('was updated').'<br />';
			}
		}
	}elseif(substr($file, 0, 6)=='setvar'){
		$var = trim(substr($file, 6,strpos($file,' ',7)-6));
		$setto = trim(substr($file, strpos($file,' ',7)));
		mt_setvar($var, $setto, 1, 0);
	}elseif(substr($file, 0, 6)=='delete'){
		$file = trim(substr($file, 6));
		if(file_exists($file)){
			unlink($file);
			echo translateString('Cleaned up').'<br/>';
		}else{
			echo translateString('no action necessary').'<br/>';
		}
	}else{
		$file = trim($file);
		$pos = strrpos($file, 'webi/') +5;
		$pos = strpos($file, '/', $pos) +1;
		$dest = substr($file, $pos);
		if( !copy($file, $dest) ){
			echo translateString('failed to update').' '.$dest.'<br />';
			$error = 1;
		}else{
			echo $dest.' '.translateString('was updated').'<br />';
		}
	}
	$count++;
}
fclose($listh);
if( $error == 1 || $listh==''){
	echo '<br/><br/>'.translateString('An error occured').'.<br /><a href="http://legoking.le.funpic.de/webi/index.php">'.translateString('Manual Update').'</a><br /><a href="index.php?noupdate=1">'.translateString('Continue with old version').'</a>';
}else{
	$file = file("http://legoking.le.funpic.de/webi/webineed.php?ver=".$version);
	echo trim($file[0]);
	echo translateString('Sucessfully updated').'<br /><a href="index.php">'.translateString('continue').'</a>';
	$versionnum = "http://legoking.le.funpic.de/webi/webiupdate27.php";
	$vnumh = fopen($versionnum, 'r');
	$newnum = trim(fgets($vnumh));
	fclose($vnumh);
	$versionh = fopen('version.txt', 'w');
	fwrite( $versionh, $newnum.'
'.$newnum);
}
?>
</body>
</html>
