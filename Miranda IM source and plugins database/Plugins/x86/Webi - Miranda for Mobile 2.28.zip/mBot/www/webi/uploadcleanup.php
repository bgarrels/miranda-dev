<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
* originally based on Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*
*/
include("inc/comun.inc.php");
include('inc/security.inc.php');

if(isset($_GET['doit'])){
	if(file_exists('../uploaded')){
		$dirhand = dir('../uploaded');
		while($file = $dirhand->read()){
			if($file != '.' && $file != '..'){
				unlink('../uploaded/'.$file);
			}
		}
		$dirhand ->close();
		rmdir('../uploaded');
	}
	redirecttolocal('clist.php');
}else{
	include('inc/header.inc.php');
	echo '</head><body>';
	$icon = 'fotos/status/default/'.ID_STATUS_ONLINE.'.png';
	printHTML('<table class=top><tr>');
	printHTML('<td class=top><div align="left">');
	printHTML('<a href="clist.php">'.translateString('CList').'</a>');
	printHTML('</div></td>');
	printHTML('<td class=top><div align="right" style="font-weight:bold;">Miranda IM <img alt="" src="'.$icon.'" /></div></td>');
	printHTML('</tr>');
	printHTML('</table>');
	
	echo '<br />'.translateString('If you continue, the people who did not download a file you sent to them yet, will not be able to download the file').'.<br />';
	echo '<a href="uploadcleanup.php?doit=go">'.translateString('continue').'</a>';
}
?>
</body>
</html>
