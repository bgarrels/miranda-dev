<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/
include("inc/comun.inc.php");
require_once('inc/security.inc.php');
?><?php

/* Apply xStatus */
if(isset($_POST['xStatusIcon'])){
	if($_POST['xStatusIcon']<=0 || $_POST['xStatusIcon']>24){
		mb_SysCallProtoService( 'ICQ', '/SetXStatus', 0, 0 );
	}else{
		$ico = $_POST['xStatusIcon'];
		settype($ico, 'int');
		mb_SysCallProtoService( 'ICQ', '/SetXStatus', $ico, 0 );
		mb_CSettingSet( null, 'ICQ', 'XStatusMsg', $_POST['xStatusBody'] );
		mb_CSettingSet( null, 'ICQ', 'XStatusName', $_POST['xStatusName'] );
	}
	
}


/* Apply Rest*/
if(isset($_POST['setAllStatus']) && $_POST['setAllStatus']!='---'){
$protocols = mb_SysEnumProtocols();
	foreach($protocols as $protocol) {
		if($protocol == 'MetaContacts'  || in_array(strtolower($protocol),unserialize(IGNORED_PROTO)))
			continue;
		$currentStatus = mb_PGetMyStatus($protocol);
		$newStatus = trim($_POST['setAllStatus']);

		if(isset($shortStatus[$newStatus]) && $newStatus != $currentStatus)
			mb_PSetMyStatus($protocol, $newStatus);
	}
	redirectToLocal('clist.php');
	exit;
}elseif(isset($_POST['setStatus'])){

	$protocols = mb_SysEnumProtocols();
	
	foreach($protocols as $protocol) {
		if($protocol == 'MetaContacts' || in_array(strtolower($protocol),unserialize(IGNORED_PROTO)))
			continue;
		$currentStatus = mb_PGetMyStatus($protocol);
		$newStatus = requestPost('status_'.$protocol);

		if($newStatus != null && $newStatus != $currentStatus)
			mb_PSetMyStatus($protocol, $newStatus);
			
		$newNick = requestPost('nick_'.$protocol);

		if($newNick != null)
			mb_SysCallProtoService($protocol, "/SetNickname", 0, $newNick);

		$newStatusMessage = requestPost('statusMessage_'.$protocol);

		if($newStatusMessage != null)
			mb_PSetMyAwayMsg($protocol, $newStatusMessage);
			
	}

	
	redirectToLocal('clist.php');
	exit;

}

/* end APPLY CHANGES */

include("inc/header.inc.php");

$icon = 'fotos/status/default/'.ID_STATUS_ONLINE.'.png';
echo '</head><body>';
printHTML('<table class=top><tr>');
printHTML('<td class=top><div align="left">');
printHTML('<a href="clist.php">< '.translateString('back').'</a>');
printHTML('</div></td>');
printHTML('<td class=top><div align="right" style="font-weight:bold;">Miranda IM <img alt="" src="'.$icon.'" /></div></td>');
printHTML('</tr></table><br />');

$protocols = mb_SysEnumProtocols();

printHTML('<form name="status" action="status.php" method="post">');

echo translateString('Global Status').': <select name="setAllStatus"><option value="---" selected="selected">--'.translateString('keep current status').'--</option>';
reset($statusArray);
while (list($statusValue, $statusName) = each($statusArray)) {
	if( $statusValue == ID_STATUS_IDLE )
		continue;
	echo '<option value="'.$statusValue.'">'.$statusName.'</option>';

}
echo '</select><br /><br />';

foreach($protocols as $protocol) {

	if(in_array(strtolower($protocol),unserialize(IGNORED_PROTO))|| $protocol == 'MetaContacts')
		continue;
		
	$myStatus = mb_PGetMyStatus($protocol);
	
	if(file_exists('fotos\\status\\'.$protocol.'\\'.$myStatus.'.png'))
		$ico = 'fotos/status/'.$protocol.'/'.$myStatus.'.png';
	else {
		if(file_exists('fotos\\status\\default\\'.$myStatus.'.png'))
			$ico = 'fotos/status/default/'.$myStatus.'.png';
		else
			$ico = 'fotos/status/default/unknown.png';
	}
	printHTML('
<div style="font-weight:bold"><img alt="'.$shortStatus[$myStatus].'" src="'.$ico.'"/> '.$protocol.'</div>
<table border="0" cellspacing="0" cellpadding="3">
 <tr>
  <td>
	'.translateString('Status').':
  </td>
  <td>
	<select name="status_'.$protocol.'">
');

	reset($statusArray);
	while (list($statusValue, $statusName) = each($statusArray)) {
		if( $statusValue == ID_STATUS_IDLE )
			continue;

		$selected = '';
		if($statusValue == $myStatus)
			$selected = ' selected="selected"';

		printHTML('<option value="'.$statusValue.'"'.$selected.'>'.$statusName.'</option>');

	}

	printHTML('
	</select>
   </td>
  </tr>');
if(OWN_NICK_SET)
  printHTML('<tr><td>'.translateString('Custom name').':</td><td><input type="text" name="nick_'.$protocol.'" /></td></tr>');
  printHTML('<tr>
   <td>
	'.translateString('Status message').':
   </td>
   <td>
	<input type="text" name="statusMessage_'.$protocol.'" />
   </td>
  </tr>');
printHTML('</table><br />');
  
if(ENABLE_X_STATUS_SET && strtolower($protocol)=='icq'){
	printHTML('<table border="0" cellspacing="0" cellpadding="3"><tr><td>X-Status:</td><td><select name="xStatusIcon">');

	printHTML('<option value="0">None</option><option value="1">angry</option><option value="2">shower</option><option value="3">tired</option><option value="4">party</option><option value="5">drink</option>');
	printHTML('<option value="6">think</option><option value="7">eat</option><option value="8">TV</option><option value="9">meet</option><option value="10">coffe</option><option value="11">music</option>');
	printHTML('<option value="12">business</option><option value="13">camera</option><option value="14">fun</option><option value="15">phone</option><option value="16">gaming</option><option value="17">learning</option>');
	printHTML('<option value="18">shopping</option><option value="19">ill</option><option value="20">sleeping</option><option value="21">surfing</option><option value="22">internet</option><option value="23">work</option><option value="24">typing</option>');

	printHTML('</select></td></tr>
	  <tr><td>'.translateString('X-Status Title').':</td>
	  <td><input type="text" name="xStatusName" /></td></tr>
	  <tr><td>'.translateString('X-Status message').':</td>
	  <td><input type="text" name="xStatusBody" /></td></tr></table><br />');
}

}

printHTML('
<div style="text-align:center">
	<input type="submit" name="setStatus" value="'. translateString('Save') .'" />
</div>');

printHTML('</form>');

include("inc/end.inc.php");

?>