<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');

if(isset($_GET['close'])){
	if($_GET['close']=='all'){
		if(file_exists('inc/settings/opentabs.txt'))
			unlink('inc/settings/opentabs.txt');
		redirectToLocal('clist.php');
		exit;
	}else{
		$opentabs = file('inc/settings/opentabs.txt');
		$output = '';
		foreach($opentabs as $tabid){
			$tabid = trim($tabid);
			if($tabid!=$_GET['close'])
				$output .= $tabid.'
';
		}
		if($output != ''){
			$hid = fopen('inc/settings/opentabs.txt', 'w');
			fwrite($hid, $output);
			fclose($hid);
		}else{
			unlink('inc/settings/opentabs.txt');
		}
	}
}

if(TABS && !isset($_GET['close']) && isset($_GET["cid"])){
	$opentabs[] = '';
	$output = '';
	if(file_exists('inc/settings/opentabs.txt')){
		$opentabs = file('inc/settings/opentabs.txt');
		foreach($opentabs as $tabid){
			$tabid = trim($tabid);
			$ignoredcid[$tabid] = true;
		}
		if(isset($ignoredcid)){
			$opentabs = null;
			foreach($ignoredcid as $tabid => $value){
				$opentabs[] = $tabid;
			}
		}
	}
	$hid = fopen('inc/settings/opentabs.txt', 'w');
	foreach($opentabs as $tabid){
		$output .= trim($tabid).'
';
	}
	$output .= $_GET["cid"];
	fwrite($hid, $output);
	fclose($hid);
}

if(isset($_GET["cid"]))
	$cid = $_GET["cid"];
elseif(file_exists('inc/settings/opentabs.txt')){
	$opentabs = file('inc/settings/opentabs.txt');
	if(isset($opentabs[0]) && trim($opentabs[0])!='')
		$cid = trim($opentabs[0]);
	elseif(isset($opentabs[1]) && trim($opentabs[1])!='')
		$cid = trim($opentabs[1]);
	else{
		redirectToLocal('clist.php');
		exit;
	}
}else{
	redirectToLocal('clist.php');
	exit;
}

$smileyarray['search'][] = "";
$smileyarray['replace'][] = "";
if( strpos(IN_PREFIX, '<img')===false )
	$in = fixforHtml(IN_PREFIX);
else
	$in = IN_PREFIX;
if( strpos(OUT_PREFIX, '<img')===false )
	$out = fixforHtml(OUT_PREFIX);
else
	$out = OUT_PREFIX;

if(SHOW_XSTAT && strtolower(mb_CGetProto($_GET["cid"]))=='icq'){
$xStatArray = array(
	0 => 'none',
	1 => 'angry',
	2 => 'shower',
	3 => 'tired',
	4 => 'party',
	5 => 'drink',
	6 => 'think',
	7 => 'eat',
	8 => 'TV',
	9 => 'meet',
	10 => 'coffe',
	11 => 'music',
	12 => 'business',
	13 => 'camera',
	14 => 'fun',
	15 => 'phone',
	16 => 'gaming',
	17 => 'learning',
	18 => 'shopping',
	19 => 'ill',
	20 => 'sleeping',
	21 => 'surfing',
	22 => 'internet',
	23 => 'work',
	24 => 'typing'
);
}


include("inc/icon.php");
include("inc/bday.php");
include("inc/tooltip.php");
include("inc/header.inc.php");

if($_SERVER['REQUEST_METHOD'] == "POST") {

	$action = $_POST["action"];
	$cid = $_POST["cid"];
	$body = mb_convert_encoding(trim($_POST["body"]), CHARSET_REPLY, "UTF-8");
	if($action == "sendMessage" && $body!="")
		if(!mb_MsgSend($cid, $body, 1))
			echo '<br />'.translateString('Failed to send message!').'<br /><br />';
}

if( USE_SMILEYS && file_exists('inc/smileys.inc.php'))
	include("inc/smileys.inc.php");

if(isset($_GET["hid"])) {
	$hid = $_GET["hid"];
	if($hid == 0)
		$hid = mb_EventFindLast($cid);
} else
	$hid = mb_EventFindLast($cid);

if(isset($_GET["search"])) {
	$search = $_GET["search"];
	$searchSuccess = false; //turn true if there are >=1 results.
}

$nick = mb_CGetDisplayName($cid);

$target = "";
if(!isset($_GET['what']) || $_GET['what']=='chat' || $_GET['what']=='search'){
echo '<script type="text/javascript">
function setFocus(){
document.getElementById("body").focus()
}
</script></head><body onload="setFocus()" onFocus="focused = true;">';
}else{
	echo '</head><body onFocus="focused = true;">';
}

printHTML('<table class="top">');
printHTML('<tr>');
printHTML('<td class="top"><div align="left"><a href="clist.php">'.translateString('CList').'</a> |');
if(TABS)
	printHTML(' <a href="contact.php?close=all">'.translateString('Close all Tabs').'</a> |');
printHTML(' <a href="contact.php?cid='.$cid.'">'.translateString('Reload').'</a> |');
printHTML(' <a href="contact.php?cid='.$cid.'&amp;what=chat">'.translateString('Reply').'</a> |');
if(!QUICK_REPLY_INCLUDE && QUICK_REPLY_ON)
	printHTML(' <a href="contact.php?cid='.$cid.'&amp;what=quick">'.translateString('Quick Reply').'</a> |');
if(FILES_ENABELED)
	printHTML(' <a href="contact.php?cid='.$cid.'&amp;what=file">'.translateString('Send File').'</a> |');
printHTML(' <a href="contact.php?cid='.$cid.'&amp;what=search">'.translateString('Search').'</a></div></td>');
$bd = '';
if(SHOW_BDAY)
	$bd = bdayicon($cid, mb_CGetProto($cid));
printHTML('<td class="top"><div align="right">');
if(isset($_SESSION['logouttime'])){
	$left = $_SESSION['logouttime']-time();
	$hleft = $left / 3600;
	settype($hleft,'integer');
	$mleft = ($left - 3600 * $hleft )/ 60;
	settype($mleft,'integer');
	if($mleft < 10)
		$mleft2 = '0'.$mleft;
	else
		$mleft2 = $mleft;
	$sleft = ($left - 3600 * $hleft - 60 * $mleft);
	if($sleft < 10)
		$sleft = '0'.$sleft;
	echo '<b>'.$hleft.":".$mleft2.':'.$sleft.'</b> - ';
}
printHTML(ContactToolTip($cid).' '.$bd.icon($cid).'</font>');
if(OTR){
	$otr = mb_CSettingGet($cid,'OTR','Encrypted');
	if($otr!=false){
		echo('<a href="otr.php?cid='.$cid.'&amp;setotr=0"><img border="0" src="fotos/other/OTRon.png" alt="on" /></a>');
	}else{
		echo('<a href="otr.php?cid='.$cid.'&amp;setotr=1"><img border="0" src="fotos/other/OTRoff.png" alt="off" /></a>');
	}
}
printHTML('</div></td></tr>');
printHTML('</table>');

$statusMessage = mb_CSettingGet($cid, 'CList', 'StatusMsg');

include('inc/tabs.php');

printHTML('<table width="100%" border="0"><tr>');
printHTML('<td valign="middle" width="100%">');
if(SHOW_AWAY && $statusMessage !== FALSE && !is_null($statusMessage) && $statusMessage!=''){
	printHTML('<div align="left" class="stattxt"><b>'.translateString('Status Message').':</b> '.fixForHTML(ssm_encoding($statusMessage)).'</div>');
	$info =1;
}
if(SHOW_XSTAT && mb_CSettingGet($cid, 'ICQ', 'XStatusId') !== FALSE && mb_CSettingGet($cid, 'ICQ', 'XStatusId') !== 0){
	$id=mb_CSettingGet($cid, 'ICQ', 'XStatusId');
	$add='';
	if(isset($xStatArray[$id]))
		$add = ' ('.$xStatArray[$id].')';
	echo '<div align="left" class="stattxt"><b>'.translateString('X-Status').': '.fixForHTML(ssm_encoding(mb_CSettingGet($cid, 'ICQ', 'XStatusName'))).$add.'</b><br/>'.fixForHTML(ssm_encoding(mb_CSettingGet($cid, 'ICQ', 'XStatusMsg'))).'</div>';
	$info =1;
}
	
printHTML('</td>');

if(AVATARS_ENABLED) {
	$info =1;
	printHTML('<td>&nbsp;</td>');
	if(!REFRESH_AVATAR && file_exists('fotos/avatars/'.$cid.'.jpg'))
		$pic = 'fotos/avatars/'.$cid.'.jpg';
	else
		$pic = 'getAvatar.img.php?cid='.$cid;
	printHTML('<td><a href="&amp;q=75&amp;s=-1"><img alt="" src="getAvatar.img.php?cid='.$cid.'" style="border: #000000 solid thin;" /></a></td>');
}
printHTML('</tr></table>');
if( isset($info))
	echo '<hr/>';

$messages = 0;
$ignorecon = 0;
if(REPLY_ON_TOP){
	include('inc/reply.inc.php');
	echo '<hr/>';
}
if(QUICK_REPLY_INCLUDE && QUICK_ON_TOP && QUICK_REPLY_ON && $_GET['what']=='chat'){
	include('inc/quickreply.inc.php');
	echo '<hr/>';
}

if($hid) {

	do {
	
		$msg = mb_EventGetData($hid, 0);
		list($module, $type, $timestamp, $flags, $body) = $msg;

		//IF IS SEARCHING HISTORY...
		if(isset($search)) {
			if(stripos($body, $search) === FALSE)
				continue;
			else
				$searchSuccess = true;
		}

		$date = date(DATE_FORMAT, $timestamp);
		
		if(MARK_MESSAGES_AS_READ)
			mb_EventMarkRead($hid, $cid);

		if($type == EVENTTYPE_FILE) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span class="out">'.$out.' '.translateString('Outgoing File Transfer').'</span>';
			else
				$body = '<span class="in">'.$in.' <a href="incomedfiles.php">'.translateString('Incoming File Transfer').'</a></span>';
		
		} else if($type == EVENTTYPE_URL) {
			if(strrpos($body, 'http:', $pos)===false)
				$bodylnk = 'http://'.trim($body);
			else
				$bodylnk = trim($body);
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span class="out">'.$out.' <a href="'.$bodylnk.'" target="_BLANK">'.$body.'</a></span>';
			else
				$body = '<span class="in">'.$in.' <a href="'.$bodylnk.'" target="_BLANK">'.$body.'</a></span>';
				
		} else if($type == EVENTTYPE_CONTACTS) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span class="out">'.$out.' '.translateString('Outgoing Contacts').'</span>';
			else
				$body = '<span class="in">'.$in.' '.translateString('Incoming Contacts').'</span>';
		
		} else if($type == EVENTTYPE_ADDED) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span class="out">'.$out.' '.translateString('You\'ve added this user to your contact list').'</span>';
			else
				$body = '<span class="in">'.$in.' '.translateString('You\'ve been added to the user contacts list').'</span>';
		
		} else if($type == EVENTTYPE_AUTHREQUEST) {
		
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span class="out">'.$out.' '.translateString('Outgoing Authorization Request').'</span>';
			else
				$body = '<span class="in">'.$in.' '.translateString('Incoming Authorization Request').'</span>';
				
		} else { //EVENTTYPE_MESSAGE or anything new :-)
			
			if($flags != SENT_UNICODE && $flags != READ_UNICODE && $flags != READ_UNICODE_UNREAD){
				$body = ssm_encoding($body);				
			}
			$body = nl2br(fixForHTML($body));
			
			$pos = 0;
			$count=0;
			$bodytmp = $body;
			while(strpos($body, 'http:', $pos)!==false){
				$von = strpos($body, 'http:', $pos);
				$to1 = strpos($body.' ', ' ', $von);
				$to2 = strpos($body.'<br', '<br', $von);
				if($to2<$to1)
					$to = $to2;
				else
					$to = $to1;
				$link = trim(substr($body,$von,$to-$von));
				$bodytmpende = substr($bodytmp,$to);
				$bodytmp = substr($body,0,$von);
				for($x=0;$x<32+strlen($link)+strlen($link);$x++)
					$bodytmp = $bodytmp.'!';
				$bodytmp = $bodytmp.$bodytmpende;
				$count++;
				$body = substr($body,0,$von).'<a href="'.$link.'" target="_BLANK">'.$link.'</a> '.substr($body,$to);
				$pos = $von+33+strlen($link)+strlen($link);
				if($pos>strlen($body))
					$pos = strlen($body);
			}
			
			$pos = 0;			
			while(strpos($bodytmp, 'www.', $pos)!==false){
				$von = strpos($bodytmp, 'www.', $pos);
				$to1 = strpos($bodytmp.' ', ' ', $von);
				$to2 = strpos($bodytmp.'<br', '<br', $von);
				if($to2<$to1)
					$to = $to2;
				else
					$to = $to1;
				$link = trim(substr($bodytmp,$von,$to-$von));
				$body = substr($body,0,$von).'<a href="http://'.$link.'" target="_BLANK">'.$link.'</a> '.substr($body,$to);
				$bodytmpende = substr($bodytmp,$to);
				$bodytmp = substr($bodytmp,0,$von);
				for($x=0;$x<39+strlen($link)+strlen($link);$x++)
					$bodytmp = $bodytmp.'!';
				$bodytmp = $bodytmp.$bodytmpende;
				$pos = $von+35+strlen($link);
				if($pos>strlen($body))
					$pos = strlen($body);
			}
			
			if( USE_SMILEYS ){
				$smiley = 0;
				while( isset($smileyarray['search'][$smiley])){
					$pos = 0;
					if(SMILEYS_WITH_WHITESPACE_ONLY){
						$searchfor = ' '.$smileyarray['search'][$smiley].' ';
						$replacewith = ' '.$smileyarray['replace'][$smiley].' ';
					}else{
						$searchfor = $smileyarray['search'][$smiley];
						$replacewith = $smileyarray['replace'][$smiley];
					}
					while(strpos(' '.$bodytmp.' ', $searchfor, $pos)!==false){
						$von = strpos(' '.$bodytmp.' ', $searchfor, $pos);
						$body = trim(substr(' '.$body.' ',0,$von).$replacewith.substr(' '.$body.' ',$von+strlen($searchfor)));
						$bodytmp = trim(substr(' '.$bodytmp.' ',0,$von).$replacewith.substr(' '.$bodytmp.' ',$von+strlen($searchfor)));
						$pos = $von+strlen($replacewith);
					}
					$smiley++;
				}
			}
			
			if($flags == SENT || $flags == SENT_UNICODE)
				$body = '<span class="out">'.$out.' '.$body.'</span>';
			else
				$body = '<span class="in">'.$in.' '.$body.'</span>';
		
		}
		
		printHTML('<span class="date">' . fixForHTML($date) . '</span>');
		if(isset($search))
			printHTML('<span style="font-size:10px;font-wight:bold;"><a href="contact.php?cid='.$cid.'&amp;hid='.$hid.'&amp;what=search">[+]</a></span>');
		echo '<br />'.$body.'<br />';
		
		++$messages;
		
	} while(($hid = mb_EventFindPrev($hid)) && $messages < MESSAGES_PER_PAGE);

	if($hid){
		printHTML('<div align="right"><a href="contact.php?cid='.$cid.'&amp;page=1&amp;what=search&amp;hid='.$hid . ((isset($search)) ? '&amp;search='.$search : '') .'">&gt;&gt; '.translateString('Back in History').'</a></div>');
		if( isset($_GET['hid']))
			printHTML('<div align="left"><a href="contact.php?what=search&amp;cid='.$cid . ((isset($search)) ? '&amp;search='.$search : '') .'">&lt;&lt; '.translateString('Latest Message').'</a></div>');
		if( isset($search) )
			printHTML('<div align="left"><a href="contact.php?cid='.$cid .'&amp;what=search">&lt;&lt; '.translateString('Show History').'</a></div>');
	}elseif(isset($search) && !$searchSuccess){
		printHTML('<span style="font-weight:bold;">"'.$search.'" '.translateString('was not found in history').'.</span><br />');
		printHTML('<br /><div align="left"><a href="contact.php?cid='.$cid .'&amp;what=search">&lt;&lt; '.translateString('Show History').'</a></div>');
	}else
		printHTML('<br /><div align="left"><a href="contact.php?cid='.$cid .'&amp;what=search">&lt;&lt; '.translateString('Show History').'</a></div>');
		
} else

	printHTML('<br /><span style="font-weight:bold;">'.translateString('History is empty').'.</span><br />');
if(!REPLY_ON_TOP){
	echo '<hr/>';
	include('inc/reply.inc.php');
}
if(QUICK_REPLY_ON && QUICK_REPLY_INCLUDE && !QUICK_ON_TOP && (!isset($_GET['what']) || $_GET['what']=='chat')){
	echo '<hr/>';
	include('inc/quickreply.inc.php');
}
$include = true;
include('inc/notify.php');
if(SOUND_ON && defined('NEW_MESSAGE_ARRIVED'))
	include('sound/sound.php');
include("inc/end.inc.php");
?>