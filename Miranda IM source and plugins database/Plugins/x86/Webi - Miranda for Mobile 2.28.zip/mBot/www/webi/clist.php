<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');

//set mail on/off
if(isset($_GET['mailis'])){
	if(mb_CSettingGet(NULL,'Webi','aamail-on')!=1){
		mt_setvar('webmail', 'off', 1, 0);
		mb_MenuModify(mt_getvar('webmailmenu'), 'Mail notification off', null, 0x04, 'sendMail');
	}elseif($_GET['mailis']=='on'){
		mt_setvar('webmail', 'off', 1, 0);
		mb_MenuModify(mt_getvar('webmailmenu'), 'Mail notification off', null, 0x00, 'sendMail');
	}else{
		mt_setvar('webmail', 'on', 1, 0);
		mb_MenuModify(mt_getvar('webmailmenu'), 'Mail notification on', null, 0x00, 'sendMail');	
	}
	redirectToLocal('clist.php');
}

include("inc/icon.php");
include("inc/bday.php");
include("inc/tooltip.php");
include("inc/header.inc.php");

function showMyStauts(){
	$protokolle = mb_SysEnumProtocols();
	$protonum = 0;
	$return = "";
	foreach($protokolle as $proto) {
		if($proto == 'MetaContacts' || in_array(strtolower($proto),unserialize(IGNORED_PROTO)))
			continue;
		$status = mb_PGetMyStatus($proto);
		$xid = mb_CSettingGet(null,'ICQ', 'XStatusId');
		$xico = false;
		if(XSTAT_ICONS && strtolower($proto)=='icq' && $xid!=0 && $xid!=false && file_exists('fotos\\status\\icq\\xstatus\\Icon_'.$xid.'.ico')){
			$ico = 'fotos/status/icq/xstatus/Icon_'.$xid.'.ico';
			$xico = true;
		}elseif(file_exists('fotos\\status\\'.$proto.'\\'.$status.'.png')){
			$ico = 'fotos/status/'.$proto.'/'.$status.'.png';
		}else{
			if(file_exists('fotos\\status\\default\\'.$status.'.png'))
				$ico = 'fotos/status/default/'.$status.'.png';
			else
				$ico = 'fotos/status/default/unknown.png';
		}
		$border = "";
		if(strtolower($proto)=='icq'){
			if(!$xico && $xid!=0 && $xid!=false){
				$border = 'style="border-color:#FF00FF;" border="1"';
			}
		}

		$return .= ' <img alt="" src="'.$ico.'"'.$border.'/> ';
	}
	return $return;
}

//read ignored group file
if(file_exists('inc/settings/ignoredgroups.txt')){
	$tmp = file('inc/settings/ignoredgroups.txt');
	foreach($tmp as $line){
		$ignoredgroups['-'.trim($line)] = true;
	}
	$tmp = '';
}

//show all contacts or just 'not offline' contacts
if( isset($_SESSION['all'])){
	$all = $_SESSION['all'];
}else{
	$all = 0;
}
if(isset($_GET["all"])) {
	$all = $_GET["all"];
	if($all != 1)
		$all = 0;
}
$_SESSION['all'] = $all;


if(isset($_GET["hide"])){
	$group = $_GET["hide"];
	if( $_GET["activ"]==1 ){
		$_SESSION['hide'.$group] = 0;
	}else{
		$_SESSION['hide'.$group] = 1;
	}
}

if(!$all)
	$showAllOrOnline = "Show offline contacts";
else
	$showAllOrOnline = "Hide offline users";

echo '</head><body onFocus="focused = true;">';
printHTML('<table class="top"><tr>');
printHTML('<td class="top"><div align="left">');
printHTML('<a href="clist.php">'.translateString('Reload').'</a> | ');
printHTML('<a href="clist.php?all='. (($all == 1) ? 0 : 1) .'">'.translateString($showAllOrOnline).'</a> | ');
printHTML('<a href="status.php">'.translateString('Status').'</a> | ');
printHTML('<a href="settings.php">'.translateString('Settings').'</a>');
if(FILES_ENABELED)
	printHTML(' | <a href="incomedfiles.php">'.translateString('Files').'</a>');
if(FILES_ENABELED && file_exists('../uploaded'))
	printHTML(' | <a href="uploadcleanup.php">'.translateString('Delete uploaded files').'</a>');
if(mb_CSettingGet(null, 'Webi', 'aamail-on')==1)
	printHTML(' | <a href="clist.php?mailis='.mt_getvar('webmail').'">Notify is '.mt_getvar('webmail').'</a>');
if(LOGIN_ENABLED)
	printHTML(' | <a href="login.php?log=out">'.translateString('Logoff').'</a>');
printHTML('</div></td>');
printHTML('<td class="top"><div align="right" style="font-weight:bold;">');
if(isset($_SESSION['logouttime'])){
	$left = $_SESSION['logouttime']-time();
	$hleft = $left / 3600;
	settype($hleft,'integer');
	$mleft = ($left - 3600 * $hleft )/ 60;
	settype($mleft,'integer');
	if($mleft < 10)
		$mleft2 = '0'.$mleft;
	else
		$mleft2 = $mleft;
	$sleft = ($left - 3600 * $hleft - 60 * $mleft);
	if($sleft < 10)
		$sleft = '0'.$sleft;
	echo $hleft.":".$mleft2.':'.$sleft;
}
printHTML(showMyStauts().'</div></td>');
printHTML('</tr></table><br />');


//collect information to form groups
if(GROUPS)
	include('inc/clist/clistcollect.groups.php');
else
	include('inc/clist/clistcollect.nogroups.php');

if(SPLIT_BY_USERS){
	$maxperrow = MAX_PER_ROW;
	$maxrows = round($amounttoshow / MAX_PER_ROW + 0.49999);
}else{
	$maxperrow = round($amounttoshow / MAX_ROWS + 0.49999);
	$maxrows = MAX_ROWS;
}
// output of list
$oldcon = '';
if(SHOW_OLD_CONTACTS>0){
	foreach($contact['cid'] as $oldid){
		$hid = mb_EventFindLast($oldid);
		if($hid == null || $hid == false || $hid == '' || $hid == '0'){
			$time = 0;
		}else{
			$message = mb_EventGetData($hid, 0);
			if($message === false)
				$time = 0;
			else
				$time = $message[2];
		}
		$tmp[$oldid] = $time;
	}
	arsort($tmp, SORT_NUMERIC);
	foreach($tmp as $key => $value){
		$sortedover[] = $key;
	}
	$count=0;
	$numer=0;
	$collum = 1;
	while($count < SHOW_OLD_CONTACTS){
		if(!isset($ignore[$sortedover[$numer]])){
			$oldcon .= '<td> '.ClistTooltip($sortedover[$numer], $collum, false).' </td>';
			if(fmod($count,$maxrows)==$maxrows-1){
				$oldcon .= '</tr><tr>';
				$collum = 0;
			}
			$count++;
			$collum++;
		}
		$numer++;
	}
}

echo '<table border="0"><tr>'.$oldcon.'</tr><tr><td align="center" valign="top"><table class="clist">';
if(GROUPS)
	include('inc/clist/clistout.groups.php');
else
	include('inc/clist/clistout.nogroups.php');

echo '</table></td></tr></table>';
$include = true;
include('inc/notify.php');
if(SOUND_ON && defined('NEW_MESSAGE_ARRIVED'))
	include('sound/sound.php');
echo '</body></html>';



//callback for menue
function sendMail($param,$cid,$hmenu){
	if(mb_CSettingGet(NULL,'Webi','aamail-on')!=1){
		mt_setvar('webmail', 'off', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification off', null, 0x04, 'sendMail');
	}elseif(mt_getvar('webmail')==='off'){
		mt_setvar('webmail', 'on', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification on', null, 0x00, 'sendMail');
	}else{
		mt_setvar('webmail', 'off', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification off', null, 0x00, 'sendMail');
	}
}
?>