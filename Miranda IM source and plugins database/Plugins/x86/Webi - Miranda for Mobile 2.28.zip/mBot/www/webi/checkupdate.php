<?
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
*/
if(!@fsockopen('legoking.le.funpic.de', 80, $errno, $errstr , 10)){
	$update = "Update server seems offline";
	return;
}
if(file_exists('version.txt')){
	$real = file('version.txt');
	if(isset($real[1]))
		$real = trim($real[1]);
	else
		$real = trim($real[0]);
}else{
	$real = 0;
}

if(isset($_GET['ignoreThisVersion'])){

	$newVerLnk = "http://legoking.le.funpic.de/webi/webiupdate27.php";
	$newVerH = fopen($newVerLnk, 'r');
	$newVer = trim(fgets($newVerH));
	fclose($newVerH);
	
	$versionh = fopen('version.txt', 'w');
	fwrite( $versionh, $newVer.'
'.$real);
	header("Location: index.php");

}else{
	$version = 0;
	if( file_exists('version.txt')){
		$versionh = fopen('version.txt', 'r');
		$version = trim(fgets($versionh));
		fclose($versionh);
	}

	$listFile = "http://legoking.le.funpic.de/webi/webiupdate27.php?ver=".$version.'&real='.$real;
	$listh = fopen($listFile, 'r');
	$amount = fgets($listh);
	fclose($listh);
	$amount = trim($amount);
	$needupdate = true;
	if($amount == '0'){
		$update = translateString('You have the current Version');
		$needupdate = false;
	}elseif(settype($amount, 'int') and $amount>0){
		$update = translateString('New Updates are available!!!').' '.translateString('Yours is').' V. '.substr($version,0,1).'.'.substr($version,1).'<br /><a href="update.php">'.translateString('update').'.</a>';
	}else{
		if(AUTO_UPDATE){
			$update = translateString('Your Version has to be updated manually!!!').'<br /><a href="http://legoking.le.funpic.de/webi/index.php">'.translateString('go to Updatepage').'</a>';
		}else{
			$update = translateString('New Updates are available!!!').'<br /><a href="http://legoking.le.funpic.de/webi/index.php">'.translateString('go to Updatepage').'</a>';
		}
	}
	if( $needupdate )
		$update = $update.'<br/><a href="http://legoking.le.funpic.de/webi/changelog.php?ver='.$version.'" target="_BLANK">Changelog</a><br/><a href="checkupdate.php?ignoreThisVersion=1">'.translateString('Ignore this Version').'</a>';
}
?>
