<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');
if($_GET['setotr']==0){
	$cid = $_GET['cid'];
	settype($cid, 'integer');
	mb_SysCallService('OTR/Stop', $cid, null);
	redirectToLocal('contact.php?cid='.$cid);
}else{
	$cid = $_GET['cid'];
	settype($cid, 'integer');
	mb_SysCallService('OTR/Start', $cid, null);
	include("inc/header.inc.php");
	echo 'Building up OTR connection. This may take some time. If you are not being redirected <a href="contact.php?cid='.$cid.'">click here</a>.';
}