<?
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/
include("inc/comun.inc.php");
include('inc/security.inc.php');
include('inc/header.inc.php');

if(file_exists('version.txt')){
	$real = file('version.txt');
	if(isset($real[1]))
		$real = trim($real[1]);
	else
		$real = trim($real[0]);
}else{
	$real = 0;
}
$version = 'V. '.substr($real, 0, 1).'.'.substr($real, 1);

printHTML('<table class=top><tr>');
printHTML('<td class=top><div align="left">');
printHTML('<a href="clist.php">'.translateString('CList').'</a>');
if(MOBILE_ON && isset($_SESSION['mobile']) && $_SESSION['mobile'])
	printHTML(' | <a href="login.php?mobilesetting=off">'.translateString('Leave mobile settings').'</a>');
elseif(MOBILE_ON)
	printHTML(' | <a href="login.php?mobilesetting=on">'.translateString('Swich to mobile settings').'</a>');
printHTML('</div></td>');
printHTML('<td class=top><div align="right" style="font-weight:bold;">Webi <font style="font-size: 9px;">('.$version.')</font></div></td>');
printHTML('</tr>');
printHTML('</table>');

printHTML('<a href="settings.php?page=general">'.translateString('General Settings').'</a> |');
printHTML('<a href="settings.php?page=status">'.translateString('My Status Settings').'</a> |');
printHTML('<a href="settings.php?page=clist">'.translateString('Clist Settings').'</a> |');
printHTML('<a href="settings.php?page=chat">'.translateString('Chat Settings').'</a> |');
printHTML('<a href="settings.php?page=smileys">'.translateString('Smileys Settings').'</a> |');
printHTML('<a href="settings.php?page=quick">'.translateString('Quickreply Settings').'</a> |');
printHTML('<a href="settings.php?page=files">'.translateString('File Settings').'</a> |');
printHTML('<a href="settings.php?page=avatar">'.translateString('Avatar Settings').'</a> |');
printHTML('<a href="editor.php?edit=ip">'.translateString('Auto Login').'</a> |');
printHTML('<a href="editor.php?edit=mail">'.translateString('Mail notification').'</a> |');
printHTML('<a href="settings.php?page=tooltip">'.translateString('Tooltip Settings').'</a><br /><br />');


$secure=true;
if(isset($_GET['edit'])){
	if($_GET['edit']=='quick')
		include('inc/editors/quick.php');
	elseif($_GET['edit']=='smile')
		include('inc/editors/smiley.php');
	elseif($_GET['edit']=='iproto')
		include('inc/editors/ignore-proto.php');
	elseif($_GET['edit']=='igroup')
		include('inc/editors/ignore-group.php');
	elseif($_GET['edit']=='ip')
		include('inc/editors/ip-login.php');
	elseif($_GET['edit']=='mail')
		include('inc/editors/mail.php');
	else
		die('Wrong argument');
	$_SESSION['edit']=$_GET['edit'];
}else{
	if($_SESSION['edit']=='quick')
		include('inc/editors/quick.php');
	elseif($_SESSION['edit']=='smile')
		include('inc/editors/smiley.php');
	elseif($_SESSION['edit']=='iproto')
		include('inc/editors/ignore-proto.php');
	elseif($_SESSION['edit']=='igroup')
		include('inc/editors/ignore-group.php');
	elseif($_SESSION['edit']=='ip')
		include('inc/editors/ip-login.php');
	elseif($_SESSION['edit']=='mail')
		include('inc/editors/mail.php');
	else
		die('Wrong argumen');
}

include('inc/end.inc.php');
?>