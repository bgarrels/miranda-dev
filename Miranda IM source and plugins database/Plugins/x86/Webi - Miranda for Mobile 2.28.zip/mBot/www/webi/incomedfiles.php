<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
* originally based on Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*
*/
include("inc/comun.inc.php");
include('inc/security.inc.php');
include('inc/header.inc.php');
echo '</head><body>';
$icon = 'fotos/status/default/'.ID_STATUS_ONLINE.'.png';
printHTML('<table class=top><tr>');
printHTML('<td class=top><div align="left">');
printHTML('<a href="clist.php">< '.translateString('back').'</a>');
printHTML('</div></td>');
printHTML('<td class=top><div align="right" style="font-weight:bold;">Miranda IM <img alt="" src="'.$icon.'" /></div></td>');
printHTML('</tr>');
printHTML('</table><br />');


$dir = mb_CSettingGet(0, 'SRFile', 'RecvFilesDirAdv');
if($dir === false){
	echo translateString("No destination for incomed files specified in Miranda DB");
	exit;
}
$dir = strtolower($dir);
$dir = str_replace('%miranda_path%', mb_SysGetMirandaDir(), $dir);
$dir = str_replace('%userprofile%', substr(mb_SysGetProfileName(), 0,strrpos(mb_SysGetProfileName(),'.')), $dir);
if(strpos($dir, '%proto%')!==false){
	$pos = strpos($dir, '%proto%');
	$dir = substr($dir, 0 , $pos);
}
if(strpos($dir, '%nick%')!==false){
	$pos = strpos($dir, '%nick%');
	$dir = substr($dir, 0 , $pos);
}
if(strpos($dir, '%userid%')!==false){
	$pos = strpos($dir, '%userid%');
	$dir = substr($dir, 0 , $pos);
}
$dir = str_replace('\\', '/', $dir);
if(strrpos($dir,'/')+1<strlen($dir))
	$dir = $dir.'/';

$addir = "";
$lowerdir = "";
if(isset($_GET['addir'])){
	$addir = strtolower(mb_convert_encoding($_GET['addir'],CHARSET_REPLY,"UTF-8"));
	$addir = str_replace('\\', '/', $addir);
	if(strrpos($addir,'/')+1<strlen($addir))
		$addir = $addir.'/';
	if(strpos($addir,'/')==0)
		$addir = substr($addir, 1);
	$dir = $dir.$addir;
	$lowerdir = substr($_GET['addir'], 0,strrpos('/'.$_GET['addir'],'/',-2));
}
if($addir != "")
	echo '<img alt="up" src="fotos/files/up.gif"/><a href="incomedfiles.php?addir='.$lowerdir.'">'.translateString('Upper direcory').'</a><br />';
if(!is_dir($dir)){
	echo translateString('The given folder does not exist.');
	exit;
}
$dirhand = dir($dir);
while($file = $dirhand->read()){
	if($file != '.' && $file != '' && $file != '..'){
		if(is_dir($dir.$file)){
			echo '<img alt="dir" src="fotos/files/dir.gif"/><a href="incomedfiles.php?addir='.mb_convert_encoding($addir.$file,"UTF-8",CHARSET_REPLY).'">'.fixForHTML(ssm_encoding($file)).'</a><br />';
		}else{
			echo '<img alt="file" src="fotos/files/file.gif"/><a href="echofile.php?file='.mb_convert_encoding($addir.$file,"UTF-8",CHARSET_REPLY).'">'.fixForHTML(ssm_encoding($file)).'</a><br />';
		}
	}
}
$dirhand ->close();
include('inc/end.inc.php');
?>