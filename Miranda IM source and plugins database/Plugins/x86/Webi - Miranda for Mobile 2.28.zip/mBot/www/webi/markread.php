<?
include("inc/comun.inc.php");
require_once('inc/security.inc.php');

$cid = mb_CFindFirst();
do{
	while( mb_EventFindFirstUnread($cid)!=""){
		$hid = mb_EventFindFirstUnread($cid);
		mb_EventMarkRead($hid,$cid);
	}
} while($cid = mb_CFindNext($cid));
redirectToLocal('clist.php');
?>