<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/
include("inc/comun.inc.php");
include('inc/security.inc.php');

function checked($readBOOL){
	if( $readBOOL)
		return 'checked="checked"';
}
function isselected($value, $readSTR){
	if( $value == $readSTR )
		echo 'selected="selected"';
}

function checkbox($number, $value){
	echo '<input type="hidden" name="existbool'.$number.'" value="1"/><label><input type="checkbox" value="1" name="bool'.$number.'" '.checked($value).' />';
}

$error =0;
if( isset($_POST['change']) ){
	if(isset($_POST['existfileaccept']) && DISABLE_AUTO_ACCEPT_FILES_SETTING==false){
		if(isset($_POST['fileaccept']) && $_POST['fileaccept']==1){
			if(mb_CSettingSet(0, 'SRFile', 'AutoAccept','1')==0)
				$error = 1;
		}else{
			if(mb_CSettingSet(0, 'SRFile', 'AutoAccept','0')==0)
				$error = 1;
		}
	}
	if(isset($_SESSION['mobile']) && $_SESSION['mobile']){
		$addition = 'm';
	}else{
		$addition = '';
	}
	for($line = 0; $line < 40; $line++){
		if( isset($_POST['existbool'.$line]) && $_POST['existbool'.$line]==1 && isset($_POST['bool'.$line]) && $_POST['bool'.$line]==1){
			$readBOOL[$line] = true;
			mb_CSettingAdd(null, 'Webi', DBVT_BYTE, 'b'.$addition.$line, 1);
		}elseif(isset($_POST['existbool'.$line]) && $_POST['existbool'.$line]==1){
			$readBOOL[$line] = false;
			mb_CSettingAdd(null, 'Webi', DBVT_BYTE, 'b'.$addition.$line, 0);
		}
	}

	for($line = 0; $line < 40; $line++){
		if( isset($_POST['str'.$line])){
			mb_CSettingAdd(null, 'Webi', DBVT_ASCIIZ, 's'.$addition.$line, trim($_POST['str'.$line]));
			$readSTR[$line] = trim($_POST['str'.$line]);
		}
	}

	echo translateString('Modification saved').'<br />';
}

include('inc/header.inc.php');
?>
<style type="text/css">
<!--
.style3 {font-size: 12px}
-->
</style>
</head>
<body>
<?
if(file_exists('version.txt')){
	$real = file('version.txt');
	if(isset($real[1]))
		$real = trim($real[1]);
	else
		$real = trim($real[0]);
}else{
	$real = 0;
}
$version = 'V. '.substr($real, 0, 1).'.'.substr($real, 1);

printHTML('<table class=top><tr>');
printHTML('<td class=top><div align="left">');
printHTML('<a href="clist.php">'.translateString('CList').'</a>');
if(MOBILE_ON && isset($_SESSION['mobile']) && $_SESSION['mobile'])
	printHTML(' | <a href="login.php?mobilesetting=off">'.translateString('Leave mobile settings').'</a>');
elseif(MOBILE_ON)
	printHTML(' | <a href="login.php?mobilesetting=on">'.translateString('Swich to mobile settings').'</a>');
printHTML('</div></td>');
printHTML('<td class=top><div align="right" style="font-weight:bold;">Webi <font style="font-size: 9px;">('.$version.')</font></div></td>');
printHTML('</tr>');
printHTML('</table>');

printHTML('<a href="settings.php?page=general">'.translateString('General Settings').'</a> |');
printHTML('<a href="settings.php?page=status">'.translateString('My Status Settings').'</a> |');
printHTML('<a href="settings.php?page=clist">'.translateString('Clist Settings').'</a> |');
printHTML('<a href="settings.php?page=chat">'.translateString('Chat Settings').'</a> |');
printHTML('<a href="settings.php?page=smileys">'.translateString('Smileys Settings').'</a> |');
printHTML('<a href="settings.php?page=quick">'.translateString('Quickreply Settings').'</a> |');
printHTML('<a href="settings.php?page=files">'.translateString('File Settings').'</a> |');
printHTML('<a href="settings.php?page=avatar">'.translateString('Avatar Settings').'</a> |');
printHTML('<a href="editor.php?edit=ip">'.translateString('Auto Login').'</a> |');
printHTML('<a href="editor.php?edit=mail">'.translateString('Mail notification').'</a> |');
printHTML('<a href="settings.php?page=tooltip">'.translateString('Tooltip Settings').'</a><br /><br />');
?>
<form name="settings" method="post" action="">
<?
if( !isset($_GET['page']) || $_GET['page']=='general'){
?>
<? echo translateString('General Settings');?>:<br />
<table border="1" cellspacing="0" cellpadding="0">

<tr><td>
 <table><tr>
  <td><? checkbox(39, $readBOOL[39]);?><? echo translateString('Write a logfile to').' '.mb_SysGetMirandaDir().'/mbot/webilog.txt';?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(28, $readBOOL[28]);?><? echo translateString('Lock Webi Host when loging in to Webi (lock like win+L)');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? checkbox(29, $readBOOL[29]);?><? echo translateString('Do not lock when using localhost');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(38, $readBOOL[38]);?><? echo translateString('Hide Mobile Settings');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(6, $readBOOL[6]);?><? echo translateString('captcha enabeled');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(30, $readBOOL[30]);?><? echo translateString('Clear Session completly');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateStringAdv('Logout after %s Minutes', '<input name="str23" type="text" value="'.$readSTR[23].'" size="7" maxlength="5"/>');?> <span class="style3">(<? echo translateStringAdv('%s to disable', '0');?>)</span></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateString('Charset to be used:');?><br />
      <span class="style3">Europe=iso-8859-1 Russia=windows-1251</span><br />
      <input name="str0" type="text" value="<? echo $readSTR[0];?>" /></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(3, $readBOOL[3]);?><? echo translateString('notify on new updates');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? checkbox(4, $readBOOL[4]);?><? echo translateString('auto-install updates');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<?
if( file_exists('version.txt')){
	$version = file('version.txt');
	$real = trim($version[1]);
	$version = trim($version[0]);
}else{
	$real = 0;
	$version = 0;
}
$current = file("http://legoking.le.funpic.de/webi/webiupdate27.php");
$current = trim($current[0]);
if($version<$current){
echo '<tr><td>
 <table><tr>
  <td><a href="update.php">Update to most current version</a>, <a href="http://legoking.le.funpic.de/webi/changelog.php?ver='.$real.'">Show Changelog</a>, <a href="checkupdate.php?ignoreThisVersion=1">Ignore this update</a></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>';
}
?>

<tr><td>
 <table><tr>
  <td><? checkbox(27, $readBOOL[27]);?><? echo translateStringAdv('Play %s when new message arrives', '</label>
<select name="str21">
	<option value="4">message.mp3 (flash)</option>
	<option value="3" '.isselected('3', $readSTR[21]).'>message.mp3</option>
	<option value="2" '.isselected('2', $readSTR[21]).'>message.wav</option>
	<option value="1" '.isselected('1', $readSTR[21]).'>message.midi</option>
  </select>');?>
 </td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateString('When new messages arrived and window is unfocused, notify with:');?> </label>
<select name="str25">
	<option value="0"><? echo translateString('nothing');?></option>
	<option value="2" <? echo isselected('2', $readSTR[25]);?>><? echo translateString('Popup (recomended)');?></option>
	<option value="1" <? echo isselected('1', $readSTR[25]);?>><? echo translateString('Window Focus');?></option>
	<option value="3" <? echo isselected('3', $readSTR[25]);?>><? echo translateString('Javascript alert');?></option>
  </select>
 (<? echo translateString('needs Javascript');?>)</td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(31, $readBOOL[31]);?><? echo translateStringAdv('show Birthday when %s days left','</label><input name="str24" type="text" value="'.$readSTR[24].'" size="4" maxlength="3"/>');?></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(2, $readBOOL[2]);?><? echo translateString('mark events as read');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><a href="markread.php"><? echo translateString('mark all events read now');?></a></td>
 </tr></table>
</td></tr>

<tr><td>
 <label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label>
</td></tr>
</table>
<?
}elseif($_GET['page']=='status'){
?>
<? echo translateString('My Status Settings');?>:<br />
<table border="1" cellspacing="0" cellpadding="0">

<tr><td>
 <table><tr>
  <td><? checkbox(19, $readBOOL[19]);?><? echo translateString('X-Status support');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(20, $readBOOL[20]);?><? echo translateString('ask for nick-name');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label>
</td></tr>
</table>

<?
}elseif($_GET['page']=='tooltip'){
?>
<? echo translateString('Tooltips');?>:<br />
<table border="1" cellspacing="0" cellpadding="0">

<tr><td>
 <table><tr>
  <td><? checkbox(35, $readBOOL[35]);?><? echo translateString('enable Tooltips');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? checkbox(36, $readBOOL[36]);?><? echo translateString('Use IE compatibility');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><label><? echo translateString('Tooltip width:');?><br />
      <input name="str29" type="text" value="<? echo $readSTR[29];?>" size="6" /></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><label><? echo translateString('background color:');?><br />
      <input name="str27" type="text" value="<? echo $readSTR[27];?>" size="8" /></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><label><? echo translateString('border color:');?><br />
      <input name="str26" type="text" value="<? echo $readSTR[26];?>" size="8" /></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><label><? echo translateString('text color:');?><br />
      <input name="str28" type="text" value="<? echo $readSTR[28];?>" size="8" /></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><span class="style3"><a href="http://www.somacon.com/p142.php" target="_BLANK"><? echo translateString('color codes');?></a></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label>
</td></tr>
</table>
<?
}elseif($_GET['page']=='clist'){
?>
<? echo translateString('Clist Settings');?>:<br />
<table border="1" cellspacing="0" cellpadding="0">
<tr><td>
 <table><tr>
  <td><a href="editor.php?edit=igroup"><? echo translateString('set ignored groups');?></a></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><a href="editor.php?edit=iproto"><? echo translateString('set ignored protocols');?></a></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(22, $readBOOL[22]);?><? echo translateString('Use groups');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateStringAdv('refresh Clist after %s secounds', '<input name="str1" type="text" value="'.$readSTR[1].'" size="7" maxlength="5"/>');?>
      <span class="style3">(<? echo translateStringAdv('%s to disable', '-1');?>)</span></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateStringAdv('Show last %s  Contacts over Clist:', '<input name="str22" type="text" value="'.$readSTR[22].'" size="4" maxlength="3"/>');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><input type="radio" name="bool21" value="1" <? echo checked($readBOOL[21]);?> /></td>
  <td><label><? echo translateStringAdv('Devide Clist after %s entrys', '<input name="str18" type="text" value="'.$readSTR[18].'" size="7" maxlength="5"/>');?></label></td>
  <td>&nbsp;</td>
 </tr><tr>
  <td><input type="radio" name="bool21" value="0" <? echo checked(!$readBOOL[21]);?> /></td>
  <td><label><? echo translateStringAdv('Devide Clist into %s colums', '<input name="str17" type="text" value="'.$readSTR[17].'" size="7" maxlength="5"/>');?></label></td>
  <td><input type="hidden" name="existbool21" value="1"/></td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateString('Sort groups by');?> <select name="str20">
	<option value=" "><? echo translateString('Do not sort')?></option>
	<option value="name" <? echo isselected('name', $readSTR[20]);?>><? echo translateString('Name')?></option>
	<option value="clist" <? echo isselected('clist', $readSTR[20]);?>><? echo translateString('like in Clist')?></option>
	<option value="last" <? echo isselected('last', $readSTR[20]);?>><? echo translateString('Time since last message')?></option>
  </select></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateString('Sort contacts by')?> <select name="str19">
	<option value=" " <? echo isselected(' ', $readSTR[19]);?>><? echo translateString('Do not sort')?></option>
	<option value="nick" <? echo isselected('nick', $readSTR[19]);?>><? echo translateString('Nick name')?></option>
	<option value="status" <? echo isselected('status', $readSTR[19]);?>><? echo translateString('Status')?></option>
	<option value="proto" <? echo isselected('proto', $readSTR[19]);?>><? echo translateString('Protocol')?></option>
	<option value="last" <? echo isselected('last', $readSTR[19]);?>><? echo translateString('Time since last message')?></option>
  </select></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(23, $readBOOL[23]);?><? echo translateString('use X-Status Icons');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? checkbox(32, $readBOOL[32]);?><? echo translateString('Show X-Status instead of usual');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateStringAdv('Shorten Group names longer than %s chars' , '<input name="str15" type="text" value="'.$readSTR[15].'" size="7" maxlength="5"/>');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateStringAdv('Shorten Contact names longer than %s chars' , '<input name="str16" type="text" value="'.$readSTR[16].'" size="7" maxlength="5"/>');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(0, $readBOOL[0]);?><? echo translateString('show Metacontacts Subcontacts');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(8, $readBOOL[8]);?><? echo translateString('show new messages in hidden groups');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
  <label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label>
</td></tr>
</table>
<?
}elseif( $_GET['page']=='chat'){
?>
<? echo translateString('Chat Settings');?>:<br />
<table border="1" cellspacing="0" cellpadding="0">
<tr><td>
 <table><tr>
  <td><label><? echo translateStringAdv('refresh Messagewindow after %s secounds', '<input name="str2" type="text" value="'.$readSTR[2].'" size="7" maxlength="5"/>');?>
      <span class="style3">(<? echo translateStringAdv('%s to disable', '-1');?>)</span></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateStringAdv('show %s messages per page', '<input name="str3" type="text" value="'.$readSTR[3].'" size="6" maxlength="4"/>');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(24, $readBOOL[24]);?><? echo translateString('Notify about new messages from other contacts while chatting');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
      <td><? checkbox(25, $readBOOL[25]);?><? echo translateString('Use Tabs to chat');?></label></td>
      <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? checkbox(26, $readBOOL[26]);?><? echo translateString('Close Tabs when logging out');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(37, $readBOOL[37]);?><? echo translateString('Show OTR status');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(17, $readBOOL[17]);?><? echo translateString('Show Users Away message');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(18, $readBOOL[18]);?><? echo translateString('Show Users X-Status');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? echo translateString('format of timestamp');?>:<br />
      <table border="0" cellspacing="0" cellpadding="0">
       <tr>
        <td width="40"><span class="style3"><? echo translateString('day');?>:</span></td>
        <td width="242"><span class="style3">d=2num, j=1num, D=3char, l=fullchar</span></td>
       </tr>
       <tr>
        <td><span class="style3"><? echo translateString('month');?>:</span></td>
        <td><span class="style3">m=2num, n=1num, M=3char, F=fullchar</span></td>
       </tr>
       <tr>
        <td><span class="style3"><? echo translateString('year');?>:</span></td>
        <td><span class="style3">Y=4num, y=2num</span></td>
       </tr>
       <tr>
        <td><span class="style3"><? echo translateString('hours');?>:</span></td>
        <td><span class="style3">12h: h=2num, g=1num, a=am/pm<br />
            24h: H=2num, G=1num</span></td>
       </tr>
       <tr>
        <td><span class="style3"><? echo translateString('minutes');?>:</span></td>
        <td><span class="style3">i=2num, </span></td>
       </tr>
       <tr>
        <td><span class="style3"><? echo translateString('sec');?>:</span></td>
        <td><span class="style3">s=2num</span></td>
       </tr>
      </table>
      <label><input name="str7" type="text" value="<? echo $readSTR[7];?>"/></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateString('prefix shown in front of incoming messages');?>:<br />
      <span class="style3"><? echo translateStringAdv('%s for icons', '&lt;img src=\'***Path***\'&gt;');?></span></label><br />
      <input name="str5" type="text" value="<? echo fixforHTML($readSTR[5]);?>"/></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><label><? echo translateString('prefix shown in front of outgoing messages');?>:<br />
      <span class="style3"><? echo translateStringAdv('%s for icons', '&lt;img src=\'***Path***\'&gt;');?></span><br />
      <input name="str4" type="text" value="<? echo fixforHTML($readSTR[4]);?>"/></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
      <td><? checkbox(12, $readBOOL[12]);?><? echo translateString('Show input over chat');?></label></td>
      <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
      <td><? checkbox(16, $readBOOL[16]);?><? echo translateString('Show quickreply over chat');?></label></td>
      <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
      <td><? checkbox(15, $readBOOL[15]);?><? echo translateString('Single line reply (Enter=send)');?></label></td>
      <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr>
 <td><label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label></td>
</tr>
</table>
<?
}elseif( $_GET['page']=='quick'){
?>
<? echo translateString('Quickreply Settings');?>:<br />
<table border="1" cellspacing="0" cellpadding="0">
<tr>
 <td><a href="editor.php?edit=quick"><? echo translateString('open QuickReplyEditor');?></a></td>
</tr>

<tr><td>
 <table><tr>
  <td><? checkbox(33, $readBOOL[33]);?><? echo translateString('Turn on Quickreply');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? checkbox(14, $readBOOL[14]);?><? echo translateString('Show input and quickreply at the same time');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
      <td><? checkbox(16, $readBOOL[16]);?><? echo translateString('Show quickreply over chat');?></label></td>
      <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><label><? echo translateString('background color for buttons');?>:<br />
      <span class="style3"><? echo translateString('default');?>: #FFFF99 <a href="http://www.somacon.com/p142.php" target="_BLANK"><? echo translateString('other values');?></a></span><br />
      <input name="str14" type="text" value="<? echo $readSTR[14];?>" size="6" /></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr>
 <td><label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label></td>
</tr>
</table>
<?
}elseif( $_GET['page']=='smileys'){
echo translateString('Smileys Settings');?>:
<table border="1" cellspacing="0" cellpadding="0">
<tr><td>
 <table><tr>
  <td><a href="editor.php?edit=smile"><? echo translateString('edit smileys');?></a></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td><? checkbox(9, $readBOOL[9]);?><? echo translateString('use smileys');?><br />
      <span class="style3"><? echo translateStringAdv('get Smileypack from %s unpac it to inc/smileys/ or use the editorsmiley', 'http://legoking.le.funpic.de/webi/smileys/');?></span></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15"> </td>
  <td><? checkbox(10, $readBOOL[10]);?><? echo translateString('use protocol specific smileys');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15"> </td>
  <td><? checkbox(11, $readBOOL[11]);?><? echo translateString('smileys have to be surrounded with whitespaces');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15"> </td>
  <td><label><? echo translateString('maximum size of smileys');?><br />
      <input name="str12" type="text" value="<? echo $readSTR[12];?>" size="6" maxlength="4"/></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr>
 <td><label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label></td>
</tr>
</table>
<?
}elseif( $_GET['page']=='avatar'){
echo translateString('Avatar Settings')?>:
 <table border="1" cellspacing="0" cellpadding="0">
<tr><td>
 <table><tr>
  <td><? checkbox(7, $readBOOL[7]);?><? echo translateString('enable avatars');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? checkbox(34, $readBOOL[34]);?><? echo translateString('refresh avatars every time (can cause huge serverload/errors)');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><label><? echo translateString('maximum size of avatar');?><br /><input name="str9" type="text" value="<? echo $readSTR[9];?>" size="6" maxlength="4"/>px</label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? echo translateString('quality of avatar');?><br />
      <input name="str10" type="text" value="<? echo $readSTR[10];?>" size="6" maxlength="4"/></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><? echo translateString('avatar file if no contact/protocol specific one');?><br />
      <input name="str11" type="text" value="<? echo $readSTR[11];?>"/></td>
	  <td><?
		$file = str_replace('\\', '/', $readSTR[11]);
		if(file_exists($file))
			echo translateString('Current').':<img src="'.$file.'">';
		else
			echo translateString('Input invalid');
		?></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr>
 <td><label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label></td>
</tr>
</table>
<?
}elseif( $_GET['page']=='files'){
echo translateString('File Settings');?>:
<table border="1" cellspacing="0" cellpadding="0">
<tr><td>
 <table><tr>
  <td><? checkbox(13, $readBOOL[13]);?><? echo translateString('enable Filesupport');?></label></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<?
$add = '';
if(DISABLE_AUTO_ACCEPT_FILES_SETTING){
	$add = 'disabled="disabled"';
	$echotip = translateString('To make this field editable change the settings in Miranda -> Mainmenu -> Webi Settings');
}else{
	$echotip = translateString('To make this field uneditable change the settings in Miranda -> Mainmenu -> Webi Settings');
}
if(mb_CSettingGet(0, 'SRFile', 'AutoAccept')==1)
	$add .= ' checked="checked"';
?>
<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><label><input name="fileaccept" type="checkbox" value="1" <? echo $add; ?>/><? echo translateString('autoaccept files');?></label><br/><span class="style3"><? echo $echotip;?></span></td>
  <td><input type="hidden" name="existfileaccept" value="1"/></td>
 </tr></table>
</td></tr>

<?
$add = '';
if(DISABLE_REMOTE_SEND_FILES){
	$echotip = translateString('To enable this function change the settings in Miranda -> Mainmenu -> Webi Settings');
}else{
	$add = ' checked="checked"';
	$echotip = translateString('To disable this function change the settings in Miranda -> Mainmenu -> Webi Settings');
}	
?>
<tr><td>
 <table><tr>
  <td width="15">&nbsp;</td>
  <td><label><input type="checkbox" disabled="disabled" <? echo $add;?>/><? echo translateString('make it possible to send files located on Webi host');?></label><br/><span class="style3"><? echo $echotip;?></span></td>
  <td>&nbsp;</td>
 </tr></table>
</td></tr>

<tr>
 <td><label><input name="change" type="submit" value="<? echo translateString('save');?>"/></label></td>
</tr>
</table>
<?
}else{
	echo translateString('wrong argument');
}
?>
</form>
</body>
</html>
