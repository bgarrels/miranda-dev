<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
*
*/
if(mb_CSettingGet(NULL,'Webi','login')===false){
	echo "You first have to set the secure settings over Mirnad -> Mainmenue -> Webi settings";
	exit;
}
include("inc/comun.inc.php");
if(CLOSE_TABS && file_exists('inc/settings/opentabs.txt'))
	unlink('inc/settings/opentabs.txt');

if(mt_getvar('disable-Webi')) {
	include("inc/header.inc.php");
	echo 'Webi was disabeled over the Miranda menu';
	exit;
}

$update = "";
$needupdate = false;
if( CHECK_FOR_UPDATE && !isset($_GET['noupdate']))
	include("checkupdate.php");

if($needupdate && AUTO_UPDATE)
	$redir = 'update.php';
elseif($needupdate)
	$redir = 'index.php';
elseif(mb_CSettingGet(null, 'Webi', 'question')<2025)
	$redir = 'question.php';
else
	$redir = '';
if(isset($_GET['logout']) && $_GET['logout']==1){
}elseif((!LOGIN_ENABLED || (isset($_SESSION[SESSION_NAME]) && $_SESSION[SESSION_NAME] == USER)) && !$needupdate) {
	@session_start();
	$_SESSION['lastactiontime'] = time();
	redirectToLocal('clist.php');
	exit;
}elseif((!LOGIN_ENABLED || (isset($_SESSION[SESSION_NAME]) && $_SESSION[SESSION_NAME] == USER)) && $needupdate){
	@session_start();
	$_SESSION['lastactiontime'] = time();
	echo $update.'<br /><br /><a href="clist.php">'.translateString('Continue with old version').'</a>';
	exit;
}else{
	$sucessful = false;
	for($x=0; $x<5; $x++){
		$way = mb_CSettingGet(NULL,'Webi','acco1'.$x);
		$ip = mb_CSettingGet(NULL,'Webi','acco2'.$x);
		if($way=="ip" && $ip==$_SERVER['REMOTE_ADDR']){
			$sucessful=true;
			break;
		}elseif($way=="dns" && gethostbyname($ip)==$_SERVER['REMOTE_ADDR'] && $ip!=$_SERVER['REMOTE_ADDR']){
			$sucessful=true;
			break;
		}
	}
	if($sucessful){
		redirectToLocal('login.php?iplogin=1&redir='.$redir);
		exit;
	}
}
include("inc/header.inc.php");

?>
<script type="text/javascript">
var newwindow;
function poptastic(url)
{
	newwindow=window.open(url,'name','height='+window.Height+',width='+window.Width+'resizable=yes,scrollbars=yes');
	if (window.focus) {newwindow.focus()}
}
</script>
<script type="text/javascript">
function setFocus(){
document.getElementById("user").focus()
}
</script>
</head><body onLoad="setFocus();">
	<br />
	<div style="font-weight:bold; text-align:center">
		Webi - Miranda Mobile<br />
<? if($needupdate){
	echo translateString('New Updates are available!!!').' '.translateString('Yours is').' V. '.substr($version,0,1).'.'.substr($version,1).'<br />'.translateString('You need to login to update').'<br />';
}else{
	echo $update;
}?>
	</div>
	<br />

	<form action="login.php?redir=<? echo $redir;?>" method="post">
	<table width="390" border="0" cellspacing="0" cellpadding="0" align="center">

		<tr>
			<td style="font-weight:bold"><?php echo translateString('User'); ?>:</td>
			<td><input type="text" id="user" name="user" maxlength="20" size="30" /></td>
		</tr>

		<tr>
			<td style="font-weight:bold"><?php echo translateString('Password'); ?>:</td>
			<td><input type="password" name="pass" maxlength="255" size="30" /></td>
		</tr>

		<?php if(CAPTCHA_ENABLED) { ?>

			<tr>
				<td colspan="2" style="text-align:center">
					&nbsp;<br />
					<span style="font-weight:bold; font-size: 10px"><?php echo translateString('Write the following characters'); ?>:</span> <br />
	
					<?php
					$campoCaptcha = "loginCaptcha";
					require("inc/captcha/captchaForm.inc.php");
					?>
				
				</td>
			</tr>
<? }
if(mb_CSettingGet(NULL,'Webi','b38')!=1){
?>
<tr>
  <td><input type="checkbox" value="1" name="mobilesetting"/></td>
  <td><?php echo translateString('Use Mobile Settings'); ?></td>
</tr>
<?
}
?>
<tr>
  <td><input type="checkbox" value="1" name="logintimer"/></td>
  <td><?php echo translateString('Limit logintime to'); ?>
    <input name="hours" type="text" value="01" size="4" maxlength="2">
    h
    :
    <input name="minutes" type="text" value="00" size="4" maxlength="2">
    min</td>
</tr>

		<tr>
			<td colspan="2" style="text-align:center">
				&nbsp;<br />
				<input type="submit" value="<?php echo translateString('Login'); ?>" />
			</td>
		</tr>
	</table>

	<div align="center"><br />
	    <a href="javascript:poptastic('index.php');"><?php echo translateString('try to fix constant width');?>
      </a>
    </div>
</form>

<?php include("inc/end.inc.php"); ?>