<?php
/*
*
*  Webi - Miranda Mobile
*  by MPK
* http://legoking.le.funpic.de/webi/
*  ICQ: 294823182
* 
* originally based on Miranda IM Mobile for MBot/MSP
*  by Felipe Brahm (aka souFrag)
*
*/

include("inc/comun.inc.php");
require_once('inc/security.inc.php');
?><?php

include("inc/phpthumb.bmp.php"); //http://phpthumb.sf.net

function getFileExtension($file) {
	$pos = strrpos($file, '.');
	if($pos===false)
		return false;
	else
		return strtolower(substr($file,$pos+1));
}

if(isset($_GET["cid"]))
	$cid = $_GET["cid"];
else
	exit();

if(!REFRESH_AVATAR && file_exists('fotos/avatars/'.$cid.'.jpg') && !isset($_GET['full'])){
	header('Location: fotos/avatars/'.$cid.'.jpg');
	exit();
}

if(AVATAR_MAX_SIZE > 0)
	$max_size = AVATAR_MAX_SIZE;
else
	$max_size = 90;
if(AVATAR_QUALIY > 5)
	$quality = AVATAR_QUALIY;
else
	$quality = 85;

$image_file = mb_CSettingGet($cid, "ContactPhoto", "File"); //set source file
$image_file = str_replace('\\', '/', $image_file);
$image_file = str_replace('//', '/', $image_file);

if(!file_exists($image_file) && mb_CSettingGet($cid, "ContactPhoto", "RFile")){
	$image_file = mb_SysGetMirandaDir().'/'.mb_CSettingGet($cid, "ContactPhoto", "RFile");
	$image_file = str_replace('\\', '/', $image_file);
	$image_file = str_replace('//', '/', $image_file);
}

$extension = getFileExtension($image_file);
if(!file_exists($image_file) || !in_array($extension, $allowedAvatarExtensions)){
	$proto = mb_CGetProto($cid);
	$image_file = mb_SysGetMirandaDir().'/'.mb_CSettingGet(null, 'AVS_ProtoPics', $proto);
	if(file_exists(mb_SysGetMirandaDir().$image_file))
		$image_file = mb_SysGetMirandaDir().$image_file;
	$image_file = str_replace('\\', '/', $image_file);
	$image_file = str_replace('//', '/', $image_file);
}

$extension = getFileExtension($image_file);
if(!file_exists($image_file) || !in_array($extension, $allowedAvatarExtensions)){
	$proto = mb_CGetProto($cid);
	$image_file = mb_CSettingGet(null, 'AVS_ProtoPics', $proto);
	if(file_exists(mb_SysGetMirandaDir().'/'.$image_file))
		$image_file = mb_SysGetMirandaDir().$image_file;
	$image_file = str_replace('\\', '/', $image_file);
	$image_file = str_replace('//', '/', $image_file);
}

if($image_file === FALSE || !file_exists($image_file))
	$image_file = NO_AVATAR_FILE;

$extension = getFileExtension($image_file);

if(!in_array($extension, $allowedAvatarExtensions))
	$image_file = NO_AVATAR_FILE; //unsupported avatar file format

$extension = getFileExtension($image_file);
if(!in_array($extension, $allowedAvatarExtensions))
	exit();

$size = getimagesize($image_file); //get original size

if(!isset($_GET['full'])){
	if($size[1]<=$size[0]){
	 $new_width=$max_size;
	 $new_height=$max_size*$size[1]/$size[0];
	}else{
	 $new_height=$max_size;
	 $new_width=$max_size*$size[0]/$size[1];
	}

	//sizes should be integers
	$new_width = round($new_width);
	$new_height = round($new_height);
}

//load original image
switch($extension) {

	case 'jpg':
	case 'jpeg':
	
		$image_big = imagecreatefromjpeg($image_file);
		break;

	case 'gif':

		$image_big = imagecreatefromgif($image_file);
		break;

	case 'bmp':

		$bmp2gd_instance = new phpthumb_bmp();
		$bmp2gd = $bmp2gd_instance->phpthumb_bmpfile2gd($image_file);
		$image_big = $bmp2gd;
		break;

	case 'png':

		$image_big = imagecreatefrompng($image_file);
		break;

	default:
		exit();
		break;

}

if(isset($_GET['full'])){
	header("Content-type: image/jpeg");
	header('Content-Disposition: filename='.$cid.'.jpg');
	imagejpeg($image_big, null, $quality);
	imagedestroy($image_big);
	exit();
}

$image_small = imagecreatetruecolor($new_width, $new_height); //create new image

imagecopyresized($image_small, $image_big, 0, 0, 0, 0, $new_width, $new_height, $size[0], $size[1]);

imagedestroy($image_big); //the original data are no longer used

//finally send image to browser and destroy no longer needed data.
imagejpeg($image_small, 'fotos/avatars/'.$cid.'.jpg', $quality);
imagedestroy($image_small);
header('Location: fotos/avatars/'.$cid.'.jpg');

exit();

?>