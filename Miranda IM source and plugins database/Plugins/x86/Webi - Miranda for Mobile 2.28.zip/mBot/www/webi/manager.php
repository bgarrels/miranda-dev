<?
include("inc/comun.inc.php");
if($_SERVER['REMOTE_ADDR']!='127.0.0.1'){
	redirectToLocal('index.php');
	exit;
}
if(!isset($_GET['delete'])){
	echo translateString('Last actions:').'<br>';
	$dir = mb_SysGetMirandaDir().'/mbot/temp';
	$dirhand = dir($dir);
	clearstatcache();
	$session = "";
	if(isset($_COOKIE['phpsessid']))
		$session = $_COOKIE['phpsessid'];
	while($file = $dirhand->read()){
		if($file != '.' && $file != '' && $file != '..' && !is_dir($file) && $file != 'sess_'.$session){
			echo date(DATE_FORMAT,fileatime($dir.'/'.$file)).'<br>';
		}
	}
	echo '<br><a href="manager.php?delete=1">'.translateString('Log everyone out, by deleting old sessions.').'</a>';
}else{
	$dir = mb_SysGetMirandaDir().'/mbot/temp';
	$dirhand = dir($dir);
	if(isset($_COOKIE['phpsessid']))
		$session = $_COOKIE['phpsessid'];
	while($file = $dirhand->read()){
		if($file != '.' && $file != '' && $file != '..' && !is_dir($file) && $file != 'sess_'.$session){
			unlink($dir.'/'.$file);
		}
	}
	redirectToLocal('manager.php');
}