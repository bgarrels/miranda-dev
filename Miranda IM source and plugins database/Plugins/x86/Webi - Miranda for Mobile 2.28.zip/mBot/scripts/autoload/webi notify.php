<?php
function mbot_load()
{
	mb_SelfRegister(MB_EVENT_MSG_IN,0);
	if(mb_CSettingGet(NULL,'Webi-mail','support')!=1){
		$mid = mb_MenuAdd('Mail notification off',0,'sendMail',mb_IconLoadSkin(213), 0x04, null, null, null, null, 1);
		mt_setvar('webmailmenu', $mid, 1, 0);
		mt_setvar('webiCharset', 'iso-8859-1', 1, 0);
	}else{
		$mid = mb_MenuAdd('Mail notification off',0,'sendMail',mb_IconLoadSkin(213), 0x00, null, null, null, null, 1);
		mt_setvar('webmailmenu', $mid, 1, 0);
		mt_setvar('webmailtime', mb_CSettingGet(NULL,'Webi-mail','min') * 60 + mb_CSettingGet(NULL,'Webi-mail','sec') , 1, 0);
		$encodable = mb_list_encodings();
		$valid = false;
		$charset = mb_CSettingGet(NULL,'Webi','s0');
		foreach($encodable as $codepack){
			if(strtolower($codepack)==strtolower($charset)){
				$valid = true;
				break;
			}
		}
		if(!$valid){
			mt_setvar('webiCharset', 'iso-8859-1', 1, 0);
		}else{
			mt_setvar('webiCharset', $charset, 1, 0);
		}
	}
	mt_setvar('webmail', 'off', 1, 0);
}

function sendMail($param,$cid,$hmenu){
	if(mb_CSettingGet(NULL,'Webi-mail','support')!=1){
		mt_setvar('webmail', 'off', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification off', null, 0x04, 'sendMail');
	}elseif(mt_getvar('webmail')==='off'){
		mt_setvar('webmail', 'on', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification on', null, 0x00, 'sendMail');
	}else{
		mt_setvar('webmail', 'off', 1, 0);
		mb_MenuModify($hmenu, 'Mail notification off', null, 0x00, 'sendMail');
	}
}

function mbe_MsgIn($cid,$body,$timestamp,$known){
	if(mt_getvar('webmail')=='on'){
		$proto = mb_CGetProto($cid);
		if(mb_CSettingGet(NULL,'Webi-mail','sendForMeta')!=1 && $proto=='MetaContacts')
			return;
		$last = mb_EventFindLast($cid);
		list($oldmodule, $oldtype, $oldtimestamp, $oldflags, $oldbody) = mb_EventGetData($last, 0);
		if($oldtimestamp + mt_setvar('webmailtime') < $timestamp){
			$head = mb_CSettingGet(NULL,'Webi-mail','header');
			if($head == false){
				$head = '1 new message from %nick% (%proto%)';
			}
			$txt = mb_CSettingGet(NULL,'Webi-mail','body');
			if($txt == false){
				$txt = '%text%';
			}
			$nick = mb_CGetDisplayName($cid);
			$head = str_replace('%nick%', $nick, str_replace('%proto%', $proto, $head));
			$head = mb_convert_encoding($head, "UTF-8",mt_getvar('webiCharset'));
			if(mb_convert_encoding($body,mt_getvar('webiCharset'), "UTF-8")==mb_convert_encoding(mb_convert_encoding($body,mt_getvar('webiCharset'), "UTF-8"),mt_getvar('webiCharset'), "UTF-8")){
				$bodyenc=mb_convert_encoding($body, "UTF-8",mt_getvar('webiCharset'));
			}else{
				$bodyenc=$body;
			}
			$head = str_replace('%text%', $bodyenc, $head);
			$txt = str_replace('%text%', $bodyenc, str_replace('%nick%', $nick, str_replace('%proto%', $proto, $txt)));
			if(file_exists(mb_SysGetMirandaDir().'/mBot/www/webi/inc/transliteration.php')){
				include('file://'.mb_SysGetMirandaDir().'/mBot/www/webi/inc/transliteration.php');
			}
			require('file://'.mb_CSettingGet(NULL,'MBot','WWWRoot').'/webi/inc/mail/class.phpmailer.php');
			$mail = new PHPMailer();
			if(!strpos(mb_CSettingGet(NULL,'Webi-mail','to'),'@')){
				mb_ConsoleShow(1);
				mb_Echo('invalid recipiant', 0);
			}
			$mail->AddAddress(mb_CSettingGet(NULL,'Webi-mail','to'));
			$mail->CharSet = 'utf-8';
			$mail->IsSMTP();
			$mail->Host = mb_CSettingGet(NULL,'Webi-mail','smtp-host');
			$mail->Port = mb_CSettingGet(NULL,'Webi-mail','smtp-port');
			$mail->From = mb_CSettingGet(NULL,'Webi-mail','from');
			$mail->FromName = 'Webi';
			if(mb_CSettingGet(NULL,'Webi-mail','smtp-auth')==1){
				$mail->SMTPAuth = true;
				$mail->Username = mb_CSettingGet(NULL,'Webi-mail','smtp-user');
				$mail->Password = mb_CSettingGet(NULL,'Webi-mail','smtp-pass');
			}else{
				$mail->SMTPAuth = false;
			}
			$mail->Subject = $head;
			$mail->Body = $txt;
			
			if(!$mail->Send()){
				mb_ConsoleShow(1);
				mb_Echo("
			could not send mail: " . $mail->ErrorInfo.'
			', 0);
			}
			/*$txt = mb_convert_encoding($txt,mt_getvar('webiCharset'), "UTF-8");			*/
		}
	}
}
?>