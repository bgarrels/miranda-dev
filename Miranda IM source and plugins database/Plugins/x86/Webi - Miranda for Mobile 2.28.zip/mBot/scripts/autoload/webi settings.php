<?php
function mbot_load(){
	mb_SelfRegister(MB_EVENT_MENU_COMMAND,1); 		//just because something has to be registered
	$sub = mb_CSettingGet(NULL,'Webi','submenu');
	if($sub == 1){
		mb_MenuAdd(mb_SysTranslate('Webi Settings'),0,'Webi_Menu',mb_IconLoadSkin(SKINICON_EVENT_URL), null, null, null, null, null, 0);
		$disablemenue = mb_MenuAdd(mb_SysTranslate('Webi is on'),0,'Webi_on',mb_IconLoadSkin(218), null, null, null, null, null, 0);
	}else{
		mb_MenuAdd(mb_SysTranslate('Webi Settings'),0,'Webi_Menu',mb_IconLoadSkin(SKINICON_EVENT_URL), null, null, null, null, null, 1);
		$disablemenue = mb_MenuAdd(mb_SysTranslate('Webi is on'),0,'Webi_on',mb_IconLoadSkin(218), null, null, null, null, null, 1);
	}
	mt_setvar('disable-Webi', false, 1, 0);
	mt_setvar('disable-Webimenu', $disablemenue, 1, 0);
}

function Webi_on(){
	if(mt_getvar('disable-Webi')){
		mb_MenuModify(mt_getvar('disable-Webimenu'), mb_SysTranslate('Webi is on'), mb_IconLoadSkin(218), null, 'Webi_on');
		mt_setvar('disable-Webi', false, 1, 0);
	}else{
		mb_MenuModify(mt_getvar('disable-Webimenu'), mb_SysTranslate('Webi is off'), mb_IconLoadSkin(219), null, 'Webi_on');
		mt_setvar('disable-Webi', true, 1, 0);
	}
}

function Webi_Menu(){
	if(@mt_getvar('running') == 1){
		mb_msgbox(mb_SysTranslate("Cannot open 2 settings dialogs at once."),"Error: Double settings");
	}else{
		$dlg = mb_DlgCreate(mb_SysTranslate('Webi Settings'), 'Webi_callback', 280, 280, 0);

		mb_DlgAddControl($dlg,1,mb_SysTranslate('Protected Webi Settings'),50,10,275,15,null);//1000
			
		mb_DlgAddControl($dlg,2,mb_SysTranslate('enable login'),5,20*(2),180,20,'protcb',0x00000002,0);//1001
		mb_DlgSendMsg($dlg,1001,0x00F1,mb_CSettingGet(NULL,'Webi','login'),0);
	
		mb_DlgAddControl($dlg,1,mb_SysTranslate('User'),10,20*(3),120,20,null);//1002
		mb_DlgAddControl($dlg,3,'user',120,20*(3),100,20,null,0x00800000|0x0080|0x00000000);//1003
		mb_DlgSetText($dlg,1003,mb_CSettingGet(NULL,'Webi','user'));
	
		mb_DlgAddControl($dlg,1,mb_SysTranslate('Password'),11,20*(4),120,20,null);//1004
		mb_DlgAddControl($dlg,3,'pass',120,20*(4),100,20,null,0x0020|0x00800000|0x0080|0x00000000);//1005
		mb_DlgSetText($dlg,1005,'***');
	
		mb_DlgAddControl($dlg,1,mb_SysTranslate('repeat Password'),11,20*(5),120,20,null);//1006
		mb_DlgAddControl($dlg,3,'pass2',120,20*(5),100,20,null,0x0020|0x00800000|0x0080|0x00000000);//1007
		mb_DlgSetText($dlg,1007,'***');
	
		mb_DlgAddControl($dlg,2,mb_SysTranslate('enable remotesend'),5,20*(6),280,20,'protcb',0x00000002,0);//1008
		mb_DlgSendMsg($dlg,1008,0x00F1,mb_CSettingGet(NULL,'Webi','remote'),0);
			
		mb_DlgAddControl($dlg,2,mb_SysTranslate('autoaccept setting editable'),5,20*(7),280,20,'protcb',0x00000002,0);//1009
		mb_DlgSendMsg($dlg,1009,0x00F1,mb_CSettingGet(NULL,'Webi','autoaccept'),0);
	
		mb_DlgAddControl($dlg,2,mb_SysTranslate('place settings in MBot submenu'),5,20*(8),280,20,'protcb',0x00000002,0);//1010
		mb_DlgSendMsg($dlg,1010,0x00F1,mb_CSettingGet(NULL,'Webi','submenu'),0);
	
		mb_DlgAddControl($dlg,2,mb_SysTranslate('open session manager'),5,20*(9),200,20,'manager');//1011
	
		if(mb_DlgRun($dlg)){
			mt_setvar('running',1,1);
		}
		mb_DlgMove($dlg, NULL, 300, 200);
	}
}

function protcb($param){
	$dlg = mb_DlgGet();
	if (mb_DlgSendMsg($dlg,$param,0x00F0,0,0) == 0x0000){	//if button unchecked
		mb_DlgSendMsg($dlg,$param,0x00F1,0x0001,0);//check it
	}else
		mb_DlgSendMsg($dlg,$param,0x00F1,0x0000,0);//uncheck it
}

function manager($param){
	$addr = mb_SysGetProcAddr('shell32.dll','ShellExecuteA');
	mb_SysCallProc($addr,0, 'open', 'http://localhost:'.mb_CSettingGet(NULL,'MBot','WWWPort').'/webi/manager.php','','',5);
}

function Webi_callback($ok,$param) { 
	if($ok == 0){
		mt_delvar('running');
		$result = mb_MsgBox(mb_SysTranslate('Do you want to visit Webi now?'), "Canceled", 4);
		if($result == 6){
			$addr = mb_SysGetProcAddr('shell32.dll','ShellExecuteA');
			mb_SysCallProc($addr,0, 'open', 'http://localhost:'.mb_CSettingGet(NULL,'MBot','WWWPort').'/webi','','',5); 
		}
		return 1;
	}
	$dlg = mb_DlgGet();
	if (mb_DlgSendMsg($dlg,1001,0x00F0,0,0) == 0x0000)
		$login = 0;
	else
		$login = 1;
	$user = mb_DlgGetText($dlg,1003);
	$pass = mb_DlgGetText($dlg,1005);
	$pass2 = mb_DlgGetText($dlg,1007);
	if (mb_DlgSendMsg($dlg,1008,0x00F0,0,0) == 0x0000)
		$remote = 0;
	else
		$remote = 1;
	if (mb_DlgSendMsg($dlg,1009,0x00F0,0,0) == 0x0000)
		$autoaccept = 0;
	else
		$autoaccept = 1;
	if (mb_DlgSendMsg($dlg,1010,0x00F0,0,0) == 0x0000)
		$submenu = 0;
	else
		$submenu = 1;
	if($login==1 && (trim($user)=='' || trim($pass)=='')){
		mbox(mb_SysTranslate('No empty username or password allowed!'), 'Error');
		return;
	}
	if($pass != $pass2){
		mbox(mb_SysTranslate('Passwords don\'t match!'), 'Error');
		return;
	}
	$old = mb_CSettingGet(NULL,'Webi','pass');
	if($login==1 && $pass == '***' && (crypt('', $old) == $old || $old===false)){
		mbox(mb_SysTranslate('You have to set a password!'), 'Error');
		return;
	}
	//finally save changes
	if($login==0){
		mb_CSettingAdd(null, 'Webi', DBVT_ASCIIZ, 'user', '');
		mb_CSettingAdd(null, 'Webi', DBVT_ASCIIZ, 'pass', crypt(''));
		mb_CSettingAdd(null, 'Webi', DBVT_BYTE, 'login', 0);
	}else{
		mb_CSettingAdd(null, 'Webi', DBVT_ASCIIZ, 'user', $user);
		if($pass!='***')
			mb_CSettingAdd(null, 'Webi', DBVT_ASCIIZ, 'pass', crypt($pass));
		mb_CSettingAdd(null, 'Webi', DBVT_BYTE, 'login', 1);
	}
	mb_CSettingAdd(null, 'Webi', DBVT_BYTE, 'remote', $remote);
	mb_CSettingAdd(null, 'Webi', DBVT_BYTE, 'autoaccept', $autoaccept);
	mb_CSettingAdd(null, 'Webi', DBVT_BYTE, 'submenu', $submenu);
	
	mt_delvar('running');
	$result = mb_MsgBox(mb_SysTranslate('Modification saved').'
'.mb_SysTranslate('Do you want to visit Webi now?'), "Final", 4);
	if($result == 6){
		$addr = mb_SysGetProcAddr('shell32.dll','ShellExecuteA');
		mb_SysCallProc($addr,0, 'open', 'http://localhost:'.mb_CSettingGet(NULL,'MBot','WWWPort').'/webi','','',5); 
	}
	return 1; 
} 
?>



