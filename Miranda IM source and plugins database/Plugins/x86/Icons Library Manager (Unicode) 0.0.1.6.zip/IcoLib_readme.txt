Icons Library Manager
---------------------

Version 0.0.1.5
by Denis Stanishevskiy // StDenis
by Joe Kucera aka Jokusoftware
for Miranda


Description
-----------

This service plugin provides UI to customize plugin's icons. It adds no
functionality on its own. It only provides generic services for other
plugins.
 

Installation
------------

For the icolib.zip zip archive - 
  Extract IcoLib.dll to Miranda plugin folder  - 
  usually this is C:\Program Files\Miranda\plugins.
  All other files are not mandatory and can go to Miranda folder. 


License
-------

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the copyright
   notice, this list of conditions and the following disclaimer.
2. The origin of this software must not be misrepresented; you must 
   not claim that you wrote the original software.  If you use this 
   software in a product, an acknowledgment in the product 
   documentation would be appreciated but is not required.
3. Altered source versions must be plainly marked as such, and must
   not be misrepresented as being the original software.
4. The name of the author may not be used to endorse or promote 
   products derived from this software without specific prior written 
   permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

For more information, e-mail jokusoftware@miranda-im.org


Version history
---------------

0.0.1.6
 fixed compatibility problems with some plug-ins (e.g. Fingerprint)
 
0.0.1.5
 added optional sorting of icons
 fixed section creation order dependency (now the order does not matter)
 GDI handling improvements
 some other internal fixes

0.0.1.4 (internal)
 some fixes (thx Bio)

0.0.1.3
 fixed multi-level sections (duplicates were created)
 improved Updater support

0.0.1.2
 small visual re-design (thx Faith Healer)
 enhanced section tree - now accepts multiple-levels
 fixed some unicode glitches
 other small fixes

0.0.1.1
 do not keep ico files open
 use windows API for icons with standard dimensions
 fixed .ico files support was still broken for most icons
 fixed memory leak
 
0.0.1.0 (New developer: Joe @ Whale)
 many internal tweaks (uses less GDI resources)
 added unicode support (2in1)
 support for .ico files is back

0.0.0.3 (Not published)
 support for icons with non-standard sizes

0.0.0.2
 changes in layout of options
 service for GenMenu
 early stage of iconpacks support
 changes of context menu
 
0.0.0.1
 tech. demo


Translation
-----------

IcoLib plugin can be translated via the Miranda language files.
The required strings are provided in langpack_icolib.txt file.
