Window Start Position
by souFrag / Felipe Brahm
ICQ#50566818
http://www.felipebrahm.com
http://www.soufrag.cl

Description:

Makes the Contact List always start on the right or left side of the screen: "X" pixels away from the top, "K" pixels from the bottom and "R" pixels from the side of the Work Area of your main monitor.

You may also select the width of the CList.

You may also select to start the window minimized to the system tray.