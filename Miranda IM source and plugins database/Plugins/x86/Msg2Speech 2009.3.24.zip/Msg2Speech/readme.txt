Miranda IM Mesg2Speech Plugin

This plugin speaks incoming text messages using Acapela Group Speech API, which is the best text speaking engine nowadays, especially when you need Russian language. 
Learn more at http://www.acapela-group.com/

Note that no warranty is provided. Use this plugin at your own risk!

Also note that Acapela Group software used by this plugin is commercial so you will probably need to purchase a license.
(Personally I used a trial version to develop this plugin)

So, if you still want to use Msg2Speech�
1. Download and install Infovox Desktop 2.2 (not sure about other versions).
2. Download and install any speech library for Infovox Desktop 2.2 (I used Alyona22k for Russian language).
3. Copy msg2speech.dll to Miranda IM Plugins folder.
4. Copy AcaTts.dll and AcaTts.ini to Miranda IM root folder.
5. Start Miranda IM.
6. Contact menu should have "Select voice" item. Select it.
7. Choose language library from the list.
8. Type equalizer name as you saved in Infovox Desktop Voice Manager if you need it.
9. Check �Speak contact info� to speak defined contact info before speaking the message.
10. Type something in �Present as� to speak it after or instead 9.
11. Select your local status when messages should be spoken.
12. Define maximum message length to speak - 0 means that plugin should speak the whole message as it is.
13. Use "Shut up" button to stop current speeh.

Note that these settings are separate for every contact in the list.

File langpack_russian_upd.txt contains the localization updates to Miranda IM russian language pack (need to bee copied to the end of original one).

If you encounter problems, please run Miranda IM with "�log" command line parameter (miranda32 -log) and email your problem description and file msg2speech.log (from Miranda IM root folder) to undwad@integra-s.com or undwad@mail.ru.

Enjoy!

24.03.2009
By Undwad 
