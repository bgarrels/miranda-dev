================================
    Synchronize Contact List
================================

Synchronizes local and server contact list at startup.
Considering the server list as the primary source there are 2 synchronization tasks:
- adding new contacts from the server which are not present in the local database (this is done by the ICQ plugin)
- deletion of local contacts which are not present in the server list (this is done by this plugin)

The plugin deletes ICQ contacts which don't exist in the server list from the local database at startup.

You can see the log of deletions in the "SyncCList.log" file in a temporary directory (echo %TEMP%).

Copyright 2007-2011 Daniel Lazarenko
http://forums.miranda-im.org/showthread.php?t=14794
