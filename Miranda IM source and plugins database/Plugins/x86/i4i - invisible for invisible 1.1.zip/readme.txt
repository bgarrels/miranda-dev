i4i - invisible for invisible
By MPK
download: http://addons.miranda-im.org/details.php?action=viewfile&id=3924
help under: http://forums.miranda-im.org/showthread.php?t=20448

---Description---
This script will set your Visible status to invisible, as soon as this Contact apears invisible or offline to you.
You can set single Contacts or whole Protocols so that they are not monitored, and their visibil status will only be changed manually.

---Install---
extract the archieve to your Miranda folder
restart Miranda
go to Mainmenu -> Invisible 4 Invisible. 
click 'edit ignored protocols' and check the ones that should not be monitored
back in the main menu click 'add contacts on invi/vilist to ignorelist' (you can also check who is ignored over 'edit ignored contacts')
click 'check whole clist'
now select enable and the settings you want to have and click ok
ready

---Uninstall---
To reverse most changes, first disable i4i over the Menu.
Restart Miranda
Go to the i4i Menu run a cleanup (lower buttons)
Close Miranda and delete the script in mbot/scripts/autoload