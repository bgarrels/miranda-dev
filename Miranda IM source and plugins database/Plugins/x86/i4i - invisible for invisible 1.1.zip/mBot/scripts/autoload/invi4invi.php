<?php
function mbot_load() 
{
	mb_SelfRegister(MB_EVENT_MENU_COMMAND,1);
	if(mb_CSettingGet(null,'Invi4Invi', 'popup')===1)
		mt_setvar('popups', true, 1);
	else
		mt_setvar('popups', false, 1);
	$sub = mb_CSettingGet(NULL,'Invi4Invi','submenu');
	if($sub == 1)
		mb_MenuAdd('Invisible 4 Invisible',0,'maindlg',mb_IconLoadSkin(7),null,null,null,null,null,0);	//adds main menu (submenu)
	else
		mb_MenuAdd('Invisible 4 Invisible',0,'maindlg',mb_IconLoadSkin(7),null,null,null,null,null,1);	//adds main menu
	if(mb_CSettingGet(null,'Invi4Invi', 'enable')==1){
		mb_MenuAdd('Monitored by i4i',0,'contactmenuaction',mb_IconLoadSkin(218),0x01,1,null,null,'contactmenuchange');	//adds contact menu
		if(mb_CSettingGet(null,'Invi4Invi', 'cleanup')==1){		//initializes scan for shutdown
			mb_SelfRegister(MB_EVENT_SHUTDOWN,0);
		}
		mb_SelfRegister(MB_EVENT_NEW_CSTATUS,1);		//initializes scan for statuschange
		if(mb_CSettingGet(null,'Invi4Invi', 'startup')==1){	//initializes scan at startup
			mb_SchReg('startInvi4Invi', '* * *', 'runComplete', 0, 0);
			mt_setvar('I4Iinitized', false, 1);
		}else
			mt_setvar('I4Iinitized', true, 1);
	}
}

//---main dialog
function maindlg(){
	if(@mt_getvar('i4imain') == 1){
		mb_msgbox(mb_SysTranslate("Cannot open 2 settings dialogs at once."),"Error: Double settings");
	}else{
		$dlg = mb_DlgCreate(mb_SysTranslate('I4I Settings'), 'savemaindlg', 280, 360, 0);

		mb_DlgAddControl($dlg,2,mb_SysTranslate('enable I4I'),5,5,270,20,'checkbox',0x00000002,0);//1000
		mb_DlgSendMsg($dlg,1000,0x00F1,mb_CSettingGet(NULL,'Invi4Invi','enable'),0);
		mb_DlgAddControl($dlg,2,mb_SysTranslate('clear lists at shutdown*'),15,5+20*(1),270,20,'checkbox',0x00000002,0);//1001
		mb_DlgSendMsg($dlg,1001,0x00F1,mb_CSettingGet(NULL,'Invi4Invi','cleanup'),0);
		mb_DlgAddControl($dlg,2,mb_SysTranslate('use Popups'),15,5+20*(2),270,20,'checkbox',0x00000002,0);//1002
		mb_DlgSendMsg($dlg,1002,0x00F1,mb_CSettingGet(NULL,'Invi4Invi','popup'),0);
		mb_DlgAddControl($dlg,2,mb_SysTranslate('check whole list at startup*'),15,5+20*(3),270,20,'checkbox',0x00000002,0);//1003
		mb_DlgSendMsg($dlg,1003,0x00F1,mb_CSettingGet(NULL,'Invi4Invi','startup'),0);
		mb_DlgAddControl($dlg,2,mb_SysTranslate('show settings in submen�*'),15,5+20*(4),270,20,'checkbox',0x00000002,0);//1004
		mb_DlgSendMsg($dlg,1004,0x00F1,mb_CSettingGet(NULL,'Invi4Invi','submenu'),0);
		mb_DlgAddControl($dlg,2,mb_SysTranslate('edit ignored protocols'),15,5+20*(5),160,20,'protodlg');//1005
		mb_DlgAddControl($dlg,2,mb_SysTranslate('edit ignored contacts'),15,5+20*(6),160,20,'contactdlg');//1006
		mb_DlgAddControl($dlg,2,mb_SysTranslate('reset contacts not in ignorelist'),15,5+20*(8),220,20,'mbe_ShutDown');//1007
		mb_DlgAddControl($dlg,2,mb_SysTranslate('check whole clist'),15,5+20*(9),220,20,'runComplete');//1008
		mb_DlgAddControl($dlg,2,mb_SysTranslate('add contacts on invi/vilist to ignorelist'),15,5+20*(10),250,20,'invi2ignore');//1009
		mb_DlgAddControl($dlg,2,mb_SysTranslate('clean up ignorelist (onli invi people stay)'),15,5+20*(11),250,20,'continueignore');//1010
		mb_DlgAddControl($dlg,2,mb_SysTranslate('put everyone to visible (even ignored)'),15,5+20*(12),250,20,'visiall');//1011
		mb_DlgAddControl($dlg,1,mb_SysTranslate('*active after restart'),15,10+20*(13),270,15,null);//1012

		if(mb_DlgRun($dlg)){
			mt_setvar('i4imain',1,1);
		}
		mb_DlgMove($dlg, NULL, 300, 200);
	}
}

//---save main dialog
function savemaindlg($ok,$param){
	if($ok == 0){
		mt_delvar('i4imain');
		return 1;
	}
	$dlg = mb_DlgGet();
	if (mb_DlgSendMsg($dlg,1000,0x00F0,0,0) == 0x0000){
		mt_setvar('I4Iinitized', false, 1);
		$enable = 0;
	}else{
		$enable = 1;
		mt_setvar('I4Iinitized', true, 1);
	}
	if (mb_DlgSendMsg($dlg,1002,0x00F0,0,0) == 0x0000){
		$popup = 0;
		mt_setvar('popups', false, 1);
	}else{
		$popup = 1;
		mt_setvar('popups', true, 1);
	}	
	if (mb_DlgSendMsg($dlg,1003,0x00F0,0,0) == 0x0000)
		$startup = 0;
	else
		$startup = 1;
	if (mb_DlgSendMsg($dlg,1001,0x00F0,0,0) == 0x0000)
		$cleanup = 0;
	else
		$cleanup = 1;
	if (mb_DlgSendMsg($dlg,1004,0x00F0,0,0) == 0x0000)
		$submen = 0;
	else
		$submen = 1;
	mb_CSettingAdd(null, 'Invi4Invi', DBVT_BYTE, 'enable', $enable);
	mb_CSettingAdd(null, 'Invi4Invi', DBVT_BYTE, 'popup', $popup);
	mb_CSettingAdd(null, 'Invi4Invi', DBVT_BYTE, 'startup', $startup);
	mb_CSettingAdd(null, 'Invi4Invi', DBVT_BYTE, 'cleanup', $cleanup);
	mb_CSettingAdd(null, 'Invi4Invi', DBVT_BYTE, 'submenu', $submen);
	
	mb_MsgBox(mb_SysTranslate('Settings saved'), 'saved');
	mt_delvar('i4imain');
	return 1;
}

//---contact dialog
function contactdlg(){
	if(@mt_getvar('i4idlg') == 1){
		mb_msgbox(mb_SysTranslate("Cannot open 2 settings dialogs at once."),"Error: Double settings");
	}else{
		mt_setvar('selcectedconcid',false,1);
		mt_setvar('selcectedconrow',false,1);
		$dlg = mb_DlgCreate('i4i - ignored contacts', 'closecontactdlg', 600, 280,0,1); // $param, $flags;
		$list_cntrl = mb_DlgAddControl($dlg,6,NULL,5,5,585,200,'managecontactdlg',0x00800000|0x0001|0x0004,0); //id=1000
		mb_DlgListAddCol($dlg,$list_cntrl,"cid",0);
		mb_DlgListAddCol($dlg,$list_cntrl,"aktiv",40);
		mb_DlgListAddCol($dlg,$list_cntrl,"User",160);
		mb_DlgListAddCol($dlg,$list_cntrl,"Protocol",90);
		mb_DlgAddControl($dlg,2,'none selected',10,210,300,20,'savecontactdlg',0x00000002,0);//1001
		
		$cid = mb_CFindFirst();
		do{
			$proto = mb_CGetProto($cid);
			if($proto =='' || mb_CSettingGet(null,'Invi4Invi',trim(strtolower($proto)))===0)
				continue;
			if(mb_CSettingGet($cid,'CList', 'Invi4Invi')===0)
				$akt = 'no';
			else
				$akt = 'yes';
			$user = mb_CGetDisplayName($cid);
			$group = mb_CSettingGet($cid, 'CList', 'Group');
			mb_DlgListAddItem($dlg,$list_cntrl,$cid,$akt,$user,$proto);
		}while($cid = mb_CFindNext($cid));

		if(mb_DlgRun($dlg)){
			mt_setvar('i4idlg',1,1);
		}
		mb_DlgMove($dlg, NULL, 150, 200);
	}
}

function managecontactdlg($id,$param,$item,$rb){
	if($item == -1)return 0;
	$dlg = mb_DlgGet(); 
	
		$list_row = $item;
		$cid = mb_DlgListGetItem($dlg,1000, $list_row, 0);
		$akt = mb_DlgListGetItem($dlg,1000, $list_row, 1);
		$name = mb_DlgListGetItem($dlg,1000, $list_row, 2);
		if($akt=='yes')
			mb_DlgSendMsg($dlg,1001,0x00F1,0x0001,0);
		else
			mb_DlgSendMsg($dlg,1001,0x00F1,0x0000,0);
		mt_setvar('selcectedconcid',$cid,1);
		mt_setvar('selcectedconrow',$list_row,1);
		mb_DlgSetText($dlg, 1001, 'monitor: '.$name);		
}

//---save contact dialog
function savecontactdlg(){
	$dlg = mb_DlgGet();
	if(mt_getvar('selcectedconcid')!==false){
		$cid = mt_getvar('selcectedconcid');		
		if (mb_DlgSendMsg($dlg,1001,0x00F0,0,0) == 0x0000){	//if button unchecked
			mb_CSettingAdd($cid, 'CList', DBVT_BYTE, 'Invi4Invi', 1);
			mb_DlgListSetItem($dlg, 1000, mt_getvar('selcectedconrow'), 1, 'yes');
			mb_DlgSendMsg($dlg,1001,0x00F1,0x0001,0);//check it
		}else{
			mb_CSettingAdd($cid, 'CList', DBVT_BYTE, 'Invi4Invi', 0);
			mb_DlgListSetItem($dlg, 1000, mt_getvar('selcectedconrow'), 1, 'no');
			mb_DlgSendMsg($dlg,1001,0x00F1,0x0000,0);//uncheck it
		}
	}
}

function closecontactdlg($ok) { 
	mt_delvar('i4idlg');
	mt_delvar('selcectedconcid');
	mt_delvar('selcectedconrow');
	return 1; 
}

//---proto dialog
function protodlg(){
	if(@mt_getvar('i4idlg') == 1){
		mb_msgbox(mb_SysTranslate("Cannot open 2 settings dialogs at once."),"Error: Double settings");
	}else{
		mt_setvar('selcectedprorow',false,1);
		$dlg = mb_DlgCreate('i4i - ignored protocol', 'closeprotodlg', 600, 280,0,1); // $param, $flags;
		$list_cntrl = mb_DlgAddControl($dlg,6,NULL,5,5,585,200,'manageprotodlg',0x00800000|0x0001|0x0004,0); //id=1000
		mb_DlgListAddCol($dlg,$list_cntrl,"ignore",40);
		mb_DlgListAddCol($dlg,$list_cntrl,"Protocol",90);
		mb_DlgAddControl($dlg,2,'none selected',10,210,300,20,'saveprotodlg',0x00000002,0);//1001
		
		$protocols = mb_SysEnumProtocols();
		foreach($protocols as $protocol){
			if(mb_CSettingGet(null,'Invi4Invi',strtolower($protocol))===0)
				$akt = 'yes';
			else
				$akt = 'no';
			mb_DlgListAddItem($dlg,$list_cntrl,$akt,$protocol);
		}
		if(mb_DlgRun($dlg)){
			mt_setvar('i4idlg',1,1);
		}
		mb_DlgMove($dlg, NULL, 150, 200);
	}
}

function manageprotodlg($id,$param,$item,$rb){
	if($item == -1)return 0;
	$dlg = mb_DlgGet(); 
	
		$list_row = $item;
		$proto = mb_DlgListGetItem($dlg,1000, $list_row, 1);
		$akt = mb_DlgListGetItem($dlg,1000, $list_row, 0);
		if($akt=='yes')
			mb_DlgSendMsg($dlg,1001,0x00F1,0x0001,0);
		else
			mb_DlgSendMsg($dlg,1001,0x00F1,0x0000,0);
		mt_setvar('selcectedprorow',$list_row,1);
		mb_DlgSetText($dlg, 1001, 'ignore: '.$proto);		
}
	
//---save proto dialog
function saveprotodlg($ok,$param){
	$dlg = mb_DlgGet();
	if(mt_getvar('selcectedprorow')!==false){
		$list_row = mt_getvar('selcectedprorow');		
		if (mb_DlgSendMsg($dlg,1001,0x00F0,0,0) == 0x0000){	//if button unchecked
			mb_CSettingAdd(null,'Invi4Invi',DBVT_BYTE,strtolower(mb_DlgListGetItem($dlg,1000, $list_row, 1)),0);
			mb_DlgListSetItem($dlg, 1000, $list_row, 0, 'yes');
			mb_DlgSendMsg($dlg,1001,0x00F1,0x0001,0);//check it
		}else{
			mb_CSettingAdd(null,'Invi4Invi',DBVT_BYTE,strtolower(mb_DlgListGetItem($dlg,1000, $list_row, 1)),1);
			mb_DlgListSetItem($dlg, 1000, $list_row, 0, 'no');
			mb_DlgSendMsg($dlg,1001,0x00F1,0x0000,0);//uncheck it
		}
	}
}

function closeprotodlg($ok) { 
	mt_delvar('i4idlg');
	mt_delvar('selcectedprorow');
	return 1; 
}

//---checks/unchecks checkboxes
function checkbox($param){
	$dlg = mb_DlgGet();
	if (mb_DlgSendMsg($dlg,$param,0x00F0,0,0) == 0x0000){	//if button unchecked
		mb_DlgSendMsg($dlg,$param,0x00F1,0x0001,0);//check it
	}else
		mb_DlgSendMsg($dlg,$param,0x00F1,0x0000,0);//uncheck it
}

//---action when clicking  
function contactmenuaction($param,$cid,$hmenu){	//changes contacts handle
	$proto = mb_CGetProto($cid);
	if(mb_CSettingGet(null,'Invi4Invi',trim(strtolower($proto)))===0){
		return 0;
	}elseif(mb_CSettingGet($cid,'CList', 'Invi4Invi')===0){
		mb_CSettingAdd($cid, 'CList', DBVT_BYTE, 'Invi4Invi', 1);
		mb_MenuModify($hmenu, 'monitored by i4i', mb_IconLoadSkin(218), 0x02,'contactmenuaction');
	}else{
		mb_CSettingAdd($cid, 'CList', DBVT_BYTE, 'Invi4Invi', 0);
		mb_MenuModify($hmenu, 'not monitored by i4i', mb_IconLoadSkin(219), 0x00,'contactmenuaction');
	}
}

//---changes Contact menu befor showing
function contactmenuchange($cid, $hmenu){
	$proto = mb_CGetProto($cid);
	if(mb_CSettingGet(null,'Invi4Invi',trim(strtolower($proto)))===0){
		mb_MenuModify($hmenu, 'i4i turned off for '.$proto, mb_IconLoadSkin(229), 0x00,'protodlg');
	}elseif(mb_CSettingGet($cid,'CList', 'Invi4Invi')===0){
		mb_MenuModify($hmenu, 'not monitored by i4i', mb_IconLoadSkin(219), 0x00,'contactmenuaction');
	}else{
		mb_MenuModify($hmenu, 'monitored by i4i', mb_IconLoadSkin(218), 0x02,'contactmenuaction');
	}
}

//---puts people who are on an invi list to ignore list
function invi2ignore(){
	$cid = mb_CFindFirst();
	do{
		if(mb_CSettingGet($cid,'CList', 'Invi4Invi')!==0  && mb_CSettingGet(null,'Invi4Invi',strtolower(mb_CGetProto($cid)))!==0){
			if(mb_CSettingGet($cid,mb_CGetProto($cid), 'ApparentMode')!==0 && mb_CSettingGet($cid,mb_CGetProto($cid), 'ApparentMode')!==false){
				mb_CSettingAdd($cid, 'CList', DBVT_BYTE, 'Invi4Invi', 0);
			}
		}
	}while($cid = mb_CFindNext($cid));
	mb_msgbox(mb_SysTranslate("Done."),"Done");
}

//---deletes people who are not on invi list from ignore list
function continueignore(){
	$cid = mb_CFindFirst();
	do{
		if(mb_CSettingGet(null,'Invi4Invi',strtolower(mb_CGetProto($cid)))!==0){
			if(mb_CSettingGet($cid,mb_CGetProto($cid), 'ApparentMode')===0 || mb_CSettingGet($cid,mb_CGetProto($cid), 'ApparentMode')===false){
				mb_CSettingAdd($cid, 'CList', DBVT_BYTE, 'Invi4Invi', 1);
			}
		}
	}while($cid = mb_CFindNext($cid));
	mb_msgbox(mb_SysTranslate("Done."),"Done");
}

//---checks every Contact
function runComplete(){
	if(mt_getvar('popups'))
		mb_PUMsg('running I4I for complete Clist');
	mt_setvar('I4Iinitized', true, 1);
	mb_SchUnreg('startInvi4Invi');
	$cid = mb_CFindFirst();
	do{
		if(mb_CGetProto($cid)=='')
			continue;
		if(mb_CSettingGet($cid,'CList', 'Invi4Invi')!==0  && mb_CSettingGet(null,'Invi4Invi',strtolower(mb_CGetProto($cid)))!==0){
			if(mb_CGetStatus($cid)==ID_STATUS_INVISIBLE || mb_CGetStatus($cid)==0 || mb_CGetStatus($cid)==ID_STATUS_OFFLINE){
				mb_CSetApparentMode($cid,ID_STATUS_OFFLINE);
			}else{
				mb_CSetApparentMode($cid,null);
			}
		}
	}while($cid = mb_CFindNext($cid));
	if(mt_getvar('popups'))
		mb_PUMsg('Invi4Invi completed Clist scan');
}


//---runs at shutdown
function mbe_ShutDown(){
	$cid = mb_CFindFirst();
	do{
		if(mb_CSettingGet($cid,'CList', 'Invi4Invi')!==0 && mb_CSettingGet(null,'Invi4Invi',trim(strtolower(mb_CGetProto($cid))))!==0){
			mb_CSetApparentMode($cid,null);
		}
	}while($cid = mb_CFindNext($cid));
}

//---visible to all
function visiall(){
	$cid = mb_CFindFirst();
	do{
		if(mb_CSettingGet(null,'Invi4Invi',trim(strtolower(mb_CGetProto($cid))))!==0){
			mb_CSetApparentMode($cid,null);
		}
	}while($cid = mb_CFindNext($cid));
}


//---checks when Contact changes Status
function mbe_CStatus($cid, $known, $module, $setting, $val_type, $value){	//checks for correct visibility if contact change status
	if(mt_getvar('I4Iinitized')==true){
		if(mb_CSettingGet($cid,'CList', 'Invi4Invi')===0 || mb_CSettingGet(null,'Invi4Invi',trim(strtolower(mb_CGetProto($cid))))===0){
			if(mt_getvar('popups'))
				mb_PUMsg('visibility for '.mb_CGetDisplayName($cid).' not set');
			return 0;
		}else{
			if(mb_CGetStatus($cid)==ID_STATUS_INVISIBLE || mb_CGetStatus($cid)==0 || mb_CGetStatus($cid)==ID_STATUS_OFFLINE){
				mb_CSetApparentMode($cid,ID_STATUS_OFFLINE);
				if(mt_getvar('popups'))
					mb_PUMsg(mb_CGetDisplayName($cid).' will not see you');
			}else{
				mb_CSetApparentMode($cid,null);
				if(mt_getvar('popups'))
					mb_PUMsg('visibility for '.mb_CGetDisplayName($cid).' was reset');
			}
			return 0;
		}
	}else
		return 0;
}
?>
