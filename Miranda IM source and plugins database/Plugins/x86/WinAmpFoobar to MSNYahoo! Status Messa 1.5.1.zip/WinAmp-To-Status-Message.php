<?php
/*
WinAMP Music Title to MSN/Yahoo Status Script for MBOT/MSP Version 1.5 made by Daniel Johnston (JohnstonDJ@gmail.com), from Version 1.).), released under the GPL.

LICENSE INFORMATION
-----------------------------------------
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
GPL Licence (http://www.gnu.org/copyleft/gpl.html)
-----------------------------------------
The Full GPL 2.0 license is in the zip file, as GPL-2.0.txt

This is a script that updates the Status Message to display the current song playing in WinAMP (
or Foobar2000 if FOO_WinAMP_SPAM is used), in Miranda. This currently supports the MSN & Yahoo Protocols.

This plugin can support files being skipped. This was added because I didn't want people to know what audio books 
I was reading, only the music I was playing. This is done in Foobar2000 by creating some metadata for the items you want to skip
 (for this example I will use %display%,) and set it to "*" (without the quotation marks).  Then in the Foo_winamp_spam settings
 change it from "[%artist% - ]%title%"  to "[%artist% - ]%title%[%display%]" (without the quotation marks).  It will then not
 show playing information for the files with that metadata.
 
 To do this in WinAMP you can add "*" to the end of the titles you don't want played. Else find a way like Foobar, to add
 some metadata to the end of the title displayed in the process. I will eventually find out how to do this, but it is not high
 on my list, as I use Foobar2000.
 
If there is no song playing or Winamp is not running, nickname appears as you defined.


Version History:
1.5.1: Made it follow the GNU GPL rules, with the GPL2.0 License being attachefd, and a rundown in the code. 
1.5: If the artist ended in ", the" it would delete that, and add "The " to the beginning of the artist
1.4: Made it possible to have files not displayed.
1.3: Cleaned up the code; added seperate status messages for the two protocols. 
1.2: Added Yahoo support, and made the code more moddable.
1.1: Moved the info from the Nickname, to the Personal Comment.
1.0: First Release by: sersiztac (sersiztac@hotmail.com), 
http://addons.miranda-im.org/details.php?action=viewfile&id=2620http://addons.miranda-im.org/details.php?action=viewfile&id=2620

A Big Thank you to:
souFrag [Felipe Brahm] for MBot/MSP Auto Set Nickname and Status Message v0.1.0.2 
http://addons.miranda-im.org/details.php?action=viewfile&id=2319
&
D46MD, Winamp Announcer Script for MSP 2.3b, 
http://addons.miranda-im.org/details.php?action=viewfile&id=2013
*/

// VARIABLES FOR SCRIPT (These are the things you can change)

// What Player are you using. (1 for WinAMP, FooBar200 with foo_winamp_spam; 2 for FooBar2000 natively) FOOBAR NATIVELY IS NOT YET IMPLENTED!
define("PLAYER", "1");

// Status Message for MSN when Music isn't playing:
define("MSN_X1", "");

// Status Message for MSN when Music is playing: (You Can Use %artist$ and %title% keys)
define("MSN_X2", "(8) %artist% - %title%");

// Status Message for Yahoo! when Music isn't playing:
define("YAHOO_X1", "");

// Status Message for Yahoo! when Music is playing: (You Can Use %artist$ and %title% keys)
define("YAHOO_X2", "Currently playing: %artist% - %title%");

//Set to "1" to use on MSN, 0 to not;
define("MSNEXIST", "1");

//Set to "1" to use on YAHOO, 0 to not;
define("YAHOOEXIST", "1");


//Actual Code; Do Not Edit this:

define("PROTOCOL", "MSN"); 
define ("PROTOCOL2", "YAHOO");

function mbot_load()
{
	updateNick();
	mb_SchReg("MusicToStatusMessage", "*/1 * *", "updateNick", 1, 0); // update after every 1 minute (*/1 * *)
}

function updateNick()
{
	if (MSNEXIST == 1)
	{
		if(mb_PGetMyStatus(PROTOCOL) != ID_STATUS_OFFLINE)
		{
			mb_PSetMyAwayMsg(PROTOCOL, NickWithMusic(MSN_X2,PROTOCOL));
		}
	}	
	if (YAHOOEXIST == 1)
	{
		if(mb_PGetMyStatus(PROTOCOL2) != ID_STATUS_OFFLINE)
		{
			mb_PSetMyAwayMsg(PROTOCOL2, NickWithMusic(YAHOO_X2,PROTOCOL2));
		}
	}	
	
}

function NickWithMusic($text,$protocol)
{
	if (PLAYER == 1){
		$find_window = @mb_SysGetProcAddr('user32.dll','FindWindowA');
		$hWND = @mb_SysCallProc($find_window,'Winamp v1.x',0);
	}
	if (PLAYER == 2){
		$find_window = @mb_SysGetProcAddr('user32.dll','FindWindowA');
		$hWND = @mb_SysCallProc($find_window,'{E7076D1C-A7BF-4f39-B771-BCBE88F2A2A8}',0);
	}

	if($protocol == "MSN"){
		if(!$hWND) return MSN_X1;
	}

	if($protocol == "YAHOO"){
		if(!$hWND) return YAHOO_X1;
	}

	$malloc = @mb_SysMalloc(2048);
	$get_window_text = @mb_SysGetProcAddr('user32.dll','GetWindowTextA');
	@mb_SysCallProc($get_window_text,$hWND,$malloc,2048);

	$title = @mb_SysGetString($malloc);


	if (substr($title,0,6) != 'Winamp' && substr($title,0,6) != '')
	{
		$start = StrPos($title,' ')+1;
		$song_info['track'] = SubStr($title,0,$start-2);
		$end = StrPos($title,' - Winamp')-$start;
		$title = SubStr($title,$start,$end);

		$SendMessage = mb_SysGetProcAddr('user32.dll','SendMessageA');
		$song_info['status'] = @mb_SysCallProc($SendMessage,$hWND,0x0400,0,104);

		list($song_info['artist'],$song_info['title']) = split(" - ",$title);
		
		// Removing ", the" from the end, and changing it to "The " at the beginning
		if(substr(strtolower(trim($song_info['artist'])),-5,5) == ', the'){
			$song_info['artist'] = substr($song_info['artist'],0,(strlen($song_info['artist'])-5));
			$song_info['artist'] = chr(84).chr(104).chr(101).chr(32).$song_info['artist'];
		}

		foreach($song_info as $key => $value)
		{
			$key = '%'.$key.'%';
			$text = str_replace($key,$value,$text);
		}
		if(substr(trim($title),-1) == "*"){
			if($protocol == "MSN"){
				return MSN_X1;
			}
			if($protocol == "YAHOO"){
				return YAHOO_X1;
			}
		}
		if($song_info['status'])
			return $text;
		}else
			if($protocol == "MSN"){
				return MSN_X1;
			}
			if($protocol == "YAHOO"){
				return YAHOO_X1;
			}
	else{
		if($protocol == "MSN"){
			return MSN_X1;
		}
		if($protocol == "YAHOO"){
			return YAHOO_X1;
		}

	}
}
?>