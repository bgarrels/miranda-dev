Status Scheduler
-----------------

This plugin lets you set certain times when protocols are "allowed" to be disconnected. If you thig its stupid blame Sybrscribe..

What this does is when a proto goes offline it checks to c wheather it is allowed to...
e.g you can set MSN to automatically reconnect between 8am and 7pm everyday except saturday unless you sign in somehwere else.

The plugin is powerful because the rules system kicks ass :)

even without the rules, the plugin uses a "default action" which works if no rule is present that fits the time/date/proto criteria (splelling???)
You have the choice of doint nothing, forcing it to always reconnect, or only force it to reconnect if you are signed in somewhere else.


How To use SS
--------------
Check out the options page.
The top section lets you set the default action which will be used if there are no rules, or no rules match the date/time/proto thingy..

The bottom 3/4 is used to set rules...
Press "Add" to add a new rule., "Remove" to remove the currently selected rule, "Rename" to rename the currently selected rule.
Rules are checked in order, the first in the drop list is the first checked. use the "Move up" and "Move Down" buttons to change the order

The action is what will happen if the rule is to be followed...
When a proto goes offline each rule is checked in order until one works, in which case the action is done and the checking stops... so order is important.
if "Enabled" is not checked the rule will get skipped.

Changelog
----------

1.1
- added an option "Connect status"
- fixed some gui bugs

1.0
- initial release


Translation
------------

fortunatly there isnt much to translate in this :)

[Enter the new item name]
[Rename item \"%s\"]
[Do not reconnect if disconnected]
[Always Reconnect if disconnected]
[Always Reconnect if disconnected, Unless Connected Elsewhere]
[Enabled]
[Action]
[Rename]
[Days Exception is active]
[Protocols]
[Sunday]
[Monday]
[Tuesday]
[Wednesday]
[Thursday]
[Friday]
[Saturday]
[Times Exception is active]
[All Day]
[Set Period]
[Start]
[End]
[Exception Order and Controls]
[Add]
[Remove]
[Move Up]
[Move Down]

------------------------------------------------------------
(c) 2005 Jonathan Gordon (jdgordy@gmail.com)

contact me on ICQ, MSN, Email or Telepathy... just make sure you tell me who you are or youll get blocked :)
ICQ: 98791178
MSN: jonnog@hotmail.com