About
-----

RandomMessageChanger-Plugin
Version 0.0.2.1
by Christian Weihs (christian.weihs@quantentunnel.de)
http://www.unet.univie.ac.at/~a9825447/rmc.htm


Description
-----------

This plugin automatically changes the status-message on changing
the status or after xx minutes. It loads the messages from a file
and picks one of the stored messages by random.


Option Description
------------------

[ ] Change on status-change:
If activated, the plugin will be triggered by changing the status.

[ ] change every xx minutes
Triggers the plugin every xx minutes after switching the status. So the
first time is xx minutes after the status switch, and then repetitively 
every xx minutes.

[ ] change while away
Enables the plugin for the status "away". So it will change the message
on switching to away (if "change on status-change" is enabled) and 
repetitively every xx minutes (if "change everx xx minutes" is enabled).



Background
----------

I was bored of everyone having the same default away-message and
so I started to change my message from time to time using some
funny notes I found in the usenet or somewhere else. And because
I'm a very lazy person, I wrote this plugin for not to have to
pick a new message for myself.


Features
--------

*) Supports Away, Not Awailable, Occupied, Dnd, and FreeForChat
*) You can specify different files for every status.
*) Can change the message on statuschange
*) Can change the message after some minutes.


Known Problems
--------------

*) Some people are irretated because the Status-Message-Dialog still
   pops up even the plugin is activated. This window can be switched
   off for every status in "Status/AwayMessages".



Installation
------------

Just copy the dll into Miranda's plugin subdirectory and configure
it un the options (Status/Random Messages).


Source
------

Mail me.


Version History
---------------

-> Version 0.0.1.2
File-reading:
| Doesn't crash if lines are longer than 999 chars. (Just cuts the line now.)
| Stops at 500 messages instead of crashing miranda at 100 messages.
| Better opening-sequence: shouldn't have problems with relative paths anymore.

Other Fixes:
| Fixed bug that prevented working at freeforchat and dnd modes on status-change.
| Better compartibility for the optionfont-plugin
| Doesn't interfer with other miranda-options anymore. Should work whatever options
|         in "Status/away messages" are set.

-> Version 0.0.1.1
Supports now multiline-status-messages. Just insert \n in the message for starting a new line.

-> Version 0.0.1.0
added support for the other status-messages
You can specify a file for every status.
Can change the message after xx minutes.

-> Version 0.0.0.2
first release

