********
Paste It
********

Description
===========
Plugin uploads the text to web page and sends the URL to your friend.

Main features
=============
- pastebin.com and wklej.to support
- paste text from clipboard
- paste file from clipboard
- choosing file using file dialog
- ability to set correct file encoding

!!! Requirements !!!
====================
Microsoft Visual C++ 2010 Redistributable Package

Changelog
=========

--- 1.0.0.3 ---
* fixed bad decoding characters from clipboard

--- 1.0.0.2 ---
* increased size of few labels in options

--- 1.0.0.1 ---
* support chat rooms
* fixed mispelling
* fixed bad decoding characters from clipboard
* increased size of few labels in options

--- 1.0.0.0 ---
+ pastebin.com and wklej.to support
+ paste text from clipboard
+ paste file from clipboard
+ choosing file using file dialog
+ ability to set correct file encoding

Author
======
Krzysztof Kral

email:  programista@poczta.of.pl
www:    http://programista.free.of.pl/miranda/
svn:    http://svn3.xp-dev.com/svn/PasteIt/
