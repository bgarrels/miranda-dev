About
~~~~~

Ipper Maniac 0.0.1.24 Plugin for Miranda

This plugin allows you to send your IP-addresses to people
in your contact list with minimal troubles. It is also able
to send IP by remote call.


TODO
~~~~

SRMM multiple messages
Message send error
nConvers support
Filter for answers on remote command

History
~~~~~~~

0.0.1.24

- Bugfix: Updater support
- Feature: MIID_MIPPER {D7569709-0956-45BE-B432-45A4C31EA4E0}
- Misc: Removed InstallScript.xml for MirInst
- Misc: Removed plugin uninstaller support

0.0.1.23

- Bugfix: Support for new tabSRMM
- Feature: Updater support

0.0.1.22

- New homepage

0.0.1.21

- Bugfix: Hotkey support for tab_SRMM

0.0.1.20

- Bugfix: Stupid bug in IP selection window
- Bugfix: SRMM Unicode support

0.0.1.19

- Feature: External IP detection (experemental, thanks to Michael Hennig)
- Feature: Custom lists support
- Feature: Support for the plugin uninstaller
- Feature: Support for InstallScripts for MirInst

0.0.1.18

- Feature: Hotkey support (only for SRMM)

0.0.1.17

- Feature: More macros in templates
- Feature: PPP-addresses detection
- Feature: Template for answers on remote command
- Bugfix: Removed menu item for IRC channels
- Minor bugfixes

0.0.1.12

- Feature: Templates with macros (ip = IP Address, %dns = DNS Address, %nl = Insert new line)
- Feature: Remote send by macro
- Feature: Options dialog with few settings
- Feature: Multi-language support


0.0.0.9

- Feature: Now supports other protocols, I think :)

0.0.0.8

- First stable version


Support and bug reporting
~~~~~~~~~~~~~~~~~~~~~~~~~

Write comments on http://addons.miranda-im.org/details.php?action=viewopinion&id=993


License and Copyright
~~~~~~~~~~~~~~~~~~~~~

Copyright (C) 2003-2007  Alexander Logvinov

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.