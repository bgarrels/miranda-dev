Meebo - Jabber plugin
---------------------

CAUTION: THIS IS AN BETA STAGE PLUGIN. IT CAN DO VERY BAD THINGS. USE AT YOUR OWN RISK.

This is a plugin for the jabber protocol, to make it work better with the meebo service (mainly with the meebo me widget). It also works with libraryh3lp.

It has the following changes regarding the official jabber protocol:
- Option to Automatically authorize new contacts of those services
- Option to Always remove meebo me contacts when they go offline (with or without history)
- Detection of meebo me MirVer
- Better handling of groups and nicks sent by meebo me 

The zip contains also some nice icons made by Angeli-Ka (thanks!).

To make this work you need this mod of jabber that support plugins:
Ansi: http://pescuma.org/miranda/jabber_mp.zip
Unicode: http://pescuma.org/miranda/jabber_mpW.zip

It also need the latest version of miranda (0.8) to correctly handle the option pages.

To report bugs/make suggestions, go to the forum thread: http://forums.miranda-im.org/showthread.php?t=11953 