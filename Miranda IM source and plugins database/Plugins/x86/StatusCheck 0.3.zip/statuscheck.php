<?php
	/*
		statuscheck.php
		--
		The invisible-checking service (invisiblecheck.php) was implemented by kanicq (http://kanicq.ru).
		This script was coded by c4mb3ll, edited by kanicq.

		Version: 0.3 [en] (9.05.2008) by Forrest79 - add all status check

	*/

	define('DEF_SCRIPT_VERSION', '0.3');

	function mbot_load() {
		mb_SelfRegister(MB_EVENT_MENU_COMMAND, 1);
		mb_MenuAdd('Check status', 0, 'ncheck_thread', mb_IconLoadSys(IDI_INFORMATION), 0x00, 1, 'ICQ', 0);

		mb_SelfSetInfo('Invisiblecheck ' . DEF_SCRIPT_VERSION);
	}

	function ncheck_thread($param, $cid, $hmenu) {
		mb_SysBeginThread('ncheck', $cid);
	}

	function ncheck($cid) {
		$uin = mb_CGetUIN($cid);
		$temp = '';

		if(!$fp = fsockopen('kanicq.ru', 80, $errno, $errstr, 30)) echo $errstr. ' (' . $errno . ")\r\n";
		else {
			$post = 'uin=' . $uin;

			$out = "POST /invisible/en/?method=2 HTTP/1.0\r\n";
			$out .= "Accept: */*\r\n";
			$out .= "User-Agent: Miranda IM Invisible-Check Plugin Bot " . DEF_SCRIPT_VERSION . " [en]\r\n";
			$out .= "Host: kanicq.ru\r\n";
			$out .= "Content-Type: application/x-www-form-urlencoded\r\n";
			$out .= "Content-Length: " . strlen($post) . "\r\n";
			$out .= "Cache-Control: no-cache\r\n";
			$out .= "Connection: Close\r\n\r\n";
			$out .= $post;

			fwrite($fp, $out);

			while(!feof($fp)) {
				$temp .= fgets($fp, 4096);
			}

			fclose($fp);
		}

		$temp = implode(' ', explode(chr(13).chr(10), $temp));
		$temp = substr($temp, strpos($temp, '<div id="info">'));
		$temp = substr($temp, 0, strpos($temp, '</b>'));
		$temp = trim(substr($temp, strrpos($temp, '>') + 1));

		$hico = mb_IconLoadSys(IDI_INFORMATION);
		mb_PUAdd($cid, mb_CGetDisplayName($cid), $temp, 0, 0, $hico);

		if($temp == 'Invisible') {
		  mb_CSettingAdd($cid, 'ICQ', DBVT_WORD, 'Status', 40078);
		} else if($temp == 'Free for chat') {
		  mb_CSettingAdd($cid, 'ICQ', DBVT_WORD, 'Status', 40077);
		} else if($temp == 'Occupied') {
		  mb_CSettingAdd($cid, 'ICQ', DBVT_WORD, 'Status', 40076);
		} else if($temp == 'N/A') {
		  mb_CSettingAdd($cid, 'ICQ', DBVT_WORD, 'Status', 40075);
		} else if($temp == 'DND') {
		  mb_CSettingAdd($cid, 'ICQ', DBVT_WORD, 'Status', 40074);
		} else if($temp == 'Away') {
		  mb_CSettingAdd($cid, 'ICQ', DBVT_WORD, 'Status', 40073);
		} else if($temp == 'Online') {
		  mb_CSettingAdd($cid, 'ICQ', DBVT_WORD, 'Status', 40072);
		} else {
		  mb_CSettingAdd($cid, 'ICQ', DBVT_WORD, 'Status', 40071);
		}
	}
?>