IMBlogger plugin
Version 0.0.0.4
by Angelo Luiz Tartari

===========
DESCRIPTION
===========

This plugin allows you to send posts to your blog at Blogger(c) typing 
them in your message window.

===========
INSTALATION
===========

1) Close Miranda IM.
2) Find Miranda main directory (search for miranda32.exe).
3) Put IMBlogger.dll into plugins directory.
4) Start Miranda IM.

==========
HOW TO USE
==========

* Adding a blog to your contact list:

- Change IMBlogger status to Online.
- Go to Main Menu -> Find/Add contacts.
- Choose "IMBlogger" in "Search on" field.
- Put your username in "Nick" field.
- Put your password in "First" field.
- Push Search button.
- Wait until results appear.
- Click in a blog, and add it to your list.

* Sending posts to your blog:

It's the same as sending a message to your buddy.

- Open the message window to your blog.
- Type your post.
- Push Send button.

You can send a post with title using <title> tag in the beginning of your post. Example:

<title>This is the title</title>
This is the body text.

========================
KNOWN PROBLEMS AND HINTS
========================

- Sometimes the posts are sent but not published. You will need login 
to your account in Blogger(c) website and publish there. It is not a 
plugin's fault, all posts are sent with publish parameter turned on.

- IMBlogger sends your posts with full acknowledgement, it means that 
sometimes it can spend more time than Miranda uses for message's 
timeout. If you are getting a lot of timeout warnings, try to use 
TweakMiranda plugin by hrk to increase the timeout time.

- Your messages are sent only if IMBlogger protocol is online.

- There are some hidden settings in IMBlogger like "do not act as a protocol" and "default startup status". You can change them using Database Editor plugin by wintime98. Please, only change settings directly in database if you know what you are doing.
Current user/IMBlogger/AsProtocol : 1 (yes) or 0 (no)
Current user/IMBlogger/StartupStatus : 40071 (offline) or 40072(online)

==========
WHAT'S NEW
==========

0.0.0.4

- Minor fixes and optimizations.

0.0.0.3

- Publish works now.
- Added a contact menu item "publish now".
- Send posts with title.
- More improvements in html parsing.
- New string in translation file.

0.0.0.2

- New advanced features (do not act as a protocol, default startup status). Please read the readme file.
- All posts are sent in HTML Unicode.
- Improvements in html parsing.
- Added a protocol icon.
- Added translation file.
- Added support for PluginSweeper plugin.

0.0.0.1

- First release.

=====
OTHER
=====

Base Address: 0x11110000

======
AUTHOR
======

Email : corsario-br@users.sourceforge.net

You can send me messages in portuguese, english or italian.

Feel free to send me some digital photos of the city that you live in.