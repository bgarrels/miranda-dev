  KexX  
~~~~~~~~

Version 0.0.1.0+
by Michael "Protogenes" Kunz
for Miranda IM


Description
-----------
This the plugin for a game I have done some years ago. The rules are really easy but the game is the more complicated...


How to
------

- install:
copy the dll to the "Miranda IM\Plugins" folder and restart Miranda.

- start a game:
one player opens the game, the other accepts

open:
  right click on an online user in the contactlist to get the contact menu or select this in the message window. There should be an entry "Play KexX"...
  A dialoge appears in which you can choose the size of the field and invite the other player.

accept:
  when you got invited it will be marked with an event in the contact list (flashing icon).
  double click this and you will get an question, if you want to accept the game and if you want to make the first move.

- play:
  you're playing on a hexagon field by placing balls on the fields. every field can hold as much balls as it have surrounding fields (should be 3, 4 or 6).
  When a field is full it "explodes" that means its balls got spread over the neighbors.
  if there are balls from the opponent they will be taken over by the actual player. (be warned of chain reactions)

- win:
  all you have to do is to get all balls from your enemy. the game ends, when one player has no balls left on the field.

- have fun:
  give this game as much Miranda users as you can ;-)


Remarks
-------

first I want to say this is an early release and it may contain some bugs. especially in some weird situations which are hard to test (if some communication aborts because windows crashes or the user lost connection). for exceptions I have included MadExcept to this project and I would be happy if you send me the bug report if something happens.


Thanks to
---------

- my friends who helped me testing
- Mathias Rauen for the excellent MadExcept (www.madshi.net) which helped me finding all the bugs yet
- the graphics32 team (www.graphics32.org)
- last but not least the Miranda IM team