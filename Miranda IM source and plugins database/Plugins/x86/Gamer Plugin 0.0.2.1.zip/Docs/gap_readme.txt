
					Gamer Plugin
					============
					  by eXiTus




1. About
========

Gamer Plugin is a Miranda IM Plugin especially for gamers (Hard to guess :D).
It's an alternative to the gamerStatus Plugin which isn't updated any more. Also it offers some extended features...


2. Features
===========

- Checks the system in a given interval of running processes.
  If one of the defined processes is started, the plugin will change the status automatically and set a special status message.
  Also, it can disable popups and sounds.
  You can define several profiles to adjust the actions accordingly, when an application is started:
		e.g.: when game is running change status to occupied, when watching dvd change status to away...
		Profiles on top of the list have a higher priority, that means:
			Let's assume the first group is 'games' and the sacond group is 'media players'.
			A media player has been started and the status has been changed accordingly.
			Now a game is started and the status will change again.
			If you start the game first and then the media player, nothing happens because the game has  a higher priority.
  After the Application is closed the old status can be restored.
  Works with NewAwaySys

- Offers a special Variable %serverip% (only with variables.dll).
  If you are playing online on a server, this variable contains the ip of the server.
  Supported games:
	Should work with all Multiplayer Games which use UDP Packages to communicate with the server.

- A Server Query Protocol is included, so that game servers can be queried to get some information like:
  Server Name, Current Map, Mod, Players on the Server, Number of Slots
  Supported games:
    > Half Life 1 / Counter-Strike
    > Half Life 2 / Counter-Strike: Source
    > Battlefield 1942
    > Battlefield Vietnam
    > Battlefield 2
    > Unreal Tournament 99, 2003, 2004
	...and much more (most of the games use similar query protocols, so they could work. Please try it out yourself)

    
3. Requirements
===============

Minimum: Windows 95
Miranda IM 0.5 (Maybe it works with older versions - but there won't be any support)
Also highly recommended: Variables.dll

To use the %serverip% variable you also need:
	-Windows XP SP 2
	-Administrator privilege (The Plugin will call a function of the WinApi to listen to the whole network traffic)
	-Variables.dll


4. Instructions
===============

Variables:
%serverip%		returns the serverip in ip:port format on success, otherwise returns NULL
%game%			if an specified .exe is running, returns the name specified in Processlist Dialog for this .exe.
				if nothing (or more than one .exe at the same time) is running it returns NULL

?query(ip:port)		querys the server given as argument, returns %true% on success
			NOTE: YOU MUST DO THAT CALL BEFORE YOU CAN USE THE FOLLOWING VARIABLES
%servername%		shows the servername
%map%			shows the name of the map
%map%			shows the name of the game + mod
%players%		displays the number of players on the server
%slots%			displays the number of slots
	

5. Changelog
============

0.0.2.1
-------
  - Added some query protocols to support more games
  - Added new variable %mod%
  - Changed %serverip% function so that it should work now with every game
  - Added support for disabling popups when running YAPP
  - Popups/Sounds are set back to the original state when miranda is closed while a game/application is still running
  - Fixed the crash when no status is selected at the "Dont change when" field

0.0.2.0
-------
  - Added profile support: 
    Now you can define several profiles with different processes to adjust the behaviour on a status change.
  - Added new options dialog to manage the profiles
  - Added features to disable popups + sounds while process is running
  - Field variables (like %serverip%, %game%, ...) return now NULL instead of %false%

0.0.1.2
-------
  - Bugfix: fixed crash on startup when network adapter without ip (not connected) is installed, thx walla ;)

0.0.1.1
-------
  - Bugfix: fixed problem adding processes in processlist dialog when a languagepack (translation) is installed

0.0.1.0
-------
  - Added the automatic status change feature with support for newawaysys
  - Added options dialog
  - Added query protocol for hl/hl2
  - Added some variables to get the query information

0.0.0.1
-------
  - first release