Quick Contacts plugin
---------------------

On pressing an user defined hotkey an dialog pops up where you can enter a contacts name or select it from a combobox and send it messages/files/urls an look at his details.

This is a mod of the Hotkey plugin by micron-x

To be able to set the hotkey you need clist_modern (or some other that implements Hotkeys2), Hotkeys+ or HotkeyService.

Available hotkeys:
- Ctrl-V: Make a voice call
- Ctrl-F: Send file
- Ctrl-U: Send URL
- Ctrl-I: Show userinfo
- Ctrl-H: Open history
- Ctrl-M: Open contact menu
- User defined: Open hotkey dialog
In Miranda 0.8 all this keys can be configured in options.

To report bugs/make suggestions, go to the forum thread: http://forums.miranda-im.org/showthread.php?t=8797

To report bugs, please create a attache dump using the pdb file (you need to copy to pdb to the same place the dll is)