     E-mage LAN protocol v0.0.1.1
--------------------------------------------

This serverless protocol was designed for communication purposes within LAN.
It is assumed to be used in place of netsend protocol,
as it has more fast and reliable behaviour.
Feel free to use it. :)

This version have just small fixes. I already have newer version which is in alpha state,
but programming free software takes time and programming good software takes even more time :)

Please support me by donating:
You can do it fast and secure via:

1. WEBMONEY
E190618659555 - EUR
R911105092057 - RUS
Z048031422394 - USD

2. E-GOLD
1103974

Also any other they is appreciated. Thanks in advance.

Do not forget to mail me after donating (kva@fromru.com or urgh@tut.by)
Please e-mail me also what features you would like to see in EmLanProto and what software you would like
to be developed.

New emlan branch will be released outside of my home network only if somebody will support my developement.

Coming soon http://kva.com.ru (50% ready) - web page with all my projects.

--------------------------------------------

My Radix is: 0x22
EmLanProto.dll rebase address: 0x22000000

Please send me BUG reports to urgh@tut.by or kva@fromru.com with detailed configuration (plugins, versions), so I'll be able to test.

--------------------------------------------

[NEW BRANCH WILL HAVE]
[+] New ident system - no more identing by IP address
[+] Sending / Receiving contacts
[+] New way for sending status messages
[+] Support of large networks which have several segments with router
[+] more, more and more ...

--------------------------------------------
ChangeLog

[0.0.1.1]
[*] Fixed bug in File Transger - file remained opened after transfer

[0.0.1.0]
[*] Fixed bug with WhoIsReadingAwayMessage plugin

[0.0.0.9]
[*] Fixed great bugs in File Transfer

[0.0.0.8]
[+] Sending to offline users will generate ACKTYPE_FAILED message immediatelly
    nConvers plugin works in wrong way - it assumes that message was sent
    Anyway this should solve problem with hanging while sending messages to multiply users and somebody is offline
[+] Added filesend
[+] Reworked some internal routines

[0.0.0.7]
[+] Added more correct work with Hidden and NotOnList fields
[+] Added URL sending
[*] Plugin was rebased

[0.0.0.6]
[?] Problem with LastSeen module is not EmLanProto problem. seen module checks only for icq and msn status changes
[?] ToolTip plugin works only with UINs e.t.c. So that's why it shows Unsupported user
[+] Added reading and sending away messages. Generally it was something like 'hack' - setting hook for icq
    GETAWAYMSG. But it works OK with all current plugins (AwaySys e.t.c.).

[0.0.0.5]
[!] Fixed problem with last seen module
[!] Fixed big BUG which makes sending status messages too often
[*] Changed status checking procedure a bit

[0.0.0.4]
[!] Fixed bug with sending message without nConvers protocol

-------------------------------------------
Viktor Kuzmin aka KVA of e-mage.  Minsk 2002-2003
