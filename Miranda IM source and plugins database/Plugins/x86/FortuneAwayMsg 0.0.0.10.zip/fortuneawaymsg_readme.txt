		-====================================-
		 FortuneAwayMsg plugin for Miranda-IM
		-====================================-


Description
-----------
This plugin for Miranda-IM doesn't add any functionality on itself. It provides basically three services for retrieving: a) a BSD Fortune message from a random file, b) a BSD Fortune message from a protocol-defined file, and c) a BSD Fortune message from a status-defined file. So, hopefully, the only thing plugin developers will have to do is to define three variables
like %fortunemsg%, %protofortunemsg% and %statusfortunemsg% and call the corresponding service in this plugin in order to retrieve the fortune msgs.


Installation
------------
Unzip fortuneawaymsg.dll to the Miranda IM plugin folder or install via Miranda Installer.
You need of course some BSD Fortune files. Grab it from here (blabla's plugin): http://www.miranda-im.org/download/feed.php?dlfile=1244


Variables
---------
You can use it with Variables plugin (v.0.2.0.0+), this way with both you may use the %fortunemsg% variable in any plugin that supports variables (like AdvancedAutoAway, SimpleAway or NAS).


Options
-------
Options page Options->Status->Fortune Messages.


Thanks
------
- UnregistereD for help, ideas and support in variables plugin
- Leecher for encouraging and providing with the necessary tools
- Blabla for kindly sending me the sources of original fortune plugin (from which I took completely the random file selection code)
- Harven for discussion and support to this plugin
- JDGordon/Targaff for helping with the Endianism thing
- Amp from the forums who provided a patched version compatible with latest Variables
- simpleaway, ieview, messagesound and skype plugins' authors for part of their code I use in the Options page
- Miranda IM developers for this amazing program
- all other people from Miranda community


Changelog
---------
0.0.0.10:
- Added support for Miranda 0.8.x.x.
0.0.0.9:
- Fixed bug in Options dialog.
0.0.0.8:
- Fixed another bug with Variables: szHelpText should not be NULL, despite what m_variables.h says.
0.0.0.7:
- Fixed small bug that caused Variables to crash at startup.
0.0.0.6:
- Patch for latest Variables by amp
- Small cahnge in Options page (show protocol description instead of protocol indentifier in Protocol combo box).
0.0.0.5:
- Added support for dbEditor++ plugin
- Added Support for Update plugin.
0.0.0.4:
- Added option to specify maximum fortune length for the %protofortunemsg% variable.
0.0.0.3:
- Fixed problem with truncation of multiline fortunes in IRC (by not replacing CR/LF pairs by single LF).
- Added an option to remove the CR character, just in case someone needs it.
0.0.0.2:
- Fist release version.


License
-------
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


=====================================================================
Copyright (C) 2005 TioDuke
mailto: tioduke@yahoo.ca
