		-========================-
		 TV plugin for Miranda IM
		-========================-

Description
-----------
This plugin for Miranda IM is simple pseudo protocol with TV listing. You can have your 
favorite TV channels on your contact list just like normal contacts. Plugin support
TV guide for each channel, quick overview of what you can watch now on TV, simple scheduler
with popup/dialog and sound notification.


Requirements
------------
- Windows 2000, XP, Vista
- Miranda IM (Unicode) 0.7+
- Popup plugin for scheduler

Installation
------------
Unzip tvplugin.dll to the Miranda IM plugins folder.
You can add new channels via standard Find/Add Contacts dialog.

Options
-------
Main:   Options - Plugins - TV plugin
Fonts:  Options - Customize - Fonts - TV
Icons:  Options - Customize - Icons - TV
Sounds: Options - Customize - Sounds - TV    

Shortcuts
---------
ALT + UP/DOWN/LEFT/RIGHT - navigation in TV guide
ALT + ENTER 		 - program info
ALT + X 		 - toggle guide / overview

Thanks
------
- Luciferka (for nice icons :)

========================================-
Copyright (C) 2008-2011 yaho
mailto: yaho@miranda-easy.net 
http://miranda-easy.net