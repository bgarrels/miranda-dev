 *  xfire miranda plugin Copyright (C) 2008 by dufte aka andreas h. <dufte@justmail.de>
 *
 *  xfirelib - C++ Library for the xfire protocol. 
 *  Copyright (C) 2006 by
 *          Beat Wolf <asraniel@fryx.ch> / http://gfire.sf.net
 *          Herbert Poul <herbert.poul@gmail.com> / http://goim.us
 *    http://xfirelib.sphene.net
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
 *

INSTALLING:

	Extract the xfire folder directly to the Miranda folder.
	Move the plugin "XFire.dll" to the plugin folder.

FIRST START:

	On the first start, the XFire plugin will search for games for game detection.
	It will then display a summary of which games have been found.
	The game detection and game parsing will only work if there is a xfire_games.ini in the XFire folder.
	Thereafter the plugin scans the running processes for games every 12 seconds.

	If you update the xfire_games.ini you can rescan your computer via "Main Menu/XFire/Rescan my Games ...".
	If you want to see the icon for a contact's games you need to put the original icons.dll from XFire in the XFire folder.
	The playing information will be displayed as xstatus in miranda. If the contact is playing on a server, it will also display
	the server IP and port. Currently there is no join button, but you can copy the IP and port to the clipboard by right-clicking
	on the contact and choosing "XFire/Copy ServerIP and Port".

	To log in, first go to the XFire options and enter your XFire login data. When you first log in
	it will try to get the avatar for each of your contacts by parsing the contact's online profile and
	storing it in the avatars folder. It isn't yet possible to get the avatar of contacts who
	who dont allow their profile to be viewed online.

	You can now chat with your contacts.

FEATURES:

	- avatar support (experimental)
	- metacontact support
	- custom folder support
	- metacontact support
	- game icon and game status for contacts with ip/port (xfire_games.ini and icons.dll needed)
	- full game detection (supports all games listed in the xfire_games.ini)
	- typing notification
	- custom nick is possible
	- goto online profile (own and contact's)
	- friend request/add friends
	- right-click to join server
	- manually setup the gamelist
	- detect serverip and port
	- automatically update xfire_games.ini and icons.dll
	- friends of friend


BUGS/FEATURE REQUESTS:
	- file transfer
	- groupchat


	If you found bugs, translation issues or have a feature request, please contact me!

		<dufte@justmail.de>

SOURCECODE:

	If you want to get the sourcecode, simply contact me also. :)

BIG THANKS TO:

	dennis s. for the icon :)
	AImXOo0o, K1ll3r8e for testing^^

Last change - 27.4.2008