WoordLookUp is a plugin to lookup words from received messages in five
different search  engines. You can configure them free, or use the predefined
engines which are Google, Wikipedia, Leo, E-Bay and www.miranda-im.org.

First time use:
Go to Optionen->Plugins->WordLookUp and configure your search engines
or press "Load defaults"

Note: If you want to compile the source you have to download LibCTiny from
http://msdn.microsoft.com/msdnmag/issues/01/01/hood/default.aspx
and copy LIBCTINY.LIB to your VisualStudio LIB directory.

PS: 
The <- and -> buttons: The only function of these buttons is to set the position
of the WordLookUp window next to the message window or on the right side of your
desktop. There is no docking function behind these buttons.

