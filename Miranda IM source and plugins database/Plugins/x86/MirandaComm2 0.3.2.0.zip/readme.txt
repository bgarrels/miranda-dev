MirandaComm Plugin v. 0.3.2.0 by Hermes (weiser(dot)philipp(at)gmail(dot)com)
-----------------------------------------------------------------------------

See mchelp
