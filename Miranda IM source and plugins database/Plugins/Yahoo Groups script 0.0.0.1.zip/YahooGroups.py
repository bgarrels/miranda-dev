#This script will try to import all the groups you have in Yahoo Messenger into Miranda.
#If a group does not exist it will be created.
#Be careful: This script will move all the yahoo contacts from their current groups into the groups they are in in Yahoo Messenger!

#Use with care.

#To run simply write the following in MirPy's console window:
#import YahooGroups #YahooGroups is the name of this file
#YahooGroups.YahooGroups() #this will move all Yahoo contacts to their groups from Yahoo Messenger.


import database

availableGroups = {}

def GetContactProtocol(hContact):
	return database.GetContactSettingString(hContact, "Protocol", "p", None)

def ReadGroups():
	"""Reads all the available groups.
	"""
	print "Reading available groups ...",
	index = 0
	module = "CListGroups"
	ok = True
	while ok:
		value = database.GetContactSettingString(0, module, str(index), None)
		if value != None:
			availableGroups[index] = value[1:]
			index += 1
		else:
			ok = False
	print "finished."

def GetNextGroupIndex():
	index = 0
	module = "CListGroups"
	while database.GetContactSettingString(0, module, str(index), None) != None:
		index += 1
	return index

def GroupExists(group):
	"""Returns True if the group exists, False otherwise.
	"""
	return group in availableGroups.values()

def CreateGroup(group):
	"""This will create a new group (and all subgroups) if they're not already available.
	To create nested groups use the following syntax "Group\Subgroups".
	"""
	prev = ""
	module = "CListGroups"

	for subgroup in group.split("\\"):
		name = prev + subgroup
		value = chr(1) + name
		if prev == "":
			prev = subgroup + "\\"
		else:
			prev = prev + subgroup + "\\"
		if not GroupExists(name):
			index = GetNextGroupIndex()
			database.WriteContactSettingString(0, module, str(index), value) 
			availableGroups[index] = name
			print "Created group[%d] = %s" % (index, name)
		#else:
			#print "Group '%s' already exists" % (name)
			
def ProcessContacts(callback, param):
	"""This method will iterate over all contacts and call a callback function that performs an action on the contact handle it receives.
	"""
	print "Starting to process contacts using callback", callback.__name__, "..."
	hContact = database.ContactFindFirst()
	while hContact != 0:
		callback(hContact, param)
		hContact = database.ContactFindNext(hContact)
	print "Finished processing contacts."

def ResetGroupCallback(hContact, protocol):
	"""This callback method will reset the groups for all contacts or the contacts of a given protocol.
	To reset the group for all contacts use pass None as the parameter.
	"""
	if (protocol == None) or (protocol == GetContactProtocol(hContact)):
		database.DeleteContactSetting(hContact, "CList", "Group")
	
def YahooGroupCallback(hContact, param):
	"""This callback method will create the group the contact is in in Yahoo Messenger.
	If the contact is not a yahoo contact then the method will do nothing.
	Callback parameter is not used.
	"""
	protocol = GetContactProtocol(hContact)
	if protocol != None:
		ygroup = database.GetContactSettingString(hContact, protocol, "YGroup", None)
		if ygroup != None:
			#valid yahoo protocol
			CreateGroup(ygroup)  #create the group if it doesn't exist
			database.WriteContactSettingString(hContact, "CList", "Group", ygroup) #move the contact to the group
			

def YahooGroups():
	"""This method will move all yahoo contacts to their groups as found in Yahoo Messenger.
	It will only move contacts from a yahoo protocol, all other contacts are left in place.
	"""
	ProcessContacts(YahooGroupCallback, None)

def ResetGroups(protocol = None):
	"""This method will reset the groups of all contacts or those of a given protocol.
	Group names are not removed, only the contacts are moved from the groups.
	"""
	ProcessContacts(ResetGroupCallback, protocol)	

ReadGroups() #read currently available groups (init)